old_intro_text = """Welcome back once again Wizard, to the ruins of the universe.

Aeons passed while you slumbered.
You have sleptwalk across many worlds.

Weep for Avalon, o lonely old Wizard!
Love and beauty transmuted to chaos and ruin.

Your beloved Avalon, and you, her loyal servant, as well.

Once a great Wizard,
Your memories and magics have faded.

Now a thirst for revenge awakens you.
The Dark Wizard Mordred is nearby.

Regain your power.
Slay Mordred.
Vengeance for Avalon.
"""

intro_text = """

Awaken, Wizard

Long have you wandered amongst the stars

While you rested, your deeds have become myth, and your powers faded to nought
Ages have come and gone, and Avalon has fallen into ruin
Your ancient foe has risen once more

Mordred's hand reaches ever forth, his hunger endless, his malice without measure 
Where his shadow falls, the world withers and cries out in torment
In the darkest night, your light sparks to life

The rift stands open
Avalon calls her champion

Take up your staff and your cloak
Go forth, and slay Mordred

"""

old_victory_text = """VICTORY

Mordred is defeated.

Order and justice will soon return to the universe.

Exhausted, you fade from conciousness back into sleep.

Perhaps this time, you may dream.
"""

victory_text = """The Dark Wizard is slain

His beasts have been broken and made tame

The beauty of Avalon will be built again

Your soul is permitted to sleep and dream once more

"""

deploy_text = """You have stepped halfway through the rift  
You may choose any point in the next realm to materialize at\n(Enter or Left click)
If you wish you may instead step out of this rift and return to the previous realm\n(Esc or Right click)
Beware, for once you enter, there will be no way to return"""

credits_text = """CREDITS

Dylan White - Design and Programming
Jacob Martinez - Design and Programming
K.Hoops - Art, Sound, and Music

Special Thanks:
Sean Conrad - Hammered Dulcimer, Guitar, Piano
Seth Pulver - Drums

Thanks to our playtesters:
Flameberger
ratbuddy
Tcrs
Leximancer
Shake The Box
"""

how_to_play_controls = """
[H:shields]: Help (This Screen)      [C:shields]: Character Sheet      [S:shields]: Learn Spells     [E:shields]: Craft Equipment

[Left Click / Enter:shields]: Move, or cast the selected spell at the cursor
[Right Click / Esc:shields]: Cancel the current spell or exit the current menu

[Numpad:shields]:
  [7 8 9:shields]
  [4   6:shields]  -> Move the wizard or targeting reticule one space in the corresponding direction
  [1 2 3:shields]

[Numpad 5:shields]: Pass the turn

[1 2 3 4 5 6 7 8 9 0:shields]: Cast/Select spell 1-10

[PGUP/PGDN or Mouse Wheel:shields]: Next/Previous page to view related information while examining something

"""

how_to_play_advanced_controls = """
[L:shields]: Show line of sight
[T:shields]: Show threatened tiles
[Y:shields]: Show threatening enemies

[I:shields]: Highlight enemies
[U:shields]: Highlight allies
[O:shields]: Highlight objects

[Tab:shields]: Next target
[M:shields]: Show message log

[V:shields]: Look (target a square to look, tab target to look at interesting places)
[W:shields]: Walk (target a square to walk there, tab target to walk to interesting places)
[A:shields]: Autopickup loot (after clearing level)

[Shift + Up/Down Arrow:shields]: While in the character sheet, change selected spell hotkey or equipment position
[Right Click:shields]: If hovering over a spell in the character panel, open that spell's upgrade menu
[Period:shields]: Interact with the tile you are on (enter portal, open shop)

See the Rebind Controls menu for further controls / hotkeys
"""

how_to_play_status_effects = """
[asseticon:stun] Stunned: Cannot act
[asseticon:petrified] Petrified: Cannot act. Gain 100 Ice and Lightning resist. Gain 75 Physical and Fire resist
[asseticon:glassed] Glassified: Cannot act. Gain 100 Ice and Lightning resist. Gain 75 Fire resist. Lose 100 Physical resist
[asseticon:sleep] Sleep: Cannot act. Ends upon taking any damage that is not Arcane or Dark
[asseticon:fear] Fear: Cannot willingly act. Each turn, automatically attempt to move away from enemies
[asseticon:frozen] Frozen: Cannot act. Ends upon taking Fire or Physical damage. 100 Ice resist prevents and cures freezing
[asseticon:poison] Poisoned: Take 1 Poison damage each turn and cannot heal. 100 Poison resist prevents and cures poison
[asseticon:bleed] Bleed: Take 3 Physical damage each turn. 100 Physical resist prevents and cures bleeding
[asseticon:necrosis] Necrosis: Lose 1 max HP each turn. 100 Dark resist prevents and cures necrosis
[asseticon:soaked] Soaked: Gain 50 Fire resist. Lose 50 Ice and Lightning resist
[asseticon:berserk] Berserked: Become hostile to all other units. May attack and be attacked by allies
[asseticon:immobile] Immobilized: Cannot walk
[asseticon:silence] Silenced: Cannot cast non-melee spells
[asseticon:blind] Blind: All spell ranges reduced to 1

[asseticon:quickcast] Quickcast: Casting spells uses only half of a turn
[asseticon:quickmove] Quickstep: Moving uses only half of a turn
[asseticon:channeling] Channeling: The spell's effect repeats on the same target until another action is taken
[asseticon:reincarnation] Reincarnate: On death, come back to life at a random location on the map with full HP
[asseticon:clarity] Clarity: Removes and prevents Stunned, Fear, Petrified, Glassified, Frozen, and Silenced
"""

how_to_play_misc_tips = """
Up to 10 spells and 2 upgrades for each can be purchased with SP
Any number of equipments can be crafted using the components you find

Spells and Equipment are only affected by bonuses to attributes in their tooltips
Attribute bonuses come in the form of percent-based and flat bonuses, and are applied in that order

Spells and Equipment can be filtered using the provided filters and with the search function
Filters can be activated by clicking or SHIFT clicking the filter, or by using their hotkeys
You can begin searches with \ to search for exact phrasing, i.e. \ adds the fire tag

Selecting equipment you cannot craft marks it as desired and adds it to your character panel
Left Click a desired item or use SHIFT 1 - 3 to craft it if possible or remove it otherwise

When something says it casts a spell or gains a spell, it will use your version of that spell
Even if you don't own the spell in question, any relevant bonuses you have will be applied

Extra tooltips while examining Rifts and Components contain a Prospective Equipment page
Prospective Equipment cannot be crafted at that moment, but could if you had the component(s) in question

Each level, you can reroll rifts once, closing the existing rifts and opening new ones

Mastery is the sum total SP cost of spells you own with a given tag, including applied upgrades
Hover over a tag filter in the Spell or Equipment shop to see your current mastery for that tag

[SH:shields] or Shields, block an instance of damage, regardless of how large or small
"""

frozen_desc = "[Frozen] units cannot act\nFrozen units unfreeze upon taking [Fire] or [Physical] damage"

petrify_desc = ("[Petrified] units cannot act\n"
				"[Petrified] units gain [100 Ice:ice] resist\n"
				"[Petrified] units gain [100 Lightning:lightning] resist\n"
				"[Petrified] units gain [75 Physical:physical] resist\n"
				"[Petrified] units gain [75 Fire:fire] resist")

glassify_desc = ("[Glassified] units cannot act\n"
				"[Glassified] units gain [-100 Physical:physical] resist\n"
				"[Glassified] units gain [100 Ice:ice] resist\n"
				"[Glassified] units gain [100 Lightning:lightning] resist\n"
				"[Glassified] units gain [75 Fire:fire] resist")

stun_desc = "[Stunned] units cannot act"
berserk_desc = "[Berserk] units are hostile to all other units, they will attack and be attacked by their allies"
poison_desc = "[Poisoned:poison] units take 1 [Poison] damage each turn and cannot heal"
blind_desc = "[Blind] units have all their spell ranges reduced to 1"

GAIN_PCT_COLORED = "{name} gains [{val}% {attr_label}:{attr_key}]"
GAIN_PCT_PLAIN   = "{name} gains {val}% {attr_label}"
GAIN_VAL_COLORED = "{name} gains [{val} {attr_label}:{attr_key}]"
GAIN_VAL_PLAIN   = "{name} gains {val} {attr_label}"

ALL_GAIN_PCT = "All spells and equipment gain [{val}% {attr_label}:{attr_key}]"
ALL_LOSE_PCT = "All spells and equipment lose [{val}% {attr_label}:{attr_key}]"
ALL_GAIN_VAL = "All spells and equipment gain [{val} {attr_label}:{attr_key}]"
ALL_LOSE_VAL = "All spells and equipment lose [{val} {attr_label}:{attr_key}]"

TAG_PCT_BONUS = "[{tag_label}:{tag_key}] spells and equipment gain [{val}% {attr_label}:{attr_key}]"
TAG_VAL_BONUS = "[{tag_label}:{tag_key}] spells and equipment gain [{val} {attr_label}:{attr_key}]"

SPELL_LEVEL = "Level {level}"
SPELL_RANGE = "Range {range} {los}"
SPELL_CHARGES = "Charges: {cur}/{max}"
SPELL_HP_COST = "HP Cost: {cost}"
SPELL_MELEE_RANGE = "Melee Range"
SPELL_QUICK_CAST = "Quick Cast"
SPELL_IGNORES_LOS = "(Ignores LoS)"
SPELL_COOLDOWN_LABEL = "Cooldown"

RESIST_VAL = "{val}% Resist {tag_label}"

STATLINE = "{value} {attr_label}"
COOLDOWN = "{value} turn cooldown {remaining}"

TAG_ADD = "\nAdds the [{tag_label}:{tag_key}] tag"

UNIT_HP = "[HP:{color}] {cur}/{max}"
UNIT_SH = "[SH:{color}] {num}"

STATUS_LINE = "YOU ARE {status}"

DMG_VAL_ONLY = "{val} damage"
DMG_VAL_TYPED_ONE = "{val} {type} damage"
DMG_VAL_TYPED_LIST = "{val} {types} damage"

COLORED_TAG = "[{tag_label}:{tag_key}]"

AND = " and "
OR = " or "


# Logging Strings
PAY_HP = "{unit} pays {cost} HP for {spell}"
DMG_BLOCKED = "{unit} blocked [{amount} {dtype_label}:{dtype_key}] from {source}"
DMG_DEALS = "{owner} deals [{amount} {dtype_label}:{dtype_key}] damage to {unit} with {source}"
KILLED_BY_UNIT = "{unit} killed by {owner} {source}"
KILLED_BY_ENV = "{unit} killed by {source}"
DMG_TAKES = "{unit} takes [{amount} {dtype_label}:{dtype_key}] damage from {source}"
HEAL_BY = "{owner} heals {unit} for [{amount}:heal] with {source}"
HEAL_FROM = "{unit} is healed for [{amount}:heal] from {source}"
DMG_CAP = "{unit} reached the repeated damage safety limit for the turn"
BUFF_APPLIED = "{buff} applied to [{unit}:{color}] for [{amount} turns:duration]"
PERMANENT_BUFF_APPLIED = "{buff} applied to [{unit}:{color}]"
USE_SPELL = "[{unit}:{color}] uses {spell}"
SPELL_CAST_CAP_REACHED = "[Congratulations Wizard!:wizard] queued spell reactions exceeded the safety limit.\nFurther queued casts were cancelled to prevent infinite recursion."

# Component Logging
HP_INCREASE = "[{component}:blood] increased your max HP by {amt}"
SPELL_STAT_INCREASE = "[{component}:{tkey}] increased {spell}'s {attr} by {amt}"
