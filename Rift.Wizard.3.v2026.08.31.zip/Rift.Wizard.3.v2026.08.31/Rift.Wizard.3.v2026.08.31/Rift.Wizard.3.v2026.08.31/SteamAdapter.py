import struct, ctypes, ctypes.util # PyInstaller wipes get_arch, restore it here for steamworks
if not hasattr(ctypes.util, "get_arch"): ctypes.util.get_arch = lambda: "x64" if struct.calcsize("P")*8==64 else "x86"

import steamworks
import dill as pickle
import os
import sys

import logging
stats_log = None
stats_log = logging.getLogger("Stats")
stats_log.setLevel(logging.DEBUG)
stats_log.propagate = False
stats_log_handler = logging.FileHandler('stats_log.txt', mode='a')
stats_log_formatter = logging.Formatter('%(asctime)s: %(message)s')
stats_log_handler.setFormatter(stats_log_formatter)
stats_log.addHandler(stats_log_handler)

from LevelGen import all_monster_names
from Level import LAST_LEVEL

import Mutators

trial_names = {t.name for t in Mutators.all_trials}


def get_runtime_dirs():
	dirs = []
	if getattr(sys, 'frozen', False):
		dirs.append(os.path.dirname(sys.executable))
		meipass = getattr(sys, '_MEIPASS', None)
		if meipass and meipass not in dirs:
			dirs.append(meipass)
		internal_dir = os.path.join(os.path.dirname(sys.executable), '_internal')
		if internal_dir not in dirs:
			dirs.append(internal_dir)
	else:
		dirs.append(os.getcwd())
		dirs.append(os.path.dirname(os.path.abspath(__file__)))
	return dirs


def find_runtime_file(filename):
	for base_dir in get_runtime_dirs():
		path = os.path.join(base_dir, filename)
		if os.path.isfile(path):
			return path
	return None

default_vals = {
	'w': 0, # wins
	'r': 0, # highest realm reached
	's': 0, # current win streak
	'l': 0, # losses / abandoned or overwritten runs
	'i': 0, # improviser streak
	'trials': set(), # Set of strings of names of finished trials
	'unlocked_outfits': set(), # Set of strings of unlocked wardrobe asset names
	'bestiary': set(), # Set of strings of defeated monster names
	'purchases': set(), # Set of strings of spells and skills ever purchased
	'victories': set(), # Set of strings of spells and skills ever won with
	'achievements': set(), # Set of strings of locally unlocked achievement ids
	'vaults': set(), # Set of strings of completed vault ids
}

def save_stats():
	with open('stats.dat', 'wb') as stats_file:
		pickle.dump(stats, file=stats_file)


_sw = None
rich_presence_flat = None
rich_presence_failed = False
def try_get_sw():
	global _sw

	# If sw was succesfully initialized before, just return it
	if _sw: return _sw

	# Else try to initialize it
	try:
		initialized_sw = steamworks.STEAMWORKS()
		initialized_sw.initialize()
		initialized_sw.RequestCurrentStats()
		_sw = initialized_sw
		stats_log.debug("Steamworks initialized and connect")
		return _sw
	except Exception as exc:
		stats_log.debug("Steamworks failed to initialize or connect: %s" % exc)
		return None

def try_get_rich_presence():
	global rich_presence_flat
	global rich_presence_failed

	if rich_presence_flat: return rich_presence_flat

	if rich_presence_failed: return None

	s = try_get_sw()
	if not s: return None

	try:
		steam_api_path = find_runtime_file('steam_api64.dll')
		if not steam_api_path:
			rich_presence_failed = True
			return None
		steam_api = ctypes.CDLL(steam_api_path)
		steam_api.SteamAPI_Init.restype = ctypes.c_bool
		init_result = steam_api.SteamAPI_Init()
		# Enable these while validating rich presence init/write/readback against Steamworks.
		# stats_log.debug("Steam rich presence SteamAPI_Init result %s" % init_result)
		if not init_result:
			rich_presence_failed = True
			stats_log.debug("Steam rich presence unavailable: SteamAPI_Init failed")
			return None

		get_friends = None
		for version in ['SteamAPI_SteamFriends_v017', 'SteamAPI_SteamFriends_v016', 'SteamAPI_SteamFriends_v015']:
			try: get_friends = getattr(steam_api, version); break
			except AttributeError: continue

		if not get_friends:
			rich_presence_failed = True
			stats_log.debug("Steam rich presence unavailable: no SteamFriends flat API export")
			return None

		get_friends.restype = ctypes.c_void_p
		set_presence = steam_api.SteamAPI_ISteamFriends_SetRichPresence
		set_presence.restype = ctypes.c_bool
		set_presence.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_char_p]
		clear_presence = steam_api.SteamAPI_ISteamFriends_ClearRichPresence
		clear_presence.restype = None
		clear_presence.argtypes = [ctypes.c_void_p]
		get_presence = steam_api.SteamAPI_ISteamFriends_GetFriendRichPresence
		get_presence.restype = ctypes.c_char_p
		get_presence.argtypes = [ctypes.c_void_p, ctypes.c_uint64, ctypes.c_char_p]
		friends = get_friends()
		if not friends:
			rich_presence_failed = True
			stats_log.debug("Steam rich presence unavailable: SteamFriends interface missing")
			return None

		rich_presence_flat = (friends, set_presence, clear_presence, get_presence)
		# stats_log.debug("Steam rich presence flat API initialized")
		return rich_presence_flat
	except Exception as exc:
		rich_presence_failed = True
		stats_log.debug("Steam rich presence unavailable: %s" % exc)
		return None

def apply_rich_presence(pairs):
	rich_presence = try_get_rich_presence()
	if not rich_presence: return False

	friends, set_presence, clear_presence, get_presence = rich_presence
	clear_presence(friends)
	results = []
	for key, value in pairs:
		result = set_presence(friends, key.encode('ascii'), value.encode('ascii'))
		# stats_log.debug("Steam rich presence %s=%s result %s" % (key, value, result))
		results.append(result)
	current_id = _sw.GetSteamID() if _sw else 0
	if current_id:
		for key, _ in pairs:
			value = get_presence(friends, current_id, key.encode('ascii'))
			value = value.decode('utf-8') if value else ""
			# stats_log.debug("Steam rich presence readback %s=%s" % (key, value))
	return all(results)

def init():

	# Try loading stats pickle
	global stats
	if os.path.exists('stats.dat'):
		with open('stats.dat', 'rb') as stats_file:
			stats = pickle.load(stats_file)
	else: stats = {}

	for k, v in default_vals.items():
		if k not in stats:
			stats[k] = v

	# Try to init sw
	try_get_sw()



def get_stat(stat):
	# Disable for now
	# Try to init sw- updating stats dict if needed
	try_get_sw()
	return stats[stat]
	
def set_stat(stat, val):
	stats_log.debug("Setting %s to %s" % (stat, val))
	stats[stat] = val
	save_stats()
	s = try_get_sw()
	if s:
		s.SetStatInt(stat.encode('ascii'), val)
		s.StoreStats()

def set_presence_menu():
	s = try_get_sw()
	if s:
		rich_presence = try_get_rich_presence()
		if rich_presence:
			friends, _, clear_presence, _ = rich_presence
			clear_presence(friends)
		else: s.ClearGameInfo()

def set_presence_game(game):
	if not game: set_presence_menu(); return
	s = try_get_sw()
	if not s: return

	level = str(game.level_num)
	trial_name = game.trial_name if game.trial_name in trial_names else None
	name = None
	gen_params = game.cur_level.gen_params
	if game.level_num == LAST_LEVEL: name = "Mordred"
	elif game.level_num == LAST_LEVEL - 1 and gen_params.bosses: name = gen_params.bosses[-1].name

	pairs = [('level', level)]
	if trial_name: pairs.append(('trial', trial_name))
	if name: pairs.append(('name', name))

	if name: pairs.append(('steam_display', '#Status_FightTrial' if trial_name else '#Status_Fight'))
	else: pairs.append(('steam_display', '#Status_LevelTrial' if trial_name else '#Status_Level'))

	if not apply_rich_presence(pairs):
		s.SetGameInfo('level'.encode('ascii'), level.encode('ascii'))
		s.SetGameInfo('steam_display'.encode('ascii'), '#Status_Level'.encode('ascii'))

def get_installed_workshop_items():
	s = try_get_sw()
	if not s:
		return []

	try:
		item_ids = s.Workshop.GetSubscribedItems()
	except Exception as exc:
		stats_log.debug("Workshop item enumeration failed: %s" % exc)
		return []

	items = []
	for item_id in item_ids:
		state = None
		try:
			state = s.Workshop.GetItemState(item_id)
		except Exception as exc:
			stats_log.debug("Workshop item state query failed for %s: %s" % (item_id, exc))

		try:
			info = s.Workshop.GetItemInstallInfo(item_id)
		except Exception as exc:
			stats_log.debug("Workshop item install query failed for %s: %s" % (item_id, exc))
			continue

		if not info or 'folder' not in info:
			stats_log.debug("Workshop item %s is not installed yet (state=%s)" % (item_id, state))
			continue

		folder = info['folder']
		if not folder or not os.path.isdir(folder):
			stats_log.debug("Workshop item %s returned invalid folder %s" % (item_id, folder))
			continue

		items.append({
			'item_id': item_id,
			'folder': folder,
			'state': state,
		})
	return items

def get_trial_status(trial_name):
	result = trial_name in stats["trials"]
	return result

def get_achievement_status(achievement_name):
	return achievement_name in stats["achievements"]

def is_outfit_unlocked(outfit):
	if outfit.asset_name in stats["unlocked_outfits"]: return True
	if outfit.unlock_achievement is None: return True
	return get_achievement_status(outfit.unlock_achievement)

def unlock_achievement(name):
	# print(f"Achievement Unlocked: {name}") # for testing purposes
	if name not in stats["achievements"]:
		stats["achievements"].add(name)
		save_stats()

	s = try_get_sw()
	if s:
		s.SetAchievement(name.encode('ascii'))
		s.StoreStats()


def unlock_all_spells_learned():
	unlock_achievement("ALL_SPELLS_LEARNED")

def unlock_all_equipment_learned():
	unlock_achievement("ALL_EQUIPMENT_LEARNED")

def unlock_all_spells_victoried():
	unlock_achievement("ALL_SPELLS_VICTORIED")

def unlock_all_equipment_victoried():
	unlock_achievement("ALL_EQUIPMENT_VICTORIED")

equipment_set_achievements = {
	"ARCHANGEL_SET": {"Archangel's Halo", "Archangel's Armor", "Archangel's Spear"},
	"CRIMSON_SET": {"Crimson Torc", "Crimson Coronet", "Crimson Brooch"},
	"DRAGON_SET": {"Drakenstaff", "Wyrm Spirit Armor", "Dragonspine Cloak", "Chaos Scale Crown"},
	"GALVANIC_SET": {"Galvanic Focus", "Galvanic Blade", "Galvanic Armor"},
	"HELLFIRE_SET": {"Hellfire Mantle", "Ghostfire Scepter"},
	"PLAGUE_SET": {"Plague Doctor's Mask", "Plague Doctor's Robe", "Plague Doctor's Cane"},
	"TWILIGHT_SET": {"Twilight Oculus", "Robe of Twilight", "Twilight Lantern"},
	"VIRTUOUS_SET": {"Crown of Virtuous Sin", "Scales of Virtuous Sin", "Sandals of Virtuous Sin", "Robes of Virtuous Sin"},
	"WARLORD_SET": {"Warlord Helm", "Warlord Vestments", "Warlord Banner"},
	"ELDRITCH_SET": {"Eldritch Mantle", "Skybreaker Array"},
	"RUINOUS_SET": {"Codex of Chaotic Evolution", "Prism of Shattered Sensations", "Cyst of Eternal Bloom", "Orb of Infinite Slaughter"},
	"DREAMING_SET": {"Dream Thief Diadem", "Psychopomp Staff", "Hypno Bauble"},
	"GAZING_SET": {"Eye Helm", "Balor's Eye Staff", "Raiment of Eyes"},
	"OOZING_SET": {"Slimebirth Cantromancy", "Macrophagic Mask", "Slimy Voodoo Mantle"},
	"ENCHANTER_SET": {"Talking Hat", "Enchantment Staff"},
	"CHESS_SET": {"Bishop Boots", "Castellan Clogs"},
	"ANGEL_TAMER": {"Arbiter Cage"}
}

full_upgrade_achievements = {
	"PERFECTED_BLOOD_BULLET": {"Blood Bullet"},
	"PERFECTED_DEATH_BOLT": {"Death Bolt"},
	"PERFECTED_GOLDEN_SKULL": {"Golden Skull"},
	"PERFECTED_LEGHEAD": {"Leghead"},
	"PERFECTED_PRISON_OF_THORNS": {"Prison of Thorns"},
	"PERFECTED_CARNIVAL": {"Carnival of Pain"},
	"PERFECTED_STARWHALE": {"Dream the Starwhale"},
	"PERFECTED_TORRENT": {"Torrent"},
	"PERFECTED_WHEEL_OF_DEATH": {"Wheel of Death"},
	"PERFECTED_IMMOLATE": {"Immolate"},
	"PERFECTED_PRISMATIC_BEAM": {"Prismatic Beam"},
	"PERFECTED_SPIKEBALL_FACTORY": {"Spikeball Factory"},
}

def record_equipment_set_achievements(equipment_names):
	equipment_names = set(equipment_names)
	for achievement_name, required_names in equipment_set_achievements.items():
		if required_names.issubset(equipment_names): unlock_achievement(achievement_name)

def record_full_upgrade_achievements(spell_names):
	spell_names = set(spell_names)
	for achievement_name, required_names in full_upgrade_achievements.items():
		if required_names.issubset(spell_names): unlock_achievement(achievement_name)

def set_trial_complete(trial_name):
	stats_log.debug(f"Setting complete {trial_name}")
	stats["trials"].add(trial_name)
	save_stats()

	if trial_name.startswith("weekly"): trial_name = "WEEKLY"
	name = trial_name.upper()
	name = name.replace(' ', '_')
	name = name.replace("'", "") # for mordred's vengeance
	unlock_achievement(name)

	# Check ARCHMAGE (all trials completed)
	if all(t.name in stats["trials"] for t in Mutators.all_trials): unlock_achievement("ARCHMAGE")

def record_loss():
	set_stat('s', 0)
	set_stat('i', 0)
	set_stat('l', get_stat('l') + 1)

def record_realm_reached(level_num):
	prev_max = get_stat('r')
	if level_num > prev_max: set_stat('r', level_num)

def record_win(total_turns, trial_name, spell_names, equipment_names, full_upgrade_spell_names):
	wins = get_stat('w') + 1
	set_stat('w', wins)

	streak = get_stat('s') + 1
	set_stat('s', streak)

	if trial_name:
		set_trial_complete(trial_name)
		if trial_name == "Improviser":
			i_streak = get_stat('i') + 1
			set_stat('i', i_streak)
			if i_streak >= 10: unlock_achievement("IMPROVISER_STREAK_TEN")

	record_total_turns(total_turns)
	record_equipment_set_achievements(equipment_names)
	record_full_upgrade_achievements(full_upgrade_spell_names)

	new_spell_victories = record_victories(spell_names)
	new_equipment_victories = record_victories(equipment_names)
	return new_spell_victories, new_equipment_victories

def record_end_sp(sp):
	if sp == 1: unlock_achievement("REMEMBERER")

def record_level_turns(num_turns):
	if num_turns <= 1: unlock_achievement("INSTANT_WIN")

def record_damage_dealt(damage):
	if damage > 15000: unlock_achievement("BIG_DAMAGE_TURN")

def record_total_turns(num_turns):
	pairs = [(1000, "BRISK_GAME"),
			 (500, "FAST_GAME"),
			 (250, "TURBO_GAME")
			]
	for (t, name) in pairs:
		if num_turns < t:
			unlock_achievement(name)

def record_cast_chain_cap():
	unlock_achievement("CAST_CHAIN_CAP")

def record_final_boss_mutual_death():
	unlock_achievement("MUTUAL_DESTRUCTION")

def record_final_boss_friendship():
	unlock_achievement("FRIENDSHIP")

def record_level_20_boss_victory(boss_name):
	from FinalBosses import level_20_boss_achievements
	if boss_name not in level_20_boss_achievements: return
	unlock_achievement(level_20_boss_achievements[boss_name])
	if all(name in stats["achievements"] for name in level_20_boss_achievements.values()):
		unlock_achievement("ALL_LEVEL_20_BOSSES")

def record_vault_complete(vault_id, all_vault_ids):
	if vault_id not in stats["vaults"]:
		stats["vaults"].add(vault_id)
		save_stats()
	unlock_achievement("VAULT_%s" % vault_id.upper().replace(' ', '_'))
	if all(v in stats["vaults"] for v in all_vault_ids):
		unlock_achievement("ALL_VAULTS")

def record_flying_daggers(daggers):
	if daggers > 1000: unlock_achievement("RIFT_OF_FLYING_DAGGERS")

def record_level_damage_sources(damage):
	if damage > 100000: unlock_achievement("TURBO_DAMAGE")

def record_reroll_count(rerolls):
	if set(i for i in range(1, LAST_LEVEL)) != rerolls: return
	unlock_achievement("GAMBLING_WIZARD")

def record_names(stat_key, names):
	new_names = set()
	for name in names:
		if name in stats[stat_key]: continue
		stats[stat_key].add(name)
		new_names.add(name)
	if new_names: save_stats()
	return new_names

def record_purchase(spell_name):
	return bool(record_names("purchases", [spell_name]))

def has_been_purchased(spell_name):
	return spell_name in stats["purchases"]

def has_purchased_all(names):
	purchases = stats["purchases"]
	if len(purchases) < len(names): return False
	return names <= purchases

def record_victory(spell_name):
	return bool(record_victories([spell_name]))

def record_victories(spell_names):
	return record_names("victories", spell_names)

def has_been_victoried(spell_name):
	return spell_name in stats["victories"]

def has_victoried_all(names):
	victories = stats["victories"]
	if len(victories) < len(names): return False
	return names <= victories

def unlock_bestiary(monster_name):
	if monster_name not in stats["bestiary"]:
		stats["bestiary"].add(monster_name)
		save_stats()
		check_bestiary_ach()

def check_bestiary_ach():
	if get_num_slain() >= len(all_monster_names):
		unlock_achievement("BESTIARY")

def has_slain(monster_name):
	return monster_name in stats["bestiary"]

def get_num_slain():
	return len([m for m in stats["bestiary"] if m in all_monster_names])

init()
