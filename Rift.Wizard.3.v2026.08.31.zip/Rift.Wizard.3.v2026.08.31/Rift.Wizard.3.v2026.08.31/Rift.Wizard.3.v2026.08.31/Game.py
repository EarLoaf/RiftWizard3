from Level import *
from LevelGen import *
import sys
import math
import os
import time
import shutil
from Spells import make_player_spells, all_player_spell_constructors
from Equipment import make_all_items, all_equipment
from collections import OrderedDict, defaultdict

import dill as pickle
import random

import SteamAdapter

BASE_PLAYER_SPELL_NAMES = frozenset(spell().name for spell in all_player_spell_constructors)
BASE_EQUIPMENT_NAMES = frozenset(equipment().name for equipment in all_equipment)

def check_all_spell_purchases():
	if SteamAdapter.has_purchased_all(BASE_PLAYER_SPELL_NAMES): SteamAdapter.unlock_all_spells_learned()

def check_all_equipment_purchases():
	if SteamAdapter.has_purchased_all(BASE_EQUIPMENT_NAMES): SteamAdapter.unlock_all_equipment_learned()

def check_all_spell_victories():
	if SteamAdapter.has_victoried_all(BASE_PLAYER_SPELL_NAMES): SteamAdapter.unlock_all_spells_victoried()

def check_all_equipment_victories():
	if SteamAdapter.has_victoried_all(BASE_EQUIPMENT_NAMES): SteamAdapter.unlock_all_equipment_victoried()

def check_all_collection_achievements():
	check_all_spell_purchases()
	check_all_equipment_purchases()
	check_all_spell_victories()
	check_all_equipment_victories()

check_all_collection_achievements()

def safe_int(f):
	if f.isdigit():
		return int(f)
	return 0

def can_continue_game():
	# Can continue if latest run has a game dat
	if os.path.exists('saves'):
		run_folders = os.listdir('saves')
		run_folders.sort(reverse=True, key=lambda f: safe_int(f))
		if run_folders:
			filename = os.path.join('saves', run_folders[0], 'game.dat')
			return os.path.exists(filename)
	return False

def continue_game(filename=None):
	if filename and os.path.exists(filename):
		with open(filename, 'rb') as savefile:
			game = pickle.load(savefile)
			game.on_loaded(filename)

			return game

	# Return latest game dat
	if os.path.exists('saves'):
		run_folders = os.listdir('saves')
		run_folders.sort(reverse=True, key=lambda f: safe_int(f))
		if run_folders:
			filename = os.path.join('saves', run_folders[0], 'game.dat')
			with open(filename, 'rb') as savefile:
				game = pickle.load(savefile)

			# Set up systems that need to be reset on load.
			game.on_loaded(filename)
			return game

def abort_game():
	if os.path.exists('saves'):
		run_folders = os.listdir('saves')
		run_folders.sort(reverse=True, key=lambda f: safe_int(f))
		if run_folders:
			filename = os.path.join('saves', run_folders[0], 'game.dat')
			if os.path.exists(filename):
				os.remove(filename)

def is_game_victory(game):
	if game.level_num != LAST_LEVEL: return False
	if any(u for u in game.cur_level.units if u.is_final_boss and are_hostile(u, game.p1)): return False
	game.record_final_boss_achievements()
	game.victory = True
	game.victory_evt = True
	game.finalize_save(victory=True)
	return True


class Game():
#	cur_game = None

	def save_game(self, filename=None):
		main_save = False
		if not filename:
			main_save = True
			filename = os.path.join('saves', str(self.run_number), 'game.dat.tmp')

		self.write_pending_combat_logs()

		dirname = os.path.dirname(filename)
		if not os.path.exists(dirname):
			os.makedirs(dirname)

		with open(filename, 'wb') as save:
			pickle.dump(self, file=save)

		# If the save is successful, overwrite the main save file
		# Do this to avoid corrupting save files when pickle crashes
		# Ideally pickle would not crash but this way at least we retain a usable save file and can try to repro the bug
		if main_save:
			main_filename = os.path.join('saves', str(self.run_number), 'game.dat')
			if os.path.exists(main_filename): os.remove(main_filename)
			os.rename(filename, main_filename)

	def prune_old_runs(self):
		keep_count = self.keep_run_count
		if not keep_count or keep_count <= 0: return
		if not os.path.exists('saves'): return
		run_folders = [f for f in os.listdir('saves') if f.isdigit() and os.path.isdir(os.path.join('saves', f))]
		if len(run_folders) <= keep_count: return
		run_pairs = sorted(((safe_int(f), f) for f in run_folders), key=lambda t: t[0])
		to_delete = run_pairs[:-keep_count]
		for _, folder in to_delete:
			if safe_int(folder) == self.run_number: continue
			try: shutil.rmtree(os.path.join('saves', folder))
			except Exception: pass

	def __getstate__(self):
		# Exclude static game catalogs from pickle - these will be regenerated on load
		state = self.__dict__.copy()
		state['all_player_spells'] = None
		state['all_player_items'] = None
		state['post_victory_tasks'] = []
		return state

	def write_stats(self):

		filename = os.path.join('saves', str(self.run_number), 'level.%d.txt')

		dirname = os.path.dirname(filename)
		if not os.path.exists(dirname):
			os.makedirs(dirname)

		with open(filename, 'wb') as save:
			pickle.dump(self, file=save)

	def get_run_number(self):
		if os.path.exists('saves'):
			run_folders = os.listdir('saves')
			if run_folders:
				return max(safe_int(f) for f in run_folders) + 1
			else:
				return 1
		else:
			os.mkdir('saves')
			return 1

	def on_loaded(self, filename):
		if not hasattr(self, 'level_cleared'):
			self.level_cleared = getattr(self, 'has_granted_xp', False)
		if not hasattr(self, 'pending_level_stats'):
			self.pending_level_stats = {}
		if not hasattr(self, 'autosave_enabled'):
			self.autosave_enabled = True
		if not hasattr(self, 'keep_run_count'):
			self.keep_run_count = None

		# Regenerate static game catalogs that were excluded from save
		self.all_player_spells = [s for s in make_player_spells() if type(s) not in self.restricted_spells]
		self.all_player_items = [e for e in make_all_items() if e.name not in self.restricted_equipment]

		# Apply mutator modifications to regenerated catalogs
		for mutator in self.mutators:
			# Reset mutator random state to ensure consistent regeneration
			if hasattr(mutator, 'seed'): mutator.set_seed(mutator.seed)
			mutator.on_generate_spells(self.all_player_spells)
			mutator.on_generate_equipment(self.all_player_items)

		owned_spells = {s.name: s for s in self.p1.spells}
		self.all_player_spells = [owned_spells.get(s.name, s) for s in self.all_player_spells]

		# Infer logdir and run number from filename
		self.logdir = os.path.join(os.path.dirname(filename), 'log')
		if not os.path.exists(self.logdir): os.mkdir(self.logdir)

		self.run_number = safe_int(os.path.split(os.path.dirname(filename))[1])
		self.cur_level.cur_shop = None
		self.cur_level.setup_level(self.level_num)
		self.rebuild_event_managers()
		self.subscribe_mutators()

	def rebuild_event_managers(self):
		levels = []
		seen = set()

		def add_level(level):
			if not level: return
			key = id(level)
			if key in seen: return
			seen.add(key)
			levels.append(level)
			for p in getattr(level, 'props', []):
				if not isinstance(p, Portal): continue
				next_level = getattr(p, 'next_level', None)
				if next_level: add_level(next_level)
				next_level = getattr(p.level_gen_params, 'level', None)
				if next_level: add_level(next_level)

		add_level(self.cur_level)
		add_level(getattr(self, 'next_level', None))
		add_level(getattr(self, 'prev_next_level', None))

		for level in levels:
			level.event_manager = EventHandler()
			for unit in level.units:
				for buff in unit.buffs:
					if getattr(buff, 'owner', None) is None:
						buff.owner = unit
					if getattr(buff, 'owner', None) and getattr(buff.owner, 'level', None):
						buff.subscribe()

	def finalize_save(self, victory):
		# Finalize current level first
		if not self.level_cleared: self.finalize_level(victory)
		self.record_run_achievements(victory)
		self.write_pending_level_stats(self.level_num)
		self.write_pending_combat_logs()
		filename = os.path.join('saves', str(self.run_number), 'game.dat')
		if os.path.exists(filename): os.remove(filename)

	def record_final_boss_achievements(self):
		if any(u for u in self.cur_level.units if u.is_final_boss and not are_hostile(u, self.p1)): SteamAdapter.record_final_boss_friendship()
		if self.p1.cur_hp > 0: return
		SteamAdapter.record_final_boss_mutual_death()

	def unlock_bestiary(self, unit):
		SteamAdapter.unlock_bestiary(unit.name)
		if unit.parent: SteamAdapter.unlock_bestiary(unit.parent.name)

	def record_spell_purchased(self, spell):
		if SteamAdapter.record_purchase(spell.name) and spell.name in BASE_PLAYER_SPELL_NAMES: check_all_spell_purchases()

	def record_equipment_crafted(self, equipment):
		if SteamAdapter.record_purchase(equipment.name) and equipment.name in BASE_EQUIPMENT_NAMES: check_all_equipment_purchases()

	def record_run_achievements(self, victory):
		if not victory: return # get the gambling wizard cheevo if you win after rerolling every level
		spell_names = [spell.name for spell in self.p1.spells]
		equipment_names = [equipment.name for equipment in self.p1.equipment]
		full_upgrade_spell_names = [spell.name for spell in self.p1.spells if spell.spell_upgrades and self.p1.has_all_upgrades(spell)]
		new_spell_victories, new_equipment_victories = SteamAdapter.record_win(self.total_turns, self.trial_name, spell_names, equipment_names, full_upgrade_spell_names)
		if new_spell_victories & BASE_PLAYER_SPELL_NAMES: check_all_spell_victories()
		if new_equipment_victories & BASE_EQUIPMENT_NAMES: check_all_equipment_victories()
		SteamAdapter.record_reroll_count(self.rift_rerolls_used)
		SteamAdapter.record_end_sp(getattr(self.p1, 'xp', 0))

	def record_turn_damage_achievement(self):
		damage_dealt = self.cur_level.turn_summary.damage_dealt
		if damage_dealt: SteamAdapter.record_damage_dealt(sum(damage_dealt.values()))

	def record_level_achievements(self, victory, dealers):
		if not victory and not dealers: return
		if victory: SteamAdapter.record_level_turns(self.cur_level.turn_no -1)
		if dealers: SteamAdapter.record_level_damage_sources(dealers[0][1]) # just pass in the highest damage dealer
		if victory and self.level_num == LAST_LEVEL - 1:
			for boss in self.cur_level.gen_params.bosses:
				SteamAdapter.record_level_20_boss_victory(boss.name)
		if victory and self.cur_level.gen_params.is_vault:
			import Vaults
			SteamAdapter.record_vault_complete(self.cur_level.gen_params.vault.id, [v.id for v in Vaults.iter_vaults()])

	def finalize_level(self, victory):
		self.pending_combat_logs[self.level_num] = self.cur_level.combat_log
		self.total_turns += self.cur_level.turn_no
		self.rift_rerolls = 1
		lines = []
		w = lambda entry: lines.append(resolve_text(entry))  # entry: str or (msg, fmt)

		w(("Realm {n}", {"n": self.level_num}))
		if self.trial_name: w(self.trial_name)
		w(("Outcome: {result}", {"result": "VICTORY" if victory else "DEFEAT"}))

		lines.append("")
		w("Turns taken:")
		w(("{n} (L)", {"n": self.cur_level.turn_no}))
		w(("{n} (G)", {"n": self.total_turns}))

		spell_counts = sorted(self.cur_level.spell_counts.items(), key=lambda t: -t[1])
		if spell_counts:
			lines.append("")
			w("Spell Casts:")
			for s, c in spell_counts:
				w(("{count:3d} {name}", {"count": c, "name": s}))

		dealers = sorted(self.cur_level.damage_dealt_sources.items(), key=lambda t: -t[1])
		self.record_level_achievements(victory, dealers)  # check vault victory damage val of highest entry
		if dealers:
			lines.append("")
			w("Damage to Enemies:")
			for s, d in dealers[:5]:
				w(("{amount} {source}", {"amount": d, "source": s}))
			if len(dealers) > 5:
				total_other = sum(d for _, d in dealers[5:])
				w(("{amount} Other", {"amount": total_other}))

		sources = sorted(self.cur_level.damage_taken_sources.items(), key=lambda t: -t[1])
		if sources:
			lines.append("")
			w("Damage to Wizard:")
			for s, d in sources[:5]:
				w(("{amount} {source}", {"amount": d, "source": s}))
			if len(sources) > 5:
				total_other = sum(d for _, d in sources[5:])
				w(("{amount} Other", {"amount": total_other}))

		if self.recent_upgrades:
			lines.append("")
			w("Purchases:")
			for u in self.recent_upgrades:
				if getattr(u, 'prereq', None):
					w(("{a}: {b}", {"a": u.prereq.name, "b": u.name}))
				else:
					w(u.name)

		self.pending_level_stats[self.level_num] = lines

		self.recent_upgrades.clear()
		self.post_victory_tasks = []

	def write_pending_level_stats(self, level_num=None):
		if level_num is None: level_num = self.level_num
		lines = self.pending_level_stats.get(level_num)
		if not lines: return
		filename = os.path.join('saves', str(self.run_number), 'stats.level_%d.txt' % level_num)
		dirname = os.path.dirname(filename)
		if not os.path.exists(dirname): os.makedirs(dirname)
		with open(filename, 'w', encoding='utf-8') as stats:
			stats.write("\n".join(lines) + "\n")
		del self.pending_level_stats[level_num]

	def get_combat_log_filename(self, level_num):
		if not self.logdir: return None
		return os.path.join(self.logdir, 'combat_log.level_%d.txt' % level_num)

	def load_combat_log(self, level_num):
		if level_num == self.level_num: return self.cur_level.combat_log
		if level_num in self.pending_combat_logs: return self.pending_combat_logs[level_num]

		filename = self.get_combat_log_filename(level_num)
		if not filename or not os.path.exists(filename): return {}

		turns = defaultdict(list)
		turn_no = None
		try:
			with open(filename, 'r', encoding='utf-8') as logfile:
				for line in logfile:
					line = line.rstrip('\n')
					if line.startswith("=== Turn ") and line.endswith(" ==="):
						turn_no = int(line[9:-4])
					elif turn_no is not None:
						turns[turn_no].append(line)
		except OSError:
			return {}
		return turns

	def write_pending_combat_logs(self, level_num=None):
		level_nums = [level_num] if level_num is not None else sorted(self.pending_combat_logs)
		for level_num in level_nums:
			turns = self.pending_combat_logs.get(level_num)
			filename = self.get_combat_log_filename(level_num)
			if turns is None or not filename: continue
			if not self.write_combat_log(filename, turns): continue
			del self.pending_combat_logs[level_num]

	def write_combat_log(self, filename, turns):
		try:
			with open(filename, 'w', encoding='utf-8') as logfile:
				for turn_no in sorted(turns):
					logfile.write("=== Turn %d ===\n" % turn_no)
					lines = turns[turn_no]
					if lines: logfile.write("\n".join(lines) + "\n")
		except OSError:
			return False
		return True

	def write_crash_combat_log(self):
		if not self.logdir: return
		filename = os.path.join(self.logdir, 'combat_log.level_%d.crash.txt' % self.level_num)
		self.write_combat_log(filename, self.cur_level.combat_log)

	# For the consumer of the Game object
	def __init__(self, generate_level=True, save_enabled=False, mutators=None, trial_name=None, seed=None):

		self.seed = seed
		if self.seed is not None: random.seed(self.seed)
		else: random.seed()

		self.level_seeds = {}
		for i in range(26):
			seeds_per_difficulty = 12
			self.level_seeds[i] = [random.random() for i in range(seeds_per_difficulty)]

		self.mutators = mutators
		if not self.mutators: self.mutators = []
		for mutator in self.mutators: mutator.set_seed(random.random())

		self.trial_name = trial_name

		self.p1 = self.make_player_character()
		self.p1.game = self # allow access to the game via the player

		self.rolled_final_bosses = set()

		self.run_number = self.get_run_number()

		self.max_spells = MAX_SPELLS
		self.free_spells = False

		self.all_player_spells = make_player_spells()
		self.all_player_items = make_all_items()

		self.level_reward_table = list(reward_table)

		self.restricted_spells = set() # accepts spell CLASSES which should be culled from spell list via non-mutator means
		self.restricted_equipment = set() # accepts equipment NAMES which should be culled from the equipment list via non-mutator means

		self.shop_craft_component_ingredients = []

		for mutator in self.mutators: mutator.on_game_begin(self)

		for mutator in self.mutators:
			mutator.on_generate_spells(self.all_player_spells)
			mutator.on_generate_equipment(self.all_player_items)

		self.generate_level = generate_level
		if generate_level:
			self.cur_level = LevelGenerator(1, self, self.seed).make_level()
		else:
			self.cur_level = Level(18, 18)
			self.cur_level.start_pos = Point(0, 0)

		self.level_num = 1

		if save_enabled:
			self.logdir = os.path.join('saves', str(self.run_number), 'log')
			if not os.path.exists(self.logdir): os.makedirs(self.logdir, exist_ok=True)
		else:
			self.logdir = None

		self.cur_level.setup_level(self.level_num)
		self.cur_level.spawn_player(self.p1)

		self.gameover = False

		self.deploying = False
		self.next_level = None
		self.prev_next_level = None

		self.victory = False

		self.level_cleared = False

		self.victory_evt = False

		self.recent_upgrades = []
		self.last_manual_cast = None

		self.total_turns = 0
		self.rift_rerolls_used = set()
		self.post_victory_tasks = []
		self.pending_level_stats = {}
		self.pending_combat_logs = {}
		self.autosave_enabled = True
		self.keep_run_count = None


		# Gather all spell tags for UI and other consumers
		self.spell_tags = []
		self.spell_tags.extend(t for t in Tags if any(t in s.tags for s in self.all_player_spells))

		self.subscribe_mutators()

		if save_enabled: self.save_game()

	def remove_level_rewards(self, rewards):
		reward_factories = set(rewards)
		self.level_reward_table = [option for option in self.level_reward_table if option[0] not in reward_factories]

	def keep_level_reward(self, reward):
		for option in self.level_reward_table:
			if option[0] is not reward: continue
			self.level_reward_table = [(option[0], option[1], None, None, option[4])]
			return
		self.level_reward_table.clear()

	def clear_level_rewards(self):
		self.level_reward_table.clear()

	# Take a levelseed, return the list of seeds that level leads to
	def get_seeds(self, difficuty):
		# Just return ranndom seeds for levels above 25
		if difficuty > 25:
			return [random.random() for i in range(10)]
		return list(self.level_seeds[difficuty])

	def subscribe_mutators(self):
		for mutator in self.mutators:
			for event_type, handler in mutator.global_triggers.items():
				self.cur_level.event_manager.register_global_trigger(event_type, handler)

	def make_player_character(self):
		# eventually tie in char creation here
		player = Unit()
		player.max_hp = 50
		player.cur_hp = 50
		player.is_player_controlled = True
		player.name = "Wizard"
		player.asset_name = 'player'
		player.team = TEAM_PLAYER

		player.tags = [Tags.Living]

		player.xp = 1

		player.components = []
		player.component_tags = defaultdict(int)
		player.equipment = []

		player.wishlist_equipment = [] # track wishlisted equipment

		player.gets_clarity = True
		player.game = self

		return player

	# Request to move the currently active controlled unit in the requested direction
	def try_move(self, xdir, ydir):
		if not self.cur_level.is_awaiting_input: return False
		if self.p1.is_stunned(): return False
		if self.p1.stationary: return False
		
		new_x = self.p1.x + xdir
		new_y = self.p1.y + ydir

		# Use melee spell if one is set and the way is blocked by a hostile unit
		blocker = self.cur_level.get_unit_at(new_x, new_y)
		if blocker and are_hostile(self.p1, blocker) and self.p1.melee_spell:
			spell = self.p1.melee_spell
			if not spell.can_cast(new_x, new_y): return False
			spell.quick_cast = self.p1.quick_move and not self.p1.quick_cast_used
			self.cur_level.set_order_cast(spell, new_x, new_y)
			return True

		# Otherwise just move
		if self.cur_level.can_move(self.p1, new_x, new_y):
			self.cur_level.set_order_move(new_x, new_y)
			return True

	# Request to cast a spell
	def try_cast(self, spell, x, y):
		if not spell.can_cast(x, y): return False
		self.cur_level.set_order_cast(spell, x, y)
		if spell in self.p1.spells: self.last_manual_cast = CastAction(spell, x, y)
		return True

	def can_shop(self, item):
		if self.cur_level.cur_shop: # if you're in a proper shop
			if self.cur_level.cur_shop.can_shop(self.p1, item): return True # if the shops rules allow you to buy it, let you buy it
			return False

		elif isinstance(item, Upgrade) or isinstance(item, Spell): # if you're in the spellbook or spellupgrade selection
			if self.can_buy_upgrade(item): return True # see if you can purchase it
			return False

		elif isinstance(item, Equipment): # if you're crafting equipment then see if you can craft it
			if self.can_craft_equipment(item): return True
			return False

		return False

	def try_shop(self, item):
		if not self.can_shop(item): return False # if you can't buy it, then fail
		purchases = item
		if self.cur_level.cur_shop:
			purchases = self.cur_level.act_shop(self.p1, item) # if you're in a shop then do the purchase
			if purchases is None: purchases = item
		elif isinstance(item, Upgrade) or isinstance(item, Spell):
			self.buy_upgrade(item) # if you're in the Spellbook the buy the spell or spellupgrade
			if isinstance(item, Spell): self.record_spell_purchased(item)
		elif isinstance(item, Equipment):
			e = item.clone() # get an instance of the item, rather than the one being held in the shop
			for c in self.shop_craft_component_ingredients:
				e.crafting_input_fns[type(c)] += 1 # do this first (so enchanter's awl can remove itself or other ingredients can be returned)
			e.on_pre_craft(self.p1) # typically no-op but lets magic wand / philosopher stone gain tags before on-crafts trigger
			for c in self.shop_craft_component_ingredients:
				c.on_craft(self.p1, e) # do the on craft for the components here, since this is where the actual piece of equipment is generated
			self.p1.equip(e)
			self.record_equipment_crafted(e)
			self.clear_wishlist(e)
		if purchases:
			if not isinstance(purchases, list): purchases = [purchases]
			self.recent_upgrades.extend(purchases)
		self.shop_craft_component_ingredients.clear()
		return True

	def try_reroll_rifts(self):

		if not getattr(self, 'rift_rerolls', 0): return
		self.rift_rerolls -= 1
		self.rift_rerolls_used.add(self.level_num)

		self.cur_level.event_manager.raise_event(EventOnReroll(self.cur_level))

		# Delete existing portals
		num_gates = 0
		for tile in self.cur_level.iter_tiles():
			if isinstance(tile.prop, Portal):
				self.cur_level.remove_prop(tile.prop)
				num_gates += 1
				self.cur_level.show_effect(tile.x, tile.y, Tags.Translocation)

		# Always roll atleast one gate- for instance if corruption destroyed all the portals
		num_gates = max(num_gates, 1)

		candidate_tiles = [t for t in self.cur_level.iter_tiles() if not t.prop and t.can_walk]
		random.shuffle(candidate_tiles)

		created = 0
		for t in candidate_tiles:
			path = self.cur_level.find_path(self.p1, Point(t.x, t.y), self.p1, pythonize=True, unit_penalty=0)
			if not path: continue # if no way to for the wizard to walk there, try again
			self.cur_level.add_portal(Portal(self.cur_level.gen_params.make_child_generator()), t.x, t.y, locked=False)
			created += 1
			if created >= num_gates: break

		if created == 0: # if they can't path to any of the candidate tiles on the level
			self.cur_level.portal_mercy() # give them a portal

	def try_pass(self):
		self.cur_level.set_order_pass()

	def has_upgrade(self, upgrade):
		if any(s.name == upgrade.name for s in self.p1.spells): return True
		if any(isinstance(b, Upgrade) and b.name == upgrade.name and b.prereq == upgrade.prereq for b in self.p1.buffs): return True
		return False

	def get_upgrade_cost(self, upgrade):
		level = upgrade.level
		if level == 0: return 0
		if self.free_spells and isinstance(upgrade, Spell): return 0
		level = max(level, 1)
		return level		

	def buy_upgrade(self, upgrade, free=False):
		if not free: self.p1.xp -= self.get_upgrade_cost(upgrade)
		if isinstance(upgrade, Upgrade): self.p1.apply_buff(upgrade)
		elif isinstance(upgrade, Spell): self.p1.add_spell(upgrade)

	def spell_is_upgraded(self, spell, limit=True):
		owned_upgrades = [b for b in self.p1.buffs if getattr(b, 'prereq', None) == spell]
		max_upgrades = 2 if limit else len(spell.spell_upgrades)
		return len(owned_upgrades) >= max_upgrades # max two upgrades by default

	def player_spell_limit_reached(self):
		if not self.p1: return False
		return len(self.p1.spells) >= self.max_spells

	def can_craft_equipment(self, equipment, tags=None):
		if isinstance(equipment, SpellBook) and self.player_spell_limit_reached(): return False # don't let buy spell-granting equipment if already at max spells
		if equipment.unique and any(e.name == equipment.name for e in self.p1.equipment):  return False  # can't build dupes of uniques
		if tags: tag_pool = tags.copy()
		else: tag_pool =self.p1.component_tags.copy()
		for tag, amount in equipment.recipe: # for each tag in the recipe
			if tag == Tags.Any: # if the tag is any
				total = sum(tag_pool.values()) # then we count up the sum of all component tags held by the player
				if total < amount:  return False # if the sum of tags held is less than the amount of Any needed, we can't craft it
				for t in list(tag_pool): # iterate through all the tags and subrtact them from the tag pool sum
					consume = min(amount, tag_pool[t])
					tag_pool[t] -= consume
					amount -= consume
					if amount <= 0: break
			else:
				if tag_pool.get(tag, 0) < amount:  return False # for normal tags, just see if you have enough
				tag_pool[tag] -= amount

		return True

	def get_prospective_equipment(self, components):
		tag_pool = self.p1.component_tags.copy()
		currently_craftable = [i for i in self.all_player_items if self.can_craft_equipment(i)]
		for component in components:
			for tag in component.tags:
				tag_pool[tag] += 1
		future_craftable = [i for i in self.all_player_items if self.can_craft_equipment(i, tag_pool)]
		diff = [i for i in future_craftable if i not in currently_craftable]
		diff.sort(key=lambda e: e.name)
		return EquipmentList(diff)

	def get_missing_crafting_requirements(self, equipment):
		tag_pool = self.p1.component_tags.copy()
		missing = []

		for tag, amount in equipment.recipe:
			if tag == Tags.Any:
				total = sum(tag_pool.values())
				if total < amount:
					missing.extend([Tags.Any] * (amount - total))
				else:
					# simulate consuming arbitrary components
					for t in list(tag_pool):
						consume = min(amount, tag_pool[t])
						tag_pool[t] -= consume
						amount -= consume
						if amount <= 0:
							break
			else:
				available = tag_pool.get(tag, 0)
				consume = min(amount, available)
				if available < amount:
					missing.extend([tag] * (amount - available))
				if consume:
					tag_pool[tag] -= consume

		return missing # hand back a flat list of the tags that are missing


	def set_wishlist_equipment(self, equipment):
		if self.p1.has_equipment(equipment): return # dont wishlist stuff you already own
		for e in self.p1.wishlist_equipment:
			if e.name == equipment.name: return
		if len(self.p1.wishlist_equipment) >= 3: self.p1.wishlist_equipment.pop(0)
		self.p1.wishlist_equipment.append(equipment)
		self.pending_wishlist_missing = self.get_wishlist_missing()

	def clear_wishlist(self, equipment=None):
		if equipment is None: self.p1.wishlist_equipment.clear()
		else: self.p1.wishlist_equipment = [e for e in self.p1.wishlist_equipment if e.name != equipment.name]
		self.pending_wishlist_missing = self.get_wishlist_missing()

	def get_wishlist_missing(self):
		return [self.get_missing_crafting_requirements(equipment) for equipment in self.p1.wishlist_equipment]

	def can_buy_upgrade(self, upgrade):

		# Limit 10 spells
		if isinstance(upgrade, Spell) and self.player_spell_limit_reached(): return False

		if self.has_upgrade(upgrade): return False

		if isinstance(upgrade, Upgrade) and upgrade.prereq:
			
			# Must have prereq
			if not self.has_upgrade(upgrade.prereq): return False

			# Two spell upgrades per spell by default
			if self.spell_is_upgraded(upgrade.prereq): return False

		if self.p1.xp < self.get_upgrade_cost(upgrade): return False

		return True

	# Request to advance the simulation- update anims, move enemies, ect.
	def advance(self):
		self.changed_level = False
		if "profile" in sys.argv:
			import time
			import cProfile
			import pstats
			pr = cProfile.Profile()
			start = time.time()
			pr.enable()

		advanced = self.cur_level.advance()
		if not self.cur_level.active_spells: self.check_triggers()
		
		if "profile" in sys.argv:
			pr.disable()
			finish = time.time()
			frame_time = finish - start
			if frame_time > 1 / 60.0:
				stats = pstats.Stats(pr)
				stats.sort_stats("cumtime")
				stats.dump_stats("profile.stats")
				stats.print_stats()
			print("frame time ms: %f" % (frame_time * 1000))

	# Check if we should respond to something that happened in the current level
	def check_triggers(self):
		if self.cur_level.cur_portal and not self.deploying: self.enter_portal()
		
		# Level victory
		# You win if every unit is friendly and you have hitpoints
		if not self.cur_level.has_enemy_units() and self.p1.cur_hp > 0:
				
			if not self.level_cleared:
				self.level_cleared = True
				self.victory_evt = True
				self.finalize_level(victory=True)
				self.cur_level.event_manager.raise_event(EventOnLevelComplete(self.cur_level), self.cur_level)
				self.p1.refresh()
				if self.level_num != LAST_LEVEL:
					self.cur_level.prop_mercy()
					self.cur_level.portal_mercy()
					self.cur_level.dismiss_units_and_clouds()



		if is_game_victory(self): return

		if self.p1.cur_hp <= 0:
			SteamAdapter.record_loss()
			self.gameover = True
			self.finalize_save(victory=False)


	def is_awaiting_input(self):
		if self.victory: return True
		if self.next_level: return True
		return self.cur_level.is_awaiting_input

	# Internal stuff
	def enter_portal(self):
		
		if self.generate_level:
			if not self.cur_level.cur_portal.next_level:
				self.cur_level.cur_portal.next_level = self.cur_level.cur_portal.level_gen_params.make_level()
			self.next_level = self.cur_level.cur_portal.next_level

		else: self.next_level = Level(18, 18)

		self.deploying = True

		# clear temp buffs so can_stand will be properly calculated for the buffless version.
		temp_buffs = [b for b in self.p1.buffs if b.buff_type in [BUFF_TYPE_CURSE, BUFF_TYPE_BLESS]]
		for d in temp_buffs: self.p1.remove_buff(d)

	def try_deploy(self, x, y):
		assert(self.deploying)

		if not self.next_level.can_stand(x, y, self.p1): return False

		# Clear all buffs heal to max ect
		self.p1.refresh()
		self.p1.clear_runtime_anims()
		self.cur_level.remove_obj(self.p1)
		self.next_level.start_pos = Point(x, y)
		self.level_num += 1
		SteamAdapter.record_realm_reached(self.level_num)
		self.next_level.setup_level(self.level_num)
		self.next_level.spawn_player(self.p1)
		self.pending_combat_logs[self.level_num - 1] = self.cur_level.combat_log
		self.write_pending_combat_logs(self.level_num - 1)
		self.cur_level = self.next_level
		self.last_manual_cast = None

		self.next_level = None
		self.prev_next_level = None
		self.deploying = False

		self.level_cleared = False

		self.rift_rerolls = 0

		import gc
		gc.collect()

		self.subscribe_mutators()

		if self.cur_level.gen_params:
			logging.getLogger("Level").debug("\nEntering level %d, id=%d" % (self.level_num, self.cur_level.gen_params.level_id))

		return True

	def try_abort_deploy(self):
		self.deploying = False
		self.prev_next_level = self.next_level
		self.next_level = None
		self.cur_level.cur_portal = None

	def can_fast_forward(self):
		return self.cur_level.can_fast_forward()

#def new_game():
#	Game.cur_game = Game()
#	return Game.cur_game

# todo- load_game, ect
