from Level import *
from Monsters import *
from copy import copy
from CommonContent import *
import sys
import random


class UndeathIdolBuff(Buff):

	def on_init(self):
		self.name = "Aura of Undeath"
		self.description = ("Each turn, [Undead] allies heal 1 HP and [Living] enemies take 1 [Dark] damage\n\n"
						    "Slain [Living] units are raised as Skeletons")

		self.global_triggers[EventOnDeath] = self.on_death

	def on_death(self, evt):
		if Tags.Living in evt.unit.tags and Tags.Undead not in evt.unit.tags:
			self.owner.level.queue_spell(self.try_raise(evt.unit))

	def try_raise(self, u):
		raise_skeleton(self.owner, u)
		yield

	def on_advance(self):
		owner = self.owner
		for u in list(self.owner.level.units):
			if Tags.Undead in u.tags and not are_hostile(u, owner): u.heal(1, self)
			if Tags.Living in u.tags and are_hostile(u, owner): u.deal_damage(1, Tags.Dark, self)


def IdolOfUndeath():
	idol = BigIdol()
	idol.name = "Idol of Undeath"
	idol.asset_name = "3x3_idol_of_undeath"
	idol.buffs.append(UndeathIdolBuff())
	return idol

class LifeIdolBuff(Buff):

	def on_init(self):
		self.name = "Aura of Life"
		self.description = "Each turn, heal [Living] allies for 5 HP"

	def on_advance(self):
		for u in self.owner.level.units:
			if Tags.Living in u.tags and not self.owner.level.are_hostile(u, self.owner):
				u.deal_damage(-5, Tags.Heal, self)
		
		for p in self.owner.level.get_points_in_ball(self.owner.x, self.owner.y, 1, diag=True):
			if self.owner.level.get_unit_at(p.x, p.y):
				continue
			if not self.owner.level.tiles[p.x][p.y].can_see:
				continue
			self.owner.level.show_effect(p.x, p.y, Tags.Holy, minor=True)

	def get_tooltip(self):
		return self.description

def IdolOfLife():
	idol = BigIdol()
	idol.name = "Fountain of Blood"
	idol.buffs.append(LifeIdolBuff())
	idol.asset_name = "3x3_idol_of_vitality"

	return idol

class IdolOfPoisonBuff(Buff):

	def on_init(self):
		self.name = "Aura of Venom"
		self.color = Tags.Poison.color
		self.description = "Each turn, extend the [poison] duration on [poisoned] enemies by 1 turn\n\nEach turn, apply 2 turns of [poison] to unpoisoned enemies"

	def on_advance(self):
		for u in self.owner.level.units:
			if u.resists[Tags.Poison] >= 100: continue
			if not are_hostile(self.owner, u): continue
			existing = u.get_buff(Poison)
			if existing: existing.turns_left += 1
			if not existing: u.apply_buff(Poison(), 2)

def IdolOfPoison():
	idol = BigIdol()
	idol.name = "Fountain of Venom"
	idol.asset_name = "fountain_of_poison"
	idol.buffs.append(IdolOfPoisonBuff())
	return idol

class PietyIdolBuff(Buff):

	def on_init(self):
		self.name = "Piety"
		self.global_triggers[EventOnDeath] = self.on_death
		self.damage = 1
		self.color = Tags.Holy.color

	def get_description(self):
		return ("When an ally is slain by an enemy, deal [{damage} Holy:holy] damage to the killer\n\n"
				"This damage increases each turn", {'damage':self.damage})

	def on_advance(self):
		self.damage += 1

	def on_death(self, evt):
		# ally death
		if evt.unit == self.owner or are_hostile(evt.unit, self.owner): return

		# died to damage
		if evt.damage_event is None: return
		source = evt.damage_event.source
		if not source: return

		# find the killer if it's hostile
		source_unit = source.owner
		if not source_unit: return
		if not are_hostile(source_unit, self.owner): return

		source_unit.level.show_path_effect(self.owner, source_unit, Tags.Holy)
		source_unit.deal_damage(self.damage, Tags.Holy, self)


def IdolOfPiety():
	u = BigIdol()
	u.name = "Idol of Piety"
	u.asset_name = '3x3_idol_of_grief'
	u.buffs = [PietyIdolBuff()]
	return u

class SculptorRelocation(Buff):

	def on_init(self):
		self.name = "Sculptor Relocation"
		self.description = "Each turn, teleport to the lowest HP allied [Construct]"

	def on_advance(self):
		o = self.owner
		opts = [u for u in o.level.units if not are_hostile(o, u) and Tags.Construct in u.tags]
		if not opts: return
		opts.sort(key=lambda u: u.cur_hp)
		lowest = opts[0].cur_hp
		chosen = [o for o in opts if o.cur_hp == lowest]
		o.level.queue_spell(self.do_hop(chosen))

	def do_hop(self, opts):
		o = self.owner
		get_summon_point = o.level.get_summon_point
		p = None
		for u in opts:
			p = get_summon_point(u.x, u.y, sort_dist=False, radius_limit=u.radius+1, unit=o)
			if p: break
		if not p: return

		if not o.level.can_move(o, p.x, p.y, teleport=True): return
		path = o.level.get_points_in_line(o, p)
		leap_effect = o.level.leap_effect
		for point in path:
			leap_effect(point.x, point.y, Tags.Physical.color, o)
			yield
		o.level.act_move(o, p.x, p.y, teleport=True)

def Sculptor():
	u = Unit()
	u.name = "Sculptor"
	u.asset_name = 'the_sculptor'
	u.max_hp = 1000
	u.tags = [Tags.Living]

	heal = HealAlly(heal=300, range=1.5, tag=Tags.Construct, can_target_self=False)
	heal.melee = True
	heal.name = "Repair Idol"

	u.spells = [heal, SimpleMeleeAttack(damage=10)]
	u.buffs = [SculptorRelocation()]
	return u

class GrantSorcery(Spell):

	def on_init(self):
		self.name = "Grant Sorcery"
		self.range = 0

	def can_threaten(self, x, y):
		return False

	def get_description(self):
		return "Grants a ranged [Fire] or [Lightning] attack to a random ally, along with immunity to that damage type"

	def get_ai_target(self):
		candidates = [u for u in self.caster.level.units if not are_hostile(u, self.caster) and not u.has_buff(TouchedBySorcery)]
		if not candidates: return None
		return random.choice(candidates)

	def can_cast(self, x, y):
		return True

	def cast_instant(self, x, y):
		unit = self.caster.level.get_unit_at(x, y)
		if not unit: return
		element = random.choice([Tags.Fire, Tags.Lightning])
		buff = TouchedBySorcery(element)
		unit.apply_buff(buff)
		self.caster.level.show_path_effect(self.caster, unit, element, minor=True)

def IdolOfSorcery():
	idol = BigIdol()
	idol.asset_name = '3x3_idol_of_sorcery'
	idol.name = "Idol of Sorcery"
	idol.spells.append(GrantSorcery())
	return idol

class BannerBuff(Buff):

	def on_applied(self, owner):
		self.global_triggers[EventOnUnitAdded] = self.on_unit_added
		self.owner_triggers[EventOnDeath] = self.on_death

		for unit in self.owner.level.units:
			if unit.is_lair:
				unit.buffs[0].min_turns -= 1
				unit.buffs[0].max_turns -= 1

	def on_unit_added(self, evt):
		if evt.unit.is_lair:
			evt.unit.buffs[0].min_turns -= 1
			evt.unit.buffs[0].max_turns -= 1

	def on_death(self, evt):
		for u in self.owner.level.units:
			if u.is_lair:
				u.buffs[0].min_turns += 1
				u.buffs[0].max_turns += 1

	def get_tooltip(self):
		return "Gates spawn units 1 turn faster"

def WarBanner():
	banner = Unit()
	banner.name = "War Banner"
	banner.stationary = True
	banner.max_hp = 35
	banner.buffs.append(BannerBuff())
	return banner

def Watcher():
	unit = Unit()
	unit.name = "Watcher"
	unit.max_hp = 40
	unit.spells.append(SimpleRangedAttack(name="Lightning Eye", damage=10, range=30, damage_type=Tags.Lightning, beam=True))
	unit.stationary = True
	unit.tags = [Tags.Construct, Tags.Lightning]
	unit.resists[Tags.Lightning] = 50
	unit.resists[Tags.Fire] = 50
	return unit

def VoidWatcher():
	unit = Watcher()
	unit.name = "Void Watcher"
	unit.shields = 1
	unit.resists[Tags.Lightning] = 0
	unit.resists[Tags.Arcane] = 100
	unit.spells[0] = SimpleRangedAttack(name="Void Eye", damage=10, range=30, damage_type=Tags.Arcane, beam=True, melt=True)
	unit.spells[0].cool_down = 3
	unit.tags = [Tags.Construct, Tags.Arcane]
	return unit

def Observer():
	u = Unit()
	u.name = "Observer"
	u.asset_name = "twofold_watcher"
	u.max_hp = 2020
	u.stationary = True
	u.tags = [Tags.Construct, Tags.Lightning]
	u.resists[Tags.Lightning] = 50
	u.resists[Tags.Fire] = 50

	chain = MonsterChainLightning()
	chain.damage = 20
	chain.range = 12
	chain.quick_cast = True
	u.spells = [chain]

	return u

class DreamerBuff(Buff):

	def on_init(self):
		self.description = "Each turn, 50% chance to teleport each other unit up to 4 tiles away"
		self.color = Tags.Translocation.color

	def get_tooltip(self):
		return self.description

	def on_advance(self):
		level = self.owner.level
		for u in level.units:

			if u == self.owner:
				continue

			if random.random() < .5:
				targets = [t for t in level.iter_tiles() if level.can_stand(t.x, t.y, u) and distance(t, u) < 4]
				if targets:
					teleport_target = random.choice(targets)
					level.flash(u.x, u.y, Tags.Translocation.color)
					level.act_move(u, teleport_target.x, teleport_target.y, teleport=True)
					level.flash(u.x, u.y, Tags.Translocation.color)

def IdolOfInsanity():
	idol = BigIdol()
	idol.name = "Idol of Insanity"
	idol.asset_name = 'idol_of_insanity'
	idol.buffs.append(DreamerBuff())
	return idol

class TreeThornSummon(Spell):

	def on_init(self):
		self.name = "Grow Thorns"
		self.num_thorns = 3
		self.cool_down = 3
		self.range = 0
		self.self_target = True
		self.extra_unit_tt_fns = [(FaeThorn, False)]

	def get_description(self):
		return "Summon 3 Fae Thorns near the wizard"

	def get_ai_target(self):
		return self.owner

	def cast_instant(self, x, y):
		for i in range(self.num_thorns): self.summon(FaeThorn(), target=self.caster.level.player_unit)

class YggdrasilsDream(Buff):

	def on_init(self):
		self.name = "Yggdrasil's Dream"
		self.description = ("Each turn, enemies take 2 [Dark] and [Arcane] damage\nAllies are healed instead")

	def on_advance(self):
		allies = []
		enemies = []
		owner = self.owner
		for u in owner.level.units:
			if are_hostile(owner, u): enemies.append(u)
			else: allies.append(u)

		damage_types = [Tags.Arcane, Tags.Dark]
		for u in enemies:
			for dt in damage_types:
				u.deal_damage(2, dt, self)

		for u in allies: u.heal(2, self)

def TwistedTree():
	tree = Unit()
	tree.name = "Yggdrasil"
	tree.tags = [Tags.Nature, Tags.Demon]

	tree.radius = 1
	tree.asset_name = '3x3_yggdrasil'

	tree.resists[Tags.Physical] = 50
	tree.resists[Tags.Arcane] = 50
	tree.resists[Tags.Dark] = 50
	tree.resists[Tags.Fire] = -100

	tree.spells.append(TreeThornSummon())

	tree.buffs.append(YggdrasilsDream())
	tree.buffs.append(SummonReinforcements(Aesir, 3, 75))
	tree.buffs.append(UnlockAchievementOnDeathBuff("YGGDRASIL"))

	tree.stationary = True

	tree.max_hp = 3550

	return tree

class TimeKeeperTimestop(Spell):

	def on_init(self):
		self.name = "Timestop"
		self.description = "Stun all enemies for 1 turn"
		self.cool_down = 3
		self.range = 0

	def can_threaten(self, x, y):
		return False

	def cast_instant(self, x, y):
		for unit in self.caster.level.units:
			if are_hostile(self.caster, unit):
				unit.apply_buff(Stun(), 1)

	def can_cast(self, x, y):
		return True

def TimeKeeper():
	lord = Unit()
	lord.name = "Time Keeper"
	lord.tags = [Tags.Arcane, Tags.Construct]

	lord.max_hp = 300
	lord.shields = 3

	lord.spells.append(TimeKeeperTimestop())
	lord.spells.append(SimpleRangedAttack(damage=9, range=6, damage_type=Tags.Arcane))

	lord.resists[Tags.Arcane] = 75
	return lord

def RainbowDragon():
	dragon = Unit()
	dragon.name = "Rainbow Drake"

	dragon.max_hp = 38
	dragon.flying = True

	dragon.resists[Tags.Fire] = 75
	dragon.resists[Tags.Lightning] = 75
	dragon.resists[Tags.Arcane] = 75

	dragon.spells.append(VoidBreath())
	dragon.spells.append(StormBreath())
	dragon.spells.append(FireBreath())

	dragon.spells.append(SimpleMeleeAttack(8))

	dragon.tags = [Tags.Dragon, Tags.Living, Tags.Lightning, Tags.Fire, Tags.Arcane]

	return dragon

class JarAlly(Spell):

	def on_init(self):
		self.name = "Pickle Soul"
		self.range = RANGE_GLOBAL
		self.cool_down = 3
		self.requires_los = False

	def get_description(self):
		return "Target ally becomes Soulbound to the Idol of Souls"

	def can_threaten(self, x, y):
		return False

	def get_ai_target(self):
		return self.get_eligible_target(self.caster, self.caster.level)

	def get_eligible_target(self, caster, level):
		allies = [u for u in level.units if are_friendly(caster, u)
				  				   and not u == self.caster
				  				   and not u.has_buff(Soulbound)
				  				   and self.can_cast(u.x ,u.y)]
		if not allies: return None
		return random.choice(allies)

	def cast_instant(self, x, y):
		caster = self.caster
		level = caster.level
		unit = level.get_unit_at(x, y)
		if not unit: return
		level.show_path_effect(caster, unit, Tags.Dark)
		unit.apply_buff(Soulbound(caster))


def GiantSoulJar():
	u = BigIdol()
	u.name = "Idol of Souls"
	u.asset_name = "3x3_soul_jar"
	u.tags = [Tags.Construct, Tags.Dark, Tags.Arcane]
	u.spells.append(JarAlly())
	add_tooltip(u, Soulbound(u))
	return u


class BloodSlimeBreath(BreathWeapon):

	def on_init(self):
		self.damage = 7

	def get_description(self):
		return "Cone attack\nSummon Blood Slimes on empty tiles"

	def per_square_effect(self, x, y, damage):
		unit = self.caster.level.get_unit_at(x, y)
		if unit: self.caster.level.deal_damage(x, y, damage, self.damage_type, self)
		else: self.summon(BloodSlime(), Point(x, y))

class TaurokeleveeBloodBuff(Buff):

	def __init__(self):
		Buff.__init__(self)
		self.name = "Corrupted Blood"
		self.color = Tags.Blood.color
		self.description = ("Heal 10 HP each turn\n"
							"Excess raises max HP\n"
							"When damaged, summon a Blood Slime")


	def on_applied(self, owner):
		self.growth = 10
		self.owner_triggers[EventOnDamaged] = self.on_damaged

	def on_advance(self):
		o = self.owner
		g = self.growth
		if (o.cur_hp + g) >= o.max_hp: o.max_hp = o.cur_hp + g
		o.deal_damage(-g, Tags.Heal, self)

	def on_damaged(self, evt):
		if evt.damage < 1: return
		self.summon(BloodSlime(), self.owner)

def Taurokelevee():
	u = Unit()
	u.radius = 1
	u.name = "Taurokelevee"
	u.asset_name = '3x3_blood_beast'
	u.tags = [Tags.Blood, Tags.Dark, Tags.Slime, Tags.Undead]
	u.max_hp = 697

	def bloodsoak(caster, target):
		if are_hostile(caster, target): target.apply_buff(NecrosisBuff())
		else: target.apply_buff(RegenBuff(1))

	burst = SimpleBurst(3, 4, Tags.Dark, cool_down=2, onhit=bloodsoak, extra_desc="\nEnemies receive [necrosis]\nAllies receive [Regeneration:heal]")
	burst.name = "Blood Burst"

	breath = BloodSlimeBreath()
	breath.name = "Gore Vent"
	breath.damage_type = Tags.Dark
	breath.range = 7
	breath.cool_down = 4

	u.spells = [breath, burst]
	u.buffs = [TaurokeleveeBloodBuff(), UnlockAchievementOnDeathBuff("TAUROKELEVEE")]
	u.extra_tt_fns = [BloodSlime]
	add_tooltip(u, RegenBuff(1))

	u.shrink_text = 1

	return u

class MedusaSnakeBuff(Buff):

	def on_init(self):
		self.owner_triggers[EventOnDamaged] = self.on_damaged

	def on_damaged(self, evt):
		if evt.damage < 0: return
		self.summon(Snake())
			
	def get_tooltip(self):
		return "When damaged, summon a Snake nearby"

class MedusaGaze(Spell):

	def on_init(self):
		self.name = "Medusa's Gaze"
		self.description = "Petrifies all units in line of sight for 3 turns"
		self.cool_down = 6
		self.range = 0

	def get_ai_target(self):
		if any(are_hostile(self.caster, u) for u in self.caster.level.get_units_in_los(self.caster)):
			return self.caster
		else: return None

	def get_impacted_tiles(self, x, y):
		return self.caster.level.get_points_in_los(self.caster)

	def cast_instant(self, x, y):
		for u in self.caster.level.get_units_in_los(self.caster):
			if u == self.caster:
				continue
			u.apply_buff(PetrifyBuff(), 3)

def Medusa():
	unit = Unit()

	unit.name = "Medusa"

	unit.max_hp = 870

	unit.spells.append(MedusaGaze())
	melee = SimpleMeleeAttack(damage=4, attacks=5, buff=Poison, buff_duration=15)
	melee.name = "Snake Bites"
	unit.spells.append(melee)

	unit.tags = [Tags.Nature, Tags.Arcane, Tags.Living, Tags.Dark]

	unit.buffs.append(MedusaSnakeBuff())
	return unit

def SwampQueen():
	unit = Unit()
	unit.name = "Swamp Queen"
	unit.max_hp = 59
	unit.shields = 2

	def mushboom():
		return random.choice([GreyMushboom(), GreenMushboom()])

	mushbooms = SimpleSummon(mushboom, num_summons=5, cool_down=12)
	mushbooms.name = "Mushbloom"
	mushbooms.description = "Summons 5 grey or green mushbooms"

	flytraps = SimpleSummon(FlyTrap, num_summons=2, global_summon=True, cool_down=9)
	flytraps.name = "Grow Fly Traps"

	heal = HealAlly(heal=18, range=9)
	heal.cool_down = 5
	gaze = SimpleRangedAttack(damage=1, damage_type=Tags.Poison, buff=Poison, buff_duration=10, range=14, cool_down=3)
	gaze.name = "Toxic Gaze"

	healaura = WizardHealAura(heal=1, duration=7, cool_down=12, radius=10)

	unit.spells = [mushbooms, flytraps, healaura, gaze]

	unit.tags = [Tags.Poison, Tags.Living, Tags.Nature]
	return unit

class BoxOfWoeBuff(Buff):

	def on_init(self):
		self.spawners = [Pain, Death, Sorrow]
		self.owner_triggers[EventOnDeath] = self.on_death
		self.description = "Releases 3 evil spirits when destroyed"

	def on_death(self, evt):
		for spawner in self.spawners: self.summon(self.get_unit(spawner))

	def get_unit(self, spawner):
		u = spawner()
		src = getattr(getattr(self, 'owner', None), 'source', None)
		if src: u.source = src; apply_minion_bonuses(src, u)
		return u

	def get_unit_extra_examine_tooltips(self):
		return [self.get_unit(s) for s in self.spawners]


def BoxOfWoe():
	unit = Unit()
	unit.name = "Box of Woe"
	unit.max_hp = 25
	unit.shields = 2

	unit.stationary = True
	aura = DamageAuraBuff(damage=2, radius=6, damage_type=[Tags.Ice, Tags.Dark, Tags.Lightning])
	aura.name = "Aura of Woe"
	unit.buffs.append(aura)
	unit.buffs.append(BoxOfWoeBuff())

	unit.tags = [Tags.Arcane, Tags.Dark, Tags.Construct]

	unit.resists[Tags.Physical] = 50
	unit.resists[Tags.Dark] = 75

	return unit


def AvianWizard():
	unit = Unit()
	unit.name = "Avian Wizard"
	unit.flying = True
	unit.max_hp = 64
	unit.shields = 3
	eagles = SimpleSummon(Thunderbird, num_summons=3, cool_down=18)

	windride = MonsterTeleport()
	windride.cool_down = 6
	windride.range = 12
	windride.name = "Ride the Wind"
	windride.description = "Teleports to a random location"

	def make_clouds(caster, target):
		points = [p for p in target.level.get_points_in_ball(target.x, target.y, radius=3) if not target.level.tiles[p.x][p.y].cloud]
		random.shuffle(points)
		for i in range(4):
			if not points: break
			p = points.pop()
			target.level.add_obj(StormCloud(caster), p.x, p.y)

	stormy = SimpleRangedAttack(damage=4, damage_type=Tags.Lightning, range=9, onhit=make_clouds)
	stormy.name = "Storm Strike"
	stormy.description = "Creates Storm Clouds near the target"

	unit.spells = [eagles, windride, stormy]

	unit.resists[Tags.Lightning] = 100
	unit.resists[Tags.Holy] = 100

	unit.tags = [Tags.Living, Tags.Nature, Tags.Lightning]
	unit.is_wizard = True
	return unit

class WizardThunderStrike(Spell):

	def on_init(self):
		self.range = 8
		self.name = "Thunder Strike"
		self.damage = 9
		self.damage_type = [Tags.Lightning]
		self.radius = 2
		self.duration = 3
		self.cool_down = 12

	def get_ai_target(self):
		# Try to hit something directly but settle for stunning something
		return Spell.get_ai_target(self) or self.get_corner_target(self.radius)

	def get_description(self):
		return "Stuns all enemies in an area around the target for [{duration}:duration] turns"

	def cast(self, x, y):
		duration = self.get_stat('duration')
		radius = self.get_stat('radius')
		caster = self.caster
		level = caster.level
		getu = level.get_unit_at
		flash = level.flash
		
		level.deal_damage(x, y, self.get_stat('damage'), self.damage_type[0], self)
		yield 
		for stage in Burst(level, Point(x, y), radius):
			for point in stage:
				flash(point.x, point.y, Tags.Physical.color)
				cur_target = getu(point.x, point.y)
				if cur_target and are_hostile(cur_target, caster):
					cur_target.apply_buff(Stun(), duration)
			yield

class WizardGrounding(Spell):
	
	def on_init(self):
		self.name = "Lightning Protection"
		self.duration = 8
		self.cool_down = 12
		self.range = 0
		self.target_allies = True

	def get_description(self):
		return "Caster and allies gain 50% [Lightning] resist for [{duration}:duration] turns"

	def cast(self, x, y):
		for u in self.caster.level.units:
			if not are_hostile(u, self.caster):
				u.apply_buff(ResistLightning(), self.get_stat('duration'))
				yield

class WizardLightningFlash(Spell):

	def on_init(self):
		self.damage = 3
		self.name = "Flash of Lightning"
		self.range = 20
		self.can_target_self = True

		self.cool_down = 16

	def get_description(self):
		return ("Teleport the caster\n"
				"On arrival, deal [{damage}:damage] [Lightning] and blind enemies in line of sight for 2 turns")

	def get_ai_target(self):
		return self.caster

	def cast(self, x, y):
		randomly_teleport(self.caster, self.range, flash=True, requires_los=False)
		yield

		points = [p for p in self.caster.level.get_points_in_los(self.caster) if not (p.x == self.caster.x and p.y == self.caster.y)]
		damage = self.get_stat('damage')

		random.shuffle(points)
		points.sort(key = lambda u: distance(self.caster, u))

		for p in points:
			unit = self.caster.level.get_unit_at(p.x, p.y)
	
			if unit:
				if not are_hostile(self.owner, unit):
					continue
			
				self.caster.level.deal_damage(p.x, p.y, damage, Tags.Lightning, self)
				unit.apply_buff(BlindBuff(), 2)
				
				self.owner.level.show_path_effect(self.caster, unit, Tags.Lightning, minor=True)
				yield


def LightningWizard():
	unit = Unit()
	unit.name = "Lightning Master"
	unit.asset_name = "lightning_wizard"
	unit.max_hp = 32
	unit.shields = 8

	insulate = WizardGrounding()
	electrocute = SimpleRangedAttack(damage=6, damage_type=Tags.Lightning, range=9, beam=True)
	electrocute.name = "Lightning Bolt"

	thunderstrike = WizardThunderStrike()

	lflash = WizardLightningFlash()

	unit.tags = [Tags.Living, Tags.Lightning]

	unit.resists[Tags.Lightning] = 50

	unit.spells = [insulate, thunderstrike, lflash, electrocute]
	unit.is_wizard = True
	return unit

def FireWizard():
	unit = Unit()
	unit.max_hp = 70
	unit.name = "Fire Wizard"
	unit.asset_name = "fire_wizard"
	unit.tags = [Tags.Living, Tags.Fire]

	firedrake = SimpleSummon(FireDrake, cool_down=20)
	fireprot = FireProtection()
	fireball = SimpleRangedAttack(damage=9, damage_type=Tags.Fire, range=8, radius=2)

	unit.spells = [firedrake, fireprot, fireball]

	unit.resists[Tags.Fire] = 100
	unit.is_wizard = True

	return unit

class WizardStoneSkin(Spell):
	
	def on_init(self):
		self.name = "Stoneskin"
		self.duration = 8
		self.cool_down = 12
		self.range = 0
		self.target_allies = True

	def get_description(self):
		return "Caster and allies gain 50% [Physical] resist for [{duration}:duration] turns"

	def cast(self, x, y):
		for u in self.caster.level.units:
			if not are_hostile(u, self.caster):
				u.apply_buff(Stoneskin(), self.get_stat('duration'))
				yield


class WizardEarthquake(Spell):

	def on_init(self):
		self.name = "Earthquake"
		self.radius = 10
		self.cool_down = 16
		self.range = 0
		self.damage = 14
		self.damage_type = [Tags.Physical]

	def get_ai_target(self):
		if any(are_hostile(self.caster, u) for u in self.caster.level.get_units_in_ball(self.caster, self.get_stat('radius'))):
			return self.caster
		return None

	def get_description(self):
		return ("Damages enemies in a burst around the caster\n"
				"50% chance to destroy affected walls")

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		points = list(level.get_points_in_ball(caster.x, caster.y, radius=self.get_stat('radius')))
		random.shuffle(points)
		dmg = self.get_stat('damage')
		for p in points:
			unit = level.get_unit_at(p.x, p.y)
			if unit and are_hostile(caster, unit): unit.deal_damage(dmg, Tags.Physical, self)
			tile = level.tiles[p.x][p.y]
			if random.random() > .5:
				level.show_effect(p.x, p.y, Tags.Physical)
				if tile.is_wall(): level.make_floor(p.x, p.y)
		yield

def MountainWizard():
	unit = Unit()
	unit.name = "Mountain Mage"
	unit.asset_name = "mountain_wizard"
	unit.max_hp = 86

	stoneskin = WizardStoneSkin()
	quake = WizardEarthquake()

	earthele = SimpleSummon(EarthElemental, cool_down=5, duration=15, path_effect=Tags.Nature)

	wolves = SimpleSummon(Wolf, cool_down=8, num_summons=3, custom_plural='Wolves')

	spikes = SimpleRangedAttack(damage=3, range=5)

	unit.spells = [stoneskin, earthele, wolves, quake, spikes]

	unit.tags = [Tags.Living, Tags.Nature]
	unit.is_wizard = True
	return unit


def GremlinWizard():
	unit = Unit()
	unit.name = "Mogwai Mage"
	unit.asset_name = 'gremlin_mage'
	unit.max_hp = 135
	unit.shields = 3
	unit.tags = [Tags.Demon, Tags.Dark]

	melee = SimpleMeleeAttack(6, drain=True)
	heal = HealAlly(8, range=5)
	bolt = SimpleRangedAttack(name="Fear Ball", damage=10, damage_type=Tags.Dark, range=6, radius=2, buff=FearBuff, buff_duration=1, cool_down=2)

	unit.spells = [bolt, heal, melee]
	unit.buffs = [SpawnOnHeal(spawn_fn=Gremlin)]

	unit.is_wizard = True

	return unit

def MaskWizard():
	unit = Unit()
	unit.name = "Masked Wizard"
	unit.asset_name = "mask_wizard"
	unit.max_hp = 1
	unit.shields = 13

	voidbeam = SimpleRangedAttack(damage=6, damage_type=Tags.Arcane, range=14, beam=True, melt=True, cool_down=6)
	voidbeam.name = "Void Beam"

	def warp(caster, target):
		randomly_teleport(target, 5)

	disperse = SimpleRangedAttack(damage=3, damage_type=Tags.Arcane, range=8, radius=3, onhit=warp, cool_down=4)
	disperse.description = "Teleports units up to 5 tiles away"
	disperse.name = "Warp Ball"

	teleport = MonsterTeleport()
	teleport.cool_down = 9

	warptouch = SimpleMeleeAttack(damage=17, damage_type=Tags.Arcane)
	warptouch.name = "Warptouch"

	unit.resists[Tags.Arcane] = 100

	unit.tags = [Tags.Arcane]

	unit.spells = [voidbeam, disperse, teleport, warptouch]
	unit.is_wizard = True
	return unit

class WizardChaosWord(Spell):

	def on_init(self):
		self.name = "Invoke Chaos"
		self.cool_down = 12
		self.range = 0
		self.target_allies = True

	def get_description(self):
		return ("Teleport all other units to random tiles\n"
				"Stun enemies for 1 turn")

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		units = list(level.units)
		getline = level.get_points_in_line
		act_move = level.act_move
		show = level.show_effect
		random.shuffle(units)

		for unit in units:
			if unit == caster: continue
			teleport_targets = [t for t in level.iter_tiles() if level.can_stand(t.x, t.y, unit)]
			if not teleport_targets: continue
			teleport_target = random.choice(teleport_targets)
			for p in getline(unit, teleport_target): show(p.x, p.y, Tags.Translocation)
			act_move(unit, teleport_target.x, teleport_target.y, teleport=True)
			if are_hostile(caster, unit): unit.apply_buff(Stun(), 1)
			yield

class WizardIceEye(Spell):
	def on_init(self):
		self.name = "Eye of Ice"
		self.cool_down = 25
		self.damage = 5
		self.duration = 9
		self.range = 0

	def get_description(self):
		return "Deal [{damage}:damage] [Ice] to an enemy in line of sight each turn\nLasts [{duration}:duration] turns"

	def cast_instant(self, x, y):
		from Spells import IceEyeBuff
		buff = IceEyeBuff(self.get_stat('damage'), 1, self)
		self.caster.apply_buff(buff, self.get_stat('duration'))

def IceLich():
	unit = Unit()
	unit.max_hp = 75
	unit.shields = 2
	unit.name = "Ice Lich"
	unit.asset_name = "dark_ice_lich_wizard"

	iceeye = WizardIceEye()

	freezeball = SimpleRangedAttack(name="Ice Ball", damage=7, radius=3, range=8, damage_type=Tags.Ice, buff=FrozenBuff, buff_duration=2, cool_down=4)

	deathtouch = SimpleMeleeAttack(23, damage_type=Tags.Dark)
	deathtouch.name = "Death Touch"

	sealsoul = LichSealSoulSpell()

	unit.spells = [deathtouch, iceeye, freezeball, sealsoul]

	unit.tags = [Tags.Undead, Tags.Dark, Tags.Ice]

	unit.resists[Tags.Dark] = 100
	unit.resists[Tags.Arcane] = 50
	unit.resists[Tags.Ice] = 75
	unit.resists[Tags.Fire] = -100
	unit.is_wizard = True
	return unit

class WizardFireEye(Spell):
	def on_init(self):
		self.name = "Eye of Fire"
		self.cool_down = 25
		self.damage = 5
		self.damage_type = Tags.Fire
		self.duration = 9
		self.range = 0

	def get_description(self):
		return "Deal [{damage}:damage] [Fire] to an enemy in line of sight each turn\nLasts [{duration}:duration] turns"

	def cast_instant(self, x, y):
		from Spells import FireEyeBuff
		buff = FireEyeBuff(self.get_stat('damage'), 1, self)
		self.caster.apply_buff(buff, self.get_stat('duration'))

def FireLich():

	unit = Unit()
	unit.max_hp = 75
	unit.shields = 2
	unit.name = "Fire Lich"
	unit.asset_name = "dark_fire_lich_wizard"

	fireeye = WizardFireEye()

	fireball = SimpleRangedAttack(damage=13, radius=4, range=8, damage_type=Tags.Fire)
	fireball.cool_down = 8
	fireball.name = "Fireball"

	deathtouch = SimpleMeleeAttack(23, damage_type=Tags.Dark)
	deathtouch.name = "Death Touch"

	sealsoul = LichSealSoulSpell()

	unit.spells = [deathtouch, fireeye, fireball, sealsoul]

	unit.resists[Tags.Dark] = 100
	unit.resists[Tags.Arcane] = 50
	unit.resists[Tags.Fire] = 75
	unit.resists[Tags.Ice] = -100

	unit.tags = [Tags.Undead, Tags.Dark, Tags.Fire]
	unit.is_wizard = True
	return unit


class WizardIceAge(Spell):

	def on_init(self):
		self.name = "Ice Age"
		self.duration = 3
		self.damage = 18
		self.damage_type = Tags.Ice
		self.cool_down = 10
		self.range = 0
		self.radius = 8

	def get_description(self):
		return "Deals damage and applies [{duration}:duration] turns of [frozen] to enemies in a burst around the caster"

	def get_ai_target(self):
		for stage in Burst(self.caster.level, self.caster, self.get_stat('radius')):
			for p in stage:
				unit = self.caster.level.get_unit_at(p.x, p.y)
				if unit and are_hostile(unit, self.caster):
					return self.caster
		return None

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		getu = level.get_unit_at
		deal_damage = level.deal_damage

		damage = self.get_stat('damage')
		duration = self.get_stat('duration')

		for stage in Burst(level, Point(x, y), self.get_stat('radius')):
			for p in stage:
				unit = getu(p.x, p.y)
				if unit and are_hostile(caster, unit):
					deal_damage(p.x, p.y, damage, Tags.Ice, self)
					unit.apply_buff(FrozenBuff(), duration)
				else: level.show_effect(p.x, p.y, Tags.Ice)
			yield

def IceWizard():

	unit = Unit()
	unit.max_hp = 75
	unit.shields = 2

	unit.name = "Ice Wizard"

	icehounds = SimpleSummon(IceHound, num_summons=3, cool_down=12)

	iceage = WizardIceAge()

	icicle = SimpleRangedAttack(name="Ice Beam", damage=6, damage_type=Tags.Ice, range=6, beam=True)

	unit.spells = [icehounds, iceage, icicle]

	unit.resists[Tags.Ice] = 75

	unit.tags = [Tags.Ice, Tags.Living]
	unit.is_wizard = True
	return unit

class WizardIgnitePoison(Spell):

	def on_init(self):
		self.name = "Ignite Poison"
		self.description = "Target poisoned unit loses all poison stacks and takes that much fire damage"
		self.range = 10
		self.cool_down = 3

	def can_cast(self, x, y):
		unit = self.caster.level.get_unit_at(x, y)
		if not unit:
			return False
		return Spell.can_cast(self, x, y) and unit.has_buff(Poison)

	def cast(self, x, y):

		i = 0
		dtypes = [Tags.Fire, Tags.Poison]
		for p in self.caster.level.get_points_in_line(self.caster, Point(x, y), find_clear=True)[1:-1]:
			i += 1
			i %= 2
			self.caster.level.deal_damage(p.x, p.y, 0, dtypes[i], self)
			yield True

		# Why would we ever not have the buff?  Some krazy buff triggers probably
		target = self.caster.level.get_unit_at(x, y)
		assert(target)

		buff = target.get_buff(Poison)
		if buff:
			target.deal_damage(buff.turns_left, Tags.Fire, self)
			target.remove_buff(buff)

		yield False


def GoblinWizard():

	unit = Unit()
	unit.name = "Goblin Wizard"
	unit.tags = [Tags.Arcane, Tags.Nature, Tags.Living]
	unit.max_hp = 45
	unit.shields = 2


	spiders = SimpleSummon(GiantSpider, num_summons=3, cool_down=10)

	swap = HagSwap()
	swap.cool_down = 13
	swap.range = 12

	ignitepoison = WizardIgnitePoison()

	sting = SimpleRangedAttack(name="Poison Sting", damage=9, range=7, buff=Poison, buff_duration=7)

	unit.spells = [spiders, ignitepoison, swap, sting]
	unit.is_wizard = True
	return unit

class SanguineHealingBuff(Buff):
	def on_init(self):
		self.name = "Sanguine Healing"
		self.description = "Heal for 1 HP whenever a unit takes damage from Bleed"
		self.global_triggers[EventOnDamaged] = self.on_damaged
		self.color = Tags.Blood.color

	def on_damaged(self, evt):
		if isinstance(evt.source, BleedBuff):
			self.owner.heal(1, self)

def Hemogoblin():
	u = Goblin()
	u.name = "Hemogoblin"
	u.max_hp = 21
	u.spells = [SimpleMeleeAttack(damage=3, buff=BleedBuff, buff_duration=10)]
	u.buffs.append(SanguineHealingBuff())
	u.tags.append(Tags.Blood)
	return u

class TwilightProtection(Spell):

	def on_init(self):
		self.name = "Twilight Protection"
		self.duration = 8
		self.cool_down = 12
		self.range = 0
		self.target_allies = True

	def get_description(self):
		return "Caster and allies gain 50% [Dark] and [Holy] resist for [{duration}:duration] turns"

	def cast(self, x, y):
		for u in self.caster.level.units:
			if not are_hostile(u, self.caster):
				u.apply_buff(ResistDark(), self.get_stat('duration'))
				u.apply_buff(ResistHoly(), self.get_stat('duration'))
				yield	



class FireProtection(Spell):

	def on_init(self):
		self.name = "Fire Protection"
		self.duration = 8
		self.cool_down = 12
		self.range = 0
		self.target_allies = True

	def get_description(self):
		return "Caster and allies gain 50% [Fire] resist for [{duration}:duration] turns"

	def cast(self, x, y):
		for u in self.caster.level.units:
			if not are_hostile(u, self.caster):
				u.apply_buff(ResistFire(), self.get_stat('duration'))
				yield	

class FrostfireProtection(Spell):
	
	def on_init(self):
		self.name = "Frostfire Protection"
		self.duration = 8
		self.cool_down = 12
		self.range = 0
		self.target_allies = True

	def get_description(self):
		return "Caster and allies gain 50% [Fire] and [Ice] resist for [{duration}:duration] turns"

	def cast(self, x, y):
		for u in self.caster.level.units:
			if not are_hostile(u, self.caster):
				u.apply_buff(ResistFire(), self.get_stat('duration'))
				u.apply_buff(ResistIce(), self.get_stat('duration'))
				yield

class WizardIceGaze(Spell):

	def on_init(self):
		self.name = 'Gaze of Winter'
		self.description = "Other units in line of sight are [frozen] for 3 turns"
		self.range = 0
		self.cool_down = 18
		self.tt_color = Tags.Ice.color

	def get_ai_target(self):
		for p in self.caster.level.get_points_in_los(self.caster):
			unit = self.caster.level.get_unit_at(p.x, p.y)
			if unit and are_hostile(self.caster, unit):
				return self.caster

	def get_impacted_tiles(self, x, y):
		return self.caster.level.get_points_in_los(self.caster)

	def can_threaten(self, x, y):
		return self.caster.level.can_see(self.caster.x, self.caster.y, x, y)

	def cast(self, x, y):
		points = [p for p in self.caster.level.get_points_in_los(self.caster) if not (p.x == self.caster.x and p.y == self.caster.y)]

		random.shuffle(points)
		points.sort(key = lambda u: distance(self.caster, u))

		for p in points:
			unit = self.caster.level.get_unit_at(p.x, p.y)
			if unit:
				self.caster.level.deal_damage(p.x, p.y, 0, Tags.Ice, self)
				unit.apply_buff(FrozenBuff(), 3)
				yield
			elif random.random() < .05:
				self.caster.level.deal_damage(p.x, p.y, 0, Tags.Ice, self)
				yield				

def FrostFireHydra():
	unit = Unit()
	unit.max_hp = 18

	unit.name = "Frostfire Hydra"
	unit.asset_name = 'fire_and_ice_hydra'

	fire = SimpleRangedAttack(damage=6, range=9, damage_type=Tags.Fire, beam=True)
	fire.name = "Fire"
	fire.cool_down = 2

	ice = SimpleRangedAttack(damage=6, range=9, damage_type=Tags.Ice, beam=True)
	ice.name = "Ice"
	ice.cool_down = 2

	unit.stationary = True
	unit.spells = [ice, fire]

	unit.resists[Tags.Fire] = 100
	unit.resists[Tags.Ice] = 100

	unit.tags = [Tags.Fire, Tags.Ice, Tags.Dragon]
	return unit


def FrostfireWizard():
	unit = Unit()
	unit.name = "Frostfire Mage"
	unit.asset_name = 'fire_ice_wizard'

	unit.max_hp = 66
	unit.shields = 2

	summon = SimpleSummon(FrostFireHydra, cool_down=15, duration=25)
	insulate = FrostfireProtection()

	gaze = WizardIceGaze()

	ball = SimpleRangedAttack(damage=7, damage_type=[Tags.Ice, Tags.Fire], range=7, radius=1)
	ball.name = "Hurl Frostfire"

	unit.spells = [summon, insulate, gaze, ball]

	unit.resists[Tags.Fire] = 50
	unit.resists[Tags.Ice] = 50
	unit.tags = [Tags.Fire, Tags.Ice, Tags.Living]
	unit.is_wizard = True
	return unit

class CrystalChain(Buff):

	def on_init(self):
		self.name = "Crystal Chain"
		self.global_triggers[EventOnDamaged] = self.on_spell_cast

	def get_description(self):
		return "When a [frozen] unit takes [Arcane] damage, redeal that damage to all [frozen] enemies"

	def on_spell_cast(self, evt):
		if not evt.source or evt.source.owner != self.owner: return
		if evt.source == self: return
		if evt.damage_type != Tags.Arcane: return
		if evt.damage < 1: return
		if not evt.unit.has_buff(FrozenBuff): return
		copy_targets = [u for u in self.owner.level.units if are_hostile(self.owner, u) and u.has_buff(FrozenBuff) and u != unit]
		for u in copy_targets: self.owner.level.queue_spell(self.do_hit(u, evt.damage))

	def do_hit(self, u, dmg): u.deal_damage(dmg, Tags.Arcane, self); yield


def CrystalWizard():
	unit = Unit()
	unit.name = "Crystal Mage"
	unit.asset_name = 'arcane_ice_wizard'
	unit.flying = True

	unit.max_hp = 44
	unit.shields = 9
	summon = SimpleSummon(IceRift, num_summons=2, cool_down=10, path_effect=Tags.Ice, radius=5)
	freeze = SimpleCurse(FrozenBuff, buff_duration=6, effect=Tags.Ice)
	freeze.cool_down = 8
	freeze.name = "Ice Tomb"
	beam = SimpleRangedAttack(name="Void Beam", damage=7, damage_type=Tags.Arcane, range=5, beam=True, melt=True)

	unit.spells = [summon, freeze, beam]
	unit.buffs = [CrystalChain()]

	unit.resists[Tags.Arcane] = 75
	unit.resists[Tags.Ice] = 100
	unit.tags = [Tags.Arcane, Tags.Ice, Tags.Living]
	unit.is_wizard = True
	return unit

class PoisonProtection(Spell):

	def on_init(self):
		self.name = "Poison Protection"
		self.range = 0
		self.can_target_self = True
		self.cool_down = 16
		self.duration = 10

	def get_description(self):
		return "Allies have their [poison] removed and gain [100% Poison:poison] resist for {duration} turns"

	def get_ai_target(self):
		return self.caster

	def cast(self, x, y):
		level = self.caster.level
		allies = [u for u in level.units if are_friendly(u, self.caster) and u != self.caster]
		for u in allies:
			u.remove_buffs(Poison)
			u.apply_buff(ResistBuff(Tags.Poison, 100), self.duration)
			level.show_path_effect(self.caster, u, Tags.Nature)
		yield

def MushroomWizard():
	u = Unit()
	u.name = "Mycelial Mage"
	u.asset_name = "mushroom_mage"

	u.max_hp = 120

	heal = PoisonProtection()
	ranged = SimpleRangedAttack(name="Spore Shot", damage=4, damage_type=Tags.Poison, radius=1, range=5, buff=Poison, buff_duration=10)

	u.spells = [heal, ranged]

	u.buffs.append(RegenBuff(10))
	u.buffs.append(GeneratorBuff(GreenMushboom, .25))
	u.buffs.append(MushboomBuff(Poison, 50))

	u.resists[Tags.Fire] = -50
	u.resists[Tags.Ice] = -50
	u.resists[Tags.Poison] = 100

	u.tags = [Tags.Nature]

	u.is_wizard = True
	return u

class GraspingEarth(Buff):

	def on_init(self):
		self.name = "Grasping Earth"
		self.color = Tags.Nature.color
		self.description = "Each turn, summon a hostile Vine nearby"
		self.stack_type = STACK_INTENSITY
		self.buff_type = BUFF_TYPE_CURSE

	def on_advance(self):
		vine_team = TEAM_PLAYER if self.owner.team == TEAM_ENEMY else TEAM_ENEMY
		self.summon(Vine(), target=self.owner, radius=2, team=vine_team)

def PumpkinWizard():
	u = Unit()
	u.name = "Jack o' Flames"
	u.asset_name = 'pumpkin_wizard'
	u.tags = [Tags.Nature, Tags.Dark, Tags.Fire]
	u.max_hp = 85
	u.shields = 2
	u.resists[Tags.Fire] = 75
	u.resists[Tags.Dark] = 75

	curse = SimpleCurse(GraspingEarth, 10, effect=Tags.Nature)
	curse.name = "Entangle"
	curse.cool_down = 6
	add_tooltip(u, GraspingEarth())

	s = FireBreath()
	s.damage = 10
	s.range = 5

	m = PullAttack(damage=10, range=5, pull_squares=2, color=Tags.Nature.color)
	m.name = "Vine Pull"

	u.spells = [curse, s, m]
	u.buffs = [DamageAuraBuff(damage=1, damage_type=Tags.Fire, radius=5, custom_name="Flaming Aura")]
	return u

# class WizardStarfireBeam(Spell):
#
# 	def on_init(self):
# 		self.name = "Starfire Pulse"
# 		self.description = "Deals arcane damage in a beam, and fire damage adjacent to the beam.  Melts walls."
# 		self.cool_down = 17
#
# 		self.range = 12
# 		self.damage = 9
#
# 		self.requires_los = False
#
# 	def cast_instant(self, x, y):
#
# 		center_beam = self.caster.level.get_points_in_line(self.caster, Point(x, y))[1:]
# 		side_beam = []
# 		for p in center_beam:
# 			for q in self.caster.level.get_points_in_ball(p.x, p.y, 1.5):
# 				if q.x == self.caster.x and q.y == self.caster.y:
# 					continue
# 				if q not in center_beam and q not in side_beam:
# 					side_beam.append(q)
#
# 		for p in center_beam + side_beam:
# 			if self.caster.level.tiles[p.x][p.y].is_wall():
# 				self.caster.level.make_floor(p.x, p.y)
#
# 		for p in center_beam:
# 			self.caster.level.deal_damage(p.x, p.y, self.get_stat('damage'), Tags.Arcane, self)
#
# 		for p in side_beam:
# 			self.caster.level.deal_damage(p.x, p.y, self.get_stat('damage'), Tags.Fire, self)
#
# class StarfireOrb(Spells.OrbSpell):
# 	def on_init(self):
# 		self.name = "Solar Orb"
# 		self.description = ("Create a slow moving searing orb"
# 							"\n\nEach turn, the orb deals damage to all enemies in line of sight."
# 							"\n\nAllies in line of sight are healed instead.")
# 		self.damage = 1
# 		self.cool_down = 12
# 		self.range = 12
# 		self.minion_health = 8
#
# 	def get_ai_target(self):
# 		return self.get_corner_target(6)
#
# 	def on_make_orb(self, orb):
# 		orb.asset_name = "searing_orb"
# 		orb.resists[Tags.Ice] = 0
# 		orb.resists[Tags.Arcane] = 0
# 		buff = orb.get_buff(Spells.OrbBuff)
# 		if buff:
# 			buff.description = ("Advances towards the target each turn.\n\n"
# 							"Each turn, deal [1:damage] [fire] damage to all enemies in line of sight.\n\n"
# 							"Allies in line of sight are healed for 1 instead. ")
#
# 	def on_orb_move(self, orb, next_point):
# 		for u in orb.level.get_units_in_los(next_point):
# 			if u == self.caster:
# 				continue
# 			if u == orb:
# 				continue
# 			if are_hostile(u, self.caster):
# 				u.deal_damage(1, Tags.Fire, self)
# 			else:
# 				u.deal_damage(-1, Tags.Heal, self)

# def StarfireWizard():
# 	unit = Unit()
# 	unit.name = "Starfire Sorcerer"
# 	unit.asset_name = "starfire_wizard"
#
# 	unit.max_hp = 48
# 	unit.shields = 4
#
# 	summon = SimpleSummon(StarfireSpirit, num_summons=2, duration=8, cool_down=12)
# 	fatbeam = WizardStarfireBeam()
# 	orb = StarfireOrb()
# 	starfirebolt = SimpleRangedAttack(damage=6, radius=1, range=6, damage_type=[Tags.Arcane, Tags.Fire])
# 	starfirebolt.name = "Ball of Starfire"
# 	unit.spells = [summon, fatbeam, orb, starfirebolt]
# 	unit.tags = [Tags.Arcane, Tags.Fire, Tags.Living]
# 	unit.resists[Tags.Arcane] = 50
# 	unit.resists[Tags.Fire] = 50
# 	unit.is_wizard = True
# 	return unit

class TideOfSin(Spell):

	def on_init(self):
		self.name = "Tide of Sin"
		self.damage = 1
		self.damage_type = Tags.Holy
		self.range = 0
		self.cool_down = 4

	def get_description(self):
		return ("Damages enemies in line of sight\n"
				"Drains a spell charge")

	def cast(self, x, y):
		damage = self.get_stat('damage')
		for u in self.caster.level.get_units_in_los(self.caster):
			if not are_hostile(self.caster, u): continue
			self.caster.level.show_path_effect(self.caster, u, Tags.Holy, minor=True)
			u.deal_damage(damage, Tags.Holy, self)
			if u.is_player_controlled: drain_spell_charges(self.caster, u)
			yield

	def can_threaten(self, x, y):
		return self.caster.level.can_see(self.caster.x, self.caster.y, x, y)

class TideOfRot(Spell):

	def on_init(self):
		self.name = "Tide of Rot"
		self.description = "Inflict 4 turns of [poison] and [necrosis] on enemies in line of sight"
		self.range = 0
		self.cool_down = 4

	def cast(self, x, y):
		for u in self.caster.level.get_units_in_los(self.caster):
			if not are_hostile(self.caster, u): continue
			self.caster.level.show_path_effect(self.caster, u, Tags.Poison, minor=True)
			u.apply_buff(Poison(), 4)
			u.apply_buff(NecrosisBuff(), 4)
			yield

	def can_threaten(self, x, y):
		return self.caster.level.can_see(self.caster.x, self.caster.y, x, y)

def BlackRider():
	unit = Unit()
	unit.max_hp = 374
	unit.name = "Black Rider"
	unit.asset_name = "black_horseman"

	unit.tags = [Tags.Holy, Tags.Demon]

	teleport = MonsterTeleport()
	teleport.cool_down = 20
	teleport.range = 50
	
	gaze = SimpleRangedAttack(damage=7, damage_type=Tags.Dark, range=9)

	unit.spells = [teleport, TideOfRot(), TideOfSin(), gaze]

	unit.resists[Tags.Dark] = 100
	unit.resists[Tags.Holy] = 100
	unit.resists[Tags.Poison] = 100

	return unit

def WhiteRider():
	unit = Unit()
	unit.max_hp = 374
	unit.name = "White Rider"
	unit.asset_name = "white_horseman"

	unit.tags = [Tags.Holy, Tags.Demon]

	unit.resists[Tags.Dark] = 100
	unit.resists[Tags.Holy] = 100
	unit.resists[Tags.Fire] = 50
	unit.resists[Tags.Physical] = 50

	teleport = MonsterTeleport()
	teleport.cool_down = 20
	teleport.range = 50

	halt = SimpleRangedAttack(damage=7, range=9, proj_name='gold_arrow', buff=Stun, buff_duration=1, cool_down=3)
	halt.name = "Arrow of Halting"
	poison = SimpleRangedAttack(damage=7, range=9, proj_name='gold_arrow', buff=Poison, buff_duration=10, cool_down=3)
	poison.name = "Arrow of Poison"
	fire = SimpleRangedAttack(damage=7, range=9, radius=3, damage_type=Tags.Fire, proj_name='gold_arrow', cool_down=3)
	fire.name = "Arrow of Flame"

	unit.spells = [teleport, halt, poison, fire]

	return unit

class RedRiderHealingBuff(Buff):

	def on_init(self):
		self.description = "When a unit takes [Physical] or [Fire] damage, heal [5 HP:heal]"
		self.name = "Strife Healing"
		self.global_triggers[EventOnDamaged] = self.on_damage
		self.trigger_types = [Tags.Fire, Tags.Physical]

	def on_damage(self, evt):
		if evt.damage_type not in self.trigger_types: return
		self.owner.heal(5, self)

class RedRiderBerserkingSpell(Spell):

	def on_init(self):
		self.name = "Strife"
		self.cool_down = 13
		self.duration = 3
		self.range = 0

	def get_description(self):
		return "Berserk enemy units in line of sight for [{duration}:duration] turns"

	def get_ai_target(self):
		for u in self.caster.level.get_units_in_los(self.caster):
			if are_hostile(self.caster, u) and not u.is_player_controlled:
				return self.caster
		return None

	def cast(self, x, y):
		for u in self.caster.level.get_units_in_los(self.caster):
			if are_hostile(self.caster, u) and not u.is_player_controlled:
				u.apply_buff(BerserkBuff(), self.get_stat('duration'))
				yield

def RedRider():
	unit = Unit()

	unit.max_hp = 374
	unit.name = "Red Rider"
	unit.asset_name = "red_horseman"
	unit.tags = [Tags.Holy, Tags.Demon]

	teleport = MonsterTeleport()
	teleport.cool_down = 20
	teleport.range = 50

	unit.resists[Tags.Dark] = 100
	unit.resists[Tags.Holy] = 100
	unit.resists[Tags.Fire] = 50
	unit.resists[Tags.Physical] = 50

	unit.spells.append(teleport)
	unit.spells.append(RedRiderBerserkingSpell())
	unit.spells.append(SimpleMeleeAttack(damage=7, attacks=4))
	unit.spells.append(LeapAttack(damage=36, damage_type=Tags.Physical, range=9, is_leap=False))

	unit.buffs = [RedRiderHealingBuff()]
	return unit

def PaleRider():
	unit = Unit()

	unit.max_hp = 374

	unit.name = "Pale Rider"
	unit.asset_name = "pale_horseman"

	unit.tags = [Tags.Holy, Tags.Demon]
	unit.resists[Tags.Dark] = 100
	unit.resists[Tags.Holy] = 100
	unit.resists[Tags.Poison] = 100

	teleport = MonsterTeleport()
	teleport.cool_down = 20
	teleport.range = 50

	hades = SimpleSummon(Ghost, num_summons=7, cool_down=17)
	hades.name = "Army of Hades"

	earth = SimpleSummon(Bloodhound, num_summons=3, cool_down=17)
	earth.name = "Beasts of Earth"
	
	famine = SimpleRangedAttack(damage=7, damage_type=Tags.Poison, range=9, onhit=lambda caster, target: drain_max_hp(target, 7), cool_down=4)
	famine.name = "Famine Gaze"
	famine.description = "Drains 7 maximum hp"

	melee = SimpleMeleeAttack(70)

	unit.spells = [teleport, hades, earth, famine, melee]
	return unit

horsemen = [WhiteRider, RedRider, BlackRider, PaleRider]

def TheFurnace():
	unit = Unit()
	unit.name = "The Furnace"
	unit.asset_name = "3x3_furnace"

	unit.radius = 1

	unit.max_hp = 4096

	unit.tags = [Tags.Fire, Tags.Construct, Tags.Metallic]

	unit.resists[Tags.Physical] = 75
	unit.resists[Tags.Fire] = 100
	unit.resists[Tags.Ice] = -100


	fire = FireBreath()
	fire.cool_down = 3
	fire.range = 5
	fire.angle = math.pi / 3.0
	fire.damage = 43
	unit.spells.append(fire)

	unit.buffs.append(DamageAuraBuff(damage=4, damage_type=Tags.Fire, radius=16))

	return unit

def ShrapnelBeast():
	unit = Unit()
	unit.name = "Shrapnel Beast"

	unit.radius = 1

	unit.max_hp = 8000

	unit.tags = [Tags.Living, Tags.Metallic]

	unit.spells.append(SimpleMeleeAttack(40))
	unit.spells[0].name = "Bite"

	shrapnel_spears = ShrapnelSpears()
	shrapnel_spears.cool_down = 6
	unit.spells.insert(0, shrapnel_spears)

	unit.buffs.append(Thorns(8))

	shrapnel_buff = SpikeBeastBuff()
	shrapnel_buff.radius = 4
	shrapnel_buff.damage = 16
	unit.buffs.append(shrapnel_buff)

	return unit


class HeatedMetalBuff(Buff):

	def on_init(self):
		self.name = "Heated Metal"
		self.global_triggers[EventOnDamaged] = self.on_damaged
		self.description = "Redeal 50% of [Physical] damage dealt to enemies as [Fire] damage"

	def on_damaged(self, evt):
		if evt.damage_type != Tags.Physical: return
		if not are_hostile(self.owner, evt.unit): return
		self.owner.level.queue_spell(self.redeal(evt))

	def redeal(self, evt):
		if not evt.unit.is_alive(): return
		damage = round(.5 * evt.damage)
		if damage <= 0: return
		evt.unit.deal_damage(damage, Tags.Fire, self)
		yield

class ShrapnelSpears(Spell):

	def on_init(self):
		self.name = "Shrapnel Spears"
		self.range = 9
		self.damage = 3
		self.damage_type = [Tags.Physical, Tags.Fire]

	def get_description(self):
		return "Each portion of the beast fires a spear of molten metal at an enemy in sight"

	def cast(self, x, y):
		cast_points = [cp for cp in self.caster.level.get_points_in_ball(self.caster.x, self.caster.y, 1, diag=True) # grab the points in the 3x3
						if self.caster.level.can_see(cp.x, cp.y, x, y, light_walls=self.cast_on_walls)] # only grab points that have los on the target

		for cp in cast_points:
			yield from self.cast_spear(cp, x, y)

	def cast_spear(self, cp, x, y):

		for p in self.caster.level.get_points_in_line(cp, Point(x, y))[1:]:
			self.caster.level.projectile_effect(p.x, p.y, proj_name='silver_spear', proj_origin=cp, proj_dest=Point(x, y)) # throw the spear in fx
			yield

		unit = self.caster.level.get_unit_at(x, y)
		if unit:
			unit.deal_damage(self.get_stat('damage'), Tags.Physical, self)
			unit.deal_damage(self.get_stat('damage'), Tags.Fire, self)
			yield

def Animikii():
	unit = Unit()
	unit.max_hp = 800

	unit.name = "Animikii"
	unit.tags = [Tags.Living, Tags.Nature, Tags.Lightning]
	unit.resists[Tags.Lightning] = 100
	unit.asset_name = "thundergod"
	unit.radius = 1
	unit.shields = 20

	unit.flying = True

	claw = SimpleMeleeAttack(damage=27, damage_type=Tags.Lightning)
	claw.name = "Lightning God Talons"

	lbolt = WideBeam(name="Lightning Blast", damage=20, beam_radius=2.5, range=12, damage_type=Tags.Lightning)
	lbolt.cool_down = 3

	summon_tbird = SimpleSummon(Thunderbird, num_summons=4, cool_down=15)
	summon_tbird.name = "Gather Flock"

	unit.spells.append(summon_tbird)
	unit.spells.append(lbolt)
	unit.spells.append(claw)

	unit.apply_buff(LightningCaller())
	unit.apply_buff(LightningVengeance())

	return unit

class LightningCaller(Buff):

	def on_init(self):
		self.name = "Lightning Caller"
		self.global_triggers[EventOnDamaged] = self.on_damage
		self.tags = [Tags.Lightning]
		self.description = "When a unit takes [Lightning] damage, create a Storm Cloud near them"

	def on_damage(self, evt):
		if not evt.damage_type == Tags.Lightning:
			return

		cloud = StormCloud(self.owner)
		cloud.source = self

		if not self.owner.level.tiles[evt.unit.x][evt.unit.y].cloud: # if there's no cloud there
			self.owner.level.add_obj(cloud, evt.unit.x, evt.unit.y) # put one there
		else:
			possible_points = self.owner.level.get_points_in_ball(evt.unit.x, evt.unit.y, 2, diag=True) # look around the unit

			def can_cloud(p):
				tile = self.owner.level.tiles[p.x][p.y]
				if tile.cloud:
					return False
				if tile.is_wall():
					return False
				return True

			possible_points = [p for p in possible_points if can_cloud(p)]
			if possible_points: # if there's anywhere a cloud could go
				point = random.choice(possible_points)
				self.owner.level.add_obj(cloud, point.x, point.y) # put one there

	def get_tooltip_color(self):
		return Tags.Lightning.color

class LightningVengeance(Buff):

	def on_init(self):
		self.name = "Lightning Vengeance"
		self.global_triggers[EventOnDeath] = self.on_death
		self.tags = [Tags.Lightning]
		self.damage = 7
		self.description = self.get_description()

	def get_description(self):
		return ("If any Storm Clouds are in line of sight of an ally's death, one of them shoots a {damage} damage Lightning strike at the closest enemy in sight", {'damage': self.damage})

	def on_death(self, evt):
		if are_hostile(self.owner, evt.unit):  return

		owner = self.owner
		level = owner.level

		cloud_tiles = [c
					   for row in level.tiles
					   for c in row
					   if level.can_see(evt.unit.x, evt.unit.y, c.x, c.y)
					   and c.cloud and isinstance(c.cloud, StormCloud)]

		random.shuffle(cloud_tiles)
		for cloud in cloud_tiles:
			enemies = [u for u in level.get_units_in_los(cloud) if are_hostile(owner, u)] # grab the units the cloud can see
			if enemies:
				enemies.sort(key=lambda u: level.unit_distance(cloud,u))
				closest = enemies[0] # grab the closest one
				level.queue_spell(self.bolts(cloud, closest))
				return

	def bolts(self, cloud, closest):
		self.owner.level.show_beam(cloud, closest, Tags.Lightning)
		closest.deal_damage(self.damage, Tags.Lightning, self)
		for i in range(1): yield

	def get_tooltip_color(self):
		return Tags.Lightning.color

def Mothgod():
	unit = Unit()
	unit.max_hp = 1966 # year of first reported sighting of Mothman
	unit.shields = 8

	unit.name = "Mothgod"
	unit.asset_name = "giant_mothgod"
	unit.tags = [Tags.Arcane, Tags.Lightning, Tags.Living, Tags.Demon]
	unit.resists[Tags.Arcane] = 100
	unit.resists[Tags.Lightning] = 100
	unit.resists[Tags.Ice] = -50

	unit.radius = 1

	unit.flying = True

	lbolt = WideBeam(name="Lightning Beam", damage=11, beam_radius=1.5, range=9, damage_type=Tags.Lightning)
	lbolt.cool_down = 3

	abolt = WideBeam(name="Arcane Beam", damage=12, beam_radius=1.5, range=9, damage_type=Tags.Arcane,requires_los=False)
	abolt.cool_down = 2

	unit.spells.append(abolt)
	unit.spells.append(lbolt)

	shregen = ShieldRegenBuff(shield_max=8, shield_freq=1)

	unit.buffs.append(TeleportyBuff())
	unit.buffs.append(ArcaneFear())
	unit.buffs.append(shregen)
	unit.buffs.append(UnlockAchievementOnDeathBuff("MOTHGOD"))

	return unit

class ArcaneFear(Buff):

	def on_init(self):
		self.name = "Superstition"
		self.duration = 1
		self.global_triggers[EventOnDamaged] = self.on_damaged
		self.description = self.get_description()

	def get_description(self):
		return "Enemies are [feared] for one turn when they take [Arcane] damage"

	def on_damaged(self, evt):
		if not are_hostile(evt.unit, self.owner): return
		if evt.damage_type == Tags.Arcane: evt.unit.apply_buff(FearBuff(), self.duration)

	def get_tooltip_color(self):
		return Tags.Arcane.color

def UltimateTroubler():
	unit = Unit()
	unit.name = "Ultimate Troubler"

	unit.max_hp = 1
	unit.shields = 99
	unit.tags = [Tags.Arcane]
	unit.resists[Tags.Arcane] = 100

	unit.add_spell(TroublerBarrage())

	unit.radius = 1
	unit.flying = True
	unit.stationary = True

	unit.buffs.append(TeleportyBuff(chance=.5, radius=18))
	unit.buffs.append(UnlockAchievementOnDeathBuff("ULTIMATE_TROUBLER"))

	return unit

class TroublerBarrage(Spell):

	def on_init(self):
		self.name = "Troubler Barrage"
		self.damage_type = [Tags.Arcane]
		self.range = 9
		self.damage = 3

	def get_description(self):
		return "Shoots 9 missiles which teleport the victims randomly up to 9 tiles away."

	def cast(self, x, y):
		cast_points = [cp for cp in self.caster.level.get_points_in_ball(self.caster.x, self.caster.y, 1, diag=True)] # grab the points in the 3x3

		for cp in cast_points:
			target = self.get_ai_target() # grab a new target for each bolt.
			if target: yield from self.cast_bolt(cp, target)

	def cast_bolt(self, cp, target):
		self.caster.level.show_beam(cp, target, Tags.Arcane)
		yield

		target_u = self.caster.level.get_unit_at(target.x, target.y)
		if target_u and target_u.is_alive():
			target_u.deal_damage(self.get_stat('damage'), Tags.Arcane, self)
			randomly_teleport(target_u, 9)
			yield

def PillarOfBone():
	unit = Unit()
	unit.max_hp = 2800

	unit.name = "Pillar of Bones"
	unit.asset_name = "3x3_pillar_of_bones"
	unit.radius = 1

	unit.stationary = True

	summon_shambler = SimpleSummon(lambda: BoneShambler(32), cool_down=12, global_summon=True, max_channel=4, path_effect=Tags.Dark)
	summon_shambler.name = "Awaken Bone Shamblers"

	bonespear = SimpleRangedAttack(damage=16, beam=True, range=6)
	bonespear.name = "Bone Spear"

	unit.spells = [summon_shambler, bonespear]

	unit.resists[Tags.Physical] = 75

	unit.tags = [Tags.Undead, Tags.Dark]
	return unit

def PillarOfWorms():
	unit = Unit()
	unit.max_hp = 3000

	unit.name = "Pillar of Worms"
	unit.asset_name = '3x3_pillar_of_worms'
	unit.radius = 1
	unit.stationary = True

	summon_shambler = SimpleSummon(WormShambler, cool_down=12, global_summon=True, max_channel=3, path_effect=Tags.Poison)

	toxic_gaze = SimpleCurse(Poison, 20)
	toxic_gaze.name = "Poison"
	toxic_gaze.range = 10

	unit.spells = [summon_shambler, toxic_gaze]

	unit.tags = [Tags.Living]

	unit.buffs.append(RegenBuff(100))
	return unit

def TwilightSeer():

	unit = Unit()
	unit.name = "Twilight Seer"
	unit.max_hp = 99
	unit.shields = 1

	protection = TwilightProtection()

	hblast = FalseProphetHolyBlast()
	hblast.range = 8
	hblast.cool_down = 2

	lifedrain = SimpleRangedAttack(damage=7, damage_type=Tags.Dark, drain=True, radius=2, range=8)
	lifedrain.name = "Life Siphon"
	lifedrain.cool_down = 2

	unit.spells = [protection, lifedrain, hblast]

	unit.resists[Tags.Dark] = 75
	unit.resists[Tags.Holy] = 75
	unit.tags = [Tags.Living, Tags.Dark, Tags.Holy]

	unit.buffs.append(ReincarnationBuff(1))
	unit.is_wizard = True
	return unit

def Enchanter():

	unit = Unit()
	unit.name = "Enchanter"
	unit.max_hp = 64

	from Spells import RegenAuraSpell
	regenaura = RegenAuraSpell()
	regenaura.tags = []
	regenaura.cool_down = 32
	regenaura.duration = 8
	regenaura.heal = 8
	regenaura.radius = 4

	nightmare = WizardNightmare()

	freeze = SimpleCurse(FrozenBuff, 2)
	freeze.name = "Freeze"
	freeze.range = 5
	freeze.cool_down = 6

	shieldally = ShieldAllySpell(shields=3, range=9, cool_down=2)

	unit.spells = [regenaura, nightmare, freeze, shieldally]
	unit.tags = [Tags.Living, Tags.Enchantment]
	unit.is_wizard = True
	return unit

def Translocator():

	unit = Unit()
	unit.name = "Translocator"
	unit.asset_name = "translocation_master"

	unit.max_hp = 85
	unit.shields = 3

	teleport = MonsterTeleport()
	teleport.cool_down = 8

	swap = HagSwap()
	swap.cool_down = 3
	swap.requires_los = False
	swap.description += "\nIgnores walls"
	swap.range = 6

	phasebolt = SimpleRangedAttack(damage=16, range=4, damage_type=Tags.Arcane)
	phasebolt.onhit = lambda caster, target: randomly_teleport(target, 3)
	phasebolt.name = "Phase Bolt"
	phasebolt.description = "Teleports victims randomly up to 3 tiles away"

	unit.spells = [teleport, swap, phasebolt]
	unit.tags = [Tags.Arcane, Tags.Translocation]
	unit.resists[Tags.Arcane] = 75
	unit.resists[Tags.Physical] = 75
	unit.is_wizard = True
	return unit


def TitanLord():
	unit = Titan()
	unit.name = "Chronos, Titan Immortal"
	unit.asset_name = "titan_immortal"
	
	unit.max_hp = 1200
	unit.spells[1].damage = 28
	unit.spells[1].radius = 3
	unit.spells[1].cool_down = 3

	unit.buffs = [ReincarnationBuff(1), DamageAuraBuff(damage=2, damage_type=Tags.Fire, radius=6)]

	return unit

def IllusoryHamsa():
	u = Unit()
	u.name = "Illusory Hamsa"
	u.asset_name = 'hamsa_illusion'
	u.tags = [Tags.Holy]
	u.max_hp = 1
	u.flying = True
	for dt in damage_tags: u.resists[dt] = 0
	u.spells = [SimpleMeleeAttack(12)]
	return u

class HamsaIllusionBuff(Buff):

	def on_init(self):
		self.name = "Illusory Doubles"
		self.description = "When this unit loses a shield, summon a temporary Illusory Hamsa\nIllusory Hamsa are Soulbound to this unit"
		self.color = Tags.Holy.color
		self.spawner = IllusoryHamsa
		self.global_triggers[EventOnShieldRemoved] = self.on_unshielded

	def on_unshielded(self, evt):
		if evt.unit != self.owner: return
		u = self.summon(self.get_unit(), sort_dist=False)
		if u:
			u.turns_to_death = 12
			u.apply_buff(Soulbound(self.owner))

	def get_unit(self):
		u = self.spawner()
		src = getattr(getattr(self, 'owner', None), 'source', None)
		if src: u.source = src; apply_minion_bonuses(src, u)
		return u

	def get_unit_extra_examine_tooltips(self):
		return [self.get_unit()]

def Hamsa():
	u = Unit()
	u.name = "Hamsa"
	u.tags = [Tags.Living, Tags.Holy]
	u.max_hp = 120
	u.shields = 12
	u.flying = True

	u.spells = [SimpleMeleeAttack(12)]
	u.buffs = [ShieldRegenBuff(12, 2), HamsaIllusionBuff()]

	return u

def AesirLord():
	unit = Aesir()
	unit.name = "Odin, Aesir Immortal"
	unit.asset_name = "aesir_immortal"
	unit.max_hp = 676

	lightning = MonsterChainLightning()
	lightning.damage = 25
	lightning.cool_down = 2

	thunder = WizardThunderStrike()
	thunder.cool_down = 9

	melee = SimpleMeleeAttack(180, buff=Stun, buff_duration=1)
	melee.name = 'Gungnir'

	unit.spells = [thunder, lightning, melee]

	unit.buffs = [ReincarnationBuff(1)]

	return unit

class CloudEaterBuff(Buff):

	def __init__(self, name='Cloud Eater', heal_amt=1, cloud_types=(BlizzardCloud, StormCloud, RainCloud), cloud_types_kw='clouds'):
		self.heal_amt = heal_amt
		self.cloud_types = cloud_types
		Buff.__init__(self)
		self.name = name
		self.cloud_types_kw = cloud_types_kw
		self.color = Tags.Nature.color

	def get_description(self):
		return ("Each turn, consumes any adjacent {clouds}\nHeal {amt} HP for each cloud eaten.", {'clouds':self.cloud_types_kw, 'amt':self.heal_amt})

	def on_advance(self):
		for tile in self.owner.level.get_tiles_in_ball(self.owner.x, self.owner.y, self.owner.radius + 1, diag=True):
			if tile.cloud and isinstance(tile.cloud, self.cloud_types):
				self.owner.level.remove_obj(tile.cloud)
				self.owner.heal(self.heal_amt, self)

def Fujin():
	u = Unit()
	u.name = 'Fujin'
	u.tags = [Tags.Holy, Tags.Nature, Tags.Demon]
	u.max_hp = 760
	u.flying = True
	u.resists[Tags.Dark] = 0
	u.resists[Tags.Holy] = 0
	u.resists[Tags.Physical] = 75
	u.resists[Tags.Lightning] = 75
	def do_push(caster, target): push(target, caster, 3)
	u.spells = [SimpleRangedAttack(name="Wind Blast",damage=8, range=8, onhit=do_push, onhit_description="Pushes the target up to 3 tiles away", proj_name='ball', buff=Stun, buff_duration=1)]
	u.buffs = [CloudGeneratorBuff(RainCloud, radius=5, chance=5), CloudEaterBuff(heal_amt=10)]
	return u

def NineTheCat():
	cat = DisplacerBeast()
	cat.name = "Nine the Cat"
	cat.max_hp = 9
	cat.shields = 9
	cat.buffs.append(ShieldRegenBuff(9, 9))
	cat.buffs.append(ReincarnationBuff(9))
	cat.spells[0].damage = 9
	return cat

def BadApple():
	u = Unit()
	u.name = "Bad Apple"
	u.tags = [Tags.Nature, Tags.Dark]
	u.max_hp = 25
	u.flying = True
	u.resists[Tags.Dark] = 100
	u.resists[Tags.Poison] = 100
	u.spells = [SimpleMeleeAttack(5, Poison, 10)]
	u.buffs = [DamageAuraBuff(1, Tags.Poison, 5, "Poisonous Aura", friendly_fire=True)]
	return u

class GeminiCloneSpell(Spell):

	def on_init(self):
		self.name = "Duplicate"
		self.description = ("Create another Gemini Twin with the same current HP\n"
						    "Only 2 twins can exist at once")
		self.range = 0

	def can_cast(self, x, y):
		num_geminis = len(list(u for u in self.caster.level.units if u.name == self.caster.name))
		return num_geminis < 2 and Spell.can_cast(self, x, y)

	def cast_instant(self, x, y):
		clone = Gemini()
		clone.cur_hp = self.caster.cur_hp
		self.summon(clone)

def Gemini():
	unit = Unit()
	unit.name = "Gemini Twin"
	unit.asset_name = "gemini"
	unit.max_hp = 400
	
	unit.buffs = [HealAuraBuff(heal=3, radius=7)]

	unit.resists[Tags.Arcane] = 75
	unit.resists[Tags.Holy] = 75
	unit.resists[Tags.Dark] = 75
	
	clone = GeminiCloneSpell()

	teleport = MonsterTeleport()
	teleport.range = 15
	teleport.cool_down = 3

	bolt = SimpleRangedAttack(range=12, damage_type=Tags.Arcane, damage=5)

	unit.tags = [Tags.Nature, Tags.Holy, Tags.Living, Tags.Arcane]

	unit.spells = [clone, teleport, bolt]

	return unit

class IdolOfSlimeBuff(Buff):

	def on_init(self):

		self.description = "When a non-[Slime] ally dies, summon a matching [Slime] where it died"
		self.global_triggers[EventOnDeath] = self.on_death

	def on_death(self, evt):
		if Tags.Slime in evt.unit.tags: return
		if are_hostile(self.owner, evt.unit): return
		self.owner.level.queue_spell(self.make_slime(evt))

	def make_slime(self, evt):

		slime_options = [GreenSlime()]

		if Tags.Fire in evt.unit.tags: slime_options.append(RedSlime())
		if Tags.Ice in evt.unit.tags: slime_options.append(IceSlime())
		if Tags.Arcane in evt.unit.tags: slime_options.append(VoidSlime())
		if Tags.Lightning in evt.unit.tags: slime_options.append(ElectricSlime())
		if Tags.Blood in evt.unit.tags: slime_options.append(BloodSlime())
		slime = random.choice(slime_options)
		self.summon(slime, target=evt.unit)
		yield

def IdolOfSlime():
	unit = BigIdol()
	unit.name = "Slimesoul Idol"
	unit.asset_name = 'idol_of_slime'
	unit.buffs.append(IdolOfSlimeBuff())
	return unit

class CrucibleOfPainEnemyBuff(Buff):

	def on_init(self):

		self.global_triggers[EventOnDamaged] = self.on_damage
		self.counter = 0
		self.counter_max = 300
		self.description = "For every 300 damage dealt to any unit, summon a Furnace Hound"
		self.spawner = FurnaceHound

	def on_damage(self, evt):
		self.counter += evt.damage

		while self.counter >= self.counter_max:
			self.counter -= self.counter_max
			self.summon(self.get_unit())

	def get_unit(self):
		u = self.spawner()
		src = getattr(getattr(self, 'owner', None), 'source', None)
		if src: u.source = src; apply_minion_bonuses(src, u)
		return u

	def get_unit_extra_examine_tooltips(self):
		return [self.get_unit()]

def CrucibleOfPain():
	unit = BigIdol()
	unit.name = "Idol of Pain"
	unit.asset_name = '3x3_idol_of_pain'
	unit.buffs.append(CrucibleOfPainEnemyBuff())
	return unit

class FieryVengeanceBuff(Buff):

	def on_init(self):
		self.global_triggers[EventOnDeath] = self.on_death
		self.description = "When an ally dies, deal [9 Fire:fire] damage to a random enemy within 4 tiles"
		self.name = "Idol of Fiery Vengeance"

	def on_death(self, evt):
		if are_hostile(evt.unit, self.owner):
			return

		self.owner.level.queue_spell(self.do_damage(evt))

	def do_damage(self, evt):
		units = self.owner.level.get_units_in_ball(evt.unit, 4)
		units = [u for u in units if are_hostile(self.owner, u)]
		random.shuffle(units)
		for unit in units[:1]:
			for p in self.owner.level.get_points_in_line(evt.unit, unit)[1:-1]:
				self.owner.level.show_effect(p.x, p.y, Tags.Fire)
			unit.deal_damage(9, Tags.Fire, self)
			yield

	def can_threaten(self, x, y):

		for u in self.owner.level.units:
			if are_hostile(u, self.owner):
				continue
			if distance(u, Point(x, y)) < 4:
				return True

		return False

def IdolOfFieryVengeance():
	unit = BigIdol()
	unit.name = "Idol of Fiery Vengeance"
	unit.asset_name = "idol_of_vengeance"
	unit.buffs.append(FieryVengeanceBuff())
	return unit

class ConcussiveIdolBuff(Buff):

	def on_init(self):
		self.global_triggers[EventOnDamaged] = self.on_damage
		self.description = "Whenever an enemy takes damage, it is stunned for 1 turn"
		self.name = "Concussive Idol"

	def on_damage(self, evt):
		if not are_hostile(self.owner, evt.unit):
			return

		evt.unit.apply_buff(Stun(), 1)

def ConcussiveIdol():
	unit = BigIdol()
	unit.name = "Concussive Idol"
	unit.asset_name = "3x3_concussive_idol"
	unit.buffs.append(ConcussiveIdolBuff())
	return unit

class VampirismIdolBuff(Buff):

	def on_init(self):
		self.name = "Idol of Vampirism"
		self.global_triggers[EventOnDamaged] = self.on_damage
		self.description = "When an ally deals damage, it heals for half that much HP"

	def on_damage(self, evt):
		if not evt.source:
			return

		if not evt.source.owner:
			return

		if are_hostile(self.owner, evt.source.owner):
			return

		heal = evt.damage // 2
		if heal <= 0:
			return

		evt.source.owner.deal_damage(-heal, Tags.Heal, self)

def VampirismIdol():
	unit = BigIdol()
	unit.buffs.append(VampirismIdolBuff())
	unit.name = "Idol of Vampirism"
	unit.asset_name = "idol_of_vampirism"
	return unit

class IdolOfAgonyBuff(Buff):

	def on_init(self):
		self.name = "Aura of Agony"
		self.description = "Redeal all non-[Poison] damage dealt to enemies as [Poison] damage"
		self.global_triggers[EventOnDamaged] = self.on_damage

	def on_damage(self, evt):
		if not are_hostile(self.owner, evt.unit):
			return
		if evt.damage_type == Tags.Poison:
			return
		self.owner.level.queue_spell(self.do_damage(evt))

	def do_damage(self, evt):
		if not evt.unit.is_alive(): return
		self.owner.level.show_beam(self.owner, evt.unit, Tags.Poison, minor=True)
		evt.unit.deal_damage(evt.damage, Tags.Poison, self)
		yield

def IdolOfAgony():
	unit = BigIdol()
	unit.buffs.append(IdolOfAgonyBuff())
	unit.name = "Idol of Agony"
	unit.asset_name = 'idol_of_agony'
	return unit

# Idol of Weakness: each turn, each enemy gets -25 resist to a random element for 20 turns
class IdolOfWeaknessDebuff(Buff):
	
	def __init__(self, tag):
		self.tag = tag
		Buff.__init__(self)

	def on_init(self):
		self.name = "%s Weakness" % self.tag.name
		self.stack_type = STACK_INTENSITY
		self.buff_type = BUFF_TYPE_CURSE
		self.color = self.tag.color
		self.resists[self.tag] = -25

class IdolOfWeaknessSpell(Spell):

	def on_init(self):
		self.name = "Weaken"
		self.description = "Enemies lose 25 resistance to a random damage type for 8 turns"
		self.range = 0

	def cast_instant(self, x, y):
		caster = self.caster
		tag = random.choice(damage_tags)
		for u in caster.level.units:
			if not are_hostile(caster, u): continue
			caster.level.show_beam(caster, u, tag, minor=True)
			u.apply_buff(IdolOfWeaknessDebuff(tag), 8)

def IdolOfWeakness():
	unit = BigIdol()
	unit.spells.append(IdolOfWeaknessSpell())
	unit.name = "Idol of Frailty"
	unit.asset_name = 'idol_of_weakness'
	return unit

class IdolOfNightmaresBuff(DamageAuraBuff):

	def __init__(self):
		DamageAuraBuff.__init__(self, 1, [Tags.Dark, Tags.Arcane], 6, custom_name="Nightmare Touched")

	def on_init(self):
		self.color = Tags.Dark.color
		self.buff_type = BUFF_TYPE_BLESS
		self.resists[Tags.Arcane] = 75
		self.resists[Tags.Dark] = 75
		self.asset = ['status', 'nightmared']

class IdolOfNightmaresSpell(Spell):

	def on_init(self):
		self.requires_los = False
		self.range = 99
		self.radius = 6
		self.damage = 1
		self.duration = 10
		self.target_allies = True
		self.name = "Bestow Nightmare"

	def get_description(self):
		return ("Apply Nightmare Touched to an ally for [{duration}:duration] turns")

	def get_ai_target(self):
		candidates = [u for u in self.owner.level.units if not are_hostile(u, self.owner) and not u.has_buff(IdolOfNightmaresBuff)]
		if candidates: return random.choice(candidates)
		return None

	def can_cast(self, x, y):
		return True

	def cast_instant(self, x, y):
		unit = self.owner.level.get_unit_at(x, y)
		if not unit: return
		unit.apply_buff(IdolOfNightmaresBuff(), self.get_stat('duration'))
		self.owner.level.show_path_effect(self.caster, unit, [Tags.Dark, Tags.Arcane], minor=True)

def IdolOfNightmares():
	unit = BigIdol()
	unit.spells.append(IdolOfNightmaresSpell())
	unit.buffs.append(IdolOfNightmaresBuff())
	unit.name = "Idol of Nightmares"
	unit.asset_name = 'the_tree_of_pain_and_nightmares'
	add_tooltip(unit, IdolOfNightmaresBuff())
	return unit

class IdolOfShieldingSpell(Spell):

	def on_init(self):
		self.name = "Mass Protection"
		self.description = "Allies gain 1 SH up to a max of 3"
		self.range = 0
		self.cool_down = 2

	def cast_instant(self, x, y):
		for u in self.owner.level.units:
			if are_hostile(self.owner, u): continue
			if u.shields >= 3: continue
			u.add_shields(1)

def IdolOfShielding():
	unit = BigIdol()
	unit.spells.append(IdolOfShieldingSpell())
	unit.shields *= 5
	unit.name = "Idol of Invincibility"
	unit.asset_name = 'idol_of_shielding'
	return unit

class GrantRebirth(Spell):

	def on_init(self):
		self.name = "Grant Rebirth"
		self.description = "A random ally gains the ability to reincarnate"
		self.range = RANGE_GLOBAL
		self.cool_down = 3
		self.requires_los = False

	def can_threaten(self, x, y):
		return False

	def get_ai_target(self):
		return self.get_eligible_target(self.caster, self.caster.level)

	def get_eligible_target(self, caster, level):
		allies = [u for u in level.units if are_friendly(caster, u)
				  				   and not u == self.caster
				  				   and not u.is_player_controlled
				  				   and not u.has_buff(ReincarnationBuff)
				  				   and self.can_cast(u.x ,u.y)]
		if not allies: return None
		return random.choice(allies)

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		unit = level.get_unit_at(x, y)
		if not unit: return
		level.show_path_effect(caster, unit, Tags.Holy)
		unit.apply_buff(ReincarnationBuff())
		yield

def IdolOfRebirth():
	unit = BigIdol()
	unit.name = "Idol of Rebirth"
	unit.asset_name = '3x3_idol_of_rebirth' # placeholder
	unit.spells = [GrantRebirth()]
	return unit

class FrostNova(Spell):

	def on_init(self):
		self.name = "Frost Nova"
		self.damage = 10
		self.duration = 3
		self.radius = 4
		self.range = 0
		self.self_target = True
		self.cool_down = 1
		self.damage_type = [Tags.Ice]

	def get_description(self):
		return ("Damages enemies and inflicts {duration} turns of [frozen] in a burst around the caster"
				"\nEach cast increases radius and cooldown by 1"
				"\nCasts as often as possible, even if no enemies are in range")

	def get_ai_target(self):
		return self.owner

	def cast(self, x, y):
		c = self.caster
		lvl = c.level
		dmg = self.get_stat('damage')
		dur = self.get_stat('duration')
		for stage in Burst(lvl, c, self.get_stat('radius')):
			for p in stage:
				u = lvl.get_unit_at(p.x, p.y)
				if u and are_hostile(c, u):
					u.deal_damage(dmg, Tags.Ice, self)
					u.apply_buff(FrozenBuff(), dur)
				if not u: lvl.show_effect(p.x, p.y, Tags.Ice)
			yield
		self.cool_down += 1
		self.radius += 1

def IdolOfFrost():
	unit = BigIdol()
	unit.asset_name = "3x3_idol_of_frost"
	unit.spells.append(FrostNova())
	unit.name = "Idol of Frost"
	return unit

class IdolOfFiendsBuff(Buff):

	def on_init(self):
		self.description = ("For every 100 damage dealt, summon a tormentor\n\n"
							"For every 666 damage dealt, summon a fiend")
		self.global_triggers[EventOnDamaged] = self.on_damage
		
		self.tormentor_spawners = [FieryTormentor, FrostfireTormentor, IcyTormentor]
		self.fiend_spawners = [FireFiend, IronFiend, StormFiend]
		self.tormentor_counter = 0
		self.fiend_counter = 0
		self.tormentor_counter_max = 100
		self.fiend_counter_max = 666

		self.color = Tags.Chaos.color

	def on_damage(self, evt):

		self.tormentor_counter += evt.damage
		self.fiend_counter += evt.damage

		while self.tormentor_counter >= self.tormentor_counter_max:
			self.tormentor_counter -= self.tormentor_counter_max
			unit = self.get_unit(random.choice(self.tormentor_spawners))
			if self.summon(unit, radius=60, sort_dist=False):
				self.owner.level.show_path_effect(self.owner, unit, Tags.Dark, minor=True)
		
		while self.fiend_counter >= self.fiend_counter_max:
			self.fiend_counter -= self.fiend_counter_max
			unit = self.get_unit(random.choice(self.fiend_spawners))
			if self.summon(unit, radius=60, sort_dist=False):
				self.owner.level.show_path_effect(self.owner, unit, Tags.Chaos, minor=True)

	def get_unit(self, spawner):
		unit = spawner()
		if self.owner.source:
			unit.source = self.owner.source
			apply_minion_bonuses(self.owner.source, unit)
		return unit

	def get_unit_extra_examine_tooltips(self):
		return [self.get_unit(spawner) for spawner in self.tormentor_spawners + self.fiend_spawners]

def IdolOfFiends():
	unit = BigIdol()
	unit.buffs.append(IdolOfFiendsBuff())
	unit.name = "Idol of Fiends"
	unit.asset_name = 'idol_of_nightmares'
	return unit

def GiantFleshFiend():
	unit = FleshFiend()
	unit.max_hp = 9006
	unit.radius = 1
	unit.asset_name = "3x3_fleshfiend"
	unit.name = "Flesh Colossus"
	unit.spells[0].damage = 66

	unit.buffs.append(DamageAuraBuff(damage=30, damage_type=[Tags.Poison, Tags.Dark], radius=5))
	unit.buffs.append(UnlockAchievementOnDeathBuff("FLESH_COLOSSUS"))
	return unit

def GiantBoneShambler():
	unit = BoneShambler(256)
	unit.max_hp = 2304
	unit.buffs = [SpawnOnDeath(lambda : BoneShambler(256), 9)]
	unit.radius = 1
	unit.asset_name = "3x3_bone_shambler"
	unit.name = "Bone Colossus"
	return unit

def GiantMassOfEyes():
	unit = FloatingEye()
	unit.max_hp = 1009
	unit.shields = 8
	unit.radius = 1

	unit.name = "Giant Mass of Eyes"
	unit.asset_name = "3x3_mass_of_eyes"

	unit.spells[0].radius = 3
	unit.spells[0].damage = 9

	unit.buffs.append(SpawnOnDeath(FloatingEyeMass, 9))
	return unit

def GiantNightmareTurtle():
	unit = Unit()
	unit.radius = 1
	unit.asset_name = '3x3_nightmare_turtle'
	unit.name = "Giant Nightmare Turtle"
	unit.max_hp = 12491

	unit.resists[Tags.Dark] = 75
	unit.resists[Tags.Arcane] = 50
	unit.resists[Tags.Physical] = 25

	aura = DamageAuraBuff(damage=2, damage_type=[Tags.Arcane, Tags.Dark], radius=10)
	aura.name = "Nightmare Aura"
	unit.buffs.append(aura)

	unit.buffs.append(UnlockAchievementOnDeathBuff("NIGHTMARE_TURTLE"))

	unit.spells.append(SimpleMeleeAttack(damage=40))
	unit.tags = [Tags.Dark, Tags.Nature, Tags.Arcane, Tags.Demon]
	return unit

def GiantGorgon():
	unit = GreyGorgon()
	unit.radius = 1
	unit.asset_name = "3x3_gorgon"
	unit.name = "Giant Gorgon"

	unit.max_hp = 3972

	unit.spells[0].range = 7
	unit.spells[0].angle = math.pi / 8.0
	unit.spells[0].duration = 3
	unit.spells[1].damage = 38

	return unit

def InfernoKing():
	unit = Unit()

	unit.radius = 1
	unit.asset_name = "3x3_inferno_king"
	unit.name = "Infernal Demon Prince"

	unit.max_hp = 6666

	unit.resists[Tags.Fire] = 100
	unit.resists[Tags.Dark] = 100
	unit.resists[Tags.Ice] = -50

	fiendsummon = SimpleSummon(spawn_func=FireFiend, num_summons=3, cool_down=12)
	fiendsummon.name = "Infernal Court"

	deathgaze = SimpleRangedAttack(damage=70, range=8, beam=True, damage_type=Tags.Dark)
	deathgaze.cool_down = 6

	breath = FireBreath()
	breath.cool_down = 0
	breath.damage = 26
	breath.range = 8

	unit.spells = [fiendsummon, deathgaze, breath]

	unit.tags = [Tags.Fire, Tags.Demon]

	return unit

def giant_mind_devo_proc(caster, target):
	caster.add_shields(1)
	possible_spells = [s for s in target.spells if s.cur_charges > 0]
	if possible_spells:
		spell = random.choice(possible_spells)
		spell.cur_charges = spell.cur_charges - 1

class MultiTentacle(Spell):

	def on_init(self):
		self.name = "Tentacles"
		self.description = "Pulls in up to 4 enemies"
		self.damage = 4
		self.num_targets = 4
		self.range = 6
		self.damage_type = Tags.Physical
		self.pull_squares = 1

	def cast(self, x, y):

		targets = [u for u in self.caster.level.get_units_in_los(self.caster) if are_hostile(self.caster, u) and distance(u, self.caster) <= self.get_stat('range')]
		random.shuffle(targets)

		damage = self.get_stat('damage')
		for t in targets[:self.get_stat('num_targets')]:
			path = self.caster.level.get_points_in_line(self.caster, t)
			for p in path[1:-1]: self.caster.level.flash(p.x, p.y, Tags.Tongue.color)
			pull(t, self.caster, self.pull_squares)
			t.deal_damage(damage, self.damage_type, self)
			yield

class InsanityAura(DamageAuraBuff):

	def __init__(self):
		DamageAuraBuff.__init__(self, damage=3, radius=1, damage_type=Tags.Arcane)
		self.name = "Insanity Aura"
		self.radius = 5
		self.damage_type = Tags.Arcane

	def get_tooltip(self):
		return "Enemies within 5 tiles take 3 arcane damage and lose 3 random spell charges each turn."

	def on_hit(self, unit):
		if not unit.is_player_controlled: return # monsters don't have spell charges, save time
		for _ in range(3): drain_spell_charges(self.owner, unit)

def GiantMindDevourer():
	unit = Unit()
	unit.name = "Ultimate Mind Devourer"
	unit.asset_name = "3x3_mind_devourer"
	unit.radius = 1

	unit.shields = 16
	unit.max_hp = 4375

	pull = MultiTentacle()

	unit.spells.append(pull)

	unit.buffs.append(InsanityAura())

	unit.tags = [Tags.Arcane, Tags.Living]
	unit.resists[Tags.Arcane] = 100

	return unit

def GiantSackOfFilth():
	unit = Unit()
	unit.name = "Giant Sack of Filth"
	unit.asset_name = "3x3_sack_of_filth"
	unit.radius = 1

	unit.max_hp = 1987

	unit.spells.append(SimpleSummon(FlyCloud, num_summons=6, cool_down=9))
	unit.spells.append(SimpleRangedAttack(damage=9, range=5, damage_type=Tags.Poison, radius=2, buff=Poison, buff_duration=4, cool_down=5))
	unit.spells.append(SimpleRangedAttack(damage=4, range=12, damage_type=Tags.Dark))

	unit.buffs.append(SpawnOnDeath(BagOfBugs, 9))
	unit.buffs.append(GeneratorBuff(FlyCloud, .5))

	unit.tags = [Tags.Dark, Tags.Construct]

	unit.resists[Tags.Dark] = 50
	unit.resists[Tags.Physical] = 25
	unit.resists[Tags.Fire] = -100

	return unit

def GreaterLamasu():
	unit = Unit()
	unit.name = "Lamasu Methuselah"

	unit.radius = 1
	unit.asset_name = '3x3_lamasu'

	unit.max_hp = 3044
	unit.shields = 6

	unit.resists[Tags.Physical] = 50
	unit.resists[Tags.Arcane] = 50
	unit.resists[Tags.Dark] = 50
	unit.resists[Tags.Holy] = 75

	unit.flying = True


	unit.spells.append(SimpleRangedAttack(damage=13, range=9, damage_type=Tags.Holy, cool_down=2))
	unit.spells.append(SimpleMeleeAttack(damage=17))
	unit.buffs.append(HealAuraBuff(heal=11, radius=13))

	unit.tags = [Tags.Nature, Tags.Living, Tags.Holy]

	return unit

class ShapedSpell(Spell):

	def __init__(self, name="Shaped Spell", damage=1, damage_type=Tags.Dark, melt_walls=True, points=None):
		self.points = points
		self.damage = damage
		Spell.__init__(self)
		self.range = 0
		self.can_target_self = True
		self.name = name
		self.damage_type = damage_type
		self.melt_walls = melt_walls
		self.cool_down = 2

	def get_ai_target(self):
		return self.owner

	def can_threaten(self, x, y):
		return (x, y) in self.points

	def cast(self, x, y):
		c = self.caster
		lvl = c.level
		d = self.get_stat('damage')
		dt = self.damage_type
		m = self.melt_walls
		for px, py in self.points:
			u = lvl.get_unit_at(px, py)
			if u and are_hostile(c, u): lvl.deal_damage(px, py, d, dt, self)
			else: lvl.show_effect(px, py, dt) # don't harm allies
			if m and lvl.tiles[px][py].is_wall(): lvl.make_floor(px, py)
		yield

class PumpkingsHarvestBuff(Buff):

	def on_init(self):
		self.name = "Pumpking's Harvest"
		self.description = "When a unit dies, heal [5 HP:heal]"
		self.global_triggers[EventOnDeath] = self.on_death

	def on_death(self, evt):
		self.owner.heal(5, self)

class SwarmSummon(Spell):

	def __init__(self, summon_fn, effect_tag=Tags.Poison):
		self.summon_fn = summon_fn
		self.summon_name = summon_fn().name
		self.effect_tag = effect_tag
		Spell.__init__(self)
		self.extra_unit_tt_fns = [(self.summon_fn, False)]

	def on_init(self):
		self.name = "%s Swarm Summon" % self.summon_name
		self.range = 0
		self.cool_down = 3
		self.tt_color = self.effect_tag.color

	def get_ai_target(self):
		return self.owner

	def can_threaten(self, x, y):
		return False

	def get_description(self):
		return ("Summon a {creature} near every enemy", {"creature":self.summon_name})

	def cast(self, x, y):
		c = self.caster
		lvl = c.level
		for u in list(lvl.units):
			if are_hostile(c, u):
				lvl.show_path_effect(c, u, self.effect_tag, minor=True)
				self.summon(self.summon_fn(), u, 2)
				yield


def TheGreatPumpking():
	u = Unit()
	u.radius = 1
	u.name = "The Great Pumpking"
	u.asset_name = 'the_great_pumpkin'
	u.max_hp = 1031
	u.tags = [Tags.Nature, Tags.Dark]
	u.resists[Tags.Fire] = 75
	u.resists[Tags.Dark] = 75
	u.resists[Tags.Holy] = -50

	smile =   [
      (4, 3), (13, 3),
      (3, 4), (4, 4), (5, 4), (12, 4), (13, 4), (14, 4),
      (2, 5), (3, 5), (4, 5), (5, 5), (6, 5), (11, 5), (12, 5), (13, 5), (14, 5), (15, 5),
      (8, 8),
      (7, 9), (8, 9), (9, 9),
	  (6, 10), (7, 10), (8, 10), (9, 10), (10, 10),
	  (1, 13), (2, 13), (3, 13), (7, 13), (8, 13), (9, 13), (10, 13), (14, 13), (15, 13), (16, 13),
      (2, 14), (3, 14), (4, 14), (7, 14), (8, 14), (9, 14), (10, 14), (13, 14), (14, 14), (15, 14),
      (2, 15), (3, 15), (4, 15), (5, 15), (6, 15), (7, 15), (8, 15), (9, 15), (10, 15), (11, 15), (12, 15), (13, 15), (14, 15), (15, 15),
      (3, 16), (4, 16), (5, 16), (6, 16), (7, 16), (8, 16), (9, 16), (10, 16), (11, 16), (12, 16), (13, 16), (14, 16)]

	s = ShapedSpell(name="Pumpking's Smile", damage=31, damage_type=Tags.Fire, points=smile)
	def smile_def(): return "Damages enemies in the smile\nCasts as often as possible"
	s.get_description = smile_def
	summon = SwarmSummon(Vine)
	u.spells = [s, summon]

	u.buffs = [PumpkingsHarvestBuff(), UnlockAchievementOnDeathBuff("PUMPKING")]

	return u

class ChainedCyclopsBuff(Buff):

	def on_init(self):
		self.name = "Chained"
		self.description = "When this unit first falls below half HP, it breaks its shackles and goes [berserk]"
		self.owner_triggers[EventOnDamaged] = self.on_damaged

	def on_damaged(self, evt):
		o = self.owner
		if o.cur_hp > o.max_hp // 2: return
		o.apply_buff(BerserkBuff())
		if o.asset_name == 'chained_cyclops': o.asset_name = 'unchained_cyclops'
		o.clear_anim('Anim')
		o.remove_buff(self)

def ChainedCyclops():
	u = Unit()
	u.radius = 1
	u.name = "Chained Cyclops"
	u.asset_name = 'chained_cyclops'
	u.asset_variants = [(['char', 'unchained_cyclops'], u.radius)]
	u.max_hp = 2000
	u.tags = [Tags.Living]

	melee = SimpleMeleeAttack(damage=30)
	ranged = SimpleRangedAttack(name="Boulder Toss", damage=30, range=6, radius=2, cool_down=7, buff=Stun, buff_duration=1, proj_name='boulder')

	u.spells = [melee, ranged]
	u.buffs = [ChainedCyclopsBuff()]

	return u

class PurityProtection(Spell):

	def on_init(self):
		self.name = "Protection of Purity"
		self.duration = 8
		self.cool_down = 12
		self.range = 0
		self.target_allies = True

	def get_description(self):
		return "Caster and allies gain 50% [Fire] and [Holy] resist for {duration} turns"

	def cast(self, x, y):
		dtypes = [Tags.Fire, Tags.Holy]
		for u in self.caster.level.units:
			if not are_hostile(u, self.caster):
				for dtype in dtypes:
					u.apply_buff(ResistBuff(dtype, 50), self.get_stat('duration'))
					yield

class HaetaeJusticeBuff(Buff):

	def on_init(self):
		self.name = "Guardian of Righteousness"
		self.description = "When an ally dies, attempt to teleport closer to the killer"
		self.global_triggers[EventOnDeath] = self.on_death

	def on_death(self, evt):
		if are_hostile(evt.unit, self.owner): return
		if not (evt.damage_event and evt.damage_event.source and evt.damage_event.source.owner): return
		self.owner.level.queue_spell(self.do_teleport(self.owner, evt.damage_event.source.owner))

	def do_teleport(self, o, u):
		lvl = o.level
		cur_dist = distance(o, u)
		for p in o.iter_occupied_points(): lvl.show_effect(p.x, p.y, Tags.Translocation)
		yield

		pts = [p for p in lvl.get_points_in_ball(u.x, u.y, radius=6) if lvl.can_move(o, p.x, p.y, teleport=True)]
		if not pts: return
		best = min(pts, key=lambda pt: distance(pt, u))
		if distance(best, u) >= cur_dist: return
		yield lvl.act_move(o, best.x, best.y, teleport=True)
		for p in o.iter_occupied_points(): lvl.show_effect(p.x, p.y, Tags.Translocation)



def HaetaeGolem():
	u = Unit()
	u.radius = 1
	u.name = "Haetae Golem"
	u.asset_name = "stone_haetae"
	u.max_hp = 1395
	u.tags = [Tags.Construct, Tags.Holy, Tags.Living]
	u.resists[Tags.Poison] = 100
	u.resists[Tags.Fire] = 50
	u.resists[Tags.Physical] = 50
	u.resists[Tags.Lightning] = 50
	u.resists[Tags.Holy] = 50

	protection = PurityProtection()
	bite = SimpleMeleeAttack(18)
	bite.name = "Bite"
	u.spells = [protection, bite]

	justice = HaetaeJusticeBuff()
	regen = ShieldRegenBuff(20, 3)

	u.burrowing = True
	u.buffs = [justice, regen, UnlockAchievementOnDeathBuff("HAETAE")]
	return u


class MoonCrownBuff(DamageAuraBuff):

	def __init__(self):
		DamageAuraBuff.__init__(self, custom_name="Moon Crown", damage=2, damage_type=[Tags.Holy, Tags.Arcane], radius=5)

	def on_init(self):
		self.resists[Tags.Holy] = 100
		self.resists[Tags.Arcane] = 100

class MoonBurst(SimpleBurst):

	def __init__(self):
		SimpleBurst.__init__(self, damage=8, radius=4, damage_type=Tags.Arcane)
		self.name = "Moon Burst"
		self.cool_down = 10
		self.range = 0

	def get_description(self):
		return ("Deals damage to enemies in a burst around the caster\n"
				"Units within 4 tiles are randomly teleported")

	def get_ai_target(self):
		return self.caster

	def get_impacted_tiles(self, x, y):
		for stage in Burst(self.caster.level, Point(x, y), self.get_stat('radius'), ignore_walls=self.ignore_walls or not self.get_stat('requires_los')):
			for p in stage:
				yield p

	def cast_instant(self, x, y):
		caster = self.caster
		level = caster.level
		getu = level.get_unit_at
		deal_damage = level.deal_damage

		damage = self.get_stat('damage')

		for p in self.get_impacted_tiles(x, y):
			u = getu(p.x, p.y)
			if not u: deal_damage(p.x, p.y, damage, Tags.Arcane, self); continue
			if are_hostile(caster, u): deal_damage(p.x, p.y, damage, Tags.Arcane, self)
			randomly_teleport(u, 20)

def MoonMage():
	unit = Unit()
	unit.name = "Moon Mage"
	unit.asset_name = 'moon_mage'

	unit.tags = [Tags.Holy, Tags.Arcane]

	unit.max_hp = 75
	unit.shields = 5

	unit.resists[Tags.Arcane] = 100
	unit.resists[Tags.Holy] = 100

	moon_beam = SimpleRangedAttack(damage=6, range=7, damage_type=[Tags.Holy, Tags.Arcane], beam=True, melt=True)
	moon_beam.name = "Moon Beam"

	moon_crown = SimpleCurse(MoonCrownBuff, 30)
	moon_crown.name = "Lunar Coronation"
	moon_crown.description = "Apply Moon Crown to an ally for 30 turns"
	moon_crown.cool_down = 8
	add_tooltip(unit, MoonCrownBuff())

	lamasu_pet = SimpleSummon(Lamasu, cool_down=10, duration=5)
	lamasu_pet.name = "Lunar Steed"


	unit.spells = [MoonBurst(), lamasu_pet, moon_crown, moon_beam]
	unit.is_wizard = True
	return unit

class SolarCrownBuff(DamageAuraBuff):

	def __init__(self):
		DamageAuraBuff.__init__(self, custom_name="Solar Crown", damage=2, damage_type=[Tags.Holy, Tags.Fire], radius=5)
		self.resists[Tags.Holy] = 100
		self.resists[Tags.Fire] = 100

def SunMage():
	u = Unit()
	u.name = "Sun Mage"
	u.asset_name = 'sun_king'
	u.tags = [Tags.Holy, Tags.Fire]
	u.max_hp = 365

	beam = SimpleRangedAttack(name="Sun Beam", damage=28, range=6, damage_type=[Tags.Holy, Tags.Fire], beam=True, melt=True)

	solar_crown = SimpleCurse(SolarCrownBuff, 30, effect=Tags.Holy)
	solar_crown.name = "Solar Coronation"
	solar_crown.description = "Apply Solar Crown to an ally for 30 turns"
	solar_crown.cool_down = 8

	regen_aura = HealAuraBuff(heal=2, radius=5, heal_self=True)
	regen_aura.name = "Healing Aura"

	u.spells = [solar_crown, beam]
	u.buffs = [SolarCrownBuff(), regen_aura]
	u.resists[Tags.Physical] = 75
	u.is_wizard = True
	add_tooltip(u, SolarCrownBuff())
	return u

class NightmareToadDefense(Buff):

	def on_init(self):
		self.description = "When damaged, [stun] the source for 2 turns"
		self.owner_triggers[EventOnDamaged] = self.on_damage

	def on_damage(self, evt):
		if evt.source.owner and are_hostile(self.owner, evt.source.owner):
			evt.source.owner.apply_buff(Stun(), 2)
			self.owner.level.show_path_effect(self.owner, evt.source.owner, Tags.Arcane, minor=True)

def ToadNightmareSorcerer():

	unit = HornedToad()
	unit.max_hp = 109
	unit.name = "Shru the Toad Sorcerer"
	unit.asset_name = "horned_toad_mage_nightmare"

	nightmare = WizardNightmare()

	pnova = SimpleBurst(damage=5, damage_type=Tags.Poison, radius=6)
	
	pnova.cool_down = 8
	def poison(caster, target): target.apply_buff(Poison(), 7)
	pnova.onhit = poison
	pnova.extra_desc = "\nApplies 7 turns of [poison]"

	voidbolt = SimpleRangedAttack(damage=4, damage_type=Tags.Arcane, range=16)

	unit.spells = [MonsterTeleport(), nightmare, pnova, voidbolt]
	unit.buffs = [NightmareToadDefense()]


	unit.resists[Tags.Arcane] = 75
	unit.resists[Tags.Dark] = 75

	unit.tags.append(Tags.Arcane)
	unit.tags.append(Tags.Dark)
	unit.is_wizard = True
	return unit

def MotherOfSpiders():
	unit = Unit()
	unit.radius = 1
	unit.asset_name = '3x3_spider_queen'
	unit.name = "Mother of Spiders"

	unit.max_hp = 1284
	unit.tags = [Tags.Spider, Tags.Living, Tags.Nature]

	bite = SimpleMeleeAttack(20, buff=Poison, buff_duration=50)

	unit.spells = [bite]
	unit.buffs = [SpiderBuff(), GeneratorBuff(spawn_func=GiantSpiderQueen, spawn_chance=.1), GeneratorBuff(spawn_func=GiantSpider, spawn_chance=.5)]

	return unit

def OssuarySpider():
	u = Unit()
	u.radius = 1
	u.asset_name = 'arachnid_abomination'
	u.name = "Ossuary Spider"
	u.max_hp = 2568
	u.tags = [Tags.Spider, Tags.Undead, Tags.Nature]
	u.spells = [SimpleSummon(BoneShambler, num_summons=3, cool_down=8), SimpleMeleeAttack(damage=20, buff=NecrosisBuff, buff_duration=50)]
	u.buffs = [DamageAuraBuff(3, [Tags.Poison, Tags.Dark], 6, "Rotting Aura"), SpiderBuff()]
	u.resists[Tags.Poison] = 100
	return u

class BadBalloonBuff(Buff):

	def on_init(self):
		self.name = "Suicide Explosion"
		self.radius = 2
		self.damage = 10
		self.duration = 3

	def on_applied(self, owner):
		self.owner_triggers[EventOnDeath] = self.on_death

	def on_death(self, death_event):
		self.owner.level.queue_spell(self.explode(self.owner.level, self.owner.x, self.owner.y))

	def explode(self, level, x, y):
		for stage in Burst(level, self.owner, self.radius):
			for point in stage:
				dealt = level.deal_damage(point.x, point.y, self.damage, Tags.Arcane, self)
				u = level.get_unit_at(point.x, point.y)
				if u and dealt: u.apply_buff(FearBuff(), self.duration)
		yield


class BadBalloonSuicide(Spell):

	def on_init(self):
		self.range = 2
		self.name = "Suicide Explosion"
		self.damage = 10
		self.damage_type = Tags.Arcane
		self.description = "Suicide attack\n2 tile radius\nAutocast on death\nInflicts [fear] on damaged units for 3 turns"

	def cast(self, x, y):
		self.caster.kill()
		yield

def BadBalloon():
	u = Unit()
	u.name = "Bad Balloon"
	u.asset_name = 'balloon'
	u.max_hp = 1
	u.tags = [Tags.Arcane]
	u.resists[Tags.Arcane] = 100
	u.spells = [BadBalloonSuicide()]
	u.buffs = [BadBalloonBuff(), QuickmoveBuff()]
	return u


def Doldrum():
	u = Unit()
	u.name = "Doldrum"
	u.asset_name = "cosmic_clown"
	u.max_hp = 999
	u.tags = [Tags.Arcane, Tags.Demon]
	u.resists[Tags.Arcane] = 100
	u.spells = [SimpleSummon(BadBalloon, num_summons=1, radius=1)]
	u.buffs = [TeleportyBuff(radius=10, chance=.5)]
	return u

class BoilingBuff(Buff):

	def on_init(self):
		self.name = 'Boiling'
		self.description = "While Steam Breath is on cooldown, this unit is immobilized\n\nTaking [Lightning] damage reduces Steam Breath cooldown by 1"
		self.owner_triggers[EventOnSpellCast] = self.on_cast
		self.owner_triggers[EventOnDamaged] = self.on_damaged

	def on_damaged(self, evt):
		if evt.damage_type is not Tags.Lightning: return
		s = self.owner.get_spell(SteamBreath)
		if not s: return
		if self.owner.cool_downs.get(s, 0) >= 1: self.owner.cool_downs[s] -= 1

	def on_cast(self, evt):
		if isinstance(evt.spell, SteamBreath):
			self.owner.apply_buff(ImmobilizeBuff())

	def on_advance(self):
		s = self.owner.get_spell(SteamBreath)
		if not s: return
		if self.owner.cool_downs.get(s, 0) != 0: return
		self.owner.remove_buffs(ImmobilizeBuff)

class SteamBreath(BreathWeapon):

	def on_init(self):
		self.name = "Steam Breath"
		self.damage = 22
		self.duration = 3
		self.damage_type = Tags.Fire

	def get_description(self):
		return ("Cone attack\n"
				"Inflicts soaked and [blind] for [{duration}:duration] turns")

	def per_square_effect(self, x, y, damage):
		self.caster.level.deal_damage(x, y, damage, Tags.Fire, self)
		u = self.caster.level.get_unit_at(x, y)
		if u:
			dur = self.get_stat('duration')
			u.apply_buff(SoakedBuff(), dur)
			u.apply_buff(BlindBuff(), dur)


def KettleMan():
	u = Unit()
	u.name = "Kettle Man"
	u.asset_name = 'kettle_man'
	u.max_hp = 212
	u.tags = [Tags.Metallic, Tags.Construct, Tags.Fire]
	u.resists[Tags.Lightning] = 75

	breath = SteamBreath()
	breath.range = 6
	breath.cool_down = 10

	u.spells = [breath]
	u.buffs = [BoilingBuff()]
	return u


class FortressShot(Spell):

	def __init__(self, shot):
		self.shot = shot
		Spell.__init__(self)

	def on_init(self):
		self.name = self.shot.name + " Barrage"
		self.description = "Each fortress tile shoots a target in range of that tile"
		self.range = self.shot.range
		self.damage = self.shot.damage
		self.damage_type = self.shot.damage_type
		self.cool_down = self.shot.cool_down

	def get_cast_point_target(self, cp):
		targets = []
		caster = self.caster
		lvl = caster.level

		for u in lvl.units:
			if not are_hostile(caster, u): continue
			if not u.is_alive(): continue
			if self.owner.is_blind() and max(abs(cp.x - u.x), abs(cp.y - u.y)) > 1: continue
			if distance(cp, u) > (self.range - 1): continue
			if not self.caster.level.can_see(cp.x, cp.y, u.x, u.y): continue
			if not self.can_harm(u): continue
			targets.append(u)

		if not targets: return None
		return random.choice(targets)

	def cast(self, x, y):
		cast_points = [p for p in self.caster.level.get_points_in_ball(self.caster.x, self.caster.y, 1, diag=True)]
		random.shuffle(cast_points)
		for cp in cast_points:
			target = self.get_cast_point_target(cp)  # grab a new legal target for each bolt.
			if target: yield from self.cast_bolt(cp, target)

	def cast_bolt(self, cp, target):
		start = cp
		end = target

		for point in Bolt(self.caster.level, start, end, find_clear=True):
			self.caster.level.projectile_effect(point.x, point.y, proj_name=self.shot.proj_name, proj_origin=start, proj_dest=end)
			yield

		target_u = self.caster.level.get_unit_at(target.x, target.y)
		if target_u and target_u.is_alive():
			target_u.deal_damage(self.get_stat('damage'), self.shot.damage_type, self)
			if hasattr(self.shot, 'onhit') and self.shot.onhit: self.shot.onhit(self.caster, target_u)
			yield

class FortressBuild(Spell):

	def __init__(self, spawner, cool_down=0, build_count=1):
		Spell.__init__(self)
		self.spawner = spawner
		self.cool_down = cool_down
		self.build_count = build_count

	def on_init(self):
		self.name = "Expand Fortress"
		self.range = 0
		self.max_charges = 0

	def get_description(self):
		if self.build_count > 1: return ("Build {count} {spawn} spawners on connected tiles", {'count': self.build_count, 'spawn': self.spawner().name})
		else: return ("Build a {spawn} spawner on connected tile", {'spawn': self.spawner().name})

	def cast(self, x, y):
		created = 0
		city = self.get_city()
		while created < self.build_count:
			placed = False
			random.shuffle(city)
			for u in city:
				adj = list(self.caster.level.get_adjacent_points(u, filter_walkable=True, check_unit=True, r=u.radius))
				if not adj: continue
				random.shuffle(adj)
				for p in adj:
					lair = MonsterSpawner(self.spawner)
					self.summon(lair, Point(p.x, p.y), radius=0)
					created += 1
					placed = True
					yield

					city.append(lair)
					if created == self.build_count: break
				if created == self.build_count: break

			if not placed: break # couldn't build

	def get_city(self):
		candidates = {self.caster}
		unit_group = set()

		while candidates:
			unit = candidates.pop()
			if unit in unit_group: continue
			if unit.tags: continue
			unit_group.add(unit)
			for p in self.caster.level.get_adjacent_points(Point(unit.x, unit.y), filter_walkable=True, r=unit.radius):
				adj_unit = self.caster.level.get_unit_at(p.x, p.y)
				if adj_unit and adj_unit not in unit_group: candidates.add(adj_unit)

		return list(unit_group)


def DuergarFortress():
	u = Unit()
	u.radius = 1
	u.name = "Duergar Fortress"

	u.max_hp = 2000
	u.stationary = True

	summon_fort = FortressBuild(Dwarf, cool_down=7, build_count=7)

	duergar_shot = SimpleRangedAttack(damage=8, range=10, damage_type=Tags.Physical, proj_name="duergar_bolt")
	duergar_shot.name = "Crossbow"
	duergar_shot.caster = u
	shot = FortressShot(duergar_shot)

	u.spells = [shot, summon_fort]

	u.buffs.append(SpawnOnDeath(Dwarf, 9))
	return u

def GnomeCastle():
	u = Unit()
	u.radius = 1
	u.name = "Gnome Castle"

	u.max_hp = 1200
	u.stationary = True

	summon_fort = FortressBuild(Gnome, cool_down=0, build_count=1)

	def summon_thorn(caster, target):
		thorn = FaeThorn()
		p = caster.level.get_summon_point(target.x, target.y, target.radius + 1, diag=True)
		if p: caster.level.summon(caster, thorn, p)

	attack = SimpleRangedAttack(damage=1, range=8, damage_type=Tags.Physical, onhit=summon_thorn)
	attack.description = "Summons a fae thorn adjacent to the target"
	attack.name = 'Thorn Bolt'
	shot = FortressShot(attack)
	shot.add_unit_tooltip(FaeThorn)

	u.spells = [shot, summon_fort]

	u.buffs.append(SpawnOnDeath(GnomeDonsy, 1))
	u.buffs.append(SpawnOnDeath(Gnome, 8))
	return u

def KoboldCamp():
	u = Unit()
	u.radius = 1
	u.name = "Kobold Camp"

	u.max_hp = 600
	u.stationary = True

	summon_fort = FortressBuild(Kobold, cool_down=3, build_count=3)

	bow = SimpleRangedAttack(damage=1, range=10, proj_name="kobold_arrow")
	bow.name = "Arrow"
	shot = FortressShot(bow)

	u.spells = [shot, summon_fort]

	u.buffs.append(SpawnOnDeath(KoboldHedgeMage, 1))
	u.buffs.append(SpawnOnDeath(Kobold, 8))
	return u

def GoblinCave():
	u = Unit()
	u.radius = 1
	u.name = "Goblin Cave"

	u.max_hp = 500
	u.stationary = True

	summon_fort = FortressBuild(Goblin, build_count=1)

	rock = SimpleRangedAttack(damage=3, range=5)
	rock.name = "Rock"
	shot = FortressShot(rock)

	u.spells = [shot, summon_fort]

	u.buffs.append(SpawnOnDeath(GoblinShaman, 1))
	u.buffs.append(SpawnOnDeath(Goblin, 8))

	return u

def SkullHornetQueen():
	u = Unit()
	u.radius = 1
	u.name = "Skull Hornet Queen"
	u.asset_name = '3x3_skull_hornet_queen'
	u.max_hp = 300
	u.tags = [Tags.Nature, Tags.Undead]
	u.flying = True

	u.spells = [SimpleMeleeAttack(damage=6, buff=NecrosisBuff, buff_duration=6, attacks=3)]
	u.buffs = [SummonReinforcements(SkullHornet, 12, 75, Tags.Poison), QuickmoveBuff(), UnlockAchievementOnDeathBuff("SKULL_QUEEN")]

	return u

def SkullHornetHive():
	u = Unit()
	u.radius = 1
	u.name = "Skull Hornet Hive"
	u.asset_name = '3x3_skull_hornet_hive'
	u.asset_variants = [(['char', '3x3_skull_hornet_queen'], u.radius)]

	u.max_hp = 400
	u.stationary = True

	hgen = GeneratorBuff(Hornet, .75, num_summons=3)

	skull_reinforcements = SummonReinforcements(SkullHornet, 12, 75, Tags.Poison)
	queen_spawn = RespawnAs(SkullHornetQueen)

	u.resists[Tags.Fire] = -50
	u.resists[Tags.Ice] = -50

	u.buffs = [hgen, skull_reinforcements, queen_spawn]

	return u


class CoralSpew(BreathWeapon):

	def on_init(self):
		self.name = "Coral Spew"
		self.damage = 12

	def get_description(self):
		return ("Cone attack\n"
				"Summon Freezing Coral around affected units")

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		damage = self.get_stat('damage')
		deal_damage = level.deal_damage
		getline = level.get_points_in_line
		proj = level.projectile_effect
		for stage in self.aoe(x, y):
			for point in stage:
				if level.tiles[point.x][point.y].unit == caster: continue
				unit = level.get_unit_at(point.x, point.y)
				if not unit or unit == caster: continue
				for p in getline(caster, point)[1:]:
					proj(p.x, p.y, proj_name='ice_bolt', proj_origin=caster, proj_dest=point, proj_duration=1)
					yield
				deal_damage(point.x, point.y, damage, Tags.Physical, self)
				deal_damage(point.x, point.y, damage, Tags.Ice, self)
				for pt in level.get_adjacent_points(unit, True, True, unit.radius): self.summon(FreezingCoral(), pt, radius=0)
			yield


class CrabMoltingBuff(Buff):

	def on_init(self):
		self.name = "Regenerative Molt"
		self.buff_type = BUFF_TYPE_PASSIVE
		self.description = "Each turn, if at or below 50% HP, cleanse all debuffs, then halve max HP and heal to full"

	def on_advance(self):
		if self.owner.cur_hp > (self.owner.max_hp // 2): return
		if not self.owner.is_alive(): return
		curses = [b for b in self.owner.buffs if b.buff_type == BUFF_TYPE_CURSE]
		for b in curses: self.owner.remove_buff(b)
		self.owner.max_hp = self.owner.max_hp // 2
		self.owner.cur_hp = self.owner.max_hp


def CoralColossus():
	u = Unit()
	u.radius = 1
	u.name = "Coral Colossus"
	u.asset_name = 'giant_coral_crab'
	u.max_hp = 3884
	u.tags = [Tags.Living, Tags.Nature, Tags.Ice]
	u.resists[Tags.Physical] = 75
	u.resists[Tags.Ice] = 100

	melee = SimpleMeleeAttack(damage=40, buff=ImmobilizeBuff, buff_duration=3, attacks=2)
	melee.name = "Crushing Claws"

	spew = CoralSpew()
	spew.damage_type = [Tags.Physical, Tags.Ice]
	spew.range = 8
	spew.cool_down = 6
	spew.add_unit_tooltip(FreezingCoral)

	u.spells = [spew, melee]
	u.buffs = [CrabMoltingBuff()]

	return u

class LavaBeam(WideBeam):

	def __init__(self):
		WideBeam.__init__(self, name="Lava Beam", damage=80, damage_type=Tags.Fire, requires_los=False)
		self.cool_down = 5

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		dmg = self.get_stat('damage')

		if self.requires_los: center_beam = level.get_points_in_line(caster, Point(x, y), find_clear=True)[1+caster.radius:]
		else: center_beam = level.get_points_in_line(caster, Point(x, y), find_clear=False)[1+caster.radius:]
		outer_beam = []

		for p in center_beam:
			for q in level.get_points_in_ball(p.x, p.y, self.beam_radius): # grab the points around the centerbeam
				if level.get_unit_at(q.x, q.y) == caster: continue # dont let caster hurt themselves
				if (q not in center_beam) and (q not in outer_beam): outer_beam.append(q) # don't include already captured pts

		wide_beam = center_beam + outer_beam

		for p in wide_beam:
			level.deal_damage(p.x, p.y, dmg, self.damage_type, self)
			if not self.requires_los and not level.tiles[p.x][p.y].can_see: level.make_floor(p.x, p.y)

		yield

		level.set_group_tileset(wide_beam, 'volcano', 'lava')
		yield

class LavaBurst(SimpleBurst):

	def __init__(self):
		SimpleBurst.__init__(self, damage=25, radius=4, damage_type=Tags.Fire, cool_down=3, ignore_walls=True)

	def get_description(self):
		return "Burst around the caster\nDestroy walls"

	def get_impacted_tiles(self, x, y):
		for stage in Burst(self.caster.level, Point(x, y), self.get_stat('radius'), ignore_walls=self.ignore_walls or not self.get_stat('requires_los')):
			for p in stage:
				yield p

	def can_threaten(self, x, y):
		if distance(self.caster, Point(x, y)) > self.radius: return False
		return True

	def cast_instant(self, x, y):
		caster = self.caster
		level = caster.level
		caster_tiles = set(caster.iter_occupied_points())

		damage = self.get_stat('damage')
		tiles = [p for p in self.get_impacted_tiles(x, y)]
		for p in tiles:
			if p in caster_tiles: continue
			level.deal_damage(p.x, p.y, damage, Tags.Fire, self)

		level.set_group_tileset(tiles, 'volcano', 'lava')


def MoltenDevourer():
	u = Unit()
	u.radius = 1
	u.name = "Molten Devourer"
	u.max_hp = 7007
	u.tags = [Tags.Metallic, Tags.Fire, Tags.Demon]
	u.resists[Tags.Fire] = 100
	u.resists[Tags.Physical] = 75
	u.burrowing = True
	u.shrink_text = 1

	beam = LavaBeam()
	burst = LavaBurst()
	gore = SimpleMeleeAttack(damage=50, buff=HemorrhageBuff, buff_duration=15, attacks=3)

	u.spells = [beam, burst, gore]
	u.buffs = [DamageAuraBuff(damage=16, damage_type=Tags.Fire, radius=7), UnlockAchievementOnDeathBuff("MOLTEN_DEVOURER")]
	add_tooltip(u, HemorrhageBuff())
	return u

def Trollet():
	unit = Troll()
	unit.name = "Trollet"
	unit.asset_name = 'troll_child'
	unit.max_hp = 10
	unit.is_coward = True
	unit.buffs.append(MatureInto(Troll, 3)) # mature into not passing on minion buffs?
	return unit

def Gryla():
	u = Unit()
	u.name = "Gryla"
	u.radius = 1
	u.max_hp = 1200
	u.tags = [Tags.Living]

	u.resists[Tags.Physical] = 50

	curse = SimpleCurse(buff=SharedPainBuff, buff_duration=0, effect=Tags.Dark)
	curse.cool_down = 2
	curse.name = "Suffering"
	curse.description = "Inflict [Shared Pain:blood] on an enemy"
	add_tooltip(u, SharedPainBuff())

	regen = SimpleCurse(TrollRegenBuff, buff_duration=0, effect=Tags.Nature)
	regen.name = "Trollify"
	regen.description = "Grant an ally Troll Regeneration"
	add_tooltip(u, TrollRegenBuff())

	u.spells = [curse, regen, SimpleRangedAttack(damage=10, damage_type=Tags.Poison, range=5, buff=Poison, buff_duration=3)]
	u.buffs = [TrollRegenBuff(), GeneratorBuff(Trollet, .2)]
	return u

class FaeBlessingBuff(Buff):

	def on_init(self):
		self.name = "Fae Blessing"
		self.description = "Each turn, gain [1 SH:shields] and remove 1 debuff"
		self.stack_type = STACK_DURATION
		self.color = Tags.Arcane.color

	def on_advance(self):
		self.owner.add_shields(1)
		debuffs = [b for b in self.owner.buffs if b.buff_type == BUFF_TYPE_CURSE]
		if not debuffs: return
		self.owner.remove_buff(random.choice(debuffs))

def GreatFaery():
	u = Unit()
	u.name = "Great Faery"
	u.tags = [Tags.Living, Tags.Nature, Tags.Arcane]
	u.max_hp = 180
	u.shields = 20
	u.flying = True
	u.resists[Tags.Arcane] = 100

	bless = SimpleCurse(FaeBlessingBuff, 12, effect=Tags.Arcane)
	bless.cool_down = 3
	bless.range = 6
	bless.name = "Fae Blessing"

	cursebolt = SimpleRangedAttack(name="Curse Bolt", damage=10, damage_type=Tags.Arcane, range=6, buff=FaeCurse, buff_duration=12)

	u.spells = [bless, cursebolt]
	u.buffs = [RegenShieldsBuff(sh=3), TeleportyBuff(radius=2, chance=.5)]

	add_tooltip(u, FaeBlessingBuff())
	add_tooltip(u, FaeCurse())

	return u

class GreatFaeryConversionBuff(Buff):

	def on_init(self):
		self.name = "Willingness"
		self.description = ("At the end of each turn, if there are no [Demons:demon] in the level, the Great Faery will ally herself with the Wizard\n\n"
							"If alive at the end of the level, the Great Faery will shrink and become your constant companion")
		self.global_triggers[EventOnLevelComplete] = self.on_complete

	def on_advance(self):
		if self.owner.team == TEAM_PLAYER: return
		if any(u for u in self.owner.level.units if Tags.Demon in u.tags): return
		self.owner.team = TEAM_PLAYER

	def on_complete(self, evt):
		for _ in self.do_transfer(): pass

	def do_transfer(self):
		p = self.owner.level.player_unit
		if not p: return
		yield from self.owner.level.show_path_effect(self.owner, p, Tags.Arcane, pause_frames=1)
		from Equipment import Companion
		p.equip(Companion(GreatFaery, [Tags.Arcane, Tags.Nature, Tags.Conjuration], {'minion_health':180, 'shields':20, 'minion_damage':10, 'minion_range':6}))

def GreatFaeryGiant():
	u = Unit()
	u.radius = 1
	u.name = "Great Faery"
	u.asset_name = '3x3_great_faery'
	u.tags = [Tags.Living, Tags.Nature, Tags.Arcane]
	u.max_hp = 18000
	u.shields = 200
	u.flying = True

	u.resists[Tags.Arcane] = 100

	bless = SimpleCurse(FaeBlessingBuff, 12, effect=Tags.Arcane)
	bless.cool_down = 3
	bless.range = 6
	bless.name = "Fae Blessing"

	cursebolt = SimpleRangedAttack(name="Curse Bolt", damage=10, damage_type=Tags.Arcane, range=6, buff=FaeCurse, buff_duration=12)

	u.spells = [bless, cursebolt]
	u.buffs = [RegenShieldsBuff(sh=30, cap=False), GreatFaeryConversionBuff()]

	add_tooltip(u, FaeBlessingBuff())
	add_tooltip(u, FaeCurse())

	return u

class SummonOnKill(Buff):

	def __init__(self, unit_fn, unit_name=None):
		Buff.__init__(self)
		self.unit_fn = unit_fn
		self.unit_name = unit_name if unit_name is not None else unit_fn().name
		self.global_triggers[EventOnDeath] = self.on_death

	def get_description(self):
		return ("On kill, summon a {unit}", {"unit":self.unit_name})

	def on_death(self, evt):
		if not evt.damage_event: return
		if evt.unit == self.owner: return # stop them from summoning when a buff they own kills them i.e. bleed
		if getattr(evt.damage_event.source, 'owner', None) != self.owner: return
		self.owner.level.queue_spell(self.do_summon(evt.unit.x, evt.unit.y))

	def do_summon(self, x, y):
		self.summon(make_minion(self, self.unit_fn), Point(x, y))
		yield

def Crackler():
	u = Unit()
	u.name = "Crackler"
	u.asset_name = 'void_crackler'
	u.tags = [Tags.Arcane, Tags.Lightning]
	u.max_hp = 9
	u.shields = 4
	u.quick_move = True
	u.resists[Tags.Lightning] = 100
	u.resists[Tags.Arcane] = 100
	u.resists[Tags.Physical] = 75
	bolt = SimpleRangedAttack(name="Crackle Bolt", damage=9, damage_type=Tags.Lightning, range=4)
	burst = SimpleBurst(damage=4, radius=9, damage_type=Tags.Arcane, cool_down=9)
	burst.name = "Void Burst"
	u.spells = [burst, bolt]
	u.buffs = [SummonOnKill(Crackler, unit_name="Crackler")]
	return u

class SlimedBuff(Buff):

	def on_init(self):
		self.name = "Slimed"
		self.color = Tags.Slime.color
		self.description = "Each turn, summon a random hostile Slime nearby"
		self.stack_type = STACK_INTENSITY
		self.buff_type = BUFF_TYPE_CURSE

	def on_advance(self):
		slime_team = TEAM_PLAYER if self.owner.team == TEAM_ENEMY else TEAM_ENEMY
		self.summon(random.choice(slime_types)(), target=self.owner, radius=2, team=slime_team)

class SlimeAdaptiveArmorBuff(Buff):

	def on_init(self):
		self.name = "Slime Armor"
		self.description = "On taking damage, changes form to become resistant to that damage type"
		self.owner_triggers[EventOnDamaged] = self.on_damaged
		self.prev_res = None
		self.cur_form = None
		self.dtypes_to_assets ={
			Tags.Poison: '3x3_rainbow_slime',
			Tags.Fire: '3x3_rainbow_slime_fire',
			Tags.Ice: '3x3_rainbow_slime_ice',
			Tags.Lightning: '3x3_rainbow_slime_lightning',
			Tags.Arcane: '3x3_rainbow_slime_arcane',
			Tags.Dark: '3x3_rainbow_slime_blood',
			Tags.Holy: '3x3_rainbow_slime_holy',
			Tags.Physical: '3x3_rainbow_slime_metallic',
		}

	def on_damaged(self, evt):
		if evt.damage <= 0: return
		form = self.dtypes_to_assets.get(evt.damage_type, None)
		if form == self.cur_form: return
		self.cur_form = form
		self.owner.asset_name = form
		self.owner.clear_anim('Anim')

		if self.prev_res: self.owner.resists[self.prev_res] -= 100
		self.owner.resists[evt.damage_type] += 100
		self.prev_res = evt.damage_type

def RainbowSlime():
	u = Unit()
	u.radius = 1
	u.name = "Rainbow Slime"
	u.asset_name = "3x3_rainbow_slime"
	u.max_hp = 1000
	u.tags = [Tags.Slime]

	armor = SlimeAdaptiveArmorBuff()
	u.asset_variants = [(['char', asset_name], u.radius) for asset_name in armor.dtypes_to_assets.values()]

	u.spells = [SimpleMeleeAttack(damage=50, buff=SlimedBuff, buff_duration=12, damage_type=Tags.Physical)]
	u.buffs = [armor, SlimeBuff(RainbowSlime, "Rainbow Slimes")]
	add_tooltip(u, SlimedBuff())
	return u


class PrismancersBeamSpell(SimpleRangedAttack):

	def __init__(self):
		SimpleRangedAttack.__init__(self, name="Prismatic Beam", damage=10, damage_type=Tags.Holy, range=10, beam=True)

	def get_description(self):
		return ("Deals damage in a beam\nIf the target is [frozen], beams shoot toward enemies in line of sight")

	def get_ai_target(self):
		frozen_targets = [u for u in self.caster.level.units
						  if u.has_buff(FrozenBuff)
						  and are_hostile(self.caster, u)
						  and self.can_cast(u.x, u.y)]
		if frozen_targets: return random.choice(frozen_targets)
		return Spell.get_ai_target(self)

	def cast(self, x, y, channel_cast=False):
		target = self.caster.level.get_unit_at(x, y)
		refract = target and target.has_buff(FrozenBuff)
		yield from SimpleRangedAttack.cast(self, x, y, channel_cast)
		if not refract: return
		refraction_targets = [u for u in self.caster.level.get_units_in_los(target) if u != target and u.is_alive() and are_hostile(self.caster, u)] if target and target.has_buff(FrozenBuff) else []
		if not refraction_targets: return
		random.shuffle(refraction_targets)
		get_points_in_line = self.caster.level.get_points_in_line
		deal_damage = self.caster.level.deal_damage
		damage = self.get_stat('damage')
		for u in refraction_targets:
			for p in get_points_in_line(target, u, inclusive=False): deal_damage(p.x, p.y, damage, Tags.Holy, self)
			deal_damage(u.x, u.y, damage, Tags.Holy, self)
			yield

def Prismancer():
	u = Unit()
	u.name = "Prismancer"
	u.asset_name = 'ice_holy_wizard'
	u.max_hp = 180
	u.shields = 20
	u.tags = [Tags.Ice, Tags.Holy, Tags.Living]
	u.is_wizard = True

	u.resists[Tags.Ice] = 100
	u.resists[Tags.Holy] = 100

	freezing_gaze = WizardIceGaze()
	freezing_gaze.cool_down = 8

	shielding = RegenShieldsBuff(sh=1)
	shielding.color = Tags.Ice.color

	u.spells = [freezing_gaze, PrismancersBeamSpell()]
	u.buffs = [shielding]

	return u

DIFF_EASY = 1
DIFF_MED = 2
DIFF_HARD = 3

# Spawner, Level, Min, Max, (Req Tag)

MONSTER_PACKS = [
	(Watcher, DIFF_EASY, 3, 6, None),
	(GooSpitter, DIFF_EASY, 3, 6, None),
	(GoblinShaman, DIFF_EASY, 3, 5, None),
	(Tombstone, DIFF_EASY, 2, 4, None),
	(Casket, DIFF_EASY, 2, 4, None),
	(Crackler, DIFF_EASY, 4, 7, None),
	(BadApple, DIFF_EASY, 2, 4, None),
	(Leghead, DIFF_EASY, 2, 4, None),
	(CardGuard, DIFF_EASY, 7, 7, None),
	(ToadKnight, DIFF_EASY, 7, 7, None),
	(FalseProphet, DIFF_EASY, 3, 6, Tags.Living),
	(GnomeDonsy, DIFF_EASY, 2, 5, Tags.Nature),
	(SkullHornet, DIFF_EASY, 6, 12, Tags.Undead),
	(Hemogoblin, DIFF_EASY, 6, 12, Tags.Blood),

	(CrystalGolem, DIFF_MED, 3, 5, None),
	(Executioner, DIFF_MED, 3, 5, None),
	(VoidWatcher, DIFF_MED, 3, 6, None),
	(BrainTree, DIFF_MED, 5, 8, None),
	(Banshee, DIFF_MED, 2, 3, None),
	(VoidElder, DIFF_MED, 2, 3, None),
	(Siren, DIFF_MED, 3, 5, None),
	(DivineHammer, DIFF_MED, 2, 4, None),
	(FireWyrmEgg, DIFF_MED, 7, 9, Tags.Fire),
	(IceWyrmEgg, DIFF_MED, 7, 9, Tags.Ice),
	(FieryTormentorMass, DIFF_MED, 4, 6, Tags.Demon),
	(FrostfireTormentorMass, DIFF_MED, 4, 6, Tags.Demon),
	(MaggotLeech, DIFF_MED, 4, 6, Tags.Blood),

	(Lamasu, DIFF_HARD, 4, 6, None),
	(LavaSpitter, DIFF_HARD, 3, 7, None),
	(CorruptedLamasu, DIFF_HARD, 3, 5, None),
	(FlamingFleshFiend, DIFF_HARD, 3, 5, None),
	(SeerOfGlass, DIFF_HARD, 3, 5, None)
]

IDOLS = [
	(IdolOfLife, DIFF_EASY, 1, 1, None),
	(CrucibleOfPain, DIFF_MED, 1, 1, None),
	(IdolOfFrost, DIFF_EASY, 1, 1, None),
	(IdolOfSlime, DIFF_EASY, 1, 1, None),
	(IdolOfPoison, DIFF_EASY, 1, 1, None),
	(IdolOfRebirth, DIFF_EASY, 1, 1, None),

	(ConcussiveIdol, DIFF_MED, 1, 1, None),
	(IdolOfUndeath, DIFF_MED, 1, 1, Tags.Living),
	(IdolOfInsanity, DIFF_MED, 1, 1, None),
	(IdolOfAgony, DIFF_MED, 1, 1, None),
	(IdolOfWeakness, DIFF_MED, 1, 1, None),
	(IdolOfNightmares, DIFF_MED, 1, 1, None),
	(IdolOfFieryVengeance, DIFF_MED, 1, 1, None),
	(VampirismIdol, DIFF_MED, 1, 1, None),
	(IdolOfSorcery, DIFF_MED, 1, 2, None),

	(IdolOfFiends, DIFF_HARD, 1, 1, None),
	(IdolOfShielding, DIFF_HARD, 1, 1, None),
	(GiantSoulJar, DIFF_HARD, 1, 1, None),
	(IdolOfPiety, DIFF_HARD, 1, 1, None),
]

SUPER_SPAWNERS = [
	(KoboldCamp, DIFF_EASY, 1, 1, None),
	(GoblinCave, DIFF_EASY, 1, 1, None),
	(SkullHornetHive, DIFF_EASY, 1, 1, None),

	(DuergarFortress, DIFF_MED, 1, 1, None),
	(GnomeCastle, DIFF_MED, 1, 1, None),
	(PillarOfBone, DIFF_MED, 1, 1, Tags.Undead),
	(PillarOfWorms, DIFF_MED, 1, 1, Tags.Living),
	(TwistedTree, DIFF_MED, 1, 1, Tags.Nature),
]

SPECIAL_MONSTERS = [
	(SwampQueen, DIFF_EASY, 1, 1, None),
	(ChaosQuill, DIFF_EASY, 2, 3, None),
	(BoxOfWoe, DIFF_EASY, 1, 2, None),
	(BatDragon, DIFF_EASY, 3, 4, None),
	(Gemini, DIFF_EASY, 1, 1, None),
	(NineTheCat, DIFF_EASY, 1, 1, None),
	(Fenris, DIFF_EASY, 1, 1, None),
	(KettleMan, DIFF_EASY, 1, 1, None),
	(LimbCollector, DIFF_EASY, 1, 1,None),

	(Fujin, DIFF_MED, 1, 1, None),
	(FallenAngel, DIFF_MED, 1, 1, None),
	(Hamsa, DIFF_MED, 1, 1, None),
	(SlimeDrake, DIFF_MED, 1, 1, None),
	(Necrodrake, DIFF_MED, 1, 1, None),
	(VoidPhoenix, DIFF_MED, 1, 1, None),
	(Pan, DIFF_MED, 1, 1, Tags.Living),
	(RottingPhoenix, DIFF_MED, 1, 1, Tags.Undead),
	(VampireCount, DIFF_MED, 1, 1, Tags.Undead),
	(ArcaneBlacksmith, DIFF_MED, 1, 1, Tags.Metallic),

	(Medusa, DIFF_HARD, 1, 1, None),
	(Doldrum, DIFF_HARD, 1, 1, None),
	(BlackRider, DIFF_HARD, 1, 1, None),
	(WhiteRider, DIFF_HARD, 1, 1, None),
	(RedRider, DIFF_HARD, 1, 1, None),
	(PaleRider, DIFF_HARD, 1, 1, None),
	(GoldenBull, DIFF_HARD, 1, 1, None),
	(TitanLord, DIFF_HARD, 1, 1, None),
	(AesirLord, DIFF_HARD, 1, 1, None),
	(GildedTyrant, DIFF_HARD, 1, 1, None),
	(Observer, DIFF_HARD, 1, 1, None)
]

WIZARDS = [
	(BoneWizard, DIFF_EASY, 1, 1, None),
	(AvianWizard, DIFF_EASY, 1, 1, None),
	(RavenMage, DIFF_EASY, 1, 1, None),
	(LightningWizard, DIFF_EASY, 1, 1, None),
	(MountainWizard, DIFF_EASY, 1, 1, None),
	(MaskWizard, DIFF_EASY, 1, 1, None),
	(IceLich, DIFF_EASY, 1, 1, None),
	(FireLich, DIFF_EASY, 1, 1, None),
	(IceWizard, DIFF_EASY, 1, 1, None),
	(GoblinWizard, DIFF_EASY, 1, 1, None),
	(FireWizard, DIFF_EASY, 1, 1, None),
	(Enchanter, DIFF_EASY, 1, 1, None),
	(Translocator, DIFF_EASY, 1, 1, None),
	(SerpentPhilosopher, DIFF_EASY, 1, 1, None),
	(CrystalWizard, DIFF_EASY, 1, 1, None),
	(EyeballWizard, DIFF_EASY, 1, 1, None),
	(GremlinWizard, DIFF_EASY, 1, 1, None),
	(MushroomWizard, DIFF_EASY, 1, 1, None),
	(PumpkinWizard, DIFF_EASY, 1, 1, None),
	(CentaurDruid, DIFF_EASY, 1, 1, Tags.Living),
	(YetiShaman, DIFF_EASY, 1, 1, Tags.Living),
	(Mechanomancer, DIFF_EASY, 1, 1, Tags.Construct),

	(ArachnidWizard, DIFF_MED, 1, 1, None),
	(Angrboda, DIFF_MED, 1, 1, None),
	(DragonMage, DIFF_MED, 1, 1, None),
	(TrollGeomancer, DIFF_MED, 1, 1, None),
	(TwilightSeer, DIFF_MED, 1, 1, None),
	(FrostfireWizard, DIFF_MED, 1, 1, None),
	(MischiefMaker, DIFF_MED, 1, 1, None),
	(MoonMage, DIFF_MED, 1, 1, None),
	(DeathchillWizard, DIFF_MED, 1, 1, None),
	(Thunderbones, DIFF_MED, 1, 1, None),
	(ToadNightmareSorcerer, DIFF_MED, 1, 1, None),
	(GrandWarlock, DIFF_MED, 1, 1, Tags.Demon),

	(TimeKeeper, DIFF_HARD, 1, 1, None),
	(BloodWizard, DIFF_HARD, 1, 1, None),
	(SunMage, DIFF_HARD, 1, 1, None),
	(Prismancer, DIFF_HARD, 1, 1, None),

]

KAIJU = [
	# Kaiju types
	(TheGreatPumpking, DIFF_EASY, 1, 1, None),
	(ChainedCyclops, DIFF_EASY, 1, 1, None),
	(HaetaeGolem, DIFF_EASY, 1, 1, None),
	(GiantMindMaggotQueen, DIFF_EASY, 1, 1, None),
	(MotherOfSpiders, DIFF_EASY, 1, 1, None),
	(GiantSackOfFilth, DIFF_EASY, 1, 1, None),
	(Taurokelevee, DIFF_EASY, 1, 1, None),
	(Gryla, DIFF_EASY, 1, 1, None),

	(Winterbringer, DIFF_MED, 1, 1, None),
	(Cindervein, DIFF_MED, 1, 1, None),
	(Stormcrest, DIFF_MED, 1, 1, None),
	(Starclaw, DIFF_MED, 1, 1, None),
	(Gloomwing, DIFF_MED, 1, 1, None),
	(Rattlemaw, DIFF_MED, 1, 1, None),
	(Dawnheart, DIFF_MED, 1, 1, None),
	(GiantMindDevourer, DIFF_MED, 1, 1, None),
	(GreaterLamasu, DIFF_MED, 1, 1, None),
	(Mothgod, DIFF_MED, 1, 1, None),
	(UltimateTroubler, DIFF_MED, 1, 1, None),
	(GiantGorgon, DIFF_MED, 1, 1, None),
	(SkullSentry, DIFF_MED, 1, 1, None),
	(Orochi, DIFF_MED, 1, 1, None),
	(OssuarySpider, DIFF_MED, 1, 1, None),
	(CoralColossus, DIFF_MED, 1, 1, None),
	(RainbowSlime, DIFF_MED, 1, 1, None),

	(Animikii, DIFF_HARD, 1, 1, None),
	(GiantBoneShambler, DIFF_HARD, 1, 1, None),
	(GiantFleshFiend, DIFF_HARD, 1, 1, None),
	(GiantNightmareTurtle, DIFF_HARD, 1, 1, None),
	(GiantMassOfEyes, DIFF_HARD, 1, 1, None),
	(InfernoKing, DIFF_HARD, 1, 1, None),
	(TheFurnace, DIFF_HARD, 1, 1, None),
	(ShrapnelBeast, DIFF_HARD, 1, 1, None),
	(Gelgut, DIFF_HARD, 1, 1, None),
	(Blightmonger, DIFF_HARD, 1, 1, None),
	(MoltenDevourer, DIFF_HARD, 1, 1, None),
]

def build_monster_group(*groups):
	seen = set()
	merged = []
	for group in groups:
		for entry in group:
			factory = entry[0]
			if factory in seen: continue
			seen.add(factory)
			merged.append(entry)
	return merged

giants = build_monster_group(IDOLS, SUPER_SPAWNERS, KAIJU)
minibosses = build_monster_group(SUPER_SPAWNERS, KAIJU)
early_game_rares = build_monster_group(MONSTER_PACKS, SPECIAL_MONSTERS, WIZARDS)
rare_monsters = build_monster_group(MONSTER_PACKS, IDOLS, SUPER_SPAWNERS, SPECIAL_MONSTERS, WIZARDS, KAIJU)


def get_rare_spawn_bounds(difficulty):
	if difficulty < 9: return DIFF_EASY, DIFF_EASY
	if difficulty < 13: return DIFF_EASY, DIFF_MED
	if difficulty < 17: return DIFF_MED, DIFF_MED
	return DIFF_HARD, DIFF_HARD

def get_rare_spawn_options(difficulty, min_level=None, max_level=None, group=None, tags=None):
	if not group: group = rare_monsters if difficulty > 6 else early_game_rares # keep giants for r6+
	default_min, default_max = get_rare_spawn_bounds(difficulty)
	if min_level is None: min_level = default_min
	if max_level is None: max_level = default_max
	min_level = max(DIFF_EASY, min(DIFF_HARD, min_level))
	max_level = max(min_level, min(DIFF_HARD, max_level))

	def can_spawn(opt):
		if opt[1] < min_level: return False
		if opt[1] > max_level: return False
		if tags is not None and opt[4] is not None:
			if opt[4] not in tags: return False
		return True

	return [opt for opt in group if can_spawn(opt)]

def roll_rare_spawn(difficulty, min_level=None, max_level=None, prng=None, group=None, tags=None, factory_only=False):
	if not group: group = rare_monsters if difficulty > 6 else early_game_rares # keep giants for r6+
	if not prng: prng = random

	opts = get_rare_spawn_options(difficulty, min_level=min_level, max_level=max_level, group=group, tags=tags)
	if not opts and tags is not None: opts = get_rare_spawn_options(difficulty, min_level=min_level, max_level=max_level, group=group)
	if not opts: opts = group.copy()

	chosen_opt = prng.choice(opts)
	spawner, diff, min_no, max_no, tag = chosen_opt

	if factory_only: return spawner

	numspawn = prng.randint(min_no, max_no)
	units = [spawner() for i in range(numspawn)]

	return units
