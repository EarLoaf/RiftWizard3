from Level import *
from Spells import *
import random
from Monsters import *
from RareMonsters import *
from Equipment import *
import Vaults


class DuplicationShop(Shop):

	def __init__(self):
		Shop.__init__(self)
		self.name = "Duplication Shrine"
		self.description = "Obtain a duplicate of a piece of equipment you have crafted"
		self.asset = ['tiles', 'shrine', 'duplication_shrine']

	def on_player_enter(self, player):
		self.items = [i for i in player.equipment if i.crafting_input_fns]
		Shop.on_player_enter(self, player)

	def buy(self, shopper, item):
		dupe = item.clone()
		for c, a in item.crafting_input_fns.items():
			for i in range(a): c().on_craft(shopper, dupe) # dupes on_craft effects
		shopper.equip(dupe)
		self.close()

	def on_player_exit(self, player):
		self.items = []

	def get_confirm_text(self, i):
		return ("Make a duplicate {i}?", {"i": i})


class ReformationShop(Shop):
	def __init__(self):
		Shop.__init__(self)
		self.name = "Shrine of Reformation"
		self.description = ("Permanently remove a spell or piece of equipment\n"
							"Spells refund SP\n"
							"Equipment refunds components\n\n"
							"Reusable")
		self.asset = ['tiles', 'shrine', 'reformation_shrine']

	def on_player_enter(self, player):
		spells = player.spells[:]
		equipment = [i for i in player.equipment if i.crafting_input_fns]
		self.items = spells + equipment
		Shop.on_player_enter(self, player)

	def on_player_exit(self, player):
		self.items = []

	def buy(self, shopper, item):
		if isinstance(item, Spell):
			spell_upgrades = [b for b in shopper.buffs if b.buff_type == BUFF_TYPE_PASSIVE and type(b.prereq) == type(item)]
			if spell_upgrades:
				for spell_upgrade in spell_upgrades:
					shopper.xp += spell_upgrade.level
					shopper.remove_buff(spell_upgrade)

			shopper.xp += getattr(item, 'level', 0)  # for weird spells without levels i.e. idol of sorcery
			shopper.remove_spell(item)

			for s in shopper.game.all_player_spells:
				if type(item) == type(s):
					shopper.game.all_player_spells.remove(s)
					shopper.game.restricted_spells.add(type(s))
					break
		else:
			for c, v in item.crafting_input_fns.items():
				for i in range(v): shopper.add_component(c())

			shopper.unequip(item)
			for i in shopper.game.all_player_items:
				if i.name == item.name: shopper.game.all_player_items.remove(i)
			shopper.game.restricted_equipment.add(item.name)

		self.items = []

	def get_confirm_text(self, i):
		return ("Permanently remove {i}?", {"i": i})

class ShrineOfPerfection(Prop):

	def __init__(self):
		self.name = "Shrine of Perfection"
		self.description = "A random spell you know gains all upgrades"
		self.asset = ['tiles', 'shrine', 'perfection_shrine']

	def on_player_enter(self, player):
		opts = [s for s in player.spells if len(s.spell_upgrades) > len([b for b in player.buffs if getattr(b, 'prereq', None) == s])]
		if not opts: return
		s = random.choice(opts)
		s.do_ui_flash(tag=s.tags[0])
		owned = [b for b in player.buffs if getattr(b, 'prereq', None) == s]

		for upgrade in s.spell_upgrades:
			if upgrade not in owned:
				player.apply_buff(upgrade)

		self.level.remove_prop(self)
		self.level.event_manager.raise_event(EventOnItemPickup(self), player)
		self.level.log(("Shrine of Perfection granted all upgrades to {spell}", {'spell':s.name}))
		# do sfx and vfx, change the name of the spell to Perfected X? change its highlight color?

class ShrineOfKnowledge(Shop):

	def __init__(self):
		Shop.__init__(self)
		self.name = "Shrine of Knowledge"
		self.asset = ['tiles', 'shrine', 'knowledge_shrine']

	def get_description(self):
		return ("Sacrifice a component to learn a random spell that shares a tag with it\n\n"
				"Components with more tags grant stronger spells")

	def on_player_enter(self, player):
		self.items = player.components
		Shop.on_player_enter(self, player)

	def buy(self, shopper, item):
		opts = self.get_matched_tag_spells(shopper, item)
		spell = random.choice(opts)
		shopper.add_spell(spell)
		purchases = [spell]
		owned = []
		for _ in range(len(item.tags)): # upgrades = num_tags
			available = [u for u in spell.spell_upgrades if u not in owned]
			if not available: continue
			upgrade = random.choice(available)
			shopper.apply_buff(upgrade)
			owned.append(upgrade)
			purchases.append(upgrade)

		shopper.remove_component(item) # spend the component
		self.close()
		return purchases

	def can_shop(self, shopper, item):
		if item is None: return True
		opts = self.get_matched_tag_spells(shopper, item)
		if not opts: return False
		return Shop.can_shop(self, shopper, item)

	def get_matched_tag_spells(self, shopper, item):
		opts = [s for s in shopper.game.all_player_spells if not shopper.get_spell(type(s))]
		opts = [s for s in opts if any(t in s.tags for t in item.tags)]
		return opts

	def on_player_exit(self, player):
		self.items = []

	def get_confirm_text(self, component):
		return ("Sacrifice {component} to learn a random spell that shares a tag with it?", {"component": component})

class EvolutionShop(Shop):
	def __init__(self):
		Shop.__init__(self)
		self.name = "Evolution Shrine"
		self.asset = ['tiles', 'shrine', 'evolution_shrine']
		self.purchases = 0
		self.max_purchases = 3
		self.selected_component = None
		self.stages = 2
		self.stage = 1

	def get_description(self):
		return (("Sacrifice a component to gain a random upgrade for a spell that shares a tag with it"
				"\n\nReusable ({remaining} times)"), {'remaining': self.max_purchases - self.purchases})

	def progress_stage(self, i):
		self.begin_spell_selection(i)

	def regress_stage(self, player):
		self.on_player_enter(player)

	def begin_spell_selection(self, component):
		player = self.level.player_unit
		spells = [s for s in player.spells if
				  any(t in s.tags for t in component.tags) # only allow spells that share a tag with the component
				  and not player.has_all_upgrades(s)]  # and spells which have unpurchased upgrades
		if not spells: self.regress_stage(player); return
		self.items = spells
		self.selected_component = component
		self.stage = 2

	def on_player_enter(self, player):
		self.selected_component = None
		self.stage = 1
		self.items = [c for c in player.components if  # only include usable components
					  any(t in s.tags
						  for s in player.spells
						  if not player.has_all_upgrades(s)
						  for t in c.tags)]

		Shop.on_player_enter(self, player)

	def buy(self, player, spell):
		owned = [b for b in player.buffs if getattr(b, 'prereq', None) == spell]
		opts = []
		for upgrade in spell.spell_upgrades:
			if upgrade not in owned: opts.append(upgrade)

		if not opts: self.regress_stage(player); return
		upgrade = random.choice(opts)
		player.apply_buff(upgrade)
		spell.do_ui_flash()
		self.level.log(("Evolution Shrine upgraded {spell} with {upgrade}.", {'spell':spell.name, 'upgrade':upgrade.name}))
		player.remove_component(self.selected_component)  # spend the component
		self.purchases += 1
		if self.purchases >= self.max_purchases: self.close()
		return upgrade

	def on_player_exit(self, player):
		self.items = []

	def get_confirm_text(self, i):
		return ("Sacrifice {component} to gain a random upgrade for {i}?", {"component": self.selected_component.name, "i": i})



class DissolutionShop(Shop):
	def __init__(self):
		Shop.__init__(self)
		self.name = "Dissolution Shrine"
		self.description = ("Permanently forget a spell and its upgrades"
							"\n\nSpawn random components nearby that share its tags"
							"\n\nMore powerful spells yield more components"
							"\n\nReusable")
		self.asset = ['tiles', 'shrine', 'dissolution_shrine']

	def on_player_enter(self, player):
		self.items = player.spells[:]
		Shop.on_player_enter(self, player)

	def buy(self, shopper, spell):
		xp = 0
		tags = spell.tags.copy()
		spell_upgrades = [b for b in shopper.buffs if b.buff_type == BUFF_TYPE_PASSIVE and type(b.prereq) == type(spell)]
		if spell_upgrades:
			for spell_upgrade in spell_upgrades:
				xp += spell_upgrade.level; shopper.remove_buff(spell_upgrade)

		xp += getattr(spell, 'level', 0) # for weird spells without levels i.e. idol of sorcery
		shopper.remove_spell(spell)

		for s in shopper.game.all_player_spells:
			if type(spell) == type(s):
				shopper.game.all_player_spells.remove(s)
				shopper.game.restricted_spells.add(type(s))

		radius_limit = 3
		max_radius = shopper.level.width + shopper.level.height

		while xp > 0:
			p = self.get_component_spawn_pt(shopper.x, shopper.y, radius_limit, shopper.level)
			if not p and radius_limit < max_radius: radius_limit += 1; continue
			component = roll_random_component(tag_req=random.choice(tags))()
			xp -= len(component.tags)
			if p:
				prop = ComponentPickup(component)
				shopper.level.add_prop(prop, p.x, p.y)
				if radius_limit > 6: self.clear_floors(shopper.x, shopper.y, shopper.level, radius_limit//2)
			else: self.collect_component(shopper, component)

		self.items = []

	def collect_component(self, player, component):
		pickup = ComponentPickup(component)
		pickup.level = player.level
		pickup.x = player.x
		pickup.y = player.y
		# mimic the on enter logic, minus removal from the level
		player.add_component(component)
		player.level.log(("Wizard picked up {component}.", {"component": component.name}))
		component.on_pickup(player, player.level)
		player.level.event_manager.raise_event(EventOnItemPickup(pickup), player)

	def clear_floors(self, x, y, level, radius):
		tiles = [tile for tile in level.get_tiles_in_ball(x, y, radius)]
		for tile in tiles: level.make_floor(tile.x, tile.y)

	def get_component_spawn_pt(self, x, y, radius_limit, level):
		options = list(level.get_points_in_ball(x, y, radius_limit))
		options.sort(key=lambda p: distance(p, Point(x, y)))

		for o in options:
			tile = level.tiles[o.x][o.y]
			if not tile.can_walk: continue
			if level.get_unit_at(o.x, o.y) and radius_limit < 5: continue
			if tile.prop: continue
			return o

		for o in options:
			tile = level.tiles[o.x][o.y]
			if level.get_unit_at(o.x, o.y) and radius_limit < 5: continue
			if tile.prop: continue
			level.make_floor(o.x, o.y)
			return o

	def on_player_exit(self, player):
		self.items = []

	def get_confirm_text(self, i):
		return ("Completely forget {i} forever?", {"i": i})



class SpellGraftShrine(Shop):

	def __init__(self):
		Shop.__init__(self)
		self.name = "Spellgraft Shrine"
		self.description = "Sacrifice a component to grant a random one of its tags to a spell you know"
		self.asset = ['tiles', 'shrine', 'spellgraft_shrine']
		self.selected_component = None
		self.stages = 2
		self.stage = 1

	def progress_stage(self, i):
		self.begin_spell_selection(i)

	def regress_stage(self, player):
		self.on_player_enter(player)

	def begin_spell_selection(self, component):
		player = self.level.player_unit
		spells = [s for s in player.spells if any(t not in s.tags for t in component.tags)] # only allow spells that don't have that tag already
		if not spells: self.regress_stage(player); return
		self.items = spells
		self.selected_component = component
		self.stage = 2

	def on_player_enter(self, player):
		self.selected_component = None
		self.stage = 1
		self.items = player.components
		Shop.on_player_enter(self, player)

	def buy(self, player, spell):
		opts = [t for t in self.selected_component.tags if t not in spell.tags] # choose a tag on the component that the spell doesn't already have
		if not opts: self.regress_stage(player); return
		t = random.choice(opts)
		spell.tags.append(t)
		spell.do_ui_flash(t)
		spell.sync_upgrade_tags()
		player.invalidate_spell_stats()
		player.remove_component(self.selected_component) # spend the component
		self.close()

	def on_player_exit(self, player):
		self.items = []

	def get_confirm_text(self, i):
		return ("Sacrifice {component} to add one of its tags to {i}?", {"component": self.selected_component.name, "i": i})


class ChronomancyShrine(Shop):

	def __init__(self):
		Shop.__init__(self)
		self.name = "Chronomancy Shrine"
		self.description = "One of your spells gains a cooldown equal to its level\nIt no longer uses charges"
		self.asset = ['tiles', 'shrine', 'chronomancy_shrine']

	def on_player_enter(self, player):
		self.items = [s for s in player.spells if s.max_charges]
		Shop.on_player_enter(self, player)

	def can_shop(self, shopper, item):
		if item is None: return True
		if item not in self.items: return False
		return True

	def buy(self, shopper, spell):
		spell.max_charges = 0
		spell.cur_charges = 0
		spell.cool_down += getattr(spell, 'level', 0) # add the cd rather than set, so it doesn't break the mutator
		spell.do_ui_flash()
		self.close()

	def on_player_exit(self, player):
		self.items = []

	def get_confirm_text(self, i):
		return ("Bind {i} with Chronomancy?", {"i": i})

class OfferingShrine(Shop):

	def __init__(self):
		Shop.__init__(self)
		self.name = "Shrine of Offering"
		self.description = "Sacrifice a component to make one of its tags appear more often in future realms"
		self.asset = ['tiles', 'shrine', 'offering_shrine']
		self.selected_component = None
		self.stages = 2
		self.stage = 1

	def progress_stage(self, i):
		self.begin_tag_selection(i)

	def regress_stage(self, player):
		self.on_player_enter(player)

	def begin_tag_selection(self, component):
		self.items = component.tags
		self.selected_component = component
		self.stage = 2

	def on_player_enter(self, player):
		self.selected_component = None
		self.stage = 1
		self.items = player.components
		Shop.on_player_enter(self, player)

	def buy(self, player, tag):
		from Mutators import BonusComponentTagAppearance
		player.game.mutators.append(BonusComponentTagAppearance(tag, 25))
		player.remove_component(self.selected_component)
		self.close()

	def on_player_exit(self, player):
		self.items = []

	def get_confirm_text(self, i):
		return ("Sacrifice {component} to make [{i}] components appear more often?", {"i": i, "component":self.selected_component.name})

class HasteShrine(Shop):

	def __init__(self):
		Shop.__init__(self)
		self.name = "Shrine of Haste"
		self.description = "One of your spells gains quickcast"
		self.asset = ['tiles', 'shrine', 'haste_shrine']

	def on_player_enter(self, player):
		self.items = [s for s in player.spells]
		Shop.on_player_enter(self, player)

	def buy(self, shopper, spell):
		spell.quick_cast += 1
		spell.do_ui_flash()
		self.close()

	def on_player_exit(self, player):
		self.items = []

	def get_confirm_text(self, i):
		return ("Grant {i} quickcast?", {"i": i})

class TransmutationShrine(Shop):

	def __init__(self):
		Shop.__init__(self)
		self.name = "Transmutation Shrine"
		self.asset = ['tiles', 'shrine', 'transmutation_shrine']
		self.purchases = 0
		self.max_purchases = 3
		self.selected_component = None
		self.stages = 2
		self.stage = 1

	def get_description(self):
		return (("Transmute a component into a different component that shares a tag with it"
				 "\n\nReusable ({remaining} times)"), {'remaining': self.max_purchases - self.purchases})

	def progress_stage(self, i):
		self.begin_target_selection(i)

	def regress_stage(self, player):
		self.on_player_enter(player)

	def begin_target_selection(self, component):
		comp_tags_set = set(component.tags)
		self.items = [type(c)() for c in all_components_ex if not comp_tags_set.isdisjoint(c.tags) and c.name != component.name]
		self.selected_component = component
		self.stage = 2

	def on_player_enter(self, player):
		self.selected_component = None
		self.stage = 1
		self.items = player.components
		Shop.on_player_enter(self, player)

	def buy(self, player, component):
		player.remove_component(self.selected_component)  # spend the component
		player.add_component(component)
		self.purchases += 1
		if self.purchases >= self.max_purchases: self.close()

	def on_player_exit(self, player):
		self.items = []

	def get_confirm_text(self, i):
		return ("Transmute {component} into {i}?", {"component": self.selected_component.name, "i": i})


class SpiderShrine(Prop):

	def __init__(self):
		self.name = "Shrine of Spiders"
		self.description = ("Gain the [Spider] tag\n"
							"Spawn [3:num_targets] webs each turn on adjacent tiles\n"
							"Webs will no longer immobilize you\n"
							"When you cast a [Translocation] spell targeting a web, refund 1 charge of that spell and consume the web")

		self.asset = ['tiles', 'shrine', 'spider_shrine']

	def on_player_enter(self, player):
		player.equip(SpiderCarapaceRobe())
		self.level.remove_prop(self)
		self.level.event_manager.raise_event(EventOnItemPickup(self), player)

def spider_shrine(_difficulty, _prng, _player): return SpiderShrine()

class SoulShrine(Prop):

	def __init__(self):
		self.name = "Shrine of Necromancy"
		self.description = ("Gain the [Undead] tag\n"
							"You gain 100% [Dark] resistance and lose 100% [Holy] resistance\n"
							"[Dark] Spells and Equipment gain +100% [max charges:max_charges]\n"
							"Learning a [Dark] spell refunds half its SP cost")
		self.asset = ['tiles', 'shrine', 'soul_shrine']

	def on_player_enter(self, player):
		player.equip(NecromancersLocket())
		self.level.remove_prop(self)
		self.level.event_manager.raise_event(EventOnItemPickup(self), player)

def soul_shrine(_difficulty, _prng, _player): return SoulShrine()

class IdolChest(Shop):

	def __init__(self):
		Shop.__init__(self)
		self.name = "Equipment Chest"
		self.description = "One piece of equipment may be taken from this chest"
		self.asset = ['tiles', 'items', 'animated', 'equipment_chest']
		self.items = [equipment() for equipment in MINI_IDOLS]

	def get_confirm_text(self, i):
		return ("Take {i}?", {"i": i})

def idol_chest(_difficulty, _prng, _player): return IdolChest()

# LEVEL REWARDS : SHOULD RETURN A LEVEL PROP OR SHOP OF SOME KIND
# rewards can take player, current level, and level randomseed into account.
def hp_shrine(_difficulty, _prng, _player): return HeartDot()
def duplication_shrine(_difficulty, _prng, _player): return DuplicationShop()
def reformation_shrine(_level, _prng, _player): return ReformationShop()
def dissolution_shrine(_level, _prng, _player): return DissolutionShop()
def evolution_shrine(_level, _prng, _player): return EvolutionShop()
def perfection_shrine(_level, _prng, _player): return ShrineOfPerfection()
def knowledge_shrine(_level, _prng, _player): return ShrineOfKnowledge()
def spellgraft_shrine(_level, _prng, _player): return SpellGraftShrine()
def chronomancy_shrine(_level, _prng, _player): return ChronomancyShrine()
def offering_shrine(_level, _prng, _player): return OfferingShrine()
def haste_shrine(_level, _prng, _player): return HasteShrine()
def transmutation_shrine(_level, _prng, _player): return TransmutationShrine()


def scroll(level, prng=random, player=None):
	mod = level // 6
	max_spell_level = 4 + mod
	min_spell_level = 2 + mod

	if player: spell_opts = [s for s in player.game.all_player_spells if min_spell_level <= s.level <= max_spell_level and not player.get_spell(type(s))]
	else: spell_opts = make_player_spells()
	prng.shuffle(spell_opts)
	spell_opts = spell_opts[:4]

	shop = Shop()
	shop.name = "Scroll of Spells"
	shop.description = "One spell may be learned for free"
	shop.asset = ['tiles', 'items', 'animated', 'spell_scroll']
	shop.items = spell_opts

	def can_shop(shopper, item):
		if shopper.get_spell(type(item)): return False
		else: return Shop.can_shop(shop, shopper, item)

	shop.can_shop = can_shop # don't let the player waste a scroll on a spell they already know.

	def confirm_txt(i): return ("Learn {spell}?", {"spell": i})
	shop.get_confirm_text = confirm_txt

	return shop

def tavern(level, prng=random, player=None):
	shop = Shop()
	shop.name = "Tavern"
	shop.description = "A place where adventurers gather"
	shop.asset = ['tiles', 'items', 'animated', 'tavern']
	shop.items = [c() for c in prng.sample(all_companions, 3)]
	def confirm_txt(i): return ("Acquire {i} as a permanent companion?", {'i':i})
	shop.get_confirm_text = confirm_txt
	return shop

def bookshelf(level, prng=random, player=None, forced_tags=None):
	if forced_tags: tags = forced_tags
	else: tags = prng.sample(spell_tags, 4)
	shop = Shop()
	shop.name = "Bookshelf"
	shop.description = "A shelf of tomes to further the wizard's learning"
	shop.asset = ['tiles', 'items', 'animated', 'bookshelf']
	shop.items = [Tome(t) for t in tags]
	def confirm_txt(i): return ("Acquire {i}?", {"i": i})
	shop.get_confirm_text = confirm_txt
	return shop

def slime_shelf():
	return bookshelf(1, forced_tags=[Tags.Slime, Tags.Eye, Tags.Chaos])

def rare_component_reward(level, prng=random, player=None):
	return ComponentPickup(prng.choice(rare_components)())

# (Reward Function(level, rng, player), Weight, Min Level, Eval Func)
def vault_portal_reward(level, prng=None, player=None):
	prng = prng or random
	game = getattr(player, "game", None)
	if not game: return hp_shrine(level, prng, player)
	return Vaults.make_vault_portal(game, level, rng=prng, locked=True)

def spellslots_available(_level, _prng, player): return not player.game.player_spell_limit_reached()
def vault_valid(level, _prng, _player): return level < 19 # don't want a vault on level 19 or 20, since that would shortcircuit Final Bosses or Mordred
def companion_count(level, prng, player): return ((len([e for e in player.equipment if isinstance(e, Companion)]) + 1) * prng.random()) < 1 # lower chance for companions if you already have some
def good_offering(level, prng, player): return prng.random() < min(1, (LAST_LEVEL - level) / (LAST_LEVEL - 14))

# reward, weight, min_level, restrict fn, name
reward_table = [
	# always rollable
	(hp_shrine, 1, None, None, "Ruby Heart"),
	(rare_component_reward, .2, None, None, "Rare Component"),
	(bookshelf, .1, None, None, "Bookshelf"),
	(scroll, .1, None, spellslots_available, "Spell Scroll"),
	(knowledge_shrine, .015, None, spellslots_available, "Shrine of Knowledge"),
	(offering_shrine, .015, None, good_offering, "Shrine of Offering"),
	(haste_shrine, .015, None, None, "Shrine of Haste"),

	# level 4+
	(reformation_shrine, .025, 4, None, "Shrine of Reformation"),
	(vault_portal_reward, .005, 4, vault_valid, "Vault Portal"),
	(dissolution_shrine, .015, 4, None, "Dissolution Shrine"),
	(tavern, .025, 4, companion_count, "Tavern"),
	(evolution_shrine, .01, 4, None, "Evolution Shrine"),
	(transmutation_shrine, .015, 4, None, "Transmutation Shrine"),

	# level 5+
	(chronomancy_shrine, .015, 5, None, "Chronomancy Shrine"),
	(duplication_shrine, .015, 5, None, "Duplication Shrine"),

	# level 8+
	(perfection_shrine, .01, 8, None, "Shrine of Perfection"),
	(spellgraft_shrine, .01, 8, None, "Spellgraft Shrine"),

	# Special Case / Vaults Only
	(spider_shrine, None, 25, None, "Spider Shrine"),
	(soul_shrine, None, 25, None, "Soul Shrine"),
	(idol_chest, None, 25, None, "Idol Chest")
	# add equipment chests as a restricted level reward for a mutator which removes components & crafting
]

def roll_level_reward(level, prng=None, player=None, forced=None, reward_options=None):
	if not prng: prng = random
	if reward_options is None: reward_options = reward_table
	if forced is not None:
		for fn, *rest in reward_options:
			if forced is fn: return fn(level, prng, player)

	def can_roll(o):
		if o[2] is not None and level < o[2]: return False
		if o[3] is None: return True
		return o[3](level, prng, player)

	opts = [o for o in reward_options if can_roll(o)]
	if not opts: return None
	return prng.choices([o[0] for o in opts], weights=[o[1] for o in opts])[0](level, prng, player)

# make rewards accessible by name-keys
reward_dict = {}
for o in reward_table:
	if o[1] is not None:
		reward_dict[o[4]] =  (o[0], o[1], o[2], o[3])

# if __name__ == "__main__":
# 	for i in range(200):
# 		print(roll_level_reward(2))
