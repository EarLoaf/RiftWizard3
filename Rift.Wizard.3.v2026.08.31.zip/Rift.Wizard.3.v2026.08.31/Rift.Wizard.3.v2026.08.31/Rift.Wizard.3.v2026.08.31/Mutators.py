import math
import random
import sys
import datetime
import RareMonsters

from Level import *
from CommonContent import *
from Monsters import *
from LevelGen import *
from Equipment import *


class Mutator(object):

	def __init__(self, mutseed=0):
		self.global_triggers = {}
		self.random = None
		self.name = self.__class__.__name__
		self.description = ""

	def get_description(self):
		return self.description

	def fmt_dict(self):
		return {}

	def set_seed(self, seed):
		self.seed = seed
		self.random = random.Random()
		self.random.seed(seed)

	def on_levelgen(self, levelgen):
		pass

	def modify_units(self, level):
		pass

	def on_levelgen_terrain(self, levelgen):
		pass

	def on_levelgen_pre(self, levelgen):
		pass

	def on_levelgen_start(self, levelgen):
		pass

	def on_level_reward(self, levelgen, reward, prng, player):
		return reward

	def on_generate_spells(self, spells):
		pass

	def on_generate_equipment(self, equipment):
		pass

	def on_generate_skills(self, skills):
		pass

	def on_game_begin(self, game):
		pass

class EveryXTurnsBuff(Buff):

	def __init__(self, mutator, interval):
		Buff.__init__(self)
		self.interval = interval
		self.mutator = mutator
		self.turn_counter = 0

	def on_init(self):
		self.name = "EveryXTurnsBuff"
		self.buff_type = BUFF_TYPE_NONE
		self.stack_type = STACK_INTENSITY

	def on_advance(self):
		if self.owner.game.level_cleared:
			return  # Don't trigger effects if the level is already won

		if self.owner.level.turn_no % self.interval == 0:
			self.mutator.do_effect(self.owner.level)

class EveryXTurnsMutator(Mutator):

	def __init__(self, interval):
		Mutator.__init__(self)
		self.interval = interval

	def on_game_begin(self, game):
		game.p1.apply_buff(EveryXTurnsBuff(self, self.interval))

	def do_effect(self, level):
		pass


class Forgetful(EveryXTurnsMutator):

	def __init__(self, interval):
		EveryXTurnsMutator.__init__(self, interval)

	def get_description(self):
		return ("Lose a charge from a random spell every {interval} turns", {'interval': self.interval})

	def do_effect(self, level):
		player = level.player_unit
		if not player:
			return
		candidates = [s for s in player.spells if s.cur_charges > 0]
		if not candidates:
			return  # Nothing to lose

		spell = random.choice(candidates)
		spell.cur_charges = max(0, spell.cur_charges - 1)
		level.log(("[Wizard:wizard] lost a charge from {spell} due to mutator", {"spell": spell.name}))

class Awestruck(EveryXTurnsMutator):

	def __init__(self, interval):
		EveryXTurnsMutator.__init__(self, interval)

	def get_description(self):
		return ("Get Stunned for one turn every {interval} turns", {'interval': self.interval})

	def do_effect(self, level):
		player = level.player_unit
		level.log("[Wizard:wizard] stunned for 1 turn due to mutator")
		player.apply_buff(Stun(), 1)

class Treachery(EveryXTurnsMutator):

	def __init__(self, interval):
		EveryXTurnsMutator.__init__(self, interval)

	def get_description(self):
		return ("A random ally joins the enemy team every {interval} turns", {'interval': self.interval})

	def do_effect(self, level):
		player = level.player_unit
		units = list(level.units)
		random.shuffle(units)
		u = next((u for u in units if u.team == player.team and not u==player), None)
		if u:
			u.team = TEAM_ENEMY
			level.log(("[{unit}:ally] joined the enemy team due to mutator", {"unit": u.name}))

class Thieving(EveryXTurnsMutator):

	def __init__(self, interval):
		EveryXTurnsMutator.__init__(self, interval)

	def get_description(self):
		return ("A random object is removed from the level every {interval} turns", {'interval': self.interval})

	def do_effect(self, level):
		if not level.props:
			return
		prop = random.choice(level.props)
		level.remove_prop(prop)
		level.log("Object removed from level due to mutator")

class Crumbling(EveryXTurnsMutator):

	def __init__(self, interval):
		EveryXTurnsMutator.__init__(self, interval)

	def get_description(self):
		return ("Unoccupied floor and wall tiles adjacent to chasms have a 10% chance to become chasms every {interval} turns", {'interval': self.interval})

	def do_effect(self, level):
		to_crumble = set()
		seen = set()
		for tile in level.iter_tiles():
			if not tile.is_chasm:
				continue
			for t in level.get_tiles_in_ball(tile.x, tile.y, 1.5):
				if t.unit:
					continue
				if t.prop:
					continue
				if t not in seen and (t.is_floor() or t.is_wall()) :
					seen.add(t)
					if random.random() < .1:
						to_crumble.add(t)

		for t in to_crumble:
			level.show_effect(t.x, t.y, Tags.Physical, minor=True)
			level.make_chasm(t.x, t.y)
			level.log("Chasm created due to mutator")

class LairMultiplier(Mutator):
	
	def __init__(self, mult):
		Mutator.__init__(self)
		self.mult = mult

	def get_description(self):
		return ("Levels contain {mult}x Monster Spawners", {'mult': self.mult})

	def on_levelgen_pre(self, levelgen):
		levelgen.num_generators *= self.mult

class NumPortals(Mutator):

	def __init__(self, num):
		Mutator.__init__(self)
		self.num = num

	def get_description(self):
		return ("All levels contain {num} rifts", {'num': self.num})

	def on_levelgen_pre(self, levelgen):
		levelgen.num_exits = self.num


class MonsterHPMult(Mutator):

	def __init__(self, mult):
		Mutator.__init__(self)
		self.mult = mult
		self.global_triggers[EventOnUnitPreAdded] = self.on_enemy_added

	def get_description(self):
		return ("All enemy units have {pct}% HP", {'pct': int(self.mult * 100)})

	def on_enemy_added(self, evt):
		if not evt.unit.ever_spawned:
			self.modify_unit(evt.unit)

	def modify_units(self, level):
		for u in level.units:
			self.modify_unit(u)

	def modify_unit(self, unit):
		if unit.is_lair:
			return
		if unit.team == TEAM_PLAYER:
			return
		# Do not buff the HP of splitting units
		if isinstance(unit.source, SplittingBuff):
			return
		unit.max_hp *= self.mult
		unit.cur_hp *= self.mult

class SuperSpawners(Mutator):

	def __init__(self, cdr):
		Mutator.__init__(self)
		self.cdr = cdr
		self.global_triggers[EventOnUnitPreAdded] = self.on_enemy_added

	def get_description(self):
		return ("Enemy Spawner health multiplied by 2 and spell cool downs decreased by {cdr}", {'cdr': self.cdr})

	def on_enemy_added(self, evt):
		if not evt.unit.ever_spawned:
			self.modify_unit(evt.unit)

	def modify_units(self, level):
		for u in level.units:
			self.modify_unit(u)

	def modify_unit(self, unit):
		if unit.team == TEAM_PLAYER:
			return
		if not unit.is_lair:
			return
		unit.max_hp *= 2
		unit.cur_hp *= 2
		for s in unit.spells:
			if s.cool_down:
				s.cool_down -= self.cdr

class MoreSpawners(Mutator):

	def __init__(self, val):
		Mutator.__init__(self)
		self.val = val

	def get_description(self):
		return ("Levels have {val} more spawners in them", {'val': self.val})

	def on_levelgen_pre(self, levelgen):
		levelgen.num_generators += self.val


class FewerSpawners(Mutator):

	def __init__(self, val):
		Mutator.__init__(self)
		self.val = val

	def get_description(self):
		return ("Levels have {val} fewer spawners in them", {'val': self.val})

	def on_levelgen_pre(self, levelgen):
		levelgen.num_generators = max(0, levelgen.num_generators -self.val)

class EnemyShields(Mutator):

	def __init__(self, shields):
		Mutator.__init__(self)
		self.shields = shields
		self.global_triggers[EventOnUnitPreAdded] = self.on_enemy_added

	def get_description(self):
		return ("All enemy units have {shields} extra SH", {'shields': self.shields})

	def on_enemy_added(self, evt):
		self.modify_unit(evt.unit)

	def modify_units(self, level):
		for u in level.units:
			self.modify_unit(u)

	def modify_unit(self, unit):
		if unit.is_lair:
			return
		if unit.team == TEAM_PLAYER:
			return
		# Do not buff the HP of splitting units
		if isinstance(unit.source, SplittingBuff):
			return
		unit.shields += self.shields

class EnemyBuff(Mutator):

	def __init__(self, buff, exclude_named=None):
		Mutator.__init__(self)
		self.buff = buff
		self.global_triggers[EventOnUnitAdded] = self.on_enemy_added
		self.exclude_named = exclude_named

	def get_description(self):
		return ("All enemy units have {buff}", {'buff': self.buff().name})

	def on_enemy_added(self, evt):
		self.modify_unit(evt.unit)

	def modify_units(self, level):
		for u in level.units:
			self.modify_unit(u)

	def modify_unit(self, unit):
		if unit.team != TEAM_ENEMY:
			return
		if unit.is_lair:
			return
		if unit.name == self.exclude_named:
			return

		buff = self.buff()
		buff.buff_type = BUFF_TYPE_PASSIVE
		unit.apply_buff(buff)

class RespawnAsMutator(Mutator):

	def __init__(self, monster):
		Mutator.__init__(self)
		self.monster = monster # monster constructor
		self.example_monster = self.monster()
		self.global_triggers[EventOnUnitAdded] = self.on_enemy_added

	def get_description(self):
		return ("All enemy units respawn as {monster}", {'monster': self.example_monster.name})

	def on_enemy_added(self, evt):
		self.modify_unit(evt.unit)

	def modify_units(self, level):
		for u in level.units:
			self.modify_unit(u)

	def modify_unit(self, unit):
		if unit.team != TEAM_ENEMY:
			return
		if unit.is_lair:
			return
		if unit.name == self.example_monster.name:
			return

		buff = RespawnAs(self.monster)
		buff.buff_type = BUFF_TYPE_PASSIVE
		unit.apply_buff(buff)

class EnemyResistance(Mutator):

	def __init__(self, damage_type, resistance):
		Mutator.__init__(self)
		self.damage_type = damage_type
		self.resistance = resistance
		self.global_triggers[EventOnUnitAdded] = self.on_enemy_added

	def get_description(self):
		return ("Enemies gain +{resistance}% {damage_type} resistance", {'resistance': self.resistance, 'damage_type': self.damage_type.name})

	def on_enemy_added(self, evt):
		if not evt.unit.ever_spawned: self.modify_unit(evt.unit)

	def modify_units(self, level):
		for unit in level.units:
			self.modify_unit(unit)

	def modify_unit(self, unit):
		if unit.team != TEAM_ENEMY: return
		if unit.is_lair: return
		unit.resists[self.damage_type] += self.resistance

class PlayerVulnerability(Mutator):

	def __init__(self, damage_type, resistance):
		Mutator.__init__(self)
		self.damage_type = damage_type
		self.resistance = resistance

	def get_description(self):
		return ("You lose {resistance}% {damage_type} resistance", {'resistance': self.resistance, 'damage_type': self.damage_type.name})

	def on_game_begin(self, game):
		game.p1.resists[self.damage_type] -= self.resistance

class ReactiveTeleportBuff(Buff):

	def __init__(self, radius):
		self.radius = radius
		Buff.__init__(self)

	def on_init(self):
		self.name = "Reactive Teleportation"
		self.buff_type = BUFF_TYPE_PASSIVE
		self.owner_triggers[EventOnDamaged] = self.on_damaged

	def get_description(self):
		return ("When this unit takes damage, it teleports up to {radius} tiles away", {'radius': self.radius})

	def on_damaged(self, evt):
		if not self.owner.is_alive(): return
		randomly_teleport(self.owner, self.radius)

class WeatherOption:

	def __init__(self, cloud):
		self.cloud = cloud
		self.name = cloud(None).name + "s"

weather_options = [
	WeatherOption(StormCloud),
	WeatherOption(BlizzardCloud),
	WeatherOption(RainCloud),
]

class Weather(EveryXTurnsMutator):

	def __init__(self, weather, max_clouds):
		EveryXTurnsMutator.__init__(self, 1)
		self.cloud = weather.cloud
		self.max_clouds = max_clouds
		self.cloud_name = weather.name
		self.name = "Weather"

	def get_description(self):
		return ("Each turn, {cloud_name} appear on up to {max_clouds} tiles across the level", {'cloud_name': self.cloud_name, 'max_clouds': self.max_clouds})

	def do_effect(self, level):
		if not level.has_hostile_units(): return
		tiles = [tile for tile in level.iter_tiles() if not tile.cloud and not tile.is_wall()]
		random.shuffle(tiles)
		for tile in tiles[:random.randint(1, self.max_clouds)]:
			cloud = self.cloud(level.player_unit)
			level.add_obj(cloud, tile.x, tile.y)

class DamageDebuff(Mutator):

	def __init__(self, buff):
		Mutator.__init__(self)
		self.buff = buff
		self.global_triggers[EventOnDamaged] = self.on_damaged

	def get_description(self):
		return ("When you take damage, gain {buff} for 1 turn", {'buff': self.buff().name})

	def on_damaged(self, evt):
		if not evt.unit.is_player_controlled: return
		evt.unit.apply_buff(self.buff(), 1)

class RandomEquipmentRestriction(Mutator):

	def __init__(self, chance_pct):
		Mutator.__init__(self)
		self.chance = chance_pct / 100
		self.chance_pct = chance_pct
		self.restricted_equipment = set()
		self.activated = False

	def get_description(self):
		return ("A random {pct}% of the crafting selection is removed", {'pct': self.chance_pct})

	def on_generate_equipment(self, equipment):
		if not self.activated:
			num_removed = math.ceil(self.chance * len(equipment))
			removals = list(equipment)
			self.random.shuffle(removals)
			removals = removals[:num_removed]
			self.restricted_equipment.update(s.name for s in removals)
			self.activated = True

		self.game.restricted_equipment.update(self.restricted_equipment)
		allowed = [s for s in equipment if s.name not in self.restricted_equipment]
		equipment.clear()
		equipment.extend(allowed)

	def on_game_begin(self, game):
		self.game = game
		self.restricted_equipment.clear()
		self.activated = False

class RandomSpellRestriction(Mutator):

	def __init__(self, chance_pct):
		Mutator.__init__(self)		
		self.chance = chance_pct / 100
		self.chance_pct = chance_pct
		self.restricted_spells = set()
		self.activated = False

	def on_game_begin(self, game):
		self.game = game
		self.restricted_spells.clear()
		self.activated = False

	def get_description(self):
		return ("A random {pct}% of the spellbook is removed", {'pct': self.chance_pct})

	def on_generate_spells(self, spells):
		if not self.activated:
			starters = [s for s in spells if s.level < 2]

			num_removed = math.ceil(self.chance * len(spells))
			removals = list(spells)
			self.random.shuffle(removals)
			removals = removals[:num_removed]
			kept = [s for s in spells if s not in removals]

			# Ensure that atleast 1 level 1 spell is present
			if starters and not any(s in kept for s in starters):
				removals.remove(self.random.choice(starters))

			self.restricted_spells.update(type(s) for s in removals)
			self.activated = True

		self.game.restricted_spells.update(self.restricted_spells)
		allowed = [s for s in spells if type(s) not in self.restricted_spells]
		spells.clear()
		spells.extend(allowed)

class SpellTagRestriction(Mutator):

	def __init__(self, tag):
		Mutator.__init__(self)
		self.tag = tag

	def get_description(self):
		return ("Only spells that have the [{tag_label}:{tag_key}] tag can be learned", {'tag_label': tag_label(self.tag), 'tag_key': tag_key(self.tag)})

	def on_generate_spells(self, spells):
		allowed = [s for s in spells if self.tag in s.tags]
		spells.clear()
		spells.extend(allowed)

class EquipmentTagRestriction(Mutator):

	def __init__(self, tag):
		Mutator.__init__(self)
		self.tag = tag

	def get_description(self):
		return ("Only equipment that has the [{tag_label}:{tag_key}] tag can be crafted", {'tag_label': tag_label(self.tag), 'tag_key': tag_key(self.tag)})

	def on_generate_equipment(self, equipment):
		allowed = [item for item in equipment if self.tag in item.tags]
		equipment.clear()
		equipment.extend(allowed)

class CharacterSwap(Mutator):

	def __init__(self, asset_name):
		Mutator.__init__(self)
		self.player_asset_replace = asset_name

	def on_game_begin(self, game):
		game.p1.asset_name = self.player_asset_replace

class WardrobeOutfit():

	def __init__(self, asset_name, name, unlock_achievement=None, unlock_desc=None):
		self.name = name
		self.asset_name = asset_name
		self.unlock_achievement = unlock_achievement
		self.description = unlock_desc

# asset_name, player facing name, required achievement, lock description
wardrobe_outfits = [
	WardrobeOutfit('player', 'Wizard'),

	WardrobeOutfit('pyromancer', 'Pyromancer', 'PYROMANCER', 'Complete the Pyromancer trial'),
	WardrobeOutfit('electromancer', 'Electromancer', 'ELECTROMANCER', 'Complete the Electromancer trial'),
	WardrobeOutfit('cryomancer', 'Cryomancer', 'CRYOMANCER', 'Complete the Cryomancer trial'),
	WardrobeOutfit('necromancer', 'Necromancer', 'NECROMANCER', 'Complete the Necromancer trial'),
	WardrobeOutfit('phytomancer', 'Phytomancer', 'PHYTOMANCER', 'Complete the Phytomancer trial'),
	WardrobeOutfit('manamancer', 'Manamancer', 'MANAMANCER', 'Complete the Manamancer trial'),
	WardrobeOutfit('sanctumancer', 'Sanctumancer', 'SANCTUMANCER', 'Complete the Sanctumancer trial'),
	WardrobeOutfit('ferromancer', 'Ferromancer', 'FERROMANCER', 'Complete the Ferromancer trial'),
	WardrobeOutfit('hemomancer', 'Hemomancer', 'HEMOMANCER', 'Complete the Hemomancer trial'),
	WardrobeOutfit('player_time_keeper', 'Chronomancer', 'CHRONOMANCER', 'Complete the Chronomancer trial'),
	WardrobeOutfit('mordred', 'Mordred', 'MORDREDS_VENGEANCE', "Complete the Mordred's Vengeance trial"),

	WardrobeOutfit('player_goblin', 'Goblin', 'VAULT_GOBLIN_VAULT', 'Complete the Vault of Goblins'),
	WardrobeOutfit('player_spider', 'Spider', 'VAULT_SPIDERS_LAIR', 'Complete the Vault of Arachnea'),
	WardrobeOutfit('player_slime', 'Slime', 'VAULT_SLIME_RIVER', 'Complete the Vault of Slime'),
	WardrobeOutfit('player_polar_bear', 'Ursine', 'VAULT_ICE_VAULT', 'Complete the Vault of Glaciers'),
	WardrobeOutfit('player_red_wyrm', 'Wyrm', 'VAULT_LAVA_CROSSROADS', 'Complete the Vault of Flame'),
	WardrobeOutfit('player_soul_skull', 'Soulbound', 'VAULT_VAULT_OF_SOULS', 'Complete the Vault of Souls'),
	WardrobeOutfit('player_watcher', 'Observer', 'VAULT_TEMPEST_SPIRE', 'Complete the Vault of Tempests'),
	WardrobeOutfit('player_faery', 'Faery', 'VAULT_FAERY_PRISON', 'Complete the Vault of the Fettered Fae'),
	WardrobeOutfit('player_idol', 'Idol', 'VAULT_SCULPTORS_WORKSHOP', 'Complete the Vault of the Sculptor'),
	WardrobeOutfit('player_demon_prince', 'Prince', 'VAULT_VAULT_OF_TORMENT', 'Complete the Vault of Torment'),

	WardrobeOutfit('player_archangel', 'Archangel', 'ARCHANGEL_SET', 'Win while wearing every piece of the Archangel equipment'),
	WardrobeOutfit('player_crimson', 'Crimson', 'CRIMSON_SET', 'Win while wearing every piece of the Crimson equipment'),
	WardrobeOutfit('player_dragonlord', 'Dragonlord', 'DRAGON_SET', 'Win while wearing Chaos Scale Crown, Dragonspine Cloak, Drakenstaff, and Wyrm Spirit Armor'),
	WardrobeOutfit('player_galvanic', 'Galvanic', 'GALVANIC_SET', 'Win while wearing every piece of the Galvanic equipment'),
	WardrobeOutfit('player_hellfire', 'Hellfire', 'HELLFIRE_SET', 'Win while wearing Hellfire Mantle and Ghostfire Scepter'),
	WardrobeOutfit('player_plague_doctor', 'Plague Doctor', 'PLAGUE_SET', 'Win while wearing every piece of the Plague Doctor equipment'),
	WardrobeOutfit('player_twilight', 'Twilight', 'TWILIGHT_SET', 'Win while wearing every piece of the Twilight equipment'),
	WardrobeOutfit('player_virtuous_sin', 'Virtuous Sin', 'VIRTUOUS_SET', 'Win while wearing every piece of the Virtuous Sin equipment'),
	WardrobeOutfit('player_warlord', 'Warlord', 'WARLORD_SET', 'Win while wearing every piece of the Warlord equipment'),
	WardrobeOutfit('player_eldritch_mantle', 'Eldritch', 'ELDRITCH_SET', 'Win while wearing Eldritch Mantle and Skybreaker Array'),
	WardrobeOutfit('player_chaos', 'Ruinous', 'RUINOUS_SET', 'Win while wearing Codex of Chaotic Evolution, Prism of Shattered Sensations, Cyst of Eternal Bloom, and Orb of Infinite Slaughter'),
	WardrobeOutfit('player_dream_thief', 'Dream Walker', 'DREAMING_SET', "Win while wearing Dream Thief Diadem, Psychopomp Staff, and Hypno Bauble"),
	WardrobeOutfit('player_enchanter', 'Enchanter', 'ENCHANTER_SET', "Win while wearing Talking Hat and Enchantment Staff"),
	WardrobeOutfit('player_eye_mage', 'Gazing', 'GAZING_SET', "Win while wearing Eye Helm, Balor's Eye Staff, and Raiment of Eyes"),
	WardrobeOutfit('player_slime_mage', 'Oozing', 'OOZING_SET', "Win while wearing Slimebirth Cantromancy, Macrophagic Mask, and Slimy Voodoo Mantle"),
	WardrobeOutfit('player_chess', 'Chess', 'CHESS_SET', "Win while wearing Bishop Boots and Castellan Clogs"),

	WardrobeOutfit('player_angel_tamer', 'Angel Tamer', 'ANGEL_TAMER', "Win while wearing Arbiter Cage"),

	WardrobeOutfit('player_gunslinger', 'Gunslinger', 'PERFECTED_BLOOD_BULLET', 'Win with a fully upgraded Blood Bullet'),
	WardrobeOutfit('player_skeleton', 'Skelemage', 'PERFECTED_DEATH_BOLT', 'Win with a fully upgraded Death Bolt'),
	WardrobeOutfit('player_golden_skull', 'Skull', 'PERFECTED_GOLDEN_SKULL', 'Win with a fully upgraded Golden Skull'),
	WardrobeOutfit('player_leghead', 'Leghead', 'PERFECTED_LEGHEAD', 'Win with a fully upgraded Leghead'),
	WardrobeOutfit('player_gnome', 'Gnome', 'PERFECTED_PRISON_OF_THORNS', 'Win with a fully upgraded Prison of Thorns'),
	WardrobeOutfit('player_carnival_of_pain', 'Ringmaster', 'PERFECTED_CARNIVAL', 'Win with a fully upgraded Carnival of Pain'),
	WardrobeOutfit('player_starswimmer', 'Dreamer', 'PERFECTED_STARWHALE', 'Win with a fully upgraded Dream the Starwhale'),
	WardrobeOutfit('player_crab', 'Scuttler', 'PERFECTED_TORRENT', 'Win with a fully upgraded Torrent'),
	WardrobeOutfit('player_death', 'Death Mage', 'PERFECTED_WHEEL_OF_DEATH', 'Win with a fully upgraded Wheel of Death'),
	WardrobeOutfit('player_immolate', 'Flaming', 'PERFECTED_IMMOLATE', 'Win with a fully upgraded Immolate'),
	WardrobeOutfit('player_prismatic_beam', 'Prism', 'PERFECTED_PRISMATIC_BEAM', 'Win with a fully upgraded Prismatic Beam'),
	WardrobeOutfit('player_spikeball', 'Spikeball', 'PERFECTED_SPIKEBALL_FACTORY', 'Win with a fully upgraded Spikeball Factory'),


	WardrobeOutfit('player_dagger', 'Dagger', 'RIFT_OF_FLYING_DAGGERS', 'Unleash over 1000 daggers'),

	WardrobeOutfit('player_pumpkin', 'Pumpkin', 'PUMPKING', 'Defeat The Great Pumpking'),
	WardrobeOutfit('player_haetae_golem', 'Haetae', 'HAETAE', 'Defeat Haetae Golem'),
	WardrobeOutfit('player_blood_beast', 'Blood Beast', 'TAUROKELEVEE', 'Defeat Taurokelevee'),
	WardrobeOutfit('player_skull_hornet_queen', 'Skull Queen', 'SKULL_QUEEN', 'Defeat Skull Hornet Queen'),
	WardrobeOutfit('player_ultimate_troubler', 'Big Trouble', 'ULTIMATE_TROUBLER', 'Defeat Ultimate Troubler'),
	WardrobeOutfit('player_yggdrasil', 'Yggdrasil', 'YGGDRASIL', 'Defeat Yggdrasil'),
	WardrobeOutfit('player_flesh_colossus', 'Fleshy', 'FLESH_COLOSSUS', 'Defeat Flesh Colossus'),
	WardrobeOutfit('player_giant_nightmare_turtle', 'Turtle', 'NIGHTMARE_TURTLE', 'Defeat Giant Nightmare Turtle'),
	WardrobeOutfit('player_mothgod', 'Moth', 'MOTHGOD', 'Defeat Mothgod'),
	WardrobeOutfit('player_molten_devourer', 'Molten', 'MOLTEN_DEVOURER', 'Defeat Molten Devourer'),

	WardrobeOutfit('player_bafflement', 'Bafflement', 'BAFFLEMENT', 'Defeat Bafflement'),
	WardrobeOutfit('player_ophan', 'Ophan', 'OPHAN', 'Defeat Ophan'),
	WardrobeOutfit('player_insanity_queen', 'Insanity Queen', 'INSANITY_QUEEN', 'Defeat Insanity Queen'),
	WardrobeOutfit('player_jormungandr', 'Jormungandr', 'JORMUNGANDR', 'Defeat Jormungandr'),
	WardrobeOutfit('player_frog_pope', 'Pope', 'POPE', 'Defeat Pope the Frog'),
	WardrobeOutfit('player_yaldabaoth', 'Yaldabaoth', 'YALDABAOTH', 'Defeat Yaldabaoth'),
	WardrobeOutfit('player_the_gardener', 'Gardener', 'GARDENER', 'Defeat The Gardener'),
	WardrobeOutfit('player_gaia', 'Gaia', 'GAIA', 'Defeat Gaia'),
	WardrobeOutfit('player_ice_queen', 'Snow Queen', 'SNOW_QUEEN', 'Defeat Snow Queen'),
	WardrobeOutfit('player_the_body_electric', 'The Body Electric', 'BODY_ELECTRIC', 'Defeat The Body Electric'),
	WardrobeOutfit('player_amaru', 'Amaru', 'AMARU', 'Defeat Amaru'),
	WardrobeOutfit('player_blood_lush', 'Hierophant', 'SANGUINE_HIEROPHANT', 'Defeat Sanguine Hierophant'),

	WardrobeOutfit('player_mutual_destruction', 'Split Wizard', 'MUTUAL_DESTRUCTION', 'Defeat Mordred while falling to 0 HP'),
	WardrobeOutfit('player_friendship', 'Friendship', 'FRIENDSHIP', 'Make Mordred your ally'),

	WardrobeOutfit('player_rift', 'Wizard Rift', 'GAMBLING_WIZARD', 'Win after rerolling every realm'),
	WardrobeOutfit('player_vault', 'Vault Seeker', 'ALL_VAULTS', 'Defeat every vault'),

	WardrobeOutfit('player_orb', 'Memory', 'REMEMBERER', 'Win with exactly 1 unspent SP'),
	WardrobeOutfit('player_clown', 'Clown', 'CAST_CHAIN_CAP', 'Create an infinite spell cast loop'),
	WardrobeOutfit('player_flame_streaker', 'Unquenchable Flame', 'IMPROVISER_STREAK_TEN', 'Win 10 Improviser runs in a row'),

]

def register_outfit(asset_name, name, unlock_achievement=None, unlock_desc=None):
	outfit = WardrobeOutfit(asset_name, name, unlock_achievement, unlock_desc)
	for i, existing in enumerate(wardrobe_outfits):
		if existing.asset_name == asset_name:
			wardrobe_outfits[i] = outfit
			return outfit
	wardrobe_outfits.append(outfit)
	return outfit

def get_wardrobe_outfit(asset_name):
	for outfit in wardrobe_outfits:
		if outfit.asset_name == asset_name: return outfit
	return None

class SpellLevelRestriction(Mutator):

	def __init__(self, val):
		Mutator.__init__(self)
		self.val = val

	def get_description(self):
		return ("Only level {level} spells", {'level': self.val})

	def on_generate_spells(self, spells):
		allowed = [s for s in spells if s.level == self.val]
		spells.clear()
		spells.extend(allowed)

class SpellTagElimination(Mutator):

	def __init__(self, tag):
		Mutator.__init__(self)
		self.tag = tag

	def get_description(self):
		return ("All [{tag_label}:{tag_key}] spells removed", {'tag_label': tag_label(self.tag), 'tag_key': tag_key(self.tag)})

	def on_generate_spells(self, spells):
		allowed = [s for s in spells if self.tag not in s.tags]
		spells.clear()
		spells.extend(allowed)

class SpellLevelElimination(Mutator):

	def __init__(self, val):
		Mutator.__init__(self)
		self.val = val

	def get_description(self):
		return ("All level {level} spells removed", {'level': self.val})

	def on_generate_spells(self, spells):
		allowed = [s for s in spells if s.level != self.val]
		spells.clear()
		spells.extend(allowed)

class BonusRerolls(Mutator):

	def __init__(self, val):
		Mutator.__init__(self)
		self.val = val
		self.global_triggers[EventOnLevelComplete] = self.on_level_complete
		self.game = None

	def get_description(self):
		return ("{val} extra rift rerolls on level completion", {'val': self.val})

	def on_level_complete(self, _level):
		self.game.rift_rerolls += self.val

	def on_game_begin(self, game):
		self.game = game

class BonusComponentTagAppearance(Mutator):

	def __init__(self, tag, val):
		Mutator.__init__(self)
		self.val = val
		self.tag = tag

	def on_level_reward(self, levelgen, reward, prng, player):
		if not levelgen.components: return reward # nothing to swap if no components
		if prng.random() > (self.val / 100): return reward # chance failed to manipulate component list
		i = prng.randint(0, len(levelgen.components) - 1)
		c = levelgen.components[i]
		levelgen.components[i] = roll_random_component(prng, tier=len(c.tags), tag_req=self.tag)()
		return reward

class Amnesiac(Mutator):

	def __init__(self):
		Mutator.__init__(self)
		self.description = ("Your spells and spell upgrades are removed and no longer available after you complete a level\n"
							"Spent SP is refunded")
		self.global_triggers[EventOnLevelComplete] = self.on_level_complete
		self.game = None

	def on_level_complete(self, _level):

		if self.game.p1: # if there's a wizard
			wizard = self.game.p1 # grab wizard unit

			for upgrade in wizard.get_spell_upgrades(): # for each spell upgrade the wizard has
				wizard.xp += upgrade.level # refund
				wizard.remove_buff(upgrade) # unlearn the upgrade

			for spell in wizard.spells: # for each of their spells
				self.game.restricted_spells.add(type(spell)) # add to restricted list, store on game for save / load persistence
				wizard.xp += spell.level # refund
				wizard.remove_spell(spell) # unlearn the spell

			self.game.all_player_spells = [spell for spell in self.game.all_player_spells if not type(spell) in self.game.restricted_spells] # make restricted spells unavailable

	def on_game_begin(self, game):
		self.game = game # grab the game instance

class MemoryLeak(Mutator):

	def __init__(self):
		Mutator.__init__(self)
		self.description = ("One of your spells is randomly removed and no longer available after you complete a level\n"
							"Spent SP is refunded")
		self.global_triggers[EventOnLevelComplete] = self.on_level_complete
		self.game = None

	def on_level_complete(self, _level):

		if self.game.p1: # if there's a wizard
			wizard = self.game.p1 # grab wizard unit
			if len(wizard.spells) < 1: return
			s = random.choice(wizard.spells)

			for upgrade in wizard.get_spell_upgrades(): # for each spell upgrade the wizard has
				if upgrade.prereq == s:
					wizard.xp += upgrade.level # refund
					wizard.remove_buff(upgrade) # unlearn the upgrade

			self.game.restricted_spells.add(type(s)) # add the spell type to the restricted set
			wizard.xp += s.level # refund
			wizard.remove_spell(s) # unlearn the spell

			self.game.all_player_spells = [spell for spell in self.game.all_player_spells if not type(spell) in self.game.restricted_spells] # make restricted spells unavailable

	def on_game_begin(self, game):
		self.game = game # grab the game instance

# class WildMagic(Mutator):
#
# 	def __init__(self):
# 		Mutator.__init__(self)
# 		self.description = ("After you complete a level or reroll rifts, your spells and skills are randomly rerolled\n"
# 							"Levels have no SP")
# 		self.global_triggers[EventOnLevelComplete] = self.on_level_complete
# 		self.global_triggers[EventOnReroll] = self.on_level_complete # rerolls spells/skills on rift reroll
# 		self.game = None
#
# 	def on_level_complete(self, _evt):
# 		if not self.game.p1: # if there's no wizard
# 			return
#
# 		wizard = self.game.p1 # grab wizard unit
#
# 		for buff in wizard.buffs[:]:
# 			if buff.buff_type == BUFF_TYPE_PASSIVE: # covers Skills and SpellUpgrades
# 				wizard.remove_buff(buff)
#
# 		wizard.spells.clear() # get rid of spells
#
# 		wizard_spell_tags = set() # set up for skill synergy mercy
#
# 		spells = all_player_spell_constructors # grab all the spells
# 		random.shuffle(spells) # shuffle em up
#
# 		level_num = self.game.cur_level.level_no
# 		min_spells = max(3, (level_num * 1) // 3)
# 		max_spells = min(12, (level_num * 2) // 3)
#
# 		if min_spells > max_spells:
# 			num_spells = 3
# 		else:
# 			num_spells = random.randint(min_spells, max_spells) # average is half the level's number of spells
#
# 		while len(wizard.spells) < num_spells:
# 			for spell in spells: # for each one
# 				new_spell = spell() # instantiate
#
# 				if new_spell.hp_cost >= wizard.max_hp: # don't want spells they can't pay for
# 					continue
#
# 				wizard.add_spell(new_spell) # give it to the wizard
# 				wizard_spell_tags.update(new_spell.tags) # track what tags the wizard has for this level
#
# 				if new_spell.spell_upgrades: # if the spell has upgrades
# 					wizard.apply_buff(random.choice(new_spell.spell_upgrades)) # give it an upgrade
#
# 				if len(wizard.spells) >= num_spells: # get out if we have the right number of spells
# 					break
#
# 		wizard.spells.sort(key=lambda s: s.level) # QoL sort spells so lowest level spells at the top
#
# 		skills = [s for s in skill_constructors if any(tag in wizard_spell_tags for tag in s().tags)] # only grab skills with tags matching our spells
# 		random.shuffle(skills) # shuffle em up
#
# 		num_skills = random.randint((level_num  // 2), level_num) # average num_skills = level_num * .75
# 		num_skills += ((level_num // 2) - num_spells) # more or less spells than average grants more or less skills
# 		num_skills = max(1, num_skills) # don't want negative slicing for early levels giving a boatload of skills
#
# 		skills = skills[:num_skills] # only take as many as we want
# 		for skill in skills: # for each skill
# 			new_skill = skill() # instantiate it
# 			wizard.apply_buff(new_skill) # give it to the wizard
#
# 	def on_game_begin(self, game):
# 		self.game = game # grab the game instance
# 		game.p1.xp = 0
# 		game.p1.add_spell(self.get_random_cantrip())
#
# 	def get_random_cantrip(self):
# 		cantrips = [s for s in all_player_spell_constructors if s().level == 1]
# 		return random.choice(cantrips)()
#
# 	def on_levelgen_pre(self, levelgen):
# 		levelgen.num_xp = 0 # no SP
#
# 		if levelgen.shrine and levelgen.shrine.name == "Scroll of Spells": # replace spell scrolls since they'd be forgotten anyway
# 			levelgen.shrine = exotic_pet_chest(levelgen.difficulty, levelgen.random, player=None)
# 		if levelgen.shrine and levelgen.shrine.name == "Scroll of Skills": # replace skill scrolls since they'd be forgotten anyway
# 			levelgen.shrine = HeartDot(25)

class SpawnWizards(Mutator):

	def __init__(self):
		Mutator.__init__(self)
		self.description = "Each level beyond the first contains an extra enemy wizard"

	def on_levelgen_pre(self, levelgen):
		if levelgen.difficulty == 1: return
		wizards = RareMonsters.get_rare_spawn_options(levelgen.difficulty, group=RareMonsters.WIZARDS)
		if not wizards: return
		wizard = self.random.choice(wizards)[0]()
		levelgen.bosses.append(wizard)
				
class SpPerLevel(Mutator):

	def __init__(self, num):
		Mutator.__init__(self)
		self.num = num

	def get_description(self):
		if self.num < 3: return ("Levels contain only {num} SP orbs", {'num': self.num})
		else: return ("Levels contain {num} SP orbs", {'num': self.num})

	def on_levelgen_pre(self, levelgen):
		levelgen.num_xp = self.num

class SpPenalty(Mutator):

	def __init__(self, num):
		Mutator.__init__(self)
		self.num = num

	def get_description(self):
		return ("Levels have {num} fewer Memory Orbs", {'num': self.num})

	def on_levelgen_pre(self, levelgen):
		levelgen.num_xp -= self.num

class SpBonus(Mutator):

	def __init__(self, num):
		Mutator.__init__(self)
		self.num = num

	def get_description(self):
		return ("Levels have {num} more SP orbs", {'num': self.num})

	def on_levelgen_pre(self, levelgen):
		levelgen.num_xp += self.num

class Trial():

	def __init__(self, name, mutators):
		self.name = name
		if isinstance(mutators, list):
			self.mutators = mutators
		elif isinstance(mutators, Mutator):
			self.mutators = [mutators]
		else:
			assert(False)

	def get_description(self):
		return "\n".join(resolve_text(m.get_description(), fmt=m.fmt_dict()) for m in self.mutators)

class ExtraElites(Mutator):

	def __init__(self, num):
		Mutator.__init__(self)
		self.num = num

	def get_description(self):
		return ("Each level has {num} extra random high level monsters", {'num': self.num})

	def on_levelgen_pre(self, levelgen):
		for i in range(self.num):
			unit = levelgen.get_elites()[0]
			levelgen.bosses.append(unit)

class SpellStatMultiplier(Mutator):

	def __init__(self, stat, mult_pct):
		Mutator.__init__(self)
		self.stat = stat
		self.mult = mult_pct / 100
		self.mult_pct = mult_pct

	def get_description(self):
		return ("Spells have {pct}% {stat}", {'pct': self.mult_pct, 'stat': self.stat.replace('_', ' ')})

	def on_generate_spells(self, spells):
		for s in spells:
			if hasattr(s, self.stat):
				setattr(s, self.stat, math.ceil(getattr(s, self.stat) * self.mult))
				if self.stat == 'max_charges':
					s.cur_charges = s.max_charges

class SpellCooldowns(Mutator):

	def __init__(self, cd):
		Mutator.__init__(self)
		self.cd = cd

	def get_description(self):
		return ("The Wizard's spells have a {cd} turn cool down", {'cd': self.cd})

	def on_generate_spells(self, spells):
		for s in spells: s.cool_down = self.cd

class SpellHPCostAdd(Mutator):

	def __init__(self, cost):
		Mutator.__init__(self)
		self.cost = cost

	def get_description(self):
		return ("Each spell has +{cost} HP cost", {'cost': self.cost})

	def on_generate_spells(self, spells):
		for s in spells: s.hp_cost += self.cost

class Attrition(Mutator):

	def __init__(self, val):
		Mutator.__init__(self)
		self.val = val
		self.global_triggers[EventOnLevelComplete] = self.attrition
		self.game = None

	def get_description(self):
		return ("At the end of each level, lose {val} max HP", {'val': self.val})

	def attrition(self, _):
		self.game.p1.max_hp = max(1, self.game.p1.max_hp - self.val)
		self.game.p1.cur_hp = self.game.p1.max_hp

	def on_game_begin(self, game):
		self.game = game

# class Corrupted(Mutator):
#
# 	def __init__(self):
# 		Mutator.__init__(self)
# 		self.description = "Corrupts the level on completion"
# 		self.global_triggers[EventOnLevelComplete] = self.on_complete
# 		self.game = None
#
# 	def on_complete(self, _):
# 		wizard = self.game.p1
# 		s = OrbCorruption()
# 		s.owner = wizard
# 		s.caster = wizard
# 		wizard.level.act_cast(wizard, s, wizard.x, wizard.y, pay_costs=False)
#
# 	def on_game_begin(self, game):
# 		self.game = game

class ExtraSpawns(Mutator):

	def __init__(self, spawn, num_extra):
		Mutator.__init__(self)
		self.spawn = spawn
		self.num_extra = num_extra

	def get_description(self):
		return ("Levels beyond the first contain {num_extra} extra {monster} units", {'num_extra': self.num_extra, 'monster': self.spawn().name})

	def on_levelgen(self, levelgen):
		if levelgen.difficulty == 1:
			return

		for i in range(self.num_extra):
			if not levelgen.empty_spawn_points:
				break
			obj = self.spawn()
			spawn_point = levelgen.empty_spawn_points.pop()
			levelgen.level.add_obj(obj, spawn_point.x, spawn_point.y)

class SpawnTagBias(Mutator):

	def __init__(self, tag, chance):
		Mutator.__init__(self)
		self.tag = tag
		self.chance = chance

	def get_description(self):
		return ("More likely to encounter [{tag_label}:{tag_key}] enemies", {'tag_label': tag_label(self.tag), 'tag_key': tag_key(self.tag)})

	def on_levelgen_pre(self, levelgen):
		if levelgen.random.random() > self.chance: return
		min_level, max_level = get_spawn_min_max(levelgen.difficulty)
		options = [m for m in tagged_spawn_options.get(self.tag, []) if min_level <= m[1] <= max_level]
		if not options: return
		primary, p_lvl, _ = levelgen.random.choice(options)
		levelgen.primary_spawn = primary
		if levelgen.difficulty > 1:
			secondary, s_lvl, _ = levelgen.random.choice(options)
			levelgen.secondary_spawn = secondary

class ExtraTagLairs(Mutator):

	def __init__(self, tag, amt):
		Mutator.__init__(self)
		self.tag = tag
		self.amt = amt

	def get_description(self):
		return ("Realms contain an additional {amt} [{tag_label}:{tag_key}] lairs", {'amt': self.amt, 'tag_label': tag_label(self.tag), 'tag_key': tag_key(self.tag)})

	def on_levelgen_pre(self, levelgen):
		min_level, max_level = get_spawn_min_max(levelgen.difficulty)
		options = [m for m in tagged_spawn_options.get(self.tag, [])]
		if not options: return
		chosen = None

		while not chosen: # sometimes there are no monsters at the difficulty level range desired, but we still need a spawner
			chosen = [m for m in options if min_level <= m[1] <= max_level]
			if chosen: break
			if min_level == 1 and max_level == 9: return  # (searched everything, failed to find a valid monster)
			min_level = max(1, min_level -1)
			max_level = min(9, max_level + 1)

		chosen = levelgen.random.choice(chosen)[0]
		for i in range(self.amt): levelgen.bosses.append(MonsterSpawner(chosen))

class OneSpell(Mutator):

	def __init__(self):
		Mutator.__init__(self)
		self.description = "Spells are free, but only one can be purchased"
		self.global_triggers[EventOnLevelComplete] = self.on_complete
		self.chosen = False
		self.game = None

	def on_game_begin(self, game):
		game.max_spells = 1
		game.free_spells = True
		self.game = game
		self.chosen = False

	def on_complete(self, _):
		if self.chosen: return
		if self.game.p1: # if there's a wizard
			wizard = self.game.p1 # grab wizard unit
			if not wizard.spells: return
			for s in self.game.all_player_spells:
				if s not in wizard.spells:
					self.game.restricted_spells.add(type(s))  # add the spell to the restricted set
			self.game.all_player_spells = wizard.spells[:] # remove the other spells at the end of the first level, assuming they've bought one.
			self.chosen = True


class GiantSlayer(Mutator):

	def __init__(self):
		Mutator.__init__(self)
		self.description = "Each level beyond the 4th has an additional giant monster"

	def on_levelgen_pre(self, levelgen):
		if levelgen.difficulty <= 4: return
		beasts = RareMonsters.get_rare_spawn_options(levelgen.difficulty, group=RareMonsters.KAIJU)
		if not beasts: return
		unit = levelgen.random.choice(beasts)[0]()
		print(unit.name)
		levelgen.bosses.append(unit)

class FixedRewards(Mutator):

	def __init__(self, reward):
		Mutator.__init__(self)
		self.reward = reward

	def get_description(self):
		return ("Every level reward is a {reward}", {'reward': self.reward})

	def on_game_begin(self, game):
		game.keep_level_reward(reward_dict[self.reward][0])

class AdventuringParty(Mutator):

	def __init__(self):
		Mutator.__init__(self)
		self.description = ("When one of your companions dies, they leave your party for good")
		self.global_triggers[EventOnDeath] = self.on_death

	def on_death(self, evt):
		source = evt.unit.source
		if not source or not isinstance(source, Companion): return # only care about companions
		if evt.unit.has_buff(ReincarnationBuff): return # don't remove if they're not actually dead
		if source.name != evt.unit.name: return # don't want to remove if it's one of their summons i.e. engineer
		if source in self.game.p1.equipment: self.game.p1.unequip(source) # remove equip

	def on_game_begin(self, game):
		self.game = game

class RemoveRewards(Mutator):

	def __init__(self, reward):
		Mutator.__init__(self)
		self.reward = reward

	def get_description(self):
		return ("Levels will not contain {reward} rewards", {'reward': self.reward})

	def on_game_begin(self, game):
		game.remove_level_rewards([reward_dict[self.reward][0]])

class RemoveMultipleRewards(Mutator):

	def __init__(self, rewards):
		Mutator.__init__(self)
		self.removed_rewards = rewards

	def get_description(self):
		return ""

	def on_game_begin(self, game):
		game.remove_level_rewards(self.removed_rewards)

class WildMagic(Mutator):

	def __init__(self):
		Mutator.__init__(self)
		self.description = "After you complete a level or reroll rifts, your spells are randomly rerolled\nLevels contain no Memory Orbs"
		self.global_triggers[EventOnLevelComplete] = self.on_level_complete
		self.global_triggers[EventOnReroll] = self.on_level_complete
		self.game = None

	def on_level_complete(self, _evt):
		if not self.game.p1: return
		wizard = self.game.p1
		level_num = self.game.cur_level.level_no

		for buff in wizard.buffs[:]:
			if isinstance(buff, Upgrade):
				wizard.remove_buff(buff)
		wizard.spells.clear()

		all_spells = [s for s in self.game.all_player_spells if s.hp_cost < wizard.max_hp]
		num_spells = min(len(all_spells), min(10, max(level_num, 3)))
		spells = self.game.cur_level.random.sample(all_spells, num_spells)
		for spell in spells: wizard.add_spell(type(spell)())

		all_upgrades = [u for s in wizard.spells for u in s.spell_upgrades]
		num_upgrades = min(len(all_upgrades), level_num * 2)
		upgrades = self.game.cur_level.random.sample(all_upgrades, num_upgrades)
		for u in upgrades: wizard.apply_buff(u)

		wizard.spells.sort(key=lambda s: s.level) # QoL sort spells so lowest level spells at the top

	def on_game_begin(self, game):
		self.game = game # grab the game instance
		game.p1.xp = 0
		game.p1.add_spell(self.get_random_cantrip())

	def get_random_cantrip(self):
		cantrips = [s for s in all_player_spell_constructors if s().level == 1]
		return random.choice(cantrips)()

	def on_levelgen_pre(self, levelgen):
		levelgen.num_xp = 0

class BloodRites(Mutator):

	def __init__(self):
		Mutator.__init__(self)
		self.description = ("Each time you cast a spell, increase its HP cost by its spell level\n"
							"If it doesn't have an HP cost, it gains one\n"
							"Resets at the end of each level")
		self.global_triggers[EventOnSpellCast] = self.on_cast
		self.global_triggers[EventOnLevelComplete] = self.on_level_complete
		self.hp_cost_increases = defaultdict(int)
		self.game = None

	def on_cast(self, evt):
		if evt.caster.is_player_controlled and hasattr(evt.spell, 'level'):
			evt.spell.hp_cost += evt.spell.level
			self.hp_cost_increases[evt.spell] += evt.spell.level

	def on_level_complete(self, evt):
		for spell, hp_cost in self.hp_cost_increases.items():
			spell.hp_cost -= hp_cost
		self.hp_cost_increases.clear()

	def on_game_begin(self, game):
		self.game = game

class Flawless(Mutator):

	def __init__(self):
		Mutator.__init__(self)
		self.description = "You have 1 HP\nYour maximum HP cannot be increased"
		self.global_triggers[EventOnItemPickup] = self.on_pickup

	def on_pickup(self, evt):
		# override components that alter max_hp
		self.game.cur_level.queue_spell(self.hp_clamp())

	def hp_clamp(self):
		self.game.p1.max_hp = 1
		self.game.p1.cur_hp = 1
		yield

	def on_game_begin(self, game):
		game.p1.max_hp = 1
		game.p1.cur_hp = 1
		self.game = game

class Chronomancer(Mutator):

	def __init__(self, minutes=10):
		Mutator.__init__(self)
		self.minutes = minutes

	def get_description(self):
		return ("You have {minutes} minutes to finish the run\nYour clock ticks while the game awaits your input\nIf time runs out, you die", {'minutes': self.minutes})

	def on_game_begin(self, game):
		game.chronomancer_time_left_ds = self.minutes * 60 * 10
		game.chronomancer_ms_carry_ds = 0

class MordredsVengeance(Mutator):

	def __init__(self):
		Mutator.__init__(self)
		self.description = ("Mordred himself will design your rifts\n"
							"There is only one path forward\n"
							"You will fall")
		self.game = None
		self.mastery_map = None
		self.damage_map = None
		self.last_updated = None

		self.spell_tags_to_damage = {Tags.Blood:(Tags.Dark, Tags.Physical), Tags.Nature:(Tags.Poison, Tags.Physical), Tags.Chaos:(Tags.Physical, Tags.Fire, Tags.Lightning), Tags.Metallic:(Tags.Physical,)}

		self.pick_random_chance = .5
		self.pick_threshold_pct = 50
		self.pick_min_choices = 8

		self.normal_spawn_cache = []
		self.rare_spawn_cache = []

		self.global_triggers[EventOnLevelComplete] = self.on_level_complete

	def update_maps(self, level):
		mastery_map = defaultdict(int)
		damage_map = defaultdict(int)

		for t in spell_tags:
			mastery = self.game.p1.get_mastery(t)
			mastery_map[t] = mastery

			if t in damage_tags: damage_map[t] += mastery

			elif t in self.spell_tags_to_damage:
				entry = self.spell_tags_to_damage[t]
				for tag in entry: damage_map[tag] += (mastery // len(entry))

		self.mastery_map = mastery_map
		self.damage_map = damage_map
		self.last_updated = level

	def get_tags_to_avoid(self):
		sorted_tags = [tag for tag, _ in sorted(self.mastery_map.items(), key=lambda x: x[1], reverse=True)]
		return sorted_tags[:max(1, len(sorted_tags) // 4)]

	def score_profile(self, profile):
		return sum(self.damage_map.get(tag, 0) * resist for tag, resist in profile)

	def get_hp_score(self, unit):
		tiles = (2 * unit.radius + 1) ** 2
		hp_term = math.log1p(unit.max_hp / tiles)
		shield_term = 0.5 * math.log1p(unit.shields / tiles)
		return int(12 * (hp_term + shield_term))

	def get_scored_entries(self, entries, score_func):
		scored = []
		for entry in entries:
			score = score_func(entry)
			if score > 0: scored.append((entry, score))
		return scored

	def pick_from_scored_entries(self, levelgen, scored, force_broad_pool=False):
		if not scored: return None

		scored.sort(key=lambda x: x[1], reverse=True)
		best_score = scored[0][1]
		threshold_pct = min(80, self.pick_threshold_pct + max(0, levelgen.difficulty - 6))

		if force_broad_pool:
			acceptable_pct = max(35, threshold_pct - 25)
			min_pool = max(5, self.pick_min_choices * 2)
			viable = [(entry, score) for entry, score in scored if score * 100 >= best_score * acceptable_pct]
			if len(viable) < min_pool: viable = scored[:min(min_pool, len(scored))]
			return levelgen.random.choice([entry for entry, _ in viable])

		viable = [(entry, score) for entry, score in scored if score * 100 >= best_score * threshold_pct]
		if len(viable) < self.pick_min_choices: viable = scored[:min(self.pick_min_choices, len(scored))]
		return levelgen.random.choice([entry for entry, _ in viable])

	def get_normal_candidates(self, levelgen, used_factories=None):
		if used_factories is None: used_factories = set()
		min_level, max_level = levelgen.min_monster_level, levelgen.max_monster_level
		return [entry for entry in self.normal_spawn_cache if min_level <= entry[1] <= max_level and entry[0] not in used_factories]

	def pick_normal_entry(self, levelgen, used_factories=None):
		if not self.damage_map: return None
		entries = self.get_normal_candidates(levelgen, used_factories=used_factories)
		resist_weight = 4 + min(2, levelgen.difficulty // 7)
		scored = self.get_scored_entries(entries, lambda entry: self.score_profile(entry[3]) * resist_weight + entry[4])
		return self.pick_from_scored_entries(levelgen, scored)

	def get_rare_difficulty_bounds(self, difficulty):
		return RareMonsters.get_rare_spawn_bounds(difficulty)

	def get_rare_candidates(self, levelgen, used_factories=None, tags=None):
		if used_factories is None: used_factories = set()
		min_diff, max_diff = self.get_rare_difficulty_bounds(levelgen.difficulty)
		group = self.rare_spawn_cache

		return [entry for entry in group
				if min_diff <= entry[1] <= max_diff
				and entry[0] not in used_factories
				and (tags is None or entry[4] is None or entry[4] in tags)]

	def pick_rare_entry(self, levelgen, used_factories=None, tags=None, force_broad_pool=False):
		if not self.damage_map: return None
		if not force_broad_pool and self.pick_random_chance > 0:
			random_chance = max(.1, self.pick_random_chance - (.02 * max(0, levelgen.difficulty - 1)))
			force_broad_pool = levelgen.random.random() < random_chance
		resist_weight = 4 + min(2, levelgen.difficulty // 7)
		entry = None
		if tags is not None:
			entries = self.get_rare_candidates(levelgen, used_factories=used_factories, tags=tags)
			scored = self.get_scored_entries(entries, lambda entry: self.score_profile(entry[5]) * resist_weight + entry[6])
			entry = self.pick_from_scored_entries(levelgen, scored, force_broad_pool=force_broad_pool)
			if entry: return entry

		entries = self.get_rare_candidates(levelgen, used_factories=used_factories)
		scored = self.get_scored_entries(entries, lambda entry: self.score_profile(entry[5]) * resist_weight + entry[6])
		return self.pick_from_scored_entries(levelgen, scored, force_broad_pool=force_broad_pool)

	def pick_rare_factory(self, levelgen, used_factories=None, tags=None):
		entry = self.pick_rare_entry(levelgen, used_factories=used_factories, tags=tags)
		if entry: return entry[0]
		return None

	def reroll_spawns(self, levelgen):
		primary_spawn = levelgen.primary_spawn
		primary_elite = levelgen.primary_elite
		secondary_spawn = levelgen.secondary_spawn
		secondary_elite = levelgen.secondary_elite

		primary_entry = self.pick_normal_entry(levelgen)
		if primary_entry: primary_spawn, _, primary_elite, _, _ = primary_entry

		if levelgen.forced_tag is None: # keep a forced tag enemy if you guarantee it via the hunter sigils
			levelgen.primary_spawn = primary_spawn
			levelgen.primary_elite = primary_elite

		used_normal = {levelgen.primary_spawn} if levelgen.primary_spawn else set()
		secondary_entry = self.pick_normal_entry(levelgen, used_factories=used_normal)
		if secondary_entry: secondary_spawn, _, secondary_elite, _, _ = secondary_entry

		levelgen.secondary_spawn = secondary_spawn
		levelgen.secondary_elite = secondary_elite

		levelgen.monster_tags.clear()


		if levelgen.primary_spawn: levelgen.update_lvl_tags(levelgen.primary_spawn)
		if levelgen.secondary_spawn: levelgen.update_lvl_tags(levelgen.secondary_spawn)

		used_rare = set()

		if levelgen.primary_elite is None:
			levelgen.primary_elite = self.pick_rare_factory(levelgen, used_factories=used_rare, tags=levelgen.monster_tags)

		if levelgen.primary_elite:
			used_rare.add(levelgen.primary_elite)
			levelgen.update_lvl_tags(levelgen.primary_elite)

		if levelgen.secondary_elite is None:
			levelgen.secondary_elite = self.pick_rare_factory(levelgen, used_factories=used_rare, tags=levelgen.monster_tags)
		if levelgen.secondary_elite:
			levelgen.update_lvl_tags(levelgen.secondary_elite)

	def reroll_bosses(self, levelgen):
		if levelgen.difficulty >= LAST_LEVEL - 1: return
		if not levelgen.bosses: return

		used_factories = set()
		new_bosses = []
		prev_boss = None
		for boss in levelgen.bosses:
			if boss.name == prev_boss: continue # to handle packs of monsters
			prev_boss = boss.name
			entry = self.pick_rare_entry(levelgen, used_factories=used_factories)
			if entry is None:
				entry = self.pick_rare_entry(levelgen, force_broad_pool=True)
			if entry is None:
				new_bosses.append(boss)
				continue

			factory, _, min_no, max_no, _, _, _ = entry
			used_factories.add(factory)
			for _ in range(levelgen.random.randint(min_no, max_no)):
				new_bosses.append(factory())

		levelgen.bosses = new_bosses

		# do this here, since rewards aren't crystalized and the player may have bought spells to beat the realm already
	def on_level_reward(self, levelgen, reward, prng, player):
		if levelgen.difficulty != self.last_updated: self.update_maps(levelgen.difficulty)
		if levelgen.difficulty < 4 and levelgen.num_component_tags < 5: # let you get past the very early game with some crafting potential
			levelgen.num_component_tags += 1
			levelgen.components.clear()
			levelgen.roll_components()

		components = []
		avoid_tags = self.get_tags_to_avoid()
		for c in levelgen.components:
			new_component = roll_random_component(tier=len(c.tags), avoid_tags=avoid_tags)()
			components.append(new_component)
		levelgen.components = components
		return reward

	def on_levelgen_pre(self, levelgen):
		if levelgen.num_exits: levelgen.num_exits = 1 # only one path forward

		if levelgen.difficulty > 1:
			mod = levelgen.difficulty // 4
			if levelgen.num_generators: levelgen.num_generators += mod
			else: levelgen.num_generators = 4 + mod
			if levelgen.num_monsters: levelgen.num_monsters += mod
			else: levelgen.num_monsters = 12 + mod

		if not self.damage_map: return
		self.reroll_spawns(levelgen)
		self.reroll_bosses(levelgen)

	def get_resists_profile(self, unit):
		return tuple((tag, unit.resists[tag]) for tag in damage_tags if unit.resists[tag] > 0)

	def build_normal_spawn_entry(self, entry):
		factory, level, elite = entry
		unit = factory()
		unit.set_default_resistances()
		return (factory, level, elite, self.get_resists_profile(unit), self.get_hp_score(unit))

	def build_rare_spawn_entry(self, entry):
		factory, diff, min_no, max_no, tag = entry
		unit = factory()
		unit.set_default_resistances()
		return (factory, diff, min_no, max_no, tag, self.get_resists_profile(unit), self.get_hp_score(unit))

	def build_spawn_caches(self):
		self.normal_spawn_cache = [self.build_normal_spawn_entry(entry) for entry in spawn_options]
		self.rare_spawn_cache = [self.build_rare_spawn_entry(entry) for entry in RareMonsters.rare_monsters]

	def on_level_complete(self, _level):
		self.game.rift_rerolls = 0 # no rerolling

	def on_levelgen_start(self, levelgen):
		# scale the spawn band upward as the run goes on
		level_bonus = 1 + max(0, (levelgen.difficulty // 5))
		levelgen.min_monster_level, levelgen.max_monster_level = get_spawn_min_max(levelgen.difficulty + level_bonus)


	def on_game_begin(self, game):
		self.game = game
		self.build_spawn_caches()
		self.mastery_map = None
		self.damage_map = None
		self.last_updated = None

class HarderMonsters(Mutator):

	def __init__(self, mod):
		Mutator.__init__(self)
		self.level_mod = mod

	def on_levelgen_start(self, levelgen):
		levelgen.min_monster_level, levelgen.max_monster_level = get_spawn_min_max(levelgen.difficulty + self.level_mod)

	def get_description(self):
		return ("Monsters may appear up to {mod} levels earlier than they normally would", {'mod':self.level_mod})

def megachest():
	equipment = []
	for e in all_equipment: equipment.append(e())
	shop = Shop()
	shop.name = "Mega Chest"
	shop.items = equipment
	shop.asset = ['tiles', 'items', 'animated', 'equipment_chest']
	return shop

class Scavenger(Mutator):

	def __init__(self):
		Mutator.__init__(self)

		# track the pools here so we can wipe out the shops
		self.reward_equipment = []
		self.reward_spells = []

		self.spells_initialized = False
		self.equipment_initialized = False

	def on_game_begin(self, game):
		self.reward_equipment.clear()
		self.reward_spells.clear()
		self.spells_initialized = False
		self.equipment_initialized = False

	def get_description(self):
		return ("Levels contain no Components\n"
				"Spells cannot be purchased with SP and Equipment cannot be crafted\n"
				"Each level contains either a Ruby Heart, a Spell Scroll, or an Equipment Chest\n"
				"Each spell and equipment can only appear once")

	def on_generate_spells(self, spells):
		if self.spells_initialized: spells.clear(); return
		self.spells_initialized = True
		self.reward_spells.extend(spells)
		spells.clear()

	def on_generate_equipment(self, equipment):
		if self.equipment_initialized: equipment.clear(); return
		self.equipment_initialized = True
		for item in equipment:
			if isinstance(item, (OnPickupTriggerEquipment, PhilosophersStone, MagicWand, DragonspineCloak)): continue
			self.reward_equipment.append(item)
		equipment.clear()

	def pop_random_rewards(self, pool, prng, count):
		rewards = []
		for _ in range(min(count, len(pool))):
			idx = prng.randrange(len(pool))
			pool[idx], pool[-1] = pool[-1], pool[idx]
			reward = pool.pop()
			rewards.append(reward)
		return rewards

	def pop_level_one_spells(self, prng):
		level_one_spells = [spell for spell in self.reward_spells if spell.level == 1]
		spells = prng.sample(level_one_spells, min(4, len(level_one_spells)))
		for spell in spells: self.reward_spells.remove(spell)
		return spells

	def make_spell_reward(self, levelgen, prng):
		if not self.reward_spells: return None
		if levelgen.difficulty == 1: spells = self.pop_level_one_spells(prng)
		else: spells = self.pop_random_rewards(self.reward_spells, prng, 4)
		if not spells: return None

		shop = Shop()
		shop.name = "Scroll of Spells"
		shop.description = "One spell may be learned for free from this text"
		shop.asset = ['tiles', 'items', 'animated', 'spell_scroll']
		shop.items = spells

		def confirm_txt(i): return ("Learn {spell}?", {"spell": i})
		shop.get_confirm_text = confirm_txt
		return shop

	def make_equipment_reward(self, levelgen, prng):
		if not self.reward_equipment: return None
		equipments = self.pop_random_rewards(self.reward_equipment, prng, 4)
		if not equipments: return None

		shop = Shop()
		shop.name = "Equipment Chest"
		shop.description = "One piece of equipment may be taken from this chest"
		shop.asset = ['tiles', 'items', 'animated', 'equipment_chest']
		shop.items = [equipment.clone() for equipment in equipments]

		def confirm_txt(i): return ("Take {i}?", {"i": i})
		shop.get_confirm_text = confirm_txt
		return shop

	def on_levelgen_pre(self, levelgen):
		levelgen.num_component_tags = 0
		levelgen.components.clear()

	def on_levelgen(self, levelgen):
		if levelgen.difficulty != 1: return

		# put a cantrip next to the player for level 1
		reward = self.make_spell_reward(levelgen, levelgen.random)
		start_pos = levelgen.level.start_pos
		pts = [p for p in list(levelgen.level.get_adjacent_points(start_pos, check_unit=True)) if not levelgen.level.tiles[p.x][p.y].prop]
		if pts:
			p = levelgen.random.choice(pts)
			levelgen.consume_spawn_point(p)
		else: p = levelgen.empty_spawn_points.pop()
		if reward: levelgen.level.add_prop(reward, p.x, p.y)

	def on_level_reward(self, levelgen, reward, prng, player):
		if reward is None: return None
		score = prng.random()
		if score < .3: return hp_shrine(levelgen.difficulty, prng, player)

		spell_limit_reached = player.game.player_spell_limit_reached()
		if not spell_limit_reached and score < .6:
			reward = self.make_spell_reward(levelgen, prng)
			if reward: return reward
			reward = self.make_equipment_reward(levelgen, prng)
			if reward: return reward
			return hp_shrine(levelgen.difficulty, prng, player)

		reward = self.make_equipment_reward(levelgen, prng)
		if reward: return reward
		if spell_limit_reached: return hp_shrine(levelgen.difficulty, prng, player)
		reward = self.make_spell_reward(levelgen, prng)
		if reward: return reward
		else: return hp_shrine(levelgen.difficulty, prng, player)

class ExtraComponents(Mutator):

	def __init__(self, num_extra):
		Mutator.__init__(self)
		self.num_extra_components = num_extra

	def get_description(self):
		return ("Levels have {num} extra components", {'num':self.num_extra_components})

	def on_levelgen_pre(self, levelgen):
		for _ in range(self.num_extra_components): levelgen.components.append(random.choice(all_components)())

class LevelOneMegaChests(Mutator):

	def __init__(self, num_chests):
		Mutator.__init__(self)
		self.num_chests = num_chests

	def get_description(self):
		return ("The first level contains {num_chests} mega chests, containing every piece of craftable equipment", {'num_chests': self.num_chests})

	def on_levelgen(self, levelgen):
		if levelgen.difficulty == 1:
			for i in range(self.num_chests):
				p = levelgen.empty_spawn_points.pop()
				levelgen.level.add_prop(megachest(), p.x, p.y)

class LevelOneRewards(Mutator):

	def __init__(self, reward, num):
		Mutator.__init__(self)
		self.num = num
		self.reward = reward
		self.game = None

	def get_description(self):
		return ("The first level contains {num} {reward} rewards", {'num': self.num, 'reward': self.reward})

	def on_levelgen(self, levelgen):
		if levelgen.difficulty == 1:
			reward_tuple = reward_dict.get(self.reward)
			for i in range(self.num):
				p = levelgen.empty_spawn_points.pop()
				if reward_tuple:
					reward = reward_tuple[0](levelgen.difficulty, random, self.game.p1)
					levelgen.level.add_prop(reward, p.x, p.y)

	def on_game_begin(self, game):
		self.game = game

class NoRewards(Mutator):

	def get_description(self):
		return "There will be no level rewards"

	def on_game_begin(self, game):
		game.clear_level_rewards()

class FreeSpell(Mutator):

	def __init__(self, spell):
		Mutator.__init__(self)
		self.spell = spell
		self.spell_name = spell().name

	def on_game_begin(self, game):
		game.p1.add_spell(self.spell())

	def get_description(self):
		return ("Begin the game with the {spell} spell", {'spell':self.spell_name})

class Immobilizer(Mutator):

	def on_game_begin(self, game):
		game.p1.stationary += 100

	def get_description(self):
		return "You cannot walk"

class Confinement(Mutator):

	def __init__(self, layers):
		Mutator.__init__(self)
		self.layers = layers

	def get_description(self):
		return ("The outer {layers} layers of each level are converted to walls", {'layers':self.layers})

	def on_levelgen_terrain(self,levelgen):
		level = levelgen.level
		tiles = level.tiles
		layers = min(self.layers, 6)
		make_wall = level.make_wall

		def is_occupied(x, y):
			tile = tiles[x][y]
			if tile.unit or tile.prop: return True
			return False

		size = level.size
		for x in range(size):
			for y in range(size):
				if layers <= x < size - layers and layers <= y < size - layers: continue
				if is_occupied(x, y): continue
				make_wall(x, y)


all_trials = [Trial(n, m) for n, m in [
	("Limited Spellbook", [RandomSpellRestriction(80)]),
	("Improviser", [RandomSpellRestriction(75), RandomEquipmentRestriction(75)]),
	("Pyromancer", [SpellTagRestriction(Tags.Fire), EquipmentTagRestriction(Tags.Fire), BonusComponentTagAppearance(Tags.Fire, 15), CharacterSwap('pyromancer')]),
	("Electromancer", [SpellTagRestriction(Tags.Lightning), EquipmentTagRestriction(Tags.Lightning), BonusComponentTagAppearance(Tags.Lightning, 15), CharacterSwap('electromancer')]),
	("Cryomancer", [SpellTagRestriction(Tags.Ice), EquipmentTagRestriction(Tags.Ice), BonusComponentTagAppearance(Tags.Ice, 15), CharacterSwap('cryomancer')]),
	("Necromancer", [SpellTagRestriction(Tags.Dark), EquipmentTagRestriction(Tags.Dark), BonusComponentTagAppearance(Tags.Dark, 15), CharacterSwap('necromancer')]),
	("Phytomancer", [SpellTagRestriction(Tags.Nature), EquipmentTagRestriction(Tags.Nature), BonusComponentTagAppearance(Tags.Nature, 15), CharacterSwap('phytomancer')]),
	("Manamancer", [SpellTagRestriction(Tags.Arcane), EquipmentTagRestriction(Tags.Arcane), BonusComponentTagAppearance(Tags.Arcane, 15), CharacterSwap('manamancer')]),
	("Sanctumancer", [SpellTagRestriction(Tags.Holy), EquipmentTagRestriction(Tags.Holy), BonusComponentTagAppearance(Tags.Holy, 15), CharacterSwap('sanctumancer')]),
	("Ferromancer", [SpellTagRestriction(Tags.Metallic), EquipmentTagRestriction(Tags.Metallic), BonusComponentTagAppearance(Tags.Metallic, 15), CharacterSwap('ferromancer')]),
	("Hemomancer", [SpellTagRestriction(Tags.Blood), EquipmentTagRestriction(Tags.Blood), BonusComponentTagAppearance(Tags.Blood, 15), CharacterSwap('hemomancer')]),
	("Oner", [OneSpell(), RemoveMultipleRewards([scroll, knowledge_shrine, dissolution_shrine])]),
	("Amnesiac", Amnesiac()),
	("Wild Magic", [WildMagic(), RemoveMultipleRewards([scroll, knowledge_shrine, evolution_shrine, chronomancy_shrine, perfection_shrine, spellgraft_shrine, reformation_shrine, dissolution_shrine, haste_shrine])]),
	("Blood Rites", BloodRites()),
	("Flawless", [Flawless(), RemoveMultipleRewards([hp_shrine])]),
	("Artificer", [ExtraComponents(2), SpPenalty(2), SpellLevelRestriction(1), RemoveMultipleRewards([scroll, knowledge_shrine])]),
	("Scavenger", Scavenger()),
	("Adventuring Party", [LevelOneRewards('Tavern', 4), AdventuringParty(), NoRewards()]),
	("Chronomancer", Chronomancer()),
	("Vanguard", HarderMonsters(5)),
	("Mordred's Vengeance", MordredsVengeance()),
]]

def get_weekly_seed():
	if 'weeklyseed' in sys.argv:
		seed = int(sys.argv[sys.argv.index('weeklyseed') + 1])
	else:
		first_weekly_date = datetime.date(2021, 4, 13)
		cur_date = datetime.date.today()
		days = (cur_date - first_weekly_date).days
		seed = days // 7

	return seed

def get_weekly_name():
	return "weekly_" + str(get_weekly_seed())

respawn_opts = [
	VampireBat,
	GreenSlime,
	Troubler,
	Mantis,
	FireSpirit,
	MindMaggot,
	SparkImp,
	Faery,
	BrainSapling,
]

weekly_boon_groups = [
	("mega_chest", [
		LevelOneMegaChests(1),
		LevelOneMegaChests(2),
	]),
	("tavern", [
		LevelOneRewards('Tavern', 2),
	]),
	("spell_stat", [
		SpellStatMultiplier('damage', 200),
		SpellStatMultiplier('range', 200),
		SpellStatMultiplier('max_charges', 200),
		SpellStatMultiplier('duration', 200),
	]),
	("sp", [
		SpBonus(1),
		SpBonus(2),
	]),
	("rerolls", [
		BonusRerolls(1),
		BonusRerolls(2),
	]),
	("rifts", [
		NumPortals(4),
		NumPortals(5),
	]),
	("spawners", [
		FewerSpawners(1),
	]),
	("components", [
		ExtraComponents(1),
		ExtraComponents(2),
	]),
]

weekly_mod_groups = [
	("elites", [
		ExtraElites(5),
		ExtraElites(10),
	]),
	("rifts", [
		NumPortals(1),
		NumPortals(2),
	]),
	("enemy_wizard", [
		SpawnWizards(),
	]),
	("spawners", [
		MoreSpawners(2),
		MoreSpawners(3),
	]),
	("monster_hp", [
		MonsterHPMult(2),
	]),
	("enemy_resistance", [
		EnemyResistance(damage_type, resistance)
		for damage_type in damage_tags
		for resistance in (50, 100)
	]),
	("player_vulnerability", [
		PlayerVulnerability(damage_type, resistance)
		for damage_type in damage_tags
		for resistance in (100, 200, 300)
	]),
	("extra_spawns", [
		ExtraSpawns(Troubler, 6),
		ExtraSpawns(Gnome, 5),
		ExtraSpawns(GlassMushboom, 8),
		ExtraSpawns(FireDrake, 3),
		ExtraSpawns(FalseProphet, 4),
		ExtraSpawns(FaeArcanist, 4),
	]),
	("enemy_buff", [
		EnemyBuff(TeleportyBuff),
		EnemyBuff(lambda: DamageAuraBuff(1, Tags.Poison, 4)),
		EnemyBuff(lambda: DamageAuraBuff(2, Tags.Fire, 2)),
		EnemyBuff(lambda: BloodrageBuff(5)),
		EnemyBuff(lambda: BloodrageBuff(10)),
		EnemyBuff(lambda: HealAuraBuff(1, 4)),
		EnemyBuff(lambda: BurrowingBuff()),
		EnemyBuff(lambda: FlyingBuff()),
	]),
	("enemy_reaction", [
		EnemyBuff(lambda: ReactiveTeleportBuff(4)),
		EnemyBuff(lambda: AdaptiveArmorBuff(25)),
	]),
	("enemy_afterlife", [
		RespawnAsMutator(monster) for monster in respawn_opts
	]),
	("enemy_shields", [
		EnemyShields(1),
		EnemyShields(2),
	]),
	("spell_rule", [
		MemoryLeak(),
	]),
	("spell_hp_cost", [
		SpellHPCostAdd(2),
		SpellHPCostAdd(3),
	]),
	("attrition", [
		Attrition(5),
		Attrition(10),
	]),
	("super_spawners", [
		SuperSpawners(4),
	]),
	("spell_stat", [
		SpellStatMultiplier('damage', 50),
		SpellStatMultiplier('range', 50),
		SpellStatMultiplier('max_charges', 50),
		SpellStatMultiplier('duration', 50),
	]),
	("spell_cooldown", [
		SpellCooldowns(3),
		SpellCooldowns(4),
	]),
	("periodic_effect", [
		Forgetful(5),
		Forgetful(10),
		Awestruck(5),
		Awestruck(10),
		Treachery(20),
		Treachery(30),
		Thieving(30),
		Thieving(20),
	]),
	("weather", [
		Weather(weather, 3) for weather in weather_options
	]),
	("damage_debuff", [
		DamageDebuff(Poison),
		DamageDebuff(NecrosisBuff),
		DamageDebuff(BlindBuff),
	]),
	("monster_level", [
		HarderMonsters(2),
		HarderMonsters(3),
	]),
	("terrain", [
		Crumbling(10),
		Crumbling(20),
		Confinement(3),
		Confinement(2),
	]),
]

weekly_restriction_groups = [
	("spell_restriction", .75, [
		RandomSpellRestriction(40),
		RandomSpellRestriction(50),
		RandomSpellRestriction(60),
		RandomSpellRestriction(70),
		RandomSpellRestriction(80),
	]),
	("equipment_restriction", .50, [
		RandomEquipmentRestriction(40),
		RandomEquipmentRestriction(50),
		RandomEquipmentRestriction(60),
		RandomEquipmentRestriction(70),
		RandomEquipmentRestriction(80),
	]),
]

weekly_mods = [mod for _, options in weekly_mod_groups for mod in options]
weekly_mods += [mod for _, _, options in weekly_restriction_groups for mod in options]

mutator_buff_options = [
	lambda: TeleportyBuff(),
	lambda: BurrowingBuff(),
	lambda: FlyingBuff(),
	lambda: DamageAuraBuff(1, Tags.Poison, 4),
	lambda: DamageAuraBuff(2, Tags.Fire, 2),
	lambda: BloodrageBuff(2),
	lambda: HealAuraBuff(1, 4),
	lambda: TrollRegenBuff(),
	lambda: ReactiveTeleportBuff(4),
	lambda: AdaptiveArmorBuff(25)
]

mutator_spawn_options = [item[0] for item  in spawn_options]

mutator_param_options = {
	SpellStatMultiplier: ['damage', 'duration', 'max_charges', 'range'],
	SpellTagRestriction: spell_tags,
	EquipmentTagRestriction: spell_tags,
	SpellTagElimination: spell_tags,
	EnemyBuff: mutator_buff_options,
	ExtraSpawns:mutator_spawn_options,
	RespawnAsMutator:mutator_spawn_options,
	EnemyResistance: damage_tags,
	PlayerVulnerability: damage_tags,
	Weather: weather_options,
	DamageDebuff: [Poison, NecrosisBuff, BlindBuff],
	FixedRewards: list(reward_dict.keys()),
	RemoveRewards: list(reward_dict.keys()),
	LevelOneRewards: list(reward_dict.keys())
}

mutators_with_params = [
	SpellStatMultiplier,
	SpellTagRestriction,
	EquipmentTagRestriction,
	SpellTagElimination,
	EnemyBuff,
	ExtraSpawns,
	FixedRewards,
	RemoveRewards,
	RespawnAsMutator,
	LevelOneRewards,
	EnemyResistance,
	PlayerVulnerability,
	Weather,
	DamageDebuff
]

mutators_with_params_and_vals = [
	SpellStatMultiplier,
	ExtraSpawns,
	LevelOneRewards,
	EnemyResistance,
	PlayerVulnerability,
	Weather
]

mutators_with_vals_first = [
	SpellStatMultiplier,
	ExtraSpawns,
	LevelOneRewards,
	EnemyResistance,
	PlayerVulnerability
]

mutators_with_vals = [
	RandomSpellRestriction,
	RandomEquipmentRestriction,
	SpellLevelElimination,
	SpellLevelRestriction,
	SpBonus,
	SpPenalty,
	SpPerLevel,
	ExtraElites,
	NumPortals,
	MonsterHPMult,
	EnemyShields,
	SpellHPCostAdd,
	Attrition,
	SuperSpawners,
	SpellCooldowns,
	Forgetful,
	Awestruck,
	Treachery,
	Thieving,
	Crumbling,
	LevelOneMegaChests,
	BonusRerolls,
	MoreSpawners,
	FewerSpawners,
	HarderMonsters,
	ExtraComponents,
	Confinement
]

mutators_with_no_args = [
	OneSpell,
	GiantSlayer,
	MemoryLeak,
	Amnesiac,
	WildMagic,
	BloodRites,
	Flawless,
	Chronomancer,
	SpawnWizards,
	MordredsVengeance,
	Scavenger
]

all_mutators = sorted(mutators_with_params + mutators_with_vals + mutators_with_no_args, key=lambda cls: cls.__name__)

def get_random_mutators(seed=None, weekly=False):

	r = random.Random(get_weekly_seed() if weekly else seed)

	modifiers = []
	num_maluses = r.choice([3, 3, 3, 4, 4, 4, 5, 5, 5, 6])

	used_groups = set() # don't want a boon / malus that contradict one another
	boon_chance = .7
	boon_groups = weekly_boon_groups.copy()

	# Each boon adds one malus
	while boon_groups and r.random() < boon_chance:
		boon_group = r.choice(boon_groups)
		boon_groups.remove(boon_group)
		group_name, options = boon_group
		modifiers.append(r.choice(options))
		used_groups.add(group_name)
		if num_maluses < 6: num_maluses += 1 # add a new malus per boon up to a reasonable limit
		boon_chance /= 2

	# Build restrictions replace normal maluses if rolled
	for _, chance, options in weekly_restriction_groups:
		if r.random() >= chance: continue
		modifiers.append(r.choice(options))
		num_maluses -= 1

	malus_groups = [group for group in weekly_mod_groups if group[0] not in used_groups]

	for _ in range(min(num_maluses, len(malus_groups))):
		malus_group = r.choice(malus_groups)
		malus_groups.remove(malus_group)
		_, options = malus_group
		modifiers.append(r.choice(options))

	return modifiers

if __name__ == "__main__":
	print(get_random_mutators(None, True))


# Assert that all mutators have descrptions
for t in all_trials:
	t.get_description()

for m in weekly_mods:
	assert(m.get_description())
