import random

import text
from Spells import DrainPulse, PainMirrorSpell, PrisonOfThorns, ChainLightningSpell, SealFate, WheelOfDeath
from Level import *
from Monsters import *
from RareMonsters import Watcher


class TimedComponentBuff(Buff):

	def __init__(self, interval, remove_if_cleared=True):
		self.interval = interval
		Buff.__init__(self)
		self.stack_type = STACK_INTENSITY
		self.counter = interval
		self.remove_if_cleared = remove_if_cleared

	def on_applied(self, owner):
		self.counter = self.interval
		self.trigger()

	def on_advance(self):
		if self.remove_if_cleared and self.owner.is_player_controlled and self.owner.game.level_cleared: self.owner.remove_buff(self)
		self.counter -= 1
		if self.counter > 0: return
		self.counter = self.interval
		self.trigger()

	def get_effect_description(self):
		return self.description

	def get_description(self):
		effect = self.get_effect_description()
		kw = 'turn' if self.counter == 1 else 'turns'
		trigger_text = ("Triggers in {turns} {kw}", {'turns': self.counter, 'kw':kw})
		if effect: return [effect, "\n", trigger_text]
		return trigger_text

	def trigger(self):
		pass

# Tier 1 Components

# Elemental Schools of Magic

class BurningEmber(Component):

	def on_init(self):
		self.name = "Burning Ember"
		self.description = ("On Pickup:"
							"\nGain a damage aura that deals 6 [Fire] damage to enemies within 5 tiles for 15 turns")
		self.tags = [Tags.Fire]

	def on_pickup(self, player, level):
		b = DamageAuraBuff(6, Tags.Fire, 5)
		b.color = Tags.Fire.color
		player.apply_buff(b, 15)

class ElementalIce(Component):

	def on_init(self):
		self.name = "Elemental Ice"
		self.description = ("On Pickup:"
							"\nGain 7 [SH:shields]")
		self.tags = [Tags.Ice]

	def on_pickup(self, player, level):
		player.add_shields(7)

class LightningJar(Component):

	def on_init(self):
		self.name = "Lightning Jar"
		self.description = ("On Pickup:"
							"\nGain [quickstep:translocation] for 25 turns")
		self.tags = [Tags.Lightning]

	def on_pickup(self, player, level):
		level.show_effect(player.x, player.y, Tags.Lightning)
		player.apply_buff(QuickmoveBuff(), 25)

class Wildflower(Component):

	def on_init(self):
		self.name = "Wildflower"
		self.description = ("On Pickup:"
							"\nRemove [poison] and heal for [50 HP:heal]")
		self.tags = [Tags.Nature]

	def on_pickup(self, player, level):
		b = player.get_buff(Poison)
		if b: player.remove_buff(b)
		self.owner = self.caster = player
		player.heal(50, self)

class ArcaneMote(Component):

	def on_init(self):
		self.name = "Arcane Mote"
		self.description = ("On Pickup:"
							"\nRegain a charge of each of your spells")
		self.tags = [Tags.Arcane]

	def on_pickup(self, player, level):
		level.show_effect(player.x, player.y, Tags.Arcane)
		for s in player.spells: s.refund_charges(1)

class ShadeweaveBuff(Buff):

		def on_init(self):
			self.name = "Shadeweave Regeneration"
			self.stack_type = STACK_INTENSITY
			self.asset = ['status', 'heal']
			self.color = Tags.Dark.color

		def get_description(self):
			if not self.owner: return "Regenerates HP each turn"
			return ("Heal [{val}:dark] HP each turn", {'val': self.owner.get_mastery(Tags.Dark)})

		def on_advance(self):
			heal = self.owner.get_mastery(Tags.Dark)
			if heal: self.owner.heal(heal, self)


class Shadeweave(Component):

	def on_init(self):
		self.name = "Shadeweave"
		self.description = ("On Pickup:"
							"\nHeal for an amount equal to your [Dark] mastery each turn until the end of the level")
		self.tags = [Tags.Dark]

	def on_pickup(self, player, level):
		player.apply_buff(ShadeweaveBuff())

class HolyIcon(Component):

	def on_init(self):
		self.name = "Holy Icon"
		self.description = ("On Pickup:"
							"\nSummon a False Prophet to fight for you")
		self.tags = [Tags.Holy]

	def get_unit(self):
		return FalseProphet()

	def on_pickup(self, player, level):
		level.show_effect(player.x, player.y, Tags.Holy)
		level.summon(player, self.get_unit())

class ShieldingShard(Component):

	def on_init(self):
		self.name = "Shielding Shard"
		self.description = ("On Pickup:"
							"\nGain [1 SH:shields] per turn for 15 turns")
		self.tags = [Tags.Metallic]

	def on_pickup(self, player, level):
		b = ShieldRegenBuff(20)
		b.name = "Shielding Shard"
		b.color = Tags.Metallic.color
		b.stack_type = STACK_INTENSITY
		player.apply_buff(b, 15)

class HeartFragment(Component):

	def on_init(self):
		self.name = "Heart Fragment"
		self.description = ("On Pickup:"
							"\nGain 10 max HP")
		self.tags = [Tags.Blood]

	def on_pickup(self, player, level):
		level.show_effect(player.x, player.y, Tags.Blood)
		player.max_hp += 10
		player.cur_hp += 10
		level.log((text.HP_INCREASE, {"component": self.name, 'amt': 10}))


# Types of Magic

class MagicRune(Component):

	def on_init(self):
		self.name = "Magic Rune"
		self.description = ("On Pickup:"
							"\n[Sorcery] spells and equipment gain +6 [damage] for 15 turns")
		self.tags = [Tags.Sorcery]

	def on_pickup(self, player, level):
		player.apply_buff(TagAttrBonus(Tags.Sorcery, 'damage', 6), 15)
		level.show_effect(player.x, player.y, Tags.Arcane)

class LostRingBuff(TimedComponentBuff):

	def __init__(self):
		TimedComponentBuff.__init__(self, 1)
		self.name = "Lost Ring"
		self.color = Tags.Enchantment.color
		self.description = "Adjacent enemies are [berserked] for 3 turns"

	def trigger(self):
		o = self.owner
		for p in o.level.get_adjacent_points(o, False, False, r=o.radius):
			unit = o.level.get_unit_at(p.x, p.y)
			if not unit: continue
			if are_friendly(o, unit): continue
			unit.apply_buff(BerserkBuff(), 3)

class LostRing(Component):

	def on_init(self):
		self.name = "Lost Ring"
		self.description = ("On Pickup:"
							"\nAdjacent enemies are [berserked] for 3 turns"
							"\nThis effect repeats every turn until the end of the level")
		self.tags = [Tags.Enchantment]

	def on_pickup(self, player, level):
		player.apply_buff(LostRingBuff())

class Incense(Component):

	def on_init(self):
		self.name = "Incense"
		self.description = ("On Pickup:"
							"\nSummon a triad of Faeries to fight for you")
		self.tags = [Tags.Conjuration]

	def get_unit(self):
		return Faery()

	def on_pickup(self, player, level):
		for i in range(3): level.summon(player, self.get_unit())


class RiftResidue(Component):

	def on_init(self):
		self.name = "Rift Residue"
		self.description = ("On Pickup:"
							"\nA random [Translocation] spell you know permanently gains +1 [max charges:max_charges]")
		self.tags = [Tags.Translocation]

	def on_pickup(self, player, level):
		opts = [s for s in player.spells if s.max_charges and Tags.Translocation in s.tags]
		if not opts: return
		s = random.choice(opts)
		player.adjust_spell_bonus(type(s), 'max_charges', 1)
		s.refund_charges(1)
		s.do_ui_flash(tag=Tags.Translocation)
		level.show_effect(player.x, player.y, Tags.Arcane)
		level.log((text.SPELL_STAT_INCREASE, {"component": self.name, "spell": s.name, 'tkey': tag_key(Tags.Translocation), "attr": attr_label('max_charges'), 'amt':1}))


# Tier 2 Components

class SeersOrb(Component):

	def on_init(self):
		self.name = "Seer's Orb"
		self.description = ("On Pickup:"
							"\nGrants +6 [range] and removes line of sight casting requirements for all spells for 10 turns")
		self.tags = [Tags.Eye, Tags.Orb]

	def on_pickup(self, player, level):
		b = GlobalAttrBonus('requires_los', -1)
		b.global_bonuses['range'] = 6
		b.name = "Seer's Sight"
		b.stack_type = STACK_DURATION

		player.apply_buff(b, 10)

class Drakentooth(Component):

	def on_init(self):
		self.name = "Drakentooth"
		self.description = ("On Pickup:"
							"\nSummon a pair of Fire Drakes to fight for you")
		self.tags = [Tags.Dragon, Tags.Fire]

	def get_unit(self):
		return FireDrake()

	def on_pickup(self, player, level):
		level.summon(player, self.get_unit())
		level.summon(player, self.get_unit())

class DevilsBlood(Component):

	def on_init(self):
		self.name = "Devil's Blood"
		self.description = ("On Pickup:"
							"\nSteal 2 max HP from each [Demon] in line of sight")
		self.tags = [Tags.Blood, Tags.Chaos]

	def on_pickup(self, player, level):
		granted = 0
		for target in level.get_units_in_los(player):
			if Tags.Demon not in target.tags: continue
			player.level.show_path_effect(player, target, Tags.Blood)
			drain_max_hp(target, 2)
			player.max_hp += 2
			player.cur_hp += 2
			granted += 2
		if granted: level.log((text.HP_INCREASE, {"component": self.name, 'amt': granted}))

class SlimeCore(Component):

	def on_init(self):
		self.name = "Slime Core"
		self.description = ("On Pickup:"
							"\nSummon a trio of friendly Void Slimes")
		self.tags = [Tags.Arcane, Tags.Slime]

	def get_unit(self):
		return VoidSlime()

	def on_pickup(self, player, level):
		for _ in range(3): level.summon(player, self.get_unit())

class AncientInscription(Component):

	def on_init(self):
		self.name = "Ancient Inscription"
		self.description = ("On Pickup:"
							"\nA random [Sorcery] or [Word] spell you know permanently gains +2 [max charges:max_charges]")
		self.tags = [Tags.Sorcery, Tags.Word]

	def on_pickup(self, player, level):
		opts = [s for s in player.spells if s.max_charges and any(s in [Tags.Sorcery, Tags.Word] for s in s.tags)]
		if not opts: return
		s = random.choice(opts)
		player.adjust_spell_bonus(type(s), 'max_charges', 2)
		s.refund_charges(2)
		s.do_ui_flash(tag=Tags.Sorcery)
		level.show_effect(player.x, player.y, Tags.Arcane)
		level.log((text.SPELL_STAT_INCREASE, {"component": self.name, "spell": s.name, 'tkey':tag_key(Tags.Sorcery), "attr": attr_label('max_charges'), "amt":2}))


class Shimmersteel(Component):

	def on_init(self):
		self.name = "Shimmersteel"
		self.description = ("On Pickup:"
							"\n[Metallic] spells and equipment gain +100% [damage] and [range] until the end of the level")
		self.tags = [Tags.Metallic, Tags.Translocation]

	def on_pickup(self, player, level):
		player.apply_buff(TagAttrBonus(Tags.Metallic, 'damage', 100, pct=True))
		player.apply_buff(TagAttrBonus(Tags.Metallic, 'range', 100, pct=True))
		level.show_effect(player.x, player.y, Tags.Translocation)

class Frostpetal(Component):

	def on_init(self):
		self.name = "Frostpetal"
		self.description = ("On Pickup:"
							"\nGain 75% [Ice] resist and regenerate 3 HP per turn for 25 turns")
		self.tags = [Tags.Ice, Tags.Nature]

	def on_pickup(self, player, level):
		player.apply_buff(ResistBuff(Tags.Ice, 75), 25)
		player.apply_buff(RegenBuff(3), 15)

class SilverDragonscale(Component):
	def on_init(self):
		self.name = "Silver Dragonscale"
		self.description = ("On Pickup:"
							"\nGain 50% [Physical] and 100% [Ice] resistance for the remainder of the level")
		self.tags = [Tags.Dragon, Tags.Metallic]

	def on_pickup(self, player, level):
		player.apply_buff(ResistBuff(Tags.Physical, 50))
		player.apply_buff(ResistBuff(Tags.Ice, 100))


class RelocatorBeaconBuff(TimedComponentBuff):

	def __init__(self):
		TimedComponentBuff.__init__(self, 3, remove_if_cleared=False)
		self.name = "Relocator Beacon"
		self.color = Tags.Translocation.color
		self.description = "Teleport a random Memory Orb or Component on the level into your inventory"

	def trigger(self):
		owner = self.owner
		level = owner.level
		opts = [p for p in level.props if isinstance(p, (MemoryOrb, ComponentPickup))]
		if not opts: return
		prop = random.choice(opts)
		player = level.player_unit
		level.show_path_effect(prop, player, Tags.Translocation)
		prop.on_player_enter(player)

class RelocatorBeacon(Component):
	def on_init(self):
		self.name = "Relocator Beacon"
		self.tags = [Tags.Orb, Tags.Translocation]
		self.description = ("On Pickup:"
							"\nTeleport a random Memory Orb or Component on the level into your inventory"
							"\nThis effect repeats every 3 turns until the end of the level")

	def on_pickup(self, player, level):
		player.apply_buff(RelocatorBeaconBuff())

class VoidstoneShard(Component):
	def on_init(self):
		self.name = "Voidstone Shard"
		self.description = ("On Pickup:"
							"\nRegain all spell charges")
		self.tags = [Tags.Arcane, Tags.Sorcery]

	def on_pickup(self, player, level):
		for s in player.spells:
			if s.max_charges:
				s.cur_charges = s.get_stat('max_charges')
				level.show_effect(player.x, player.y, Tags.Arcane)

class BindingRing(Component):
	def on_init(self):
		self.name = "Binding Ring"
		self.description = ("On Pickup:"
							"\nTurns the nearest [Demon] or [Arcane] unit into an ally")
		self.tags = [Tags.Conjuration, Tags.Enchantment]

	def on_pickup(self, player, level):
		targets = level.get_units_by_distance(player, enemy=True)
		for u in targets:
			if Tags.Arcane in u.tags or Tags.Demon in u.tags:
				level.show_path_effect(player, u, Tags.Arcane)
				u.team = player.team
				break

class RunedVellum(Component):
	def on_init(self):
		self.name = "Runed Vellum"
		self.description = ("On Pickup:"
							"\nTriples the remaining duration of any of your currently active buffs")
		self.tags = [Tags.Sorcery, Tags.Enchantment]

	def on_pickup(self, player, level):
		tb = [b for b in player.buffs if b.buff_type == BUFF_TYPE_BLESS and b.turns_left > 0]
		for b in tb:
			b.turns_left *= 3
			level.show_effect(player.x, player.y, Tags.Arcane)

class CursedSeal(Component):
	def on_init(self):
		self.name = "Cursed Seal"
		self.description = ("On Pickup:"
							"\nCast Seal Fate on all enemies in your line of sight")
		self.tags = [Tags.Dark, Tags.Enchantment]

	def on_pickup(self, player, level):
		spell = player.get_or_make_spell(SealFate)
		enemies = [u for u in level.get_units_in_los(player) if u is not player and are_hostile(u, player)]
		for enemy in enemies: level.act_cast(player, spell, enemy.x, enemy.y, pay_costs=False)


class Hellbloom(Component):
	def on_init(self):
		self.name = "Hellbloom"
		self.description = ("On Pickup:"
							"\nSummon 9 friendly Hellhounds which appear at random locations")
		self.tags = [Tags.Fire, Tags.Nature]

	def get_unit(self):
		return HellHound()

	def on_pickup(self, player, level):
		for i in range(9):
			level.summon(player, self.get_unit(), radius=36, sort_dist=False)


class VoltaicAshBuff(TimedComponentBuff):

	def __init__(self):
		TimedComponentBuff.__init__(self, 6)
		self.name = "Voltaic Ash"
		self.color = Tags.Lightning.color
		self.description = ("Fire a beam toward each other unit in your line of sight"
							"\nEach beam deals 16 [Fire] or [Lightning] damage")

	def trigger(self):
		targets = [u for u in self.owner.level.get_units_in_los(self.owner) if u is not self.owner]
		for target in targets:
			dtype = random.choice([Tags.Fire, Tags.Lightning])
			self.owner.level.queue_spell(self.do_bolt(target, dtype))

	def do_bolt(self, target, dtype):
		for p in self.owner.level.get_points_in_line(self.owner, target):
			if (p.x, p.y) == (self.owner.x, self.owner.y): continue
			self.owner.level.deal_damage(p.x, p.y, 16, dtype, self)
			yield


class VoltaicAsh(Component):
	def on_init(self):
		self.name = "Voltaic Ash"
		self.description = ("On Pickup:"
							"\nFire a beam toward each other unit in your line of sight"
							"\nEach beam deals 16 [Fire] or [Lightning] damage"
							"\nThis effect repeats every 6 turns until the end of the level")
		self.tags = [Tags.Fire, Tags.Lightning]

	def on_pickup(self, player, level):
		player.apply_buff(VoltaicAshBuff())


class GlacialScript(Component):
	def on_init(self):
		self.name = "Glacial Script"
		self.description = ("On Pickup:"
							"\nCast your self-targeted [Ice] spells")
		self.tags = [Tags.Ice, Tags.Word]

	def on_pickup(self, player, level):
		spells = [s for s in player.spells if Tags.Ice in s.tags and s.range == 0]
		for s in spells: player.level.act_cast(player, s, player.x, player.y, pay_costs=False)

class BeastbloodFungus(Component):
	def on_init(self):
		self.name = "Beastblood Fungus"
		self.description = ("On Pickup:"
							"\nHeal 2 HP per turn for the remainder of the level")
		self.tags = [Tags.Nature, Tags.Blood]

	def on_pickup(self, player, level):
		player.apply_buff(RegenBuff(2))

class ScriptedCortex(Component):
	def on_init(self):
		self.name = "Scripted Cortex"
		self.description = ("On Pickup:"
							"\nA random [Arcane] or [Word] spell you know permanently gains +2 [max charges:max_charges]")
		self.tags = [Tags.Arcane, Tags.Word]

	def on_pickup(self, player, level):
		opts = [s for s in player.spells if s.max_charges and any(s in [Tags.Arcane, Tags.Word] for s in s.tags)]
		if not opts: return
		s = random.choice(opts)
		player.adjust_spell_bonus(type(s), 'max_charges', 2)
		s.refund_charges(2)
		s.do_ui_flash(tag=Tags.Arcane)
		level.show_effect(player.x, player.y, Tags.Arcane)
		level.log((text.SPELL_STAT_INCREASE,  {"component": self.name, 'tkey':tag_key(Tags.Arcane), "attr": attr_label('max_charges'),  "spell": s.name, "amt":2}))

class UmbralResin(Component):
	def on_init(self):
		self.name = "Umbral Resin"
		self.description = ("On Pickup:"
							"\nGain 100% resistance to [Dark] and [Poison] damage for the remainder of the level")

		self.tags = [Tags.Dark, Tags.Nature]

	def on_pickup(self, player, level):
		player.apply_buff(ResistBuff(Tags.Dark, 100))
		player.apply_buff(ResistBuff(Tags.Poison, 100))

class ChargedCog(Component):
	def on_init(self):
		self.name = "Charged Cog"
		self.description = ("On Pickup:"
							"\nSummon a friendly Copper Spikeball")
		self.tags = [Tags.Metallic, Tags.Lightning]

	def get_unit(self):
		return SpikeBallCopper()

	def on_pickup(self, player, level):
		level.summon(player, self.get_unit())

class SacrificialBrand(Component):
	def on_init(self):
		self.name = "Sacrificial Brand"
		self.description = ("On Pickup:"
							"\nGain max HP equal to your [Blood] mastery")
		self.tags = [Tags.Blood, Tags.Metallic]

	def on_pickup(self, player, level):
		granted = player.get_mastery(Tags.Blood)
		if not granted: return
		player.max_hp += granted
		player.cur_hp += granted
		level.show_effect(player.x, player.y, Tags.Blood)
		level.log((text.HP_INCREASE, {"component": self.name, 'amt': granted}))


class CrimsonSigil(Component):
	def on_init(self):
		self.name = "Crimson Sigil"
		self.description = ("On Pickup:"
							"\nCast Drain Pulse")
		self.tags = [Tags.Blood, Tags.Sorcery]

	def on_pickup(self, player, level):
		level.act_cast(player, player.get_or_make_spell(DrainPulse), player.x, player.y, pay_costs=False)

class SanctifiedLocket(Component):
	def on_init(self):
		self.name = "Sanctified Locket"
		self.description = ("On Pickup:"
							"\n[Undead], [Demons], and [Dark] units in line of sight are [feared] for 8 turns")
		self.tags = [Tags.Holy, Tags.Enchantment]

	def on_pickup(self, player, level):
		evil = [Tags.Undead, Tags.Demon, Tags.Dark]
		targets = [u for u in level.get_units_in_los(player) if any(t in evil for t in u.tags)]
		for u in targets: level.queue_spell(self.do_fear(player, u))

	def do_fear(self, player, target):
		player.level.show_path_effect(player, target, Tags.Holy)
		target.apply_buff(FearBuff(), 8)
		yield


class FulminiteRetributionBuff(RetributiveEffect):
	def __init__(self):
		RetributiveEffect.__init__(self, name="Fulminite Retribution")
		self.color = Tags.Lightning.color
		self.description = "Cast Chain Lightning targeting the first enemy that damages you each turn"
		self.activated = False

	def retribution(self, evt):
		if self.activated: return
		if not (evt.source and evt.source.owner and are_hostile(evt.source.owner, evt.unit)): return
		self.activated = True  # to stop queues from stacking up
		wizard, enemy = evt.unit, evt.source.owner
		wizard.level.act_cast(wizard, wizard.get_or_make_spell(ChainLightningSpell), enemy.x, enemy.y, pay_costs=False)

	def on_advance(self):
		self.activated = False

class FulminiteShard(Component):
	def on_init(self):
		self.name = "Fulminite Shard"
		self.description = ("On Pickup:"
							"\nCast Chain Lightning targeting the first enemy that damages you each turn for the remainder of the level")
		self.tags = [Tags.Lightning, Tags.Enchantment]

	def on_pickup(self, player, level):
		player.apply_buff(FulminiteRetributionBuff())


class RetinalJelly(Component):
	def on_init(self):
		self.name = "Retinal Jelly"
		self.description = ("On Pickup:"
							"\nSummon a friendly Annihilation Goo")
		self.tags = [Tags.Eye, Tags.Slime]

	def get_unit(self):
		return AnnihilationGoo()

	def on_pickup(self, player, level):
		level.summon(player, self.get_unit())

class WarpedDragonEgg(Component):
	def on_init(self):
		self.name = "Warped Dragon Egg"
		self.description = ("On Pickup:"
							"\nA random [Conjuration] spell you know gains +3 [minion damage:minion_damage]")
		self.tags = [Tags.Chaos, Tags.Dragon]

	def on_pickup(self, player, level):
		opts = [s for s in player.spells if Tags.Conjuration in s.tags]
		if not opts: return
		s = random.choice(opts)
		s.do_ui_flash(tag=Tags.Chaos)
		player.adjust_spell_bonus(type(s), 'minion_damage', 3)
		level.show_effect(player.x, player.y, Tags.Chaos)
		level.log(("[{component}:{tkey}] increased {spell}'s {attr} by {amt}",
				   {"component": self.name, 'tkey':tag_key(Tags.Chaos),  "spell": s.name, "attr": attr_label('minion_damage'), 'amt': 3}))



class VotiveCandle(Component):
	def on_init(self):
		self.name = "Votive Candle"
		self.description = ("On Pickup:"
							"\nHeal 10 HP per turn for the next 12 turns")
		self.tags = [Tags.Fire, Tags.Holy]

	def on_pickup(self, player, level):
		b = RegenBuff(10)
		b.color = Tags.Holy.color
		b.name = "Unwavering Faith"
		player.apply_buff(b, 12)
		level.show_effect(player.x, player.y, Tags.Holy)

class DreamthornVine(Component):
	def on_init(self):
		self.name = "Dreamthorn Vine"
		self.description = ("On Pickup:"
							"\nThe nearest enemy is [stunned] for 6 turns, and you cast Prison of Thorns on them")
		self.tags = [Tags.Arcane, Tags.Nature]

	def on_pickup(self, player, level):
		targets = level.get_units_by_distance(player, enemy=True)
		if not targets: return
		level.queue_spell(self.do_effect(player, targets[0]))

	def do_effect(self, player, unit):
		player.level.show_path_effect(player, unit, Tags.Arcane)
		unit.apply_buff(Stun(), 6)
		player.level.act_cast(player, player.get_or_make_spell(PrisonOfThorns), unit.x, unit.y, pay_costs=False)
		yield

class WatcherStone(Component):
	def on_init(self):
		self.name = "Watcher Stone"
		self.description = ("On Pickup:"
							"\nSummon a friendly Watcher")
		self.tags = [Tags.Eye, Tags.Metallic]

	def get_unit(self):
		return Watcher()

	def on_pickup(self, player, level):
		level.summon(player, self.get_unit())

class BloodBasin(Component):
	def on_init(self):
		self.name = "Blood Basin"
		self.description = "On Pickup:\nCast Pain Mirror"
		self.tags = [Tags.Blood, Tags.Ritual]

	def on_pickup(self, player, level):
		level.act_cast(player, player.get_or_make_spell(PainMirrorSpell), player.x, player.y, pay_costs=False)

class HolyWater(Component):
	def on_init(self):
		self.name = "Holy Water"
		self.description = ("On Pickup:"
							"\nRemove all debuffs from yourself"
							"\nGain 75% [Dark] and [Fire] resistance that lasts for the remainder of the level")
		self.tags = [Tags.Holy, Tags.Ritual]

	def on_pickup(self, player, level):
		debuffs = [b for b in player.buffs if b.buff_type is BUFF_TYPE_CURSE]
		for d in debuffs: player.remove_buff(d)
		player.apply_buff(ResistBuff(Tags.Dark, 75))
		player.apply_buff(ResistBuff(Tags.Fire, 75))

class MirrorStone(Component):
	def on_init(self):
		self.name = "Mirror Stone"
		self.description = "On Pickup:\nGain an additional copy of this component"
		self.tags = [Tags.Ritual, Tags.Translocation]

	def on_pickup(self, player, level):
		if player.is_player_controlled: player.add_component(type(self)())
		level.show_effect(player.x, player.y, Tags.Translocation)


class StormglassEyeBuff(TimedComponentBuff):

	def __init__(self):
		TimedComponentBuff.__init__(self, 6)
		self.name = "Stormglass Eye"
		self.color = Tags.Lightning.color
		self.description = ("Summon a [Storm Cloud:lightning] over each enemy in line of sight"
							"\n[Storm Clouds:lightning] have a 50% chance to deal 25 [Lightning] damage each turn and last for 5 turns")

	def trigger(self):
		targets = [u for u in self.owner.level.get_units_in_los(self.owner) if are_hostile(self.owner, u)]
		random.shuffle(targets)
		for target in targets: self.owner.level.queue_spell(self.do_effect(target))

	def do_effect(self, unit):
		for p in self.owner.level.get_points_in_line(self.owner, unit):
			self.owner.level.show_effect(p.x, p.y, Tags.Lightning)
			yield
		self.owner.level.add_obj(StormCloud(self.owner, damage=25, duration=5), unit.x, unit.y)
		yield


class StormglassEye(Component):
	def on_init(self):
		self.name = "Stormglass Eye"
		self.description = ("On Pickup:"
							"\nSummon a [Storm Cloud:lightning] over each enemy in line of sight"
							"\nEach cloud has a 50% chance to deal 25 [Lightning] damage each turn"
							"\n[Storm Clouds:lightning] last for 5 turns"
							"\nThis effect repeats every 6 turns until the end of the level")
		self.tags = [Tags.Eye, Tags.Lightning]

	def on_pickup(self, player, level):
		player.apply_buff(StormglassEyeBuff())

class IceWyrmScale(Component):
	def on_init(self):
		self.name = "Ice Wyrm Scale"
		self.description = "On Pickup:\nSummon a friendly Ice Wyrm Egg nearby"
		self.tags = [Tags.Dragon, Tags.Ice]

	def get_unit(self):
		return IceWyrmEgg()

	def on_pickup(self, player, level):
		level.summon(player, self.get_unit())

class MycelialOoze(Component):
	def on_init(self):
		self.name = "Mycelial Ooze"
		self.description = ("On Pickup:"
							"\nSummon 5 friendly Green Mushbooms nearby"
							"\nWhen they die, 3 Green Slimes are summoned from their corpses")
		self.tags = [Tags.Nature, Tags.Slime]

	def get_unit(self):
		u = GreenMushboom()
		u.buffs.append(SpawnOnDeath(GreenSlime, 3))
		return u

	def on_pickup(self, player, level):
		for _ in range(5):
			level.summon(player, self.get_unit(), sort_dist=False)

class GoldenDragonscale(Component):
	def on_init(self):
		self.name = "Golden Dragonscale"
		self.description = "On Pickup:\nDeal [10 Holy:holy] damage to enemies that harm you for the remainder of the level"
		self.tags = [Tags.Dragon, Tags.Holy]

	def on_pickup(self, player, level):
		buff = RetaliationBuff(10, Tags.Holy)
		buff.name = "Golden Dragonscale"
		buff.color = Tags.Holy.color
		buff.stack_type = STACK_INTENSITY
		player.apply_buff(buff)

class DragontongueTablet(Component):
	def on_init(self):
		self.name = "Dragontongue Tablet"
		self.description = "On Pickup:\nGain 1 SP if you know a [Dragon] spell"
		self.tags = [Tags.Dragon, Tags.Word]

	def on_pickup(self, player, level):
		if not player.is_player_controlled: return
		count = 0
		for s in player.spells:
			if Tags.Dragon in s.tags:
				s.do_ui_flash(tag=Tags.Dragon)
				count += 1
				break
		player.xp += count
		level.log(("Wizard gained {count} SP from the {name}", {'count':count, 'name':self.name}))

class CursedDice(Component):
	def on_init(self):
		self.name = "Cursed Dice"
		self.description = "On Pickup:\nCast Wheel of Death between 2 and 12 times"
		self.tags = [Tags.Dark, Tags.Sorcery]

	def on_pickup(self, player, level):
		num = random.randint(1, 6) + random.randint(1, 6)
		s = player.get_or_make_spell(WheelOfDeath)
		for _ in range(num): level.act_cast(player, s, player.x, player.y, pay_costs=False)


class Moonstone(Component):

	def on_init(self):
		self.name = "Moonstone"
		self.description = "On Pickup:\nSummon a friendly Lamasu"
		self.tags = [Tags.Conjuration, Tags.Holy]

	def get_unit(self):
		return Lamasu()

	def on_pickup(self, player, level):
		level.summon(player, self.get_unit())






# Tier 3 Components

class FrozenHeartwood(Component):
	def on_init(self):
		self.name = "Frozen Heartwood"
		self.description = ("On Pickup:\n"
							"Inflict 50 [Ice] damage and 6 turns of [frozen] on enemies within 5 tiles\n"
							"Allies are healed instead")
		self.tags = [Tags.Blood, Tags.Ice, Tags.Nature]

	def on_pickup(self, player, level):
		self.owner = player
		level.queue_spell(self.do_burst(player, level))

	def do_burst(self, player, level):
		for stage in Burst(level, player, 5):
			for p in stage:
				u = level.get_unit_at(p.x, p.y)
				if u:
					if u is player: continue
					elif are_hostile(player, u): u.deal_damage(50, Tags.Ice, self); u.apply_buff(FrozenBuff(), 6)
					else: u.heal(15, self)
				else:
					level.show_effect(p.x, p.y, Tags.Ice)
			yield


class StarfireIngot(Component):
	def on_init(self):
		self.name = "Starfire Ingot"
		self.description = "On Pickup:\nSummon a pair of Starfire Chimeras to fight for you"
		self.tags = [Tags.Arcane, Tags.Fire, Tags.Metallic]

	def get_unit(self):
		return StarfireChimera()

	def on_pickup(self, player, level):
		level.summon(player, self.get_unit())
		level.summon(player, self.get_unit())

class EidolonsStrings(Component):
	def on_init(self):
		self.name = "Eidolon's Strings"
		self.description = "On Pickup:\n[Arcane] enemies are [berserked] for 12 turns"
		self.tags = [Tags.Arcane, Tags.Dark, Tags.Enchantment]

	def on_pickup(self, player, level):
		for u in level.units:
			if are_hostile(player, u) and Tags.Arcane in u.tags:
				level.queue_spell(self.do_strings(player, u, level))

	def do_strings(self, player, u, level):
		level.show_path_effect(player, u, Tags.Arcane)
		u.apply_buff(BerserkBuff(), 12)
		yield

class TimelostInscriptionBuff(Buff):

	def on_init(self):
		self.name = "Timelost Inscription"
		self.color = Tags.Sorcery.color
		self.description = "When you cast a [Sorcery] spell, each of your other spells regains a charge"
		self.owner_triggers[EventOnSpellCast] = self.on_cast

	def on_cast(self, evt):
		if not (evt.spell and evt.spell.caster and evt.spell.tags and Tags.Sorcery in evt.spell.tags): return
		o = self.owner
		opts = [s for s in o.spells if s is not evt.spell]
		for s in opts: s.refund_charges(1)
		o.level.show_effect(o.x, o.y, Tags.Translocation)

class TimelostInscription(Component):
	def on_init(self):
		self.name = "Timelost Inscription"
		self.description = "On Pickup:\nFor the next 6 turns, when you cast a [Sorcery] spell, each of your other spells regains a charge"
		self.tags = [Tags.Sorcery, Tags.Translocation, Tags.Word]

	def on_pickup(self, player, level):
		player.apply_buff(TimelostInscriptionBuff(), 6)

class PlanarKeystone(Component):
	def on_init(self):
		self.name = "Planar Keystone"
		self.description = "On Pickup:\nCreate a new Rift under the wizard"
		self.tags = [Tags.Conjuration, Tags.Translocation, Tags.Orb]

	def on_pickup(self, player, level):
		level.queue_spell(self.make_portal(player, level)) #  queued so it doesn't mess with prop removal

	def make_portal(self, player, level):
		level.add_portal(Portal(level.gen_params.make_child_generator()), player.x, player.y)
		yield

class RunicFetish(Component):
	def on_init(self):
		self.name = "Runic Fetish"
		self.description = "On Pickup:\nEnemies in line of sight are afflicted by [Shared Pain:blood], which redeals damage dealt to one unit to the others"
		self.tags = [Tags.Blood, Tags.Dark, Tags.Enchantment]

	def on_pickup(self, player, level):
		for u in level.get_units_in_los(player):
			if are_hostile(player, u):
				level.queue_spell(self.do_binding(player, u, level))

	def do_binding(self, player, target, level):
		level.show_path_effect(player, target, Tags.Blood)
		target.apply_buff(SharedPainBuff())
		yield

class OozingOculite(Component):
	def on_init(self):
		self.name = "Oozing Oculite"
		self.description = "On Pickup:\nOne of your spells permanently gains +1 [range]"
		self.tags = [Tags.Chaos, Tags.Eye, Tags.Slime]

	def on_pickup(self, player, level):
		spells = [s for s in player.spells if s.range and not s.melee]
		if not spells: return
		s = random.choice(spells)
		s.do_ui_flash(tag=Tags.Slime)
		player.adjust_spell_bonus(type(s), 'range', 1)
		level.log(("[{component}:{tkey}] increased {spell}'s {attr} by {amt}",
			   {"component":self.name, 'tkey':tag_key(Tags.Chaos),  "spell": s.name, "attr": attr_label('range'), "amt":1}))


class AstralPhylacteryBuff(TimedComponentBuff):

	def __init__(self):
		TimedComponentBuff.__init__(self, 6)
		self.name = "Astral Phylactery"
		self.color = Tags.Dark.color
		self.description = "A random ally that is not already Soulbound becomes Soulbound to you and cannot die until you do"
		self.connected_targets = []

	def trigger(self):
		candidates = self.owner.get_allies()
		candidates = [u for u in candidates if not u.has_buff(Soulbound)]
		if not candidates: return
		target = random.choice(candidates)
		self.owner.level.show_path_effect(self.owner, target, Tags.Dark)
		target.apply_buff(Soulbound(self.owner))
		self.connected_targets.append(target)


class AstralPhylactery(Component):
	def on_init(self):
		self.name = "Astral Phylactery"
		self.description = ("On Pickup:"
							"\nA random ally that is not already Soulbound becomes Soulbound to you and cannot die until you do"
							"\nThis effect repeats every 6 turns until the end of the level")
		self.tags = [Tags.Arcane, Tags.Dark, Tags.Translocation]

	def on_pickup(self, player, level):
		player.apply_buff(AstralPhylacteryBuff())

class DefiledReliquary(Component):
	def on_init(self):
		self.name = "Defiled Reliquary"
		self.description = ("On Pickup:\n"
							"Summon a Defiled Reliquary nearby\n"
							"Each turn, it deals 10 [Dark] or [Holy] damage to enemies within 5 tiles")
		self.tags = [Tags.Dark, Tags.Holy, Tags.Metallic]

	def get_unit(self):
		u = Idol()
		u.name = "Defiled Reliquary"
		u.asset_name = 'defiled_reliquary'
		u.apply_buff(DamageAuraBuff(10, [Tags.Dark, Tags.Holy], 5, custom_name="Unholy Aura"))
		return u

	def on_pickup(self, player, level):
		level.summon(player, self.get_unit())

class ThundergodsFang(Component):
	def on_init(self):
		self.name = "Thundergod's Fang"
		self.description = "On Pickup:\nEnemies with the [Lightning] tag and less HP than you join your team"
		self.tags = [Tags.Lightning, Tags.Metallic, Tags.Nature]

	def on_pickup(self, player, level):
		targets = [u for u in level.units if Tags.Lightning in u.tags and u.cur_hp < player.cur_hp and are_hostile(u, player)]
		for t in targets: level.queue_spell(self.do_effect(player, t))

	def do_effect(self, player, unit):
		for p in player.level.get_points_in_line(player, unit): player.level.show_effect(p.x, p.y, Tags.Lightning); yield
		unit.team = player.team
		yield

class NacreousCysts(Component):
	def on_init(self):
		self.name = "Nacreous Cysts"
		self.description = "On Pickup:\nGain a 50% chance to summon a friendly Green Slime each turn for the remainder of the level"
		self.tags = [Tags.Dark, Tags.Metallic, Tags.Slime]

	def get_unit(self):
		return GreenSlime()

	def on_pickup(self, player, level):
		b = GeneratorBuff(GreenSlime, .5)
		b.name = "Nacreous Cysts"
		b.color = Tags.Slime.color
		player.apply_buff(b)

class ArchfiendsBone(Component):
	def on_init(self):
		self.name = "Archfiend's Bone"
		self.description = "On Pickup:\nSummon a Chaos Fiend to aid you for 16 turns"
		self.tags = [Tags.Chaos, Tags.Conjuration, Tags.Ritual]

	def get_unit(self):
		u = ChaosFiend()
		u.turns_to_death = 16
		return u

	def on_pickup(self, player, level):
		level.summon(player, self.get_unit())

class HagHeartBuff(TimedComponentBuff):

	def __init__(self):
		TimedComponentBuff.__init__(self, 1)
		self.name = "Hag Heart"
		self.color = Tags.Dark.color
		self.description = ("Deal 1 [Dark] damage to other [Living] units in line of sight"
							"\nHeal for damage dealt this way")

	def trigger(self):
		targets = [u for u in self.owner.level.get_units_in_los(self.owner) if Tags.Living in u.tags and u != self.owner]
		for target in targets: self.owner.level.queue_spell(self.bolt(target))

	def bolt(self, target):
		damage = target.deal_damage(1, Tags.Dark, self)
		yield
		for p in self.owner.level.get_points_in_line(target, self.owner, find_clear=True)[1:-1]:
			self.owner.level.show_effect(p.x, p.y, Tags.Dark, minor=True)
			yield
		if damage: self.owner.heal(damage, self)

class HagHeart(Component):
	def on_init(self):
		self.name = "Hag Heart"
		self.description = ("On Pickup:"
							"\nDeal 1 [Dark] damage to all other [Living] units in line of sight"
							"\nHeal for damage dealt this way"
							"\nThis effect repeats every turn until the end of the level")

		self.tags = [Tags.Dark, Tags.Blood, Tags.Sorcery]

	def on_pickup(self, player, level):
		player.apply_buff(HagHeartBuff())


class RavenEyeBuff(TimedComponentBuff):

	def __init__(self):
		TimedComponentBuff.__init__(self, 12)
		self.name = "Raven Eye"
		self.color = Tags.Dark.color
		self.description = "[Blind] all enemies for 6 turns"

	def trigger(self):
		self.owner.level.queue_spell(self.do_blindness())

	def do_blindness(self):
		tiles = [t for t in self.owner.level.iter_tiles()]
		random.shuffle(tiles)
		tiles.sort(key=lambda t: distance(self.owner, t, diag=True))
		for tile in tiles:
			unit = tile.unit
			if unit and are_hostile(self.owner, unit): unit.apply_buff(BlindBuff(), 6)
			elif random.random() < .25: self.owner.level.show_effect(tile.x, tile.y, Tags.Dark)
			if random.random() < .05: yield

class RavenEye(Component):
	def on_init(self):
		self.name = "Raven Eye"
		self.description = "On Pickup:\n[Blind] all enemies for 6 turns\nThis effect repeats every 12 turns until the end of the level"
		self.tags = [Tags.Dark, Tags.Eye, Tags.Enchantment]

	def on_pickup(self, player, level):
		player.apply_buff(RavenEyeBuff())


class FrostCoreBuff(TimedComponentBuff):

	def __init__(self):
		self.radius = 2
		TimedComponentBuff.__init__(self, 6)
		self.name = "Frost Core"
		self.color = Tags.Ice.color

	def get_effect_description(self):
		return "Inflict 10 [Ice] damage and 3 turns of [frozen] on enemies within [{radius}:radius] tiles", {'radius': self.radius}

	def trigger(self):
		self.owner.level.queue_spell(self.do_nova(self.radius))
		self.radius += 1

	def do_nova(self, radius):
		for stage in Burst(self.owner.level, self.owner, radius):
			for p in stage:
				unit = self.owner.level.get_unit_at(p.x, p.y)
				if unit and are_hostile(self.owner, unit):
					unit.deal_damage(10, Tags.Ice, self)
					unit.apply_buff(FrozenBuff(), 3)
				if not unit: self.owner.level.show_effect(p.x, p.y, Tags.Ice)
			yield


class FrostCore(Component):
	def on_init(self):
		self.name = "Frost Core"
		self.description = ("On Pickup:"
							"\nInflict 10 [Ice] damage and 3 turns of [frozen] on enemies within [2:radius] tiles"
							"\nEach time this effect repeats, its [radius] is increased by 1"
							"\nThis effect repeats every 6 turns until the end of the level")
		self.tags = [Tags.Ice, Tags.Sorcery, Tags.Metallic]

	def on_pickup(self, player, level):
		player.apply_buff(FrostCoreBuff())


class ArbiterLens(Component):
	def on_init(self):
		self.name = "Arbiter's Lens"
		self.description = ("On Pickup:\nSummon 3 Arbiters that disappear after 12 turns")
		self.tags = [Tags.Holy, Tags.Conjuration, Tags.Eye]

	def get_unit(self):
		u = Arbiter()
		u.turns_to_death = 12
		return u

	def on_pickup(self, player, level):
		for _ in range(3):
			level.summon(player, self.get_unit())


	# RARE COMPONENTS:

class Journeystone(Component):
	def on_init(self):
		self.name = "Journeystone"
		self.tags = [Tags.Translocation]
		self.description = "On Craft:\nIf the crafted equipment has the [Translocation] tag, it grants +6 [range] and [max charges:max_charges] to your [Translocation] spells and equipment"

	def on_craft(self, player, equipment):
		if Tags.Translocation not in equipment.tags: return
		equipment.tag_bonuses[Tags.Translocation]['range'] += 6
		equipment.tag_bonuses[Tags.Translocation]['max_charges'] += 6
		add_tooltip(equipment, self)

class MithrilOre(Component): # make this one Rare

	def on_init(self):
		self.name = "Mithril Ore"
		self.description = ("On Craft:"
							"\nIf the crafted equipment has the [damage] attribute, it deals +9 damage")
		self.tags = [Tags.Metallic]

	def on_craft(self, player, equipment):
		if hasattr(equipment, 'damage'): equipment.damage += 9
		add_tooltip(equipment, self)

class EnchantersAwl(Component):

	def on_init(self):
		self.name = "Enchanter's Awl"
		self.description = ("On Craft:"
							"\nIf the crafted equipment has the [Enchantment] tag, this is returned to your inventory after being used")
		self.tags = [Tags.Enchantment]

	def on_craft(self, player, equipment):
		if Tags.Enchantment not in equipment.tags: return
		player.level.show_effect(player.x, player.y, Tags.Arcane)
		player.add_component(type(self)())
		equipment.crafting_input_fns[type(self)] -= 1 # remove it from the stored ingredients so deconstruction shrine doesn't let you get infinite amounts of these

class LuminousThreads(Component):

	def on_init(self):
		self.name = "Luminous Threads"
		self.description = "On Craft:\nIf the crafted equipment grants the wearer resistances, it grants [SH:shields] equal to your [Holy] mastery at the start of each level"
		self.tags = [Tags.Enchantment, Tags.Holy]

	def on_craft(self, player, equipment):
		if not equipment.resists: return
		add_event_trigger(equipment.owner_triggers, EventOnUnitAdded, self.grant_shields)
		add_tooltip(equipment, self)

	def grant_shields(self, evt):
		sh = evt.unit.get_mastery(Tags.Holy)
		if sh: evt.unit.add_shields(sh)


class BloodrageSerum(Component):

	def on_init(self):
		self.name = "Bloodrage Serum"
		self.description = ("On Craft:\n"
							"If the crafted equipment has the [Blood] tag, it grants a stack of [Bloodrage:blood] for 3 turns when an enemy damages you\n"
							"[Bloodrage:blood] grants all spells and equipment +1 [damage]")
		self.tags = [Tags.Blood, Tags.Blood]

	def on_craft(self, player, equipment):
		if Tags.Blood not in equipment.tags: return
		add_event_trigger(equipment.owner_triggers, EventOnDamaged, self.do_rage)
		add_tooltip(equipment, self)

	def do_rage(self, evt):
		if not(evt.source and evt.source.owner and are_hostile(evt.source.owner, evt.unit)): return
		evt.unit.apply_buff(BloodrageBuff(1), 3)


class FlameBladeFragment(Component):

	def on_init(self):
		self.name = "Flame Blade Fragment"
		self.tags = [Tags.Fire, Tags.Metallic]
		self.description = "On Craft:\nThe crafted equipment grants a +3 [damage] bonus to spells and equipment to each of its tags"

	def on_craft(self, player, equipment):
		for t in equipment.tags: equipment.tag_bonuses[t]['damage'] += 3
		add_tooltip(equipment, self)


class IronbarkPlate(Component):
	def on_init(self):
		self.name = "Ironbark Plate"
		self.description = "On Craft:\nIf the crafted equipment has the [Nature] or [Metallic] tag, it gains +25% [Physical] and [Poison] resistances"
		self.tags = [Tags.Nature, Tags.Metallic]

	def on_craft(self, player, equipment):
		if Tags.Nature not in equipment.tags and Tags.Metallic not in equipment.tags: return
		equipment.resists[Tags.Physical] += 25
		equipment.resists[Tags.Poison] += 25
		add_tooltip(equipment, self)


class PhoenixFeather(Component):

	def on_init(self):
		self.name = "Phoenix Feather"
		self.tags = [Tags.Fire, Tags.Holy]
		self.description = ("On Craft:\nIf the crafted equipment has the [Fire] tag, it heals you for [1 HP:heal] when you cast a [Fire] spell"
							"\nIf the crafted equipment has the [Holy] tag, it heals you for [1 HP:heal] when you cast a [Holy] spell")

	def on_craft(self, player, equipment):
		if Tags.Fire in equipment.tags:
			def heal_on_cast_fire(evt, equipment=equipment):
				if Tags.Fire not in evt.spell.tags: return
				evt.caster.heal(1, equipment)
			add_event_trigger(equipment.owner_triggers, EventOnSpellCast, heal_on_cast_fire)
		if Tags.Holy in equipment.tags:
			def heal_on_cast_holy(evt, equipment=equipment):
				if Tags.Holy not in evt.spell.tags: return
				evt.caster.heal(1, equipment)
			add_event_trigger(equipment.owner_triggers, EventOnSpellCast, heal_on_cast_holy)
		add_tooltip(equipment, self)


class ChaosSeed(Component):
	def on_init(self):
		self.name = "Chaos Seed"
		self.description = ("On Craft:\nIf the crafted equipment has the [Nature] tag, it gains the [Chaos] tag"
							"\nAny attribute bonuses the equipment provides to [Nature] spells and equipment are also provided to [Chaos] spells and equipment"
							"\nAny effects which trigger specifically from [Nature] spells also trigger from [Chaos] spells")
		self.tags = [Tags.Chaos, Tags.Nature]

	def on_craft(self, player, equipment):
		if Tags.Nature not in equipment.tags: return
		if Tags.Chaos not in equipment.tags: equipment.tags.append(Tags.Chaos)
		for bonus in equipment.tag_bonuses[Tags.Nature].items():
			stat, val = bonus
			equipment.tag_bonuses[Tags.Chaos][stat] += val
		for bonus in equipment.tag_bonuses_pct[Tags.Nature].items():
			stat, val = bonus
			equipment.tag_bonuses_pct[Tags.Chaos][stat] += val
		trigger_tags = getattr(equipment, 'trigger_tags', None)
		if trigger_tags and Tags.Nature in trigger_tags and Tags.Chaos not in trigger_tags:
			equipment.trigger_tags.append(Tags.Chaos)

		add_tooltip(equipment, self)


class CharredRelic(Component):
	def on_init(self):
		self.name = "Charred Relic"
		self.description = "On Craft:\nIf the crafted equipment has the [Holy] tag, it grants a random [Holy] spell you know +1 to each of its base attributes"
		self.tags = [Tags.Fire, Tags.Holy, Tags.Metallic]

	def on_craft(self, player, equipment):
		if Tags.Holy not in equipment.tags: return
		opts = [s for s in player.spells if Tags.Holy in s.tags and s.stats]
		if not opts: return
		s = random.choice(opts)
		s.do_ui_flash(tag=Tags.Holy)
		attrs = [stat for stat in s.stats if getattr(s, stat, 0) > 0 and stat in stat_names]
		for stat in attrs: equipment.spell_bonuses[type(s)][stat] += 1
		add_tooltip(equipment, self)
		s.refund_charges(1)


class DragonAmbrosia(Component):
	def on_init(self):
		self.name = "Dragon Ambrosia"
		self.description = "On Craft:\nIf the crafted equipment has the [Dragon] tag, it grants +1 [max charges:max_charges] to all [Dragon] spells for each [Dragon] spell you know"
		self.tags = [Tags.Dragon, Tags.Dragon]

	def on_craft(self, player, equipment):
		if Tags.Dragon not in equipment.tags: return
		count = 0
		dragon_spells = [s for s in player.spells if Tags.Dragon in s.tags]
		equipment.tag_bonuses[Tags.Dragon]['max_charges'] += len(dragon_spells)
		player.level.show_effect(player.x, player.y, Tags.Dragon)
		add_tooltip(equipment, self)
		for s in dragon_spells: s.refund_charges(count)


class ChimeraEyes(Component):
	def on_init(self):
		self.name = "Chimera Eyes"
		self.description = "On Craft:\nIf the crafted equipment has the [Chaos] or [Eye] tags, Chimera Eyes grants [Eye] spells you know a random upgrade\n\nIf this component grants one or more upgrades, it is destroyed"
		self.tags = [Tags.Eye, Tags.Chaos, Tags.Eye]

	def on_craft(self, player, equipment):
		add_tooltip(equipment, self)
		if Tags.Chaos not in equipment.tags and Tags.Eye not in equipment.tags: return
		opts = [s for s in player.spells if Tags.Eye in s.tags and any(u for u in s.spell_upgrades if not u.applied)]
		if not opts: return
		for s in opts:
			upg_opts = [u for u in s.spell_upgrades if not u.applied]
			upgrade = random.choice(upg_opts)
			player.apply_buff(upgrade)
			s.do_ui_flash(tag=Tags.Chaos)
			player.level.log(("[Chimera Eyes:chaos] upgraded {spell} with {upgrade}", {'spell': s.name, 'upgrade': upgrade.name}))
		equipment.crafting_input_fns[type(self)] -= 1


class WarlordsSkull(Component):
	def on_init(self):
		self.name = "Warlord's Skull"
		self.description = ("On Craft:\nIf the crafted equipment would provide bonuses to [damage], [duration], [range], or [num_targets], "
							"it provides those bonuses to [minion_damage], [minion_duration], [minion_range], or [num_summons] instead")
		self.tags = [Tags.Conjuration, Tags.Conjuration]

	def on_craft(self, player, equipment):
		targets = ['damage', 'range', 'duration', 'num_targets']
		converts = ['minion_damage', 'minion_range', 'minion_duration', 'num_summons']
		tag_boosts = [equipment.tag_bonuses, equipment.tag_bonuses_pct]
		global_boosts = [equipment.global_bonuses, equipment.global_bonuses_pct]
		for boost in tag_boosts:
			tags_to_drop = []
			for tag, stats in boost.items():
				for i in range(len(targets)):
					stat = stats.get(targets[i], 0)
					if stat:
						stats[converts[i]] += stat
						stats.pop(targets[i], None)
				if not stats: tags_to_drop.append(tag)
			for tag in tags_to_drop: boost.pop(tag, None)

		for boost in global_boosts:
			for i in range(len(targets)):
				stat = boost.get(targets[i], 0)
				if stat:
					boost[converts[i]] += stat
					boost.pop(targets[i], None)

		add_tooltip(equipment, self)


class OdinsEye(Component):
	def on_init(self):
		self.name = "Odin's Eye"
		self.description = "On Craft:\nFor each of the crafted equipment's tags, cast a random self-targeted [Eye] spell you know with that tag at the beginning of each level"
		self.tags = [Tags.Eye]

	def on_craft(self, player, equipment):
		def autocast(evt, equipment=equipment):
			chosen = []
			for tag in equipment.tags:
				opts = [s for s in evt.unit.spells if Tags.Eye in s.tags and tag in s.tags and s.range == 0]
				if not opts:continue
				chosen.append(random.choice(opts))
			for s in chosen:
				evt.unit.level.act_cast(evt.unit, s, evt.unit.x, evt.unit.y, pay_costs=False)
				s.do_ui_flash(tag=Tags.Eye)
		add_event_trigger(equipment.owner_triggers, EventOnUnitAdded, autocast)
		add_tooltip(equipment, self)


class BrokenStopwatch(Component):
	def on_init(self):
		self.name = "Broken Stopwatch"
		self.description = ("On Craft:"
							"\nIf used to craft a piece of equipment with the [duration] attribute, it gains +3 duration")
		self.tags = [Tags.Arcane, Tags.Enchantment, Tags.Metallic]

	def on_craft(self, player, equipment):
		if hasattr(equipment, 'duration'): equipment.duration += 3
		add_tooltip(equipment, self)


class AmaranthinePetal(Component):

	def on_init(self):
		self.name = "Amaranthine Petal"
		self.tags = [Tags.Blood, Tags.Nature]
		self.description = "On Craft:\nThe crafted equipment grants a +1 [duration] bonus to spells and equipment to each of its tags"

	def on_craft(self, player, equipment):
		for t in equipment.tags: equipment.tag_bonuses[t]['duration'] += 1
		add_tooltip(equipment, self)

class CursedRosary(Component):

	def on_init(self):
		self.name = "Cursed Rosary"
		self.tags = [Tags.Dark, Tags.Ritual]
		self.description = "On Craft:\nIf the crafted equipment has the [Dark] or [Ritual] tags, it heals you to full health when you complete a ritual"

	def on_craft(self, player, equipment):
		if Tags.Dark in equipment.tags or Tags.Ritual in equipment.tags:
			def heal_on_ritual_completion(evt, equipment=equipment):
				evt.caster.heal(evt.caster.max_hp, equipment)
				equipment.do_ui_flash(Tags.Ritual)
			add_event_trigger(equipment.owner_triggers, EventOnRitualComplete, heal_on_ritual_completion)
		add_tooltip(equipment, self)

class StormsongNote(Component):

	def on_init(self):
		self.name = "Stormsong Note"
		self.tags = [Tags.Ice, Tags.Lightning, Tags.Word]
		self.description = ("On Craft:\nIf the crafted equipment has the [Ice] tag, it summons [Blizzards:ice] at random locations when you manually cast an [Ice] spell"
							"\nIf the crafted equipment has the [Lightning] tag, it summons [Storm Clouds:lightning] at random locations when you manually cast a [Lightning] spell"
							"\nThe number of clouds created is equal to the spell's level"
							"\nThe [damage] and [duration] of the clouds scale with the equipment")

	def on_craft(self, player, equipment):
		add_tooltip(equipment, self)
		if Tags.Ice in equipment.tags:
			def blizzard_on_cast(evt, equipment=equipment):
				if not evt.pay_costs: return
				if Tags.Ice not in evt.spell.tags: return
				u = evt.caster
				tiles = [tile for tile in u.level.iter_tiles() if not tile.cloud and not tile.is_wall() and not (tile.x == u.x and tile.y == u.y)]
				random.shuffle(tiles)
				equipment.do_ui_flash(Tags.Ice)
				for _ in range(evt.spell.level):
					if not tiles: return
					tile = tiles.pop()
					u.level.add_obj(BlizzardCloud(u, equipment.get_stat('damage', base=5), equipment.get_stat('duration', base=5)), tile.x, tile.y)
			add_event_trigger(equipment.owner_triggers, EventOnSpellCast, blizzard_on_cast)
			equipment.add_effect_tooltip(lambda: BlizzardCloud(player, equipment.get_stat('damage', base=5), equipment.get_stat('duration', base=5)))

		if Tags.Lightning in equipment.tags:
			def storm_on_cast(evt, equipment=equipment):
				if not evt.pay_costs: return
				if Tags.Lightning not in evt.spell.tags: return
				u = evt.caster
				tiles = [tile for tile in u.level.iter_tiles() if not tile.cloud and not tile.is_wall() and not (tile.x == u.x and tile.y == u.y)]
				random.shuffle(tiles)
				equipment.do_ui_flash(Tags.Lightning)
				for _ in range(evt.spell.level):
					if not tiles: return
					tile = tiles.pop()
					u.level.add_obj(StormCloud(u, equipment.get_stat('damage', base=10), equipment.get_stat('duration', base=5)), tile.x, tile.y)
			add_event_trigger(equipment.owner_triggers, EventOnSpellCast, storm_on_cast)
			equipment.add_effect_tooltip(lambda: StormCloud(player, equipment.get_stat('damage', base=10), equipment.get_stat('duration', base=5)))


class DiscardedHomunculi(Component):

	def on_init(self):
		self.name = "Discarded Homunculi"
		self.tags = [Tags.Blood, Tags.Conjuration]
		self.description = "On Craft:\nIf the crafted equipment has the [num_summons] attribute, it gains +2 [num_summons]"

	def on_craft(self, player, equipment):
		add_tooltip(equipment, self)
		if not getattr(equipment, 'num_summons', None): return
		equipment.num_summons += 2


class PolymathsPalimpsest(Component):

	def on_init(self):
		self.name = "Polymath's Palimpsest"
		self.tags = [Tags.Conjuration, Tags.Enchantment, Tags.Sorcery]
		self.description = "On Craft:\nIf the crafted equipment has the [Word] tag in its recipe, this is returned to your inventory after being used"

	def on_craft(self, player, equipment):
		if Tags.Word not in [t for t,e in equipment.recipe]: return
		player.add_component(type(self)())
		equipment.crafting_input_fns[type(self)] -= 1  # remove it from the stored ingredients so deconstruction shrine doesn't let you get infinite amounts of these

class FamiliarsCollar(Component):

	def on_init(self):
		self.name = "Familiar's Collar"
		self.description = "On Craft:\nWhen the crafted equipment summons a unit, pay [3 HP:blood] to make it Soulbound to the wizard"
		self.tags = [Tags.Blood, Tags.Conjuration, Tags.Enchantment]

	def on_craft(self, player, equipment):
		def bind_on_summon(evt, equipment=equipment):
			if are_hostile(evt.unit, equipment.owner): return
			if getattr(evt.unit, 'source', None) != equipment: return
			if evt.unit.has_buff(Soulbound): return
			if equipment.owner.pay_hp(3, equipment.name):
				evt.unit.apply_buff(Soulbound(evt.unit.level.player_unit))
				evt.unit.level.show_path_effect(equipment.owner, evt.unit, Tags.Blood, minor=True)
		add_event_trigger(equipment.global_triggers, EventOnUnitAdded, bind_on_summon)
		add_tooltip(equipment, self)
		add_tooltip(equipment, Soulbound(player))

class SkeletonKey(Component):

	def on_init(self):
		self.name = "Skeleton Key"
		self.description = "On Craft:\nIf the crafted equipment has the [Translocation] tag, gain an additional Rift reroll each level"
		self.tags = [Tags.Dark, Tags.Metallic, Tags.Translocation]

	def on_craft(self, player, equipment):
		add_tooltip(equipment, self)
		if Tags.Translocation not in equipment.tags: return
		if not player.is_player_controlled: return
		def add_reroll(evt, equipment=equipment): equipment.owner.game.rift_rerolls += 1
		add_event_trigger(equipment.global_triggers, EventOnLevelComplete, add_reroll)
		if player.game.level_cleared: player.game.rift_rerolls += 1 # grant the reroll now if they craft after the level's over

class PrimordialOoze(Component):

	def on_init(self):
		self.name = "Primordial Ooze"
		self.description = "On Craft:\nIf the crafted equipment has the [Slime] tag, a random spell you know gains the [Slime] tag"
		self.tags = [Tags.Slime]

	def on_craft(self, player, equipment):
		add_tooltip(equipment, self)
		if Tags.Slime not in equipment.tags: return
		opts = [s for s in player.spells if Tags.Slime not in s.tags]
		if not opts: return False
		s = random.choice(opts)
		s.tags.append(Tags.Slime)
		s.do_ui_flash(Tags.Slime)
		s.sync_upgrade_tags()
		player.invalidate_spell_stats()

class QuipuSaga(Component):

	def on_init(self):
		self.name = "Quipu Saga"
		self.description = "On Craft:\nIf the crafted equipment has the [damage] attribute, at the end of each level it gains +1 [damage]"
		self.tags = [Tags.Nature, Tags.Word, Tags.Word]

	def on_craft(self, player, equipment):
		add_tooltip(equipment, self)
		if not getattr(equipment, 'damage', None): return
		if not player.is_player_controlled: return
		def damage_bump(evt, equipment=equipment):
			equipment.damage += 1
			equipment.do_ui_flash()
		add_event_trigger(equipment.global_triggers, EventOnLevelComplete, damage_bump)
		if player.game.level_cleared: equipment.damage += 1 ; equipment.do_ui_flash() # grant the damage now if they craft after the level's over

class WorldstoneSocket(Component):

	def on_init(self):
		self.name = "Worldstone Socket"
		self.description = "On Craft:\nIf the crafted equipment has the [radius] attribute, it gains +2 [radius]"
		self.tags = [Tags.Nature, Tags.Orb]

	def on_craft(self, player, equipment):
		add_tooltip(equipment, self)
		if not getattr(equipment, 'radius', None): return
		equipment.radius += 2

def roll_random_component(prng=random, tier=None, tag_req=None, avoid_tags=None):
	opts = []
	desired_tier = [tier] if tier else [1, 2, 3]
	if tag_req: opts = [type(c) for c in all_components_ex if tag_req in c.tags and len(c.tags) in desired_tier]
	if avoid_tags: opts = [type(c) for c in all_components_ex if not any(t in avoid_tags for t in c.tags) and len(c.tags) in desired_tier]
	if not opts: opts = [type(c) for c in all_components_ex if len(c.tags) in desired_tier]
	return prng.choice(opts)

t1_components = [
	BurningEmber,
	ElementalIce,
	LightningJar,
	Wildflower,
	ArcaneMote,
	Shadeweave,
	HolyIcon,
	ShieldingShard,
	HeartFragment,
	MagicRune,
	LostRing,
	Incense,
	RiftResidue
]

t2_components = [
	SeersOrb,
	Drakentooth,
	DevilsBlood,
	SlimeCore,
	AncientInscription,
	Shimmersteel,
	Frostpetal,
	SilverDragonscale,
	RelocatorBeacon,
	VoidstoneShard,
	BindingRing,
	RunedVellum,
	CursedSeal,
	Hellbloom,
	VoltaicAsh,
	GlacialScript,
	BeastbloodFungus,
	ScriptedCortex,
	UmbralResin,
	ChargedCog,
	SacrificialBrand,
	CrimsonSigil,
	SanctifiedLocket,
	FulminiteShard,
	RetinalJelly,
	WarpedDragonEgg,
	VotiveCandle,
	DreamthornVine,
	WatcherStone,
	BloodBasin,
	HolyWater,
	MirrorStone,
	StormglassEye,
	IceWyrmScale,
	MycelialOoze,
	GoldenDragonscale,
	DragontongueTablet,
	CursedDice,
	Moonstone,
]

t3_components = [
	FrozenHeartwood,
	StarfireIngot,
	EidolonsStrings,
	TimelostInscription,
	PlanarKeystone,
	RunicFetish,
	OozingOculite,
	AstralPhylactery,
	DefiledReliquary,
	ThundergodsFang,
	NacreousCysts,
	ArchfiendsBone,
	HagHeart,
	RavenEye,
	FrostCore,
	ArbiterLens,
]

rare_components = [
	Journeystone,
	MithrilOre,
	EnchantersAwl,
	OdinsEye,
	PrimordialOoze,

	LuminousThreads,
	BloodrageSerum,
	FlameBladeFragment,
	IronbarkPlate,
	PhoenixFeather,
	ChaosSeed,
	DragonAmbrosia,
	WarlordsSkull,
	CursedRosary,
	DiscardedHomunculi,
	WorldstoneSocket,

	CharredRelic,
	ChimeraEyes,
	BrokenStopwatch,
	AmaranthinePetal,
	StormsongNote,
	PolymathsPalimpsest,
	FamiliarsCollar,
	SkeletonKey,
	QuipuSaga,
]

all_components = t1_components + t2_components + t3_components
all_components_ex = [c() for c in all_components]

component_tags = {
	Tags.Fire,
	Tags.Ice,
	Tags.Lightning,
	Tags.Nature,
	Tags.Arcane,
	Tags.Dark,
	Tags.Holy,
	Tags.Metallic,
	Tags.Blood,
	Tags.Sorcery,
	Tags.Enchantment,
	Tags.Conjuration,
	Tags.Eye,
	Tags.Dragon,
	Tags.Orb,
	Tags.Chaos,
	Tags.Slime,
	Tags.Word,
	Tags.Translocation,
	Tags.Ritual,
	Tags.Any
}

def weigh_tag_representation():
	total_tags = defaultdict(int)
	total_objects = defaultdict(int)
	component_tag_representation = defaultdict(int)
	for c in all_components:
		c = c()
		for t in c.tags: component_tag_representation[t.name] += 1; total_tags["Components"] += 1
		total_objects["Components"] += 1

	from Spells import all_player_spell_constructors as spells
	spell_tag_representation = defaultdict(int)
	for s in spells:
		s = s()
		for t in s.tags:
			spell_tag_representation[t.name] += 1
			total_tags["Spells"] += 1
		total_objects["Spells"] += 1

	from Equipment import all_equipment as equipment
	equipment_tag_representation = defaultdict(int)
	for e in equipment:
		e = e()
		if not e.recipe: continue
		for entry in e.recipe:
			if (
				not isinstance(entry, tuple)
				or len(entry) != 2
				or not hasattr(entry[0], "name")  # loose Tag check
				or not isinstance(entry[1], int)
				or entry[1] <= 0
			):
				print(f"{e.name} has a malformed recipe")
				break  # only show one error per equipment
			t, a = entry
			if t == Tags.Any: continue
			for i in range(a): # want to know how many those tags are required
				equipment_tag_representation[t.name] += 1
				total_tags["Equipment"] += 1
		total_objects["Equipment"] += 1

	print("Tag Representation:\n")
	for t, n in component_tag_representation.items():
		cn = round(n * 100 / total_tags["Components"])
		en = round(equipment_tag_representation[t] * 100 / total_tags["Equipment"]) if t in equipment_tag_representation else 0
		sn = round(spell_tag_representation[t] * 100 / total_tags["Spells"]) if t in spell_tag_representation else 0
		# Want Equipment representation to roughly match Spell representation
		equip_msg = ""
		if sn - en > 5: equip_msg = f"Make more {t} equipment to match spells"
		# Want Components representation to roughly match Equipments
		comp_msg = ""
		if en - cn > 5: comp_msg = f"Make more {t} components to match equipment"
		if equip_msg or comp_msg: suggestion = " ".join(s for s in (equip_msg, comp_msg) if s) # ideally we want to make more of the least to bring it into rough parity
		else: suggestion = ""
		print(f"{t}: components:{cn}%, equipment:{en}%, spells:{sn}%.    {suggestion}")

	print(f"{len(equipment)} total equipment")
	print(f"{len(spells)} total spells")
	print(f"{len(all_components)} total components")

def list_unused_tag_combos():
	ignore = {Tags.Any}
	all_tags = [t for t in component_tags if t not in ignore]

	def norm2(a, b):
		an, bn = a if isinstance(a, str) else a.name, b if isinstance(b, str) else b.name
		return (an, bn) if an <= bn else (bn, an)

	def norm3(a, b, c):
		ns = [a if isinstance(a, str) else a.name,
		      b if isinstance(b, str) else b.name,
		      c if isinstance(c, str) else c.name]
		# simple 3-item sort without imports
		if ns[0] > ns[1]: ns[0], ns[1] = ns[1], ns[0]
		if ns[1] > ns[2]: ns[1], ns[2] = ns[2], ns[1]
		if ns[0] > ns[1]: ns[0], ns[1] = ns[1], ns[0]
		return ns[0], ns[1], ns[2]

	existing_pairs = set()
	existing_triples = set()
	loc_pair = {}    # ('Fire','Holy') -> ['T2', 'T3', ...]
	loc_triple = {}  # ('Fire','Holy','Orb') -> ['T3', ...]

	for ccls in all_components:
		c = ccls()
		tags = [t for t in c.tags if t not in ignore]
		n = len(tags)

		# pairs present in this component
		for i in range(n):
			for j in range(i + 1, n):
				k = norm2(tags[i], tags[j])
				existing_pairs.add(k)
				loc_pair.setdefault(k, []).append("T2" if n == 2 else "T3")

		# triples present in this component
		for i in range(n):
			for j in range(i + 1, n):
				for k in range(j + 1, n):
					key = norm3(tags[i], tags[j], tags[k])
					existing_triples.add(key)
					loc_triple.setdefault(key, []).append("T3")

	# all possible pairs/triples from tag set
	all_pairs = set()
	for i in range(len(all_tags)):
		for j in range(i + 1, len(all_tags)):
			all_pairs.add(norm2(all_tags[i], all_tags[j]))

	all_triples = set()
	for i in range(len(all_tags)):
		for j in range(i + 1, len(all_tags)):
			for k in range(j + 1, len(all_tags)):
				all_triples.add(norm3(all_tags[i], all_tags[j], all_tags[k]))

	unused_pairs = [p for p in all_pairs if p not in existing_pairs]
	unused_triples = [t for t in all_triples if t not in existing_triples]

	def sort2(lst):
		return sorted(lst, key=lambda x: (x[0], x[1]))
	def sort3(lst):
		return sorted(lst, key=lambda x: (x[0], x[1], x[2]))

	print(f"\n=== Missing 2-tag components: {len(unused_pairs)} ===")
	for p in sort2(unused_pairs):
		print(" + ".join(p))

	print(f"\n=== Missing 3-tag components: {len(unused_triples)} ===")
	for t in sort3(unused_triples)[:200]:  # cap if huge
		print(" + ".join(t))



if __name__ == "__main__":
	weigh_tag_representation()
	# results = avg_tags_per_level()
	# for lvl, avg_tags in results.items():
	# 	print(f"Level {lvl}: Avg tag income = {avg_tags:.2f}")

	# list_unused_tag_combos()
