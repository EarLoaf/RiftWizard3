import importlib.machinery
import importlib.util
import os
import sys
import time
import traceback
import types

import SteamAdapter


loaded_mods = []
load_errors = []
load_error_entries = []
tag_filter_letters = {}


def reset():
	loaded_mods.clear()
	load_errors.clear()
	load_error_entries.clear()
	tag_filter_letters.clear()


def register_tag(name, color, letter=None, asset=None, shop_filter=True):
	if letter:
		letter = letter.lower()
		assert len(letter) == 1 and 'a' <= letter <= 'z'

	from Level import Tag, Tags
	from Spells import spell_tags

	tag = Tag(name, color, asset)
	Tags.add(tag)
	if shop_filter: spell_tags.append(tag)
	if letter: tag_filter_letters[tag.name] = letter
	return tag


def register_component(component, rare=False):
	from Level import Component
	from Components import t1_components, t2_components, t3_components, rare_components, all_components, all_components_ex, component_tags

	sample = component()
	assert isinstance(sample, Component)
	component_tags.update(sample.tags)

	if rare:
		rare_components.append(component)
		return component

	tier_lists = {
		1: t1_components,
		2: t2_components,
		3: t3_components,
	}
	tier = len(sample.tags)
	assert tier in tier_lists

	tier_lists[tier].append(component)
	all_components.append(component)
	all_components_ex.append(sample)
	return component


def get_loaded_mods():
	return list(loaded_mods)


def get_loaded_mod_names():
	return [mod['label'] for mod in loaded_mods]


def get_load_errors():
	return list(load_errors)


def get_load_error_entries():
	return [dict(entry) for entry in load_error_entries]


def get_load_error_count():
	return len(load_error_entries)


def get_load_error_summary_for_mod(mod_name):
	for entry in load_error_entries:
		if entry['mod_name'] == mod_name:
			return entry['summary']
	return ""


def get_first_load_error_summary():
	if not load_error_entries:
		return ""
	return load_error_entries[0]['summary']


def add_load_error(summary, mod_name=None, details=None):
	load_error_entries.append({
		'mod_name': mod_name,
		'summary': summary,
		'details': details,
	})
	load_errors.append(summary)
	if details:
		load_errors.append(details)


def find_asset(asset):
	for mod in reversed(loaded_mods):
		path = os.path.join(mod['root'], *asset) + '.png'
		if os.path.exists(path):
			return path

	if len(asset) > 1:
		for mod in reversed(loaded_mods):
			if asset[0] != mod['mod_name']: continue
			path = os.path.join(mod['root'], *asset[1:]) + '.png'
			if os.path.exists(path): return path

	return None


def ensure_mods_package():
	if 'mods' not in sys.modules:
		package = types.ModuleType('mods')
		package.__path__ = []
		sys.modules['mods'] = package
		return package

	package = sys.modules['mods']
	try:
		package.__path__
	except AttributeError:
		package.__path__ = []
	return package


def register_mod_parent(root):
	parent = os.path.dirname(root)
	if not parent:
		return

	package = ensure_mods_package()
	if parent not in package.__path__:
		package.__path__.append(parent)


def make_mod_record(mod_name, root, entry_path, source, workshop_item_id=None):
	label = mod_name
	if source == 'workshop':
		label = "%s [Workshop %s]" % (mod_name, workshop_item_id)

	return {
		'mod_name': mod_name,
		'label': label,
		'root': root,
		'entry_path': entry_path,
		'source': source,
		'workshop_item_id': workshop_item_id,
	}


def read_mod_description(root):
	path = os.path.join(root, 'description.txt')
	if not os.path.exists(path):
		return ""

	with open(path, 'r', encoding='utf-8') as file:
		return file.read().strip()


def find_entry_path(folder):
	if not os.path.isdir(folder):
		return (None, None)

	mod_name = os.path.basename(os.path.normpath(folder))
	entry_path = os.path.join(folder, mod_name + '.py')
	if os.path.exists(entry_path):
		return (mod_name, entry_path)
	return (None, None)


def discover_local_mods():
	modfolder = 'mods'
	if not os.path.exists(modfolder):
		return []

	candidates = []
	for name in sorted(os.listdir(modfolder)):
		root = os.path.join(modfolder, name)
		if not os.path.isdir(root): continue
		mod_name, entry_path = find_entry_path(root)
		if not entry_path: continue
		if mod_name == 'example_mod': continue # do not load this, it's for modders to look at only
		candidates.append(make_mod_record(mod_name, root, entry_path, 'local'))
	return candidates


def get_workshop_item_folders(error_list=None):
	try:
		items = SteamAdapter.get_installed_workshop_items()
	except Exception as exc:
		add_load_error("Workshop discovery failed: %s" % exc)
		return []

	return [(item['item_id'], item['folder']) for item in items]


def discover_workshop_mods(error_list=None):
	candidates = []
	for item_id, folder in get_workshop_item_folders(error_list):
		item_candidates = []
		for name in sorted(os.listdir(folder)):
			root = os.path.join(folder, name)
			if not os.path.isdir(root): continue
			mod_name, entry_path = find_entry_path(root)
			if not entry_path: continue
			item_candidates.append(make_mod_record(mod_name, root, entry_path, 'workshop', item_id))

		if not item_candidates:
			add_load_error("Workshop item %s has no valid mod payload at %s" % (item_id, folder))
			continue

		if len(item_candidates) > 1:
			add_load_error("Workshop item %s has multiple mod payloads at %s" % (item_id, folder))
			continue

		candidates.append(item_candidates[0])
	return candidates


def discover_mods(error_list=None):
	local_mods = discover_local_mods()
	workshop_mods = discover_workshop_mods(error_list)
	grouped = {}

	for mod in local_mods:
		grouped[mod['mod_name']] = {
			'mod_name': mod['mod_name'],
			'local': mod,
			'workshop': [],
		}

	for mod in workshop_mods:
		entry = grouped.setdefault(mod['mod_name'], {
			'mod_name': mod['mod_name'],
			'local': None,
			'workshop': [],
		})
		entry['workshop'].append(mod)

	catalog = []
	for mod_name in sorted(grouped):
		entry = grouped[mod_name]
		active = entry['local'] if entry['local'] else entry['workshop'][0]
		catalog.append({
			'mod_name': mod_name,
			'active': active,
			'local': entry['local'],
			'workshop': list(entry['workshop']),
			'has_local': entry['local'] is not None,
			'has_workshop': bool(entry['workshop']),
			'description': read_mod_description(active['root']),
		})

	return catalog


def load_mod(mod):
	mod_name = mod['mod_name']
	package_name = 'mods.' + mod_name
	legacy_name = package_name + '.' + mod_name
	register_mod_parent(mod['root'])
	parent_package = ensure_mods_package()

	package_spec = importlib.machinery.ModuleSpec(package_name, loader=None, is_package=True)
	package_spec.submodule_search_locations = [mod['root']]
	package_module = importlib.util.module_from_spec(package_spec)
	package_module.__path__ = [mod['root']]
	package_module.__file__ = mod['entry_path']
	sys.modules[package_name] = package_module
	setattr(parent_package, mod_name, package_module)

	spec = importlib.util.spec_from_file_location(legacy_name, mod['entry_path'])
	if spec is None or spec.loader is None:
		raise ImportError("Could not create import spec for %s" % mod['entry_path'])

	module = importlib.util.module_from_spec(spec)
	sys.modules[legacy_name] = module
	setattr(package_module, mod_name, module)

	try:
		spec.loader.exec_module(module)
	except Exception:
		delattr(parent_package, mod_name)
		delattr(package_module, mod_name)
		sys.modules.pop(package_name, None)
		sys.modules.pop(legacy_name, None)
		raise


def load_mods(enabled_mod_names):
	reset()
	catalog = discover_mods()
	catalog_by_name = {mod['mod_name']: mod for mod in catalog}

	# Steam Workshop folders may become visible shortly after initialization.
	for _ in range(3):
		if all(mod_name in catalog_by_name for mod_name in enabled_mod_names): break
		time.sleep(.25)
		catalog = discover_mods()
		catalog_by_name = {mod['mod_name']: mod for mod in catalog}

	selected_mod_names = []
	seen_mod_names = set()

	for mod_name in enabled_mod_names:
		if mod_name in seen_mod_names:
			continue
		seen_mod_names.add(mod_name)
		if mod_name not in catalog_by_name:
			add_load_error("Enabled mod %s was not found." % mod_name, mod_name=mod_name)
			continue
		selected_mod_names.append(mod_name)

	for mod_name in selected_mod_names:
		mod = catalog_by_name[mod_name]['active']

		try:
			load_mod(mod)
		except Exception as exc:
			add_load_error("Failed to load %s: %s" % (mod['label'], exc), mod_name=mod_name, details=traceback.format_exc())
			continue

		loaded_mods.append(mod)
		seen_mod_names.add(mod_name)

	if loaded_mods:
		print("Loaded mods:")
		for mod in loaded_mods:
			print(mod['label'])

	if load_errors:
		print("Mod load errors:")
		for error in load_errors:
			print(error)
