from Level import *
from CommonContent import *
import random


class BreathWeapon(Spell):

	def __init__(self):
		Spell.__init__(self)
		self.range = 5
		self.cool_down = 3
		self.angle = math.pi / 6.0
		self.ignore_walls = False

	def aoe(self, x, y):
		target = Point(x, y)
		return Burst(self.caster.level,
					 Point(self.caster.x, self.caster.y),
					 self.get_stat('range'),
					 burst_cone_params=BurstConeParams(target, self.angle),
					 ignore_walls=self.ignore_walls)

	def cast(self, x, y):
		damage = self.get_stat('damage')
		for stage in self.aoe(x, y):
			for point in stage:
				if self.caster.level.tiles[point.x][point.y].unit == self.caster: continue
				self.per_square_effect(point.x, point.y, damage)
			yield

	def can_cast(self, x, y):
		if not Spell.can_cast(self, x, y): return False
		return Point(x, y) in self.get_breath_impacted_tiles(x, y)

	def get_impacted_tiles(self, x, y):
		return [p for stage in self.aoe(x, y) for p in stage]

	def per_square_effect(self, x, y, damage):
		pass

	def breath_cache(self):
		lvl = self.caster.level
		origin = (self.caster.x, self.caster.y)
		cache = getattr(self, "cached_breath_data", None)
		if not cache or cache["turn"] != lvl.turn_no or cache["origin"] != origin:
			cache = {"turn": lvl.turn_no, "origin": origin, "options": {}, "choice": None, "coverage": None, "harm": {}}
			self.cached_breath_data = cache
		return cache

	def get_breath_impacted_tiles(self, x, y):
		options = self.breath_cache()["options"]
		target = Point(x, y)
		impacted = options.get(target)
		if impacted is None:
			impacted = set(p for stage in self.aoe(x, y) for p in stage)
			options[target] = impacted
		return impacted

	def breath_can_harm(self, unit):
		cache = self.breath_cache()
		harm = cache["harm"]
		if unit not in harm: harm[unit] = self.can_harm(unit)
		return harm[unit]

	def breath_options(self):
		lvl = self.caster.level
		origin = Point(self.caster.x, self.caster.y)
		origin_x = self.caster.x
		origin_y = self.caster.y
		r = self.get_stat("range")
		enemies = []
		for u in lvl.units:
			if not lvl.are_hostile(u, self.caster): continue
			range_with_radius = r + u.radius
			dx = u.x - origin_x
			dy = u.y - origin_y
			if dx*dx + dy*dy > range_with_radius*range_with_radius: continue
			enemies.append(u)
		random.shuffle(enemies)

		for enemy in enemies:
			if not self.breath_can_harm(enemy): continue
			occupied = list(enemy.iter_occupied_points()) if enemy.radius else [Point(enemy.x, enemy.y)]
			candidates = set(occupied)
			spill = min(r, 2 + enemy.radius)  # small halo around the target for quick'n'dirty targeting to save perf, will fallback to expensive if this doesn't find anything
			for base in occupied: candidates.update(lvl.get_points_in_ball(base.x, base.y, spill))
			candidates = list(candidates)
			random.shuffle(candidates)
			for point in candidates: yield from self.breath_options_for_point(origin, point)

	def breath_options_for_point(self, origin, point):
		options = self.breath_cache()["options"]
		candidates = []
		seen = set()

		def add_candidate(p):
			if p not in seen: seen.add(p); candidates.append(p)

		add_candidate(point)
		line = self.caster.level.get_points_in_line(origin, point, two_pass=False)
		if len(line) > 1:
			add_candidate(line[min(len(line) - 1, self.get_stat("range"))])
			add_candidate(line[len(line) // 2])
		for target in candidates:
			impacted = options.get(target)
			if impacted is None:
				if not self.can_cast(target.x, target.y): continue
				impacted = self.get_breath_impacted_tiles(target.x, target.y)
			yield target, impacted

	def breath_choice(self):
		cache = self.breath_cache()
		if cache["choice"] is not None: return cache["choice"]
		lvl = self.caster.level
		# First pass: enemy-centred casts only (cheap)
		for candidate, impacted in self.breath_options():
			if impacted and any((unit := lvl.get_unit_at(p.x, p.y)) and lvl.are_hostile(unit, self.caster) and self.breath_can_harm(unit) for p in impacted):
				cache["choice"] = (candidate, impacted)
				return cache["choice"]

		# Fallback: reuse any cones we already cached (e.g. from can_threaten)
		for candidate, impacted in cache["options"].items():
			if impacted and any((unit := lvl.get_unit_at(p.x, p.y)) and lvl.are_hostile(unit, self.caster) and self.breath_can_harm(unit) for p in impacted):
				cache["choice"] = (candidate, impacted)
				return cache["choice"]

		cache["choice"] = (None, set())
		return cache["choice"]

	def breath_coverage(self):
		cache = self.breath_cache()
		if cache["coverage"] is None:
			lvl = self.caster.level
			origin = Point(self.caster.x, self.caster.y)
			r = self.get_stat("range")
			coverage = set()
			for target in lvl.get_points_in_ball(origin.x, origin.y, r):
				if not self.can_cast(target.x, target.y): continue
				coverage.update(self.get_breath_impacted_tiles(target.x, target.y))
			cache["coverage"] = coverage
		return cache["coverage"]

	def get_ai_target(self):
		self.cached_breath_data = None
		return self.breath_choice()[0]

	def can_threaten(self, x, y):
		return Point(x, y) in self.breath_coverage()

class StormBreath(BreathWeapon):

	def on_init(self):
		self.name = "Storm Breath"
		self.damage = 10
		self.damage_type = Tags.Lightning

	def get_description(self):
		return "Cone attack\nCreates Storm Clouds"

	def per_square_effect(self, x, y, damage):
		self.caster.level.deal_damage(x, y, damage, self.damage_type, self)
		cloud = StormCloud(self.caster, damage)
		cloud.source = self
		self.caster.level.add_obj(cloud, x, y)


class FireBreath(BreathWeapon):

	def on_init(self):
		self.name = "Fire Breath"
		self.damage = 9
		self.damage_type = Tags.Fire

	def get_description(self):
		if self.ignore_walls: return "Cone attack\nMelts walls"
		return "Cone attack"

	def per_square_effect(self, x, y, damage):
		self.caster.level.deal_damage(x, y, damage, self.damage_type, self)
		if self.ignore_walls:
			if self.caster.level.tiles[x][y].is_wall():
				self.caster.level.make_floor(x, y)

class PoisonBreath(BreathWeapon):

	def on_init(self):
		self.name = "Poison Breath"
		self.damage = 9
		self.damage_type = Tags.Poison

	def get_description(self):
		if self.ignore_walls: return "Cone attack\nMelts walls"
		return "Cone attack"

	def per_square_effect(self, x, y, damage):
		self.caster.level.deal_damage(x, y, damage, self.damage_type, self)
		if self.ignore_walls:
			if self.caster.level.tiles[x][y].is_wall():
				self.caster.level.make_floor(x, y)

class IceBreath(BreathWeapon):

	def on_init(self):
		self.name = "Ice Breath"
		self.damage = 7
		self.damage_type = Tags.Ice
		self.duration = 2
		self.embrace = False

	def get_description(self):
		return ("Cone attack\nInflicts [frozen] for {duration} turns",
				{'duration': self.get_stat('duration')})

	def per_square_effect(self, x, y, damage):
		unit = self.caster.level.get_unit_at(x, y)
		if not unit: self.caster.level.show_effect(x, y, Tags.Ice); return
		if self.embrace and are_friendly(self.caster, unit):
			unit.apply_buff(ResistBuff(Tags.Ice, res=5))
			unit.add_shields(1)
			self.caster.level.show_effect(x, y, Tags.Ice)
			return

		self.caster.level.deal_damage(x, y, damage, self.damage_type, self)
		unit.apply_buff(FrozenBuff(), self.get_stat('duration'))


class VoidBreath(BreathWeapon):

	def __init__(self):
		BreathWeapon.__init__(self)
		self.name = "Void Breath"
		self.damage = 9
		self.damage_type = Tags.Arcane
		self.requires_los = False
		self.ignore_walls = True

	def get_description(self):
		return "Cone attack\nMelts walls"

	def per_square_effect(self, x, y, damage):
		if not self.caster.level.tiles[x][y].is_chasm: self.caster.level.make_floor(x, y)
		self.caster.level.deal_damage(x, y, damage, Tags.Arcane, self)

class HolyBreath(BreathWeapon):

	def on_init(self):
		self.name = "Holy Breath"
		self.description = "Cone attack\nHeals allies"
		self.damage = 9
		self.damage_type = Tags.Holy

	def per_square_effect(self, x, y, damage):
		unit = self.caster.level.get_unit_at(x, y)
		if unit and not are_hostile(self.caster, unit): self.caster.level.deal_damage(x, y, -damage, Tags.Heal, self)
		else: self.caster.level.deal_damage(x, y, damage, self.damage_type, self)

class DarkBreath(BreathWeapon):

	def on_init(self):
		self.name = "Dark Breath"
		self.description = "Cone attack\nSlain units become Skeletons"
		self.damage = 11
		self.damage_type = Tags.Dark

	def per_square_effect(self, x, y, damage):
		unit = self.caster.level.get_unit_at(x, y)
		self.caster.level.deal_damage(x, y, damage, self.damage_type, self)
		if unit and not unit.is_alive(): raise_skeleton(self.caster, unit)

class NecroticBreath(BreathWeapon):

	def on_init(self):
		self.name = "Necrotic Breath"
		self.damage = 15
		self.duration = 5
		self.damage_type = Tags.Dark

	def get_description(self):
		return (("Cone attack\n"
				"Applies [necrosis] for [{duration}:duration] turns",
				{'duration': self.get_stat('duration')}))

	def per_square_effect(self, x, y, damage):
		u = self.caster.level.get_unit_at(x, y)
		dmg = self.caster.level.deal_damage(x, y, damage, self.damage_type, self)
		if u and u.is_alive() and are_hostile(u, self.caster) and dmg: u.apply_buff(NecrosisBuff(), self.get_stat('duration'))

class SpiritBuff(Buff):

	def __init__(self, tag, val=5):
		Buff.__init__(self)
		self.tag = tag
		self.growth_val = val
 
	def on_applied(self, owner):
		self.global_triggers[EventOnSpellCast] = self.on_spell_cast

	def on_spell_cast(self, spell_cast_event):
		hp_gain = self.growth_val
		if (self.tag in spell_cast_event.spell.tags 
			and self.owner.level.can_see(spell_cast_event.x, spell_cast_event.y, self.owner.x, self.owner.y)):  # put caster here first, since player is going to be checked against a lot and their fov map is already made.
			self.owner.max_hp += hp_gain
			self.owner.cur_hp += hp_gain
			self.owner.level.queue_spell(self.effect(spell_cast_event.x, spell_cast_event.y))


	def effect(self, x, y):
		for p in self.owner.level.get_points_in_line(Point(x, y), self.owner, find_clear=True):
			self.owner.level.flash(p.x, p.y, self.tag.color)
			yield
		self.owner.level.flash(self.owner.x, self.owner.y, Tags.Heal.color)


	def get_tooltip(self):
		return ("Gain {growth} max HP whenever a {tag} spell is cast in line of sight", {'growth':self.growth_val, 'tag':formatted_tag(self.tag)})



class SporeBeastBuff(Buff):

	def on_init(self):
		self.name = "Spores"
		self.healing = 8
		self.radius = 2
		self.owner_triggers[EventOnDamaged] = self.on_damage_taken

	def on_damage_taken(self, event):
		if random.random() < .3:
			self.owner.level.queue_spell(self.heal_burst())

	def heal_burst(self):
		for stage in Burst(self.owner.level, Point(self.owner.x, self.owner.y), self.radius):
			for p in stage:
				self.owner.level.deal_damage(p.x, p.y, -self.healing, Tags.Heal, self)
			yield

	def get_tooltip(self):
		return "When damaged, 30% chance to heal all units within {radius} tiles for {heal} HP", {'radius':self.radius, 'heal':self.healing}

class SpikeBeastBuff(Buff):

	def on_init(self):
		self.name = "Spikebeast Spikes"
		self.damage = 8
		self.radius = 2
		self.owner_triggers[EventOnDamaged] = self.on_damage_taken

	def on_damage_taken(self, event):
		if random.random() < .3:
			self.owner.level.queue_spell(self.heal_burst())

	def heal_burst(self):
		for stage in Burst(self.owner.level, Point(self.owner.x, self.owner.y), self.radius):
			for p in stage:
				if (p.x == self.owner.x and p.y == self.owner.y) or (self.owner.level.get_unit_at(p.x, p.y) == self.owner):
					continue
				self.owner.level.deal_damage(p.x, p.y, self.damage, Tags.Physical, self)
			yield

	def get_tooltip(self):
		return "When damaged, 30% chance to deal {damage} [Physical] damage to all units within {radius} tiles" , {'damage':self.damage, 'radius':self.radius}

class BlizzardBeastBuff(Buff):

	def on_init(self):
		self.name = "Ice Spores"
		self.radius = 2
		self.owner_triggers[EventOnDamaged] = self.on_damaged
		self.description = "When damaged, create 2 Blizzards up to 2 tiles away"

	def on_damaged(self, evt):
		for i in range(2):
			points = self.owner.level.get_points_in_ball(self.owner.x, self.owner.y, self.radius)
			points = [p for p in points if not self.owner.level.tiles[p.x][p.y].cloud and self.owner.level.tiles[p.x][p.y].can_see]
			if points:
				p = random.choice(points)
				cloud = BlizzardCloud(self.owner)
				self.owner.level.add_obj(cloud, p.x, p.y)

class VoidBomberBuff(Buff):

	def on_init(self):
		self.radius = 2
		self.damage = 12
		self.clusters = 0
		self.name = "Suicide Explosion"
		self.color = Tags.Arcane.color

	def on_applied(self, owner):
		self.owner_triggers[EventOnDeath] = self.on_death

	def on_death(self, death_event):
		self.owner.level.queue_spell(self.explode(self.owner.level, self.owner.x, self.owner.y))

	def get_tooltip(self):
		if self.clusters: return "Summon 3 Void Bombers on death"

	def explode(self, level, x, y):
		owner = self.owner
		level = owner.level
		tiles = level.tiles
		deal_damage = level.deal_damage
		for stage in Burst(level, owner, self.radius, ignore_walls=True):
			for point in stage:
				deal_damage(point.x, point.y, self.damage, Tags.Arcane, self)
				if tiles[point.x][point.y].is_wall(): level.make_floor(point.x, point.y)

		for i in range(self.clusters): self.summon(VoidBomber())
		yield

class VoidBomberSuicide(Spell):

	def on_init(self):
		self.range = 2
		self.name = "Suicide Explosion"
		self.description = "Suicide attack\n2 tile radius\nMelts Walls\nAutocast on death"
		self.damage = 12
		self.damage_type = Tags.Arcane

	def cast(self, x, y):
		self.caster.kill()
		yield

class FireBomberBuff(Buff):

	def on_init(self):
		self.name = "Suicide Explosion"
		self.radius = 2
		self.damage = 12
		self.clusters = 0
		self.color = Tags.Fire.color

	def on_applied(self, owner):
		self.owner_triggers[EventOnDeath] = self.on_death

	def on_death(self, death_event):
		self.owner.level.queue_spell(self.explode(self.owner.level, self.owner.x, self.owner.y))

	def get_tooltip(self):
		if self.clusters: return "Summon 3 Fire Bombers on death"

	def explode(self, level, x, y):
		for stage in Burst(self.owner.level, self.owner, self.radius):
			for point in stage:
				self.owner.level.deal_damage(point.x, point.y, self.damage, Tags.Fire, self)
		for i in range(self.clusters): self.summon(FireBomber())
		yield

class FireBomberSuicide(Spell):

	def on_init(self):
		self.range = 2
		self.name = "Suicide Explosion"

		#For tooltips
		self.damage = 12
		self.damage_type = Tags.Fire

		self.description = "Suicide attack\n2 tile radius\nAutocast on death"

	def cast(self, x, y):
		self.caster.kill()
		yield

class PoisonBomberBuff(Buff):

	def on_init(self):
		self.name = "Suicide Explosion"
		self.radius = 2
		self.damage = 15
		self.clusters = 0

	def on_applied(self, owner):
		self.owner_triggers[EventOnDeath] = self.on_death

	def on_death(self, death_event):
		self.owner.level.queue_spell(self.explode(self.owner.level, self.owner.x, self.owner.y))

	def explode(self, level, x, y):
		for point in self.owner.level.get_points_in_ball(self.owner.x, self.owner.y, self.radius):
			if not self.owner.level.can_see(self.owner.x, self.owner.y, point.x, point.y):
				continue
			self.owner.level.deal_damage(point.x, point.y, self.damage, Tags.Poison, self)

		yield

class PoisonBomberSuicide(Spell):

	def on_init(self):
		self.range = 2
		self.name = "Suicide Explosion"

		self.damage = 15
		self.damage_type = Tags.Poison
		
		self.description = "Suicide attack\n2 tile radius\nAutocast on death"

	def cast(self, x, y):
		self.caster.kill()
		yield

class IceBomberBuff(Buff):

	def on_init(self):
		self.name = "Suicide Explosion"
		self.radius = 2
		self.damage = 10
		self.duration = 3
		self.clusters = 0

	def on_applied(self, owner):
		self.owner_triggers[EventOnDeath] = self.on_death

	def on_death(self, death_event):
		self.owner.level.queue_spell(self.explode(self.owner.level, self.owner.x, self.owner.y))

	def get_tooltip(self):
		if self.clusters: return "Summon 3 Ice Bombers on death"

	def explode(self, level, x, y):
		for stage in Burst(level, self.owner, self.radius):
			for point in stage:
				level.deal_damage(point.x, point.y, self.damage, Tags.Ice, self)
				u = level.get_unit_at(point.x, point.y)
				if u: u.apply_buff(FrozenBuff(), self.duration)
		for i in range(self.clusters): self.summon(IceBomber())
		yield


class IceBomberSuicide(Spell):

	def on_init(self):
		self.range = 2
		self.name = "Suicide Explosion"
		self.damage = 10
		self.damage_type = Tags.Ice
		self.description = "Suicide attack\n2 tile radius\nAutocast on death\nInflicts [frozen] for 3 turns"

	def cast(self, x, y):
		self.caster.kill()
		yield

def Idol():
	idol = Unit()
	idol.asset_name = "idol"

	idol.max_hp = 50
	idol.shields = 2
	idol.stationary = True

	idol.tags = [Tags.Construct]
	idol.resists[Tags.Fire] = 50
	idol.resists[Tags.Lightning] = 50
	idol.resists[Tags.Physical] = 50
	return idol

def BigIdol():
	idol = Idol()
	idol.radius = 1
	idol.max_hp *=30
	idol.shields *=10
	return idol

def FurnaceHound():
	unit = HellHound()
	unit.name = "Furnace Hound"
	unit.asset_name = "hell_hound_furnace"
	unit.tags.append(Tags.Metallic)
	unit.max_hp += 7
	buff = DamageAuraBuff(damage=1, damage_type=Tags.Fire, radius=4)
	buff.name = "Furnace Aura"
	unit.buffs.append(buff)
	unit.spells[0].damage_type = [Tags.Physical]
	unit.spells[1].damage_type = Tags.Physical
	unit.resists[Tags.Ice] = -50
	return unit


def Kobold():
	unit = Unit()
	unit.name = "Kobold"
	unit.max_hp = 4
	bow = SimpleRangedAttack(damage=1, range=10, proj_name="kobold_arrow")
	bow.name = "Bow"
	bow.cooldown = 2
	unit.spells.append(bow)
	unit.tags = [Tags.Living]
	return unit

class HasteSpell(Spell):

	def on_init(self):
		self.name = "Quicken"
		self.description = "Target ally gains [Quickstep:translocation]"
		self.target_allies = True
		self.range = 3

	def can_cast(self, x, y):
		u = self.caster.level.get_unit_at(x, y)
		if not u:
			return False
		if u.stationary:
			return False
		if u.quick_move:
			return False
		return Spell.can_cast(self, x, y)

	def cast_instant(self, x, y):
		u = self.caster.level.get_unit_at(x, y)
		u.apply_buff(QuickmoveBuff())

class UselessCoward(Buff):

	def on_init(self):
		self.name = "Useless Coward"
		self.description = "Will run away in fear if all spells are on cooldown"
		self.buff_type = BUFF_TYPE_PASSIVE

	def on_advance(self):
		cool_downs = self.owner.cool_downs.values()
		if all(cd > 0 for cd in cool_downs) and len(cool_downs) == len(self.owner.spells):
			dur = min(cool_downs)
			self.owner.apply_buff(FearBuff(), dur)


def KoboldHedgeMage():
	unit = Unit()
	unit.name = "Kobold Hedge Mage"
	unit.max_hp = 25
	unit.tags = [Tags.Arcane, Tags.Living]

	haste = HasteSpell()
	haste.cool_down = 3

	arcane = SimpleRangedAttack(damage=20, damage_type=Tags.Arcane, range=6, beam=True, cool_down=10)
	arcane.name = "Stolen Wand"

	unit.spells = [arcane, haste]

	unit.buffs.append(UselessCoward())

	unit.is_wizard = True

	return unit

def Golem():
	unit = Unit()
	unit.name = "Golem"
	unit.max_hp = 25
	unit.spells.append(SimpleMeleeAttack(8))
	unit.tags = [Tags.Construct, Tags.Metallic]
	return unit

def CrystalGolem():
	unit = Golem()
	unit.name = "Crystal Golem"
	unit.max_hp *= 4
	unit.spells[0].damage *= 3
	unit.add_spell(SimpleRangedAttack(name="Crystal Shot", damage=16, damage_type=Tags.Physical, range=3, cool_down=3))

	unit.resists[Tags.Physical] = -50
	for tag in damage_tags:
		if tag != Tags.Physical:
			unit.resists[tag] = 100

	unit.apply_buff(PrismaticBuff())

	return unit

class PrismaticBuff(Buff):

	def on_init(self):
		self.name = "Prismatic"
		self.description = "Each turn, becomes vulnerable to a different damage type"
		self.rotation_tags = [t for t in damage_tags if t != Tags.Physical]
		self.current = 0
		self.previous = None

	def on_advance(self):
		cur_tag = self.rotation_tags[self.current]
		self.owner.level.show_effect(self.owner.x, self.owner.y, cur_tag)
		if self.previous: self.owner.resists[self.previous] += 200
		self.owner.resists[cur_tag] -= 200
		self.previous = cur_tag
		self.current = (self.current + 1) % len(self.rotation_tags)

class ConstructShards(Buff):

	def on_init(self):
		self.name = "Necromechanomancery"
		self.global_triggers[EventOnDeath] = self.on_death
		self.description = "When a friendly [Construct] dies, deal 6 [Fire] or [Physical] damage to up to 3 enemies in a 4 tile burst"

	def on_death(self, evt):
		if are_hostile(self.owner, evt.unit):
			return
		if not Tags.Construct in evt.unit.tags:
			return

		targets = self.owner.level.get_units_in_ball(evt.unit, 4)
		targets = [t for t in targets if self.owner.level.can_see(evt.unit.x, evt.unit.y, t.x, t.y) and are_hostile(self.owner, t)]

		random.shuffle(targets)
		for t in targets[:3]:

			for p in self.owner.level.get_points_in_line(evt.unit, t, find_clear=True)[1:-1]:
				dtype = random.choice([Tags.Fire, Tags.Physical])
				self.owner.level.show_effect(p.x, p.y, dtype, minor=True)

			dtype = random.choice([Tags.Fire, Tags.Physical])
			t.deal_damage(6, dtype, self)

class IronPlating(Buff):

	def on_init(self):
		self.resists[Tags.Physical] = 50
		self.buff_type = BUFF_TYPE_BLESS
		self.name = "Iron Plating"
		self.asset = ['status', 'iron_plating']

def Mechanomancer():

	unit = Unit()
	unit.name = "Mechanomancer"
	unit.max_hp = 131

	golems = SimpleSummon(Golem, num_summons=2, cool_down=20)

	armor = SimpleCurse(IronPlating, 12, effect=Tags.Physical)
	armor.cool_down = 3
	armor.range = 5
	armor.name = "Iron Blessing"
	armor.description = "Apply Iron Plating to an ally, granting 50% [Physical] resist"

	heal = HealAlly(25, 5, Tags.Construct)
	heal.cool_down = 5
	heal.name = "Reconstitution"

	spike = SimpleRangedAttack(damage=8, range=3)
	spike.name = 'Spikebolt'

	unit.spells = [golems, armor, heal, spike]

	unit.tags = [Tags.Construct]
	unit.is_wizard = True
	return unit

def Thunderbird():
	unit = Unit()
	unit.name = "Thunderbird"
	unit.max_hp = 22
	unit.shields = 1

	unit.flying = True

	claw = SimpleMeleeAttack(damage=5, damage_type=Tags.Lightning)
	claw.name = "Lightning Talons"

	dive = LeapAttack(damage=5, damage_type=Tags.Lightning, range=5, is_leap=True)
	dive.name = "Lightning Dive"
	dive.cool_down = 3

	unit.spells.append(dive)
	unit.spells.append(claw)

	unit.resists[Tags.Lightning] = 75
	unit.tags = [Tags.Lightning, Tags.Nature, Tags.Living]

	return unit

def SpikeBall():
	unit = Unit()
	unit.name = "Spike Ball"
	unit.asset_name = 'rolling_spike_ball'
	unit.max_hp = 60
	unit.spells.append(SimpleMeleeAttack(10, trample=True))
	unit.buffs.append(Thorns(6))
	unit.tags = [Tags.Construct, Tags.Metallic]
	return unit

def SpikeBallCopper():
	unit = SpikeBall()
	unit.name = "Copper Spike Ball"
	unit.asset_name = "rolling_spike_ball_copper"

	unit.buffs.append(DamageAuraBuff(damage_type=Tags.Lightning, damage=3, radius=2))
	return unit

def Cyclops():
	unit = Unit()
	unit.name = "Cyclops"
	unit.max_hp = 55
	boulder = SimpleRangedAttack(damage=12, damage_type=Tags.Physical, range=10, radius=1)
	boulder.cool_down = 5
	boulder.onhit = lambda caster, target: target.apply_buff(Stun(), 1)
	boulder.cooldown = 6
	boulder.name = "Throw boulder"
	boulder.description = "Stuns for 1 turn"
	unit.spells.append(boulder)
	unit.spells.append(SimpleMeleeAttack(9))
	unit.tags = [Tags.Living]
	return unit


class ScaleWoven(Buff):

	def __init__(self, tag):
		self.immunity_tag = tag
		Buff.__init__(self)

	def on_init(self):
		self.resists[self.immunity_tag] = 100
		self.name = '%s Woven' % self.immunity_tag.name
		self.color = self.immunity_tag.color
		self.buff_type = BUFF_TYPE_BLESS

def FrostfireHydra():
	unit = Unit()
	unit.max_hp = 24

	unit.name = "Frostfire Hydra"
	unit.asset_name = 'fire_and_ice_hydra'

	fire = SimpleRangedAttack(damage=8, range=5, damage_type=Tags.Fire, beam=True, buff=BlindBuff, buff_duration=1)
	fire.cool_down = 2

	ice = SimpleRangedAttack(damage=8, range=5, damage_type=Tags.Ice, beam=True, buff=FrozenBuff, buff_duration=1)
	ice.cool_down = 2

	unit.stationary = True
	unit.spells = [ice, fire]
	unit.resists[Tags.Fire] = 100
	unit.resists[Tags.Ice] = 100
	unit.resists[Tags.Poison] = 100
	unit.tags = [Tags.Fire, Tags.Ice, Tags.Dragon]
	return unit

class CrystalEyesBuff(Buff):

	def on_init(self):
		self.name = "Crystalline"
		self.description = "Redeal 50% of damage dealt as [Arcane]"
		self.color = Tags.Arcane.color
		self.global_triggers[EventOnDamaged] = self.on_damaged

	def on_damaged(self, evt):
		if evt.source.owner == self.owner and evt.source != self:
			self.owner.level.deal_damage(evt.unit.x, evt.unit.y, evt.damage//2, Tags.Arcane, self)

def CrystallineFrostfireHydra():
	unit = FrostfireHydra()
	unit.name = "Crystalline Frostfire Hydra"
	unit.asset_name = "fire_and_ice_hydra_crystal_eyes"
	unit.apply_buff(CrystalEyesBuff())
	unit.tags.append(Tags.Arcane)
	return unit

class OrochiGrowthBuff(Buff):

	def on_init(self):
		self.name = "Orochi Regrowth"
		# self.description = "For every 100 damage taken, takes an extra turn after its turn ends"
		self.owner_triggers[EventOnDamaged] = self.on_damaged
		self.counter = 0
		self.threshold = 100

		self.extra_turns = 0
		self.turn_activations = set()

	def get_description(self):
		desc = ["For every 100 damage taken, takes an extra turn after its turn ends"]
		if self.extra_turns: desc.append(("\nExtra Turns: {extra_turns}", {'extra_turns':self.extra_turns}))
		return desc

	def on_damaged(self, evt):
		if evt.damage <= 0: return
		self.counter += evt.damage
		if self.counter < self.threshold: return
		while self.counter >= self.threshold:
			self.extra_turns += 1
			self.counter -= self.threshold

	def on_advance(self):
		if self.owner.level.turn_no in self.turn_activations: return
		self.turn_activations.add(self.owner.level.turn_no)
		for _ in range(self.extra_turns): self.owner.level.queue_spell(self.do_turn())

	def do_turn(self):
		for _ in self.owner.level.take_turn(self.owner): yield

def Orochi():
	u = Unit()
	u.name = "Orochi"
	u.radius = 1
	u.asset_name = "3x3_hydra"
	u.max_hp = 480
	u.tags = [Tags.Fire, Tags.Ice, Tags.Dragon]
	u.resists[Tags.Fire] = 100
	u.resists[Tags.Ice] = 100
	u.resists[Tags.Poison] = 100

	fire = WideBeam(name="Flame", damage=16, range=8, damage_type=Tags.Fire)
	fire.cool_down = 2

	ice = WideBeam(name="Frost", damage=16, range=8, damage_type=Tags.Ice)
	ice.cool_down = 2

	u.stationary = True
	u.spells = [ice, fire]
	u.buffs = [OrochiGrowthBuff()]
	return u

def CrystallineOrochi():
	unit = Orochi()
	unit.name = "Crystalline Orochi"
	unit.asset_name = "3x3_hydra_crystal"
	unit.apply_buff(CrystalEyesBuff())
	unit.tags.append(Tags.Arcane)
	return unit

class ScaleWeave(Spell):

	def on_init(self):
		self.name = "Scale Weave"
		self.range = 7
		self.radius = 4
		self.duration = 20
		self.cool_down = 6
		self.target_allies = True

	def get_description(self):
		return "Allies near target [Dragon] gain immunity to its damage types for {duration} turns", {'duration': self.get_stat('duration')}

	def get_ai_target(self):
		# Return an allied dragon in range with non immune allies in the aoe
		caster = self.caster
		getball = caster.level.get_units_in_ball
		radius = self.get_stat('radius')
		potentials = [u for u in getball(caster, self.get_stat('range'))]
		potentials = [u for u in potentials if Tags.Dragon in u.tags and u != caster]
		if not potentials: return None
		random.shuffle(potentials)
		dts = damage_tags[:]
		for p in potentials:
			dtypes = [t for t in dts if t in p.tags]
			if not dtypes: continue
			nearby = [v for v in getball(p, radius) if not are_hostile(v, caster) and any(v.resists[t] < 100 for t in dtypes)]
			if nearby and self.can_cast(p.x, p.y): return p
		return None

	def can_cast(self, x, y):
		unit = self.caster.level.get_unit_at(x, y)
		if not unit: return False
		if Tags.Dragon not in unit.tags: return False
		return Spell.can_cast(self, x, y)

	def cast_instant(self, x, y):
		duration = self.get_stat('duration')
		caster = self.caster
		level = caster.level
		showbeam = level.show_beam

		dragon = level.get_unit_at(x, y)
		dtypes = [t for t in damage_tags if t in dragon.tags]
		if not dtypes: return
		showbeam(caster, dragon, random.choice(dtypes), minor=True)
		for u in level.get_units_in_ball(dragon, self.get_stat('radius')):
			if u == dragon: continue
			if are_hostile(caster, u): continue
			for t in dtypes:
				if u.resists[t] >= 100: continue
				showbeam(dragon, u, t, minor=True)
				u.apply_buff(ScaleWoven(t), duration)

class StormBall(Spell):

	def on_init(self):
		self.name = "Storm Ball"
		self.description = "Creates Thunderstorms and Blizzards"
		self.radius = 2
		self.cool_down = 3

	def get_ai_target(self):
		return self.get_corner_target(self.get_stat('radius'))

	def cast(self, x, y):
		target = Point(x, y)
		for stage in Burst(self.caster.level, target, self.get_stat('radius')):
			for p in stage:
				if not self.caster.level.tiles[p.x][p.y].cloud:
					cloud = random.choice([StormCloud, BlizzardCloud])(self.caster)
					self.caster.level.add_obj(cloud, p.x, p.y)
			yield

def random_drake():
	return random.choice([FireDrake, StormDrake, FireDrake, StormDrake, GoldDrake, VoidDrake, IceDrake])()

def DragonMage():
	unit = Unit()
	unit.name = "Dragon Mage"
	unit.asset_name = "dragon_wizard"
	unit.max_hp = 160

	beckon = SimpleSummon(random_drake, num_summons=3, cool_down=22, global_summon=True)
	beckon.name = "Summon Drakes"
	beckon.description = "Summon 3 random Drakes at random locations"

	from Spells import DragonClaw
	def dclaw_desc(): return "Deals damage in an arc"
	dclaw = DragonClaw()
	dclaw.tags = []
	dclaw.get_description = dclaw_desc

	unit.spells = [beckon, ScaleWeave(), WizardSwap(Tags.Dragon), dclaw]

	unit.resists[Tags.Fire] = 50
	unit.resists[Tags.Lightning] = 50
	unit.resists[Tags.Ice] = 50
	unit.resists[Tags.Arcane] = 50

	unit.tags = [Tags.Dragon, Tags.Living]
	unit.is_wizard = True

	return unit

def StormDrake():
	unit = Unit()
	unit.name = "Storm Drake"
	unit.max_hp = 48
	unit.flying = True
	unit.spells.append(StormBreath())
	unit.spells.append(SimpleMeleeAttack(8))
	unit.resists[Tags.Lightning] = 100
	unit.tags = [Tags.Dragon, Tags.Living, Tags.Lightning]
	return unit

def FireDrake():
	unit = Unit()
	unit.name = "Fire Drake"
	unit.max_hp = 48
	unit.flying = True
	unit.spells.append(FireBreath())
	unit.spells.append(SimpleMeleeAttack(8))
	unit.resists[Tags.Fire] = 100
	unit.resists[Tags.Ice] = -50
	unit.tags = [Tags.Dragon, Tags.Living, Tags.Fire]
	return unit

def VoidDrake():
	unit = Unit()
	unit.name = "Void Drake"
	unit.max_hp = 48
	unit.flying = True
	unit.spells.append(VoidBreath())
	unit.spells.append(SimpleMeleeAttack(8))
	unit.resists[Tags.Arcane] = 100
	unit.tags = [Tags.Dragon, Tags.Living, Tags.Arcane]
	return unit

def GoldDrake():
	unit = Unit()
	unit.name = "Gold Drake"
	unit.max_hp = 48
	unit.flying = True
	unit.spells.append(HolyBreath())
	unit.spells.append(SimpleMeleeAttack(8))
	unit.resists[Tags.Holy] = 100
	unit.tags = [Tags.Dragon, Tags.Living, Tags.Holy]
	return unit

def Dracolich():
	unit = Unit()
	unit.name = "Dracolich"
	unit.asset_name = "bone_drake"
	unit.max_hp = 240
	unit.flying = True
	unit.spells = [LichSealSoulSpell(), DarkBreath(), SimpleMeleeAttack(8)]
	unit.resists[Tags.Dark] = 100
	unit.tags = [Tags.Dragon, Tags.Undead, Tags.Dark]
	return unit

def Necrodrake():
	u = Unit()
	u.name = "Necrodrake"
	u.asset_name = 'necro_drake'
	u.max_hp = 240
	u.flying = True
	u.spells = [NecroticBreath(), SimpleMeleeAttack(12, NecrosisBuff, 5, drain=True)]
	u.resists[Tags.Dark] = 100
	u.tags = [Tags.Dragon, Tags.Living, Tags.Dark]
	return u

def IceDrake():
	unit = Unit()
	unit.name = "Ice Drake"
	unit.max_hp = 48
	unit.flying = True
	unit.spells.append(IceBreath())
	unit.spells.append(SimpleMeleeAttack(8))
	unit.resists[Tags.Ice] = 100
	unit.resists[Tags.Fire] = -50
	unit.tags = [Tags.Dragon, Tags.Living, Tags.Ice]
	return unit


def SlimeDrake():
	unit = Unit()
	unit.name = "Slime Drake"
	unit.flying = True
	unit.max_hp = 140

	unit.buffs.append(SlimeBuff(spawner=SlimeDrake, name="slime drakes"))

	unit.tags = [Tags.Slime, Tags.Dragon]

	unit.resists[Tags.Poison] = 100
	unit.resists[Tags.Physical] = 50

	poison_breath = PoisonBreath()
	melee = SimpleMeleeAttack(8)
	unit.spells = [poison_breath, melee]

	return unit


class BatBreath(BreathWeapon):

	def on_init(self):
		self.name = "Torrent of Bats"
		self.damage = 7
		self.damage_type = Tags.Physical

	def get_description(self):
		return "Cone attack\nSummons Bats in empty tiles"

	def per_square_effect(self, x, y, damage):
		unit = self.caster.level.get_unit_at(x, y)
		if unit: self.caster.level.deal_damage(x, y, damage, self.damage_type, self)
		else: self.summon(Bat(), Point(x, y))


def BatDragon():
	dragon = Unit()
	dragon.name = "Bat Dragon"

	dragon.max_hp = 38
	dragon.flying = True

	dragon.resists[Tags.Dark] = 50

	dragon.spells.append(BatBreath())

	dragon.spells.append(SimpleMeleeAttack(8))
	dragon.tags = [Tags.Dragon, Tags.Living, Tags.Dark]

	return dragon

def FireWyrm():
	unit = Unit()
	unit.name = "Fire Wyrm"
	unit.asset_name = "wyrm_red"
	unit.max_hp = 75

	unit.spells.append(FireBreath())
	unit.spells.append(SimpleMeleeAttack(14, trample=True))

	unit.buffs.append(RegenBuff(8))

	unit.tags = [Tags.Fire, Tags.Dragon, Tags.Living]

	unit.resists[Tags.Fire] = 100
	unit.resists[Tags.Ice] = -50

	unit.burrowing = True
	return unit

def IceWyrm():
	unit = Unit()
	unit.name = "Ice Wyrm"
	unit.asset_name = "wyrm_blue"

	unit.max_hp = 75

	unit.spells.append(IceBreath())
	unit.spells.append(SimpleMeleeAttack(14, trample=True))

	unit.tags = [Tags.Ice, Tags.Dragon, Tags.Living]

	unit.resists[Tags.Ice] = 100
	unit.resists[Tags.Fire] = -50
	
	unit.buffs.append(RegenBuff(8))

	unit.burrowing = True
	return unit

def FireWyrmEgg():
	unit = Unit()
	unit.name = "Fire Wyrm Egg"
	unit.asset_name = "red_wyrm_egg"

	unit.max_hp = 14

	unit.stationary = True
	unit.buffs.append(SpawnOnDeath(FireWyrm, 1))

	unit.resists[Tags.Fire] = 100
	unit.resists[Tags.Physical] = 50
	unit.resists[Tags.Ice] = - 50
	unit.tags = [Tags.Living, Tags.Dragon, Tags.Fire]
	return unit


def IceWyrmEgg():
	unit = Unit()
	unit.name = "Ice Wyrm Egg"
	unit.asset_name = "blue_wyrm_egg"

	unit.max_hp = 14

	unit.stationary = True
	unit.buffs.append(SpawnOnDeath(IceWyrm, 1))

	unit.resists[Tags.Ice] = 100
	unit.resists[Tags.Physical] = 50
	unit.resists[Tags.Fire] = -50
	unit.tags = [Tags.Living, Tags.Dragon, Tags.Ice]
	return unit


def Cindervein():
	u = Unit()
	u.name = 'Cindervein'
	u.asset_name = '3x3_red_dragon'
	u.radius = 1
	u.tags = [Tags.Dragon, Tags.Living, Tags.Fire]

	u.max_hp = 3400
	u.flying = True

	breath = FireBreath()
	breath.damage = 40
	breath.range = 8
	breath.cool_down = 3

	u.spells = [breath, SimpleMeleeAttack(23)]

	u.resists[Tags.Fire] = 100
	u.resists[Tags.Physical] = 50
	u.resists[Tags.Ice] = -50

	return u


def Winterbringer():
	unit = Unit()
	unit.name = "Winterbringer"

	unit.asset_name = '3x3_dragon'
	unit.radius = 1

	unit.max_hp = 2676
	unit.flying = True
	breath = IceBreath()
	breath.range = 11
	breath.damage = 14
	unit.spells.append(breath)
	breath.cool_down = 4
	unit.spells.append(SimpleMeleeAttack(17))

	unit.resists[Tags.Ice] = 100
	unit.resists[Tags.Physical] = 50
	unit.resists[Tags.Fire] = -50
	unit.tags = [Tags.Dragon, Tags.Living, Tags.Ice]

	return unit

def Starclaw():
	unit = Unit()
	unit.name = "Starclaw"

	unit.asset_name = '3x3_void_dragon'
	unit.radius = 1

	unit.max_hp = 3676
	unit.flying = True
	breath = VoidBreath()
	breath.range = 7
	breath.damage = 34
	unit.spells.append(breath)
	breath.cool_down = 3
	unit.spells.append(SimpleMeleeAttack(17))

	unit.resists[Tags.Arcane] = 100
	unit.resists[Tags.Physical] = 50
	unit.tags = [Tags.Dragon, Tags.Living, Tags.Arcane]

	return unit

def Stormcrest():
	unit = Unit()
	unit.name = "Stormcrest"

	unit.asset_name = '3x3_storm_dragon'
	unit.radius = 1

	unit.max_hp = 1976
	unit.flying = True
	breath = StormBreath()
	breath.range = 9
	breath.damage = 20
	unit.spells.append(breath)
	breath.cool_down = 3
	unit.spells.append(SimpleMeleeAttack(27))

	unit.resists[Tags.Lightning] = 100
	unit.resists[Tags.Physical] = 50
	unit.tags = [Tags.Dragon, Tags.Living, Tags.Lightning]

	return unit

def Dawnheart():
	unit = Unit()
	unit.name = "Dawnheart"

	unit.asset_name = '3x3_holy_dragon'
	unit.radius = 1

	unit.max_hp = 4831

	unit.flying = True

	breath = HolyBreath()
	breath.range = 9
	breath.damage = 28
	unit.spells.append(breath)
	breath.cool_down = 3
	unit.spells.append(SimpleMeleeAttack(17))

	unit.resists[Tags.Holy] = 100
	unit.resists[Tags.Physical] = 50
	unit.resists[Tags.Dark] = -50
	unit.tags = [Tags.Dragon, Tags.Living, Tags.Holy]

	return unit

def Gelgut():
	unit = Unit()
	unit.name = "Gelgut"
	unit.asset_name = '3x3_slime_dragon'
	unit.radius = 1

	unit.flying = True

	unit.max_hp = 3845

	unit.buffs.append(SlimeBuff(spawner=Gelgut, name="Gelguts"))

	unit.tags = [Tags.Slime, Tags.Dragon]

	unit.resists[Tags.Poison] = 100
	unit.resists[Tags.Physical] = 75

	poison_breath = PoisonBreath()
	poison_breath.damage += 9
	poison_breath.range = 7

	melee = SimpleMeleeAttack(45)

	unit.spells = [poison_breath, melee]

	return unit

def Gloomwing():
	unit = Unit()
	unit.name = "Gloomwing"

	unit.asset_name = '3x3_bat_dragon'
	unit.radius = 1

	unit.max_hp = 2187
	unit.flying = True
	breath = BatBreath()
	breath.range = 11
	breath.damage = 14
	unit.spells.append(breath)
	breath.cool_down = 4
	unit.spells.append(SimpleMeleeAttack(27, drain=True))

	unit.resists[Tags.Dark] = 100
	unit.resists[Tags.Physical] = 50
	unit.resists[Tags.Holy] = -50
	unit.tags = [Tags.Dragon, Tags.Dark, Tags.Blood, Tags.Undead]

	return unit

def Blightmonger():
	u = Unit()
	u.name = "Blightmonger"
	u.asset_name = '3x3_necro_dragon'
	u.radius = 1

	u.max_hp = 4781
	u.flying = True
	breath = NecroticBreath()
	breath.range = 10
	breath.damage = 24
	breath.duration = 25
	u.spells = [breath, SimpleMeleeAttack(32, NecrosisBuff, 25, drain=True)]

	u.resists[Tags.Dark] = 100
	u.tags = [Tags.Dragon, Tags.Dark]

	return u

def Rattlemaw():
	unit = Unit()
	unit.name = "Rattlemaw"
	unit.asset_name = "3x3_bone_dragon"
	unit.max_hp = 3004
	unit.radius = 1
	unit.flying = True
	breath = DarkBreath()
	breath.range = 11
	breath.damage = 23
	unit.spells = [LichSealSoulSpell(), breath, SimpleMeleeAttack(47)]
	unit.resists[Tags.Dark] = 100
	unit.tags = [Tags.Dragon, Tags.Undead, Tags.Dark]
	return unit

def RandomImp():
	return random.choice([FireImp, SparkImp, IronImp])()

def FireImp():
	unit = Unit()
	unit.name = "Fire Imp"
	unit.asset_name = 'imp_fire'
	unit.max_hp = 5
	unit.resists[Tags.Fire] = 75
	unit.resists[Tags.Ice] = -75
	unit.resists[Tags.Dark] = 75
	unit.spells.append(SimpleRangedAttack(damage=3, range=3, damage_type=Tags.Fire))
	unit.tags = [Tags.Demon, Tags.Fire]
	unit.flying = True
	return unit

def SparkImp():
	unit = Unit()
	unit.name = "Spark Imp"
	unit.asset_name = 'imp_spark'
	unit.max_hp = 5
	unit.resists[Tags.Lightning] = 75
	unit.resists[Tags.Dark] = 75
	unit.spells.append(SimpleRangedAttack(damage=3, range=3, damage_type=Tags.Lightning))
	unit.tags = [Tags.Demon, Tags.Lightning]
	unit.flying = True
	return unit

def IronImp():
	unit = Unit()
	unit.name = "Iron Imp"
	unit.asset_name = 'imp_iron'
	unit.max_hp = 5
	unit.resists[Tags.Dark] = 75
	unit.spells.append(SimpleRangedAttack(damage=3, range=3, damage_type=Tags.Physical))
	unit.tags = [Tags.Demon, Tags.Metallic]
	unit.flying = True
	return unit

def ChaosImp():
	unit = FireImp()
	unit.max_hp = 12
	unit.name = "Chaos Imp"
	unit.asset_name = "imp_chaos"
	unit.resists[Tags.Lightning] = 75

	shards = SimpleRangedAttack(damage=6, range=3, damage_type=[Tags.Lightning, Tags.Fire], radius=1)
	shards.name = "Chaos Shards"
	unit.spells = [shards]

	unit.tags.append(Tags.Lightning)
	return unit

def FurnaceImp():
	unit = FireImp()
	unit.max_hp = 12
	unit.name = "Furnace Imp"
	unit.asset_name = "imp_furnace"
	unit.resists[Tags.Physical] = 75

	shards = SimpleRangedAttack(damage=4, range=3, damage_type=[Tags.Physical, Tags.Fire], radius=1)
	shards.name = "Furnace Shards"
	unit.spells = [shards]

	unit.buffs.append(DamageAuraBuff(damage=1, damage_type=Tags.Fire, radius=4))
	unit.resists[Tags.Ice] = -50
	unit.tags.append(Tags.Metallic)
	return unit

def AshImp():
	unit = FireImp()
	unit.max_hp = 16
	unit.name = "Ash Imp"
	unit.asset_name = "imp_ash"

	shards = SimpleRangedAttack(damage=6, range=3, damage_type=Tags.Fire, buff=BlindBuff, buff_duration=1)
	shards.name = "Ash Bolt"
	unit.spells = [shards]
	return unit

def TungstenImp():
	unit = IronImp()
	unit.name = "Tungsten Imp"
	unit.asset_name = "imp_tungsten"
	unit.max_hp = 12
	unit.resists[Tags.Physical] = 90
	unit.resists[Tags.Arcane] = 50
	return unit

def RotImp():
	unit = Unit()
	unit.max_hp = 12
	unit.name = "Rot Imp"
	unit.asset_name = "imp_rot"
	unit.spells = [SimpleRangedAttack(name="Rot Bolt", damage=3, range=4, damage_type=Tags.Dark, buff=NecrosisBuff, buff_duration=3)]
	unit.tags = [Tags.Dark, Tags.Demon]
	unit.resists[Tags.Dark] = 75
	unit.flying = True
	return unit

def CopperImp():
	unit = IronImp()
	unit.max_hp = 12
	unit.name = "Copper Imp"
	unit.asset_name = "imp_copper"
	lbolt = SimpleRangedAttack(damage=4, range=5, beam=True, damage_type=Tags.Lightning)
	lbolt.name = "Lightning Bolt"
	lbolt.cool_down = 2
	coppershard = SimpleRangedAttack(damage=7, range=3, damage_type=Tags.Physical)
	coppershard.cool_down = 2
	unit.spells = [lbolt, coppershard]
	unit.tags.append(Tags.Lightning)
	return unit

def InsanityImp():
	unit = Unit()
	unit.flying = True
	unit.tags = [Tags.Demon, Tags.Arcane]
	unit.max_hp = 12
	unit.name = "Insanity Imp"
	unit.asset_name = "imp_insanity"

	unit.resists[Tags.Arcane] = 75
	unit.resists[Tags.Dark] = 75

	def onhit(caster, target): randomly_teleport(target, 3)
	insanity = SimpleRangedAttack(damage=3, range=6, damage_type=Tags.Arcane, onhit=onhit)
	insanity.description = "Teleports the target up to 3 tiles"
	insanity.name = "Phase Bolt"
	unit.spells = [insanity]

	return unit

def VoidImp():
	unit = Unit()
	unit.flying = True
	unit.tags = [Tags.Demon, Tags.Arcane]
	unit.max_hp = 12
	unit.name = "Void Imp"
	unit.asset_name = "imp_void"
	unit.resists[Tags.Arcane] = 75
	unit.resists[Tags.Dark] = 75

	void = SimpleRangedAttack(damage=3, range=5, damage_type=Tags.Arcane, beam=True, melt=True)
	unit.spells.append(void)
	return unit

def FireSpirit():
	unit = Unit()
	unit.name = "Fire Spirit"
	unit.max_hp = 10
	unit.buffs.append(SpiritBuff(Tags.Fire))
	unit.buffs.append(Thorns(4, Tags.Fire))
	unit.resists[Tags.Fire] = 100
	unit.resists[Tags.Ice] = -100
	unit.resists[Tags.Physical] = 50
	unit.spells.append(SimpleRangedAttack(damage=5, range=5, damage_type=Tags.Fire))
	unit.tags = [Tags.Fire]
	return unit

def SparkSpirit():
	unit = Unit()
	unit.name = "Spark Spirit"
	unit.max_hp = 10
	unit.buffs.append(SpiritBuff(Tags.Lightning))
	unit.buffs.append(Thorns(4, Tags.Lightning))
	unit.resists[Tags.Lightning] = 100
	unit.resists[Tags.Physical] = 50
	unit.spells.append(SimpleRangedAttack(damage=5, range=5, damage_type=Tags.Lightning))
	unit.tags = [Tags.Lightning]
	return unit

def StormSpirit():
	spirit = Unit()
	spirit.max_hp = 36
	spirit.name = "Storm Spirit"

	spirit.buffs.append(SpiritBuff(Tags.Ice))
	spirit.buffs.append(SpiritBuff(Tags.Lightning))

	spirit.spells.append(SimpleRangedAttack(name="Storm Blast", damage=11, radius=1, range=6, damage_type=[Tags.Ice, Tags.Lightning]))

	spirit.resists[Tags.Ice] = 100
	spirit.resists[Tags.Lightning] = 100
	unit.resists[Tags.Physical] = 50

	spirit.tags = [Tags.Ice, Tags.Lightning]
	
	return spirit

def ChaosSpirit():
	spirit = Unit()
	spirit.max_hp = 36
	spirit.name = "Chaos Spirit"

	spirit.buffs.append(SpiritBuff(Tags.Fire))
	spirit.buffs.append(SpiritBuff(Tags.Lightning))
	spirit.buffs.append(SpiritBuff(Tags.Chaos))

	chaosball = SimpleRangedAttack(damage=11, radius=1, range=6, damage_type=[Tags.Fire, Tags.Lightning, Tags.Physical])
	chaosball.name = "Chaos Blast"

	spirit.spells.append(chaosball)

	spirit.resists[Tags.Fire] = 100
	spirit.resists[Tags.Lightning] = 100
	spirit.resists[Tags.Physical] = 100

	spirit.tags = [Tags.Fire, Tags.Lightning, Tags.Chaos]
	
	return spirit

def FlyCloud():
	unit = Unit()
	unit.name = "Fly Swarm"
	unit.asset_name = "fly_swarm"
	unit.tags = [Tags.Living, Tags.Dark]
	unit.max_hp = 6
	unit.resists[Tags.Physical] = 75
	unit.resists[Tags.Dark] = 75
	unit.resists[Tags.Ice] = -50
	unit.flying = 1
	unit.spells.append(SimpleMeleeAttack(1))
	return unit

def BagOfBugs(spawn=FlyCloud):
	unit = Unit()
	unit.name = "Bag of Bugs"
	unit.max_hp = 16

	unit.spells.append(SimpleMeleeAttack(4))
	unit.buffs.append(SpawnOnDeath(spawn, 4))

	unit.tags = [Tags.Dark, Tags.Construct]

	unit.resists[Tags.Dark] = 50
	unit.resists[Tags.Physical] = 25
	unit.resists[Tags.Fire] = -100

	unit.buffs.append(GeneratorBuff(spawn, .05))

	return unit

def FlyTrap():
	unit = Unit()
	unit.name = "Fly Trap"
	unit.stationary = True
	unit.max_hp = 7

	unit.tags = [Tags.Living, Tags.Nature]

	fly_summon = SimpleSummon(FlyCloud, num_summons=3, cool_down=15)
	fly_summon.name = "Spawn Flies"
	unit.spells.append(fly_summon)
	tongue_attack = PullAttack(damage=2, range=5, color=Tags.Tongue.color)
	tongue_attack.name = "Tongue"
	tongue_attack.cool_down = 2
	unit.spells.append(tongue_attack)

	return unit

def SporeBeast():
	unit = Unit()
	unit.name = "Spore Beast"
	unit.max_hp = 25
	unit.buffs.append(SporeBeastBuff())
	unit.spells.append(SimpleMeleeAttack(8))
	unit.tags = [Tags.Living, Tags.Nature]
	return unit

def Mycobeast():
	unit = Unit()
	unit.name = "Mycobeast"
	unit.max_hp = 31
	unit.asset_name = "spore_beast_toxic"

	unit.buffs.append(GeneratorBuff(GreenMushboom, .1))
	unit.buffs.append(GeneratorBuff(GreyMushboom, .1))
	unit.buffs.append(RegenBuff(1))

	unit.spells.append(SimpleMeleeAttack(8))

	unit.resists[Tags.Fire] = -50
	unit.resists[Tags.Ice] = -50
	unit.resists[Tags.Poison] = 100

	unit.tags = [Tags.Living, Tags.Nature]

	return unit

def GreaterSporeBeast():
	unit = Unit()
	unit.name = "Greater Spore Beast"
	unit.max_hp = 65
	unit.buffs.append(SporeBeastBuff())
	unit.spells.append(SimpleMeleeAttack(8))
	unit.tags = [Tags.Living, Tags.Nature]
	return unit

def SpikeBeast():
	unit = Unit()
	unit.name = "Spike Beast"
	unit.max_hp = 65
	unit.buffs.append(SpikeBeastBuff())
	unit.buffs.append(Thorns(8))
	unit.spells.append(SimpleMeleeAttack(12))
	unit.tags = [Tags.Living, Tags.Nature]
	unit.resists[Tags.Physical] = 75
	return unit

def BlizzardBeast():
	unit = Unit()
	unit.name = "Blizzard Beast"
	unit.max_hp = 36
	unit.buffs.append(BlizzardBeastBuff())
	unit.spells.append(SimpleMeleeAttack(8))
	unit.tags = [Tags.Living, Tags.Nature, Tags.Ice]
	unit.resists[Tags.Ice] = 100
	unit.resists[Tags.Fire] = -50
	return unit

def VoidBomber():
	unit = Unit()
	unit.name = "Void Bomber"
	unit.max_hp = 1
	unit.buffs.append(VoidBomberBuff())
	unit.spells.append(VoidBomberSuicide())
	unit.tags = [Tags.Arcane]
	return unit


def FireBomber():
	unit = Unit()
	unit.name = "Fire Bomber"
	unit.max_hp = 1
	unit.buffs.append(FireBomberBuff())
	unit.spells.append(FireBomberSuicide())
	unit.tags = [Tags.Fire]
	return unit

def IceBomber():
	unit = Unit()
	unit.name = "Ice Bomber"
	unit.max_hp = 1
	unit.buffs.append(IceBomberBuff())
	unit.spells.append(IceBomberSuicide())
	unit.tags = [Tags.Ice]
	return unit

def PoisonBomber():
	unit = Unit()
	unit.name = "Poison Bomber"
	unit.asset_name = "poison_bomber"
	unit.max_hp = 1
	unit.buffs.append(PoisonBomberBuff())
	unit.spells.append(PoisonBomberSuicide())
	unit.tags = [Tags.Poison]
	return unit

def VoidRocketBomber():
	unit = VoidBomber()
	unit.shields = 1
	unit.name = "Void Rocket Bomber"
	unit.asset_name = "void_bomber_cluster"
	unit.buffs[0].clusters = 3
	unit.buffs.append(QuickmoveBuff())
	unit.tags.append(Tags.Construct)
	return unit

def FireRocketBomber():
	unit = FireBomber()
	unit.shields = 1
	unit.name = "Fire Rocket Bomber"
	unit.asset_name = "fire_bomber_cluster"
	unit.buffs[0].clusters = 3
	unit.buffs.append(QuickmoveBuff())
	unit.tags.append(Tags.Construct)
	return unit

def IceRocketBomber():
	unit = IceBomber()
	unit.shields = 1
	unit.name = "Ice Rocket Bomber"
	unit.asset_name = "ice_bomber_cluster"
	unit.buffs[0].clusters = 3
	unit.buffs.append(QuickmoveBuff())
	unit.tags.append(Tags.Construct)
	return unit

def DisplacerBeast():
	unit = Unit()
	unit.name = "Displacer Beast"
	unit.max_hp = 10
	unit.spells.append(SimpleMeleeAttack(3))
	unit.buffs.append(TeleportyBuff(flash=True))
	unit.tags = [Tags.Living, Tags.Arcane]
	unit.resists[Tags.Arcane] = 50
	return unit

def RazorBeast():
	unit = Unit()
	unit.name = "Razor Beast"
	unit.max_hp = 18
	unit.spells.append(SimpleMeleeAttack(damage=3, buff=BleedBuff, buff_duration=3, attacks=2))
	unit.buffs.append(TeleportyBuff(flash=True))
	unit.tags = [Tags.Living, Tags.Arcane, Tags.Metallic]
	unit.resists[Tags.Arcane] = 50
	unit.resists[Tags.Lightning] = -50
	unit.resists[Tags.Physical] = 0
	unit.resists[Tags.Poison] = 0
	unit.resists[Tags.Fire] = 0
	unit.resists[Tags.Ice] = 0
	return unit

def Orc():
	unit = Unit()
	unit.name = "Orc"
	unit.max_hp = 20
	unit.spells.append(SimpleMeleeAttack(5))
	unit.tags = [Tags.Living]
	return unit

def OrcWarchief():
	unit = Orc()
	unit.name = "Orc Warchief"
	unit.max_hp = 60
	unit.get_spell(SimpleMeleeAttack).damage *= 3

	summon = SimpleSummon(Orc, 3, 15)
	summon.name = "Summon Warband"
	unit.spells.insert(0, summon)
	unit.cool_downs[summon] = random.randint(summon.cool_down//2, summon.cool_down)
	return unit

def FlameMaw():
	unit = Unit()
	unit.max_hp = 36

	unit.tags = [Tags.Arcane, Tags.Fire]

	unit.resists[Tags.Fire] = 100
	unit.resists[Tags.Arcane] = 100
	unit.resists[Tags.Ice] = -50

	unit.name = "Flame Maw"
	unit.asset_name = 'flamemouth'

	firespell = SimpleRangedAttack(damage=5, damage_type=Tags.Fire, beam=True, range=7, max_channel=4, cool_down=9)
	unit.spells.insert(0, firespell)
	return unit

def IceMaw():
	unit = Unit()
	unit.max_hp = 36
	unit.tags = [Tags.Arcane, Tags.Ice]
	unit.resists[Tags.Ice] = 100
	unit.resists[Tags.Arcane] = 100
	unit.resists[Tags.Fire] = -50

	unit.name = "Ice Maw"
	unit.asset_name = 'icemouth'

	icespell = SimpleRangedAttack(damage=5, damage_type=Tags.Ice, beam=True, range=7, max_channel=4, cool_down=9, buff=FrozenBuff, buff_duration=2)
	unit.spells.insert(0, icespell)
	return unit

def HungryMaw():
	unit = Unit()
	unit.max_hp = 8
	unit.shields = 2
	unit.tags = [Tags.Arcane, Tags.Demon]
	unit.name = "Hungry Maw"

	unit.spells.append(PullAttack(damage=9, range=7, color=Tags.Tongue.color))

	unit.flying = True
	unit.stationary = True

	unit.resists[Tags.Arcane] = 75
	unit.resists[Tags.Dark] = 50
	unit.resists[Tags.Lightning] = -50

	return unit

def HolyGhost():
	spirit = Unit()
	spirit.name = "Holy Ghost"
	spirit.max_hp = 4
	spirit.spells.append(SimpleRangedAttack(damage=2, damage_type=Tags.Holy, range=3))
	spirit.turns_to_death = 7
	spirit.tags = [Tags.Holy, Tags.Undead]
	spirit.buffs.append(TeleportyBuff())
	spirit.resists[Tags.Holy] = 100
	spirit.resists[Tags.Dark] = -100
	spirit.resists[Tags.Physical] = 100
	spirit.flying = True
	return spirit

class SatyrWineSpell(Spell):

	def on_init(self):
		self.name = "Refresh"
		self.description = "Heal self or an ally for [5 HP:heal]"
		self.range = 1.5
		self.melee = True
		self.can_target_self = True
		self.cool_down = 2

	def get_ai_target(self):
		caster = self.caster
		units = [caster] if caster.cur_hp < caster.max_hp else []
		units.extend(u for u in caster.level.get_adjacent_units(caster) if not are_hostile(u, caster) and u.cur_hp < u.max_hp)
		if units:
			return random.choice(units)
		else:
			return None

	def cast_instant(self, x, y):
		u = self.caster.level.get_unit_at(x, y)
		if u:
			u.deal_damage(-5, Tags.Heal, self)

def Satyr():
	unit = Unit()
	unit.name = "Satyr"
	unit.max_hp = 19

	unit.tags = [Tags.Living, Tags.Nature]

	heal = HealAlly(5, 2)
	heal.name = "Refresh"
	heal.cool_down = 2

	unit.spells = [SimpleMeleeAttack(3), heal]

	return unit

def Pan():
	unit = Unit()
	unit.name = "Pan"
	unit.max_hp = 91
	unit.tags = [Tags.Chaos, Tags.Living, Tags.Nature]

	summon = SimpleSummon(Satyr, num_summons=7, cool_down=7, global_summon=True, path_effect=Tags.Blood)
	summon.name = "Piper at the Gates"

	madness = PansMadnessSpell()

	melee = SimpleMeleeAttack(18)

	unit.spells = [summon, madness, melee]
	return unit

class PansMadnessSpell(Spell):

	def on_init(self):
		self.name = "Strife"
		self.description = "Berserks enemies for 3 turns"
		self.cool_down = 3
		self.duration = 3
		self.radius = 3
		self.range = 0

	def get_ai_target(self):
		if any(are_hostile(u, self.caster) for u in self.caster.level.get_units_in_ball(self.caster, self.get_stat('radius'))):
			return self.caster
		return None

	def cast(self, x, y):
		for p in self.caster.level.get_points_in_ball(x, y, self.get_stat('radius')):
			self.caster.level.show_effect(p.x, p.y, Tags.Blood)
			yield
			u = self.caster.level.get_unit_at(p.x, p.y)
			if u and are_hostile(self.caster, u) and not u.is_player_controlled:
				u.apply_buff(BerserkBuff(), self.get_stat('duration'))
				yield

def Boggart():
	unit = Unit()
	unit.name = "Boggart"
	unit.max_hp = 6
	unit.shields = 1

	unit.spells.append(SimpleMeleeAttack(4, damage_type=Tags.Arcane))

	unit.tags = [Tags.Living, Tags.Nature, Tags.Arcane]
	
	unit.resists[Tags.Arcane] = 75

	return unit


class SmokeBomb(Spell):

	def on_init(self):
		self.name = "Blinding Powder"
		self.description = "Blind nearby units, teleport up to 10 tiles away\nFlees while on cooldown"
		self.range = 0
		self.damage_type = Tags.Poison
		self.radius = 2
		self.duration = 3

	def get_ai_target(self):
		for p in self.caster.level.get_adjacent_points(self.caster, filter_walkable=False):
			u = self.caster.level.get_unit_at(p.x, p.y)
			if u and are_hostile(u, self.caster): return self.caster
		else:
			return None

	def cast(self, x, y):
		target = Point(x, y)
		lvl = self.caster.level
		for stage in Burst(self.caster.level, target, self.get_stat('radius')):
			for point in stage:
				lvl.show_effect(point.x, point.y, Tags.Poison, minor=True, speed=2)
				unit = lvl.get_unit_at(point.x, point.y)
				if unit and unit != self.caster: unit.apply_buff(BlindBuff(), self.duration)
			yield
		randomly_teleport(self.caster, 10)
		self.caster.apply_buff(FearBuff(), self.cool_down)
		yield


def BoggartAssassin():
	unit = Boggart()
	unit.name = "Boggart Assassin"

	unit.max_hp = 18
	unit.shields = 2

	leap = LeapAttack(damage=4, range=3)
	leap.name = "Lunge"

	poison = SimpleMeleeAttack(damage=4, buff=Poison, buff_duration=10, attacks=2)
	poison.name = "Poison Stab"
	poison.cool_down = 2

	smoke = SmokeBomb()
	smoke.cool_down = 4

	unit.buffs = [QuickmoveBuff()]
	unit.spells = [poison, smoke, leap]

	return unit

class RallySpell(Spell):
	def on_init(self):
		self.name = "Faintly Blowing"
		self.description = "Allies within 4 tiles gain +1 spell damage"
		self.cool_down = 3
		self.range = 0

	def can_cast(self, x, y):
		return any(u for u in self.caster.level.get_units_in_ball(self.caster, 4) if u != self.caster and not are_hostile(self.caster, u))

	def can_threaten(self, x, y):
		return False

	def cast_instant(self, x, y):
		caster = self.caster
		level = caster.level
		seen = set()
		for p in level.get_points_in_ball(x, y, 4):
			u = level.get_unit_at(p.x, p.y)
			level.show_effect(p.x, p.y, Tags.Blood, minor=True)
			if not u or are_hostile(caster, u) or u==self.caster: continue
			seen.add(u)

		# don't super buff multi-tile units
		for u in seen: u.apply_buff(BloodrageBuff(1))

def BoggartHornblower():
	unit = Unit()
	unit.name = "Boggart Hornblower"
	unit.max_hp = 30
	unit.shields = 5
	unit.tags = [Tags.Arcane, Tags.Living, Tags.Nature]
	unit.resists[Tags.Arcane] = 75

	summon = SimpleSummon(Boggart, num_summons=1, cool_down=3)
	rally = RallySpell()
	melee = SimpleMeleeAttack(damage=8, damage_type=Tags.Arcane)

	unit.spells = [summon, rally, melee]
	unit.cool_downs[summon] = random.randint(summon.cool_down // 2, summon.cool_down)
	return unit

class MindMaggotBuff(Buff):

	def on_init(self):
		self.description = "Each turn, 5% chance to gain Flying"

	def on_advance(self):
		if random.random() > .05: return

		self.owner.flying += 1
		self.owner.clear_anim('Anim')
		self.owner.asset_name = "mind_maggot_winged"
		self.owner.name += " Drone"

		dive = LeapAttack(damage=3, range=4, is_leap=True)
		dive.name = "Dive Attack"
		self.owner.add_spell(dive)
		self.owner.remove_buff(self)

def MindMaggot():
	unit = Unit()
	unit.name = "Mind Maggot"
	unit.max_hp = 5

	melee = SimpleMeleeAttack(3, damage_type=Tags.Arcane, onhit=drain_spell_charges)
	melee.description = "On hit, drains a spell charge"
	melee.name = "Brain Bite"
	unit.spells.append(melee)

	unit.buffs.append(MindMaggotBuff())

	unit.tags = [Tags.Living, Tags.Arcane]
	return unit

def MindMaggotQueen():
	unit = Unit()
	unit.name = "Mind Maggot Queen"
	unit.max_hp = 79
	melee = SimpleMeleeAttack(11, onhit=drain_spell_charges)
	melee.name = "Brain Bite"
	melee.description = "On hit, drains a spell charge"
	unit.spells.append(melee)

	unit.buffs.append(GeneratorBuff(spawn_func=MindMaggot, spawn_chance=.1))

	unit.tags = [Tags.Living, Tags.Arcane]
	return unit

class MaggotCursed(Buff):

	def on_init(self):
		self.name = "Maggoty"
		self.color = Tags.Arcane.color
		self.description = "Each turn, summon a hostile Mind Maggot nearby"
		self.stack_type = STACK_INTENSITY
		self.buff_type = BUFF_TYPE_CURSE

	def on_advance(self):
		maggot_team = TEAM_PLAYER if self.owner.team == TEAM_ENEMY else TEAM_ENEMY
		self.summon(MindMaggot(), target=self.owner, radius=2, team=maggot_team)

def MindMaggotWretch():
	u = Unit()
	u.name = "Mind Maggot Wretch"
	u.tags = [Tags.Living, Tags.Arcane, Tags.Dark]
	u.max_hp = 200

	drain = "On hit, drains a spell charge"
	melee = SimpleMeleeAttack(damage=25, damage_type=Tags.Physical, onhit=drain_spell_charges, onhit_description=drain, attacks=2)
	melee.name = "Brain Bites"

	u.spells = [melee]
	u.buffs = [QuickmoveBuff(), DeathCurseRetaliation(name="Wretched Curse", buff=MaggotCursed, buff_dur=10, color_tag=Tags.Arcane)]

	add_tooltip(u, MaggotCursed())
	add_tooltip(u, MindMaggot())

	return u

def MaggotLeech():
	u = Unit()
	u.name = "Maggot Leech"
	u.asset_name = 'blood_maggot'
	u.tags = [Tags.Blood, Tags.Dark, Tags.Living]
	u.max_hp = 100

	u.resists[Tags.Dark] = 75

	drain = SimpleMeleeAttack(damage=10, buff=HemorrhageBuff, buff_duration=10, drain=True)
	drain.name = "Blood Bite"

	u.spells = [drain]
	u.buffs = [QuickmoveBuff()]
	add_tooltip(u, HemorrhageBuff())

	return u

def GiantMindMaggotQueen():
	unit = Unit()
	unit.name = "Maggot Empress"
	unit.asset_name = "3x3_maggot_queen"
	unit.max_hp = 1210
	unit.radius = 1

	melee = SimpleMeleeAttack(74, onhit=drain_all_spell_charges)
	melee.name = "Brain Bite"
	melee.description = "On hit, drain all charges from a spell"
	unit.spells.append(melee)

	summon = SimpleSummon(MindMaggot, num_summons=4, cool_down=8)
	unit.spells.append(summon)

	unit.flying = True
	unit.tags = [Tags.Living, Tags.Arcane]
	return unit

def Centaur():
	unit = Unit()
	unit.name = "Centaur"
	unit.max_hp = 15
	
	javalin = SimpleRangedAttack(damage=5, range=5)
	javalin.cool_down = 8
	javalin.name = "Throw Spear"
	unit.spells.append(javalin)
	
	trample = SimpleMeleeAttack(4, trample=True)
	trample.name = "Trample"
	unit.spells.append(trample)
	
	leap = LeapAttack(damage=4, damage_type=Tags.Physical, range=4)
	leap.name = "Leap"
	leap.cool_down = 3
	unit.spells.append(leap)

	unit.tags = [Tags.Living]
	return unit

def CentaurDruid():
	unit = Centaur()
	unit.name = "Centaur Druid"
	unit.max_hp = 90

	eagles = SimpleSummon(Eagle, cool_down=15, num_summons=2)

	regen = WizardHealAura()
	regen.heal = 4
	regen.duration = 10
	regen.cool_down = 15

	trample = SimpleMeleeAttack(8, trample=True)
	trample.name = "Trample"

	leap = LeapAttack(damage=8, damage_type=Tags.Physical, range=4)
	leap.name = "Leap"
	leap.cool_down = 3

	unit.spells = [eagles, regen, trample, leap]
	unit.is_wizard = True

	return unit

def Thunderbones():
	unit = Unit()
	unit.name = "Old Thunderbones"
	unit.asset_name = "ogre_shaman"

	unit.max_hp = 256
	unit.shields = 3

	unit.resists[Tags.Dark] = 50
	unit.resists[Tags.Lightning] = 50

	summon = SimpleSummon(SparkSpirit, num_summons=2, cool_down=5, duration=20)
	ball = SimpleRangedAttack(damage=10, damage_type=Tags.Dark, range=6, radius=2, buff=FearBuff, buff_duration=3, cool_down=5)
	melee = SimpleMeleeAttack(damage=25, damage_type=Tags.Physical, buff=Stun, buff_duration=1)

	unit.spells = [summon, ball, melee]
	unit.buffs.append(SpawnOnDeath([ToweringBoneShambler], [2]))

	unit.tags = [Tags.Living, Tags.Dark, Tags.Lightning]
	unit.is_wizard = True
	return unit

def Ogre():
	unit = Unit()
	unit.name = "Ogre"
	unit.max_hp = 45
	unit.spells.append(SimpleMeleeAttack(15))
	unit.tags = [Tags.Living]
	return unit

class Invigoration(Spell):

	def on_init(self):
		self.name = "Invigoration"
		self.range = 0
		self.can_target_self = True
		self.cool_down = 6

	def get_description(self):
		return "Wounded allies heal for [10 HP:heal] and gain [1:damage] spell damage"

	def get_ai_target(self):
		if any(u for u in self.caster.level.units if are_friendly(u, self.caster) and u.cur_hp != u.max_hp):
			return self.caster
		return None

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		allies = [u for u in level.units if are_friendly(u, caster) and u.cur_hp != u.max_hp and u != caster]
		for u in allies:
			level.show_path_effect(caster, u, Tags.Nature)
			u.heal(10, self)
			u.apply_buff(BloodrageBuff(1))
			yield from level.show_path_effect(caster, u, Tags.Nature, pause_frames=1)
		yield

def TrollGeomancer():
	unit = EarthTroll()
	unit.max_hp = 120
	unit.name = "Troll Geomancer"
	unit.asset_name = "troll_wizard"

	petrify = SimpleRangedAttack(damage=0, damage_type=Tags.Physical, range=4, cool_down=15, buff=PetrifyBuff, buff_duration=4)
	petrify.name = "Petrify"

	def wolf():
		wolf = Unit()
		wolf.max_hp = 12
		wolf.name = "Clay Hound"
		wolf.asset_name = "earth_hound"

		wolf.resists[Tags.Physical] = 50
		wolf.resists[Tags.Fire] = 50
		wolf.resists[Tags.Lightning] = 50

		wolf.spells.append(SimpleMeleeAttack(5))
		wolf.spells.append(LeapAttack(5, damage_type=Tags.Physical, range=5))
		wolf.tags = [Tags.Living, Tags.Nature]
		wolf.buffs.append(RegenBuff(3))
		return wolf

	wolves = SimpleSummon(wolf, cool_down=8, num_summons=2)
	wolves.name = "Summon Clay Hounds"


	melee = SimpleMeleeAttack(10)
	unit.spells = [petrify, wolves, Invigoration(), melee]

	unit.tags.append(Tags.Nature)
	unit.is_wizard = True
	return unit

def Troll():
	unit = Unit()
	unit.name = "Troll"
	unit.max_hp = 30
	unit.buffs.append(TrollRegenBuff())
	unit.spells.append(SimpleMeleeAttack(10))
	unit.tags = [Tags.Living]
	return unit

def EarthTroll():
	unit = Troll()
	unit.asset_name = "troll"
	unit.name = "Earth Troll"
	unit.resists[Tags.Physical] = 50
	unit.resists[Tags.Fire] = 50
	unit.resists[Tags.Lightning] = 50
	return unit

def StormTroll():
	unit = Troll()
	unit.asset_name = None
	unit.name = "Storm Troll"
	unit.resists[Tags.Lightning] = 100
	unit.buffs.append(CloudGeneratorBuff(StormCloud, radius=3, chance=10))
	unit.tags = [Tags.Living, Tags.Lightning]
	return unit

def Trollataur():
	unit = Troll()
	unit.name = "Trollataur"
	unit.max_hp = 45

	trample = SimpleMeleeAttack(8, trample=True)
	trample.name = "Trample"

	leap = LeapAttack(damage=8, damage_type=Tags.Physical, range=4)
	leap.name = "Leap"
	leap.cool_down = 3

	unit.spells = [trample, leap]

	return unit

class SirenSong(Spell):

	def on_init(self):
		self.name = "Siren Song"
		self.description = "Pull [Living] enemies up to 3 tiles toward the caster, inflict [berserk] for 3 turns"
		self.radius = 6
		self.pull_distance = 3
		self.duration = 3
		self.range = 0
		self.cool_down = 2

	def cast(self, x, y):
		for unit in self.caster.level.get_units_in_ball(Point(x, y), self.radius):
			if are_friendly(self.caster, unit): continue
			if Tags.Living not in unit.tags: continue
			pull(unit, self.caster, self.pull_distance)
			yield from self.caster.level.show_path_effect(self.caster, unit, Tags.Music, pause_frames=1)
			if unit.is_player_controlled: continue
			unit.apply_buff(BerserkBuff(), self.duration)
		yield

	def get_ai_target(self):
		for unit in self.caster.level.get_units_in_ball(self.caster, self.radius):
			if are_hostile(self.caster, unit): return self.caster
		return None

def Siren():
	u = Unit()
	u.name = "Siren"
	u.tags = [Tags.Living, Tags.Nature, Tags.Demon]
	u.max_hp = 96
	u.stationary = True
	def love(caster, target):
		if not target.is_alive(): return
		if Tags.Living not in target.tags: return
		if target.is_player_controlled: return
		target.team = caster.team
		target.remove_buffs(BerserkBuff)
	bite = SimpleMeleeAttack(damage=4, onhit=love, onhit_description="Dominates [Living] non-player enemies and removes [berserk]")
	bite.name = "Love Bite"
	u.spells = [SirenSong(), bite]
	u.buffs = []
	u.resists[Tags.Lightning] = -50
	u.resists[Tags.Holy] = -50
	u.resists[Tags.Dark] = 0
	return u


def Gremlin():
	unit = Unit()
	unit.name = "Gremlin"
	unit.max_hp = 17
	unit.tags = [Tags.Demon, Tags.Dark]

	melee = SimpleMeleeAttack(4)
	wail = SimpleRangedAttack(damage=1, damage_type=Tags.Dark, range=5, buff=FearBuff, buff_duration=1, cool_down=4)
	wail.name = 'Fear Bolt'

	unit.spells = [wail, melee]

	return unit

class BansheeFearAura(DamageAuraBuff):

	def __init__(self):
		DamageAuraBuff.__init__(self, damage=0, damage_type=Tags.Dark, radius=5)
		self.description = "Each turn, enemies within 5 tiles are [feared] for 1 turn"

	def on_hit(self, unit):
		unit.apply_buff(FearBuff(), 1)

	def get_tooltip(self):
		return self.description

def Banshee():
	unit = Unit()
	unit.name = "Wailing Banshee"
	unit.max_hp = 81
	unit.tags = [Tags.Undead, Tags.Dark]
	unit.asset_name = 'banshee'
	unit.spells.append(SimpleMeleeAttack(9, damage_type=Tags.Dark))
	unit.buffs.append(BansheeFearAura())
	return unit

def Ghost():
	unit = Unit()
	unit.name = "Ghost"
	unit.max_hp = 4
	unit.resists[Tags.Physical] = 100
	unit.resists[Tags.Dark] = 50
	unit.buffs.append(TeleportyBuff())
	unit.spells.append(SimpleMeleeAttack(1, damage_type=Tags.Dark))
	unit.flying = True
	unit.tags = [Tags.Dark, Tags.Undead]
	return unit

def Pain():
	pain = Ghost()
	pain.name = "Pain"
	pain.asset_name = "ghost_pain"
	pain.max_hp = 24
	pain.spells = [SimpleRangedAttack(damage=6, range=4, damage_type=Tags.Lightning)]

	pain.resists[Tags.Lightning] = 50
	return pain

def Death():

	death = Ghost()
	death.name = "Death"
	death.asset_name = "ghost_woe"
	death.max_hp = 24
	death.spells = [SimpleRangedAttack(damage=6, range=4, damage_type=Tags.Dark)]

	death.resists[Tags.Dark] = 100
	return death

def Sorrow():
	sorrow = Ghost()
	sorrow.name = "Sorrow"
	sorrow.asset_name = "ghost_sorrow"
	sorrow.max_hp = 24
	sorrow.spells = [SimpleRangedAttack(damage=6, range=4, damage_type=Tags.Ice)]

	sorrow.resists[Tags.Ice] = 50
	return sorrow


def GhostFire():
	unit = Ghost()
	unit.name = "Fire Ghost"
	unit.asset_name = "fire_ghost"
	unit.resists[Tags.Fire] = 100
	unit.resists[Tags.Ice] = -100
	fire = SimpleRangedAttack(damage=7, range=5, damage_type=Tags.Fire)
	fire.name = "Fire Bolt"
	unit.spells[0] = fire

	unit.tags.append(Tags.Fire)
	return unit

def GhostMass():
	unit = Ghost()
	unit.max_hp = 28
	unit.name = "Ghostly Mass"
	unit.asset_name = "ghostly_mass"
	unit.spells[0].damage *= 8
	unit.buffs.append(SpawnOnDeath(Ghost, 8))
	return unit

class TombstoneSummon(SimpleSummon):

	def __init__(self):
		SimpleSummon.__init__(self, Ghost, cool_down=4, global_summon=True, path_effect=Tags.Dark)
		self.name = "Haunt"
		self.description = "Summons a Ghost near the Wizard"

	def cast(self, x, y, channel_cast=False):
		self.summon(self.get_unit(), target=Point(x, y), sort_dist=True)
		yield

	def get_ai_target(self):
		return self.caster.level.player_unit

	def can_cast(self, x, y):
		return True

	def can_threaten(self, x, y):
		return False

def Tombstone():
	idol = Idol()
	idol.name = "Tombstone"
	idol.asset_name = 'tombstone'
	idol.spells.append(TombstoneSummon())
	return idol

def Casket():
	u = Unit()
	u.stationary = True
	u.flying = True
	u.name = "Haunted Casket"
	u.asset_name = 'casket'
	u.tags = [Tags.Dark, Tags.Construct]
	u.max_hp = 100
	u.spells = [SimpleSummon(VampireBat, num_summons=3, cool_down=12, radius=5, path_effect=Tags.Dark), SimpleSummon(Bat, radius=5, path_effect=Tags.Dark)]
	u.buffs = [GeneratorBuff(CountBat, .01)]
	u.resists[Tags.Dark] = 100
	u.resists[Tags.Fire] = -100
	return u

def Goblin():
	unit = Unit()
	unit.name = "Goblin"
	unit.max_hp = 7
	unit.spells.append(SimpleMeleeAttack(2))
	unit.tags = [Tags.Living]
	return unit

def GoblinArmored():
	unit = Goblin()
	unit.name = "Armored Goblin"
	unit.asset_name = "goblin_armored"
	unit.max_hp = 16
	unit.tags.append(Tags.Metallic)
	unit.spells = [SimpleMeleeAttack(7)]
	unit.resists[Tags.Lightning] = -50
	unit.resists[Tags.Ice] = 0
	return unit

def HealingTotem():
	unit = Unit()
	unit.name = "Healing Totem"
	unit.asset_name = "totem_healing"
	unit.max_hp = 20
	buff = HealAuraBuff(3, 5)
	unit.buffs.append(buff)
	unit.stationary = True
	return unit

def LightningTotem():
	unit = Unit()
	unit.name = "Lightning Totem"
	unit.asset_name = "totem_lightning"
	unit.max_hp = 7
	unit.tags = [Tags.Construct, Tags.Lightning]
	arc = SimpleRangedAttack(damage=4, damage_type=Tags.Lightning, range=5)
	unit.spells = [arc]
	unit.stationary = True
	return unit

def GoblinShaman():
	unit = Goblin()
	unit.name = "Goblin Shaman"
	unit.max_hp = 33
	unit.shields = 6

	bolt = SimpleRangedAttack(damage=3, damage_type=Tags.Dark, range=3)
	unit.spells.insert(0, bolt)

	summonheal = SimpleSummon(HealingTotem, 1, 5, duration=10)
	summonheal.name = "Summon Healing Totem"
	unit.spells.insert(0, summonheal)
	unit.cool_downs[summonheal] = random.randint(summonheal.cool_down//2, summonheal.cool_down)

	summonlightning = SimpleSummon(LightningTotem, 1, 5, duration=10)
	summonlightning.name = "Summon Lightning Totem"
	unit.spells.insert(0, summonlightning)
	unit.cool_downs[summonlightning] = random.randint(summonlightning.cool_down//2, summonlightning.cool_down)

	unit.is_wizard = True

	return unit


def Bat():
	unit = Unit()
	unit.name = "Bat"
	unit.max_hp = 4
	unit.flying = True
	unit.spells.append(SimpleMeleeAttack(2))
	unit.tags = [Tags.Living, Tags.Dark]
	return unit

class SlimeBuff(Buff):

	def __init__(self, spawner, name='slimes', growth_chance=.5):
		Buff.__init__(self)
		self.description = ("Each turn, {chance}% chance to heal for 10% of original max HP\n"
							"Excess raises max HP\n\n"
							"At double original max HP, split into 2 {spawn}",
							{'chance': int(100 * growth_chance), 'spawn': name})

		self.name = "Slime Growth"
		self.color = Tags.Slime.color
		self.spawner = spawner
		self.spawner_name = name
		self.growth_chance = growth_chance

	def on_applied(self, owner):
		self.start_hp = owner.max_hp
		self.to_split = self.start_hp * 2
		self.growth = self.start_hp // 10

	def get_description(self):
		if self.applied:
			return ("Each turn, {chance}% chance to heal for {heal} HP\n"
					"Excess raises max HP\n"
					"At {threshold} HP, split into 2 {spawn}",
					{'chance': int(100 * self.growth_chance), 'heal': self.growth, 'threshold': self.to_split, 'spawn': self.spawner_name})
		else: return self.description

	def on_advance(self):
		self.check_split()
		if random.random() >= self.growth_chance: return

		owner = self.owner
		growth = self.growth
		cur = owner.cur_hp
		if (cur + growth) >= owner.max_hp: owner.max_hp = cur + growth
		owner.heal(growth, self)
		self.check_split()

	def check_split(self):
		if self.owner.cur_hp >= self.to_split:
			u = self.summon(self.get_unit(), self.owner)
			if not u: return # dont cut hp if a double was unable to be summoned
			self.owner.max_hp //= 2
			self.owner.cur_hp //= 2


	def get_unit(self):
		u = self.spawner()
		src = getattr(getattr(self, 'owner', None), 'source', None)
		if src: u.source = src; apply_minion_bonuses(src, u)
		return u

def get_matching_slimes(unit):
	candidates = []
	if Tags.Fire in unit.tags:
		candidates.append(RedSlime)
	if Tags.Ice in unit.tags:
		candidates.append(IceSlime)
	if Tags.Arcane in unit.tags:
		candidates.append(VoidSlime)
	if Tags.Lightning in unit.tags:
		candidates.append(ElectricSlime)
	if Tags.Blood in unit.tags:
		candidates.append(BloodSlime)
	if not candidates: # default back to greens
		candidates.append(GreenSlime)
	return candidates


class GrowSlimes(Spell):

	def on_init(self):
		self.name = "Grow Slimes"
		self.description = "Allied [Slimes:slime] gain 5 max HP"
		self.cool_down = 3
		self.range = 0

	def get_ai_target(self):
		return self.caster

	def cast_instant(self, x, y):
		for u in self.caster.level.units:
			if Tags.Slime not in u.tags: continue
			if are_hostile(self.caster, u): continue
			if u == self.caster: continue
			u.max_hp += 5


def SlimeMage():
	unit = Unit()
	unit.name = "Slime Brewer"
	unit.max_hp = 180

	unit.tags = [Tags.Living, Tags.Slime]

	def summon_slime(caster, target):
		slime_type = random.choice(slime_types)
		slime = slime_type()
		caster.level.summon(caster, slime, target)

	attack = SimpleRangedAttack(damage=6, range=7, damage_type=Tags.Poison, onhit=summon_slime)
	attack.name = "Slime Spew"
	attack.description = "Summons a random Slime near the target"
	for fn in slime_types: attack.add_unit_tooltip(fn)

	unit.spells.append(GrowSlimes())
	unit.spells.append(attack)

	unit.is_wizard = True

	return unit

def GreenSlime():

	unit = Unit()
	unit.name = "Green Slime"

	unit.max_hp = 10

	unit.tags = [Tags.Slime]

	unit.spells.append(SimpleMeleeAttack(3, damage_type=Tags.Poison))
	unit.buffs.append(SlimeBuff(spawner=GreenSlime))

	unit.resists[Tags.Poison] = 100
	unit.resists[Tags.Physical] = 50

	return unit

def RedSlime():

	unit = Unit()

	unit.name = "Red Slime"
	unit.max_hp = 10

	unit.tags = [Tags.Slime, Tags.Fire]

	unit.spells.append(SimpleRangedAttack(damage=3, damage_type=Tags.Fire, range=3))

	unit.buffs.append(SlimeBuff(spawner=RedSlime))

	unit.resists[Tags.Fire] = 100
	unit.resists[Tags.Ice] = -100
	unit.resists[Tags.Physical] = 50

	return unit

def IceSlime():

	unit = Unit()

	unit.name = "Ice Slime"
	unit.max_hp = 10

	unit.tags = [Tags.Slime, Tags.Ice]

	unit.spells.append(SimpleRangedAttack(damage=3, damage_type=Tags.Ice, range=3))

	unit.buffs.append(SlimeBuff(spawner=IceSlime))

	unit.resists[Tags.Ice] = 100
	unit.resists[Tags.Physical] = 50
	unit.resists[Tags.Fire] = -100

	return unit

def VoidSlime():

	unit = Unit()

	unit.name = "Void Slime"
	unit.max_hp = 10

	unit.tags = [Tags.Slime, Tags.Arcane]

	unit.spells.append(SimpleRangedAttack(damage=3, damage_type=Tags.Arcane, range=3, melt=True, beam=True))

	unit.buffs.append(SlimeBuff(spawner=VoidSlime))
	unit.buffs.append(TeleportyBuff(radius=7))

	unit.resists[Tags.Arcane] = 100
	unit.resists[Tags.Physical] = 50

	return unit

def ElectricSlime():

	unit = Unit()
	unit.name = "Electric Slime"
	unit.max_hp = 10
	unit.tags = [Tags.Slime, Tags.Lightning]
	unit.spells.append(SimpleMeleeAttack(damage=3, damage_type=Tags.Lightning))
	unit.spells.append(LeapAttack(damage=3, damage_type=Tags.Lightning, range=3))
	unit.buffs.append(SlimeBuff(spawner=ElectricSlime))

	unit.resists[Tags.Lightning] = 100
	unit.resists[Tags.Physical] = 50

	return unit

def BloodSlime():

	unit = Unit()
	unit.name = "Blood Slime"
	unit.max_hp = 10
	unit.tags = [Tags.Slime, Tags.Blood]
	unit.spells.append(SimpleMeleeAttack(damage=3, damage_type=Tags.Physical, drain=True))
	unit.spells.append(SimpleRangedAttack(damage=3, damage_type=Tags.Dark, range=3, drain=True))
	unit.buffs.append(SlimeBuff(spawner=BloodSlime))

	unit.resists[Tags.Dark] = 100
	unit.resists[Tags.Physical] = 50

	return unit

slime_types = [
	GreenSlime,
	RedSlime,
	ElectricSlime,
	VoidSlime,
	BloodSlime,
	IceSlime
]

slime_types_to_damage = {
	GreenSlime: Tags.Poison,
	RedSlime: Tags.Fire,
	ElectricSlime: Tags.Lightning,
	VoidSlime: Tags.Arcane,
	BloodSlime: Tags.Dark,
	IceSlime: Tags.Ice,
}

slime_damage_type_to_status = {
	Tags.Poison: Poison,
	Tags.Fire: BlindBuff,
	Tags.Lightning: ImmobilizeBuff,
	Tags.Arcane: Silence,
	Tags.Dark: BleedBuff,
	Tags.Ice: SoakedBuff
}

class GeneratorBuff(Buff):

	def __init__(self, spawn_func, spawn_chance, global_summon=False, num_summons=1):
		Buff.__init__(self)
		self.spawner = spawn_func
		self.spawn_chance = spawn_chance
		self.spawner_name = spawn_func().name
		self.global_summon = global_summon
		self.num_summons = num_summons

	def on_advance(self):
		if random.random() > self.spawn_chance: return
		for i in range(self.num_summons):
			unit = self.get_unit()
			if self.global_summon: # look for a place to deposit them
				targets = [t for t in self.owner.level.iter_tiles() if self.owner.level.can_stand(t.x, t.y, unit)]
				if targets: target = random.choice(targets)
				else: return
			else: target = None
			self.owner.level.summon(self.owner, unit, target=target)

	def get_unit(self):
		u = self.spawner()
		src = getattr(getattr(self, 'owner', None), 'source', None)
		if src: u.source = src; apply_minion_bonuses(src, u)
		return u

	def get_unit_extra_examine_tooltips(self):
		return [self.get_unit()]

	def get_tooltip(self):
		num = 'a' if self.num_summons == 1 else self.num_summons
		if self.spawn_chance < 1:
			return ("Has a {chance}% chance each turn to spawn {num} {spawn}",
			{'chance':int(100 * self.spawn_chance), 'num':num, 'spawn':self.spawner_name})
		else:
			return ("Each turn spawns {num} {spawn}", {'num':num, 'spawn':self.spawner_name})


def DisplacerBeastMother():
	unit = DisplacerBeast()
	unit.name = "Displacer Broodmother"
	unit.spells[0].damage = 12
	unit.max_hp = 72
	unit.buffs.append(GeneratorBuff(DisplacerBeast, .1))
	unit.tags = [Tags.Living, Tags.Arcane]
	return unit

def Efreet():

	unit = Unit()
	unit.max_hp = 84
	unit.name = "Efreet"

	unit.buffs.append(DamageAuraBuff(damage_type=Tags.Fire, damage=6, radius=5, friendly_fire=False))
	unit.spells.append(SimpleRangedAttack(damage=13, range=4, damage_type=Tags.Fire))

	unit.resists[Tags.Fire] = 100
	unit.resists[Tags.Ice] = -50
	unit.flying = True

	unit.tags = [Tags.Fire, Tags.Demon]
	unit.buffs.append(TeleportyBuff())

	return unit

class SpikedWheelBuff(Buff):

	def on_init(self):
		self.name = "Spiked Wheel"
		self.owner_triggers[EventOnDeath] = self.on_death

	def get_description(self):
		return "On death, shoot spears of bone in all 8 directions\nEach spear deals 25 [Physical] damage to each tile it passes through until it hits a wall"

	def on_death(self, evt):
		self.owner.level.queue_spell(self.do_spears(Point(self.owner.x, self.owner.y)))

	def do_spears(self, origin):
		owner = self.owner
		level = owner.level
		projectile_effect = level.projectile_effect
		get_extended_path = level.get_extended_path
		getu = level.get_unit_at
		tiles = level.tiles
		deal_damage = level.deal_damage

		for p in level.get_adjacent_points(origin, False, False):
			path = get_extended_path(origin, p)[1:]
			for pt in path:
				projectile_effect(pt.x, pt.y, proj_name='bone_spear', proj_origin=origin, proj_dest=path[-1])
				if tiles[pt.x][pt.y].is_wall(): break
				u = getu(pt.x, pt.y)
				if u: deal_damage(pt.x, pt.y, 25, Tags.Physical, self)
			yield


def BoneWheel():
	u = Unit()
	u.name = "Bone Wheel"
	u.tags = [Tags.Undead, Tags.Dark]
	u.max_hp = 200
	u.spells = [SimpleMeleeAttack(damage=10, buff=BleedBuff, buff_duration=10, trample=True)]
	u.buffs = [QuickmoveBuff(), CurseRetaliation(buff=BleedBuff, buff_dur=3, color_tag=Tags.Blood, melee=True), SpikedWheelBuff()]
	return u

def BoneShambler(HP=32):
	unit = Unit()
	unit.max_hp = HP
	unit.resists[Tags.Dark] = 100

	if HP >= 256: unit.name = "Bone Shambler Megalith"
	elif HP >= 64: unit.name = "Towering Bone Shambler"
	elif HP >= 16: unit.name = "Bone Shambler"
	else: unit.name = "Bone Shambler Fragment"
	if HP >= 16: unit.buffs.append(SplittingBuff(spawner=lambda : BoneShambler(unit.max_hp // 2), children=2))
	unit.spells.append(SimpleMeleeAttack(HP // 4))
	unit.tags = [Tags.Undead]
	return unit

def ToweringBoneShambler(HP=128):
	return BoneShambler(128)

def BoneShamblerMegalith():
	return BoneShambler(256)

def WormShambler(HP=50):
	unit = WormBall(HP)
	return unit

def SmallWormBall():
	return WormBall(5)

def WormBall(HP=10):
	unit = Unit()
	unit.max_hp = HP

	if HP >= 50:
		unit.name = "Worm Shambler"
		unit.asset_name = "wormball_shambler"
	
		def summon_worms(caster, target):
			worms = WormBall(5)
			caster.level.summon(caster, worms, target)

		spitworms = SimpleRangedAttack(damage=7, range=6, damage_type=Tags.Physical, onhit=summon_worms, cool_down=3)
		spitworms.name = "Worm Bolt"
		spitworms.description = "Summons a Tiny Worm Ball next to the target"
		unit.spells.append(spitworms)
	elif HP >= 10:
		unit.name = "Large Worm Ball"
		unit.asset_name = "wormball"
	else:
		unit.name = "Small Worm Ball"
		unit.asset_name = "wormball_small"

	if HP >= 10:
		unit.buffs.append(SplittingBuff(spawner=lambda : WormBall(unit.max_hp // 2), children=2))

	unit.buffs.append(RegenBuff(3))
	unit.spells.append(SimpleMeleeAttack(HP // 2))

	unit.tags = [Tags.Living]
	return unit

def WormBallToxic(HP=10):
	unit = Unit()
	unit.max_hp = HP

	if HP >= 50:
		unit.name = "Toxic Worm Shambler"
		unit.asset_name = "wormball_shambler_toxic"

		def summon_worms(caster, target):
			worms = WormBallToxic(5)
			caster.level.summon(caster, worms, target)

		spitworms = SimpleRangedAttack(damage=7, range=6, damage_type=Tags.Physical, onhit=summon_worms, cool_down=3)
		unit.spells.append(spitworms)

	elif HP >= 10:
		unit.name = "Large Toxic Worm Ball"
		unit.asset_name = "wormball_toxic"
	else:
		unit.name = "Small Toxic Worm Ball"
		unit.asset_name = "wormball_small_toxic"

	if HP >= 10:
		unit.buffs.append(SplittingBuff(spawner=lambda : WormBallToxic(unit.max_hp // 2), children=2))

	unit.buffs.append(RegenBuff(3))
	unit.spells.append(SimpleMeleeAttack(HP // 2))
	unit.buffs.append(DamageAuraBuff(damage=2 if HP >= 10 else 1, damage_type=Tags.Poison, radius=3))

	unit.tags = [Tags.Living, Tags.Poison]
	unit.resists[Tags.Poison] = 100
	return unit

def WormBallIron(HP=10):
	unit = Unit()
	unit.max_hp = HP

	if HP >= 50:
		unit.name = "Iron Worm Shambler"
		unit.asset_name = "wormball_shambler_iron"

		def summon_worms(caster, target):
			worms = WormBallIron(5)
			caster.level.summon(caster, worms, target)

		spitworms = SimpleRangedAttack(damage=7, range=6, damage_type=Tags.Physical, onhit=summon_worms, cool_down=3)
		unit.spells.append(spitworms)

	elif HP >= 10:
		unit.name = "Large Iron Worm Ball"
		unit.asset_name = "wormball_iron"
	else:
		unit.name = "Small Iron Worm Ball"
		unit.asset_name = "wormball_small_iron"

	if HP >= 10:
		unit.buffs.append(SplittingBuff(spawner=lambda : WormBallIron(unit.max_hp // 2), children=2))

	unit.buffs.append(RegenBuff(3))
	unit.spells.append(SimpleMeleeAttack(3 + HP // 2))

	unit.tags = [Tags.Construct, Tags.Metallic]
	return unit

def WormBallGhostly(HP=10):
	unit = Unit()
	unit.max_hp = HP

	if HP >= 50:
		unit.name = "Ghostly Worm Shambler"
		unit.asset_name = "wormball_shambler_ghostly"

		def summon_worms(caster, target):
			worms = WormBallGhostly(5)
			caster.level.summon(caster, worms, target)

		spitworms = SimpleRangedAttack(damage=7, range=6, damage_type=Tags.Physical, onhit=summon_worms, cool_down=3)
		unit.spells.append(spitworms)
		
	elif HP >= 10:
		unit.name = "Large Ghostly Worm Ball"
		unit.asset_name = "wormball_ghostly"
	else:
		unit.name = "Small Ghostly Worm Ball"
		unit.asset_name = "wormball_small_ghostly"

	if HP >= 10:
		unit.buffs.append(SplittingBuff(spawner=lambda : WormBallGhostly(unit.max_hp // 2), children=2))

	unit.buffs.append(RegenBuff(3))
	unit.buffs.append(TeleportyBuff())
	unit.spells.append(SimpleMeleeAttack(HP // 2, damage_type=Tags.Dark))

	unit.resists[Tags.Physical] = 100
	unit.tags = [Tags.Undead]
	return unit

def FaeryGlass():
	unit = Faery()
	unit.name = "Glass Faery"
	unit.asset_name = "faery_glass"

	unit.shields += 1

	glassbolt = SimpleRangedAttack(damage=2, range=4, damage_type=Tags.Arcane, effect=Tags.Glassification, buff=GlassPetrifyBuff, buff_duration=1)
	glassbolt.name = "Glassification Bolt"

	unit.spells = [HealAlly(heal=7, range=6), glassbolt]

	unit.tags.append(Tags.Glass)
	return unit

def FaeryIce():
	unit = Faery()
	unit.name = "Ice Faery"
	unit.asset_name = "faery_ice"

	icebolt = SimpleRangedAttack(damage=2, range=4, damage_type=Tags.Ice, buff=FrozenBuff, buff_duration=1)
	icebolt.name = "Freezing Bolt"

	unit.spells = [HealAlly(heal=7, range=6), icebolt]
	unit.tags.append(Tags.Ice)
	unit.resists[Tags.Ice] = 100
	return unit

def Faery():
	unit = Unit()
	unit.name = "Faery"
	unit.asset_name = 'evil_faery'
	unit.flying = True
	unit.max_hp = 9
	unit.shields = 1
	unit.buffs.append(TeleportyBuff(chance=.5))
	unit.spells.append(HealAlly(heal=7, range=6))
	unit.spells.append(SimpleRangedAttack(damage=2, range=4, damage_type=Tags.Arcane))
	unit.tags = [Tags.Nature, Tags.Arcane, Tags.Living]
	unit.resists[Tags.Arcane] = 50
	return unit

def HellHound():
	unit = Unit()
	unit.name = "Hell Hound"
	unit.max_hp = 19
	unit.resists[Tags.Fire] = 100
	unit.resists[Tags.Ice] = -50
	unit.resists[Tags.Dark] = 50
	unit.spells.append(SimpleMeleeAttack(damage=6, damage_type=Tags.Fire))
	unit.spells.append(LeapAttack(damage=6, damage_type=Tags.Fire, range=4))
	unit.buffs.append(Thorns(4, Tags.Fire))
	unit.tags = [Tags.Demon, Tags.Fire]
	return unit

def IceHound():
	unit = Unit()
	unit.name = "Ice Hound"
	unit.max_hp = 19
	unit.resists[Tags.Ice] = 100
	unit.resists[Tags.Dark] = 50
	unit.spells.append(SimpleMeleeAttack(damage=6, damage_type=Tags.Ice))
	unit.spells.append(LeapAttack(damage=6, damage_type=Tags.Ice, range=4))
	unit.buffs.append(Thorns(4, Tags.Ice))
	unit.tags = [Tags.Demon, Tags.Ice]
	return unit

def Minotaur():
	unit = Unit()
	unit.name = "Minotaur"
	unit.max_hp = 45
	unit.spells.append(SimpleMeleeAttack(damage=12, trample=True))
	unit.spells.append(LeapAttack(damage=12, damage_type=Tags.Physical, range=6, is_leap=False))
	unit.tags = [Tags.Living]
	return unit


class BullCleave(Spell):

	def on_init(self):
		self.name = "Thrashing Horns"
		self.description = "Hits enemies in an arc"
		self.range = 1.5
		self.melee = True
		self.can_target_self = False

		self.damage = 30
		self.damage_type = [Tags.Physical]

	def get_impacted_tiles(self, x, y):
		ball = self.caster.level.get_points_in_ball(x, y, 1, diag=True)
		aoe = [p for p in ball if 1 <= distance(p, self.caster, diag=True) < 2]
		return aoe

	def cast(self, x, y):
		for p in self.get_impacted_tiles(x, y):
			unit = self.caster.level.get_unit_at(p.x, p.y)
			if unit and not are_hostile(self.caster, unit): continue
			self.caster.level.deal_damage(p.x, p.y, self.get_stat('damage'), Tags.Physical, self)
			yield

def GoldenBull():
	unit = Minotaur()
	unit.name = "Minos, The Golden Bull"
	unit.asset_name = "minotaur_gilded"

	unit.max_hp = 960

	unit.tags = [Tags.Living, Tags.Metallic]

	for s in unit.spells: s.damage *= 3
	unit.spells[0] = BullCleave()

	unit.quick_move = True

	unit.resists[Tags.Dark] = 75
	unit.resists[Tags.Holy] = 75

	return unit

class CockatriceGaze(Spell):

	def __init__(self):
		Spell.__init__(self)
		self.name = "Stone Gaze"
		self.range = 8
		self.cool_down = 10

	def cast(self, x, y):
		start = Point(self.caster.x, self.caster.y)
		target = Point(x, y)

		for point in Bolt(self.caster.level, start, target):
			self.caster.level.flash(point.x, point.y, Tags.Petrification.color)
			yield

		unit = self.caster.level.get_unit_at(x, y)
		unit.apply_buff(PetrifyBuff(), 3)
		yield

	def get_description(self):
		return "Petrifies for 3 turns"

def Cockatrice():
	unit = Unit()
	unit.name = "Cockatrice"
	unit.max_hp = 55
	peck = SimpleMeleeAttack(damage=12, buff=BlindBuff, buff_duration=6)
	peck.name = "Peck"
	unit.spells.append(peck)
	unit.spells.append(CockatriceGaze())
	
	unit.flying = True

	unit.resists[Tags.Arcane] = 50
	unit.resists[Tags.Physical] = 50
	unit.resists[Tags.Lightning] = -100
	
	unit.tags = [Tags.Arcane, Tags.Living]
	return unit

def VoidRift():

	unit = Unit()
	unit.name = "Void Rift"
	unit.max_hp = 30
	unit.stationary = True
	unit.buffs.append(GeneratorBuff(VoidBomber, .2))
	unit.buffs.append(TeleportyBuff(chance=.1, radius=8))
	unit.spells.append(SimpleRangedAttack(damage=5, range=7, damage_type=Tags.Arcane))
	unit.resists[Tags.Arcane] = 100
	unit.resists[Tags.Physical] = 50
	unit.tags = [Tags.Arcane]
	return unit

def FlameRift():

	unit = Unit()
	unit.name = "Flame Rift"
	unit.max_hp = 30
	unit.stationary = True
	unit.buffs.append(GeneratorBuff(FireBomber, .2))
	unit.buffs.append(TeleportyBuff(chance=.1, radius=8))
	unit.spells.append(SimpleRangedAttack(damage=5, range=7, damage_type=Tags.Fire))
	unit.resists[Tags.Fire] = 100
	unit.resists[Tags.Ice] = -100
	unit.resists[Tags.Arcane] = 50
	unit.resists[Tags.Physical] = 50
	unit.tags = [Tags.Arcane, Tags.Fire]
	return unit

def IceRift():
	unit = Unit()
	unit.name = "Ice Rift"
	unit.max_hp = 30
	unit.stationary = True
	unit.buffs.append(GeneratorBuff(IceBomber, .2))
	unit.buffs.append(TeleportyBuff(chance=.1, radius=8))
	unit.spells.append(SimpleRangedAttack(damage=5, range=7, damage_type=Tags.Ice))
	unit.resists[Tags.Ice] = 100
	unit.resists[Tags.Fire] = -100
	unit.resists[Tags.Arcane] = 50
	unit.resists[Tags.Physical] = 50
	unit.tags = [Tags.Arcane, Tags.Ice]
	return unit

def ButterflyDemon():
	unit = Unit()
	unit.name = "Butterfly Demon"
	unit.flying = True
	unit.max_hp = 50
	unit.shields = 3
	unit.resists[Tags.Arcane] = 100
	unit.resists[Tags.Lightning] = 100
	unit.resists[Tags.Ice] = -50
	unit.buffs.append(TeleportyBuff())
	unit.spells.append(SimpleRangedAttack(name="Void Beam", damage=9, damage_type=Tags.Arcane, range=6, beam=True, melt=True, cool_down=3))
	unit.spells.append(SimpleRangedAttack(name="Lightning Beam", damage=9, damage_type=Tags.Lightning, range=6, beam=True, cool_down=2))
	unit.tags = [Tags.Demon, Tags.Nature, Tags.Arcane, Tags.Lightning]
	return unit

class ToadHop(Spell):

	def on_init(self):
		self.name = "Frog Hop"
		self.description = "Leaps to a random tile in line of sight within 4 tiles"
		self.range = 0
		self.cool_down = 4

	def cast(self, x, y):
		target = get_random_teleport_destination(self.caster, 4, requires_los=True)
		if not target: return
		caster = self.caster
		level = caster.level
		path = level.get_points_in_line(caster, target, find_clear=True)
		for point in path: level.leap_effect(point.x, point.y, Tags.Physical.color, caster); yield
		level.act_move(caster, target.x, target.y, teleport=True)
		yield

def HornedToad():

	unit = Unit()
	unit.name = 'Horned Toad'
	unit.max_hp = 18

	tongue_attack = PullAttack(damage=2, range=3, color=Tags.Tongue.color)
	tongue_attack.name = "Tongue Lash"
	unit.spells.append(ToadHop())
	unit.spells.append(SimpleMeleeAttack(damage=8))
	unit.spells.append(tongue_attack)
	unit.tags = [Tags.Living, Tags.Nature]
	unit.resists[Tags.Ice] = -50
	return unit

def GiantToad():

	unit = Unit()
	unit.name = 'Towering Toadbeast'
	unit.asset_name = 'big_toad'
	unit.max_hp = 85

	unit.buffs.append(TrollRegenBuff())

	tongue_attack = PullAttack(damage=3, range=4, color=Tags.Tongue.color)
	tongue_attack.name = "Tongue Lash"
	unit.spells.append(ToadHop())
	unit.spells.append(SimpleMeleeAttack(damage=15, trample=True))
	unit.spells.append(tongue_attack)
	unit.tags = [Tags.Living, Tags.Nature]
	unit.resists[Tags.Ice] = -50
	return unit

def ToadKnight():
	u = Unit()
	u.name = "Toad Knight"
	u.max_hp = 145
	u.tags = [Tags.Living, Tags.Nature, Tags.Metallic]
	u.resists[Tags.Ice] = -50

	melee = SimpleMeleeAttack(damage=18, buff=BleedBuff, buff_duration=6)
	melee.name = "Blade Tongue"

	u.spells = [melee, ToadHop()]
	u.buffs = [Thorns(12), TrollRegenBuff()]
	return u

def FlameToad():

	unit = Unit()
	unit.name = 'Flame Toad'
	unit.max_hp = 45

	unit.resists[Tags.Fire] = 75
	unit.resists[Tags.Ice] = -100
	
	unit.spells.append(ToadHop())
	unit.spells.append(SimpleRangedAttack(name="Fireball", damage=7, range=4, radius=1, damage_type=Tags.Fire))
	unit.tags = [Tags.Living, Tags.Fire, Tags.Nature]
	return unit

def VoidToad():

	unit = Unit()
	unit.name = 'Void Toad'
	
	unit.max_hp = 45
	unit.shields = 2

	unit.resists[Tags.Arcane] = 75
	unit.resists[Tags.Ice] = -50

	unit.spells.append(ToadHop())
	voidlick = SimpleRangedAttack(name="Void Lick", damage=7, range=3, damage_type=Tags.Arcane, beam=True, melt=True)
	voidlick.onhit = lambda caster, target: pull(target, caster, 1)
	voidlick.requires_los = False
	voidlick.description = "Beam attack\nPulls target towards the caster\nMelts walls"
	unit.spells.append(voidlick)

	unit.tags = [Tags.Living, Tags.Arcane, Tags.Nature]
	return unit

class ToadPriestTorrent(Spell):

	def on_init(self):
		self.name = "Water Blast"
		self.damage = 10
		self.beam_radius = 1.5
		self.beam_width = 3
		self.range = 6
		self.duration = 3
		self.damage_type = Tags.Physical
		self.requires_los = False
		self.cool_down = 3

	def get_description(self):
		return ("Damages and pushes away units in a wide beam\n"
				"Applies 3 turns of soaked\n"
				"Melts walls\n")

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		deal_damage = level.deal_damage
		tiles = level.tiles
		make_floor = level.make_floor
		show_effect = level.show_effect

		damage = self.get_stat('damage')
		duration = self.get_stat('duration')

		center_beam = level.get_points_in_line(caster, Point(x, y), find_clear=False)[1+caster.radius:]
		outer_beam = []

		for p in center_beam:
			for q in level.get_points_in_ball(p.x, p.y, self.beam_radius): # grab the points around the centerbeam
				if level.get_unit_at(q.x, q.y) == caster: continue # dont let caster hurt themselves
				if (q not in center_beam) and (q not in outer_beam): outer_beam.append(q) # don't include already captured pts

		wide_beam = center_beam + outer_beam

		for p in wide_beam:
			deal_damage(p.x, p.y, damage, Tags.Physical, self, flash=False)
			if tiles[p.x][p.y].is_wall(): make_floor(p.x, p.y)
			show_effect(p.x, p.y, Tags.Water)
			u = level.get_unit_at(p.x, p.y)
			if u:
				u.apply_buff(SoakedBuff(), duration)
				push(u, caster, 1)

		yield

def ToadPriest():
	unit = HornedToad()
	unit.max_hp *= 10

	unit.name = "Toad Priest"
	unit.asset_name = "toad_priest"

	tongue = PullAttack(damage=6, range=5, color=Tags.Tongue.color)
	tongue.name = "Tongue Lash"

	unit.spells = [ToadPriestTorrent(), tongue, ToadHop()]
	return unit

class SpiderBuff(Buff):

	def on_advance(self):
		# Do not make webs if there are no enemy units
		if not any(are_hostile(u, self.owner) for u in self.owner.level.units): return
		spawn_webs(self.owner)

	def get_tooltip(self):
		return "Weaves webs each turn"

def QueenMonster(base_spawner):
	unit = base_spawner()
	unit.name = "%s Queen" % unit.name
	unit.asset_name += '_mother'
	unit.base = base_spawner

	unit.max_hp = 96
	if unit.shields: unit.shields += 2

	melee = unit.get_spell(SimpleMeleeAttack)
	if melee: melee.damage *= 8

	def baby():
		u = BabyMonster(base_spawner)
		return u

	unit.apply_buff(GeneratorBuff(spawn_func=baby, spawn_chance=.1, global_summon=False, num_summons=2))

	return unit

def BabyMonster(base_spawner):
	unit = base_spawner()
	unit.name = "Baby %s" % unit.name
	unit.asset_name += '_child'
	unit.max_hp = 3
	unit.is_coward = True
	unit.buffs.append(MatureInto(base_spawner, 8)) # mature into not passing on minion buffs?
	return unit

def BabySpider():
	return BabyMonster(GiantSpider)

def GiantSpiderQueen():
	return QueenMonster(GiantSpider)

def GiantSpider():

	unit = Unit()

	unit.name = "Giant Spider"
	unit.asset_name = "dark_spider"
	unit.max_hp = 14

	unit.buffs.append(SpiderBuff())
	unit.spells.append(SimpleMeleeAttack(2, buff=Poison, buff_duration=10))

	unit.tags = [Tags.Spider, Tags.Living, Tags.Nature]
	unit.resists[Tags.Ice] = -50
	return unit

def BabySteelSpider():
	return BabyMonster(SteelSpider)

def SteelSpiderQueen():
	return QueenMonster(SteelSpider)

def BabyPhaseSpider():
	return BabyMonster(PhaseSpider)

def PhaseSpiderQueen():
	return QueenMonster(PhaseSpider)

def SteelSpider():

	unit = Unit()

	unit.name = "Steel Spider"
	unit.asset_name = "steel_spider"
	unit.max_hp = 14

	unit.buffs.append(SpiderBuff())
	unit.spells.append(SimpleMeleeAttack(6, buff=Poison, buff_duration=10))

	unit.tags = [Tags.Spider, Tags.Construct, Tags.Metallic]

	return unit

def PhaseSpider():

	unit = Unit()

	unit.name = "Aether Spider"
	unit.asset_name = "aether_spider"
	unit.max_hp = 14
	unit.shields = 1

	unit.resists[Tags.Arcane] = 100
	unit.resists[Tags.Physical] = 75
	unit.resists[Tags.Ice] = -50

	unit.buffs.append(SpiderBuff())
	unit.buffs.append(TeleportyBuff(chance=.5, radius=7))
	unit.spells.append(SimpleMeleeAttack(4, damage_type=Tags.Arcane, buff=Poison, buff_duration=10))

	unit.tags = [Tags.Spider, Tags.Living, Tags.Arcane]

	return unit

def ArachnidWizard():
	unit = Unit()
	unit.name = "Arachnid Wizard"

	unit.max_hp = 88
	unit.shields = 8

	unit.resists[Tags.Arcane] = 100
	unit.resists[Tags.Physical] = 75

	from Spells import PrisonOfThorns
	thorns = PrisonOfThorns()
	thorns.tags = []
	thorns.max_charges = 0
	thorns.cool_down = 13
	thorns.description = "Surround targets with Fae Thorns"
	thorns.minion_damage = 1

	bite = SimpleMeleeAttack(4, damage_type=Tags.Arcane, buff=Poison, buff_duration=10)
	bite.name = "Spider Bite"

	spit = SimpleRangedAttack(name="Neurotoxin", damage=8, damage_type=Tags.Arcane, range=8, cool_down=3, onhit=drain_spell_charges, onhit_description="Drains a spell charge", buff=Poison, buff_duration=10)

	unit.spells = [thorns, spit, bite]

	unit.tags = [Tags.Spider, Tags.Living, Tags.Arcane]

	unit.buffs.append(SpiderBuff())
	unit.buffs.append(TeleportyBuff(chance=.75, radius=7))
	unit.is_wizard = True

	return unit

def BloodKnight():

	unit = Unit()
	unit.name = "Blood Knight"
	unit.tags = [Tags.Blood, Tags.Living]

	unit.max_hp = 200

	unit.resists[Tags.Dark] = 50

	from Spells import LifedrainSpell
	life_drain = LifedrainSpell()
	life_drain.tags = []
	life_drain.max_charges = 0
	life_drain.cool_down = 6
	life_drain.duration = 3
	life_drain.hp_cost = 0
	life_drain.range = 3
	unit.spells.append(life_drain)

	melee = SimpleMeleeAttack(damage=8, damage_type=Tags.Physical, attacks=2, drain=True) # dual sabers?
	unit.spells.append(melee)

	growth = MonsterGrowthBuff(name="Blood Amalgam", color=Tags.Blood.color, event_type=EventOnDamaged, health_growth=1, damage_growth=1)
	unit.buffs.append(growth)

	thorns = Thorns(1, Tags.Dark)
	unit.buffs.append(thorns)

	return unit

def VoidKnight():

	unit = Unit()

	unit.name = "Void Knight"

	unit.max_hp = 200
	unit.shields = 3

	unit.resists[Tags.Physical] = 50
	unit.resists[Tags.Arcane] = 100
	unit.resists[Tags.Dark] = 50

	melee = SimpleMeleeAttack(damage=8, damage_type=Tags.Arcane, onhit=lambda caster, target: randomly_teleport(target, 3))
	unit.spells.append(melee)
	melee.get_description = lambda : "Teleports the target up to 3 tiles"

	charge = LeapAttack(damage=16, damage_type=Tags.Arcane, range=3, is_ghost=True)
	charge.name = "Aether Charge"
	charge.get_description = lambda : "Ignores obstacles"
	unit.spells.append(charge)
	
	unit.tags = [Tags.Arcane, Tags.Living]
	return unit

def ChaosKnight():

	unit = Unit()

	unit.name = "Chaos Knight"

	unit.max_hp = 200

	unit.resists[Tags.Physical] = 75
	unit.resists[Tags.Fire] = 75
	unit.resists[Tags.Lightning] = 75

	# Melee attack with extra chaos damage
	melee = SimpleMeleeAttack(damage=8, damage_type=[Tags.Physical, Tags.Lightning, Tags.Fire])

	chaosball = SimpleRangedAttack(damage=16, radius=2, range=6, damage_type=[Tags.Fire, Tags.Lightning, Tags.Physical])
	chaosball.name = "Chaos Ball"
	chaosball.cool_down = 4

	unit.spells.append(chaosball)
	unit.spells.append(melee)

	unit.tags = [Tags.Fire, Tags.Lightning, Tags.Living]

	return unit

def StormKnight():

	unit = Unit()

	unit.name = "Storm Knight"

	unit.max_hp = 200

	unit.resists[Tags.Physical] = 50
	unit.resists[Tags.Lightning] = 75
	unit.resists[Tags.Ice] = 100

	leap = LeapAttack(damage=8, range=7, damage_type=Tags.Lightning)
	leap.name = "Flash of Lightning"
	leap.cool_down = 7
	unit.spells.append(leap)

	def freeze(caster, target): target.apply_buff(FrozenBuff(), 2)
	frost = SimpleBurst(damage=16, radius=2, damage_type=Tags.Ice, onhit=freeze)
	frost.name = "Frost"
	frost.description = "Inflicts [frozen] for 2 turns"
	frost.cool_down = 5
	unit.spells.append(frost)

	def make_cloud(caster, target):
		points = [p for p in target.level.get_points_in_ball(target.x, target.y, 1, diag=True) if not target.level.tiles[p.x][p.y].cloud and distance(caster, p) > 0]
		if points:
			point = random.choice(points)
			cloud = random.choice([StormCloud(caster), BlizzardCloud(caster)])
			target.level.add_obj(cloud, point.x, point.y)

	melee = SimpleMeleeAttack(damage=6, onhit=make_cloud)
	melee.name = "Storm Strike"
	melee.description = "Creates Thunderstorms and Blizzards"
	unit.spells.append(melee)

	unit.tags = [Tags.Ice, Tags.Lightning, Tags.Living]
	
	return unit

def TwilightKnight():
	unit = Unit()
	unit.name = "Twilight Knight"

	unit.max_hp = 200
	unit.resists[Tags.Dark] = 100
	unit.resists[Tags.Holy] = 100

	melee = SimpleMeleeAttack(damage=11, damage_type=Tags.Dark, buff=NecrosisBuff, buff_duration=10)
	melee.name = "Wight Blade"

	blast = FalseProphetHolyBlast()
	blast.cool_down = 3
	blast.damage = 14

	unit.spells = [blast, melee]

	unit.tags = [Tags.Dark, Tags.Holy, Tags.Living]

	unit.buffs.append(ReincarnationBuff(1))
	return unit

def EnergyKnight():
	unit = Unit()
	unit.name = "Energy Knight"

	unit.max_hp = 200
	unit.shields = 6

	unit.resists[Tags.Arcane] = 100
	unit.resists[Tags.Lightning] = 100

	melee = SimpleMeleeAttack(damage=6, damage_type=Tags.Arcane, onhit=lambda caster, target: randomly_teleport(target, 5))
	unit.spells.append(melee)
	melee.description = "Teleports the target up to 5 tiles"

	leap = LeapAttack(damage=10, range=7, damage_type=Tags.Lightning)
	leap.name = "Flash of Lightning"
	leap.cool_down = 7
	unit.spells.append(leap)


	unit.tags = [Tags.Lightning, Tags.Arcane, Tags.Living]
	return unit


def Lamasu():

	unit = Unit()
	unit.name = "Lamasu"
	unit.max_hp = 200
	unit.shields = 3

	unit.resists[Tags.Physical] = 50
	unit.resists[Tags.Arcane] = 50
	unit.resists[Tags.Dark] = 50
	unit.resists[Tags.Holy] = 75

	unit.flying = True

	unit.spells.append(SimpleMeleeAttack(damage=7))
	leap = LeapAttack(damage=7, range=4)
	leap.name = "Charge"
	unit.spells.append(leap)
	unit.buffs.append(HealAuraBuff(heal=5, radius=5))

	unit.tags = [Tags.Nature, Tags.Living, Tags.Holy]

	return unit

class LamasuCorruptionAura(DamageAuraBuff):

	def __init__(self):
		DamageAuraBuff.__init__(self, damage=3, damage_type=[Tags.Dark, Tags.Poison], radius=3, custom_name="Corruption Aura", friendly_fire=True)
		self.stack_type = STACK_INTENSITY
		self.buff_type = BUFF_TYPE_CURSE
		self.color = Tags.Dark.color

def CorruptedLamasu():

	unit = Unit()
	unit.name = "Corrupted Lamasu"
	unit.asset_name = 'lamasu_corrupted'
	unit.max_hp = 400
	unit.shields = 6

	unit.resists[Tags.Arcane] = 75
	unit.resists[Tags.Dark] = 100
	unit.resists[Tags.Poison] = 100
	unit.resists[Tags.Holy] = -50

	unit.flying = True

	def inflict_corruption(caster, target): target.apply_buff(LamasuCorruptionAura())
	melee = SimpleMeleeAttack(damage=12, onhit=inflict_corruption, onhit_description="On hit, inflict a stacking aura that deals 3 [Dark] or [Poison] damage within 3 tiles each turn", drain=True)
	melee.name = "Corrupted Bite"

	leap = LeapAttack(damage=12, range=5)
	leap.name = "Charge"

	unit.spells = [melee, leap]

	unit.buffs = [LamasuCorruptionAura()]

	unit.tags = [Tags.Nature, Tags.Undead, Tags.Dark]

	return unit

class TurtleDefenseBonus(Stun):

	def on_init(self):
		Stun.on_init(self)
		self.resists[Tags.Physical] = 50
		self.resists[Tags.Fire] = 50
		self.resists[Tags.Lightning] = 50
		self.name = "Inside Shell"

class TurtleBuff(Buff):

	def on_applied(self, owner):
		self.buff_type = BUFF_TYPE_BLESS
		self.owner_triggers[EventOnDamaged] = self.on_damaged

	def on_damaged(self, event):
		if not self.owner.is_stunned():
			self.owner.apply_buff(TurtleDefenseBonus(), 3)

	def get_tooltip(self):
		return "When damaged, withdraw into its shell and gain 50% [Physical], [Fire], and [Lightning] resist"

def NightmareTurtle():

	unit = Unit()

	unit.name = "Nightmare Turtle"

	unit.max_hp = 295

	unit.resists[Tags.Dark] = 75
	unit.resists[Tags.Arcane] = 50

	aura = DamageAuraBuff(damage=2, damage_type=[Tags.Arcane, Tags.Dark], radius=5)
	aura.name = "Nightmare Aura"
	unit.buffs.append(aura)
	unit.buffs.append(TurtleBuff())

	unit.spells.append(SimpleMeleeAttack(damage=30))
	unit.tags = [Tags.Dark, Tags.Nature, Tags.Arcane, Tags.Demon]
	return unit

def Wolf():
	wolf = Unit()
	wolf.max_hp = 15
	wolf.name = "Wolf"
	wolf.spells.append(SimpleMeleeAttack(4))
	wolf.tags = [Tags.Living, Tags.Nature]
	wolf.spells.append(LeapAttack(damage=4, damage_type=Tags.Physical, range=3))
	return wolf

def VampireBat():
	unit = Unit()
	unit.name = "Vampire Bat"
	unit.asset_name = "bat_vampire"
	unit.max_hp = 4
	unit.flying = True
	
	unit.resists[Tags.Dark] = 100
	unit.tags = [Tags.Undead, Tags.Dark, Tags.Blood]
	unit.is_coward = True

	unit.buffs.append(MatureInto(Vampire, 20))
	return unit

def Vampire():

	unit = Unit()
	unit.name = "Vampire"

	unit.resists[Tags.Fire] = -100

	unit.max_hp = 32
	unit.flying = True

	melee = SimpleMeleeAttack(damage=7, damage_type=Tags.Dark, drain=True)
	melee.name = "Drain Life"
	unit.spells.append(melee)

	unit.tags = [Tags.Undead, Tags.Dark, Tags.Blood]
	unit.buffs.append(RespawnAs(VampireBat))
	return unit

class VampireCountBuff(Buff):

	def on_init(self):
		self.name = "Blood Tax"
		self.description = "When an enemy takes [Dark] damage, heal [4 HP:heal]"
		self.global_triggers[EventOnDamaged] = self.on_damaged

	def on_damaged(self, evt):
		if are_hostile(self.owner, evt.unit) and evt.damage_type == Tags.Dark:
			self.owner.deal_damage(-4, Tags.Heal, self)

def CountBat():
	unit = Bat()
	unit.name = "Vampire Count Bat"
	unit.asset_name = "bat_vampire_count"
	unit.is_coward = True
	unit.buffs.append(MatureInto(VampireCount, 20))
	return unit

def bat_or_ghost():
	unit = random.choice([Bat(), Ghost()])
	unit.turns_to_death = random.randint(5, 9)
	return unit

def VampireCount():
	unit = Vampire()
	unit.name = "Vampire Count"
	unit.asset_name = "vampire_count"
	unit.max_hp = 1260

	def raise_vamp(caster, target):
		if target.is_alive(): return
		if Tags.Living not in target.tags: return
		caster.level.summon(caster, Vampire(), target)


	melee = SimpleMeleeAttack(damage=11, damage_type=Tags.Dark, drain=True, onhit=raise_vamp, onhit_description="Slain [Living] units are raised as Vampires")
	melee.name = "Drain Life"

	unit.buffs.append(VampireCountBuff())
	unit.spells= [melee]

	unit.get_buff(RespawnAs).spawner = CountBat
	return unit

def BoneKnight():
	unit = Unit()
	unit.name = "Bone Knight"
	unit.max_hp = 40
	unit.shields = 1
	unit.tags = [Tags.Undead, Tags.Dark]
	melee = SimpleMeleeAttack(damage=9, damage_type=Tags.Physical, buff=BleedBuff, buff_duration=3)
	melee.name = "Bone Blade"
	unit.spells.append(melee)
	unit.buffs.append(Thorns(damage=1, dtype=Tags.Physical))
	return unit

def BoneKnightArcher():
	u = Unit()
	u.name = "Bone Knight Archer"
	u.max_hp = 25
	u.tags = [Tags.Undead, Tags.Dark]
	arrow = SimpleRangedAttack(name='Bone Arrow', damage=3, damage_type=Tags.Physical, range=6, proj_name="bone_arrow", buff=BleedBuff, buff_duration=3)
	u.spells.append(arrow)
	return u

class DeathEaterBuff(Buff):

	def on_init(self):
		self.name = "Death Eater"
		self.color = Tags.Dark.color
		self.description = "When an [Undead] ally dies, gain a stack of Bloodrage"
		self.global_triggers[EventOnDeath] = self.on_death

	def on_death(self, evt):
		if Tags.Undead not in evt.unit.tags: return
		if are_hostile(evt.unit, self.owner): return
		if evt.unit == self.owner: return
		self.owner.level.show_beam(evt.unit, self.owner, Tags.Dark, minor=True)
		self.owner.apply_buff(BloodrageBuff(1))

def BoneKing():
	u = Unit()
	u.name = "Bone King"
	u.max_hp = 260
	u.tags = [Tags.Undead, Tags.Dark]

	melee = SimpleMeleeAttack(damage=9, damage_type=Tags.Physical, buff=BleedBuff, buff_duration=3, attacks=2)
	melee.name = "Bone Blades"

	summon = SimpleSummon(BoneKnightArcher, num_summons=3, cool_down=12)
	summon.name = "Call Reinforcements"

	u.spells = [summon, melee]

	u.buffs = [DeathEaterBuff()]

	add_tooltip(u, BloodrageBuff(1))

	return u


class WizardWheel(Spell):

	def on_init(self):
		self.name = "Wheel of Death"
		self.damage = 27
		self.damage_type = Tags.Dark
		self.range = 0
		self.cool_down = 27
		self.description = "Hits a random enemy anywhere on the map"

	def cast(self, x, y):
		delay = 15
		for i in range(delay):
			yield

		targets = [u for u in self.caster.level.units if self.caster.level.are_hostile(self.caster, u)]
		if targets:
			target = random.choice(targets)
			target.deal_damage(self.get_stat('damage'), self.damage_type, self)

		for i in range(delay):
			yield

class WizardSwap(Spell):

	def __init__(self, tag):
		self.tag = tag
		Spell.__init__(self)

	def on_init(self):
		self.name = "%s Swap" % self.tag.name
		self.description = ("Swap places with a random {tag} unit", {'tag': formatted_tag(self.tag)})
		self.cool_down = 18
		self.target_allies = True

	def can_threaten(self, x, y):
		return False

	def can_swap(self, u):
		caster = self.caster
		if u == caster: # don't randomly select themselves
			return False
		if self.tag not in u.tags: # early out tags first
			return False
		if u.radius: # don't swap with giants, unnecessarily complex
			return False

		# Ensure the caster can be at target's location
		if not caster.level.can_move(caster, u.x, u.y, teleport=True, force_swap=True):
			return False

		# Ensure that the target can be where the caster is
		if not caster.level.can_move(u, caster.x, caster.y, teleport=True, force_swap=True):
			return False

		return True

	def can_cast(self, x, y):
		return any(self.can_swap(u) for u in self.caster.level.units)

	def cast_instant(self, x, y):
		target = random.choice([u for u in self.caster.level.units if self.can_swap(u)])
		
		path = self.caster.level.get_points_in_line(self.caster, target, find_clear=True)
		for i in range(len(path)):
			p1 = path[i]
			p2 = path[-i]
			for p in [p1, p2]:
				self.caster.level.show_effect(p.x, p.y, Tags.Translocation, minor=True)

		self.caster.level.act_move(self.caster, target.x, target.y, teleport=True, force_swap=True)

		self.caster.level.show_effect(target.x, target.y, Tags.Translocation)
		self.caster.level.show_effect(self.caster.x, self.caster.y, Tags.Translocation)


def RandomShambler():
	hp = random.randint(8, 15)
	return BoneShambler(hp)

def BoneWizard():
	unit = Unit()
	unit.name = "Bone Wizard"
	unit.max_hp = 54
	unit.shields = 1

	swap = WizardSwap(Tags.Undead)
	swap.name = "Bone Swap"
	swap.cool_down = 10

	bones = SimpleSummon(RandomShambler, num_summons=16, cool_down=32, global_summon=True)
	bones.name = "Raise Bones"

	knights = SimpleSummon(BoneKnight, num_summons=2, cool_down=16)
	knights.name = "Assemble Bone Knight"

	def make_skeleton(caster, target):
		raise_skeleton(caster, target)
		yield

	def try_raise(caster, target):
		if not target.is_alive():
			caster.level.queue_spell(make_skeleton(caster, target))

	dbolt = SimpleRangedAttack(damage=7, range=6, damage_type=Tags.Dark, onhit=try_raise)
	dbolt.name = "Death Bolt"
	dbolt.description = "Slain targets become Skeletons"

	unit.spells = [bones, knights, swap, dbolt]

	unit.resists[Tags.Dark] = 100
	unit.resists[Tags.Arcane] = 50
	unit.resists[Tags.Physical] = 50

	unit.tags = [Tags.Dark, Tags.Undead]
	unit.is_wizard = True

	return unit


class MushboomBuff(Buff):

	def __init__(self, buff, apply_duration, effect_tag=Tags.Poison):
		self.buff = buff
		self.apply_duration = apply_duration
		self.effect_tag = effect_tag
		Buff.__init__(self)

	def on_init(self):
		self.owner_triggers[EventOnDeath] = self.on_death
		self.description = ("On death, apply {buff} to adjacent units for {duration} turns",
							{'buff': self.buff().name, 'duration': self.apply_duration})
		self.name = "Mushboom Burst"
		
	def on_death(self, evt):
		self.owner.level.queue_spell(self.explode(self.owner.level, self.owner.x, self.owner.y))

	def explode(self, level, x, y):
		for p in level.get_points_in_rect(x - 1, y - 1, x + 1, y + 1):
			level.show_effect(p.x, p.y, self.effect_tag)
			unit = level.get_unit_at(p.x, p.y)
			if unit:
				unit.apply_buff(self.buff(), self.apply_duration)

		yield

class FalseProphetHolyBlast(Spell):

	def on_init(self):
		self.name = "Heavenly Blast"
		self.description = "Beam attack\nHeals allies"
		self.radius = 1
		self.range = 6
		self.damage = 8
		self.damage_type = Tags.Holy

	def can_harm(self, target_unit):
		if not are_hostile(self.caster, target_unit): return True
		return Spell.can_harm(self, target_unit)

	def get_ai_target(self):
		enemy = self.get_corner_target(1)
		if enemy: return enemy
		else:
			allies = [u for u in self.caster.level.get_units_in_ball(self.caster, self.get_stat('range')) if u != self.caster and not are_hostile(self.caster, u)]
			allies = [u for u in allies if self.caster.level.can_see(self.caster.x, self.caster.y, u.x, u.y)]
			allies = [u for u in allies if u.can_be_healed() and self.can_cast(u.x, u.y)]
			if allies: return random.choice(allies)
		return None

	def cast(self, x, y):
		target = Point(x, y)

		def deal_damage(point):
			unit = self.caster.level.get_unit_at(point.x, point.y)
			if unit and not are_hostile(unit, self.caster) and not unit == self.caster:
				unit.deal_damage(-self.get_stat('damage'), Tags.Heal, self)
			elif unit == self.caster: pass
			else: self.caster.level.deal_damage(point.x, point.y, self.get_stat('damage'), Tags.Holy, self)

		points_hit = set()
		for point in Bolt(self.caster.level, self.caster, target):
			deal_damage(point)
			points_hit.add(point)
			yield

		stagenum = 0
		for stage in Burst(self.caster.level, target, self.get_stat('radius')):
			for point in stage:
				if point in points_hit: continue
				deal_damage(point)

			stagenum += 1
			for i in range(3): yield

def FalseProphet():

	unit = Unit()
	unit.name = "False Prophet"

	unit.max_hp = 48

	unit.spells.append(FalseProphetHolyBlast())
	unit.spells.append(SimpleSummon(Cultist, num_summons=2, cool_down=8))

	unit.buffs.append(ReincarnationBuff(1))

	unit.resists[Tags.Holy] = 100
	unit.resists[Tags.Fire] = 50

	unit.tags = [Tags.Living, Tags.Holy]
	return unit

class ArchonHolyBeam(Spell):

	def on_init(self):
		self.name = "Archon Beam"
		self.description = "Beam attack\nHeals and shields allies"
		self.damage_type = [Tags.Fire, Tags.Holy]
		self.damage = 14
		self.range = 7

	def cast(self, x, y):
		caster = self.caster
		dmg = self.get_stat('damage')
		dtypes = self.damage_type
		for p in caster.level.get_points_in_line(caster, Point(x, y), find_clear=True)[1:]:
			unit = caster.level.get_unit_at(p.x, p.y)
			for dtype in dtypes:
				if unit and are_friendly(unit, caster): unit.add_shields(1); unit.heal(dmg, self)
				else: caster.level.deal_damage(p.x, p.y, dmg, dtype, self)
			yield


def ArchonPurifier():
	angel = Unit()
	angel.name = "Archon Purifier"
	angel.asset_name = 'archon_of_purity'
	angel.tags = [Tags.Holy]

	angel.max_hp = 77
	angel.shields = 12
	angel.flying = True

	angel.resists[Tags.Holy] = 100
	angel.resists[Tags.Fire] = 100

	beam = ArchonHolyBeam()
	angel.spells = [beam]

	aura = DamageAuraBuff(3, [Tags.Fire, Tags.Holy], 4, "Purifier Aura")
	angel.buffs = [aura]

	return angel

class AuraOfHaste(Buff):

	def on_init(self):
		self.name = "Aura of Haste"
		self.radius = 3
		self.color = Tags.Holy.color
		self.description = "Each turn, allies within 3 tiles take an extra turn\nDoes not affect Angelic Visitors"

	def on_advance(self):
		owner = self.owner
		targets = [u for u in owner.level.get_units_in_ball(owner, self.radius) if not are_hostile(owner, u) and u.name != owner.name]
		if not targets: return
		owner.level.queue_spell(self.force_turns(targets))

	def force_turns(self, targets):
		take_turn = self.owner.level.take_turn
		for t in targets:
			for _ in take_turn(t):
				yield

def AngelicVisitor():
	u = Unit()
	u.name = "Angelic Visitor"
	u.max_hp = 400
	u.tags = [Tags.Holy]
	u.flying = True

	u.resists[Tags.Holy] = 100
	u.resists[Tags.Fire] = 100
	u.resists[Tags.Physical] = 100
	u.resists[Tags.Poison] = 100
	u.resists[Tags.Dark] = -100

	blast = FalseProphetHolyBlast()
	blast.damage = 40
	u.spells = [blast]
	u.buffs = [AuraOfHaste()]

	return u



class AngelSong(Spell):

	def on_init(self):
		self.name = "Sing"
		self.description = "Heals [Living] and [Holy] units, damages [Undead], [Demon], and [Dark] units"
		self.radius = 4
		self.damage = 2
		self.range = 0
		self.friendly_fire = True
		self.salvation = False
		self.damage_type = [Tags.Fire, Tags.Holy]
		self.heal_tags = [Tags.Living, Tags.Holy]
		self.hurt_tags = [Tags.Dark, Tags.Undead, Tags.Demon]

	def cast_instant(self, x, y):
		d = self.get_stat('damage')
		c = self.caster
		ff = self.friendly_fire
		s = self.salvation
		for unit in c.level.get_units_in_ball(Point(x, y), self.radius):
			if unit.has_tags(self.heal_tags) and unit.cur_hp < unit.max_hp and (ff or are_friendly(c, unit)):
				if s and are_friendly(c, unit):
					curses = [b for b in unit.buffs if b.buff_type==BUFF_TYPE_CURSE]
					if curses: unit.remove_buff(random.choice(curses))
				unit.heal(d, self)
			if unit.has_tags(self.hurt_tags):
				if ff or are_hostile(unit, c): # hit everything on ff, if not ff hit if its an enemy
					unit.deal_damage(d, Tags.Fire, self)
					unit.deal_damage(d, Tags.Holy, self)

	def get_ai_target(self):
		c = self.caster
		ff = self.friendly_fire
		units = c.level.get_units_in_ball(c, self.radius)
		for unit in units:
			if unit.has_tags(self.heal_tags) and unit.cur_hp < unit.max_hp and (ff or are_friendly(c, unit)): return c
			if unit.has_tags(self.hurt_tags):
				if ff: return c # if friendly fire is on, hit em
				elif are_hostile(unit, c): return c # if it's off, check their team and cast if they're an enemy
				else: continue # otherwise skip
		return None

def AngelicSinger():
	angel = Unit()
	angel.name = "Angelic Singer"
	angel.max_hp = 12
	angel.shields = 2

	song = AngelSong()
	angel.spells.append(song)

	angel.flying = True
	angel.tags = [Tags.Holy]
	angel.resists[Tags.Holy] = 50
	angel.resists[Tags.Fire] = 50
	angel.resists[Tags.Dark] = 100
	return angel

class WailOfPain(Spell):

	def on_init(self):
		self.name = "Cacophony"
		self.range = 0
		self.radius = 6
		self.damage = 22
		self.cool_down = 7
		self.damage_type = [Tags.Dark]

	def get_description(self):
		return "Damages enemies in a burst around the caster"

	def can_threaten(self, x, y):
		return distance(self.caster, Point(x, y)) <= self.radius

	def cast_instant(self, x, y):
		damage = self.get_stat('damage')
		for p in self.caster.level.get_points_in_ball(self.caster.x, self.caster.y, self.radius):
			unit = self.caster.level.get_unit_at(p.x, p.y)
			if unit and are_friendly(self.caster, unit): continue
			if not self.caster.level.tiles[p.x][p.y].can_see: continue
			self.caster.level.deal_damage(p.x, p.y, damage, Tags.Dark, self)

def FallenAngel():
	angel = Unit()
	angel.name = "Fallen Angel"
	angel.max_hp = 400
	angel.shields = 2
	angel.flying = True


	shield_spell = ShieldSightSpell(4, 2)
	fire = SimpleRangedAttack(damage=14, damage_type=[Tags.Dark, Tags.Fire], range=4, radius=2)
	fire.name = "Hellfire"

	angel.spells.append(WailOfPain())
	angel.spells.append(shield_spell)
	angel.spells.append(fire)

	angel.resists[Tags.Dark] = 100
	angel.resists[Tags.Fire] = 50
	angel.resists[Tags.Holy] = 100

	angel.tags = [Tags.Demon, Tags.Holy]

	angel.buffs.append(ReincarnationBuff(2))

	return angel

def GreenMushboom():

	unit = Unit()
	unit.name = "Green Mushboom"
	unit.max_hp = 11

	spores = SimpleRangedAttack(name="Poison Puff", damage=1, damage_type=Tags.Poison, range=2, buff=Poison, buff_duration=4, cool_down=3)
	unit.spells.append(spores)
	
	unit.buffs.append(MushboomBuff(Poison, 12))

	unit.resists[Tags.Fire] = -50
	unit.resists[Tags.Ice] = -50
	unit.resists[Tags.Poison] = 100
	unit.tags = [Tags.Nature]

	return unit

def GreyMushboom():

	unit = Unit()
	unit.name = "Grey Mushboom"

	unit.asset_name = "mushboom_grey"

	unit.max_hp = 11

	def spores(caster, target):
		target.apply_buff(Stun(), 2)

	spores = SimpleRangedAttack(damage=1, damage_type=Tags.Poison, range=2, onhit=spores)
	spores.cool_down = 5
	spores.name = "Spore Puff"
	spores.description = "Stuns for 2 turns"
	unit.spells.append(spores)
	
	unit.buffs.append(MushboomBuff(Stun, 3))

	unit.resists[Tags.Fire] = -50
	unit.resists[Tags.Ice] = -50
	unit.resists[Tags.Poison] = 100
	unit.tags = [Tags.Nature]

	return unit

def GlassMushboom():
	u = Unit()
	u.name = "Glass Mushboom"
	u.max_hp = 11
	u.shields = 2
	u.spells = [SimpleRangedAttack(name="Glass Spores", cool_down=3, buff=GlassPetrifyBuff, buff_duration=2)]
	u.buffs = [MushboomBuff(BleedBuff, 4, effect_tag=Tags.Blood)]
	u.resists[Tags.Poison] = 100
	u.tags = [Tags.Nature, Tags.Glass, Tags.Arcane, Tags.Construct]
	return u

class RedMushboomBuff(Buff):

	def on_init(self):
		self.name = "Fire Spores"
		self.owner_triggers[EventOnDeath] = self.on_death
		self.description = "On death, deal [9 Fire:fire] damage to adjacent units"

	def on_death(self, evt):
		self.owner.level.queue_spell(self.explode())

	def explode(self):
		for p in self.owner.level.get_adjacent_points(self.owner):
			self.owner.level.deal_damage(p.x, p.y, 9, Tags.Fire, self)
		yield

def RedMushboom():
	unit = Unit()
	unit.name = "Red Mushboom"

	unit.asset_name = "mushboom_red"

	unit.max_hp = 11

	spores = SimpleRangedAttack(damage=5, damage_type=Tags.Fire, range=2)
	spores.cool_down = 3
	spores.name = "Fire Spores"
	unit.spells.append(spores)

	unit.buffs.append(RedMushboomBuff())

	unit.resists[Tags.Fire] = 100
	unit.resists[Tags.Ice] = -50
	unit.resists[Tags.Poison] = 100
	unit.tags = [Tags.Nature, Tags.Fire]
	return unit

def ThornPlant():
	unit = Unit()
	unit.name = "Spriggan Bush"
	unit.max_hp = 3

	unit.resists[Tags.Physical] = 50
	unit.resists[Tags.Fire] = -100

	unit.spells.append(SimpleMeleeAttack(3))
	unit.stationary = True
	unit.tags = [Tags.Nature]

	unit.buffs.append(MatureInto(Spriggan, random.randint(10, 20)))

	return unit

def Spriggan():

	unit = Unit()
	unit.name = "Spriggan"

	unit.max_hp = 9

	unit.resists[Tags.Physical] = 50
	unit.resists[Tags.Fire] = -100

	unit.buffs.append(RespawnAs(ThornPlant))
	unit.spells.append(SimpleMeleeAttack(2))

	unit.tags = [Tags.Living, Tags.Nature]
	return unit

def IcySprigganBush():
	unit = ThornPlant()
	unit.name = "Icy Spriggan Bush"
	unit.asset_name = "spriggan_bush_icy"

	ice = SimpleRangedAttack(damage=3, range=4, damage_type=Tags.Ice)
	ice.name = "Ice"
	unit.spells.append(ice)
	return unit

def IcySpriggan():
	unit = Spriggan()
	unit.name = "Icy Spriggan"
	unit.asset_name = "spriggan_icy"
	unit.buffs = [RespawnAs(IcySprigganBush)]
	unit.resists[Tags.Ice] = 100
	ice = SimpleRangedAttack(damage=3, range=4, damage_type=Tags.Ice)
	ice.name = "Ice"
	unit.spells = [ice]

	return unit

def Treant():

	unit = Unit()
	unit.name = "Treant"

	unit.max_hp = 37

	unit.resists[Tags.Physical] = 50
	unit.resists[Tags.Fire] = -100

	regrow = HealAlly(12, 0)
	regrow.name = "Regrow"
	regrow.cool_down = 3
	unit.spells.append(regrow)

	unit.spells.append(SimpleMeleeAttack(8))

	unit.tags = [Tags.Nature, Tags.Living]

	return unit

class ForestRageBuff(Buff):

	def on_init(self):
		self.name = "Forest's Rage"
		self.description = "When damaged, gain +1 spell damage"
		self.owner_triggers[EventOnDamaged] = self.on_damaged
		self.color = COLOR_DAMAGE

	def on_damaged(self, evt):
		for s in self.owner.spells:
			if getattr(s, 'damage', None):
				s.damage += 1

def Oakheart():
	unit = Treant()
	unit.name = "Oakheart"
	unit.max_hp = 101

	unit.buffs.append(ForestRageBuff())

	b = RegenBuff(12)
	b.color = Tags.Nature.color
	unit.buffs.append(b)
	return unit

def VampireMist():
	unit = Ghost()
	unit.name = "Vampiric Mist"
	unit.asset_name = "ghost_vampire"

	unit.resists[Tags.Fire] = -100
	unit.max_hp = 12
	unit.buffs.append(MatureInto(GreaterVampire, 20))
	unit.is_coward = True

	unit.tags = [Tags.Undead, Tags.Dark, Tags.Blood]

	return unit


def GreaterVampire():

	unit = Unit()

	unit.name = "Greater Vampire"

	unit.resists[Tags.Fire] = -100

	unit.max_hp = 48
	unit.flying = True

	def drain(self, target):
		self.max_hp += 7
		self.cur_hp += 7
		drain_max_hp(target, 7)

	melee = SimpleMeleeAttack(damage=7, damage_type=Tags.Dark, onhit=drain)
	melee.name = "Greater Life Drain"
	melee.description = "Steals 7 max HP"
	unit.spells.append(melee)

	unit.buffs.append(RespawnAs(VampireMist))

	unit.tags = [Tags.Undead, Tags.Dark, Tags.Blood]

	return unit

def VampireEye():
	unit = Unit()
	unit.name = "Vampire Eye"
	unit.max_hp = 10
	unit.shields = 1
	unit.resists[Tags.Arcane] = 50
	unit.flying = True
	unit.is_coward = True

	drain = SimpleRangedAttack(damage=2, range=99, damage_type=Tags.Dark)
	drain.onhit = lambda caster, target: caster.deal_damage(-2, Tags.Heal, drain)
	drain.name = "Life Drain"
	drain.cool_down = 2
	drain.description = "Heals for damage dealt"

	unit.spells.append(drain)

	unit.buffs.append(TeleportyBuff())

	unit.buffs.append(MatureInto(MindVampire, 20))

	unit.tags = [Tags.Arcane, Tags.Dark, Tags.Undead]
	return unit

def MindVampire():

	unit = Unit()

	unit.name = "Mind Vampire"

	unit.resists[Tags.Arcane] = 50
	unit.resists[Tags.Fire] = -100

	unit.max_hp = 25
	unit.shields = 3
	unit.flying = True

	def mind_drain(self, target):
		if self.shields < 3:
			self.add_shields(1)
		drain_spell_charges(self, target)
	
	melee = SimpleMeleeAttack(damage=7, damage_type=Tags.Arcane, onhit=mind_drain)
	melee.name = "Mind Drain"
	melee.description = "On hit, drain a charge from a random spell and gain [1 SH:shields], up to [3 SH:shields]"

	unit.spells.append(melee)

	unit.buffs.append(RespawnAs(VampireEye))

	unit.tags = [Tags.Arcane, Tags.Dark, Tags.Undead]

	return unit


def FaeThorn():
	unit = Unit()
	unit.name = "Fae Thorn"
	unit.max_hp = 10
	unit.spells.append(SimpleMeleeAttack(damage=4))
	unit.stationary = True
	unit.turns_to_death = 6
	unit.tags = [Tags.Nature, Tags.Arcane]
	return unit

class ThornQueenThornBuff(Buff):

	def on_init(self):
		self.radius = 6

	def get_tooltip(self):
		return "Each turn, summon a Fae Thorn within 6 tiles"

	def on_advance(self):
		self.summon(FaeThorn(), radius=self.radius, sort_dist=False)


def ThornQueen():

	unit = Unit()

	unit.name = "Fae Queen"
	unit.max_hp = 50
	unit.shields = 2
	unit.flying = True
	unit.resists[Tags.Arcane] = 100
	
	summon = SimpleSummon(Faery, num_summons=4, cool_down=10, duration=15, radius=6, custom_plural="Faeries")
	summon.name = "Fae Queen's Guard"
	unit.spells.append(summon)
	unit.spells.append(SimpleRangedAttack(damage=7, range=4, damage_type=Tags.Arcane))
		
	unit.buffs.append(TeleportyBuff(chance=.5))
	unit.buffs.append(GeneratorBuff(FaeThorn, 1, global_summon=True))
	unit.buffs.append(HealAuraBuff(heal=6, radius=8))
	unit.buffs.append(ShieldRegenBuff(shield_freq=3, shield_max=2))
	unit.tags = [Tags.Living, Tags.Nature, Tags.Arcane]

	return unit

class FaeCurse(Buff):

	def on_init(self):
		self.name = "Fae Curse"
		self.color = Tags.Arcane.color
		self.description = "Deals 3 [Arcane] damage each turn"
		self.buff_type = BUFF_TYPE_CURSE
		self.stack_type = STACK_INTENSITY

	def on_advance(self):
		self.owner.deal_damage(3, Tags.Arcane, self)

class RoyalRebuke(Buff):

	def on_init(self):
		self.name = "Royal Rebuke"
		self.description = "On death, afflict the killer with Fae Curse, which deals 3 [Arcane] damage each turn"
		self.owner_triggers[EventOnDeath] = self.on_death
		self.color = Tags.Arcane.color

	def on_death(self, evt):
		if not evt.damage_event: return
		if not evt.damage_event.source: return
		if not evt.damage_event.source.owner: return
		self.owner.level.show_beam(self.owner, evt.damage_event.source.owner, Tags.Arcane, minor=True, inclusive=True)
		evt.damage_event.source.owner.apply_buff(FaeCurse())

def FaeryEmpress():
	u = Unit()
	u.name = "Faery Empress"
	u.tags = [Tags.Living, Tags.Arcane, Tags.Nature]
	u.max_hp = 300
	u.shields = 12
	u.flying = True
	u.resists[Tags.Arcane] = 100

	def eat_temp_buff(caster, target):
		buffs = [b for b in target.buffs if b.buff_type == BUFF_TYPE_BLESS and b.turns_left]
		if not buffs: return
		to_remove = random.choice(buffs)
		if target.is_alive(): target.remove_buff(to_remove)
		caster.add_shields(1)

	eat_desc = "Removes 1 temporary buff\nGains 1 SH per buff removed"
	ranged = SimpleRangedAttack(name="Fae Royalties", damage=10, range=6, damage_type=Tags.Arcane, onhit=eat_temp_buff, onhit_description=eat_desc, drain=True)

	u.spells = [ranged]
	u.buffs = [TeleportyBuff(radius=6, chance=.8), RoyalRebuke()]

	add_tooltip(u, FaeCurse())

	return u

def FloatingEye():
	unit = Unit()
	unit.name = "Floating Eyeball"

	unit.max_hp = 1
	unit.shields = 4
	unit.resists[Tags.Arcane] = 100
	unit.flying = True
	unit.spells.append(SimpleRangedAttack(damage=2, range=99, damage_type=Tags.Arcane))
	unit.buffs.append(TeleportyBuff())

	unit.tags = [Tags.Arcane, Tags.Demon]
	return unit

def EyeballWizard():
	unit = Unit()
	unit.name = "Louis the Seer"
	unit.asset_name = "eye_wizard"
	unit.max_hp = 1
	unit.shields = 8
	unit.resists[Tags.Arcane] = 100
	unit.flying = True

	def summon_eye(caster, target):
		eye = FloatingEye()
		eye.source = getattr(caster, 'source', None)
		if eye.source: apply_minion_bonuses(eye.source, eye)  # preserves minion bonuses
		caster.level.summon(caster, eye, target)

	look = SimpleRangedAttack(name="Look", damage=2, range=99, damage_type=Tags.Arcane, onhit=summon_eye)
	look.description = "On hit, summon a Floating Eyeball near the target"
	look.add_unit_tooltip(FloatingEye)
	unit.spells.append(look)
	unit.buffs.append(RegenShieldsBuff(sh=1))
	unit.buffs.append(TeleportyBuff(radius=10, chance=.75))

	unit.tags = [Tags.Arcane, Tags.Demon]
	unit.is_wizard = True
	return unit

def FlamingEye():
	unit = FloatingEye()
	unit.name = "Flaming Eyeball"
	unit.spells = [SimpleRangedAttack(damage=4, range=99, radius=1, damage_type=Tags.Fire)]
	unit.tags.append(Tags.Fire)
	unit.resists[Tags.Arcane] = 50
	unit.resists[Tags.Fire] = 100

	return unit

def FrostEye():
	unit = FloatingEye()
	unit.name = "Frost Eyeball"
	unit.asset_name = "floating_eyeball_ice"
	unit.spells[0] = SimpleRangedAttack(damage=2, range=99, damage_type=Tags.Ice, buff=FrozenBuff, buff_duration=2)
	unit.tags.append(Tags.Ice)
	unit.resists[Tags.Arcane] = 50
	unit.resists[Tags.Ice] = 100

	return unit

def Elf():
	unit = Unit()
	unit.name = "Aelf"
	unit.max_hp = 18
	unit.shields = 1
	unit.resists[Tags.Dark] = 50
	unit.resists[Tags.Lightning] = 75
	unit.spells.append(SimpleMeleeAttack(damage=10, damage_type=Tags.Dark))
	unit.spells.append(SimpleRangedAttack(damage=6, range=7, damage_type=Tags.Lightning))
	unit.tags = [Tags.Living, Tags.Lightning, Tags.Dark]
	return unit

def Dwarf():
	unit = Unit()
	unit.name = "Duergar"
	unit.max_hp = 35
	unit.resists[Tags.Physical] = 50
	unit.resists[Tags.Dark] = 50
	unit.resists[Tags.Lightning] = -50
	crossbow = SimpleRangedAttack(damage=12, range=8, damage_type=Tags.Physical, proj_name="duergar_bolt")
	crossbow.name = "Crossbow"
	crossbow.cool_down = 5
	sword = SimpleMeleeAttack(damage=6)
	sword.name = "Short Sword"
	unit.spells.append(crossbow)
	unit.spells.append(sword)
	unit.tags = [Tags.Living, Tags.Dark]
	return unit

class DryderPoisonGaze(Spell):

	def on_init(self):
		self.name = "Toxic Gaze"
		self.description = "Poisons enemies in line of sight for 8 turns"
		self.cool_down = 10
		self.duration = 8
		self.range = 0

	def get_ai_target(self):
		for u in self.owner.level.get_units_in_los(self.caster):
			if are_hostile(self.owner, u):
				return self.owner

	def cast_instant(self, x, y):
		for u in self.owner.level.get_units_in_los(self.caster):
			if are_hostile(self.owner, u):
				u.apply_buff(Poison(), self.get_stat('duration'))
				for p in self.owner.level.get_points_in_line(self.owner, u)[1:-1]:
					self.owner.level.show_effect(p.x, p.y, Tags.Poison, minor=True)

def Dryder():
	unit = Unit()
	unit.name = "Dryder"
	unit.max_hp = 128
	unit.shields = 6
	unit.resists[Tags.Dark] = 75
	unit.spells.append(DryderPoisonGaze())
	unit.spells.append(SimpleRangedAttack(damage=9, range=4, damage_type=Tags.Dark, buff=BleedBuff, buff_duration=3))
	unit.buffs.append(SpiderBuff())
	unit.tags = [Tags.Living, Tags.Dark, Tags.Spider]
	return unit

def Redcap():
	unit = Unit()
	unit.name = "Redcap"
	unit.max_hp = 14
	unit.shields = 1
	unit.resists[Tags.Fire] = 75
	unit.resists[Tags.Arcane] = 50
	unit.resists[Tags.Ice] = -50

	unit.tags = [Tags.Living, Tags.Arcane, Tags.Fire]

	def summon_thorn(caster, target):
		caster.level.summon(caster, RedMushboom(), target, 2)

	attack = SimpleRangedAttack(damage=1, range=4, damage_type=Tags.Physical, onhit=summon_thorn, cool_down=2)
	attack.description = "Summons a Red Mushboom near the target"
	attack.name = "Fire Seed"
	attack.add_unit_tooltip(RedMushboom)
	
	unit.spells.append(attack)
	return unit

def ThornTrouble(caster, target):
	randomly_teleport(target, 3)
	for i in range(3):
		thorn = FaeThorn()
		caster.level.summon(caster, thorn, target)

def MischiefMaker():
	unit = Unit()
	unit.name = "Mischief Maker"
	unit.asset_name = "gnomed_troubler"
	unit.max_hp = 1
	unit.shields = 33

	unit.stationary = True
	unit.flying = True

	phasebolt = SimpleRangedAttack(damage=2, range=10, damage_type=Tags.Arcane)
	phasebolt.onhit = ThornTrouble
	phasebolt.name = "Thorncurse"
	phasebolt.description = "Teleports the target up to 3 tiles and summons 3 Fae Thorns nearby"
	unit.spells = [phasebolt]

	unit.resists[Tags.Arcane] = 100

	unit.tags = [Tags.Arcane]

	unit.buffs.append(TeleportyBuff(chance=.1, radius=8))

	return unit

def GnomeDonsy(num=5):
	unit = Gnome()
	unit.name = "Gnome Donsy"
	unit.max_hp *= num
	unit.shields *= num
	thorn_bolt = unit.get_spell(SimpleRangedAttack)
	thorn_bolt.attacks = num
	thorn_bolt.description += f", attacks {num} times"
	return unit


def Gnome():
	unit = Unit()
	unit.name = "Gnome"
	unit.max_hp = 10
	unit.shields = 1
	unit.resists[Tags.Arcane] = 50

	def summon_thorn(caster, target):
		thorn = FaeThorn()
		thorn.source = getattr(unit, 'source', None)
		if thorn.source: apply_minion_bonuses(unit.source, thorn) # preserves minion bonuses, i.e. faehaunt/gnomeshoes
		p = caster.level.get_summon_point(target.x, target.y, radius_limit=target.radius + 1, diag=True)
		if p: caster.level.summon(unit, thorn, p)

	attack = SimpleRangedAttack(damage=1, range=4, damage_type=Tags.Physical, onhit=summon_thorn)
	attack.description = "Summons a Fae Thorn next to the target"
	attack.name = 'Thorn Bolt'
	attack.add_unit_tooltip(FaeThorn)
	unit.spells.append(attack)

	unit.tags = [Tags.Living, Tags.Nature, Tags.Arcane]
	return unit

class MonsterChainLightning(Spell):

	def on_init(self):
		self.name = "Chain Lightning"
		self.range = 6
		self.damage = 10
		self.arc_range = 3
		self.damage_type = Tags.Lightning

	def cast(self, x, y):
		caster = self.caster
		level = caster.level

		prev = self.caster
		target = level.get_unit_at(x, y) or Point(x, y)
		already_hit = set()
		damage = self.get_stat('damage')
		dt = self.damage_type
		arc_range = self.arc_range

		show_effect = level.show_effect
		deal_damage = level.deal_damage
		get_line = level.get_points_in_line
		get_ball = level.get_units_in_ball
		can_see = level.can_see

		while target or prev == caster:
			for p in get_line(prev, target, find_clear=True)[1:]:
				show_effect(p.x, p.y, dt, minor=True)
				yield
			deal_damage(target.x, target.y, damage, dt, self)
			yield
			already_hit.add(target)
			def can_arc(u, prev):
				if not are_hostile(caster, u): return False
				if u in already_hit: return False
				if not can_see(prev.x, prev.y, u.x, u.y): return False
				return True
			units = [u for u in get_ball(target, arc_range) if can_arc(u, target)]
			prev = target
			if units: target = random.choice(units)
			else: target = None

	def get_impacted_tiles(self, x, y):
		level = self.caster.level
		points = level.get_points_in_ball(x, y, self.arc_range)
		return [p for p in points if level.can_see(x, y, p.x, p.y)]

	def get_description(self):
		return ("Chains to targets up to {radius} tiles away", {'radius': self.arc_range})

	def can_threaten(self, x, y):
		return self.can_threaten_corner(x, y, self.arc_range)

	def get_ai_target(self):
		# Target as if it were a fireball of radius arc_range
		return Spell.get_ai_target(self) or self.get_corner_target(self.arc_range)

def ElfLightningLord():
	unit = Unit()
	unit.name = "Aelf Lightning Artist"
	unit.asset_name = "aelf_lightning_lord"
	unit.max_hp = 86
	unit.shields = 2
	unit.resists[Tags.Dark] = 50
	unit.resists[Tags.Lightning] = 100
	unit.spells.append(SimpleMeleeAttack(damage=10, damage_type=Tags.Lightning))
	unit.spells.append(MonsterChainLightning())
	unit.tags = [Tags.Living, Tags.Lightning, Tags.Dark]
	return unit

def OrcFireShaman():
	unit = Unit()
	unit.name = "Orc Pyromancer"
	unit.resists[Tags.Fire] = 50
	unit.max_hp = 26
	unit.spells.append(SimpleMeleeAttack(5))
	unit.spells.append(SimpleRangedAttack(name='Fireball', damage=8, damage_type=Tags.Fire, range=7, radius=2))
	unit.tags = [Tags.Living]
	return unit

def FaeArcanist():
	unit = Unit()
	unit.flying = True
	unit.name = "Faery Arcanist"
	unit.max_hp = 15
	unit.shields = 2
	unit.buffs.append(TeleportyBuff(chance=.7))
	unit.buffs.append(ShieldRegenBuff(2, 3))
	unit.spells.append(HealAlly(heal=9, range=5))

	def remove_temp_buff(caster, target):
		buffs = [b for b in target.buffs if b.buff_type == BUFF_TYPE_BLESS and b.turns_left]
		if not buffs: return
		to_remove = random.choice(buffs)
		if target.is_alive(): target.remove_buff(to_remove)

	blast = SimpleRangedAttack(damage=6, range=5, radius=1, damage_type=Tags.Arcane, onhit=remove_temp_buff)
	blast.name = "Arcane Blast"
	blast.description = "Removes 1 temporary buff"

	unit.spells.append(blast)

	unit.resists[Tags.Arcane] = 50

	unit.tags = [Tags.Nature, Tags.Arcane, Tags.Living]
	return unit

def FireFiend():
	unit = Unit()
	unit.name = "Fire Fiend"
	unit.max_hp = 66
	fireball = SimpleRangedAttack(damage=13, range=6, radius=2, damage_type=Tags.Fire)
	fireball.cool_down = 3
	deathgaze = SimpleRangedAttack(damage=5, range=6, beam=True, damage_type=Tags.Dark)
	deathgaze.cool_down = 4
	summon_imps = SimpleSummon(spawn_func=FireImp, num_summons=3, cool_down=7)
	unit.spells = [summon_imps, fireball, deathgaze]
	unit.resists[Tags.Fire] = 100
	unit.resists[Tags.Dark] = 100
	unit.resists[Tags.Ice] = -50
	unit.tags = [Tags.Fire, Tags.Demon]
	return unit

def ChaosFiend():
	unit = Unit()

	unit.name = "Chaos Fiend"
	unit.asset_name = "fiend_chaos"

	unit.max_hp = 166

	chaosball = SimpleRangedAttack(damage=13, range=6, radius=2, damage_type=[Tags.Fire, Tags.Lightning, Tags.Physical])
	chaosball.name = "Chaos Ball"

	deathgaze = SimpleRangedAttack(damage=5, range=6, beam=True, damage_type=Tags.Dark)
	deathgaze.cool_down = 2

	summon_imps = SimpleSummon(spawn_func=ChaosImp, num_summons=3, cool_down=7)

	unit.spells = [summon_imps, chaosball, deathgaze]

	unit.tags = [Tags.Fire, Tags.Lightning, Tags.Demon]
	unit.resists[Tags.Fire] = 100
	unit.resists[Tags.Lightning] = 100
	unit.resists[Tags.Ice] = -50

	return unit

class FiendConductance(Buff):
	
	def on_init(self):
		self.name = "Conductivity"
		self.resists[Tags.Lightning] = -100
		self.color = Tags.Lightning.color
		self.asset = ['status', 'conductance']
		self.buff_type = BUFF_TYPE_CURSE

def CopperFiend():
	unit = Unit()

	unit.name = "Copper Fiend"
	unit.asset_name = "fiend_copper"

	unit.max_hp = 166

	conductance = SimpleCurse(FiendConductance, 7)
	conductance.cool_down = 3
	conductance.name = "Conductivity"
	conductance.range = 10
	add_tooltip(unit, FiendConductance())

	summon_imps = SimpleSummon(CopperImp, num_summons=3, cool_down=7)

	deathgaze = SimpleRangedAttack(damage=5, range=6, beam=True, damage_type=Tags.Dark)
	deathgaze.cool_down = 2

	lightningbolt = SimpleRangedAttack(damage=5, range=6, beam=True, damage_type=Tags.Lightning)

	unit.spells = [summon_imps, conductance, deathgaze, lightningbolt]
	unit.tags = [Tags.Lightning, Tags.Metallic, Tags.Demon]

	unit.resists[Tags.Lightning] = 100

	return unit

def FurnaceFiend():
	unit = Unit()

	unit.name = "Furnace Fiend"
	unit.asset_name = "fiend_furnace"

	unit.max_hp = 166

	summon_imps = SimpleSummon(FurnaceImp, num_summons=3, cool_down=7)
	deathgaze = SimpleRangedAttack(damage=5, range=6, beam=True, damage_type=Tags.Dark)
	deathgaze.cool_down = 2
	
	unit.resists[Tags.Ice] = -50
	unit.resists[Tags.Lightning] = 75

	fireblast = FireBreath()

	fireblast.range = 5
	fireblast.damage = 13
	fireblast.name = "Fire Blast"
	fireblast.cool_down = 0	

	unit.spells = [summon_imps, deathgaze, fireblast]

	unit.buffs.append(DamageAuraBuff(damage=2, damage_type=Tags.Fire, radius=7))
	unit.tags = [Tags.Fire, Tags.Metallic, Tags.Demon]

	return unit

def InsanityFiend():
	unit = Unit()

	unit.name = "Insanity Fiend"
	unit.asset_name = "fiend_insanity"

	unit.max_hp = 166
	unit.shields = 4

	summon_imps = SimpleSummon(InsanityImp, num_summons=3, cool_down=7)
	deathgaze = SimpleRangedAttack(damage=5, range=6, beam=True, damage_type=Tags.Dark)
	deathgaze.cool_down = 2
	disrupt = lambda caster, target : randomly_teleport(caster, 3)
	bolt = SimpleRangedAttack(damage=3, range=6, onhit=disrupt, damage_type=Tags.Arcane)
	bolt.name = "Phase Bolt"
	bolt.description = "Teleports the target up to 3 tiles"
	unit.spells = [summon_imps, deathgaze, bolt]

	unit.resists[Tags.Arcane] = 100

	unit.tags = [Tags.Arcane, Tags.Demon]
	return unit

def RotFiend():
	unit = Unit()
	unit.name = "Rot Fiend"
	unit.asset_name = "fiend_rot"

	unit.max_hp = 166

	summon_imps = SimpleSummon(RotImp, num_summons=3, cool_down=7)
	deathgaze = SimpleRangedAttack(damage=5, range=6, beam=True, damage_type=Tags.Dark)
	deathgaze.cool_down = 2

	rotball = SimpleRangedAttack(name="Rot Blast", damage=4, range=6, radius=2, damage_type=Tags.Dark, buff=NecrosisBuff, buff_duration=10)

	unit.spells = [summon_imps, deathgaze, rotball]

	unit.tags = [Tags.Dark, Tags.Demon]
	return unit

def AshFiend():
	unit = Unit()
	unit.name = "Ash Fiend"
	unit.asset_name = "fiend_ash"

	unit.max_hp = 166
	
	summon_imps = SimpleSummon(AshImp, num_summons=3, cool_down=7)
	
	deathgaze = SimpleRangedAttack(damage=5, range=6, beam=True, damage_type=Tags.Dark)
	deathgaze.cool_down = 2

	ashblast = SimpleRangedAttack(damage=7, range=6, radius=3, damage_type=[Tags.Fire, Tags.Dark, Tags.Poison], buff=BlindBuff, buff_duration=1)
	ashblast.cool_down = 2
	ashblast.name = "Ash Blast"	
	
	unit.spells = [summon_imps, ashblast, deathgaze]
	unit.tags = [Tags.Fire, Tags.Demon]
	unit.resists[Tags.Fire] = 100

	return unit


class FiendStormBolt(Spell):

	def on_init(self):
		self.name = "Storm Bolt"
		self.description = "Beam attack, creates Storm Clouds along the beam"
		self.damage = 9
		self.damage_type = Tags.Lightning
		self.cool_down = 2
		self.range = 7

	def cast_instant(self, x, y):
		damage = self.get_stat('damage')
		for p in self.caster.level.get_points_in_line(self.caster, Point(x, y), find_clear=True)[1:]:
			self.caster.level.deal_damage(p.x, p.y, damage, self.damage_type, self)
			self.caster.level.add_obj(StormCloud(self.caster, damage), p.x, p.y)

def StormFiend():
	unit = Unit()
	unit.name = "Storm Fiend"
	unit.asset_name = 'spark_fiend'
	unit.max_hp = 66
	deathgaze = SimpleRangedAttack(damage=5, range=6, beam=True, damage_type=Tags.Dark)
	deathgaze.cool_down = 2
	summon_imps = SimpleSummon(spawn_func=SparkImp, num_summons=3, cool_down=7)
	unit.spells.append(FiendStormBolt())
	unit.spells.append(deathgaze)
	unit.spells.append(summon_imps)
	unit.tags = [Tags.Lightning, Tags.Demon]
	unit.resists[Tags.Lightning] = 100
	return unit

def IronFiend():
	unit = Unit()
	unit.name = "Iron Fiend"
	unit.asset_name = 'iron_demon'
	unit.max_hp = 66
	ironshot = SimpleRangedAttack(damage=7, range=6, effect=Tags.Petrification)
	ironshot.name = "Iron Gaze"
	ironshot.description = "Petrifies for 1 turn"
	ironshot.onhit = lambda caster, target: target.apply_buff(PetrifyBuff(), 1)
	ironshot.cool_down = 5
	deathgaze = SimpleRangedAttack(damage=5, range=6, beam=True, damage_type=Tags.Dark)
	deathgaze.name = "Death Beam"
	deathgaze.cool_down = 2
	summon_imps = SimpleSummon(spawn_func=IronImp, num_summons=3, cool_down=7)
	unit.spells.append(ironshot)
	unit.spells.append(deathgaze)
	unit.spells.append(summon_imps)
	unit.tags = [Tags.Metallic, Tags.Demon]
	return unit

class BloodCurseBuff(Buff):

	def on_init(self):
		self.name = "Blood Curse"
		self.stack_type = STACK_INTENSITY
		self.buff_type = BUFF_TYPE_CURSE
		self.color = Tags.Blood.color
		for dt in damage_tags: self.resists[dt] = -10
		self.owner_triggers[EventOnDamaged] = self.on_damaged
		self.description = "Damage taken heals a random enemy for the same amount"

	def on_damaged(self, evt):
		if evt.damage <= 0: return
		targets = [u for u in self.owner.get_hostiles() if u.cur_hp < u.max_hp]
		if not targets: return
		t = random.choice(targets)
		self.owner.level.show_beam(self.owner, t, Tags.Blood, minor=True)
		t.heal(evt.damage, self)


def ArchFiend():
	u = Unit()
	u.name = "Arch Fiend"
	u.tags = [Tags.Demon, Tags.Blood, Tags.Chaos]
	u.max_hp = 666
	u.flying = True

	u.resists[Tags.Dark] = 100
	u.resists[Tags.Fire] = 100
	u.resists[Tags.Physical] = 75

	def onhit(caster, target): target.apply_buff(NecrosisBuff())
	blast_desc = "Inflicts [necrosis] on enemies"

	blast =  SimpleRangedAttack(name="Hellfire Blast", damage=20, damage_type=[Tags.Dark, Tags.Fire], range=7, radius=2, onhit=onhit, onhit_description=blast_desc)
	blast.damage_type_random = False

	retaliation = DeathCurseRetaliation(name="Cursed Blood", buff=BloodCurseBuff, buff_dur=30, color_tag=Tags.Blood)
	add_tooltip(u, BloodCurseBuff())


	u.spells = [blast]
	u.buffs = [retaliation, RegenBuff(66)]

	return u

def GooSpitter():
	u = Unit()
	u.name = "Goo Spitter"
	u.tags = [Tags.Slime]
	u.max_hp = 85
	u.stationary = True


	def summon_slime(caster, target):
		s = GreenSlime()
		s.source = getattr(u, 'source', None)
		if s.source: apply_minion_bonuses(u.source, s)  # preserves minion bonuses
		p = caster.level.get_summon_point(target.x, target.y, radius_limit=target.radius + 1, diag=True)
		if p: caster.level.summon(u, s, p)

	attack = SimpleRangedAttack(damage=3, range=8, damage_type=Tags.Poison, onhit=summon_slime)
	attack.name = "Spit"
	attack.description = "Summons a Green Slime next to the target"
	attack.add_unit_tooltip(GreenSlime)

	u.spells = [attack]
	u.buffs = [ToxicAura()]

	u.resists[Tags.Physical] = 50
	u.resists[Tags.Poison] = 100
	u.resists[Tags.Dark] = -50
	u.resists[Tags.Ice] = -50

	return u

def LavaSpitter():
	u = Unit()
	u.name = "Lava Spitter"
	u.tags = [Tags.Slime, Tags.Fire]
	u.max_hp = 150
	u.stationary = True

	def summon_slime(caster, target):
		s = RedSlime()
		s.source = getattr(caster, 'source', None)
		if s.source: apply_minion_bonuses(caster.source, s)  # preserves minion bonuses
		p = caster.level.get_summon_point(target.x, target.y, radius_limit=target.radius + 1, diag=True)
		if p: caster.level.summon(caster, s, p)

	attack = SimpleRangedAttack(damage=3, range=9, damage_type=Tags.Fire, onhit=summon_slime, attacks=2)
	attack.name = "Spit"
	attack.description = "Summons a Red Slime next to the target"
	attack.add_unit_tooltip(RedSlime)

	u.spells = [attack]

	u.resists[Tags.Physical] = 50
	u.resists[Tags.Fire] = 100
	u.resists[Tags.Poison] = 100
	u.resists[Tags.Dark] = -50
	u.resists[Tags.Ice] = -50

	return u

def AnnihilationGoo():
	unit = Unit()
	unit.name = "Annihilation Goo"

	unit.resists[Tags.Arcane] = 100
	unit.resists[Tags.Physical] = 50
	unit.resists[Tags.Dark] = 75
	unit.resists[Tags.Fire] = 25
	unit.resists[Tags.Lightning] = 25
	unit.resists[Tags.Ice] = -50
	unit.resists[Tags.Poison] = 100

	unit.tags = [Tags.Arcane, Tags.Slime]

	unit.max_hp = 190
	unit.shields = 3

	unit.stationary = True

	teleport = MonsterTeleport()
	teleport.cool_down = 4
	teleport.requires_los = True
	teleport.range = 100
	teleport.description = "Teleports to a random tile in line of sight"

	tongue = PullAttack(damage=2, range=9, color=Tags.Tongue.color)
	tongue.name = "Tongue Lash"
	aura = DamageAuraBuff(damage=3, damage_type=Tags.Arcane, radius=4)
	unit.buffs.append(aura)

	unit.spells = [teleport, tongue]
	return unit

def MaskedWizard():
	unit = Unit()
	unit.name = "Masked Wizard"
	unit.asset_name = "mask_wizard"
	unit.max_hp = 1
	unit.shields = 13

	voidbeam = SimpleRangedAttack(damage=6, damage_type=Tags.Arcane, range=10, beam=True, melt=True, cool_down=6)
	voidbeam.name = "Void Beam"

	def warp(caster, target):
		randomly_teleport(target, 5)

	disperse = SimpleRangedAttack(damage=3, damage_type=Tags.Arcane, range=6, radius=3, onhit=warp, cool_down=4)
	disperse.description = "Teleports units up to 5 tiles"
	disperse.name = "Warp Ball"

	teleport = MonsterTeleport()
	teleport.cool_down = 9

	warptouch = SimpleMeleeAttack(damage=17, damage_type=Tags.Arcane)
	warptouch.name = "Warptouch"

	unit.resists[Tags.Arcane] = 100

	unit.tags = [Tags.Arcane]

	unit.spells = [voidbeam, disperse, teleport, warptouch]
	unit.is_wizard = True
	return unit

def Troubler():
	unit = Unit()
	unit.name = "Troubler"
	unit.asset_name = 'mask'


	unit.max_hp = 1
	unit.shields = 1

	unit.resists[Tags.Arcane] = 100

	phasebolt = SimpleRangedAttack(damage=2, range=7, damage_type=Tags.Arcane)
	phasebolt.onhit = lambda caster, target: randomly_teleport(target, 3)
	phasebolt.name = "Phase Bolt"
	phasebolt.description = "Teleports the target up to 3 tiles"

	unit.spells.append(phasebolt)
	unit.flying=True
	unit.stationary=True

	unit.buffs.append(TeleportyBuff(chance=.1, radius=8))

	unit.tags = [Tags.Arcane]

	return unit

def Fearface():
	unit = Troubler()
	unit.name = "Fearface"
	unit.asset_name = 'fear_face'

	unit.shields += 1

	unit.resists[Tags.Dark] = 100
	unit.tags = [Tags.Arcane, Tags.Undead]

	fearbolt = SimpleRangedAttack(damage=2, range=7, damage_type=Tags.Dark)
	fearbolt.onhit = lambda caster, target: randomly_teleport(target, 3)
	fearbolt.name = "Fear Bolt"
	fearbolt.buff = FearBuff
	fearbolt.buff_duration = 2
	fearbolt.description = "Teleports the target up to 3 tiles and inflicts [fear] for 2 turns"

	unit.spells = [fearbolt]

	return unit


def Witch():

	unit = Unit()
	unit.name = "Witch"

	unit.max_hp = 13
	unit.flying = True

	ghosty = SimpleSummon(Ghost, num_summons=1, duration=10, cool_down=5)
	deathbolt = SimpleRangedAttack(damage=3, range=5, damage_type=Tags.Dark)

	unit.spells.append(ghosty)
	unit.spells.append(deathbolt)

	unit.asset_name = 'witch'

	unit.tags = [Tags.Living, Tags.Dark]
	unit.resists[Tags.Dark] = 50
	unit.resists[Tags.Fire] = -50
	unit.resists[Tags.Holy] = -50
	return unit

def WildMan():
	unit = Unit()
	unit.name = "Wild Man"
	unit.asset_name = "werewolf_human"

	unit.max_hp = 8
	unit.is_coward = True

	unit.buffs.append(MatureInto(Werewolf, 20))

	unit.tags = [Tags.Living]
	return unit

def Werewolf():
	unit = Unit()
	unit.name = "Werewolf"
	unit.asset_name = "werewolf_transformed"
	unit.max_hp = 28

	unit.spells.append(SimpleMeleeAttack(6))
	leap = LeapAttack(damage=6, range=3)
	leap.cool_down = 3
	unit.spells.append(leap)

	unit.resists[Tags.Dark] = 75
	unit.resists[Tags.Holy] = -50

	unit.buffs.append(RespawnAs(WildMan))

	unit.tags = [Tags.Living, Tags.Nature, Tags.Dark]
	return unit

class MonsterGrowthBuff(Buff):

	def __init__(self, name="Ravenous Hunger", color=Tags.Blood.color, event_type=EventOnDeath, health_growth=10, damage_growth=1):
		Buff.__init__(self)
		self.color = color
		self.name = name
		self.event_type = event_type
		self.health_growth = health_growth
		self.damage_growth = damage_growth
		desc_txt = ''
		if event_type == EventOnDeath: desc_txt = "On killing a unit, "; self.global_triggers[EventOnDeath] = self.on_death
		elif event_type == EventOnDamaged: desc_txt = "On dealing damage, "; self.global_triggers[EventOnDamaged] = self.on_deal_damage
		self.description = [desc_txt,
							("gain [{health}:minion_health] max HP and [{damage}:minion_damage] damage to spells",
							 {'health': health_growth, 'damage': damage_growth})]

	def on_init(self):
		self.buff_type = BUFF_TYPE_BLESS

	def on_death(self, evt):
		if evt.damage_event and evt.damage_event.source and evt.damage_event.source.owner == self.owner:
			self.owner.max_hp += self.health_growth
			self.owner.heal(self.health_growth, self)
			for spell in self.owner.spells:
				if not hasattr(spell, 'damage'): continue
				spell.damage += self.damage_growth

	def on_deal_damage(self, evt):
		if evt.unit == self.owner: return # stop poison / bleed / etc self owned buffs from proccing this
		if evt.source and evt.source.owner and evt.source.owner == self.owner:
			self.owner.max_hp += self.health_growth
			self.owner.heal(self.health_growth, self)
			for spell in self.owner.spells:
				if not hasattr(spell, 'damage'): continue
				spell.damage += self.damage_growth


def Fenris():
	unit = Wolf()
	multiplier = 8
	unit.max_hp *= multiplier
	for spell in unit.spells:
		spell.damage *= multiplier
	unit.apply_buff(MonsterGrowthBuff())
	unit.name = "Fenris"
	return unit

class HemorrhageBuff(Buff):

	def on_init(self):
		self.name = "Hemorrhage"
		self.stack_type = STACK_INTENSITY
		self.buff_type = BUFF_TYPE_CURSE
		self.color = Tags.Blood.color

	def get_description(self):
		return ("Each turn, gain 1 stack of [bleed] for Hemorrhage's remaining duration\n"
				"Cannot be applied to units immune to [Physical] damage")

	def on_applied(self, owner):
		if owner.resists[Tags.Physical] >= 100: return ABORT_BUFF_APPLY

	def on_advance(self):
		self.owner.apply_buff(BleedBuff(), self.turns_left)

def Angrboda():
	u = Unit()
	u.name = "Angrboda"
	u.max_hp = 350
	u.flying = True
	u.tags = [Tags.Living, Tags.Dark, Tags.Arcane]

	drain = HagDrain()
	drain.damage = 10
	drain.cool_down = 4

	summon = SimpleSummon(Fenris, 1, cool_down=15)
	bolt = SimpleRangedAttack(name="Hemorrhaging Bolt", damage=9, damage_type=Tags.Dark, range=6, buff=HemorrhageBuff, buff_duration=3)

	u.resists[Tags.Dark] = 75
	u.resists[Tags.Arcane] = 50
	u.resists[Tags.Holy] = -50
	u.resists[Tags.Lightning] = -50

	add_tooltip(u, HemorrhageBuff())

	u.spells = [summon, drain, bolt]
	u.buffs = [TeleportyBuff(radius=6, chance=.4)]

	u.is_wizard = True

	return u

class CultistPain(Spell):

	def on_init(self):
		self.name = "Pain"
		self.description = "Ignores walls"
		self.requires_los = False
		self.range = 6
		self.damage = 1
		self.hp_cost = 1
		self.damage_type = Tags.Dark

	def cast_instant(self, x, y):
		caster = self.caster
		caster.level.show_beam(caster, Point(x, y), Tags.Dark)
		caster.level.deal_damage(x, y, self.get_stat('damage'), Tags.Dark, self)


def Cultist():
	unit = Unit()
	unit.name = "Cultist"
	unit.max_hp = 10

	unit.spells.append(CultistPain())

	unit.tags = [Tags.Living, Tags.Dark]
	
	unit.resists[Tags.Dark] = 50
	unit.resists[Tags.Holy] = -50

	return unit


class GreenGorgonBreath(BreathWeapon):

	def __init__(self):
		BreathWeapon.__init__(self)
		self.name = "Green Gorgon Breath"
		self.duration = 15
		self.damage_type = Tags.Poison
		self.cool_down = 10
		self.range = 5
		self.angle = math.pi / 6.0

	def get_description(self):
		return "Cone attack\nApplies [poison] for 15 turns"

	def per_square_effect(self, x, y, damage):
		unit = self.caster.level.get_unit_at(x, y)
		if unit:
			self.caster.level.deal_damage(x, y, 0, self.damage_type, self)
			unit.apply_buff(Poison(), self.get_stat('duration'))
		else:
			self.caster.level.deal_damage(x, y, 0, self.damage_type, self)

def GreenGorgon():

	unit = Unit()
	unit.asset_name = 'poison_gorgon'
	unit.name = 'Green Gorgon'

	unit.max_hp = 66

	unit.spells.append(GreenGorgonBreath())
	unit.spells.append(SimpleMeleeAttack(damage=13))
	
	unit.tags = [Tags.Poison, Tags.Living]
	unit.resists[Tags.Poison] = 100
	return unit

class GreyGorgonBreath(BreathWeapon):

	def __init__(self):
		BreathWeapon.__init__(self)
		self.name = "Grey Gorgon Breath"
		self.damage = 9
		self.damage_type = Tags.Physical
		self.cool_down = 10
		self.range = 5
		self.angle = math.pi / 6.0
		self.duration = 2

	def get_description(self):
		return "Cone attack\nApplies [petrify] for 2 turns"

	def per_square_effect(self, x, y, damage):
		self.caster.level.show_effect(x, y, Tags.Petrification)
		unit = self.caster.level.get_unit_at(x, y)
		if unit:
			self.caster.level.deal_damage(x, y, damage, self.damage_type, self)
			unit.apply_buff(PetrifyBuff(), self.get_stat('duration'))

def GreyGorgon():
	unit = Unit()
	unit.name = 'Grey Gorgon'

	unit.max_hp = 128

	unit.spells.append(GreyGorgonBreath())
	unit.spells.append(SimpleMeleeAttack(damage=23))
	
	unit.tags = [Tags.Dark, Tags.Living]
	unit.resists[Tags.Physical] = 75
	unit.resists[Tags.Dark] = 75
	return unit

def Lich():

	lich = Unit()
	lich.max_hp = 55
	lich.shields = 2
	lich.name = 'Lich'

	lich.spells.append(SimpleRangedAttack(damage=8, range=6, damage_type=Tags.Dark))
	lich.spells.append(LichSealSoulSpell())
	
	lich.resists[Tags.Dark] = 100
	lich.resists[Tags.Arcane] = 50

	lich.tags = [Tags.Dark, Tags.Undead]

	return lich


class HagDrain(Spell):

	def on_init(self):
		self.name = "Life Siphon"
		self.description = "Steals life from all [Living] units in line of sight"
		self.damage = 2
		self.range = 0
		self.damage_type = Tags.Dark

	def get_ai_target(self):
		if self.caster.cur_hp >= self.caster.max_hp: return False
		if not any(Tags.Living in u.tags and u != self.caster for u in self.caster.level.get_units_in_los(self.caster)): return False
		return self.caster

	def get_impacted_tiles(self, x, y):
		return [u for u in self.caster.level.get_units_in_los(self.caster) if Tags.Living in u.tags and u != self.caster]

	def can_threaten(self, x, y):
		return self.owner.level.can_see(self.owner.x, self.owner.y, x, y)

	def bolt(self, target, dmg):
		damage = target.deal_damage(dmg, self.damage_type, self)
		yield
		for p in self.caster.level.get_points_in_line(target, self.caster, find_clear=True)[1:-1]:
			self.caster.level.show_effect(p.x, p.y, self.damage_type, minor=True)
			yield
		if damage: self.caster.deal_damage(-damage, Tags.Heal, self)

	def cast_instant(self, x, y):
		total = 0
		dmg = self.get_stat('damage')
		targets = [u for u in self.caster.level.get_units_in_los(self.caster)]
		for u in targets:
			if u == self.caster: continue
			if Tags.Living not in u.tags: continue
			self.owner.level.queue_spell(self.bolt(u, dmg))

def NightHag():

	hag = Unit()
	hag.max_hp = 84

	hag.name = "Night Hag"

	hag.spells.append(HagDrain())

	sleep_touch = SimpleMeleeAttack(damage=1, damage_type=Tags.Dark, buff=SleepBuff, buff_duration=2)
	sleep_touch.cool_down = 3
	sleep_touch.name = "Sleep Touch"

	hag.spells.append(sleep_touch)

	hag.resists[Tags.Dark] = 75
	hag.resists[Tags.Arcane] = 50
	hag.resists[Tags.Holy] = -50
	hag.resists[Tags.Fire] = -50

	hag.buffs.append(GeneratorBuff(spawn_func=BreathStealer, spawn_chance=.15))

	hag.tags = [Tags.Dark, Tags.Arcane, Tags.Undead]
	return hag

class HagSwap(Spell):

	def on_init(self):
		self.name = "Aether Swap"
		self.description = "Swap places with the Wizard"
		self.range = 12
		self.cool_down = 9

	def can_threaten(self, x, y):
		return distance(self.caster, Point(x, y)) <= self.range and ((not self.requires_los) or self.caster.level.can_see(self.caster.x, self.caster.y, x, y))

	def can_cast(self, x, y):
		c = self.caster
		lvl = c.level
		unit = lvl.get_unit_at(x, y)
		if not unit: return False
		if not unit.is_player_controlled: return False
		if not lvl.can_stand(x, y, c, check_unit=False): return False # Ensure the caster can go where he is trying to go
		if not lvl.can_stand(c.x, c.y, unit, check_unit=False): return False # Ensure that the target can stand where its getting swapped to
		return Spell.can_cast(self, x, y)

	def cast(self, x, y):

		target = self.caster.level.get_unit_at(x, y)

		# Do an animation so players see something happening
		for p in self.caster.level.get_points_in_ball(target.x, target.y, 1):
			if p.x == target.x and p.y == target.y: continue
			self.caster.level.show_effect(p.x, p.y, Tags.Translocation)

		for p in self.caster.level.get_points_in_ball(x, y, 1):
			if p.x == x and p.y == y: continue
			self.caster.level.show_effect(p.x, p.y, Tags.Translocation)

		yield

		path = self.caster.level.get_points_in_line(self.caster, Point(x, y), find_clear=True)
		for i in range(len(path)):
			p1 = path[i]
			p2 = path[-i]
			for p in [p1, p2]:
				self.caster.level.show_effect(p.x, p.y, Tags.Translocation, minor=True)
				yield

		self.caster.level.act_move(self.caster, x, y, teleport=True, force_swap=True)

		for p in self.caster.level.get_points_in_ball(target.x, target.y, 1):
			if p.x == target.x and p.y == target.y: continue
			self.caster.level.show_effect(p.x, p.y, Tags.Translocation)

		for p in self.caster.level.get_points_in_ball(x, y, 1):
			if p.x == x and p.y == y: continue
			self.caster.level.show_effect(p.x, p.y, Tags.Translocation)

def VoidHag():

	hag = Unit()
	hag.name = "Dream Hag"
	hag.asset_name = "night_hag_2"
	hag.max_hp = 67
	hag.shields = 2

	sleep_touch = SimpleMeleeAttack(damage=1, damage_type=Tags.Dark, buff=SleepBuff, buff_duration=3)
	sleep_touch.cool_down = 3
	sleep_touch.name = "Sleep Touch"

	hag.spells.append(HagSwap())
	hag.spells.append(sleep_touch)

	hag.resists[Tags.Dark] = 50
	hag.resists[Tags.Arcane] = 75
	hag.resists[Tags.Holy] = -50
	hag.resists[Tags.Fire] = -50

	hag.buffs.append(ShieldRegenBuff(2, 2))

	hag.tags = [Tags.Dark, Tags.Arcane, Tags.Living]
	return hag


def IceBelcher():
	liz = Unit()
	liz.max_hp = 23
	liz.name = "Ice Belcher"
	liz.asset_name = "ice_lizard_giant"
	liz.resists[Tags.Ice] = 75
	liz.resists[Tags.Fire] = -50
	liz.tags = [Tags.Living, Tags.Ice, Tags.Dragon]
	liz.spells.append(SimpleRangedAttack(damage=4, range=5, radius=2, damage_type=Tags.Ice, buff=FrozenBuff, buff_duration=1))
	return liz


def FireBelcher():
	liz = Unit()
	liz.max_hp = 23
	liz.name = "Fire Belcher"
	liz.asset_name = "fire_lizard_belcher"
	liz.resists[Tags.Fire] = 75
	liz.resists[Tags.Ice] = -50
	liz.tags = [Tags.Living, Tags.Fire, Tags.Dragon]
	liz.spells.append(SimpleRangedAttack(damage=4, range=5, radius=2, damage_type=Tags.Fire))
	return liz

def Snake():
	snek = Unit()
	snek.name = "Snake"
	snek.max_hp = 9
	snek.spells.append(SimpleMeleeAttack(3, buff=Poison, buff_duration=5))
	snek.resists[Tags.Ice] = -50
	snek.tags = [Tags.Living, Tags.Nature]
	return snek

def MantisEggSac():
	u = Unit()
	u.name = "Mantis Egg Sac"
	u.max_hp = 25
	u.tags = [Tags.Living]
	u.stationary = True
	def deathspawn_tt(): return "On death, summon 4 Mantises"
	deathspawn = SpawnOnDeath(Mantis, 4)
	deathspawn.get_tooltip = deathspawn_tt
	u.buffs = [deathspawn, MatureInto(MantisQueen, 10)]
	return u

class LayEggsSpell(Spell):

	def on_init(self):
		self.name = "Lay Eggs"
		self.range = 0
		self.cool_down = 12
		self.spawn_func = MantisEggSac

	def get_description(self):
		return "Summons a Mantis Egg Sac"

	def cast_instant(self, x, y):
		self.caster.level.summon(self.caster, self.get_unit())

	def get_unit(self):
		u = self.spawn_func()
		src = getattr(getattr(self, 'caster', None), 'source', None)
		if src: u.source = src; apply_minion_bonuses(src, u)
		return u

	def get_unit_extra_examine_tooltips(self):
		return [self.get_unit()]

def MantisQueen():
	unit = Unit()
	unit.name = "Mantis Queen"
	unit.max_hp = 55
	unit.tags = [Tags.Living]
	summon = LayEggsSpell()
	unit.spells.append(summon)
	unit.cool_downs[summon] = random.randint(summon.cool_down//2, summon.cool_down)
	unit.spells.append(SimpleMeleeAttack(damage=12))
	unit.spells.append(LeapAttack(damage=12, range=4))
	return unit

def Mantis():
	mantis = Unit()
	mantis.name = "Mantis"
	mantis.max_hp = 4
	mantis.spells.append(SimpleMeleeAttack(damage=3))
	mantis.spells.append(LeapAttack(damage=3, range=4))
	mantis.tags = [Tags.Living]
	return mantis

def MetalMantis():

	mantis = Unit()
	mantis.name = "Metal Mantis"
	mantis.asset_name = "mantis_metal"
	mantis.max_hp = 12

	mantis.spells.append(SimpleMeleeAttack(damage=6))
	mantis.spells.append(LeapAttack(damage=6, range=4))	

	mantis.tags = [Tags.Construct, Tags.Metallic]

	return mantis

class RavenBlind(Spell):

	def on_init(self):
		self.name = "Mass Blindness"
		self.description = "Blinds all enemies for 3 turns"
		self.cool_down = 9
		self.range = 0

	def cast(self, x, y):
		tiles = [t for t in self.caster.level.iter_tiles()]
		random.shuffle(tiles)
		tiles.sort(key=lambda u: distance(self.caster, u))

		for t in tiles:

			u = t.unit
			if u and are_hostile(self.caster, u):
				u.apply_buff(BlindBuff(), 3)

			elif random.random() < .25:
				self.caster.level.deal_damage(t.x, t.y, 0, Tags.Dark, self)

			if random.random() < .05:
				yield

def RavenMage():
	unit = Unit()
	unit.name = "Raven Mage"
	unit.asset_name = "raven_wizard"
	unit.max_hp = 76
	unit.shields = 4
	unit.flying = True


	windride = MonsterTeleport()
	windride.cool_down = 12
	windride.requires_los = True
	windride.range = 20
	windride.name = "Ride the Wind"
	windride.description = "Teleports to a random tile in line of sight"


	ravens = SimpleSummon(Raven, num_summons=3, cool_down=6)
	blind = RavenBlind()
	deathtouch = SimpleMeleeAttack(damage=44, damage_type=Tags.Dark)
	deathtouch.name = "Death Touch"

	unit.spells = [ravens, windride, blind, deathtouch]

	unit.tags = [Tags.Living, Tags.Dark]
	unit.is_wizard = True
	return unit

def Raven():

	unit = Unit()
	unit.name = "Raven"
	unit.max_hp = 13
	unit.flying = True

	peck = SimpleMeleeAttack(damage=3, buff=BlindBuff, buff_duration=3)
	peck.name = 'Peck'
	unit.spells.append(peck)

	unit.resists[Tags.Dark] = 50

	unit.tags = [Tags.Living, Tags.Dark]

	return unit

def MindDevourer():

	unit = Unit()
	unit.name = "Mind Devourer"

	unit.shields = 2
	unit.max_hp = 82

	def mind_drain(caster, target):
		caster.add_shields(1)
		drain_spell_charges(caster, target)

	melee = SimpleMeleeAttack(25, damage_type=Tags.Arcane, onhit=mind_drain)
	melee.name = "Brain Bite"
	melee.description = "On hit, drain a charge from a random spell and gain [1 SH:shields]"
	unit.spells.append(melee)

	pull = PullAttack(damage=2, range=6, color=Tags.Tongue.color)
	pull.name = "Tentacle"
	unit.spells.append(pull)

	unit.tags = [Tags.Arcane, Tags.Living]
	unit.resists[Tags.Arcane] = 100

	return unit

class ToxicAura(DamageAuraBuff):

	def __init__(self):
		DamageAuraBuff.__init__(self, damage=10, damage_type=Tags.Poison, radius=3, custom_name="Toxic Aura")
		self.color = Tags.Poison.color

	def get_tooltip(self):
		return "Each turn, enemies within 3 tiles take [10 Poison:poison] damage and are poisoned for 3 turns"

	def on_hit(self, unit):
		if unit.is_alive():
			unit.apply_buff(Poison(), 3)

def ToxicMindDevourer():
	u = MindDevourer()
	u.name = "Toxic Mind Devourer"
	u.buffs.append(ToxicAura())
	u.resists[Tags.Poison] = 100
	return u

def SkullSentry():
	u = Unit()
	u.radius = 1
	u.name = "Skull Sentry"
	u.asset_name = '3x3_crystal_skull'
	u.max_hp = 800
	u.tags = [Tags.Dark, Tags.Undead, Tags.Construct]
	u.stationary = True
	u.spells = [WideBeam(name="Sentry Beam", damage=29, damage_type=Tags.Dark)]
	return u

def GiantSkull():
	unit = Unit()
	unit.flying = True
	
	unit.max_hp = 78

	unit.name = "Giant Floating Skull"
	unit.asset_name = "giant_skull"
	unit.stationary = True

	deathgaze = SimpleRangedAttack(damage=13, damage_type=Tags.Dark, range=7, beam=True)
	deathgaze.name = "Death Gaze"
	deathgaze.cool_down = 2

	unit.spells.append(deathgaze)

	unit.buffs.append(TeleportyBuff(chance=.1, radius=8))
	unit.resists[Tags.Dark] = 100
	unit.tags = [Tags.Undead, Tags.Dark]
	return unit

def GoldSkull():

	unit = GiantSkull()
	unit.name = "Golden Skull"
	unit.asset_name = "giant_skull_gilded"
	unit.shields = 2

	unit.tags.append(Tags.Holy)
	unit.tags.append(Tags.Metallic)

	holybeam = SimpleRangedAttack(damage=13, damage_type=Tags.Holy, range=7, beam=True)
	holybeam.name = "Wrath Gaze"
	holybeam.cool_down = 2
	
	heal = HealAlly(heal=13, range=7, can_target_self=False)
	heal.cool_down = 2

	unit.spells = [holybeam, heal]

	unit.resists[Tags.Dark] = 50
	unit.resists[Tags.Holy] = 50
	
	return unit

def PurpleHand():

	unit = Unit()
	unit.name = "Purple Hand"
	unit.asset_name = "giant_hand"

	unit.shields = 2
	unit.max_hp = 38

	melee = SimpleMeleeAttack(16, damage_type=Tags.Arcane)
	melee.onhit = lambda caster, target: randomly_teleport(target, 4)
	melee.name = "Void Flick"
	melee.description = "Teleports the target up to 4 tiles"

	unit.spells.append(melee)

	unit.tags = [Tags.Arcane]

	unit.resists[Tags.Arcane] = 75
	return unit

def Bloodghast():

	unit = Ghost()
	unit.name = "Bloodghast"
	unit.asset_name = "blood_ghost"
	unit.spells[0].name = "Frenzy Haunt"
	unit.spells[0].onhit = bloodrage()
	unit.spells[0].description = "On hit, gain +1 damage for 10 turns"
	add_tooltip(unit, BloodrageBuff(2))

	unit.tags.append(Tags.Demon)
	unit.tags.append(Tags.Blood)

	unit.resists[Tags.Poison] = 100
	unit.resists[Tags.Dark] = 75

	return unit

def Bloodhound():

	unit = Unit()

	unit.name = "Blood Hound"
	unit.asset_name = "blood_wolf"
	unit.max_hp = 19

	melee = SimpleMeleeAttack(6)
	melee.onhit = bloodrage()
	melee.name = "Frenzy Bite"
	melee.description = "On hit, gain +2 damage for 10 turns"
	unit.spells.append(melee)
	add_tooltip(unit, BloodrageBuff(2))

	unit.spells.append(LeapAttack(damage=6, damage_type=Tags.Physical, range=3))
	unit.tags = [Tags.Demon, Tags.Nature, Tags.Blood]
	unit.resists[Tags.Dark] = 75

	return unit


def BloodWizard():
	unit = Unit()
	unit.max_hp = 350
	unit.name = "Blood Magus"
	unit.asset_name = "blood_wizard"

	unit.resists[Tags.Dark] = 50

	unit.tags = [Tags.Blood, Tags.Dark]

	bone_spear = SimpleRangedAttack(damage=8, range=6, damage_type=Tags.Physical, beam=True, proj_name="bone_spear")
	bone_spear.name = "Bone Spear"

	from Spells import LifedrainSpell
	life_drain = LifedrainSpell()
	life_drain.tags = []
	life_drain.max_charges = 0
	life_drain.cool_down = 5
	life_drain.radius = 0
	life_drain.duration = 9
	life_drain.hp_cost = 0
	life_drain.range = 8

	hounds = SimpleSummon(Bloodhound, num_summons=2, cool_down=13)

	mass_bloodrage = MassBloodrageSpell()

	unit.spells = [hounds, mass_bloodrage, life_drain, bone_spear]
	unit.is_wizard = True
	return unit

class MassBloodrageSpell(Spell):

	def on_init(self):
		self.name = "Mass Bloodrage"
		self.cool_down = 15
		self.duration = 5
		self.description = "Allies gain +7 spell damage for 5 turns"
		self.range = 0
		self.target_allies = True

	def cast(self, x, y):
		units = list(self.owner.level.units)
		random.shuffle(units)
		for u in units:
			if not are_hostile(self.caster, u):
				u.apply_buff(BloodrageBuff(7), self.get_stat('duration'))
				yield

def OrcWolf():
	wolf = Wolf()
	wolf.max_hp += 10
	wolf.name = "Orc Wolf"
	return wolf

def OrcHoundlord():
	unit = Orc()
	unit.name = "Orc Houndlord"
	unit.max_hp += 29
	houndy = SimpleSummon(OrcWolf, num_summons=2, cool_down=10)
	unit.spells.insert(0, houndy)
	return unit

def LivingLightningScroll():

	unit = Unit()
	unit.name = "Living Scroll of Lightning"
	unit.asset_name = "living_lightning_scroll"

	bolt = SimpleRangedAttack(damage=6, range=10, damage_type=Tags.Lightning, beam=True)

	unit.spells.append(bolt)
	bolt.suicide = True

	unit.flying = True

	unit.max_hp = 5

	unit.resists[Tags.Arcane] = 100
	unit.resists[Tags.Lightning] = 100

	unit.tags = [Tags.Arcane, Tags.Lightning, Tags.Construct]

	return unit


def LivingFireballScroll():

	unit = Unit()
	unit.name = "Living Scroll of Fireball"
	unit.asset_name = "living_fireball_scroll"

	ball = SimpleRangedAttack(damage=6, range=7, damage_type=Tags.Fire, radius=2)
	
	unit.spells.append(ball)
	ball.suicide = True

	unit.flying = True

	unit.max_hp = 5

	unit.resists[Tags.Arcane] = 100
	unit.resists[Tags.Fire] = 100

	unit.tags = [Tags.Arcane, Tags.Fire, Tags.Construct]

	return unit

def FieryTormentor():

	unit = Unit()
	unit.name = "Fiery Tormentor"
	unit.asset_name = "tormentor_fiery"
	unit.max_hp = 34

	
	burst = SimpleBurst(damage=7, damage_type=Tags.Fire, cool_down=5, radius=4)
	burst.name = "Fiery Torment"

	unit.spells.append(burst)
	lifedrain = SimpleRangedAttack(damage=2, range=2, damage_type=Tags.Dark, drain=True)
	lifedrain.name = "Soul Suck"
	unit.spells.append(lifedrain)

	unit.tags = [Tags.Fire, Tags.Demon]
	unit.resists[Tags.Dark] = 100
	unit.resists[Tags.Fire] = 100
	unit.resists[Tags.Ice] = -50
	return unit

def FieryTormentorMass():
	unit = FieryTormentor()
	unit.name = "Fiery Tormenting Mass"
	unit.asset_name = "tormentor_fiery_mass"
	unit.max_hp += 37
	unit.buffs.append(SpawnOnDeath(FieryTormentor, 3))
	return unit

def FrostfireTormentor():

	unit = Unit()
	unit.name = "Frostfire Tormentor"
	unit.asset_name = "tormentor_frostfire"
	unit.max_hp = 56

	def freeze(caster, target): target.apply_buff(FrozenBuff(), 1)
	burst = SimpleBurst(damage=7, damage_type=[Tags.Fire, Tags.Ice], cool_down=3, radius=4, onhit=freeze, extra_desc="\nApplies 2 turns of [frozen]")
	burst.name = "Frostfire Torment"

	unit.spells.append(burst)

	lifedrain = SimpleRangedAttack(damage=2, range=2, damage_type=Tags.Dark, drain=True)
	lifedrain.name = "Soul Suck"
	unit.spells.append(lifedrain)

	unit.tags = [Tags.Fire, Tags.Ice, Tags.Demon]
	unit.resists[Tags.Dark] = 100
	unit.resists[Tags.Fire] = 100
	unit.resists[Tags.Ice] = 100
	return unit

def FrostfireTormentorMass():
	unit = FrostfireTormentor()
	unit.name = "Frostfire Tormenting Mass"
	unit.asset_name = "tormentor_frostfire_mass"
	unit.max_hp += 37
	unit.buffs.append(SpawnOnDeath(FrostfireTormentor, 3))
	return unit

def DarkTormentor():

	unit = Unit()
	unit.name = "Dark Tormentor"
	unit.asset_name = "tormentor_dark"
	unit.max_hp = 34

	burst = SimpleBurst(damage=7, damage_type=Tags.Dark, cool_down=5, ignore_walls=True, radius=4)
	burst.name = "Dark Torment"

	unit.spells.append(burst)
	lifedrain = SimpleRangedAttack(damage=2, range=2, damage_type=Tags.Dark, drain=True)
	lifedrain.name = "Soul Suck"
	unit.spells.append(lifedrain)

	unit.tags = [Tags.Dark, Tags.Demon]
	unit.resists[Tags.Dark] = 100
	return unit

def IcyTormentor():

	unit = Unit()
	unit.name = "Frosty Tormentor"
	unit.asset_name = "tormentor_ice"
	unit.max_hp = 34

	def freeze(caster, target):
		target.apply_buff(FrozenBuff(), 1)

	burst = SimpleBurst(damage=7, damage_type=Tags.Ice, cool_down=5, radius=4, onhit=freeze)
	burst.description = "Inflicts [frozen] for 1 turn"
	burst.name = "Frosty Torment"

	unit.spells.append(burst)
	lifedrain = SimpleRangedAttack(damage=2, range=2, damage_type=Tags.Dark, drain=True)
	lifedrain.name = "Soul Suck"
	unit.spells.append(lifedrain)

	unit.tags = [Tags.Ice, Tags.Demon]
	unit.resists[Tags.Dark] = 100
	unit.resists[Tags.Ice] = 100
	unit.resists[Tags.Fire] = -50
	return unit

def Yeti():

	unit = Unit()

	unit.name = "Yeti"
	unit.max_hp = 155

	unit.spells.append(SimpleMeleeAttack(34))
	unit.buffs.append(DamageAuraBuff(damage=3, damage_type=Tags.Ice, radius=4, friendly_fire=False))


	unit.resists[Tags.Ice] = 100
	unit.resists[Tags.Fire] = -50

	unit.tags = [Tags.Ice, Tags.Living]

	return unit

class ShamansSorrow(Buff):

	def on_init(self):
		self.name = "Shaman's Sorrow"
		self.global_triggers[EventOnDeath] = self.on_death
		self.tags = [Tags.Ice, Tags.Dark]

	def get_description(self):
		return "When a [Living] ally dies within [5 tiles:radius], summon a Sorrow on its tile"

	def on_death(self, evt):
		if Tags.Living not in evt.unit.tags: return
		if are_hostile(self.owner, evt.unit): return
		if distance(self.owner, evt.unit) > 5: return
		self.owner.level.queue_spell(self.summon_ghost(evt.unit.x, evt.unit.y))

	def summon_ghost(self, x, y):
		u = self.summon(Sorrow(), target=Point(x, y))
		if u: yield from self.owner.level.show_path_effect(self.owner, u, [Tags.Ice, Tags.Dark], minor=True, pause_frames=1)
		yield

	def get_tooltip_color(self):
		return Tags.Ice.color

def YetiShaman():
	u = Yeti()
	u.name = "Yeti Shaman"
	u.max_hp = 180
	u.shields = 3
	u.spells.insert(0, WizardBlizzard())
	u.buffs.append(ShamansSorrow())
	u.is_wizard = True
	return u

def Stalker():
	u = Unit()
	u.name = "Stalker"
	u.tags = [Tags.Living, Tags.Blood]
	u.max_hp = 190

	slash = SimpleMeleeAttack(damage=6, buff=BleedBuff, buff_duration=12, attacks=2)
	slash.name = "Slash"

	bite = SimpleMeleeAttack(damage=28, drain=True)
	bite.cool_down = 3
	bite.name = "Bite"

	u.spells = [bite, slash]
	u.buffs = [QuickmoveBuff()]

	return u

def GoatHead():

	unit = Unit()

	unit.name = "Goatia"
	unit.asset_name = "floating_goat_head"
	unit.max_hp = 17

	unit.stationary = True
	unit.flying = True

	leap_attack = LeapAttack(damage=5, range=3)
	leap_attack.cool_down = 2

	leap_random = MonsterTeleport()
	leap_random.cool_down = 2
	leap_random.range = 3

	unit.spells = [leap_attack, leap_random]
	unit.buffs.append(DeathExplosion(damage=5, radius=1, damage_type=Tags.Dark))
	unit.tags = [Tags.Demon, Tags.Nature]
	
	unit.resists[Tags.Dark] = 50

	return unit

def RedLion():

	unit = Unit()
	unit.max_hp = 40

	unit.name = "Fire Lion"
	unit.asset_name = "chaos_lion"

	unit.resists[Tags.Fire] = 100

	fire = SimpleRangedAttack(damage=8, range=5, damage_type=Tags.Fire, cool_down=2)
	fire.name = "Fire"
	melee = SimpleMeleeAttack(6)
	unit.spells = [fire, melee]

	unit.tags = [Tags.Fire, Tags.Living]

	return unit

def GoldenSnake():

	unit = Unit()
	unit.max_hp = 9
	unit.name = "Lightning Snake"
	unit.asset_name = "chaos_snake"

	unit.resists[Tags.Lightning] = 100

	spark = SimpleRangedAttack(damage=8, range=3, damage_type=Tags.Lightning, cool_down=2)
	spark.name = "Lightning"
	melee = SimpleMeleeAttack(3, buff=Poison, buff_duration=10)
	unit.spells = [spark, melee]

	unit.tags = [Tags.Lightning, Tags.Living]
	return unit

def ChaosChimera():

	unit = Unit()
	unit.max_hp = 46

	unit.resists[Tags.Fire] = 75
	unit.resists[Tags.Lightning] = 75

	unit.name = "Chaos Chimera"

	fire = SimpleRangedAttack(damage=8, range=5, damage_type=Tags.Fire, cool_down=2)
	fire.name = "Fire"
	spark = SimpleRangedAttack(damage=8, range=5, damage_type=Tags.Lightning, cool_down=2)
	spark.name = "Lightning"
	unit.spells = [fire, spark]
	unit.tags = [Tags.Fire, Tags.Lightning, Tags.Living]

	unit.buffs.append(SpawnOnDeath([RedLion, GoldenSnake], 1))

	return unit

def IceLion():

	unit = Unit()
	unit.max_hp = 40

	unit.name = "Ice Lion"
	unit.asset_name = "deathchill_lion"

	unit.resists[Tags.Ice] = 100

	ice = SimpleRangedAttack(damage=8, beam=True, range=5, damage_type=Tags.Ice, cool_down=2)
	ice.name = "Ice"
	melee = SimpleMeleeAttack(6)
	melee.name = "Claw"
	unit.spells = [ice, melee]

	unit.tags = [Tags.Ice, Tags.Living]

	return unit

def DeathSnake():

	unit = Unit()
	unit.max_hp = 9
	unit.name = "Death Snake"
	unit.asset_name = "deathchill_snake"

	unit.resists[Tags.Dark] = 100

	spark = SimpleRangedAttack(damage=8, beam=True, range=3, damage_type=Tags.Dark, cool_down=2)
	spark.name = "Darkness"
	melee = SimpleMeleeAttack(4, buff=Poison, buff_duration=10)
	melee.name = "Bite"
	unit.spells = [spark, melee]

	unit.tags = [Tags.Dark, Tags.Living]
	return unit

def DeathchillChimera():

	unit = Unit()
	unit.max_hp = 46

	unit.resists[Tags.Dark] = 75
	unit.resists[Tags.Ice] = 75

	unit.name = "Deathchill Chimera"

	fire = SimpleRangedAttack(damage=8, beam=True, range=5, damage_type=Tags.Ice, cool_down=2)
	fire.name = "Ice"
	spark = SimpleRangedAttack(damage=8, beam=True, range=5, damage_type=Tags.Dark, cool_down=2)
	spark.name = "Darkness"
	unit.spells = [fire, spark]
	unit.tags = [Tags.Dark, Tags.Ice, Tags.Living]

	unit.buffs.append(SpawnOnDeath([IceLion, DeathSnake], 1))

	return unit

def DeathchillWizard():
	unit = Unit()
	unit.name = "Deathchiller"
	unit.asset_name = "deathchill_wizard"

	unit.max_hp = 90
	unit.shields = 2
	unit.resists[Tags.Dark] = 100
	unit.resists[Tags.Ice] = 100
	unit.resists[Tags.Holy] = -50
	unit.resists[Tags.Fire] = -50

	unit.tags = [Tags.Dark, Tags.Ice]

	# Spells:
	# Deathbolt (as player spell- deal damage and raise)
	# Iceball (as player spell- aoe ice and freeze)
	# Deathchill Chimera Summoning

	def make_skeleton(caster, target):
		raise_skeleton(caster, target)
		yield

	def try_raise(caster, target):
		if not target.is_alive():
			caster.level.queue_spell(make_skeleton(caster, target))

	dbolt = SimpleRangedAttack(damage=7, range=6, damage_type=Tags.Dark, onhit=try_raise)
	dbolt.name = "Death Bolt"
	dbolt.description = "Raises slain targets as skeletons"

	from Spells import DeathChill


	def get_dchill_desc():
		return ("Deal [Dark] damage to the target each turn for 3 turns\n"
				"If the target dies while under the effect, inflicts [Ice] damage and 3 turns of [frozen] on enemies within 3 tiles")

	dchill = DeathChill()
	dchill.tags = []
	dchill.max_charges = 0
	dchill.cool_down = 5
	dchill.duration = 3
	dchill.intensity = 1
	dchill.get_description = get_dchill_desc


	deathchill_calling = SimpleSummon(DeathchillChimera, num_summons=1, cool_down=9)

	unit.spells = [deathchill_calling, dchill, dbolt]
	unit.is_wizard = True
	return unit

def StarLion():

	unit = Unit()
	unit.max_hp = 40

	unit.name = "Star Lion"
	unit.asset_name = "starfire_lion"

	unit.resists[Tags.Arcane] = 100

	void = SimpleRangedAttack(damage=8, beam=True, range=5, melt=True, damage_type=Tags.Arcane, cool_down=2)
	void.name = "Void"
	melee = SimpleMeleeAttack(6)
	melee.name = "Claw"
	unit.spells = [void, melee]

	unit.tags = [Tags.Arcane, Tags.Living]

	return unit

def FireSnake():

	unit = Unit()
	unit.max_hp = 9
	unit.name = "Fire Snake"
	unit.asset_name = "starfire_snake"

	unit.resists[Tags.Fire] = 100

	fire = SimpleRangedAttack(damage=8, radius=1, range=3, damage_type=Tags.Fire, cool_down=2)
	fire.name = "Fire"
	melee = SimpleMeleeAttack(3, buff=Poison, buff_duration=10)
	melee.name = "Bite"
	unit.spells = [fire, melee]

	unit.tags = [Tags.Fire, Tags.Living]
	return unit

def StarfireChimera():

	unit = Unit()
	unit.max_hp = 46

	unit.resists[Tags.Fire] = 75
	unit.resists[Tags.Arcane] = 75

	unit.name = "Starfire Chimera"

	fire = SimpleRangedAttack(damage=8, range=5, radius=2, damage_type=Tags.Fire, cool_down=2)
	fire.name = "Fire"
	void = SimpleRangedAttack(damage=8, beam=True, range=5, melt=True, damage_type=Tags.Arcane, cool_down=2)
	void.name = "Void"
	unit.spells = [fire, void]
	unit.tags = [Tags.Arcane, Tags.Fire, Tags.Living]

	unit.buffs.append(SpawnOnDeath([StarLion, FireSnake], 1))

	return unit


class GlassyGaze(Spell):

	def __init__(self):
		Spell.__init__(self)
		self.name = "Glassy Gaze"
		self.range = 12
		self.cool_down = 10
		self.duration = 3

	def cast(self, x, y):
		start = Point(self.caster.x, self.caster.y)
		target = Point(x, y)

		for point in Bolt(self.caster.level, start, target):
			self.caster.level.flash(point.x, point.y, Tags.Glassification.color)
			yield

		unit = self.caster.level.get_unit_at(x, y)
		unit.apply_buff(GlassPetrifyBuff(), self.duration)
		yield

	def get_description(self):
		return "Turns the target to glass for {dur} turns", {'dur':self.duration}

def GlassButterfly():
	demon = ButterflyDemon()
	demon.name = "Glass Butterfly"
	demon.shields = 16
	demon.tags.append(Tags.Glass)
	demon.shrink_text = 1
	return demon

def GlassGolem():
	golem = Golem()
	golem.name = "Glass Golem"
	golem.shields = 2
	golem.tags.append(Tags.Glass)
	golem.resists[Tags.Physical] = -100
	return golem

def GlassCockatrice():
	cockatrice = Cockatrice()
	cockatrice.name = "Glass Cockatrice"
	cockatrice.tags.append(Tags.Glass)
	cockatrice.spells[1] = GlassyGaze()
	cockatrice.shields = 2
	return cockatrice

def GiantFlamingSkull():
	unit = GiantSkull()
	
	unit.name = "Giant Flaming Skull"
	unit.asset_name = "giant_flaming_skull"
	
	fireball = SimpleRangedAttack(damage=25, damage_type=Tags.Fire, range=7, radius=4)
	fireball.name = "Giant Fireball"
	fireball.cool_down = 4

	unit.spells.append(fireball)

	unit.resists[Tags.Fire] = 100
	unit.tags.append(Tags.Fire)
	return unit

class PhoenixBuff(Buff):
	
	def on_init(self):
		self.owner_triggers[EventOnDeath] = self.on_death
		self.name = "Phoenix Fire"
		self.radius = 4

	def get_tooltip(self):
		return "On death, deal 25 [Fire] damage in a 4 tile burst, healing allies instead"

	def on_death(self, evt):

		for p in self.owner.level.get_points_in_ball(self.owner.x, self.owner.y, self.radius):
			unit = self.owner.level.get_unit_at(*p)
			if unit and not are_hostile(unit, self.owner):
				unit.deal_damage(-25, Tags.Heal, self)
			else:
				self.owner.level.deal_damage(p.x, p.y, 25, Tags.Fire, self)
	
	def can_threaten(self, x, y):
		return distance(self.owner, Point(x, y)) < self.radius

def Phoenix():

	phoenix = Unit()
	phoenix.max_hp = 125
	phoenix.name = "Phoenix"

	phoenix.tags = [Tags.Fire, Tags.Holy]

	phoenix.buffs.append(PhoenixBuff())
	phoenix.buffs.append(ReincarnationBuff(2))

	phoenix.flying = True

	phoenix.resists[Tags.Fire] = 100
	phoenix.resists[Tags.Dark] = -50

	phoenix.spells.append(SimpleRangedAttack(damage=9, range=5, damage_type=Tags.Fire))
	return phoenix	


class ArcanePhoenixBuff(Buff):

	def on_init(self):
		self.owner_triggers[EventOnDeath] = self.on_death
		self.name = "Phoenix Starfire"

	def get_tooltip(self):
		return "On death, deal 25 [Arcane] damage and melt walls in a 5 tile burst\nAllies gain [2 SH:shields] instead"

	def on_death(self, evt):

		for p in self.owner.level.get_points_in_ball(self.owner.x, self.owner.y, 5):
			unit = self.owner.level.get_unit_at(*p)
			if unit and not are_hostile(unit, self.owner): unit.add_shields(2)
			else: self.owner.level.deal_damage(p.x, p.y, 25, Tags.Arcane, self)
			if not self.owner.level.tiles[p.x][p.y].can_see: self.owner.level.make_floor(p.x, p.y)


def VoidPhoenix():
	phoenix = Unit()
	phoenix.max_hp = 250
	phoenix.name = "Void Phoenix"
	phoenix.asset_name = "cosmic_bird"

	phoenix.tags = [Tags.Arcane, Tags.Holy]

	phoenix.buffs.append(ArcanePhoenixBuff())
	phoenix.buffs.append(ReincarnationBuff(2))

	phoenix.flying = True

	phoenix.resists[Tags.Arcane] = 100
	phoenix.resists[Tags.Dark] = -50

	phoenix.spells.append(SimpleRangedAttack(damage=9, range=5, damage_type=Tags.Arcane, melt=True))
	phoenix.buffs.append(DamageAuraBuff(damage=3, damage_type=Tags.Arcane, melt_walls=True, radius=6))
	return phoenix

class RottingPhoenixBuff(Buff):

	def on_init(self):
		self.owner_triggers[EventOnDeath] = self.on_death
		self.name = "Phoenix Rotfire"
		self.damage = 25
		self.damage_type = [Tags.Dark, Tags.Fire]

	def get_tooltip(self):
		return "On death, deal 25 [Dark] and [Fire] damage and melt walls in a 5 tile burst\nUndead allies heal and gain max HP instead"

	def on_death(self, evt):
		o = self.owner
		lvl = o.level
		dmg = self.damage
		dtypes = self.damage_type

		for p in lvl.get_points_in_ball(o.x, o.y, 5):
			unit = lvl.get_unit_at(*p)
			for dtype in dtypes:
				if unit and not are_hostile(unit, self.owner) and Tags.Undead in unit.tags: unit.max_hp += dmg; unit.heal(dmg, self)
				else: self.owner.level.deal_damage(p.x, p.y, dmg, dtype, self)
			if not self.owner.level.tiles[p.x][p.y].can_see: self.owner.level.make_floor(p.x, p.y)

def RottingPhoenix():
	phoenix = Unit()
	phoenix.max_hp = 250
	phoenix.name = "Rotting Phoenix"

	phoenix.tags = [Tags.Dark, Tags.Fire, Tags.Undead, Tags.Holy]

	phoenix.buffs.append(RottingPhoenixBuff())
	phoenix.buffs.append(ReincarnationBuff(2))

	phoenix.flying = True

	phoenix.resists[Tags.Holy] = 50
	phoenix.resists[Tags.Fire] = 50

	phoenix.spells.append(SimpleRangedAttack(name= "Rotfire", damage=9, range=5, damage_type=[Tags.Dark, Tags.Fire], buff=NecrosisBuff, buff_duration=3, melt=True))
	phoenix.buffs.append(DamageAuraBuff(damage=3, damage_type=[Tags.Dark, Tags.Fire], melt_walls=True, radius=6, custom_name="Rotfire Aura"))
	return phoenix

class VolcanoTurtleBuff(Buff):

	def on_init(self):
		self.description = ("Each turn, spew 3 meteors within 4 tiles\n"
						    "Each meteor deals [8 Fire:fire] damage in a 2 tile burst\n"
						    "Direct hits deal [11 Physical:physical] damage, stun for 1 turn, and make floors")
		self.name = "Volcano Shell"

	def on_advance(self):
		possible_points = [p for p in self.owner.level.get_points_in_ball(self.owner.x, self.owner.y, 4) if distance(p, self.owner) > 1]
		for i in range(3): self.owner.level.queue_spell(self.meteor(random.choice(possible_points)))

	def can_threaten(self, x, y):
		return distance(self.owner, Point(x, y)) <= 6

	def meteor(self, target):

		self.owner.level.make_floor(target.x, target.y)
		self.owner.level.deal_damage(target.x, target.y, 11, Tags.Physical, self)
		unit = self.owner.level.get_unit_at(target.x, target.y)
		if unit: unit.apply_buff(Stun(), 1)
		yield

		deal_damage = self.owner.level.deal_damage
		for stage in Burst(self.owner.level, target, 2):
			for point in stage:
				deal_damage(point.x, point.y, 8, Tags.Fire, self)
		yield

def VolcanoTurtle():
	unit = Unit()
	unit.name = "Volcano Turtle"
	unit.max_hp = 395
	unit.resists[Tags.Fire] = 100
	unit.resists[Tags.Ice] = -50

	unit.buffs.append(TurtleBuff())
	unit.buffs.append(VolcanoTurtleBuff())

	unit.spells.append(SimpleMeleeAttack(damage=30))
	unit.tags = [Tags.Nature, Tags.Fire, Tags.Demon]
	return unit

class GlacialTurtleBuff(Buff):

	def on_init(self):
		self.name = "Ice Age Shell"
		self.damage = 8
		self.damage_type = Tags.Ice
		self.radius = 3
		self.duration = 3
		self.global_triggers[EventOnDeath] = self.on_death

	def get_description(self):
		return (("Each turn, enemies within [{radius} tiles:radius] take [{damage} Ice:ice] damage and [frozen] for [{duration}:duration] turns\n"
				"When a [frozen] unit within the radius dies to [Ice] damage, create a wall on its tile"), {"damage": self.damage, "duration": self.duration, "radius": self.radius})

	def on_death(self, evt):
		de = evt.damage_event
		if not de: return
		if de.damage_type != Tags.Ice: return
		if not evt.unit.has_buff(FrozenBuff): return
		self.owner.level.make_wall(evt.unit.x, evt.unit.y)
		tile = self.owner.level.tiles[evt.unit.x][evt.unit.y]
		self.owner.level.set_tile_style(tile, 'turtle', tile.chasm_type)

	def on_advance(self):
		o = self.owner
		lvl = o.level
		damage_type = self.damage_type
		dmg = self.damage
		dur = self.duration
		for p in lvl.get_points_in_ball(o.x, o.y, self.radius):
			unit = lvl.get_unit_at(p.x, p.y)
			if unit:
				if are_friendly(o, unit): continue
				unit.deal_damage(dmg, damage_type, self)
				unit.apply_buff(FrozenBuff(), dur)

			else:
				if random.random() < .5: continue
				lvl.show_effect(p.x, p.y, damage_type, minor=True)

	def can_threaten(self, x, y):
		return distance(self.owner, Point(x, y)) <= self.radius


def GlacialTurtle():
	unit = Unit()
	unit.name = "Glacial Turtle"
	unit.max_hp = 395
	unit.resists[Tags.Ice] = 100
	unit.resists[Tags.Fire] = -50

	unit.burrowing = True

	unit.buffs.append(TurtleBuff())
	unit.buffs.append(GlacialTurtleBuff())

	unit.spells.append(SimpleMeleeAttack(damage=30))
	unit.tags = [Tags.Nature, Tags.Ice, Tags.Demon]
	return unit

def Titan():
	unit = Unit()
	unit.name = "Titan"

	unit.max_hp = 394

	unit.resists[Tags.Fire] = 100
	unit.resists[Tags.Holy] = 75
	unit.resists[Tags.Dark] = 75

	fire = SimpleRangedAttack(damage=23, damage_type=Tags.Fire, range=7, radius=2, cool_down=4)
	melee = SimpleMeleeAttack(damage=35)

	unit.spells = [melee, fire]

	unit.tags = [Tags.Fire, Tags.Living, Tags.Holy]
	return unit

def Aesir():
	unit = Unit()
	unit.name = "Aesir"
	unit.max_hp = 121
	unit.shields = 3

	unit.resists[Tags.Lightning] = 100
	unit.resists[Tags.Holy] = 100
	unit.resists[Tags.Dark] = 75

	lightning = SimpleRangedAttack(damage=22, damage_type=Tags.Lightning, range=12, beam=True, cool_down=4)
	melee = SimpleMeleeAttack(29)

	unit.spells = [melee, lightning]

	unit.tags = [Tags.Lightning, Tags.Living, Tags.Holy]
	return unit

def FleshFiend():
	unit = Unit()
	unit.name = "Flesh Fiend"
	unit.asset_name = 'fleshy_mass'
	unit.max_hp = 431

	unit.buffs.append(RegenBuff(21))
	unit.spells.append(SimpleMeleeAttack(19))
	unit.tags = [Tags.Demon, Tags.Living]

	unit.resists[Tags.Physical] = -50

	return unit

def FlamingFleshFiend():
	unit = FleshFiend()
	unit.name = "Flaming Flesh Fiend"
	unit.asset_name = 'fleshy_mass_burning'
	unit.tags.append(Tags.Fire)
	unit.resists[Tags.Fire] = 100
	unit.buffs.append(DamageAuraBuff(10, Tags.Fire, 4, custom_name="Burning Aura"))
	return unit

def Reaper():
	unit = Unit()
	unit.name = "Reaper"
	unit.max_hp = 31
	unit.shields = 2
	unit.resists[Tags.Physical] = 100
	unit.resists[Tags.Dark] = 100

	touch = SimpleMeleeAttack(damage=200, damage_type=Tags.Dark)
	touch.name = "Death Touch"
	unit.flying = True
	unit.buffs.append(TeleportyBuff())

	unit.spells = [touch]

	unit.tags = [Tags.Undead, Tags.Dark]

	return unit

class WhirlWind(Spell):

	def on_init(self):
		self.name = "Reaping Scythe"
		self.melee = True
		self.damage = 200
		self.damage_type = [Tags.Dark]
		self.damage_type_random = False
		self.range = 1.5
		self.description = "Hits all adjacent enemies\nGains 1 Reincarnation on kill"

	def cast_instant(self, x, y):
		caster = self.caster
		level = caster.level
		adj_enemies = [u for u in level.get_adjacent_units(caster) if are_hostile(caster, u)]
		if not adj_enemies: return
		damage = self.get_stat('damage')
		dtypes = self.damage_type
		deal_damage = level.deal_damage
		b = caster.get_buff(ReincarnationBuff)
		if b: existing = True
		else: b = ReincarnationBuff(lives=0); existing = False
		kills = 0
		for u in adj_enemies:
			for dtype in dtypes:
				deal_damage(u.x, u.y, damage, dtype, self)
			if not u.is_alive(): b.lives += 1; kills += 1
		if kills and not existing: caster.apply_buff(b)


def WhirlwindReaper():
	u = Unit()
	u.name = "Whirlwind Reaper"
	u.asset_name = 'second_death'
	u.max_hp = 44
	u.shields = 4
	u.resists[Tags.Dark] = 100
	u.resists[Tags.Physical] = 100
	u.tags = [Tags.Undead, Tags.Dark]
	u.flying = True
	u.spells = [WhirlWind()]
	u.buffs = [QuickmoveBuff(), ReincarnationBuff(lives=2)]
	return u


def FloatingEyeMass():
	unit = FloatingEye()
	unit.name = "Mass of Eyes"
	unit.asset_name = "floating_eyeball_mass"
	unit.max_hp += 17
	unit.shields += 8
	unit.spells[0].radius = 2
	unit.spells[0].damage = 8
	unit.buffs.append(SpawnOnDeath(FloatingEye, 6))
	return unit

def Arbiter():
	u = Unit()
	u.name = "Arbiter"
	u.asset_name = 'holy_eye'
	u.max_hp = 80
	u.spells = [WideBeam(name="Arbiter Gaze", damage=8, damage_type=Tags.Holy, range=12)]
	u.flying = True
	u.tags = [Tags.Holy, Tags.Eye]
	u.resists[Tags.Holy] = 100
	u.resists[Tags.Physical] = 50
	return u

class GildedPyreBuff(Buff):
	def on_init(self):
		self.name = "Gilded Pyre"
		self.color = Tags.Fire.color
		self.global_triggers[EventOnDeath] = self.on_death

	def get_description(self):
		return "When a unit dies, gain +1 spell damage"

	def on_death(self, _):
		for s in self.owner.spells:
			if hasattr(s, 'damage') and s.damage:
				s.damage += 1


def GildedTyrant():
	u = Unit()
	u.name = "Gilded Tyrant"
	u.tags = [Tags.Holy, Tags.Dark, Tags.Fire, Tags.Metallic]
	u.max_hp = 1000
	u.flying = True
	u.resists[Tags.Fire] = 100
	u.resists[Tags.Physical] = 100
	u.resists[Tags.Dark] = 100
	u.resists[Tags.Holy] = 100
	u.resists[Tags.Ice] = 0

	beam = WideBeam(name="Solar Flare", damage=40, damage_type=Tags.Fire)
	beam.cool_down = 2

	touch = SimpleMeleeAttack(damage=99, buff=ImmobilizeBuff, buff_duration=10, damage_type=[Tags.Physical], drain=True)
	touch.name = "Gilded Grasp"
	touch.cool_down = 2

	u.spells = [touch, beam]
	u.buffs = [GildedPyreBuff()]

	return u

def GargoyleStatue():
	unit = Unit()
	unit.name = "Gargoyle Statue"
	unit.max_hp = 30
	unit.tags = [Tags.Metallic, Tags.Construct, Tags.Dark]
	unit.buffs.append(MatureInto(Gargoyle, 10))
	unit.resists[Tags.Dark] = 75
	unit.resists[Tags.Holy] = -50
	unit.stationary = True
	return unit

def Gargoyle():
	unit = Unit()
	unit.name = "Gargoyle"
	unit.flying = True
	unit.tags = [Tags.Metallic, Tags.Construct, Tags.Dark]
	unit.spells.append(SimpleMeleeAttack(12))
	unit.buffs.append(RespawnAs(GargoyleStatue))
	unit.max_hp = 60
	unit.resists[Tags.Dark] = 75
	unit.resists[Tags.Holy] = -50
	return unit

class WriteChaosScrolls(Spell):

	def on_init(self):
		self.name = "Scribe Chaos Scrolls"
		self.description = "Summons 2-4 Living Fireball or Living Lightning Scrolls"
		self.range = 0
		self.cool_down = 6
		self.extra_unit_tt_fns = [(LivingFireballScroll, True), (LivingLightningScroll, True)]

	def cast(self, x, y):
		for i in range(random.randint(2, 4)):
			unit = random.choice([LivingFireballScroll(), LivingLightningScroll()])
			self.summon(unit, sort_dist=False)
			yield

def ChaosQuill():
	unit = Unit()
	unit.name = "Chaos Quill"

	unit.max_hp = 15
	unit.shields = 6

	unit.spells.append(WriteChaosScrolls())

	unit.resists[Tags.Fire] = 75
	unit.resists[Tags.Lightning] = 75
	unit.resists[Tags.Arcane] = 100

	unit.stationary = True
	unit.flying = True
	unit.tags = [Tags.Chaos, Tags.Arcane, Tags.Construct]
	unit.buffs.append(TeleportyBuff(chance=.1, radius=5))
	return unit


# Ally bat- if an ally is in melee range of self and closer to target than self, can cast.
# Deals physical damage to target and to the ally, teleports the ally to a summon point near the player
# Does leap attack anim of ally
class CyclopsAllyBat(Spell):

	def on_init(self):
		self.name = "Swat Ally"
		self.description = "Bats an adjacent unit towards an enemy"
		self.damage = 13
		self.range = 8
		self.damage_type = Tags.Physical

	def get_chump(self, x, y):
		target = Point(x, y)
		adj_points = self.caster.level.get_adjacent_points(self.caster, filter_walkable=False)
		possible_chumps = []
		for p in adj_points:
			unit = self.caster.level.get_unit_at(p.x, p.y)
			if unit == self.caster: continue
			if not unit: continue
			if not self.caster.level.can_see(target.x, target.y, p.x, p.y): continue
			if unit.radius: continue
			possible_chumps.append(unit)
		if possible_chumps:
			return random.choice(possible_chumps)
		else:
			return None

	def can_cast(self, x, y):
		chump = self.get_chump(x, y)
		if chump is None: return False
		if not self.caster.level.get_summon_point(x, y, radius_limit=1, diag=True): return False
		return Spell.can_cast(self, x, y)

	def cast(self, x, y):
		
		target = self.caster.level.get_unit_at(x, y)
		if not target:
			return

		chump = self.get_chump(target.x, target.y)
		if not chump:
			return

		dest = self.caster.level.get_summon_point(x, y, radius_limit=1, diag=True)
		if not dest:
			return

		for p in self.caster.level.get_points_in_line(chump, dest, find_clear=True):
			self.caster.level.leap_effect(p.x, p.y, Tags.Physical.color, chump)
			yield

		self.caster.level.act_move(chump, dest.x, dest.y, teleport=True)
		
		target.deal_damage(self.get_stat('damage'), Tags.Physical, self)
		chump.deal_damage(self.get_stat('damage'), Tags.Physical, self)


# Enemy bat- if an enemy is in melee range, teleport the enemy to a random point in LOS (again with leap anim).
# The random point must be one such that the distance from the point to the enemy is less than point to the cyclops
class CyclopsEnemyBat(Spell):

	def on_init(self):
		self.name = "Swat Enemy"
		self.description = "Bat an enemy to a random tile in line of sight"
		self.damage = 13
		self.range = 1
		self.melee = True
		self.damage_type = Tags.Physical

	def get_destination(self, target):
		possibles = list(self.caster.level.get_points_in_los(self.caster))
		def is_valid_dest(dest):
			if self.caster.level.get_unit_at(dest.x, dest.y):
				return False
			if distance(dest, target) >= distance(dest, self.caster):
				return False
			if not self.caster.level.can_stand(dest.x, dest.y, target):
				return False
			return True

		possibles = [p for p in possibles if is_valid_dest(p)]
		if possibles:
			return random.choice(possibles)
		else:
			return None

	def cast(self, x, y):
		unit = self.caster.level.get_unit_at(x, y)
		if not unit:
			return
		# If the level is totally full, just whack the guy and call it a day
		unit.deal_damage(self.get_stat('damage'), Tags.Physical, self)
		target = self.get_destination(unit)
		if not target:
			return

		for p in self.caster.level.get_points_in_line(unit, target, find_clear=True):
			self.caster.level.leap_effect(p.x, p.y, Tags.Physical.color, unit)
			yield

		self.caster.level.act_move(unit, target.x, target.y, teleport=True)


def RedCyclops():
	unit = Unit()
	unit.name = "Red Cyclops"
	unit.max_hp = 256
	unit.spells.append(CyclopsEnemyBat())
	unit.spells.append(CyclopsAllyBat())
	unit.tags = [Tags.Living]
	return unit

class CoatlBreath(BreathWeapon):

	def __init__(self):
		BreathWeapon.__init__(self)
		self.name = "Emerald Breath"
		self.duration = 15
		self.damage = 3
		self.damage_type = Tags.Poison
		self.cool_down = 6
		self.range = 7
		self.angle = math.pi / 6.0

	def get_description(self):
		return "Cone attack\nEnemies are [poisoned] for {duration} turns\nAllies gain [1 SH:shields] instead"

	def per_square_effect(self, x, y, damage):
		unit = self.caster.level.get_unit_at(x, y)
		if unit and are_hostile(self.caster, unit):
			self.caster.level.deal_damage(x, y, damage, self.damage_type, self)
			unit.apply_buff(Poison(), self.get_stat('duration'))
		elif unit and not are_hostile(self.caster, unit):
			unit.add_shields(1)
		else:
			self.caster.level.deal_damage(x, y, 0, self.damage_type, self)

def FeatheredSerpent():
	unit = Unit()
	unit.max_hp = 97
	unit.shields = 1

	unit.flying = True

	unit.name = "Feathered Serpent"
	unit.asset_name = "coatl"

	teleport = MonsterTeleport()
	teleport.cool_down = 18
	teleport.range = RANGE_GLOBAL

	heal = HealAlly(25, range=10, tag=Tags.Living)
	heal.cool_down = 9

	abolt = SimpleRangedAttack(damage=3, damage_type=Tags.Arcane, range=5)
	abolt.cool_down = 2
	pbreath = CoatlBreath()

	melee = SimpleMeleeAttack(7)

	unit.spells = [pbreath, heal, abolt, melee]

	unit.resists[Tags.Poison] = 100
	unit.resists[Tags.Arcane] = 100
	unit.resists[Tags.Holy] = 100
	unit.resists[Tags.Dark] = -100

	unit.tags = [Tags.Living, Tags.Holy, Tags.Arcane]

	return unit

def LightningFlies():
	unit = FlyCloud()
	unit.name = "Lightning Bug Swarm"
	unit.asset_name = "fly_swarm_lightning"
	unit.spells = [SimpleRangedAttack(damage=1, damage_type=Tags.Lightning, range=3)]
	unit.resists[Tags.Lightning] = 75
	unit.tags.append(Tags.Lightning)
	return unit

class VengeanceBuff(Buff):

	def __init__(self, damage_type, damage, radius=4):
		self.damage_type = damage_type
		self.damage = damage
		self.radius = radius

		Buff.__init__(self)

	def on_init(self):
		self.name = "Vengeance"
		self.owner_triggers[EventOnDeath] = self.on_death

	def get_description(self):
		return (("On death, deal {damage} {tag} damage to a random enemy within {radius} tiles",
				{'damage':self.damage, 'tag':formatted_tag(self.damage_type), 'radius':self.radius}))

	def can_threaten(self, x, y):
		return distance(self.owner, Point(x, y)) <= self.radius

	def on_death(self, evt):
		targets = self.owner.level.get_units_in_ball(self.owner, self.radius)
		targets = [u for u in targets if are_hostile(self.owner, u)]

		if targets:
			target = random.choice(targets)
			for p in self.owner.level.get_points_in_line(self.owner, target):
				self.owner.level.show_effect(p.x, p.y, self.damage_type, minor=True)
			target.deal_damage(self.damage, self.damage_type, self)

def BlackCat():
	unit = Unit()
	unit.tags = [Tags.Living, Tags.Dark]
	unit.resists[Tags.Dark] = 75
	unit.resists[Tags.Holy] = -50
	unit.name = "Cursed Cat"
	unit.asset_name = "accursed_cat" # needs art
	unit.spells.append(SimpleMeleeAttack(2))
	unit.max_hp = 7
	unit.buffs.append(ReincarnationBuff(1))
	unit.buffs.append(VengeanceBuff(Tags.Dark, 4))
	return unit

def Zombie():
	unit = Unit()
	unit.tags = [Tags.Undead]
	unit.name = "Rotting Zombie"
	unit.asset_name = "zombie"
	unit.max_hp = 27
	unit.spells = [SimpleMeleeAttack(damage=5, buff=NecrosisBuff, buff_duration=3)]
	return unit

def RotSapling():
	unit = Unit()
	unit.name = "Rot Sprouts"
	unit.max_hp = 12

	unit.resists[Tags.Dark] = 100
	unit.resists[Tags.Physical] = 50
	unit.resists[Tags.Fire] = -100
	unit.resists[Tags.Ice] = -50

	unit.tags = [Tags.Dark, Tags.Nature]


	unit.spells.append(SimpleMeleeAttack(1, damage_type=Tags.Dark))
	unit.buffs.append(ChanceToBecome(RotTree, .02, name="Rot Tree"))
	unit.buffs.append(ChanceToBecome(Zombie, .02))

	unit.stationary = True
	return unit

def RotTree():
	unit = Unit()
	unit.name = "Rot Tree"
	unit.max_hp = 65

	unit.resists[Tags.Dark] = 100
	unit.resists[Tags.Physical] = 50
	unit.resists[Tags.Fire] = -100
	unit.resists[Tags.Ice] = -50

	unit.buffs.append(GeneratorBuff(RotSapling, .2))

	unit.tags = [Tags.Dark, Tags.Nature]

	unit.stationary = True
	return unit

def ZombieMass():
	unit = Unit()
	unit.tags = [Tags.Undead]
	unit.name = "Rotting Mass"
	unit.asset_name = "zombie_mass"
	unit.max_hp = 121
	unit.spells = [SimpleMeleeAttack(damage=15, buff=NecrosisBuff, buff_duration=15)]
	unit.buffs = [SpawnOnDeath(Zombie, 8)]
	return unit

def BarkLord():
	unit = Unit()
	unit.tags = [Tags.Nature, Tags.Living]
	unit.name = "Bark Lord"
	unit.asset_name = "bark_lord"

	swap = WizardSwap(Tags.Nature)
	swap.name = "Life Swap"
	swap.cool_down = 10

	unit.spells.append(SimpleSummon(Vine, num_summons=3, sort_dist=False, cool_down=15, radius=5))
	unit.spells.append(swap)
	unit.spells.append(SimpleMeleeAttack(22))

	unit.max_hp = 95

	unit.resists[Tags.Fire] = -100
	unit.resists[Tags.Physical] = 50

	unit.buffs.append(RegenBuff(6))
	return unit

def Elephant():
	unit = Unit()
	unit.max_hp = 60
	unit.name = "Pachyderm"
	unit.asset_name = "elephant"
	unit.tags = [Tags.Nature, Tags.Living]

	unit.spells.append(SimpleMeleeAttack(12, trample=True))
	unit.resists[Tags.Physical] = 50

	return unit


def RockWorm():
	unit = Unit()
	unit.max_hp = 25
	unit.name = "Rock Worm"

	unit.tags = [Tags.Living]

	unit.spells.append(SimpleMeleeAttack(7))

	unit.resists[Tags.Physical] = 50
	unit.resists[Tags.Lightning] = 50
	unit.resists[Tags.Fire] = 50
	unit.resists[Tags.Ice] = -50

	unit.burrowing = True
	return unit

def WormWizard():
	unit = Unit()
	unit.max_hp = 100
	unit.name = "Worm Wizard"
	unit.tags = [Tags.Living]

	unit.buffs.append(RegenBuff(10))

	from Spells import LifedrainSpell, Lumbriogenesis
	drain_spell = LifedrainSpell()
	drain_spell.tags = []
	drain_spell.max_charges = 0
	drain_spell.cool_down = 3
	drain_spell.stacking = 1
	drain_spell.damage = 6
	drain_spell.duration = 9
	drain_spell.range = 7

	lumbrio = SimpleSummon(WormShambler, 1, cool_down=6, radius=1)
	lumbrio.hp_cost = 50
	lumbrio.name = "Lumbriogenesis"

	def summon_worms(caster, target):
		worm = WormBall(5)
		worm.source = getattr(caster, 'source', None)
		if worm.source: apply_minion_bonuses(worm.source, worm)  # preserves minion bonuses
		caster.level.summon(caster, worm, target)

	spitworms = SimpleRangedAttack(damage=6, range=5, damage_type=Tags.Physical, onhit=summon_worms)
	spitworms.name = "Worm Bolt"
	spitworms.description = "Summons a Tiny Worm Ball next to the target"
	spitworms.add_unit_tooltip(SmallWormBall, True)

	unit.spells = [drain_spell, lumbrio, spitworms]

	unit.is_wizard = True

	return unit

class WormInfectionSpell(Spell):

	def on_init(self):
		self.name = "Worm Infection"
		self.description = "Target [Living] ally spawns 2 Worm Balls on death"
		self.range = 5
		self.cool_down = 12
		self.can_target_empty = False
		self.target_allies = True

	def can_cast(self, x, y):
		u = self.caster.level.get_unit_at(x, y)
		if not u:return False
		if Tags.Living not in u.tags: return False
		if u.has_buff(SpawnOnDeath):return False
		if "Worm" in u.name:return False
		return Spell.can_cast(self, x, y)

	def cast(self, x, y):
		u = self.caster.level.get_unit_at(x, y)
		buff = SplittingBuff(spawner=lambda: WormBall(u.max_hp // 2), children=2)
		buff.name = "Worm Infection"
		buff.color = Tags.Blood.color
		u.apply_buff(buff)
		for p in self.caster.level.get_points_in_line(self.caster, u)[1:-1]:
			self.owner.level.show_effect(p.x, p.y, Tags.Blood, minor=True)
			self.owner.level.show_effect(p.x, p.y, Tags.Poison, minor=True)
			yield

def BlueLion():
	lion = Unit()
	lion.name = "Blue Lion"
	lion.max_hp = 28

	lion.flying = True

	sheen_spell = ShieldSightSpell(cool_down=3, shields=2)
	sheen_spell.name = "Blue Lion Sheen"

	lion.spells.append(sheen_spell)
	lion.spells.append(SimpleMeleeAttack(7))

	lion.tags = [Tags.Nature, Tags.Arcane, Tags.Holy]
	lion.resists[Tags.Arcane] = 50
	lion.resists[Tags.Physical] = 50

	return lion

def Eagle():
	eagle = Unit()
	eagle.name = "Eagle"
	eagle.flying = True
	eagle.max_hp = 18
	eagle.shields = 0

	dive = LeapAttack(damage=6, range=5, is_leap=True)
	peck = SimpleMeleeAttack(damage=6)
	dive.name = 'Dive'
	peck.name = 'Claw'
	eagle.spells = [peck, dive]

	eagle.tags = [Tags.Living, Tags.Holy, Tags.Nature]
	return eagle

def StoneFish():
	unit = Unit()
	unit.max_hp = 75

	unit.name = "Stonefish"
	unit.asset_name = "stonefish"

	unit.tags = [Tags.Living, Tags.Arcane]

	unit.spells.append(SimpleRangedAttack(damage=4, damage_type=Tags.Physical, range=3))

	unit.resists[Tags.Physical] = 75
	unit.resists[Tags.Lightning] = 50
	unit.resists[Tags.Fire] = 50
	unit.resists[Tags.Ice] = -50

	unit.burrowing = True
	return unit

def StoneShark():
	u = Unit()
	u.name = "Stone Shark"
	u.asset_name = "great_stonefish"
	u.max_hp = 225
	u.tags = [Tags.Living, Tags.Arcane]
	leap = LeapAttack(damage=16, range=4)
	leap.cool_down = 3
	leap.quick_cast = True
	u.spells = [leap, SimpleMeleeAttack(damage=16, attacks=3)]
	u.buffs = [QuickmoveBuff()]
	u.burrowing = True

	u.resists[Tags.Physical] = 75
	u.resists[Tags.Lightning] = 75
	u.resists[Tags.Fire] = 75
	u.resists[Tags.Arcane] = 75

	u.resists[Tags.Ice] = -75


	return u

def StarSwimmer():
	unit = Unit()
	unit.max_hp = 30
	unit.shields = 2

	unit.name = "Star Swimmer"
	unit.tags = [Tags.Arcane]

	unit.resists[Tags.Arcane] = 100

	phasebolt = SimpleRangedAttack(damage=3, range=6, damage_type=Tags.Arcane, radius=2)
	phasebolt.onhit = lambda caster, target: randomly_teleport(target, 4)
	phasebolt.name = "Phase Blast"
	phasebolt.description = "Teleports targets up to 4 tiles"

	unit.spells.append(phasebolt)
	unit.flying=True
	unit.stationary=True

	unit.buffs.append(TeleportyBuff(chance=.1, radius=10))

	return unit

def AnimatedArmor():
	u = Unit()
	u.name = "Animated Armor"
	u.tags = [Tags.Construct, Tags.Metallic, Tags.Arcane]
	u.max_hp = 50
	u.shields = 1
	u.resists[Tags.Arcane] = 75
	u.flying = True

	u.spells = [SimpleMeleeAttack(damage=5, trample=True)]
	u.buffs =[RetaliationBuff(1, Tags.Arcane)]

	return u

def SentientShield():
	u = Unit()
	u.name = "Sentient Shield"
	u.tags = [Tags.Construct, Tags.Metallic, Tags.Arcane]
	u.max_hp = 18
	u.shields = 2
	u.resists[Tags.Arcane] = 100
	def shield_shove(caster, target): push(target, caster, 1)
	u.spells = [SimpleMeleeAttack(damage=5, onhit=shield_shove, onhit_description="On hit, push the target 1 tile")]
	u.buffs = [ShieldRegenBuff(2, 2)]
	return u


def DancingBlade():
	unit = Unit()
	unit.name = "Dancing Blade"
	unit.asset_name = "spectral_blade"
	unit.max_hp = 9
	unit.shields = 2

	unit.spells.append(LeapAttack(damage=9, range=3))

	unit.flying = True

	unit.tags = [Tags.Construct, Tags.Metallic, Tags.Arcane]

	unit.resists[Tags.Arcane] = 100

	return unit

def SwordOfLight():
	unit = Unit()
	unit.name = "Sword of Light"
	unit.asset_name = "dancing_blade_holy" # temporary until they have their own asset
	unit.max_hp = 12
	unit.shields = 3

	unit.spells.append(LeapAttack(damage=9, range=3, damage_type=Tags.Holy))
	unit.flying = True
	unit.tags = [Tags.Construct, Tags.Holy, Tags.Metallic]
	unit.resists[Tags.Holy] = 100
	return unit

def ArcaneBlacksmith():
	u = Unit()
	u.name = "Arcane Blacksmith"
	u.max_hp = 75
	u.stationary = True
	u.tags = [Tags.Arcane,Tags.Metallic]

	sword = SimpleSummon(DancingBlade, 1, cool_down=5)
	sword.name = "Forge Blade"
	shield = SimpleSummon(SentientShield, 1, cool_down=5)
	shield.name = "Forge Shield"
	armor = SimpleSummon(AnimatedArmor, 1, cool_down=5)
	armor.name = "Forge Armor"

	u.resists[Tags.Lightning] = 0

	u.spells = [sword, shield, armor]

	return u

def AnimatedKnight():
	u = Unit()
	u.name = "Animated Knight"
	u.max_hp = 75
	u.tags = [Tags.Construct, Tags.Metallic, Tags.Arcane]
	u.resists[Tags.Arcane] = 100

	def shield_shove(caster, target): push(target, caster, 2)
	shield = SimpleMeleeAttack(damage=12, onhit=shield_shove, onhit_description="On hit, push the target 2 tiles")
	u.spells = [shield]
	u.buffs = [ShieldRegenBuff(2, 2), RetaliationBuff(1, Tags.Arcane), SpawnOnDeath([DancingBlade, SentientShield, AnimatedArmor], 1)]
	return u

class CurseReflection(Buff):

	def on_init(self):
		self.name = "Curse Reflection"
		self.description = "Debuffs that would be applied to this unit are instead delivered to the target of its next attack"
		self.owner_triggers[EventOnBuffAttemptApply] = self.on_attempt_debuff
		self.owner_triggers[EventOnSpellCast] = self.on_cast
		self.curses = []

	def on_applied(self, owner):
		owner.debuff_immune = True

	def on_attempt_debuff(self, evt):
		if evt.buff.buff_type != BUFF_TYPE_CURSE: return
		self.curses.append((evt.buff, evt.duration))

	def on_cast(self, evt):
		u = self.owner.level.get_unit_at(evt.x, evt.y)
		if not u or not are_hostile(self.owner, u): return
		while self.curses:
			curse, duration = self.curses.pop()
			u.apply_buff(curse, duration)


class SelfReflectionSpell(Spell):

	def on_init(self):
		self.name = "Self Reflection"
		self.description = "Channel for 8 turns, then summon a Gelid Mirror in line of sight"
		self.range = 0
		self.tt_color = Tags.Glass.color
		self.max_channel = 8

	def cast(self, x, y, channel_cast=False):
		if not channel_cast and self.is_manual_cast():
			self.caster.apply_buff(ChannelBuff(self.cast, Point(x, y), cast_after_channel=True), self.max_channel)
			return

		caster = self.caster
		can_stand = caster.level.can_stand
		u = GelidMirror()
		targets = [p for p in caster.level.get_points_in_los(caster) if can_stand(p.x, p.y, u)]
		if not targets: return
		target = random.choice(targets)
		caster.level.show_beam(caster, target, Tags.Ice, minor=True)
		self.summon(u, target=target, radius=0)
		yield


def GelidMirror():
	u = Unit()
	u.name = "Gelid Mirror"
	u.max_hp = 285
	u.debuff_immune = True

	u.tags = [Tags.Ice, Tags.Glass, Tags.Construct]
	u.resists[Tags.Ice] = 75
	u.resists[Tags.Lightning] = 75

	u.resists[Tags.Physical] = -100
	u.resists[Tags.Fire] = -100

	u.spells = [SimpleRangedAttack(damage=10, damage_type=Tags.Ice, range=6, beam=True), SelfReflectionSpell()]
	u.buffs = [CurseReflection()]

	return u

class ScarecrowBuff(Buff):

	def on_init(self):
		self.name = "Scary"
		self.description = "Damaging [Nature] or [Living] units afflicts them with [fear] for 3 turns"
		self.global_triggers[EventOnDamaged] = self.on_damage

	def on_damage(self, evt):
		if not (evt.source and evt.source.owner and evt.source.owner is self.owner): return
		if not any(t in [Tags.Nature, Tags.Living] for t in evt.unit.tags): return
		if not evt.unit.is_alive(): return
		evt.unit.apply_buff(FearBuff(), 3)

def Scarecrow():
	u = Unit()
	u.name = "Scarecrow"
	u.tags = [Tags.Nature, Tags.Dark]
	u.max_hp = 25
	u.resists[Tags.Dark] = 75

	u.stationary = True

	s = WailOfPain()
	s.radius = 5
	s.name = "Scare"
	s.damage = 1
	s.cool_down = 0

	u.spells.append(s)

	u.buffs.append(ScarecrowBuff())

	return u

def Pumpkinhead():
	u = Unit()
	u.name = "Pumpkinhead"
	u.tags = [Tags.Nature, Tags.Dark, Tags.Fire]
	u.max_hp = 15
	u.resists[Tags.Fire] = 50
	u.resists[Tags.Dark] = 50

	s = FireBreath()
	s.damage = 5
	s.range = 3

	m = PullAttack(damage=3, range=3, color=Tags.Nature.color)

	u.spells = [s, m]

	return u

def Vine():
	u = Unit()
	u.name = "Vine"
	u.max_hp = 3
	u.tags = [Tags.Nature]
	u.stationary = True
	pull = PullAttack(damage=3, range=3, color=Tags.Nature.color)
	u.spells.append(pull)
	return u

class SnakePhilosophy(Spell):

	def on_init(self):
		self.name = "Enlighten Serpent"
		self.description = "Sacrifice a Snake to summon a random Drake"
		self.range = 9
		self.cool_down = 5
		self.target_allies = True

	def cast_instant(self, x, y):
		unit = self.caster.level.get_unit_at(x, y)
		assert(unit)
		p = Point(unit.x, unit.y)
		unit.kill(trigger_death_event=False)
		drake, path_type = random.choice([(FireDrake(), Tags.Fire), (StormDrake(), Tags.Lightning), (VoidDrake(), Tags.Arcane)])
		drake = self.summon(drake, target=p)
		if drake: self.owner.level.show_path_effect(self.caster, drake, path_type, minor=True)

	def can_cast(self, x, y):
		unit = self.caster.level.get_unit_at(x, y)
		return unit and unit.name == "Snake" and Spell.can_cast(self, x, y)

	def get_ai_target(self):
		candidates = [u for u in self.caster.level.get_units_in_los(self.caster) if u.name == "Snake"]
		candidates = [c for c in candidates if self.can_cast(c.x, c.y)]
		if candidates: return random.choice(candidates)

def SerpentPhilosopher():
	unit = Unit()
	unit.asset_name = "serpent_philosopher"
	unit.name = "Slazephan the Philosopher"
	unit.max_hp = 94

	unit.spells.append(SimpleSummon(Snake, num_summons=8, cool_down=20))
	unit.spells.append(SnakePhilosophy())
	heal = HealAlly(50, range=10)
	heal.cool_down = 8
	heal.name = "Heal"
	unit.spells.append(heal)
	unit.spells.append(SimpleRangedAttack(damage=5, damage_type=Tags.Poison, range=6))

	unit.resists[Tags.Fire] = 50
	unit.resists[Tags.Poison] = 100

	unit.tags = [Tags.Living, Tags.Nature]
	unit.is_wizard = True
	return unit

def TwoHeadedSnake():
	unit = Snake()
	unit.name = "Two Headed Snake"
	unit.asset_name = 'two_headed_snake'
	unit.max_hp *= 2
	unit.buffs.append(SpawnOnDeath(Snake, 2))
	return unit

def BrainSapling():
	unit = Unit()
	unit.name = "Brain Sapling"
	unit.max_hp = 12

	unit.resists[Tags.Arcane] = 100
	unit.resists[Tags.Physical] = 50
	unit.resists[Tags.Fire] = -100
	unit.resists[Tags.Ice] = -50

	unit.tags = [Tags.Arcane, Tags.Nature]


	unit.spells.append(SimpleMeleeAttack(1, damage_type=Tags.Arcane))
	unit.buffs.append(ChanceToBecome(BrainTree, .02, name="Brain Tree"))

	unit.stationary = True
	return unit

def BrainTree():
	unit = Unit()
	unit.name = "Brain Tree"
	unit.max_hp = 65

	unit.resists[Tags.Arcane] = 100
	unit.resists[Tags.Physical] = 50
	unit.resists[Tags.Fire] = -100
	unit.resists[Tags.Ice] = -50

	unit.spells.append(SimpleRangedAttack(damage=3, damage_type=Tags.Arcane, range=7))

	unit.buffs.append(GeneratorBuff(BrainSapling, .2))

	unit.tags = [Tags.Arcane, Tags.Nature]

	unit.stationary = True
	return unit


class WizardImpPrison(Spell):

	def on_init(self):
		self.name = "Prison of Imps"
		self.description = "Surround enemies with Imps"
		self.cool_down = 5
		self.range = 11
		self.imps = [FireImp, SparkImp, IronImp]

	# Do not allow casting if it would result in 0 imps
	def can_cast(self, x, y):
		if not self.caster.level.get_adjacent_points(Point(x, y), filter_walkable=False, check_unit=True):
			return False
		return Spell.can_cast(self, x, y)

	def get_impacted_tiles(self, x, y):

		candidates = {Point(x, y)}
		unit_group = set()

		while candidates:
			candidate = candidates.pop()
			unit = self.caster.level.get_unit_at(candidate.x, candidate.y)
			if unit and unit not in unit_group and are_hostile(unit, self.caster):
				unit_group.add(unit)

				for p in self.caster.level.get_adjacent_points(Point(unit.x, unit.y), filter_walkable=False):
					candidates.add(p)

		outline = set()
		for unit in unit_group:
			for p in self.caster.level.get_adjacent_points(Point(unit.x, unit.y)):
				if not self.caster.level.get_unit_at(p.x, p.y):
					outline.add(p)

		return list(outline)

	def get_unit(self, imp):
		u = imp()
		src = getattr(getattr(self, 'caster', None), 'source', None)
		if src: u.source = src; apply_minion_bonuses(src, u)
		return u

	def get_unit_extra_examine_tooltips(self):
		return [self.get_unit(c) for c in self.imps]

	def cast(self, x, y):
		target_points = self.get_impacted_tiles(x, y)
		random.shuffle(target_points)
		for p in target_points:
			unit = self.get_unit(random.choice(self.imps))
			self.summon(unit, p, radius=0)
			yield


class WizardDemonicPromotion(Spell):

	def on_init(self):
		self.name = "Demonic Promotion"
		self.description = "Transforms an Imp into a Fiend"
		self.range = 10
		self.cool_down = 30
		self.target_allies = True
		self.imps_to_demons = [(FireImp, FireFiend), (SparkImp, StormFiend), (IronImp, IronFiend)]
		self.imp_names = [c[0]().name for c in self.imps_to_demons]
		self.extra_unit_tt_fns = [(c[1], False) for c in self.imps_to_demons]

	def can_cast(self, x, y):
		unit = self.caster.level.get_unit_at(x, y)
		if not unit: return False
		if Tags.Demon not in unit.tags: return False
		if unit.name not in self.imp_names: return False
		return Spell.can_cast(self, x, y)

	def cast_instant(self, x, y):
		unit = self.caster.level.get_unit_at(x, y)
		if not unit: return
		if Tags.Demon not in unit.tags: return
		if unit.name not in self.imp_names: return
		unit.kill(trigger_death_event=False)
		idx = self.imp_names.index(unit.name)
		fiend = self.imps_to_demons[idx][1]()
		if fiend: self.summon(fiend, target=Point(unit.x, unit.y))


def GrandWarlock():
	unit = Unit()
	unit.name = "Grand Warlock"

	unit.max_hp = 133
	unit.shields = 1

	unit.resists[Tags.Fire] = 75
	unit.resists[Tags.Lightning] = 75
	unit.resists[Tags.Physical] = 50

	unit.tags = [Tags.Chaos]

	# Spells
	# Annihilate
	# Imp Prison
	# Demonic Promotion
	from Spells import AnnihilateSpell
	wizard_annihilate = AnnihilateSpell()
	wizard_annihilate.tags = []
	wizard_annihilate.max_charges = 0
	wizard_annihilate.damage = 7
	wizard_annihilate.range = 4

	imp_prison = WizardImpPrison()

	demonic_promotion = WizardDemonicPromotion()

	unit.spells = [imp_prison, demonic_promotion, wizard_annihilate]
	unit.is_wizard = True
	return unit

class WarlockChaosBarrage(Spell):

	def on_init(self):
		self.name = "Chaos Strike"
		self.description = "Shoot a bolt of each damage type at random enemies"
		self.random_damage_type = True
		self.range = 4
		self.damage = 6
		self.damage_type = [Tags.Fire, Tags.Lightning, Tags.Physical]

	def cast(self, x, y):
		o = self.owner
		l = o.level
		can_see = l.can_see
		targets = [u for u in l.get_units_in_ball(o, self.get_stat('range')) if are_hostile(o, u) and can_see(o.x, o.y, u.y, u.y)]
		if not targets: return
		dmg = self.get_stat('damage')
		for i in range(3):
			target = random.choice(targets)
			l.show_beam(o, target, self.damage_type[i], minor=True)
			l.deal_damage(target.x, target.y, dmg, self.damage_type[i], self)
			yield

class ImpCollectorSummonImpSpell(SimpleSummon):

	def __init__(self):
		SimpleSummon.__init__(self, RandomImp, num_summons=3, cool_down=6, duration=5)
		self.name = "Imp Gate"
		self.description = "Summons 3 temporary Imps"
		self.imps = [FireImp, SparkImp, IronImp]

	def cast(self, x, y, channel_cast=False):
		if self.max_channel and not channel_cast and self.is_manual_cast(): self.caster.apply_buff(ChannelBuff(self.cast, Point(x, y)), self.max_channel); return
		if self.suicide: self.caster.kill()
		target = Point(x, y)
		for i in range(self.num_summons):
			unit = self.get_imp(random.choice(self.imps))
			summoned_unit = self.summon(unit, target, sort_dist=self.sort_dist, radius=self.radius)
			if not summoned_unit: return # abort if self.summon returns None
			if self.path_effect: self.owner.level.show_path_effect(self.owner, summoned_unit, self.path_effect, minor=True)
			yield

	def get_imp(self, imp):
		u = imp()
		u.turns_to_death = self.duration
		src = getattr(getattr(self, 'caster', None), 'source', None)
		if src: u.source = src; apply_minion_bonuses(src, u)
		return u

	def get_unit_extra_examine_tooltips(self):
		return [self.get_imp(c) for c in self.imps]

def ImpCollector():
	unit = Unit()
	unit.name = "Imp Collector"
	unit.tags = [Tags.Demon, Tags.Chaos]
	unit.max_hp = 66

	unit.resists[Tags.Dark] = 50
	unit.resists[Tags.Fire] = 50
	unit.resists[Tags.Lightning] = 50
	unit.resists[Tags.Physical] = 50

	swap = WizardSwap(Tags.Demon)
	swap.name = "Fiend Swap"
	swap.cool_down = 7

	unit.spells = [ImpCollectorSummonImpSpell(), swap, WarlockChaosBarrage()]

	return unit

def BreathStealer():
	unit = DisplacerBeast()
	unit.name = "Breathstealer"
	unit.tags.append(Tags.Dark)
	unit.spells[0] = SimpleMeleeAttack(3, buff=Silence, buff_duration=3)
	return unit

def FaeSniper():
	unit = Unit()
	unit.name = "Fae Huntsman"
	unit.asset_name = "fae_marksman"
	unit.max_hp = 18

	unit.shields = 2
	unit.tags = [Tags.Arcane, Tags.Living]
	unit.resists[Tags.Arcane] = 50

	bow = SimpleRangedAttack(damage=3, range=7, proj_name="kobold_arrow", buff=Silence, buff_duration=1)
	unit.spells = [bow]

	return unit

class SilenceAura(DamageAuraBuff):
 
	def __init__(self):
		DamageAuraBuff.__init__(self, damage=0, damage_type=Tags.Dark, radius=5)
		self.description = "Each turn, afflict enemies within 5 tiles with Silence for 2 turns"


	def on_hit(self, unit):
		unit.apply_buff(Silence(), 2)

	def get_tooltip(self):
		return self.description

def SilentSpecter():
	unit = Ghost()
	unit.name = "Silent Specter"
	unit.max_hp = 16
	unit.asset_name = 'silent_specter'

	unit.buffs.append(SilenceAura())

	return unit

def FireElemental():
	elemental = Unit()
	elemental.name = 'Fire Elemental'
	elemental.spells.append(SimpleRangedAttack("Elemental Fire", damage=7, damage_type=Tags.Fire, range=4))
	elemental.resists[Tags.Fire] = 100
	elemental.resists[Tags.Physical] = 50
	elemental.resists[Tags.Ice] = -100
	elemental.max_hp = 22
	elemental.tags = [Tags.Fire]
	return elemental

def StarfireElemental():
	elemental = Unit()
	elemental.name = 'Starfire Elemental'
	elemental.spells.append(SimpleRangedAttack("Elemental Starfire", damage=7, damage_type=[Tags.Fire, Tags.Arcane], range=4))
	elemental.resists[Tags.Fire] = 100
	elemental.resists[Tags.Arcane] = 100
	elemental.resists[Tags.Physical] = 50
	elemental.resists[Tags.Ice] = -100
	elemental.max_hp = 22
	elemental.tags = [Tags.Fire, Tags.Arcane]
	elemental.shields = 1
	return elemental

def EarthElemental():
	ele = Unit()
	ele.name = "Earth Elemental"
	ele.add_spell(SimpleMeleeAttack(20))
	ele.max_hp = 120
	ele.stationary = True
	ele.resists[Tags.Physical] = 50
	ele.resists[Tags.Fire] = 50
	ele.resists[Tags.Lightning] = 50
	ele.resists[Tags.Poison] = 100
	ele.tags = [Tags.Nature]
	return ele

def SteamElemental():
	u = Unit()
	u.name = "Steam Elemental"
	u.tags = [Tags.Fire, Tags.Ice]
	u.resists[Tags.Fire] = 100
	u.resists[Tags.Ice] = 100
	u.resists[Tags.Physical] = 50
	u.max_hp = 20
	u.spells = [SimpleRangedAttack(name="Steam Shot", damage=10, damage_type=Tags.Fire, range=4, buff=SoakedBuff, buff_duration=3)]
	return u

def GiantBear():
	bear = Unit()
	bear.name = "Giant Bear"
	bear.max_hp = 100
	swipe = SimpleMeleeAttack(10, attacks=2)
	bear.spells.append(swipe)
	bear.tags = [Tags.Living, Tags.Nature]
	return bear

class VenomBeastHealing(Buff):

	def on_init(self):
		self.name = "Venom Drinker"
		self.description = "When a unit takes [Poison] damage, heal for that much"
		self.global_triggers[EventOnDamaged] = self.on_damage

	def on_damage(self, evt):
		if evt.damage_type != Tags.Poison:
			return
		self.owner.deal_damage(-evt.damage, Tags.Heal, self)

def VenomBear():
	bear = GiantBear()
	bear.name = "Venom Bear"
	bear.asset_name = "giant_bear_venom"
	bear.resists[Tags.Poison] = 100
	bear.tags = [Tags.Living, Tags.Poison, Tags.Nature]

	bite = SimpleMeleeAttack(damage=10, buff=Poison, buff_duration=5, attacks=2)
	bite.name = "Poison Bite"
	bear.spells = [bite]
	bear.buffs = [VenomBeastHealing()]
	return bear

class Hibernate(Spell):

	def on_init(self):
		self.name = "Hibernate"
		self.description = "[Freeze] caster for 4 turns"
		self.duration = 4
		self.healing = 20

		self.cool_down = 9
		self.range = 0
		self.can_target_self = True
		self.target_allies = True

	def can_cast(self, x, y):
		return self.caster.cur_hp <= self.caster.max_hp - 15 and Spell.can_cast(self, x, y)

	def cast_instant(self, x, y):
		self.caster.apply_buff(FrozenBuff(), self.get_stat('duration'))

class IcyMetabolism(Buff):

	def on_init(self):
		self.name = "Icy Metabolism"
		self.color = Tags.Ice.color
		self.heal = 10

	def get_tooltip(self):
		return "Heal {heal} HP each turn while Frozen", {'heal':self.heal}

	def on_advance(self):
		if self.owner.has_buff(FrozenBuff):
			self.owner.deal_damage(-self.heal, Tags.Heal, self)


def PolarBear():

	unit = GiantBear()
	unit.name = "Polar Bear"
	unit.spells.insert(0, Hibernate())
	unit.buffs.append(IcyMetabolism())
	unit.resists[Tags.Ice] = 50
	unit.resists[Tags.Fire] = -50
	unit.tags.append(Tags.Ice)
	return unit

def ArmoredPolarBear():
	unit = PolarBear()
	unit.name = "Armored Polar Bear"
	unit.asset_name = "polar_bear_armored"
	unit.resists[Tags.Physical] = 50
	unit.resists[Tags.Lightning] = -50
	unit.tags.append(Tags.Metallic)
	return unit

def BloodBear():

	unit = GiantBear()
	unit.name = "Blood Bear"
	unit.tags = [Tags.Nature, Tags.Demon, Tags.Blood]
	unit.resists[Tags.Dark] = 75
	melee = unit.get_spell(SimpleMeleeAttack)
	melee.onhit = bloodrage()
	melee.name = "Frenzy Claw"
	melee.onhit_description = "On hit, gain +2 damage for 10 turns"
	add_tooltip(unit, BloodrageBuff(2))
	return unit

class WaterElementalRegenBuff(Buff):

	def on_init(self):
		self.color = Tags.Nature.color
		self.description = "Heal 15 HP each turn while Soaked, otherwise die"

	def on_advance(self):
		if self.owner.has_buff(SoakedBuff): self.owner.heal(15, self)
		else: self.owner.kill()

def WaterElemental():
	unit = Unit()
	unit.tags = [Tags.Nature]
	unit.name = 'Water Elemental'

	unit.max_hp = 40

	trample = SimpleMeleeAttack(9, trample=True, buff=SoakedBuff, buff_duration=3)

	unit.resists[Tags.Fire] = 50
	unit.resists[Tags.Ice] = 50
	unit.resists[Tags.Physical] = 75

	unit.spells.append(trample)
	unit.buffs = [WaterElementalRegenBuff()]

	return unit

def Leghead():
	u = Unit()
	u.name = "Leghead"
	u.tags = [Tags.Arcane, Tags.Dark]
	u.max_hp = 45
	u.shields = 3

	bite = SimpleMeleeAttack(damage=12, buff=FearBuff, buff_duration=1)
	bite.name = "Big Bite"
	u.spells = [bite]
	u.buffs = [QuickmoveBuff()]

	u.resists[Tags.Dark] = 100
	u.resists[Tags.Arcane] = 50

	return u

def VoidChild():
	u = Unit()
	u.name = "Void Child"
	u.tags = [Tags.Arcane, Tags.Dark]
	u.max_hp = 8
	u.shields = 1
	u.resists[Tags.Arcane] = 50
	u.resists[Tags.Physical] = 50
	u.spells = [SimpleRangedAttack(name="Void Stare", damage=3, damage_type=[Tags.Arcane, Tags.Dark], range=3, beam=True, buff=FearBuff, buff_duration=1,  max_channel=3)]
	return u

def VoidElder():
	u = Unit()
	u.name = "Void Elder"
	u.tags = [Tags.Arcane, Tags.Dark]
	u.max_hp = 80
	u.shields = 3
	u.resists[Tags.Arcane] = 75
	u.resists[Tags.Dark] = 75
	u.resists[Tags.Physical] = 75
	u.spells = [SimpleRangedAttack(name="Void Stare", damage=10, damage_type=[Tags.Arcane, Tags.Dark], range=4, beam=True, buff=FearBuff, buff_duration=1,  max_channel=3)]
	u.buffs = [ShieldRegenBuff(shield_max=3,shield_freq=3)]
	return u

def VoidAncestor():
	u = Unit()
	u.name = "Void Ancestor"
	u.tags = [Tags.Arcane, Tags.Dark]
	u.max_hp = 240
	u.shields = 12
	u.resists[Tags.Arcane] = 100
	u.resists[Tags.Dark] = 100
	u.resists[Tags.Physical] = 75
	u.spells = [SimpleRangedAttack(name="Void Stare", damage=20, damage_type=[Tags.Arcane, Tags.Dark], range=5, beam=True, buff=FearBuff, buff_duration=1,  max_channel=3)]
	u.buffs = [RegenShieldsBuff(sh=2)]
	return u

def Executioner():
	u = Unit()
	u.name = "Executioner"
	u.tags = [Tags.Undead, Tags.Dark]
	u.max_hp = 144
	axe = SimpleMeleeAttack(damage=40)
	axe.name = "Execute"

	grab = SimpleMeleeAttack(damage=3, buff=ImmobilizeBuff, buff_duration=3)
	grab.name = "Grab"
	grab.cool_down = 3

	u.spells = [grab, axe]
	return u

class LimbCollectionBuff(Buff):

	def on_init(self):
		self.name = "Limb Collection"
		self.color = Tags.Undead.color
		self.global_triggers[EventOnDeath] = self.on_death
		self.owner_triggers[EventOnMoved] = self.on_move
		self.counter = 0
		self.counter_max = 4

	def get_description(self):
		desc = ['Collects a limb whenever it takes a step or an adjacent unit dies\n\nAfter collecting 4 limbs, a Bone Shambler is spawned nearby']
		if self.owner: desc.append(('\n\nCollected: {c} / {cmax}', {'c':self.counter, 'cmax':self.counter_max}))
		return desc

	def on_death(self, evt):
		if evt.unit == self.owner: return
		if not self.owner.level.are_adjacent(self.owner, evt.unit): return
		self.counter += 1

	def on_move(self, evt):
		self.counter += 1

	def on_advance(self):
		if self.counter < self.counter_max: return
		while self.counter >= self.counter_max:
			self.counter -= self.counter_max
			self.owner.level.queue_spell(self.do_summon())

	def do_summon(self):
		self.summon(BoneShambler())
		yield

	def get_unit_extra_examine_tooltips(self):
		return [BoneShambler()]

def LimbCollector():
	u = Unit()
	u.name = "Limb Collector"
	u.tags = [Tags.Dark, Tags.Undead]
	u.max_hp = 128
	u.spells = [SimpleMeleeAttack(damage=11, buff=Stun, buff_duration=1)]
	u.buffs = [LimbCollectionBuff()]
	return u


def Hornet():
	u = Unit()
	u.name = "Giant Hornet"
	u.asset_name = 'hornet'
	u.max_hp = 3
	u.tags = [Tags.Nature, Tags.Living]
	u.flying = True
	u.spells = [SimpleMeleeAttack(damage=1, buff=Poison, buff_duration=3)]

	return u

def SkullHornet():
	u = Unit()
	u.name = "Skull Hornet"
	u.max_hp = 9
	u.tags = [Tags.Nature, Tags.Undead]
	u.flying = True
	u.buffs = [QuickmoveBuff()]
	u.spells = [SimpleMeleeAttack(damage=3, buff=NecrosisBuff, buff_duration=3, attacks=3)]

	return u

def StringedPuppet():
	u = Unit()
	u.name = "Stringed Puppet"
	u.asset_name = "wooden_boy"
	u.max_hp = 5
	u.tags = [Tags.Construct]
	u.resists[Tags.Fire] = -100
	u.spells = [PullAttack(3, color=Tags.Physical.color), SimpleMeleeAttack(damage=3)]
	return u

def HeadCannon():
	u = Unit()
	u.name = "Head Cannon"
	u.asset_name = 'cannon_boy'
	u.max_hp = 12
	u.tags = [Tags.Construct, Tags.Metallic, Tags.Fire]
	u.spells = [SimpleRangedAttack(name="Cannonball", damage=18, damage_type=Tags.Physical, range=5, radius=1, proj_name='rock_cyclops')]
	u.buffs = [DeathExplosion(18, 3, Tags.Fire, custom_name="Death Combustion", custom_color=Tags.Fire.color)]
	return u

class AttachedBuff(Buff):

	def __init__(self, attached_unit):
		self.attached_unit = attached_unit
		Buff.__init__(self)

	def on_init(self):
		self.name = "Attached"
		self.owner_triggers[EventOnMoved] = self.on_move
		self.global_triggers[EventOnDeath] = self.on_death
		self.buff_type = BUFF_TYPE_CURSE
		self.stack_type = STACK_INTENSITY


	def on_applied(self, owner):
		existing = [b for b in owner.buffs if isinstance(b, AttachedBuff)]
		existing = [b for b in existing if b.attached_unit == self.attached_unit]
		# multiple units can attach to one, but it doesn't make sense for the same unit to inflict it over and over
		if len(existing) > 1: return ABORT_BUFF_APPLY

		self.rel_x = self.attached_unit.x - owner.x
		self.rel_y = self.attached_unit.y - owner.y

	def get_description(self):
		return ("{unit} moves with the owner of this buff if there is space to keep its relative position", {'unit': self.attached_unit.name})

	def on_move(self, evt):
		if self.owner.level.can_move(self.attached_unit, evt.x + self.rel_x, evt.y + self.rel_y, teleport=evt.teleport):
			self.owner.level.act_move(self.attached_unit, evt.x + self.rel_x, evt.y + self.rel_y, teleport=evt.teleport)
		else:
			self.owner.remove_buff(self)

	def on_death(self, evt):
		if evt.unit is self.attached_unit:
			self.owner.remove_buff(self)

class ScuttlerPinch(SimpleMeleeAttack):

	def __init__(self):
		SimpleMeleeAttack.__init__(self, damage=5, buff=ImmobilizeBuff, buff_duration=1)
		self.name = "Pinch"
		self.description = "Immobilizes for 1 turn"

	def can_continue_channel(self, target):
		return (target.is_alive()
				and self.caster.level.get_unit_at(target.x, target.y) == target
				and self.caster.level.are_hostile(self.caster, target)
				and self.can_cast(target.x, target.y))

	def cast(self, x, y, channel_cast=False):
		if not channel_cast and self.is_manual_cast():
			target = self.caster.level.get_unit_at(x, y)
			if not target: return
			self.caster.apply_buff(ChannelBuff(self.cast, target, channel_check=self.can_continue_channel))
			return

		unit = self.caster.level.get_unit_at(x, y)

		if not unit: # don't keep casting if there's nothing there
			b = self.caster.get_buff(ChannelBuff)
			if b: self.caster.remove_buff(b)
			return

		self.caster.level.deal_damage(x, y, self.get_stat('damage'), Tags.Physical, self)
		# don't stack here immobilize, just do it for 1 turn at a time, even if multiple crabs are swarming, if they aren't being pinched,
		# they shouldn't be immobilized
		if unit.is_alive() and not unit.has_buff(ImmobilizeBuff): unit.apply_buff(ImmobilizeBuff(), 1)
		yield

def Scuttler():
	u = Unit()
	u.name = "Scuttler"
	u.asset_name = "hot_crab"
	u.max_hp = 23
	u.resists[Tags.Physical] = 50
	u.resists[Tags.Ice] = -75
	u.tags = [Tags.Living]
	u.spells = [ScuttlerPinch()]
	return u

def SnowScuttler():
	u = Unit()
	u.name = "Snow Scuttler"
	u.asset_name = "cold_crab"
	u.max_hp = 38
	u.tags = [Tags.Living, Tags.Ice]
	u.resists[Tags.Physical] = 50
	u.resists[Tags.Ice] = 75
	u.resists[Tags.Fire] = -50
	u.spells = [ScuttlerPinch()]
	u.buffs = [DamageAuraBuff(3, Tags.Ice, 2)]
	return u

def FreezingCoral():
	u = Unit()
	u.name = "Freezing Coral"
	u.asset_name = "coral"
	u.max_hp = 12
	u.stationary = True
	u.tags = [Tags.Nature, Tags.Ice]
	u.resists[Tags.Physical] = 50
	u.resists[Tags.Ice] = 100
	u.buffs = [CurseRetaliation(name="Sharp Edges", buff=BleedBuff, buff_dur=4, color_tag=Tags.Blood, melee=True), DamageAuraBuff(3, Tags.Ice, 2)]
	return u

class GuardsmanBuff(Buff):

	def on_init(self):
		self.name = "Guardsman"
		self.description = "Each turn, grant 1 SH to adjacent unshielded allies"
		self.color = COLOR_SHIELD

	def on_advance(self):
		owner = self.owner
		candidates = [u for u in owner.level.get_adjacent_units(owner) if not u.shields and not are_hostile(owner, u)]
		for u in candidates: u.add_shields(1)


def CardGuard():
	u = Unit()
	u.name = "Card Guard"
	u.max_hp = 77
	u.tags = [Tags.Arcane, Tags.Construct]
	u.resists[Tags.Physical] = -100
	u.resists[Tags.Fire] = -100
	u.resists[Tags.Arcane] = 75
	u.spells = [SimpleMeleeAttack(damage=7)]
	u.buffs = [GuardsmanBuff()]
	return u

def DivineHammer():
	u = Unit()
	u.name = "Divine Hammer"
	u.max_hp = 50
	u.shields = 3
	u.flying = True
	u.tags = [Tags.Holy, Tags.Metallic, Tags.Construct]
	u.resists[Tags.Holy] = 100
	u.spells = [LeapAttack(damage=25, range=4, damage_type=Tags.Physical, buff=Stun, buff_duration=1)]
	return u

def SeerOfGlass():
	u = Unit()
	u.name = "Glass Seer"
	u.asset_name = 'glass_angel'
	u.stationary = True
	u.flying = True
	u.tags = [Tags.Holy, Tags.Eye, Tags.Glass, Tags.Construct]
	u.max_hp = 12
	u.shields = 12
	shot = SimpleRangedAttack(name="Glassify", damage=3, damage_type=Tags.Physical, range=36, proj_name='glassification', buff=GlassPetrifyBuff, buff_duration=1)
	shot.tt_color = Tags.Glass.color
	u.spells = [shot]
	u.buffs = [MushboomBuff(HemorrhageBuff, 10, effect_tag=Tags.Blood), TeleportyBuff()]
	add_tooltip(u, GlassPetrifyBuff())
	add_tooltip(u, HemorrhageBuff())
	return u

class IsolateSpell(Spell):

	def on_init(self):
		self.name = "Isolate"
		self.damage = 10
		self.range = 6
		self.damage_type = [Tags.Arcane]
		self.can_target_empty = False
		self.tt_color = Tags.Arcane.color

	def get_description(self):
		return "Turns an unoccupied adjacent tile into a chasm"

	def cast(self, x, y):
		getu = self.caster.level.get_unit_at
		make_chasm = self.caster.level.make_chasm
		show_effect = self.caster.level.show_effect
		u = getu(x, y)
		self.caster.level.show_beam(self.caster, u, dtype=Tags.Arcane)
		self.caster.level.deal_damage(x, y, self.get_stat('damage'), Tags.Arcane, self)
		opts = []
		for p in self.caster.level.get_adjacent_points(Point(u.x, u.y), filter_walkable=False, check_unit=True, r=u.radius):
			if not getu(p.x, p.y): opts.append(p)

		if opts:
			p = random.choice(opts)
			show_effect(p.x, p.y, Tags.Translocation)
			make_chasm(p.x, p.y)

		yield

class VoidSaintShieldBuff(Buff):

	def on_init(self):
		self.name = "Void Shielding"
		self.description = "When targeted by a spell, gains [1 SH:shields]"
		self.global_triggers[EventOnSpellCast] = self.on_cast

	def on_cast(self, evt):
		if evt.x != self.owner.x: return
		if evt.y != self.owner.y: return
		self.owner.add_shields(1)

	# teleport away when you examine them, funny but probably too crazy
	# def get_description(self):
	# 	if not self.owner or not self.owner.level: return self.description
	# 	randomly_teleport(self.owner, 4)
	# 	return self.description

def VoidSaint():
	u = Unit()
	u.name = "Void Saint"
	u.tags = [Tags.Arcane, Tags.Holy]
	u.max_hp = 404
	u.resists[Tags.Arcane] = 100
	u.resists[Tags.Holy] = 100
	u.resists[Tags.Physical] = 50
	u.resists[Tags.Dark] = 50
	u.spells = [IsolateSpell()]
	u.buffs = [VoidSaintShieldBuff(), TeleportyBuff(radius=4, chance=.75)]
	return u

# POTENTIAL VARIANT RETURNERS #
#########################################################

# class FindBoarRider(Spell):
#
# 	def on_init(self):
# 		self.name = "Find Rider"
# 		self.description = "Find an adjacent nearby orc to serve as a mount"
# 		self.range = 0
#
# 	def find_rider(self):
# 		for p in self.caster.level.get_points_in_ball(self.caster.x, self.caster.y, diag=True, radius=1):
# 			unit = self.caster.level.get_unit_at(p.x, p.y)
# 			if unit:
# 				if unit.name == "Orc":
# 					return unit
# 		return None
#
# 	def can_cast(self, x, y):
# 		return self.find_rider() is not None and Spell.can_cast(self, x, y)
#
# 	def cast_instant(self, x, y):
# 		rider = self.find_rider()
# 		rider.kill(trigger_death_event=False)
# 		self.caster.kill(trigger_death_event=False)
# 		self.caster.level.add_obj(OrcBoarRider(), self.caster.x, self.caster.y)


# def OrcBoar():
# 	unit = Unit()
# 	unit.max_hp = 12
#
# 	unit.name = "Orc Boar"
# 	unit.asset_name = "orc_pig"
#
# 	unit.is_coward = True
# 	unit.spells = [FindBoarRider()]
# 	unit.tags = [Tags.Living]
#
# 	return unit
#
# def OrcBoarRider():
# 	unit = Orc()
# 	unit.max_hp += 12
#
# 	unit.name = "Orc Boar Rider"
# 	unit.asset_name = "orc_pig_rider"
#
# 	charge = LeapAttack(damage=5, is_leap=False, range=4)
# 	charge.name = "Charge"
# 	charge.cool_down = 3
#
# 	unit.buffs.append(RespawnAs(OrcBoar))
# 	unit.spells.append(charge)
# 	return unit



def ArmoredOgre():
	unit = Ogre()
	unit.tags.append(Tags.Metallic)
	unit.max_hp += 20
	unit.name = "Armored Ogre"
	unit.spells[0] = SimpleMeleeAttack(damage=25, buff=Stun, buff_duration=1)
	return unit


# def SlimeCube(spawner):
# 	# Slime cubes: stationary, regenerating, reproducing slime generators
#
# 	unit = spawner()
# 	unit.asset_name = "%s_cube" % unit.get_asset_name()
# 	unit.name = "%s Cube" % unit.name
#
# 	summon = SimpleSummon(spawner, cool_down=10)
# 	unit.spells.insert(0, summon)
#
# 	unit.max_hp *= 3
# 	unit.stationary = True
# 	unit.buffs[0].spawner = lambda: SlimeCube(spawner)
#
# 	return unit

# def BoneKnightKing():
# 	unit = King(BoneKnight)
# 	unit.name = "Ossuonobius, Bone King"
# 	unit.asset_name = "bone_knight_king"
# 	return unit

# def JeweledHand():
# 	unit = PurpleHand()
# 	unit.name = "Jeweled Hand"
# 	unit.asset_name = "giant_hand_jeweled"
#
# 	unit.shields += 4
#
# 	return unit

##############################################################


class BurrowingBuff(Buff):

	def on_init(self):
		self.name = "Burrowing"
		self.stack_type = STACK_DURATION

	def on_applied(self, owner):
		owner.burrowing += 1

	def on_unapplied(self):
		self.owner.burrowing -= 1

class FlyingBuff(Buff):

	def on_init(self):
		self.name = "Flying"
		self.stack_type = STACK_DURATION

	def on_applied(self, owner):
		owner.flying += 1

	def on_unapplied(self):
		self.owner.flying -= 1

class QuickmoveBuff(Buff):

	def on_init(self):
		self.name = "Quickstep"
		self.color = Tags.Translocation.color
		self.stack_type = STACK_DURATION
		self.asset = ['status', 'quickmove']

	def on_applied(self, owner):
		owner.quick_move += 1

	def on_unapplied(self):
		self.owner.quick_move -= 1

class QuickcastingBuff(GlobalAttrBonus):

	def __init__(self):
		GlobalAttrBonus.__init__(self, 'quick_cast', 1)
		self.name = "Quickcasting"
		self.stack_type = STACK_DURATION
		self.asset = ['status', 'quickcast']

# Unit, Difficulty, Alpha
spawn_options = [
	(Goblin, 1, GoblinShaman),
	(Bat, 1, Vampire),
	(Hornet, 1, SkullHornet),
	(StringedPuppet, 1, PurpleHand),


	(VoidBomber, 2, VoidRift),
	(FireBomber, 2, FlameRift),
	(IceBomber, 2, IceRift),
	(MindMaggot, 2, MindMaggotQueen),
	(DisplacerBeast, 2, DisplacerBeastMother),
	(GreenMushboom, 2, Mycobeast),
	(Mantis, 2, MantisQueen),
	(Boggart, 2, BoggartHornblower),
	(Orc, 2, OrcWarchief),
	(Ghost, 2, Witch),
	(GoblinArmored, 2, GoblinShaman),
	(Scuttler, 2, None),
	(GreenSlime, 3, SlimeMage),

	(VoidChild, 3, VoidElder),
	(Pumpkinhead, 3, Scarecrow),
	(FireImp, 3, FireFiend),
	(SparkImp, 3, StormFiend),
	(Zombie, 3, RotTree),
	(IronImp, 3, IronFiend),
	(Satyr, 3, Pan),
	(WormBall, 3, WormWizard),
	(Kobold, 3, KoboldHedgeMage),
	(Witch, 3, NightHag),
	(RockWorm, 3, WormWizard),
	(GiantSpider, 3, GiantSpiderQueen),
	(GreyMushboom, 3, Mycobeast),
	(HornedToad, 3, ToadPriest),
	(Raven, 3, RavenMage),
	(Treant, 3, Oakheart),
	(Cultist, 3, FalseProphet),
	(TwoHeadedSnake, 3, SerpentPhilosopher),
	(BreathStealer, 3, NightHag),
	(RazorBeast, 3, None),
	(SparkSpirit, 3, None),
	(FireSpirit, 3, None),
	(RedSlime, 4, None),
	(IceSlime, 4, None),
	(ElectricSlime, 4, None),

	(SnowScuttler, 4, None),
	(GlassMushboom, 4, None),
	(Gremlin, 4, Banshee),
	(Centaur, 4, CentaurDruid),
	(Ogre, 4, Thunderbones),
	(BagOfBugs, 4, None),
	(Troll, 4, TrollGeomancer),
	(Troubler, 4, MaskedWizard),
	(Faery, 4, ThornQueen),
	(Vampire, 4, VampireCount),
	(Gnome, 4, MischiefMaker),
	(GoatHead, 4, None),
	(PolarBear, 4, None),
	(HellHound, 4, None),
	(Werewolf, 4, Fenris),
	(BlizzardBeast, 4, None),
	(SkullHornet, 4, None),
	(BoggartAssassin, 4, BoggartHornblower),
	(IceRocketBomber, 4, None),
	(FireRocketBomber, 4, None),
	(VoidRocketBomber, 4, None),
	(SentientShield, 4, None),
	(FieryTormentor, 4, None),
	(HeadCannon, 4, None),
	(BoneShambler, 4, Lich),
	(DancingBlade, 4, ArcaneBlacksmith),
	(VoidSlime, 4, None),
	(BloodSlime, 4, None),


	(IcyTormentor, 5, None),
	(AnimatedArmor, 5, ArcaneBlacksmith),
	(BoneKnight, 5, Dracolich),
	(Elf, 5, Aesir),
	(ArmoredPolarBear, 5, None),
	(FlameMaw, 5, None),
	(IceMaw, 5, None),
	(Mycobeast, 5, None),
	(Thunderbird, 5, None),
	(Bloodhound, 5, BloodWizard),
	(Golem, 5, Mechanomancer),
	(StoneFish, 5, None),
	(FaeSniper, 5, None),
	(FireBelcher, 5, FireWyrm),
	(IceBelcher, 5, IceWyrm),
	(PhaseSpider, 5, PhaseSpiderQueen),
	(SpikeBeast, 5, None),
	(BloodBear, 5, BloodWizard),
	(Dwarf, 5, None),
	(OrcHoundlord, 5, None),
	(ImpCollector, 5, GrandWarlock),
	(PurpleHand, 5, None),
	(Leghead, 5, None),
	(Trollataur, 5, CentaurDruid),
	(FloatingEye, 5, EyeballWizard),
	(CardGuard, 5, None),
	(ArmoredOgre, 5, None),
	(GiantToad, 5, ToadPriest),
	(FlameToad, 5, None),
	(VoidToad, 5, None),
	(StormTroll, 5, TrollGeomancer),
	(Minotaur, 5, None),
	(GiantSpiderQueen, 5, None),
	(VoidRift, 5, None),
	(FlameRift, 5, None),

	(FrostfireTormentor, 6, None),
	(ChaosChimera, 6, None),
	(StarfireChimera, 6, None),
	(DeathchillChimera, 6, DeathchillWizard),
	(SpikeBall, 6, None),
	(BoneKnightArcher, 6, Lich),
	(Fearface, 6, None),
	(StormDrake, 6, DragonMage),
	(FireDrake, 6, DragonMage),
	(WormShambler, 6, None),
	(MindMaggotQueen, 6, GiantMindMaggotQueen),
	(GhostMass, 6, None),
	(FaeArcanist, 6, ThornQueen),
	(StarSwimmer, 6, None),
	(ToadKnight, 6, ToadPriest),
	(MindVampire, 6, None),
	(BarkLord, 6, None),
	(Stalker, 6, None),
	(Executioner, 6, None),
	(FalseProphet, 6, FallenAngel),
	(Gargoyle, 6, None),
	(VoidDrake, 6, DragonMage),
	(GoldDrake, 6, DragonMage),
	(IceDrake, 6, DragonMage),

	(Dryder, 7, None),
	(Banshee, 7, None),
	(VoidElder, 7, None),
	(MindDevourer, 7, None),
	(FireWyrm, 7, DragonMage),
	(NightHag, 7, None),
	(RedCyclops, 7, None),
	(GiantSkull, 7, None),
	(GreyGorgon, 7, None),
	(Efreet, 7, None),
	(Yeti, 7, YetiShaman),
	(Cockatrice, 7, None),
	(ButterflyDemon, 7, None),
	(FlamingEye, 7, None), # Infernal Oculari (many eyed demon, can do a chain-fireball style spell)
	(AnimatedKnight, 7, ArcaneBlacksmith),
	(SteelSpiderQueen, 7, None),
	(PhaseSpiderQueen, 7, None),
	(ThornQueen, 7, FaeryEmpress),
	(ElfLightningLord, 7, None),
	(VoidKnight, 7, None),
	(StormKnight, 7, None),
	(BloodKnight, 7, None),
	(EnergyKnight, 7, None),
	(TwilightKnight, 7, None),
	(ChaosKnight, 7, None),
	(Reaper, 7, None),
	(BoneKing, 7, None),
	(DivineHammer, 7, None),

	(ToxicMindDevourer, 8, None),
	(ZombieMass, 8, None),
	(VoidHag, 8, None),
	(IceWyrm, 8, None),
	(ChaosFiend, 8, None),
	(AshFiend, 8, None),
	(InsanityFiend, 8, None),
	(FurnaceFiend, 8, None),
	(CopperFiend, 8, None),
	(RotFiend, 8, None),
	(AnnihilationGoo, 8, SlimeMage),
	(Lich, 8, None),
	(ToweringBoneShambler, 8, LimbCollector),
	(NightmareTurtle, 8, None),
	(Lamasu, 8, None),
	(FleshFiend, 8, None),
	(Aesir, 8, None),
	(GiantFlamingSkull, 8, None),
	(GoldSkull, 8, None),
	(ArchonPurifier, 8, None),
	(StoneShark, 8, None),
	(SeerOfGlass, 8, None),

	(BoneWheel, 9, None),
	(VoidAncestor, 9, None),
	(FaeryEmpress, 9, None),
	(GelidMirror, 9, None),
	(CorruptedLamasu, 9, None),
	(Phoenix, 9, None),
	(VolcanoTurtle, 9, None),
	(GlacialTurtle, 9, None),
	(Dracolich, 9, None),
	(Necrodrake, 9, None),
	(Titan, 9, None),
	(FloatingEyeMass, 9, None),
	(BoneShamblerMegalith, 9, None),
	(Arbiter, 9, None),
	(AngelicVisitor, 9, None),
	(ArchFiend, 9, None),
	(MindMaggotWretch, 9, None),
	(WhirlwindReaper, 9, None),
	(VoidSaint, 9, None),
]

tagged_spawn_options = {}
monster_tags = set()

for entry in spawn_options:
	factory = entry[0]
	unit = factory()
	if not unit or not unit.tags: raise Exception("spawn_options entry has no tags: %s" % factory)
	for t in unit.tags:
		monster_tags.add(t)
		tagged_spawn_options.setdefault(t, []).append(entry)
