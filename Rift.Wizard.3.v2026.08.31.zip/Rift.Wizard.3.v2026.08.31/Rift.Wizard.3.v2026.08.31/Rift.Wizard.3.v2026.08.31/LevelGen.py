from Level import *
from Monsters import *
from Spells import *
from Equipment import *
from LevelRewards import *
from RareMonsters import *
import random
from collections import namedtuple
from LevelGenHelpers import *
from FinalBosses import *

LEVELGEN_DEBUG_LOGS = False

LEVEL_SIZE = 18

def set_level_size(new_size):
	global LEVEL_SIZE
	LEVEL_SIZE = new_size

import sys

import logging
level_logger = logging.getLogger("Level")
level_logger.setLevel(logging.DEBUG)
level_logger.propagate = False
if LEVELGEN_DEBUG_LOGS: level_logger.addHandler(logging.FileHandler('level_log.txt', mode='w'))

class Biome():

	def __init__(self, tileset, tags=None, limit_walls=False, needs_chasms=False, min_level=0, chasm_type="water", restricted_chasms=None):
		self.tileset = tileset
		self.tags = tags
		self.limit_walls = limit_walls
		self.needs_chasms = needs_chasms
		self.min_level = min_level
		self.chasm_type = chasm_type
		self.restricted_chasms = restricted_chasms

	def can_spawn(self, levelgen):
		if levelgen.difficulty < self.min_level: return False
		if self.tags: # If the biome has tag reqs, insist that the primary spawn has those tags
			if not any(t for t in self.tags if t in levelgen.primary_spawn().tags): return False
		return True

all_chasms = [
	'water',
	'lava',
	'swamp'
]

all_biomes = [
	Biome('stone'),
	Biome('brick'),
	Biome('cave'),
	Biome('fishbone', restricted_chasms=['water']),
	Biome('flesh'),
	Biome('fossil'),
	Biome('ice', restricted_chasms=['water']),
	Biome('jungle', restricted_chasms=['swamp']),
	Biome('moss', restricted_chasms=['swamp']),
	Biome('volcano'),
	Biome('turtle', min_level=25) # don't spawn naturally, just have it here so turtle can grab it and level grabs sprites correctly
]

def random_point(levelgen):
	return Point(levelgen.random.randint(0, LEVEL_SIZE - 1), levelgen.random.randint(0, LEVEL_SIZE - 1))


def get_tag_income_bounds(diff):
	min_tags = 4
	max_tags = 5
	if diff % 5 == 0:
		max_tags += 1
		min_tags -= 1
	return min_tags, max_tags

def horde_level(levelgen):
	primary, _, secondary, _, _ = levelgen.get_spawns(level_mod=1) # horde levels were too easy with same tier combatants
	levelgen.primary_spawn = primary
	levelgen.secondary_spawn = secondary
	levelgen.bosses = []
	levelgen.num_generators *= 3
	levelgen.num_monsters *= 3

def wizard_level(levelgen):
	min_level, max_level = get_rare_spawn_bounds(levelgen.difficulty)
	current_wizards = get_rare_spawn_options(levelgen.difficulty, group=WIZARDS)
	if not current_wizards: return

	wizards = current_wizards
	if len(wizards) < 10 and min_level > DIFF_EASY:
		wizards = get_rare_spawn_options(levelgen.difficulty, min_level=min_level - 1, max_level=max_level, group=WIZARDS)

	levelgen.num_monsters = 0
	levelgen.num_generators = 0
	levelgen.primary_spawn = None
	levelgen.secondary_spawn = None
	levelgen.bosses.clear()

	current_wizard = levelgen.random.choice(current_wizards)
	remaining_wizards = [wizard for wizard in wizards if wizard != current_wizard]
	wizards = [current_wizard] + levelgen.random.sample(remaining_wizards, min(2, len(remaining_wizards)))

	numwizards = (levelgen.difficulty // 2) + levelgen.random.randint(4, 7)

	for i in range(numwizards):
		wizard = levelgen.random.choice(wizards)[0]()
		levelgen.bosses.append(wizard)

def beast_level(levelgen):
	beasts = get_rare_spawn_options(levelgen.difficulty, group=KAIJU)
	if not beasts: return

	levelgen.num_monsters = 0
	levelgen.num_generators = 0
	levelgen.primary_spawn = None
	levelgen.secondary_spawn = None
	levelgen.bosses.clear()

	numwbeasts = max(2, (levelgen.difficulty // 5) + levelgen.random.randint(1, 2))

	for entry in levelgen.random.sample(beasts, numwbeasts):
		beast = entry[0]()
		levelgen.bosses.append(beast)

def alphas_only(levelgen):
	mod = levelgen.random.randint(1, 3)
	primary, p_elite, secondary, s_elite, _ = levelgen.get_spawns(level_mod = -mod)
	levelgen.monster_tags.clear()
	levelgen.primary_spawn = p_elite
	levelgen.update_lvl_tags(p_elite)
	levelgen.primary_elite = None
	levelgen.secondary_spawn = s_elite
	levelgen.update_lvl_tags(s_elite)
	levelgen.secondary_elite = None
	levelgen.num_generators = 0
	levelgen.bosses.clear()
	num_bosses = 1 + round(levelgen.difficulty / 5)
	for i in range(num_bosses):
		levelgen.bosses.extend(roll_rare_spawn(levelgen.difficulty, prng=levelgen.random, tags=levelgen.monster_tags))

level_mutators = [
	horde_level,
	wizard_level,
	beast_level,
	alphas_only
]

class LevelGenerator():

	def __init__(self, difficulty, game=None, seed=None, corrupted=False, forced_tag=None):
		
		self.difficulty = difficulty
		self.level = None
		self.level_seed = seed
		self.reward_seed = None
		self.reward_materialized = False

		self.next_level_seeds = None			
		self.random = random.Random()

		if seed is not None:
			level_logger.debug("Seeding levelgen with %f" % seed)
			self.random = random.Random(seed)
			if game:
				self.next_level_seeds = game.get_seeds(difficulty)
				self.random.shuffle(self.next_level_seeds)

		self.level_id = self.random.randint(0, 1000000)
		self.reward_seed = self.level_seed if self.level_seed is not None else self.level_id

		self.num_start_points = self.random.choice([4, 6, 8, 10, 12, 14, 16])
		self.reconnect_chance = self.random.choice([0, 0, .15, .2, .25, .3])
		self.game = game
		self.num_exits = 3

		self.bosses = []
		self.base_monster_lvl = 0
		self.monster_lvl = 0
		self.min_monster_level,  self.max_monster_level = get_spawn_min_max(self.difficulty)

		self.monster_tags = set()
		self.forced_tag = forced_tag

		if self.game:
			for m in self.game.mutators:
				m.on_levelgen_start(self)

		self.primary_spawn, self.primary_elite, self.secondary_spawn, self.secondary_elite, self.monster_lvl = self.get_spawns()

		self.biome = self.random.choice([b for b in all_biomes if b.can_spawn(self)])
		if self.biome.restricted_chasms: chasm_type = self.random.choice([c for c in all_chasms if c not in self.biome.restricted_chasms])
		else: chasm_type = self.random.choice([c for c in all_chasms])
		self.biome.chasm_type = self.chasm_type = chasm_type

		# keep it basic for level 1
		if self.difficulty == 1:
			self.biome = Biome('stone')
			self.biome.chasm_type = self.chasm_type = 'water'

		self.corrupted = corrupted
		self.corrupted_tiles = []
		self.is_vault = False

		self.num_monsters = self.random.randint(6, 10)

		self.num_generators = self.random.randint(3, 5)
		if self.num_generators > 3: self.monster_lvl += self.random.randint(0, 1)

		self.shrine = None
		if difficulty in [1, LAST_LEVEL] or not self.game: self.reward_materialized = True

		# As we go up in diff, add more stuff to the board

		# Add extras non spawned high level monsters
		if 17 >= self.difficulty >= 3: self.add_elites()

		# Include a single alpha for each monster type
		if self.difficulty >= 4: self.add_alphas()

		if self.difficulty % 5 == 0 and self.random.random() < .66: self.add_miniboss()

		if self.difficulty >= 6: self.add_challenge_mod()

		if self.difficulty >= 8: self.add_lairs()

		if self.difficulty >= 11: self.add_challenge_mod()

		if difficulty >= 14:
			self.add_super_challenge()
			if self.random.random() > .75:
				self.add_super_challenge()
				self.monster_lvl += 1

		if difficulty >= 16: self.add_boss_duplicates()

		if not forced_tag and 7 < difficulty < 21 and self.random.random() < .15: # don't want to mutate things with forced tags
			modifier = self.random.choice(level_mutators)
			modifier(self)
			self.base_monster_lvl = round((self.min_monster_level + self.max_monster_level) // 2)  # reset base so tag income isn't wonky after rerunning get_spawn inside mutator
			self.monster_lvl = self.base_monster_lvl + 1 # adjust this up/down inside the mutator?

		self.monster_diversity_sanity_check()

		self.num_xp = 3

		self.num_component_tags = self.roll_tag_income()
		self.components = []
		self.roll_components()

		if difficulty == 1:
			self.num_generators = 1
			self.num_monsters = 4
			self.primary_spawn = Goblin
			self.num_shrines = 0
			self.components = []

		if difficulty == 2:
			self.num_generators = 3

		if difficulty == LAST_LEVEL - 2:
			self.num_exits = 2

		if difficulty == LAST_LEVEL - 1:
			self.bosses.append(roll_final_boss(self.random, game))
			self.num_exits = 1

		if difficulty == LAST_LEVEL:
			self.bosses = [Mordred()]
			self.num_shrines = 0
			self.num_exits = 0

		if self.game:
			for m in self.game.mutators:
				m.on_levelgen_pre(self)

		self.description = self.get_description()

	def roll_tag_income(self):
		min_tags, max_tags = get_tag_income_bounds(self.difficulty)
		# a bounded number between 3 and 9 influenced by the actual difficulty of the level compared to the baseline difficulty of the level
		return max(min_tags, min(3 + round((self.monster_lvl - self.base_monster_lvl) * (self.monster_lvl/self.base_monster_lvl)), max_tags))

	def roll_components(self):
		total = self.num_component_tags
		tiers = [0, 0, 0]
		while total > 0:
			i = self.random.randrange(len(tiers))
			if tiers[i] < 3:
				tiers[i] += 1
				total -= 1

		for t in tiers:
			if t == 1: self.components.append(self.random.choice(t1_components)())
			elif t == 2: self.components.append(self.random.choice(t2_components)())
			elif t == 3: self.components.append(self.random.choice(t3_components)())

	def monster_diversity_sanity_check(self):
		num = 6
		if self.primary_spawn: num -= 1
		if self.secondary_spawn: num -= 1
		if self.difficulty == LAST_LEVEL - 1: num -= 1

		kept = []
		seen = set()
		for monster in reversed(self.bosses): # reverse so we keep the latest (most important) added bosses
			if monster.name not in seen:
				if len(seen) == num: continue  # this would add an extra unique name, so drop it
				seen.add(monster.name)
			elif monster.radius: continue # don't include duplicates of the same 3x3
			kept.append(monster)  # duplicates reach here even after seen
		kept.reverse()
		self.bosses = kept

	def get_alphas(self):
		if not self.primary_elite: return
		units = [self.primary_elite()]
		if self.secondary_elite: units.append(self.secondary_elite())
		return units

	def get_elites(self):
		_, level = get_spawn_min_max(self.difficulty) # find the max spawn difficulty for the given level
		level = min(level+1, 9) # get that +1
		num_elites = 2
		for i in range(self.difficulty // 2):
			if self.random.random() < (self.difficulty * .03):
				num_elites += 1 # add up to 10 extra elites
		options = [(s, l, e) for s, l, e in spawn_options if l == level]
		spawner = self.random.choice(options)[0]
		units = [spawner() for i in range(num_elites)]
		if num_elites > 6 and self.difficulty < 14: self.monster_lvl += 1
		return units

	def add_boss(self):
		spawns = roll_rare_spawn(self.difficulty, prng=self.random)
		self.bosses.extend(spawns)

	def add_alphas(self):
		alphas = self.get_alphas() # returns one of each for each spawn
		self.bosses.extend(alphas)

	def add_elites(self):
		elites = self.get_elites()
		self.bosses.extend(elites)

	def add_miniboss(self):
		lvl = self.difficulty
		m = math.ceil(lvl/5)
		spawns = roll_rare_spawn(difficulty=lvl, min_level=m, max_level=m, prng=self.random, group=minibosses)
		del self.bosses[-1] # replace the final entry rather than add on, level 5 is already extremely challenging
		self.bosses.extend(spawns)
		self.monster_lvl += 4

	def add_idol(self):
		spawns = roll_rare_spawn(difficulty=self.difficulty, prng=self.random, group=IDOLS)
		self.bosses.extend(spawns)

	def add_challenge_mod(self):
		challenges = [self.add_elites, self.add_idol, self.add_boss, lambda: self.add_wizard_gang(1)]
		self.random.choice(challenges)()

	def add_wizard_gang(self, num=3):
		wizards = get_rare_spawn_options(self.difficulty, group=WIZARDS)
		if not wizards: return
		for i in range(num): self.bosses.append(self.random.choice(wizards)[0]())

	def add_giant_monster(self):
		monster = roll_rare_spawn(self.difficulty, prng=self.random, group=giants)
		self.bosses.append(monster[0])

	def add_boss_duplicates(self):
		candidates = []
		for spawner in [self.primary_elite, self.secondary_elite]:
			if not spawner: continue
			unit = spawner()
			if unit.radius: continue
			candidates.append(spawner)
		if not candidates:
			self.add_idol()
			return
		for spawn_fn in candidates: self.bosses.append(spawn_fn())

	def add_lairs(self):
		self.num_generators += self.random.randint(1, 3)

	def add_super_challenge(self):
		challenges = [self.add_giant_monster, self.add_boss, self.add_lairs, self.add_boss_duplicates]
		self.random.choice(challenges)()

	def get_forced_tag_spawns(self):
		min_level, max_level = self.min_monster_level, self.max_monster_level
		options = [m for m in tagged_spawn_options.get(self.forced_tag, [])]
		chosen = None

		while not chosen: # sometimes there are no monsters at the difficulty level range desired, but we still need something!
			chosen = [m for m in options if min_level <= m[1] <= max_level]
			if chosen: break
			if min_level == 1 and max_level == 9:
				self.forced_tag = None
				return self.get_spawns() # fallback after resetting forced tag if there are no monsters with that tag somehow # (searched everything, failed to find a valid monster)
			min_level = max(1, min_level -1)
			max_level = min(9, max_level + 1)

		self.base_monster_lvl = round((min_level + max_level) // 2)

		self.random.shuffle(chosen)
		primary, p_lvl, p_elite = chosen.pop()
		self.update_lvl_tags(primary)
		if not p_elite: p_elite = roll_rare_spawn(self.difficulty, prng=self.random, tags=self.monster_tags, factory_only=True)
		self.update_lvl_tags(p_elite)

		s_lvl = 0
		if self.difficulty > 1:
			secondary, s_lvl, s_elite = self.random.choice([(m, l, e) for m, l, e in spawn_options if min_level <= l <= max_level])
			self.update_lvl_tags(secondary)
			if not s_elite: s_elite = roll_rare_spawn(self.difficulty, prng=self.random, tags=self.monster_tags, factory_only=True)
			self.update_lvl_tags(s_elite)
		else: secondary, s_elite = None, None

		avg_lvl = (p_lvl + s_lvl) // 2 if s_lvl else p_lvl

		return primary, p_elite, secondary, s_elite, avg_lvl

	def get_spawns(self, level_mod=0):
		if self.forced_tag: return self.get_forced_tag_spawns()
		min_level, max_level = self.min_monster_level + level_mod, self.max_monster_level + level_mod
		min_level = max(1, min(9, min_level))
		max_level = max(min_level, min(9, max_level))
		self.base_monster_lvl = round((min_level + max_level) // 2)
		primary, p_lvl, p_elite = self.random.choice([(m, l, e) for m, l, e in spawn_options if min_level <= l <= max_level])
		self.update_lvl_tags(primary)
		if not p_elite: p_elite = roll_rare_spawn(self.difficulty, prng=self.random, tags=self.monster_tags, factory_only=True)
		self.update_lvl_tags(p_elite)

		s_lvl = 0
		if self.difficulty > 1:
			secondary, s_lvl, s_elite = self.random.choice([(m, l, e) for m, l, e in spawn_options if min_level <= l <= max_level])
			self.update_lvl_tags(secondary)
			if not s_elite: s_elite = roll_rare_spawn(self.difficulty, prng=self.random, tags=self.monster_tags, factory_only=True)
			self.update_lvl_tags(s_elite)
		else: secondary, s_elite = None, None

		avg_lvl = (p_lvl + s_lvl) // 2 if s_lvl else p_lvl

		return primary, p_elite, secondary, s_elite, avg_lvl

	def update_lvl_tags(self, factory):
		if factory is None: return
		self.monster_tags.update(set(factory().tags))

	def get_description(self):
		description = "A portal to another realm"
		description += "num_start_points: %d" % self.num_start_points
		description += "reconnect_chance: %.2f" % self.reconnect_chance
		return description

	def materialize_reward(self, player=None):
		if self.reward_materialized: return self.shrine
		if not self.game or self.difficulty in [1, LAST_LEVEL]:
			self.reward_materialized = True
			self.shrine = None
			return self.shrine
		if player is None: player = self.game.p1
		reward_prng = random.Random(self.reward_seed)
		reward = roll_level_reward(self.difficulty, reward_prng, player=player, reward_options=self.game.level_reward_table)
		for mutator in self.game.mutators: reward = mutator.on_level_reward(self, reward, reward_prng, player)
		self.shrine = reward
		self.reward_materialized = True
		return self.shrine

	def make_child_generator(self, difficulty=None, forced_tag=None):
		if not difficulty: difficulty = self.difficulty + 1
		if self.next_level_seeds: seed = self.next_level_seeds.pop()
		else: seed = self.random.random()

		return LevelGenerator(difficulty, self.game, seed, forced_tag=forced_tag)

	def make_level(self, check_terrain=True):

		level_logger.debug("\nGenerating level for %d" % self.difficulty)
		level_logger.debug("Level id: %d" % self.level_id)
		level_logger.debug("num start points: %d" % self.num_start_points)
		level_logger.debug("reconnect chance: %.2f" % self.reconnect_chance)

		self.level = Level(LEVEL_SIZE, LEVEL_SIZE)
		self.level.set_tileset(self.biome.tileset, self.biome.chasm_type)
		self.level.random = self.random

		can_accept_terrain = False
		attempt = 0
		if check_terrain:
			while (not can_accept_terrain and attempt < 15):
				self.make_terrain()
				can_accept_terrain = self.check_terrain()
				attempt += 1
				if attempt >= 25:
					self.log_level()
					raise Exception("Failed 25 times to generate an acceptable level")
		else: self.make_terrain()

		level_logger.debug("Level generated in %d tries" % attempt)

		level_logger.debug("Final layout:")
		self.log_level()

		if self.game:
			for m in self.game.mutators:
				m.on_levelgen_terrain(self)

		self.populate_level()

		self.level.gen_params = self

		if self.game:
			for m in self.game.mutators:
				m.on_levelgen(self)
			for m in self.game.mutators: # sometimes mutators add units in on_levelgen so if we modify we want to modify them all
				m.modify_units(self.level)

		return self.level

	def log_tile_mix(self, label=''):
		if not LEVELGEN_DEBUG_LOGS: return
		total = LEVEL_SIZE * LEVEL_SIZE
		floors = sum(1 for t in self.level.iter_tiles() if t.can_walk)
		chasms = sum(1 for t in self.level.iter_tiles() if t.is_chasm)
		walls = total - floors - chasms
		level_logger.debug("TILES %s : floors = %d walls=%d chasms=%d", label, floors, walls, chasms)

	def log_level(self):
		if not LEVELGEN_DEBUG_LOGS: return
		level_logger.debug('---')
		#Print ascii art of level
		for i in range(LEVEL_SIZE):
			row = ''
			for j in range(LEVEL_SIZE):
				t = self.level.tiles[i][j]
				c = '#'
				if t.can_walk:
					c='.'
				elif t.can_see:
					c = ' '
				row = row + c
			level_logger.debug(row)

		level_logger.debug('---')
		self.log_tile_mix()

	def get_standable_tiles(self, radius=1, flying=False):
		# Return the list of tiles that a n x n monster could stand on
		test_unit = Unit()
		test_unit.radius = radius
		test_unit.flying = flying

		results = []

		for t in self.level.iter_tiles():
			if self.level.can_stand(t.x, t.y, test_unit):
				results.append(t)

		return results

	def expand_to_radius(self, radius, flying=False):
		# Put a pathable tile next to each pathable tile so monsters of
		#  the given radius can traverse the level
		
		standable = set(Point(t.x, t.y) for t in self.get_standable_tiles(radius=radius, flying=flying))

		to_enlarge = []
		for i in range(radius, LEVEL_SIZE - radius):
			for j in range(radius, LEVEL_SIZE - radius):

				# Dont enlarge tiles that can already be stood on, no point in doing this
				if Point(i, j) in standable:
					continue

				t = self.level.tiles[i][j]
				if flying:
					if t.can_see:
						to_enlarge.append(t)
				else:
					if t.can_walk:
						to_enlarge.append(t)

		for t in to_enlarge:
			for i in range(-radius, radius+1):
				for j in range(-radius, radius+1):
					cur_point = Point(t.x + i, t.y + j)
					if flying:
						cur_tile = self.level.tiles[cur_point.x][cur_point.y]
						
						# Dont mess with existing floors for the sake of big fliers
						if cur_tile.can_walk:
							continue
						# Otherwise, expand floors into floors, expand chasms into chasms
						elif t.can_walk:
							self.level.make_floor(cur_point.x, cur_point.y)	
						else:
							self.level.make_chasm(cur_point.x, cur_point.y)
					else:
						self.level.make_floor(cur_point.x, cur_point.y)

	def ensure_connectivity(self, chasm=False):

		# For each tile
		# If it is 

		# Tile -> Label
		# For each (floor) tile
		#  If it is not labelled
		#  Label it i+1 and then traverse all connected tiles, assigning same label
		# At the end you have some number of labels
		# For each label
		# Find the shortest distance to a tile with another label
		# Connect those tiles by turning wall tiles into floor tiles
		def qualifies(tile):
			# When connecting chasms, it is ok for them to be connected over any non wall tile- just check LOS
			if chasm:
				return tile.can_see
			else:
				return tile.can_walk

		def make_path(x, y):
			if chasm:
				if not self.level.tiles[x][y].can_see:
					self.level.make_chasm(x, y)
			else:
				self.level.make_floor(x, y)

		def iter_neighbors(tile):
			visited = set([tile])
			to_visit = [tile]
			while to_visit:
				cur = to_visit.pop()

				for p in self.level.get_points_in_ball(cur.x, cur.y, 1, diag=False):
					t = self.level.tiles[p.x][p.y]
					
					if t in visited:
						continue

					if not qualifies(t):
						continue

					visited.add(t)
					to_visit.append(t)
					yield t

		cur_label = 0
		tile_labels = {}

		for tile in self.level.iter_tiles():
			# Do not label walls (or chasms when not doing the chasm pass)
			if not qualifies(tile):
				continue

			if tile not in tile_labels:
				cur_label += 1
				tile_labels[tile] = cur_label

				for neighbor in iter_neighbors(tile):
					tile_labels[neighbor] = cur_label
				
		# Instead of using a set, deterministically shuffle a list using the seeded randomizer
		labels_left = list(set(tile_labels.values()))

		# Sort first to derandomize initial ordering
		labels_left.sort()
		self.random.shuffle(labels_left)

		def tile_key(t):
			return t.x + 1000*t.y

		while len(labels_left) > 1:
			cur_label = labels_left.pop()
			best_dist = 100000
			best_inner = None
			best_outer = None
			for cur_inner in sorted(tile_labels.keys(), key=tile_key):
				
				if tile_labels[cur_inner] != cur_label:
					continue

				for cur_outer in sorted(tile_labels.keys(), key=tile_key):
					if tile_labels[cur_outer] not in labels_left:
						continue

					# Add random increment to randomly break ties
					cur_dist = distance(cur_inner, cur_outer) + self.random.random()
					if cur_dist < best_dist:
						best_dist = cur_dist
						best_inner = cur_inner
						best_outer = cur_outer

			for p in self.level.get_points_in_line(best_inner, best_outer, no_diag=True, prng=self.random):
				make_path(p.x, p.y)

	def count_tiles(self):
		floors = 0
		chasms = 0
		walls = 0
		for t in self.level.iter_tiles():
			if t.can_walk: floors += 1
			elif t.is_chasm: chasms += 1
			else: walls += 1
		return floors, chasms, walls

	# Check that terrain has enough walls and floors
	def check_terrain(self):
		min_floors = 70
		max_floors = 230
		num_floors, _, _ = self.count_tiles()
		return (max_floors >num_floors > min_floors)


	def make_terrain(self):

		chasm = self.random.random() < .35
		level_logger.debug("Filling with %s" % ('chams' if chasm else 'walls'))
		for x in range(LEVEL_SIZE):
			for y in range(LEVEL_SIZE):
				if not chasm: self.level.make_wall(x, y)
				else: self.level.make_chasm(x, y)

		if self.difficulty > 1:
			foundation_mutators = [
				macro_checkerboard_3x3,
				voronoi_districts,
				serpentine_river,
				spiral_carve,
				fortress_cells,
				cavern_pockets,
				banded_walls,
				rooms_and_corridors,
				random_walk_corridors,
				ring_and_spokes,
				paths_floor,
				paths,
				lumps,
				squares,
				grid,
				ribs,
				weave
			]
			detail_mutators = [
				fault_lines,
				alcove_nibbler,
				bridge_stitcher,
				choke_point_builder,
				symmetry_breaker,
				edge_bays,
				white_noise,
				border,
				bisymmetry,
				wallify,
				expand_floor,
				walls_to_chasms,
				chasmify,
				quads,
				radialquads,
				conway,
				section,
				pillar_noise,
				wall_clusters,
				deep_wall_walk,
				speckled_wall_decay,
				noisy_pocket_carve,
				edge_breach_erosion,
				ribs,
				ruins,
				stalagmites
			]

			level_logger.debug("Foundation mutators:")
			num_foundations = self.random.randint(2, 3)
			for mutator in self.random.sample(foundation_mutators, min(num_foundations, len(foundation_mutators))):
				mutator(self)
				self.log_tile_mix(getattr(mutator, '__name__', str(mutator)))

			level_logger.debug("Detail mutators:")
			num_details = self.random.choice([1, 2, 2, 3])
			last_mutator = None
			for i in range(num_details):
				options = [m for m in detail_mutators if m != last_mutator]
				if not options: break
				mutator = self.random.choice(options)
				if self.mutator_wipes_board(mutator): continue
				mutator(self)
				self.log_tile_mix(getattr(mutator, '__name__', str(mutator)))
				last_mutator = mutator

			num_floors, num_chasms, num_walls = self.count_tiles()
			min_chasms = self.random.choice([10, 14, 18])
			if num_chasms < min_chasms:
				self.random.choice([walls_to_chasms, crater_field, chasmify])(self)
				self.log_tile_mix('chasm_boost')

			edge_floors = sum(1 for t in self.level.iter_tiles() if t.can_walk and (t.x <= 1 or t.y <= 1 or t.x >= LEVEL_SIZE - 2 or t.y >= LEVEL_SIZE - 2))
			if edge_floors < 6 and self.random.random() < .7:
				mutator = self.random.choice([edge_breach_erosion, deep_wall_walk, noisy_pocket_carve, speckled_wall_decay])
				mutator(self)
				self.log_tile_mix(getattr(mutator, '__name__', str(mutator)))

			floors, chasms, walls = self.count_tiles()
			if chasms > walls and self.random.random() < .5:
				stalagmites(self)
				self.log_tile_mix('stalagmites')
				floors, chasms, walls = self.count_tiles()
			if walls < 70 and chasms > walls and self.random.random() < .4:
				self.random.choice([pillar_noise, ribs, stalagmites])(self)
				self.log_tile_mix('cover_injection')

		else:
			paths(self)
			self.log_tile_mix('paths')

			lumps(self, num_lumps=3, space_size=30)
			self.log_tile_mix('lumps')

		self.tidy_border()
		self.log_tile_mix('tidy_border')

		fix_attempts = 10
		min_floors = 70
		max_floors = 230
		for i in range(fix_attempts):
			num_floors, num_chasms, num_walls = self.count_tiles()
			self.log_level()

			if num_walls < 60 and num_chasms > num_walls and self.random.random() < .35:
				self.random.choice([pillar_noise, ribs, stalagmites])(self)
				num_floors, num_chasms, num_walls = self.count_tiles()

			if num_floors < min_floors or num_floors > max_floors:
				level_logger.debug("Trying to fix floor amounts:")
				mutator = self.random.choice(seed_mutators)
				mutator(self)
				self.log_level()
			else: break

		num_floors, num_chasms, num_walls = self.count_tiles()
		min_walls = self.random.choice([50, 60, 70])
		if num_walls < min_walls:
			self.random.choice([ribs, pillar_noise, wall_clusters, wallify])(self)
			self.log_tile_mix('wall_boost')

		num_floors, num_chasms, num_walls = self.count_tiles()
		if num_walls >= 60:
			diagonal_wall_cuts(self)
			self.log_tile_mix('diag_wall_cuts')

		# max_fly_radius = 0
		# for b in self.bosses:
		# 	if b.stationary: continue
		# 	if not b.flying: continue
		# 	max_fly_radius = max(max_fly_radius, b.radius)
		#
		# max_walk_radius = 0
		# for b in self.bosses:
		# 	if b.stationary: continue
		# 	if b.flying: continue
		# 	max_walk_radius = max(max_walk_radius, b.radius)

		# Ensure connectivity
		self.ensure_connectivity(chasm=False)
		self.ensure_connectivity(chasm=True)

		# # Make sure the level is navigable for big monsters
		# if max_fly_radius:
		# 	level_logger.debug("Expanding flyable corridors to %d" % max_walk_radius)
		# 	self.expand_to_radius(max_fly_radius, flying=True)
		# 	self.log_level()
		# elif max_walk_radius:
		# 	level_logger.debug("Expanding walkable corridors to %d" % max_walk_radius)
		# 	self.expand_to_radius(max_walk_radius, flying=False)
		# 	self.log_level()

		# Uniformize floors and chasms
		floor_tiles = [t for t in self.level.iter_tiles() if t.is_floor()]
		if floor_tiles:
			first = floor_tiles[0]
			for t in floor_tiles: self.level.set_tile_style(t, first.tileset, t.chasm_type)
		
		chasm_tiles = [t for t in self.level.iter_tiles() if t.is_chasm]
		if chasm_tiles:
			first = chasm_tiles[0]
			for t in chasm_tiles: self.level.set_tile_style(t, first.tileset, t.chasm_type)

	def mutator_wipes_board(self, mutator):
		# run mutator on a throwaway board to make sure it is not repainting everything
		original_level = self.level
		test_level = Level(LEVEL_SIZE, LEVEL_SIZE)

		for x in range(LEVEL_SIZE):
			for y in range(LEVEL_SIZE):
				tile = original_level.tiles[x][y]
				if tile.is_floor(): test_level.make_floor(x, y)
				elif tile.is_chasm: test_level.make_chasm(x, y)
				else: test_level.make_wall(x, y)

		self.level = test_level
		try: mutator(self)
		finally: self.level = original_level

		sample_size = min(60, LEVEL_SIZE * LEVEL_SIZE)
		changed = 0
		for _ in range(sample_size):
			x = self.random.randint(0, LEVEL_SIZE - 1)
			y = self.random.randint(0, LEVEL_SIZE - 1)
			old_tile = original_level.tiles[x][y]
			new_tile = test_level.tiles[x][y]

			if old_tile.can_walk != new_tile.can_walk or old_tile.is_chasm != new_tile.is_chasm or old_tile.can_see != new_tile.can_see:
				changed += 1

		return (changed / sample_size) > .7

	def tidy_border(self):
		# Count walls and edges on edge.
		# Make all edge floor tiles into most common type.
		walls = 0
		chasms = 0
		level = self.level
		for i in range(0, LEVEL_SIZE):
			tiles = [level.tiles[i][0], level.tiles[0][i], level.tiles[i][LEVEL_SIZE-1], level.tiles[LEVEL_SIZE-1][i]]
			for tile in tiles:
				if tile.is_wall(): walls += 1
				if tile.is_chasm: chasms += 1

		for i in range(0, LEVEL_SIZE):
			tiles = [level.tiles[i][0], level.tiles[0][i],  level.tiles[i][LEVEL_SIZE-1], level.tiles[LEVEL_SIZE-1][i]]
			for tile in tiles:
				if walls < chasms: level.make_chasm(tile.x, tile.y)
				else: level.make_wall(tile.x, tile.y)

	def consume_spawn_point(self, point):
		if point in self.empty_spawn_points: self.empty_spawn_points.remove(point)
		if point in self.wall_spawn_points: self.wall_spawn_points.remove(point)

	def pop_prop_spawn_point(self):
		if self.empty_spawn_points: return self.empty_spawn_points.pop()

		if self.wall_spawn_points:
			point = self.wall_spawn_points.pop()
			self.level.make_floor(point.x, point.y)
			return point

		candidates = []
		for i in range(LEVEL_SIZE):
			for j in range(LEVEL_SIZE):
				point = Point(i, j)
				if point in self.corrupted_tiles: continue
				if point == self.level.start_pos: continue
				tile = self.level.tiles[i][j]
				if tile.unit or tile.prop: continue
				candidates.append(point)

		if not candidates: return None
		point = self.random.choice(candidates)
		self.level.make_floor(point.x, point.y)
		return point

	def find_spawn_point(self, unit, pool):
		if not pool: return None
		candidates = list(pool)
		if unit.radius:
			r = unit.radius
			candidates = [p for p in candidates if r <= p.x <= LEVEL_SIZE - 1 - r and r <= p.y <= LEVEL_SIZE - 1 - r]
			candidates = [p for p in candidates if all(self.level.get_unit_at(q.x, q.y) is None for q in self.level.get_points_in_ball(p.x, p.y, r, diag=True))]
		return self.random.choice(candidates) if candidates else None

	# to be called on units to make space for 3x3's to move around
	def clear_spawn_area(self, unit):
		if not unit.radius: return
		if unit.stationary: return # don't need to make space to move for immobile things
		pad = unit.radius + self.random.randint(1, 2)
		for dx in range(-pad, pad + 1):
			for dy in range(-pad, pad + 1):
				x = unit.x + dx
				y = unit.y + dy
				if not self.level.is_coord_in_bounds(x, y): continue
				other = self.level.get_unit_at(x, y)
				if other not in [None, unit]: continue
				tile = self.level.tiles[x][y]
				if tile.prop: continue
				if unit.flying:
					if tile.is_wall():
						self.level.make_chasm(x, y)
				else:
					if not tile.can_walk:
						self.level.make_floor(x, y)

	def place_unit(self, unit, point, make_floor=False):
		if not point: return False
		if make_floor: self.level.make_floor(point.x, point.y)
		self.consume_spawn_point(point)
		self.level.add_obj(unit, point.x, point.y)
		if unit.radius:
			for p in unit.iter_occupied_points():
				if p == point: continue
				self.level.make_floor(p.x, p.y)
				self.consume_spawn_point(p)
			self.clear_spawn_area(unit)
		return True


	def populate_level(self):

		# Find points to put stuff
		self.empty_spawn_points = []
		self.wall_spawn_points = []
		for i in range(LEVEL_SIZE):
			for j in range(LEVEL_SIZE):
				cur_point = Point(i, j)
				if cur_point in self.corrupted_tiles: continue
				if self.level.get_unit_at(i, j): continue
				if self.level.can_walk(i, j): self.empty_spawn_points.append(cur_point)
				else:
					if len([p for p in self.level.get_adjacent_points(cur_point)]) > 1:
						self.wall_spawn_points.append(cur_point)

		self.random.shuffle(self.empty_spawn_points)
		self.random.shuffle(self.wall_spawn_points)

		self.level.start_pos = self.empty_spawn_points.pop()

		for _ in range(self.num_exits):
			if self.wall_spawn_points: exit_loc = self.wall_spawn_points.pop() # try to use walls
			elif self.empty_spawn_points: exit_loc = self.empty_spawn_points.pop() # if no walls, use a random unoccupied spot
			else: print("Not enough valid spots for portals"); continue
			self.level.make_floor(exit_loc.x, exit_loc.y)
			self.level.add_portal(Portal(self.make_child_generator()), exit_loc.x, exit_loc.y, flash=False)

		sorted_bosses = sorted(self.bosses, key=lambda boss: boss.radius, reverse=True)
		for boss in sorted_bosses:
			point = self.find_spawn_point(boss, self.empty_spawn_points)
			if not self.place_unit(boss, point): print(f"{boss.name} was unable to be placed at {point}"); continue

		for component in self.components:
			p = self.pop_prop_spawn_point()
			if not p: break
			prop = ComponentPickup(component)
			self.level.add_prop(prop, p.x, p.y)

		self.materialize_reward()
		if self.shrine:
			p = self.pop_prop_spawn_point()
			if p: self.level.add_prop(self.shrine, p.x, p.y)

		for i in range(self.num_xp):
			spawn_point = self.pop_prop_spawn_point()
			if not spawn_point: break
			pickup = MemoryOrb()
			self.level.add_prop(pickup, spawn_point.x, spawn_point.y)

		for i in range(self.num_generators):
			pool = self.wall_spawn_points if self.wall_spawn_points else self.empty_spawn_points
			if not pool: break
			if self.secondary_spawn and self.random.random() < .5: gate = MonsterSpawner(self.secondary_spawn)
			elif self.primary_spawn: gate = MonsterSpawner(self.primary_spawn)
			else: break
			point = self.find_spawn_point(gate, pool)
			if not self.place_unit(gate, point, make_floor=point in self.wall_spawn_points): continue

		for i in range(self.num_monsters):
			if not self.empty_spawn_points or not (self.primary_spawn or self.secondary_spawn): break
			spawner_fn = self.primary_spawn if not self.secondary_spawn else self.random.choice([self.primary_spawn, self.secondary_spawn])
			unit = spawner_fn()
			point = self.find_spawn_point(unit, self.empty_spawn_points)
			if not self.place_unit(unit, point): continue


# Make a list of all monsters
all_monsters = []
seen_monster_names = set()
all_monster_names = []


def record(monster):
	if monster.name in seen_monster_names: return
	all_monsters.append(monster)
	seen_monster_names.add(monster.name)

	for extra in monster.get_extra_examine_tooltips():
		if isinstance(extra, Unit):
			record(extra)


def make_bestiary():
	all_monsters.clear()
	seen_monster_names.clear()
	all_monster_names.clear()

	for s, l, e in spawn_options:
		record(s())
		if e: record(e())

	for r in rare_monsters: record(r[0]())
	# one offs, only live in vaults, can expand to a list if need be
	record(GreatFaeryGiant())
	record(Sculptor())
	for b in all_bosses_and_forms: record(b())

	max_radius = max((m.radius for m in all_monsters), default=0)
	height = sum((1 + 2 * m.radius) + 1 for m in all_monsters)
	test_level = Level(1 + 2 * max_radius, height)

	cur_y = 0

	for m in all_monsters:
		test_level.add_obj(m, max_radius, cur_y + m.radius)
		cur_y += (1 + 2 * m.radius) + 1

	for m in all_monsters: all_monster_names.append(m.name)


if __name__ == "__main__":
	for i in range(1000):
		print('Generating level %d' % i)
		gen = LevelGenerator(difficulty=random.randint(1, 21))
		test_boss = Unit()
		test_boss.radius = 1
		test_boss.flying = True

		test_boss2 = Unit()
		test_boss2.radius = 1
		test_boss2.flying = False

		gen.make_level()
