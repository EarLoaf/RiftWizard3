from Level import *
from Monsters import *
from copy import copy
import math
import itertools
import text

class FireballSpell(Spell):

	def on_init(self):
		self.tags = [Tags.Fire, Tags.Sorcery]
		self.damage_type = [Tags.Fire]
		self.level = 1

		self.name = "Fireball"
		self.radius = 2
		self.damage = 9
		self.max_charges = 12
		self.range = 6

		self.upgrades['chaos'] = (1, 5, "Chaos Ball", "Fireball randomly deals [Physical], [Lightning], or [Fire] damage\nIf a unit is resistant to one or more of these damage types, Fireball deals the damage type that unit is least resistant to", [Tags.Chaos], [Tags.Physical, Tags.Lightning])
		self.upgrades['shaped_blast'] = (1, 4, "Shaped Blast", "Fireball gains 1 [radius] for every 4 tiles away that you cast it, and never damages the wizard or their allies")
		self.upgrades[('meteor', 'duration')] = ([1, 3], 3, "Meteor", "Units in the center tile take extra [Physical] damage and are [stunned] for [{duration}:duration] turns", None, [Tags.Physical])
		self.upgrades[('ash', 'duration')] = ([1, 4], 2, "Ash Ball", "Fireball [blinds] and [poisons] units for [{duration}:duration] turns")

	def get_description(self):
		return "Deal [{damage}:damage] [Fire] damage in a [{radius}:radius] tile burst"

	def cast(self, x, y):
		damage = self.get_stat('damage')
		dur = self.get_stat('duration')
		dtypes = self.get_stat('damage_type')

		shaped = self.get_stat('shaped_blast')
		chaos = self.get_stat('chaos')
		ash = self.get_stat('ash')

		level = self.caster.level

		if self.get_stat('meteor'):
			unit = level.get_unit_at(x, y)
			if not unit: level.show_effect(x, y, Tags.Physical)
			elif (not shaped) or are_hostile(unit, self.caster):
				level.deal_damage(x, y, damage, Tags.Physical, self)
				unit.apply_buff(Stun(), dur)

		for stage in self.get_aoe(x, y):
			for point in stage:
				unit = level.get_unit_at(point.x, point.y)
				if unit and shaped and are_friendly(self.caster, unit): continue
				if chaos:
					if unit: dtype = min(((unit.resists[t], t) for t in dtypes), key=lambda t : t[0])[1]
					else: dtype = random.choice(dtypes)
				else: dtype = Tags.Fire
				if unit and ash: unit.apply_buff(BlindBuff(), dur); unit.apply_buff(Poison(), dur)
				level.deal_damage(point.x, point.y, damage, dtype, self)
			yield
		return

	def get_aoe(self, x, y):
		effective_radius = self.get_stat('radius')
		if self.get_stat('shaped_blast'):
			dist = distance(self.caster, Point(x, y))
			effective_radius += int(dist//4)
		yield from Burst(self.caster.level, Point(x, y), effective_radius, ignore_walls=not self.get_stat('requires_los'))

	def get_impacted_tiles(self, x, y):
		for stage in self.get_aoe(x, y):
			for point in stage:
				unit = self.caster.level.get_unit_at(point.x, point.y)
				if self.get_stat('shaped_blast') and unit and not are_hostile(unit, self.caster): continue
				yield point

	def get_ai_target(self):
		return Spell.get_corner_target(self, self.get_stat('radius'))

class MeteorShower(Spell):

	def on_init(self):
		self.name = "Rain of Fire"

		self.num_targets = 7
		self.radius = 3

		self.range = RANGE_GLOBAL

		self.max_charges = 1

		self.tags = [Tags.Fire, Tags.Sorcery]
		self.level = 9

		self.max_channel = 10

		self.upgrades['chaos'] = (1, 7, "Chaos Storm", "Each impact casts Annihilate on [{num_targets}:num_targets] enemies within [{radius}:radius] tiles", [Tags.Chaos], None, {'num_targets': 2, 'radius': 3})
		self.upgrades['dragons'] = (1, 9, "Rain of Dragons", "Each impact has a 20% chance of casting your Fire Drake spell as well", [Tags.Dragon])
		self.upgrades['pyrostatic'] = (1, 7, "Pyrostatic Storm", "Each impact casts Lightning Bolt on up to [{num_targets}:num_targets] enemies in its line of sight", [Tags.Lightning], None, {'num_targets': 2})
		self.upgrades['ritual'] = (1, 8, "Ritual of Explosions", "Cast Flame Burst each turn you channel\nIf you complete the ritual, gain [100% Fire:fire] resistance until the end of the level", [Tags.Ritual])


	def get_description(self):
		return ("Cast Fireball targeting [{num_targets}:num_targets] random tiles in a [{radius}:radius] tile radius each turn\n"
				"This spell can be channeled for up to [{max_channel}:max_channel] turns")

	def get_impacted_tiles(self, x, y):
		fireball = self.caster.get_or_make_spell(FireballSpell)
		impacted = set()
		for target in self.caster.level.get_points_in_ball(x, y, self.get_stat('radius')):
			for point in fireball.get_impacted_tiles(target.x, target.y):
				impacted.add(point)
		return impacted

	def cast(self, x, y, channel_cast=False):

		if not channel_cast and self.is_manual_cast():
			self.caster.apply_buff(ChannelBuff(self.cast, Point(x, y)), self.get_stat('max_channel'))
			return

		caster = self.caster
		level = caster.level
		act_cast = level.act_cast

		points_in_ball = list(level.get_points_in_ball(x, y, self.get_stat('radius')))

		if level.tiles[x][y].is_wall(): level.make_floor(x, y)

		fireball = self.owner.get_or_make_spell(FireballSpell)

		ritual = self.get_stat('ritual')
		if ritual: fburst = caster.get_or_make_spell(FlameBurstSpell)

		chaos = self.get_stat('chaos')
		if chaos:
			annihilate = caster.get_or_make_spell(AnnihilateSpell)
			chaos_radius = self.get_stat('radius', base=3)
			chaos_num_targets = self.get_stat('num_targets', base=2)

		dragons = self.get_stat('dragons')
		if dragons: fire_drake = caster.get_or_make_spell(SummonFireDrakeSpell)

		pyrostatic = self.get_stat('pyrostatic')
		if pyrostatic:
			lbolt = caster.get_or_make_spell(LightningBoltSpell)
			pyrostatic_num_targets = self.get_stat('num_targets', base=2)

		if ritual and channel_cast:
			if caster.has_buff(ChannelBuff):
				for _ in act_cast(caster, fburst, caster.x, caster.y, pay_costs=False, queue=False): pass
			else: caster.apply_buff(ResistBuff(Tags.Fire, res=100))

		for _ in range(self.get_stat('num_targets')):
			target = random.choice(points_in_ball)
			for _ in act_cast(caster, fireball, target.x, target.y, pay_costs=False, queue=False): yield

			if chaos:
				targets = [t for t in level.get_units_in_ball(target, chaos_radius) if are_hostile(caster, t)]
				random.shuffle(targets)
				targets = targets[:chaos_num_targets]
				for t in targets:
					for _ in act_cast(caster, annihilate, t.x, t.y, pay_costs=False, queue=False, origin_point=target): pass

			if pyrostatic:
				targets = [t for t in level.get_units_in_los(target) if are_hostile(caster, t)]
				random.shuffle(targets)
				targets = targets[:pyrostatic_num_targets]
				for t in targets:
					for _ in act_cast(caster, lbolt, t.x, t.y, pay_costs=False, queue=False, origin_point=target): pass


			if dragons and random.random() < .2:
				for _ in act_cast(caster, fire_drake, target.x, target.y, pay_costs=False, queue=False): pass

class ThunderGod(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)

	def on_init(self):
		self.name = "Thunder God"
		self.color = Tags.Lightning.color
		self.description = "Cast Rain of Thunderbolts at the end of each turn"

	def on_advance(self):
		self.owner.level.act_cast(self.owner, self.spell, self.owner.x, self.owner.y, pay_costs=False, is_echo=True)

class RainOfThunderbolts(Spell):

	def on_init(self):
		self.name = "Rain of Thunderbolts"
		self.max_charges = 1
		self.tags = [Tags.Lightning, Tags.Sorcery]
		self.level = 7


		self.max_channel = 12
		self.range = 0
		self.num_targets = 12

		self.accepted_clouds = {StormCloud, BlizzardCloud, RainCloud}


		self.upgrades['dragons'] = (1, 9, "Tempest Drakes", "Each strike has a 20% chance of casting your Storm Drake spell", [Tags.Dragon])
		self.upgrades['all_weather'] = (1, 6, "Cryostorm", "Rain of Thunderbolts may also target [Blizzards:ice] or [Rain Clouds:nature], but casts Iceball on them instead of Thunder Strike", [Tags.Ice])
		self.upgrades['stormbringer'] = (1, 7, "Stormbringer", "Each turn you channel, summon [{num_targets}:num_targets] [Storm Clouds:lightning] at random locations", None, None, {'num_targets': 12})
		self.upgrades['god'] = (1, 8, "Thunder God", "Instead of channeling this spell, when you cast it, you get a buff for [{max_channel}:max_channel] turns which causes its effects to trigger as though you had channeled it at the end of each turn", [Tags.Enchantment], None, {'max_channel':12})

		self.add_upgrade_tooltip("Thunder God", lambda: ThunderGod(self))

	def get_description(self):
		return ("Cast Thunder Strike targeting up to [{num_targets}:num_targets] [Storm Clouds:lightning] each turn\n"
				"Clouds with enemies in them are prioritized\n"
				"Will not target the caster or their allies\n"
				"This spell can be channeled for up to [{max_channel}:max_channel] turns")

	def cast(self, x, y, channel_cast=False, is_echo=False):
		god = self.get_stat('god')
		caster = self.caster
		level = caster.level

		if god and not is_echo:
			caster.apply_buff(ThunderGod(self), self.get_stat('max_channel'))
			return

		if not channel_cast and not god and self.is_manual_cast():
			caster.apply_buff(ChannelBuff(self.cast, Point(x, y)), self.get_stat('max_channel'))
			return

		thunderstrike = caster.get_or_make_spell(ThunderStrike)
		storm_drake = caster.get_or_make_spell(SummonStormDrakeSpell)
		ice_ball = caster.get_or_make_spell(Iceball)

		all_weather = self.get_stat('all_weather')
		dragons = self.get_stat('dragons')
		stormbringer = self.get_stat('stormbringer')

		if all_weather: targets = [c for c in level.clouds if type(c) in self.accepted_clouds]
		else: targets = [c for c in level.clouds if isinstance(c, StormCloud)] # storm clouds only
		enemies = []
		empty = []
		for t in targets:
			u = level.get_unit_at(t.x, t.y)
			if not u: empty.append(t)
			elif u and are_hostile(caster, u): enemies.append(t)

		if enemies: random.shuffle(enemies)
		if empty: random.shuffle(empty)
		targets = enemies + empty

		for target in targets[:self.get_stat('num_targets')]:
			if all_weather:
				if isinstance(target, StormCloud): level.act_cast(caster, thunderstrike, target.x, target.y, pay_costs=False)
				else: level.act_cast(caster, ice_ball, target.x, target.y, pay_costs=False)
			else: level.act_cast(caster, thunderstrike, target.x, target.y, pay_costs=False)

			if dragons and random.random() < .2:
					level.act_cast(caster, storm_drake, target.x, target.y, pay_costs=False, queue=True)

		if stormbringer:
			targets = [p for p in level.iter_tiles()
					   if(
							not level.tiles[p.x][p.y].cloud
							and not level.tiles[p.x][p.y].is_wall()
							and (p.x, p.y) != (caster.x, caster.y))]

			random.shuffle(targets)
			targets = targets[:self.get_stat('num_targets')]
			for target in targets:
				cloud = StormCloud(caster)
				level.add_obj(cloud, target.x, target.y)

			yield

class RepeaterCast(Buff):

	def __init__(self, spell, x, y):
		Buff.__init__(self)
		self.spell = spell
		self.name = f"{spell.name} Repeater"
		self.description = ("Recast {spell_name} at the end of your turn", {"spell_name": spell.name})
		self.color = spell.tags[0].color
		self.target_x = x
		self.target_y = y
		self.stack_type = STACK_INTENSITY

	def on_advance(self):
		self.owner.level.act_cast(self.owner, self.spell, self.target_x, self.target_y, pay_costs=False, is_echo=True)

class LightningBoltSpell(Spell):

	def on_init(self):
		self.damage = 12
		self.range = 8
		self.name = "Lightning Bolt"
		self.max_charges = 14
		self.damage_type = [Tags.Lightning]

		self.tags = [Tags.Lightning, Tags.Sorcery]
		self.level = 1

		self.upgrades[('scrolls', 'minion_health')] = ([1, 5], 3, "Electric Ink", "When Lightning Bolt kills a unit, summon a Living Lightning Scroll that can cast your Lightning Bolt once\nWhen it casts the spell it dies")
		self.upgrades['energy'] = (1, 5, "Energy Bolt", "Lightning Bolt also deals [Arcane] damage", [Tags.Arcane], [Tags.Arcane])
		self.upgrades['stormbolt'] = (1, 3, "Stormbolt", "Create [Storm Clouds:lightning] on affected tiles", [Tags.Nature])
		self.upgrades[('repeater', 'duration')] = ([1, 2], 6, "Repeater Bolts", "Lightning Bolt will be recast at the target location at the end of your turn for [{duration}:duration] turns")

		self.add_upgrade_tooltip("Electric Ink", self.scroll)

		self.suicide = False

	def get_description(self):
		return "Deal [{damage}:damage] [Lightning] damage in a beam"

	def scroll(self):
		scroll = LivingLightningScroll()
		scroll.spells = []
		apply_minion_bonuses(self, scroll)

		# Make sure that the parent is the original wizard, not the current living spell scroll
		spell_parent = self.statholder if self.statholder else self.caster

		spell = grant_minion_spell(LightningBoltSpell, scroll, spell_parent, 0)
		spell.suicide = True
		return scroll

	def cast(self, x, y, is_echo=False, origin_point=None):
		caster = self.caster
		level = caster.level
		getu = level.get_unit_at
		deal_damage = level.deal_damage

		if self.get_stat('repeater') and not is_echo: caster.apply_buff(RepeaterCast(self, x, y), self.get_stat('duration'))

		start = origin_point or caster
		target = Point(x, y)

		dtypes = self.get_stat('damage_type')
		dmg = self.get_stat('damage')

		scroll = self.get_stat('scrolls')
		queue_spell = level.queue_spell

		stormbolt = self.get_stat('stormbolt')
		if stormbolt: add_obj = level.add_obj

		for dtype in dtypes:
			for point in Bolt(level, start, target, find_clear=self.get_stat('requires_los')):
				if scroll: unit = getu(*point)
				else: unit = None
				deal_damage(point.x, point.y, dmg, dtype, self)
				if unit and not unit.is_alive(): queue_spell(self.do_scroll(unit)) # self.summon(self.scroll(), target=unit)
				if stormbolt: add_obj(StormCloud(caster, dmg), point.x, point.y)
			for i in range(4): yield

		# For scrolls
		if self.suicide: caster.kill()

	def do_scroll(self, target):
		self.summon(self.scroll(), target=target)
		yield

	def get_impacted_tiles(self, x, y):
		start = Point(self.caster.x, self.caster.y)
		target = Point(x, y)
		return list(Bolt(self.caster.level, start, target, find_clear=self.get_stat('requires_los')))

class AnnihilateSpell(Spell):

	def on_init(self):
		self.range = 5
		self.name = "Annihilate"
		self.max_charges = 10
		self.damage = 16
		self.tags = [Tags.Chaos, Tags.Sorcery]
		self.damage_type = [Tags.Fire, Tags.Lightning, Tags.Physical]
		self.level = 2

		self.upgrades['assured_destruction'] = (1, 1, 'Assured Destruction', 'If you are able, when you cast this spell, use an additional charge to cast it again if the target lives')
		self.upgrades['cascade'] =  (1, 2, 'Cascade', 'If Annihilate kills a unit, any remaining hits will jump to an enemy within range of the killed unit\nIgnores line of sight')
		self.upgrades['comprehensive'] =  (1, 7, 'Comprehensive Annihilation', 'Annihilate also deals [Ice], [Holy], [Dark], and [Arcane] damage hits', [Tags.Ice, Tags.Holy, Tags.Dark, Tags.Arcane], [Tags.Ice, Tags.Holy, Tags.Dark, Tags.Arcane])
		self.upgrades['damage'] = (666, 9, 'Mega Annihilate')

	def get_description(self):
		return ("Deal [{damage}:damage] [Fire], [Lightning], and [Physical] damage to the target")

	def cast(self, x, y, origin_point=None):
		dmg = self.get_stat('damage')
		cascade = self.get_stat('cascade')
		cascade_range = self.get_stat('range')
		dtypes = self.get_stat('damage_type')

		caster = self.caster
		level = caster.level
		deal_damage = level.deal_damage

		unit_target = level.get_unit_at(x, y)

		targets = [Point(x, y)]
		level.show_path_effect(origin_point or caster, targets[0], Tags.Chaos)

		for cur_target in targets:
			for dtype in dtypes:
				if cascade and not level.get_unit_at(cur_target.x, cur_target.y):
					other_targets = [t for t in level.get_units_in_ball(cur_target, cascade_range) if are_hostile(t, caster)]
					if other_targets:
						new_target = random.choice(other_targets)
						level.show_path_effect(cur_target, new_target, Tags.Chaos)
						cur_target = new_target

				deal_damage(cur_target.x, cur_target.y, dmg, dtype, self)
				for i in range(3): yield

		if self.get_stat('assured_destruction') and caster.is_player_controlled: # is_player_controlled check to prevent awkwardness with allies casting it
			unit = level.get_unit_at(x, y)
			if unit and unit.is_alive() and unit is unit_target:
				if self.can_pay_costs():
					self.cur_charges -= 1
					level.act_cast(caster, self, x, y, pay_costs=False)

class StormWalk(Spell):

	def on_init(self):
		self.name = "Storm Walk"
		self.tags = [Tags.Ice, Tags.Lightning, Tags.Nature, Tags.Translocation]
		self.level = 3
		self.range = 50
		self.requires_los = False
		self.max_charges = 12
		self.cloud_match = {StormCloud:Tags.Lightning, BlizzardCloud: Tags.Ice, RainCloud: Tags.Nature}

		self.upgrades['quick_cast'] = (1, 2, "Quickcast", "Storm Walk gains quickcast")
		self.upgrades['weathered'] = (1, 3, "Weathered Traveler", "Leave behind a line of matching clouds between you and your destination")
		self.upgrades['boon'] = (1, 3, "Storm Boon", "Gain a boon depending on the kind of cloud you Storm Walk to\n[Rain Clouds:nature] remove all debuffs\n[Blizzards:ice] grant 3 [SH:shields]\n[Lightning Clouds:lightning] grant 3 turns of [quickstep:translocation]")
		self.upgrades['surge'] = (1, 5, "Storm Surge", "Cast Storm Burst after arriving at your destination")

	def get_description(self):
		return ("Teleport to target unoccupied tile"
				"\nCan only target tiles with a [Rain Cloud:nature], [Storm Cloud:lightning], or [Blizzard:ice]"
				"\nConsumes the target cloud")

	def can_cast(self, x, y):
		level = self.caster.level
		cloud = level.tiles[x][y].cloud
		if type(cloud) not in self.cloud_match: return False
		if not level.can_stand(x, y, self.caster): return False
		return Spell.can_cast(self, x, y)

	def do_boon(self, c):
		if c is BlizzardCloud: self.caster.add_shields(3)
		elif c is StormCloud: self.caster.apply_buff(QuickmoveBuff(), 3)
		elif c is RainCloud:
			for b in list(self.caster.buffs):
				if b.buff_type == BUFF_TYPE_CURSE:
					self.caster.remove_buff(b)

	def cast_instant(self, x, y):
		if not self.caster.level.can_move(self.caster, x, y, teleport=True): return
		target_cloud = self.caster.level.tiles[x][y].cloud
		cloud_type = type(target_cloud)
		effect_tag = self.cloud_match.get(cloud_type)
		if not effect_tag: return # abort if we some how cast where we're not supposed to
		weathered = self.get_stat('weathered')
		for p in self.caster.level.get_points_in_line(self.caster, target_cloud):
			self.caster.level.show_effect(p.x, p.y, effect_tag)
			if weathered: self.caster.level.add_obj(cloud_type(self.caster), p.x, p.y)
		self.caster.level.act_move(self.caster, x, y, teleport=True)
		if self.get_stat('boon'): self.do_boon(cloud_type)
		if self.get_stat('surge'): self.caster.level.act_cast(self.caster, self.caster.get_or_make_spell(StormBurst), x, y, pay_costs=False)
		if target_cloud.is_alive: target_cloud.kill()

class Teleport(Spell):

	def on_init(self):
		self.range = 16
		self.requires_los = False
		self.name = "Teleport"
		self.max_charges = 2

		self.must_target_empty = True

		self.tags = [Tags.Sorcery, Tags.Arcane, Tags.Translocation]
		self.level = 5

		self.upgrades[('group_teleport', 'num_targets')] = ([1, 10], 1, "Group Teleport", "Also teleports up to [{num_targets}:num_targets] allies to locations near the destination")
		self.upgrades['quick_cast'] = (1, 3, "Quickcast", "Teleport gains quickcast")
		self.upgrades[('assassin', 'damage', 'duration')] = ([1, 60, 3], 3, "Assassinate", "If you Teleport adjacent to an enemy who could not see your original location, attempt to assassinate them, inflicting [{damage}:damage] [Arcane] damage and [{duration}:duration] turns of [silence]\nIf this kills an enemy, the Teleport charge is refunded") # special void dagger effect?
		self.upgrades['void_teleport'] = (1, 5, "Void Teleport", "Teleport deals [Arcane] damage to enemies in line of sight of the destination equal to its [max charges:max_charges]")

	def get_description(self):
		return "Teleport to target tile"

	def can_cast(self, x, y):
		return Spell.can_cast(self, x, y) and self.caster.level.can_move(self.caster, x, y, teleport=True)

	def cast(self, x, y):
		caster = self.caster
		level = caster.level

		start_loc = Point(caster.x, caster.y)
		level.show_effect(caster.x, caster.y, Tags.Translocation)
		p = level.get_summon_point(x, y, flying=caster.flying, burrowing=caster.burrowing)
		if not p: return
		if start_loc == Point(x, y): p = start_loc
		else:
			yield level.act_move(caster, p.x, p.y, teleport=True)
			level.show_effect(caster.x, caster.y, Tags.Translocation)

		if self.get_stat('group_teleport'):
			eligible_targets = [u for u in level.units if not are_hostile(u, caster) and u != caster]
			if eligible_targets:
				random.shuffle(eligible_targets)
				for i in range(min(len(eligible_targets), self.get_stat('num_targets'))):
					target = eligible_targets[i]
					teleport_point = level.get_summon_point(x, y, unit=target)
					if teleport_point:
						yield level.act_move(eligible_targets[i], teleport_point.x, teleport_point.y, teleport=True)
						level.show_effect(eligible_targets[i].x, eligible_targets[i].y, Tags.Translocation)

		if self.get_stat('void_teleport'):
			charge_dmg = self.get_stat('max_charges')
			for unit in level.get_units_in_los(caster):
				if not are_hostile(caster, unit): continue
				unit.deal_damage(charge_dmg, Tags.Arcane, self)

		if self.get_stat('assassin'):
			damage = self.get_stat('damage')
			duration = self.get_stat('duration')
			targets = set()
			for pt in level.get_adjacent_points(p, False, False, caster.radius):
				u = level.get_unit_at(pt.x, pt.y)
				if not u: continue
				if not are_hostile(caster,u): continue
				if level.can_see(pt.x, pt.y, start_loc.x, start_loc.y): continue
				targets.add(u)
			for target in targets: target.deal_damage(damage, Tags.Arcane, self); target.apply_buff(Silence(), duration)
			if any(not u.is_alive() for u in targets): self.refund_charges(1)

	def get_ai_target(self):
		points = [p for p in self.owner.level.get_points_in_ball(self.owner.x, self.owner.y, self.get_stat('range'))]
		points = [p for p in points if self.can_cast(p.x, p.y)]
		if not points: return None
		return random.choice(points)


class BlinkSpell(Spell):

	def on_init(self):
		self.range = 5
		self.requires_los = True
		self.name = "Blink"
		self.max_charges = 6
		self.tags = [Tags.Arcane, Tags.Sorcery, Tags.Translocation]
		self.level = 3

		self.upgrades[('aether_swap', 'damage')] = ([1, 16], 1, "Aether Swap", "You may now cast Blink targeting a unit\nDoing so causes you to swap places with them, and deals [{damage}:damage] [Arcane] damage")
		self.upgrades['requires_los'] = (-1, 2, "Blindcasting", "Blink can be cast outside your line of sight")
		self.upgrades['dispersal'] = (1, 3, "Dissolution", "Casting Blink also casts Disperse on the target")
		self.upgrades[('thunder', 'num_targets')] = ([1, 2], 5, "Thunderblink", "Casting Blink also casts Thunder Strike on the [{num_targets}:num_targets] nearest enemies in line of sight of the target", [Tags.Lightning])

	def get_description(self):
		return "Teleport to target tile"

	def get_ai_target(self):
		points = [p for p in self.caster.level.get_points_in_ball(self.caster.x, self.caster.y, self.get_stat('range')) if self.can_cast(p.x, p.y)]
		if not points: return None
		if not self.get_stat('aether_swap'): return random.choice(points)

		# special targeting rules for aether swap
		preferred = []
		safe = []
		level = self.caster.level
		for p in points:
			u = level.get_unit_at(p.x, p.y)
			if not u: safe.append(p); continue
			vuln = u.resists[Tags.Arcane] < 100
			if vuln and are_hostile(self.caster, u): preferred.append(p) # prefer enemies it can damage
			elif not vuln: safe.append(p) # avoids arcane vulnerable allies

		if preferred: return random.choice(preferred)
		if safe: return random.choice(safe)
		return None

	def can_cast(self, x, y):
		caster = self.caster
		aether = self.get_stat('aether_swap')
		unit = caster.level.get_unit_at(x, y)
		if unit:
			if aether:
				# Cant swap with giants
				if unit.radius: return False

				# Ensure the caster can go where he is trying to go
				if not caster.level.can_stand(x, y, caster, check_unit=False): return False

				# Ensure that the target can stand where its getting swapped to (prevent flying crash)
				if not caster.level.can_stand(caster.x, caster.y, unit, check_unit=False): return False

				return Spell.can_cast(self, x, y)
			else: return False
		return Spell.can_cast(self, x, y) and caster.level.can_move(caster, x, y, teleport=True)

	def cast_aether_swap(self, x, y):
		target = self.caster.level.get_unit_at(x, y)
		if target == self.caster: return

		# Fizzle if attempting to cast on non walkable tile
		if self.caster.level.can_move(self.caster, x, y, teleport=True, force_swap=True):
			self.caster.level.act_move(self.caster, x, y, teleport=True, force_swap=True)

		target.deal_damage(self.get_stat('damage'), Tags.Arcane, self)

	def cast(self, x, y):
		u = self.caster.level.get_unit_at(x, y)
		if u and self.get_stat('aether_swap'): self.cast_aether_swap(x, y)

		start_loc = Point(self.caster.x, self.caster.y)

		self.caster.level.show_effect(self.caster.x, self.caster.y, Tags.Translocation)
		p = self.caster.level.get_summon_point(x, y, flying=self.caster.flying, burrowing=self.caster.burrowing) # incorporate teleporting into walls if burrowing
		if not p: return

		if start_loc == Point(x, y): p = start_loc
		else:
			yield self.caster.level.act_move(self.caster, p.x, p.y, teleport=True)
			self.caster.level.show_effect(self.caster.x, self.caster.y, Tags.Translocation)

		if self.get_stat('dispersal'):
			disperse = self.caster.get_or_make_spell(Disperse)
			self.caster.level.act_cast(self.caster, disperse, p.x, p.y, pay_costs=False)

		if self.get_stat('thunder'):
			self.caster.level.queue_spell(self.do_thunderblink_strikes())

	def do_thunderblink_strikes(self):
		caster = self.caster
		tstrike = caster.get_or_make_spell(ThunderStrike)
		enemies = [u for u in caster.level.get_units_in_los(caster) if are_hostile(u, caster)]
		enemies.sort(key=lambda u: caster.level.unit_distance(u, caster))
		n = self.get_stat('num_targets')
		for u in enemies[:n]:
			caster.level.act_cast(caster, tstrike, u.x, u.y, pay_costs=False, queue=True)
			yield

class FlameGateBuff(Buff):

	def __init__(self, spell):
		Buff.__init__(self)
		self.name = "Flame Gate"
		self.spell = spell
		self.buff_type = BUFF_TYPE_BLESS
		self.asset = ['status', 'flame_gate']
		self.description = "When you cast a [Fire] spell, summon a temporary Fire Elemental near the target\nThis effect ends if you move or manually cast a spell without the [Fire] tag"
		self.searing_gate = self.spell.get_stat('searing_gate')
		self.searing_damage = self.spell.get_stat('damage', base=1)
		self.radius = self.spell.get_stat('radius')

	def on_applied(self, owner):
		self.owner_triggers[EventOnSpellCast] = self.on_spell_cast
		self.owner_triggers[EventOnMoved] = self.on_move
		self.color = Color(255, 0, 0)

	def on_spell_cast(self, spell_cast_event):
		if Tags.Fire in spell_cast_event.spell.tags:
			self.owner.level.queue_spell(self.make_elemental(spell_cast_event))
			if self.searing_gate: self.radius += 1
		elif spell_cast_event.pay_costs: self.owner.remove_buff(self)

	def on_move(self, evt):
		self.owner.remove_buff(self)

	def make_elemental(self, spell_cast_event):
		elemental = self.spell.make_elemental()
		self.spell.summon(elemental, target=spell_cast_event)
		yield

	def on_advance(self):
		if self.searing_gate:
			targets = [u for u in self.owner.level.get_units_in_ball(self.owner, self.radius) if are_hostile(u, self.owner)]
			for u in targets: u.deal_damage(self.searing_damage, Tags.Fire, self.spell)

	def get_description(self):
		if not self.searing_gate: return self.description
		return [self.description] + [("\nEach turn, deal [{damage}:damage] [Fire] damage to enemies within [{radius}:radius] tiles\nThis radius increases when you cast a [Fire] spell", {'damage': self.searing_damage, 'radius': self.radius})]


class StarfireGateBuff(Buff):

	def __init__(self, spell):
		Buff.__init__(self)
		self.name = "Starfire Gate"
		self.spell = spell
		self.buff_type = BUFF_TYPE_BLESS
		self.asset = ['status', 'flame_gate']
		self.description = "When you cast a [Fire] or [Arcane] spell, summon a temporary Starfire Elemental near the target\nThis effect ends if you move or manually cast a spell without the [Fire] or [Arcane] tags"
		self.searing_gate = self.spell.get_stat('searing_gate')
		self.searing_damage = self.spell.get_stat('damage', base=1)
		self.radius = self.spell.get_stat('radius')

	def on_applied(self, owner):
		self.owner_triggers[EventOnSpellCast] = self.on_spell_cast
		self.owner_triggers[EventOnMoved] = self.on_move
		self.color = Color(255, 0, 0)

	def on_move(self, _evt):
		self.owner.remove_buff(self)

	def on_spell_cast(self, spell_cast_event):
		if Tags.Fire in spell_cast_event.spell.tags or Tags.Arcane in spell_cast_event.spell.tags:
			self.owner.level.queue_spell(self.make_elemental(spell_cast_event))
			if self.searing_gate: self.radius += 1
		elif spell_cast_event.pay_costs: self.owner.remove_buff(self)

	def make_elemental(self, spell_cast_event):
		elemental = self.spell.make_elemental(StarfireElemental)
		self.spell.summon(elemental, target=spell_cast_event)
		yield

	def on_advance(self):
		if self.searing_gate:
			targets = [u for u in self.owner.level.get_units_in_ball(self.owner, self.radius) if are_hostile(u, self.owner)]
			for u in targets: u.deal_damage(self.searing_damage, Tags.Fire, self.spell)

	def get_description(self):
		if not self.searing_gate: return self.description
		return [self.description] + [("\nEach turn, deal [{damage}:damage] [Fire] damage to enemies within [{radius}:radius] tiles\nThis radius increases when you cast a [Fire] or [Arcane] spell", {'damage': self.searing_damage, 'radius': self.radius})]


class FlameGateSpell(Spell):

	def on_init(self):
		self.range = 0
		self.max_charges = 3
		self.name = "Flame Gate"
		self.tags = [Tags.Fire, Tags.Enchantment, Tags.Conjuration]
		self.level = 3

		self.radius = 0
		self.minion_damage = 7
		self.minion_health = 22
		self.minion_range = 4
		self.minion_duration = 12

		self.upgrades[('gatewatch', 'num_summons')] = ([1, 3], 2, "Gatewatch", "Immediately summon [{num_summons}:num_summons] Fire Elementals when you cast this spell")
		self.upgrades['cast_eye'] = (1, 5, "Eye Gate", "Fire Elementals can cast your Eye of Fire on a 10 turn cool down")
		self.upgrades['starfire_summon'] = (1, 4, "Starfire Gate", "Instead applies Starfire Gate\nStarfire Gate can be sustained with both [Fire] and [Arcane] spells\nStarfire Gate summons Starfire Elementals instead of Fire Elementals", [Tags.Arcane])
		self.upgrades[('searing_gate', 'damage', 'radius')] = ([1, 1, 1], 4, "Searing Gate", "Flame Gate deals [{damage}:damage] [Fire] damage to enemies within [{radius}:radius] tiles of you each turn\nThis radius increases by 1 each time you cast a [Fire] spell")

		self.add_upgrade_tooltip("Starfire Gate", lambda: self.make_elemental(StarfireElemental))

	def get_impacted_tiles(self, x, y):
		if not self.get_stat('searing_gate'): return [Point(x, y)]
		return Spell.get_impacted_tiles(self, x, y)

	def cast(self, x, y):
		if self.get_stat('starfire_summon'):
			self.caster.apply_buff(StarfireGateBuff(self), 0)
			if self.get_stat('gatewatch'):
				for i in range(self.get_stat('num_summons')):
					elemental = self.make_elemental(StarfireElemental)
					self.summon(elemental, self.caster)
		else:
			self.caster.apply_buff(FlameGateBuff(self), 0)
			if self.get_stat('gatewatch'):
				for i in range(self.get_stat('num_summons')):
					elemental = self.make_elemental()
					self.summon(elemental, self.caster)
		yield

	def make_elemental(self, spawn_fn=FireElemental):
		elemental = make_minion(self, spawn_fn)
		if self.get_stat('cast_eye'): grant_minion_spell(EyeOfFireSpell, elemental, self.caster, cool_down=10)
		return elemental

	def get_extra_examine_tooltips(self):
		return [self.make_elemental()] + self.get_upgrade_tooltips()

	def get_description(self):
		return ("When you cast a [Fire] spell, summon a temporary Fire Elemental near the target\n"
				"This effect ends if you move or manually cast a spell without the [Fire] tag")

class LightningFormBuff(Buff):

	def __init__(self, spell):
		Buff.__init__(self)
		self.spell = spell
		self.transform_asset = ["char", "player_lightning_form"]
		self.name = "Lightning Form"
		self.buff_type = BUFF_TYPE_BLESS
		self.asset = ['status', 'lightning_form']
		self.color = Tags.Lightning.color
		self.cast = True
		self.stack_type = STACK_TYPE_TRANSFORM

		self.fire_form = self.spell.get_stat('fire_form')
		self.lingering_form = self.spell.get_stat('lingering_form')
		self.crackling_aura = self.spell.get_stat('crackling_aura')
		self.momentum = self.spell.get_stat('momentum')
		self.aura_damage = self.spell.get_stat('damage')
		self.aura_num_targets = self.spell.get_stat('num_targets')
		self.aura_radius = self.spell.get_stat('radius')
		self.check_tags = [Tags.Lightning]
		if self.fire_form:
			self.check_tags = [Tags.Lightning, Tags.Fire]
			self.resists[Tags.Fire] = 100

		self.resists[Tags.Lightning] = 100
		self.resists[Tags.Physical] = 100

		self.linger = 3

	def get_description(self):
		tag_text = "[Lightning]"
		if self.fire_form: tag_text = "[Lightning] or [Fire]"
		desc = "When you cast a %s spell, if the target tile is unoccupied, teleport to that tile" % tag_text
		if self.lingering_form: desc += "\nIf you do not cast a %s spell on your turn, this buff lasts 3 more turns" % tag_text
		else: desc += "\nLose this buff the first turn you do not cast a %s spell on your turn" % tag_text
		if self.crackling_aura: desc += "\nEach turn, deal [{damage}:damage] [Lightning] damage to up to [{num_targets}:num_targets] enemies within [{radius}:radius] tiles"
		if self.momentum: desc += "\nEach turn Lightning Form remains active, [Lightning] spells and equipment gain 10% [damage]"
		return (desc, {'damage': self.aura_damage, 'num_targets': self.aura_num_targets, 'radius': self.aura_radius})


	def on_advance(self):
		if self.cast == False:
			if not self.lingering_form: self.owner.remove_buff(self)
			else: self.linger -= 1
			if self.linger <= 0: self.owner.remove_buff(self)
		else: self.linger = 3
		self.cast = False

		if self.momentum:
			self.tag_bonuses_pct[Tags.Lightning]['damage'] += 10
			self.owner.adjust_tag_bonus(Tags.Lightning, 'damage', 10, pct=True)

		if self.crackling_aura:
			targets = [u for u in self.owner.level.get_units_in_ball(self.owner, self.aura_radius) if are_hostile(self.owner, u)]
			random.shuffle(targets)

			for i in range(min(self.aura_num_targets, len(targets))):
				if targets[i] and targets[i].is_alive():
					targets[i].deal_damage(self.aura_damage, Tags.Lightning, self.spell)

	def on_applied(self, caster):
		self.owner_triggers[EventOnSpellCast] = self.on_spell_cast
		self.owner_triggers[EventOnPass] = self.on_pass

	def on_spell_cast(self, spell_cast_event):
		for tag in self.check_tags:
			if tag in spell_cast_event.spell.tags:
				self.cast = True
				if self.owner.level.can_move(self.owner, spell_cast_event.x, spell_cast_event.y, teleport=True):
					self.owner.level.queue_spell(self.do_teleport(spell_cast_event.x, spell_cast_event.y))


	def on_pass(self, evt):
		if self.owner.has_buff(ChannelBuff):
			self.cast = True

	def do_teleport(self, x, y):
		if self.owner.x == x and self.owner.y == y: return # don't teleport in place
		if self.owner.level.can_move(self.owner, x, y, teleport=True):
			yield self.owner.level.act_move(self.owner, x, y, teleport=True)

class LightningFormSpell(Spell):

	def on_init(self):
		self.range = 0
		self.max_charges = 3
		self.name = "Lightning Form"
		self.physical_resistance = 0

		self.tags = [Tags.Lightning, Tags.Enchantment, Tags.Translocation]
		self.level = 4

		self.upgrades['lingering_form'] = (1, 1, "Lingering Form", "Lasts 3 turns after you cast a [Lightning] spell")
		self.upgrades['fire_form'] = (1, 3, "Fire Form", "Also works on [Fire] spells and grants [100 Fire:fire] resist", [Tags.Fire])
		self.upgrades[('crackling_aura', 'damage', 'num_targets', 'radius')] = ([1, 5, 4, 5], 3, "Crackling Aura", "Each turn, Lightning Form deals [{damage}:damage] [Lightning] damage to up to [{num_targets}:num_targets] enemies within [{radius}:radius] tiles")
		self.upgrades['momentum'] = (1, 5, "Gathering Momentum", "Each turn Lightning Form is active, [Lightning] spells and equipment gain 10% [damage]\nThis bonus is removed with Lightning Form")

	def cast(self, x, y):
		self.caster.apply_buff(LightningFormBuff(self))
		yield

	def get_description(self):
		return ("When you cast a [Lightning] spell, if the target tile is unoccupied, teleport to that tile\n"
				"Gain [100 Lightning:lightning] resistance\n"
				"Gain [100 Physical:physical] resistance\n"
				"Lightning Form ends if you fail to cast a [Lightning] spell on your turn")

	def get_extra_examine_tooltips(self):
		return [LightningFormBuff(self)] + self.get_upgrade_tooltips()


class VoidBeamResistDebuff(Buff):

	def on_init(self):
		self.buff_type = BUFF_TYPE_CURSE
		self.color = Tags.Arcane.color
		self.name = "Arcane Vulnerability"
		self.stack_type = STACK_INTENSITY
		self.resists[Tags.Arcane] = -25

class VoidBeamSpell(Spell):

	def on_init(self):
		self.range = 8
		self.max_charges = 8
		self.name = "Void Beam"
		self.requires_los = False
		self.damage = 25

		self.tags = [Tags.Arcane, Tags.Sorcery]
		self.damage_type = [Tags.Arcane]
		self.level = 4

		self.upgrades[('detonate', 'radius')] = ([1, 3], 2, "Detonation Beam", "If Void Beam kills the target unit, it detonates, dealing its damage to tiles in a [{radius}:radius] tile burst around the target")
		self.upgrades['starbeam'] = (1, 4, "Star Beam", "Void beam also deals [Fire] damage", [Tags.Fire], [Tags.Fire])
		self.upgrades['curse'] = (1, 3, "Void Curse", "Void Beam strips 50 [Arcane] resistance from its target before dealing damage")
		self.upgrades['voidpulse'] = (1, 4, "Void Pulse", "Sends out a wide pulse which also affects tiles adjacent to the center beam")

		self.add_upgrade_tooltip("Void Curse", lambda: ResistBuff(Tags.Arcane, res=-50))

	def aoe(self, x, y):
		start = Point(self.caster.x, self.caster.y)
		target = Point(x, y)
		path = Bolt(self.caster.level, start, target, two_pass=False, find_clear=False)
		for point in path:
			yield point

	def get_impacted_tiles(self, x, y):
		center_beam = list(self.aoe(x, y))

		side_beam = []
		if self.get_stat('voidpulse'):
			for p in center_beam:
				for q in self.caster.level.get_points_in_ball(p.x, p.y, 1.5):
					if q.x == self.caster.x and q.y == self.caster.y:
						continue
					if q not in center_beam and q not in side_beam:
						side_beam.append(q)

		path = center_beam + side_beam
		return path

	def cast(self, x, y):
		damage = self.get_stat('damage')
		dtypes = self.get_stat('damage_type')

		caster = self.caster
		level = caster.level
		getu = level.get_unit_at
		tiles = level.tiles
		make_floor = level.make_floor
		deal_damage = level.deal_damage

		target_unit = getu(x, y)

		if self.get_stat('curse') and target_unit: target_unit.apply_buff(ResistBuff(Tags.Arcane, res=-50))


		for point in self.get_impacted_tiles(x, y):
			if not tiles[point.x][point.y].can_see: make_floor(point.x, point.y)
			for dt in dtypes: deal_damage(point.x, point.y, damage, dt, self)
		yield

		if target_unit and self.get_stat('detonate') and not target_unit.is_alive():
			for stage in Burst(level, target_unit, self.get_stat('radius'), ignore_walls=True):
				for point in stage:
					if not tiles[point.x][point.y].can_see: make_floor(point.x, point.y)
					for dt in dtypes: deal_damage(point.x, point.y, damage, dt, self)
				yield


	def get_description(self):
		return "Deal [{damage}:damage] [Arcane] damage in a beam\nMelts walls"

class EnervatedBuff(Buff):

	def on_init(self):
		self.name = "Ennervated"
		self.color = Tags.Lightning.color
		self.buff_type = BUFF_TYPE_CURSE
		self.owner_triggers[EventOnSpellCast] = self.on_cast
		self.owner_triggers[EventOnMoved] = self.on_move

	def on_cast(self, evt):
		self.owner.apply_buff(Stun(), 2)

	def on_move(self, evt):
		self.owner.apply_buff(Stun(), 2)

class ThunderStrike(Spell):

	def on_init(self):
		self.range = 6
		self.max_charges = 12
		self.name = "Thunder Strike"
		self.damage = 24
		self.damage_type = [Tags.Lightning]
		self.radius = 2
		self.duration = 3

		self.tags = [Tags.Lightning, Tags.Sorcery]
		self.level = 2

		self.storm_power = 0
		self.upgrades['requires_los'] = (-1, 2, "Blindcasting", "Thunder Strike can be cast outside your line of sight")
		self.upgrades['storm_power'] = (1, 3, "Storm Power", "Refund a charge if the target tile has a [Storm Cloud:lightning]")
		self.upgrades['heaven_strike'] = (1, 4, "Heaven Strike", "Thunder Strike also deals [Holy] damage", [Tags.Holy], [Tags.Holy])
		self.upgrades['enervate'] = (1, 2, "Enervate", "Target receives the [Enervated:lightning] debuff, which [stuns] them for 1 turn when they move or cast a spell")

		self.add_upgrade_tooltip("Enervate", EnervatedBuff)

	def get_description(self):
		return ("Deal [{damage}:damage] [Lightning] damage to the target\n"
				"Enemies within [{radius}:radius] tiles of the target are [stunned] for [{duration}:duration] turns")

	def can_harm(self, target_unit):
		return Spell.can_harm(self, target_unit) or (are_hostile(self.caster, target_unit) and target_unit.can_be_stunned())

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		target = Point(x, y)
		getu = level.get_unit_at

		level.show_beam(caster, target, Tags.Lightning)
		in_cloud = isinstance(level.tiles[x][y].cloud, StormCloud)

		duration = self.get_stat('duration')
		radius = self.get_stat('radius')
		damage = self.get_stat('damage')

		if in_cloud and self.get_stat('storm_power'): self.refund_charges(1)

		for dtype in self.get_stat('damage_type'):
			level.deal_damage(x, y, damage, dtype, self)
			yield

		if self.get_stat('enervate'):
			unit = getu(x, y)
			if unit: unit.apply_buff(EnervatedBuff())

		for stage in Burst(level, target, radius, ignore_walls=not self.get_stat('requires_los')):
			for point in stage:
				level.show_effect(point.x, point.y, Tags.Thunderstrike)
				u = getu(point.x, point.y)
				if u and are_hostile(caster, u): u.apply_buff(Stun(), duration)
			yield

	def get_impacted_tiles(self, x, y):
		radius = self.get_stat('radius')
		return [p for stage in Burst(self.caster.level, Point(x, y), radius, ignore_walls=not self.get_stat('requires_los')) for p in stage]


class ChaosBarrage(Spell):

	def on_init(self):
		self.name = "Chaos Barrage"
		self.range = 6
		self.damage = 6
		self.num_targets = 9
		self.angle = math.pi / 6
		self.max_charges = 6
		self.tags = [Tags.Chaos, Tags.Sorcery]
		self.damage_type = [Tags.Fire, Tags.Lightning, Tags.Physical]
		self.can_target_self = False

		self.level = 2

		self.upgrades['num_targets'] = (9, 5, "Mega Barrage")
		self.upgrades['shockwaves'] = (1, 4, "Shockwaves", "Each bolt also deals damage to adjacent tiles")
		self.upgrades['smart_targeting'] = (1, 3, "Smart Bolts", "Chaos Barrage will not harm allies\nEach bolt will use the damage type its target resists the least")
		self.upgrades[('endless', 'max_channel')] = ([1, 4], 3, "Endless Barrage", "You may channel Chaos Barrage for [{max_channel}:max_channel] turns")

	def get_description(self):
		return ("Shoot up to [{num_targets}:num_targets] bolts of chaotic energy at units in a cone\n"
				"Each bolt deals [{damage}:damage] [Fire], [Lightning], or [Physical] damage")

	def get_cone_burst(self, x, y):
		target = Point(x, y)
		burst = Burst(self.caster.level, self.caster, self.get_stat('range'), expand_diagonals=True, burst_cone_params=BurstConeParams(target, self.angle), ignore_walls=not self.get_stat('requires_los'))
		return [p for stage in burst for p in stage]

	def cast(self, x, y, channel_cast=False):

		if self.get_stat('endless') and not channel_cast and self.is_manual_cast():
			self.caster.apply_buff(ChannelBuff(self.cast, Point(x, y)), self.get_stat('max_channel'))
			return

		cone_points = self.get_cone_burst(x, y)
		if not cone_points: return

		caster = self.caster
		level = caster.level
		deal_damage = level.deal_damage
		getu = level.get_unit_at
		show_beam = level.show_beam
		get_adjacent_points = level.get_adjacent_points

		shockwaves = self.get_stat('shockwaves')
		smart = self.get_stat('smart_targeting')

		possible_targets = [getu(p.x, p.y) for p in cone_points]
		possible_targets = [u for u in possible_targets if u and u != caster]
		if smart:
			possible_targets = [u for u in possible_targets if are_hostile(caster, u)]
			filtered_points = []
			for p in cone_points:
				u = getu(p.x, p.y)
				if u and are_hostile(caster, u): filtered_points.append(p)
			cone_points = filtered_points

		damage = self.get_stat('damage')
		dtypes = self.get_stat('damage_type')

		shoot_random = False

		for i in range(self.get_stat('num_targets')):
			if not shoot_random: possible_targets = [u for u in possible_targets if u.is_alive()]
			if not possible_targets:
				shoot_random = True
				possible_targets = cone_points # shoot random tiles if no units remain
				if not possible_targets: return


			target = random.choice(possible_targets)
			is_unit = isinstance(target, Unit)

			# If there are no points then do a random element even if smart targeting is enabled
			if smart and is_unit: dt = min(dtypes, key=lambda t: target.resists[t])
			else: dt = random.choice(dtypes)

			if is_unit and target.radius: target = random.choice(list(target.iter_occupied_points()))

			show_beam(caster, target, dt)
			deal_damage(target.x, target.y, damage, dt, self)


			if shockwaves:
				yield
				for p in get_adjacent_points(target, filter_walkable=False):
					if smart:
						u = getu(*p)
						if u and not are_hostile(u, caster): continue
						deal_damage(p.x, p.y, damage, dt, self)
					else: deal_damage(p.x, p.y, damage, dt, self)

			yield


	def get_impacted_tiles(self, x, y):
		return self.get_cone_burst(x, y)

class Disperse(Spell):

	def on_init(self):
		self.range = 6
		self.max_charges = 15
		self.name = "Disperse"
		self.tags = [Tags.Arcane, Tags.Sorcery, Tags.Translocation]
		self.can_target_self = False
		self.radius = 3
		self.level = 2

		self.upgrades['violent'] = (1, 6, "Violent Warp", "Cast Magic Missile on teleported enemies", None, [Tags.Arcane])
		self.upgrades['shields'] = (3, 2, "Protective Warp", "Teleported allies gain [{shields} SH:shields]")
		self.upgrades[('void_sickness', 'duration')] = ([1, 10], 2, "Void Sickness", "Teleported enemies receive [{duration}:duration] turns of [silence] and [poison]", [Tags.Dark])
		self.upgrades['far_sending'] = (1, 3, "Far Sending", "Instead of being randomly teleported, targets are sent as far away from the caster as possible")

	def get_description(self):
		return ("Teleport all units in a [{radius}:radius] tile radius to random locations\n"
				"The caster is unaffected")

	def get_impacted_tiles(self, x, y):
		return self.caster.level.get_points_in_ball(x, y, self.get_stat('radius'))

	def cast(self, x, y):
		caster = self.caster
		level = caster.level

		violent = self.get_stat('violent')
		sickness = self.get_stat('void_sickness')
		dur = self.get_stat('duration')
		shields = self.get_stat('shields')
		far = self.get_stat('far_sending')

		for target in level.get_units_in_ball(Point(x, y), self.get_stat('radius')):
			if not target: continue
			if target == self.caster: continue
			level.show_effect(target.x, target.y, Tags.Translocation)
			yield

			if far: target_point = level.get_farthest_stand_tile(target, caster, diag=True)
			else: target_point = level.get_random_stand_tile(target)
			if not target_point: continue

			level.show_beam(target, target_point, Tags.Translocation, minor=True, inclusive=True)
			level.act_move(target, target_point.x, target_point.y, teleport=True)
			yield

			if are_hostile(caster, target):
				if violent:
					magic_missile = caster.get_or_make_spell(MagicMissile)
					level.act_cast(caster, magic_missile, target.x, target.y, pay_costs=False)
					yield

				if sickness:
					target.apply_buff(Silence(), dur)
					target.apply_buff(Poison(), dur)

			elif shields: target.add_shields(shields)



class PetrifySpell(Spell):

	def on_init(self):
		self.tags = [Tags.Arcane, Tags.Enchantment]
		self.level = 2
		self.range = 6
		self.max_charges = 10
		self.name = "Petrify"

		self.duration = 10

		self.upgrades['glassify'] = (1, 2, 'Glassify', 'Target is [glassed] instead of [petrified]')
		self.upgrades['arcane_conductivity'] = (1, 2, "Arcane Conductivity", "Target also loses [100 Arcane:arcane] resist")
		self.upgrades[('petrified_animation', 'minion_damage')] = ([1, 8], 3, "Rocky Servitude", "If the target is slain while [petrified], raise them as a Golem\nGolems inherit the HP of the slain unit")
		self.upgrades['panic'] = (1, 8, "Panic", "Enemies in line of sight of the target are [feared] for [{duration}:duration] turns", None, None, {'duration':2})

		self.add_upgrade_tooltip("Arcane Conductivity", lambda: ResistBuff(Tags.Arcane, res=-100))
		self.add_upgrade_tooltip("Rocky Servitude", self.make_tt_golem)

	def create_golem(self, evt):
		u = evt.unit
		golem = Golem()
		golem.max_hp = u.max_hp
		apply_minion_bonuses(self, golem)
		if u.flying:
			golem.name = "Flying Golem"
			golem.asset_name = "golem_flying"
			golem.flying = True
		self.summon(golem, u)

	def make_tt_golem(self):
		u = Golem()
		apply_minion_bonuses(self, u)
		u.max_hp = 0
		return u

	def get_petrify_buff(self):
		buff = PetrifyBuff() if not self.get_stat('glassify') else GlassPetrifyBuff()
		return buff

	def can_harm(self, target_unit):
		if not are_hostile(self.caster, target_unit): return False
		if self.get_stat('glassify') and Tags.Glass in target_unit.tags: return False
		return target_unit.can_be_stunned()

	def get_ai_target(self):
		return Spell.get_ai_target(self, check_harm=True)

	def cast(self, x, y):

		target = self.caster.level.get_unit_at(x, y)
		if not target: return

		self.caster.level.deal_damage(x, y, 0, Tags.Physical, self)
		buff = self.get_petrify_buff()
		if self.get_stat('petrified_animation'): buff.owner_triggers[EventOnDeath] = self.create_golem
		target.apply_buff(buff, self.get_stat('duration'))
		if self.get_stat('arcane_conductivity'): target.apply_buff(ResistBuff(Tags.Arcane, res=-100), self.get_stat('duration'))
		if self.get_stat('panic'):
			enemies = [u for u in target.level.get_units_in_los(target) if are_hostile(self.caster, u)]
			fear_dur = self.get_stat('duration', base=2)
			for u in enemies: u.apply_buff(FearBuff(), fear_dur)
		yield

	def get_description(self):
		return "[Petrify] the target for [{duration}:duration] turns"

class StoneAuraBuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)

	def on_init(self):
		self.name = "Petrification Aura"
		self.description = "Petrify nearby enemies each turn"
		self.num_targets = self.spell.get_stat('num_targets')
		self.radius = self.spell.get_stat('radius')
		self.duration = self.spell.get_stat('duration')
		self.crumbling_aura = self.spell.get_stat('crumbling_aura')
		self.wormification = self.spell.get_stat('wormification')
		self.glassify = self.spell.get_stat('glassify')
		self.stillness = self.spell.get_stat('stillness')
		self.threshold = self.spell.get_stat('damage')
		self.petrify_buff_class = GlassPetrifyBuff if self.glassify else PetrifyBuff
		if self.wormification: self.global_triggers[EventOnDeath] = self.on_death

	def get_description(self):
		buff_kw = '[glassed]' if self.glassify else "[petrified]"
		combined_kw = '[glassed] or [petrified]' if self.glassify else "[petrified]"
		desc = "Each turn, [{num_targets}:num_targets] enemies within [{radius}:radius] tiles are {buff_kw} for [{duration}:duration] turns"
		if self.stillness: desc += "\n25% chance for the debuff to be permanent"
		if self.crumbling_aura: desc += "\nEach turn, kill {combined_kw} enemies in the aura's radius with [{damage}:damage] or less HP"
		if self.wormification: desc += "\nEnemies slain while {combined_kw} within the aura's radius are raised as Rock Worms"
		return (desc, {'buff_kw':buff_kw, 'num_targets': self.num_targets, 'radius': self.radius, 'damage': self.threshold, 'duration':self.duration, 'combined_kw':combined_kw})

	def on_death(self, evt):
		if distance(evt.unit, self.owner) <= self.radius and (evt.unit.get_buff(PetrifyBuff) or evt.unit.get_buff(GlassPetrifyBuff)):
			self.owner.level.queue_spell(self.summon_worm(evt))

	def summon_worm(self, evt):
		unit = RockWorm()
		unit.max_hp = evt.unit.max_hp
		apply_minion_bonuses(self.spell, unit)
		self.summon(unit, target=evt.unit)
		yield

	def on_advance(self):
		BuffClass = self.petrify_buff_class
		owner = self.owner
		units = [u for u in owner.level.get_units_in_ball(owner, self.radius)]
		random.shuffle(units)
		stoned = 0
		for u in units:
			if not are_hostile(self.owner, u): continue

			if stoned < self.num_targets:
				if self.stillness and random.random() < 0.25: u.apply_buff(BuffClass())
				else: u.apply_buff(BuffClass(), self.duration)
				stoned += 1

			if u.has_buff(BuffClass):
				if self.crumbling_aura and u.cur_hp <= self.threshold: u.kill()
				continue

			if stoned >= self.num_targets: break


class PetrificationAuraSpell(Spell):

	def on_init(self):
		self.range = 0
		self.name = "Petrification Aura"
		self.tags = [Tags.Arcane, Tags.Enchantment]
		self.level = 4
		self.max_charges = 2
		self.num_targets = 3
		self.duration = 6
		self.radius = 5

		self.upgrades[('damage', 'crumbling_aura')] = ([16, 1], 3, "Crumbling Aura", "Each turn, [petrified] enemies within the aura that have [{damage}:damage] or less HP are killed")
		self.upgrades[('wormification', 'minion_damage')] = ([1, 7], 4, "Wormification Aura", "[Petrified] enemies slain within the aura are raised as Rock Worms\nRock Worms inherit the max HP of the slain unit")
		self.upgrades['glassify'] = (1, 5, "Glassify", "Petrification Aura will inflict [glassed] instead of [petrify]\nEffects of this spell which trigger from [petrify] will also trigger from [glassed]")
		self.upgrades['stillness'] = (1, 8, "Perfect Stillness", "There is a 25% chance for the [petrification:petrify] to be permanent")

		self.add_upgrade_tooltip("Wormification Aura", self.make_rockwurm)

	def get_description(self):
		return ("Each turn, [{num_targets}:num_targets] enemies within [{radius}:radius] tiles are [petrified] for [{duration}:duration] turns\n"
				"Lasts [{duration}:duration] turns")

	def make_rockwurm(self):
		u = RockWorm()
		apply_minion_bonuses(self, u)
		u.max_hp = 0
		return u

	def get_stone_aura_buff(self):
		return StoneAuraBuff(self)

	def get_petrify_buff(self):
		return GlassPetrifyBuff() if self.get_stat('glassify') else PetrifyBuff()

	def get_extra_examine_tooltips(self):
		return [self.get_stone_aura_buff()] + self.get_upgrade_tooltips()

	def cast_instant(self, x, y):
		self.caster.apply_buff(self.get_stone_aura_buff(), self.get_stat('duration'))

class SummonWolfSpell(Spell):

	def on_init(self):
		self.tags = [Tags.Nature, Tags.Conjuration]
		self.level = 1
		self.max_charges = 7
		self.name = "Wolf"

		self.minion_health = 15
		self.minion_damage = 4
		self.minion_range = 3

		self.must_target_walkable = True
		self.must_target_empty = True
		self.target_empty = True

		self.upgrades[('pack', 'num_summons')] = ([1, 3], 6, "Wolf Pack", "Summons a pack of [{num_summons}:num_summons] wolves instead of just 1")
		self.upgrades['werewolf'] = (1, 1, "Werewolf", "Summon a Werewolf instead of a Wolf", [Tags.Dark])
		self.upgrades['fleet_footed'] = (1, 2, "Fleet Footed", "Wolves gain [quickstep:translocation]", [Tags.Translocation])
		self.upgrades['ravenous'] = (1, 5, "Ravenous Wolf", "Consumes all remaining charges on cast"
														   "\nThe wolf's health and spells' damage are multiplied by the number of charges consumed"
														   "\nEach time the wolf kills a unit, they grow more powerful", [Tags.Blood])

		self.add_upgrade_tooltip("Werewolf", lambda: self.make_wolf(Werewolf))


	def get_extra_examine_tooltips(self):
		return [self.make_wolf()] + self.get_upgrade_tooltips()

	def make_wolf(self, spawn_fn=Wolf):
		wolf = make_minion(self, spawn_fn)
		if self.get_stat('ravenous'): self.make_ravenous(wolf)
		if self.get_stat('fleet_footed'): wolf.apply_buff(QuickmoveBuff())
		return wolf

	def make_ravenous(self, wolf):
		unit = wolf
		multiplier = self.cur_charges + 1
		unit.max_hp *= multiplier
		for spell in unit.spells:
			spell.damage *= multiplier
		unit.apply_buff(MonsterGrowthBuff(health_growth=self.get_stat('minion_health', base=10), damage_growth=self.get_stat('minion_damage', base=1)))
		return unit

	def cast(self, x, y):
		num_to_summon = 1
		if self.get_stat('pack'):
			num_to_summon = self.get_stat('num_summons')

		for i in range(num_to_summon):
			spawn_fn = Werewolf if self.get_stat('werewolf') else Wolf
			wolf = self.make_wolf(spawn_fn)
			self.summon(wolf, Point(x, y))
			yield

		if self.get_stat('ravenous'):
			self.cur_charges = 0  # uses all charges
			yield

	def get_description(self):
		return ("Summon a Wolf")

class SummonGiantBear(Spell):

	def on_init(self):
		self.max_charges = 3
		self.name = "Giant Bear"
		self.minion_health = 100
		self.minion_damage = 10

		self.tags = [Tags.Nature, Tags.Conjuration]
		self.level = 3

		self.upgrades['armored'] = (1, 3, "Armored Polar Bear", "Summon an Armored Polar Bear instead", [Tags.Ice, Tags.Metallic])
		self.upgrades['venom'] = (1, 4, "Venom Bear", "Summons a Venom Bear instead")
		self.upgrades[('hp_cost', 'blood')] = ([5, 1], 4, "Blood Bear", "Summons a Blood Bear instead", [Tags.Blood])
		self.upgrades[('mauler', 'num_targets')] = ([1, 4], 2, "Mauler", "The bear's melee attack hits [{num_targets}:num_targets] times, instead of twice")

		self.add_upgrade_tooltip("Armored Polar Bear", lambda: self.get_bear(ArmoredPolarBear))
		self.add_upgrade_tooltip("Venom Bear", lambda: self.get_bear(VenomBear))
		self.add_upgrade_tooltip("Blood Bear", lambda: self.get_bear(BloodBear))

		self.must_target_walkable = True
		self.must_target_empty = True

	def get_extra_examine_tooltips(self):
		return [self.get_bear(GiantBear)] + self.get_upgrade_tooltips()

	def get_bear(self, spawn_fn):
		u = make_minion(self, spawn_fn)
		if self.get_stat('mauler'):
			s = u.get_spell(SimpleMeleeAttack)
			s.attacks = self.get_stat('num_targets')
		return u

	def cast(self, x, y):
		spawners = []
		if self.get_stat('venom'): spawners.append(VenomBear)
		if self.get_stat('armored'): spawners.append(ArmoredPolarBear)
		if self.get_stat('blood'): spawners.append(BloodBear)
		if not spawners: spawners = [GiantBear]
		random.shuffle(spawners)
		charges_available = self.cur_charges + 1 # base cost already paid
		spawned = 0
		for spawner in spawners:
			if spawned >= charges_available: break
			unit =  self.summon(self.get_bear(spawner), Point(x, y))
			if unit: spawned += 1
			yield
		if spawned > 1: self.cur_charges -= (spawned - 1)

	def get_description(self):
		return ("Summon a Giant Bear\n"
				"If you have multiple upgrades that would replace your bear, you attempt to expend multiple charges to summon multiple bears instead of one\n"
				"If not enough charges remain, a random valid bear is chosen")

class DarknessBuff(Buff):

	def __init__(self, spell):
		Buff.__init__(self)
		self.spell = spell

	def on_init(self):
		self.name = "Darkness"
		self.color = Tags.Dark.color
		self.description = "Blind all units on the map"
		self.asset = ['status', 'darkness']
		self.darkvision = False
		self.owner_triggers[EventOnUnitAdded] = self.on_unit_added

	def on_unit_added(self, evt):
		self.effect_unit(evt.unit)

	def on_applied(self, evt):
		units = list(self.owner.level.units)
		for unit in units: self.effect_unit(unit)

	def on_advance(self):
		units = list(self.owner.level.units)
		for unit in units:
			if not unit.get_buff(BlindBuff):
				self.effect_unit(unit)

	def on_unapplied(self):
		units = list(self.owner.level.units)
		for unit in units:
			buff = unit.get_buff(BlindBuff)
			if buff: unit.remove_buff(buff)

	def effect_unit(self, unit):
		if self.darkvision and are_friendly(self.owner, unit): return
		unit.apply_buff(BlindBuff())

class Darkness(Spell):

	def on_init(self):
		self.name = "Darkness"
		self.duration = 5
		self.max_charges = 1
		self.level = 3
		self.tags = [Tags.Dark, Tags.Enchantment]
		self.range = 0

		self.upgrades['darkvision'] = (1, 6, "Darkvision", "Only [blinds] enemies")
		self.upgrades[('curse', 'num_targets')] = ([1, 2], 4, "Eyes Of Cursed Dark", "Casting Darkness also casts Shadow Hex on up to [{num_targets}:num_targets] enemies in your line of sight", [Tags.Eye])
		self.upgrades['duration'] = (5, 4, "Long Night")
		self.upgrades['vamp'] = (1, 3, "Nightstalkers", "When you cast this spell, summon either a Wild Man or a Vampire Bat near each enemy", [Tags.Conjuration])

		self.add_upgrade_tooltip("Nightstalkers", lambda: make_minion(self, WildMan), lambda: make_minion(self, Werewolf), lambda: make_minion(self, VampireBat), lambda: make_minion(self, Vampire))

	def cast_instant(self, x, y):
		buff = DarknessBuff(self)
		if self.get_stat('darkvision'): buff.darkvision = True
		self.caster.apply_buff(buff, self.get_stat('duration'))
		if self.get_stat('vamp'):
			candidates = [WildMan, VampireBat]
			for u in self.caster.get_hostiles():
				self.summon(make_minion(self, random.choice(candidates)), u)
		if self.get_stat('curse'):
			targets = [u for u in self.caster.level.get_units_in_los(self.caster) if are_hostile(self.caster, u)]
			if not targets: return
			num = min(len(targets), self.get_stat('num_targets'))
			random.shuffle(targets)
			targets = targets[:num]
			s = self.caster.get_or_make_spell(ShadowHexSpell)
			for t in targets: self.caster.level.act_cast(self.caster, s, t.x, t.y, pay_costs=False)

	def get_description(self):
		return ("Each turn, [blind] all units for 1 turn\n"
				"Lasts [{duration}:duration] turns")

class SpiritHarvestUpgrade(Upgrade):

	def __init__(self, spell):
		self.spell = spell
		Upgrade.__init__(self, spell)

	def on_init(self):
		self.name = "Spirit Harvest"
		self.added_tags = [Tags.Conjuration]
		self.tags = [Tags.Lightning, Tags.Nature, Tags.Enchantment, Tags.Conjuration]
		self.description = ("For every 75 damage dealt by Lightning Storm, summon a Storm Spirit"
							"\nAdds the [Conjuration] tag")
		self.global_triggers[EventOnDamaged] = self.on_damaged
		self.global_triggers[EventOnUnitAdded] = self.on_unit_added

		self.level = 5
		self.minion_health = 36
		self.minion_range = 6
		self.minion_damage = 11
		self.new_attributes = {'minion_health':36, 'minion_range':6, 'minion_damage':11}

		self.dmg_dealt = 0
		self.threshold = 75

	def on_unit_added(self, evt):
		if evt.unit == self.owner:
			self.dmg_dealt = 0

	def on_damaged(self, evt):
		if evt.source == self.spell:
			self.dmg_dealt += evt.damage

		while self.dmg_dealt >= self.threshold:
			self.dmg_dealt -= self.threshold
			self.summon(self.spell.make_spirit(), target=self.spell.caster)

class StormSpell(Spell):

	def on_init(self):
		self.level = 4
		self.max_charges = 3
		self.name = "Lightning Storm"
		self.duration = 10
		self.range = 6
		self.radius = 4
		self.damage = 12
		self.stats.append('strikechance')
		self.strikechance = 50
		self.tags = [Tags.Lightning, Tags.Nature, Tags.Enchantment]

		self.upgrades['strikechance'] = (50, 2, "Surestrike", "Clouds summoned by Lightning Storm deal damage every turn")
		self.upgrades[('radius', 'damage')] = ([1, 12], 3, "Supercell")
		self.upgrades['particle'] = (1, 4, "Particle Storm", "Clouds summoned by Lightning Storm also deal [{damage}:damage] [Arcane] damage every turn", [Tags.Arcane], None, {'damage':3})
		self.add_upgrade(SpiritHarvestUpgrade(self))

		self.add_upgrade_tooltip("Spirit Harvest", self.make_spirit)

	def cast(self, x, y):
		caster = self.caster
		lvl = caster.level
		dmg = self.get_stat('damage')
		dur = self.get_stat('duration')
		strikechance = self.get_stat('strikechance')
		particle = self.get_stat('particle')
		if particle: particle_dmg = self.get_stat('damage', base=3)


		for stage in Burst(lvl, Point(x, y), self.get_stat('radius'), ignore_walls=not self.get_stat('requires_los')):
			for p in stage:
				cloud = StormCloud(caster, dmg)
				cloud.duration = dur
				cloud.strikechance = strikechance
				cloud.source = self
				if particle: cloud.particle_dmg = particle_dmg
				yield lvl.add_obj(cloud, p.x, p.y)

	def make_spirit(self): # for stormspirit upgrade, now gets minion bonuses
		u = StormSpirit()
		apply_minion_bonuses(self, u)
		return u

	def get_impacted_tiles(self, x, y):
		return [p for stage in Burst(self.caster.level, Point(x, y), self.get_stat('radius'), ignore_walls=not self.get_stat('requires_los')) for p in stage]

	def get_description(self):
		return ("Create [Storm Clouds:lightning] over tiles in a [{radius}:radius] tile radius\n"
				"[Storm Clouds:lightning] have a [{strikechance}%:strikechance] chance of dealing [{damage}:damage] [Lightning] damage each turn\n"
				"The clouds last for [{duration}:duration] turns")

class PrisonOfThorns(Spell):

	def on_init(self):
		self.tags = [Tags.Arcane, Tags.Conjuration, Tags.Nature]
		self.level = 4
		self.max_charges = 3
		self.name = "Prison of Thorns"
		self.range = 5

		self.minion_damage = 4
		self.minion_health = 10
		self.minion_duration = 15

		self.upgrades[('grasping_vines', 'minion_range')] = ([1, 2], 3, "Grasping Vines","Fae Thorns gain the [Living] tag and a [{minion_range}:minion_range] range [Physical] attack, which pulls enemies towards it")
		self.upgrades['rot'] = (1, 3, "Rot Growth", "Summon Rot Sprouts instead of Fae Thorns, which can grow into Rot Trees or Rotting Zombies", [Tags.Dark])
		self.upgrades[('icy', 'minion_range')] = ([1, 4], 6, "Icy Prison", "Fae Thorns receive a [{minion_range} range:minion_range] [Ice] attack", [Tags.Ice])
		self.upgrades[('minion_damage', 'minion_health', 'minion_duration')] = ([4, 10, 15], 4, "Super Max")

		self.add_upgrade_tooltip("Rot Growth", lambda: make_minion(self, RotSapling), lambda: make_minion(self, RotTree), lambda: make_minion(self, Zombie))

	def get_description(self):
		return "Summon temporary Fae Thorns surrounding a connected group of enemies"

	def get_extra_examine_tooltips(self):
		return [self.make_thorn()] + self.get_upgrade_tooltips()

	def make_thorn(self):
		unit = make_minion(self, FaeThorn)
		if self.get_stat('rot'):
			unit = make_minion(self, RotSapling)
		if self.get_stat('grasping_vines'):
			pull = PullAttack(damage=self.get_stat('minion_damage'), range=self.get_stat('minion_range', base=2), color=Tags.Nature.color)
			unit.spells.append(pull)
			unit.tags.append(Tags.Living)
		if self.get_stat('icy'):
			unit.tags.append(Tags.Ice)
			unit.resists[Tags.Ice] = 100
			ice_bolt = SimpleRangedAttack(damage=self.get_stat('minion_damage'), range=self.get_stat('minion_range', base=4), damage_type=Tags.Ice)
			unit.spells.append(ice_bolt)
		return unit

	def can_cast(self, x, y):
		u = self.caster.level.get_unit_at(x, y)
		if not u: return False
		if not are_hostile(self.caster, u): return False
		return Spell.can_cast(self, x, y)

	def cast(self, x, y):
		target_points = self.get_impacted_tiles(x, y)
		random.shuffle(target_points)
		for p in target_points:
			unit = self.make_thorn()
			self.summon(unit, p, radius=0)
			yield

	def get_impacted_tiles(self, x, y):

		candidates = set([Point(x, y)])
		unit_group = set()

		while candidates:
			candidate = candidates.pop()
			unit = self.caster.level.get_unit_at(candidate.x, candidate.y)
			if unit and unit not in unit_group and are_hostile(unit, self.caster):
				unit_group.add(unit)

				for q in unit.iter_occupied_points():
					for p in self.caster.level.get_adjacent_points(Point(q.x, q.y), filter_walkable=False):
						if not self.caster.level.get_unit_at(p.x, p.y) == unit:
							candidates.add(p)

		outline = set()
		for unit in unit_group:
			for q in unit.iter_occupied_points():
				for p in self.caster.level.get_adjacent_points(Point(q.x, q.y)):
					if not self.caster.level.get_unit_at(p.x, p.y):
						outline.add(p)

		return list(outline)

class PillarDisruptionDebuff(Buff):

	def on_init(self):
		self.name = "Flammable"
		self.color = Tags.Fire.color
		self.resists[Tags.Fire] = -50
		self.stack_type = STACK_DURATION
		self.buff_type = BUFF_TYPE_CURSE
		self.asset = ['status', 'amplified_fire']

class FlameStrikeSpell(Spell):

	def on_init(self):
		self.max_charges = 2
		self.radius = 1
		self.damage = 50
		self.range = 8
		self.name = "Pillar of Fire"
		self.requires_los = False

		self.tags = [Tags.Fire, Tags.Holy, Tags.Sorcery]
		self.damage_type = [Tags.Fire]
		self.level = 5

		self.upgrades[('channel', 'max_channel')] = ([1, 12], 2, "Channeled Flame", "You may channel Pillar of Fire for up to [{max_channel}:max_channel] turns")
		self.upgrades[('disruption', 'duration')] = ([1, 10], 3, "Disrupting Flames", "Strips target of shields and applies -50 [Fire] resist for [{duration}:duration] turns")
		self.upgrades[('cast_annihilate', 'num_targets')] = ([1, 4], 4, "Pillar of Annihilation", "On kill, cast Annihilate on up to [{num_targets}:num_targets] enemies in line of sight of the killed unit", [Tags.Chaos])
		self.upgrades[('damage', 'range', 'radius')] = ([50, 8, 1], 5, "Orbital Bombardment")

		self.add_upgrade_tooltip("Disrupting Flames", PillarDisruptionDebuff)

	def cast(self, x, y, channel_cast=False):
		if self.get_stat('channel') and not channel_cast and self.is_manual_cast():
			self.caster.apply_buff(ChannelBuff(self.cast, Point(x, y)), self.get_stat('max_channel'))
			return

		caster = self.caster
		level = caster.level
		getu = level.get_unit_at
		deal_damage = level.deal_damage

		damage = self.get_stat('damage')
		center_damage = damage * 2

		disruption = self.get_stat('disruption')
		duration = self.get_stat('duration')

		annihilation = self.get_stat('cast_annihilate')
		killed = set()

		for stage in Burst(level, Point(x, y), self.get_stat('radius'), ignore_walls=not self.get_stat('requires_los')):
			for point in stage:
				unit = getu(point.x, point.y)
				if point.x == x and point.y == y:
					dmg = center_damage
					if unit and disruption:
						unit.shields = 0
						unit.apply_buff(PillarDisruptionDebuff(), duration)
				else: dmg = damage
				deal_damage(point.x, point.y, dmg, Tags.Fire, self)
				if unit and annihilation and not unit.is_alive(): killed.add(point)
				yield

		if annihilation and killed:
			s = caster.get_or_make_spell(AnnihilateSpell)
			num_targets = self.get_stat('num_targets')
			for p in killed:
				possible_targets = [t for t in level.get_units_in_los(p) if are_hostile(caster, t)]
				random.shuffle(possible_targets)
				for t in possible_targets[:num_targets]:
					level.act_cast(caster, s, t.x, t.y, pay_costs=False, origin_point=p)

		return

	def get_impacted_tiles(self, x, y):
			return [p for stage in Burst(self.caster.level, Point(x, y), self.get_stat('radius'), ignore_walls=not self.get_stat('requires_los')) for p in stage]

	def get_description(self):
		return ("Deal [{damage}:damage] [Fire] damage in a [{radius}:radius] tile burst\n"
			    "Deals double damage to the targeted tile")

class BloodlustBuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)
		self.stack_type = STACK_INTENSITY
		self.name = "Blood Lust"
		self.buff_type = BUFF_TYPE_BLESS
		self.asset = ['status', 'bloodlust']
		self.color = Tags.Fire.color

		if spell.get_stat('escalating'): self.global_bonuses['damage'] = spell.get_stat('minion_damage')
		else: self.global_bonuses['damage'] = 6

		self.berserker_rage = spell.get_stat('berserker_rage')
		self.endless_fury = spell.get_stat('endless_fury')

		self.combustion_point = spell.get_stat('combustion_point')
		if self.combustion_point:
			self.combustion_duration = 0 if self.endless_fury else spell.get_stat('duration')
			self.combustion_damage = spell.get_stat('damage')
			self.combustion_radius = spell.get_stat('radius')

		if self.berserker_rage:
			for dtype in damage_tags:
				self.resists[dtype] = 5

	def get_description(self):
		if self.endless_fury: return "Each turn, take [1 Fire:fire] damage"
		else: return self.description

	def on_advance(self):
		if self.endless_fury: self.owner.deal_damage(1, Tags.Fire, self.spell)

	def on_applied(self, owner):
		if self.combustion_point:
			death_buff = DeathExplosion(self.combustion_damage*10, self.combustion_radius, Tags.Fire)
			death_buff.stack_type = STACK_INTENSITY
			owner.apply_buff(death_buff, self.combustion_duration)

			fire_aura = DamageAuraBuff(self.combustion_damage, Tags.Fire, self.combustion_radius)
			fire_aura.stack_type = STACK_INTENSITY
			owner.apply_buff(fire_aura, self.combustion_duration)


class BoilingBlood(Spell):

	def on_init(self):
		self.name = "Boiling Blood"
		self.max_charges = 6
		self.duration = 7
		self.extra_damage = 6
		self.range = 0
		self.hp_cost = 10

		self.tags = [Tags.Nature, Tags.Enchantment, Tags.Blood, Tags.Fire]
		self.level = 2

		self.upgrades[('escalating', 'minion_damage')] = ([1, 8], 5, "Escalating Fury", "Allies' spells gain [{minion_damage}:minion_damage] [damage], instead of a flat 6")
		self.upgrades[('combustion_point', 'damage', 'radius')] = ([1, 3, 2], 3, "Combustion Point", "Affected units receive a damage aura that deals [{damage}:damage] [Fire] damage to enemies within [{radius}:radius] tiles each turn\nAffected units explode on death, dealing [{damage}0:damage] [Fire] damage to units within [{radius}:radius] tiles")
		self.upgrades['endless_fury'] = (1, 5, "Endless Fury", "Boiling Blood becomes permanent, but causes units to take 1 [Fire] damage per turn")
		self.upgrades['berserker_rage'] = (1, 2, "Berserker Rage", "Boiling Blood grants 5% resistance to all damage types")

		self.add_upgrade_tooltip("Combustion Point", self.get_fire_aura)
		self.add_upgrade_tooltip("Combustion Point", self.get_fire_explosion)

	def get_extra_examine_tooltips(self):
		return [self.get_bloodlust_buff()] + self.get_upgrade_tooltips()

	def get_bloodlust_buff(self):
		buff = BloodlustBuff(self)
		return buff

	def get_fire_aura(self):
		fire_aura = DamageAuraBuff(self.get_stat('damage', base=3), Tags.Fire, self.get_stat('radius', base=2))
		fire_aura.stack_type = STACK_INTENSITY
		return fire_aura

	def get_fire_explosion(self):
		explosion = DeathExplosion(self.get_stat('damage', base=3) * 10, self.get_stat('radius', base=2), Tags.Fire)
		explosion.stack_type = STACK_INTENSITY
		return explosion

	def get_description(self):
		desc = []
		if self.get_stat('escalating'): desc.append("Allies' spells gain [{minion_damage}:minion_damage] [damage]")
		else: desc.append("Allies' spells gain 6 [damage]")
		if self.get_stat('endless_fury'): desc.append("\nPermanent duration")
		else: desc.append("\nLasts [{duration}:duration] turns")
		return desc

	# for usage by bloodshift
	def do_buff(self, unit):
		dur = 0 if self.get_stat('endless_fury') else self.get_stat('duration')
		buff = BloodlustBuff(self)
		unit.apply_buff(buff, dur)
		unit.level.show_effect(unit.x, unit.y, Tags.Fire)
		yield

	def cast(self, x, y):
		dur = 0 if self.get_stat('endless_fury') else self.get_stat('duration')
		for unit in self.caster.get_allies():
			buff = self.get_bloodlust_buff()
			unit.apply_buff(buff, dur)
			unit.level.show_effect(unit.x, unit.y, Tags.Fire)
			yield

class HealingLight(Spell):

	def on_init(self):
		self.tags = [Tags.Holy, Tags.Sorcery]
		self.level = 2
		self.name = "Healing Light"
		self.heal = 50

		self.max_charges = 25
		self.range = 0

		self.upgrades['shields'] = (3, 3, "Shielding Light", "Allies in line of sight gain [{shields} SH:shields]")
		self.upgrades['remove_debuffs'] = (1, 2, "Purifying Light", "Allies in line of sight lose all debuffs before being healed")
		self.upgrades['heart_flame'] = (1, 4, "Heartflame", "When Healing Light heals an ally, the nearest enemy in their line of sight takes that much [Fire] and [Holy] damage", [Tags.Fire], [Tags.Fire, Tags.Holy])
		self.upgrades[('ritual', 'max_channel')] = ([1, 6], 4, "Ritual of Rejuvenation", "You may channel Healing Light for [{max_channel}:max_channel] turns\nIf you complete the ritual, apply a buff that regenerates [5 HP:heal] per turn for the remainder of the level to allies in line of sight", [Tags.Ritual])
		self.add_upgrade_tooltip("Ritual of Rejuvenation", self.get_rejuvenation_buff)

	def get_description(self):
		return "Heal allies in line of sight for [{heal} HP:heal]"

	def get_rejuvenation_buff(self):
		buff = RegenBuff(5)
		buff.name = "Rejuvenation"
		buff.color = Tags.Holy.color
		return buff

	def get_impacted_tiles(self, x, y):
		return [u for u in self.caster.level.get_units_in_los(self.caster) if u != self.caster and self.caster.team==u.team]

	def cast(self, x, y, channel_cast=False):
		caster = self.caster
		level = caster.level

		remove_debuffs = self.get_stat('remove_debuffs')
		heal_amt = self.get_stat('heal')
		shields = self.get_stat('shields')
		heart_flame = self.get_stat('heart_flame')
		ritual = self.get_stat('ritual')
		has_channel = caster.has_buff(ChannelBuff)

		if ritual and not channel_cast and self.is_manual_cast():
			caster.apply_buff(ChannelBuff(self.cast, Point(x, y)), self.get_stat('max_channel'))
			return

		for unit in level.get_units_in_los(caster):
			if caster.team==unit.team and unit != caster: # wasn't healing berserked allies, but it should since berserk is a debuff
				level.show_beam(caster, unit, Tags.Holy)
				if remove_debuffs: # remove debuffs first to get rid of poison so heal can work.
					debuffs = [b for b in unit.buffs if b.buff_type == BUFF_TYPE_CURSE]
					for debuff in debuffs: unit.remove_buff(debuff)

				health_dealt = 0
				if unit.cur_hp < unit.max_hp: health_dealt -= unit.deal_damage(-heal_amt, Tags.Heal, self)
				if shields: unit.add_shields(shields)

				if heart_flame and health_dealt > 0:
					possible_targets = level.get_units_by_distance(unit, enemy=True, require_los=True)
					if not possible_targets: continue
					target = possible_targets[0]
					level.show_path_effect(unit, target, [Tags.Holy, Tags.Fire])
					level.deal_damage(target.x, target.y, health_dealt, Tags.Fire, self)
					level.deal_damage(target.x, target.y, health_dealt, Tags.Holy, self)

				if ritual and channel_cast and not has_channel:
					unit.apply_buff(self.get_rejuvenation_buff()) # final turn

				yield
		yield

class RegenerativeGoop(Upgrade):

	def __init__(self, spell):
		self.spell = spell
		Upgrade.__init__(self, spell)

	def on_init(self):
		self.added_tags = [Tags.Slime]
		self.tags = [Tags.Nature, Tags.Enchantment, Tags.Slime]
		self.level = 2
		self.name = "Regenerative Goop"
		self.description = "[Slime] allies heal adjacent allies when healed by the aura\nAdds the [Slime] tag"
		self.global_triggers[EventOnHealed] = self.on_healed

	def on_healed(self, evt):
		if are_hostile(evt.unit, self.owner): # ignore healing of enemies
			return
		if not evt.source: # sourceless ignore
			return
		if not evt.source.owner: # ownerless ignore
			return
		if not isinstance(evt.source, HealAuraBuff): #didn't come from heal aura, ignore
			return
		if not evt.source.owner == self.owner: # didn't come from the wizards, heal aura, ignore
			return
		if not Tags.Slime in evt.unit.tags: # not a slime, ignore
			return
		heal_targets = [u for u in self.owner.level.get_adjacent_units(evt.unit) if not are_hostile(evt.unit, u)] # get a list of adj allied
		for u in heal_targets: # heal each one
			u.heal(self.spell.heal, self.spell)

class RegenAuraSpell(Spell):

	def on_init(self):
		self.name = "Regeneration Aura"
		self.heal = 4
		self.duration = 8
		self.range = 0
		self.radius = 8

		self.max_charges = 2
		self.level = 2

		self.tags = [Tags.Enchantment, Tags.Nature]
		self.whole_map = 0

		self.upgrades['whole_map'] = (1, 4, "Global", "The aura heals all allies on the level")
		self.upgrades['death_defiance'] = (1, 6, "Death Defiance", "When you cast this spell, allies in the affected radius gain the ability to reincarnate on death", [Tags.Holy])
		self.upgrades['self_heal'] = (1, 2, "Self Healing", "You are also healed by the aura")
		self.add_upgrade(RegenerativeGoop(self))

	def get_description(self):
		return ("Each turn, heal allies within [{radius}:radius] tiles for [{heal} HP:heal]\n"
				"Lasts [{duration}:duration] turns")

	def get_heal_aura_buff(self):
		heal_caster = True if self.get_stat('self_heal') else False
		return HealAuraBuff(self.get_stat('heal'), self.get_stat('radius'), whole_map=self.get_stat('whole_map'), heal_self=heal_caster)

	def get_extra_examine_tooltips(self):
		return [self.get_heal_aura_buff()] + self.get_upgrade_tooltips()

	def cast_instant(self, x, y):
		self.caster.apply_buff(self.get_heal_aura_buff(), self.get_stat('duration'))
		if self.get_stat('death_defiance'):
			allies = [u for u in self.caster.level.get_units_in_ball(self.caster, self.get_stat('radius')) if not are_hostile(self.caster, u) and not u==self.caster and not u.is_player_controlled]
			for u in allies:
				if u.has_buff(ReincarnationBuff): u.get_buff(ReincarnationBuff).lives += 1
				else: u.apply_buff(ReincarnationBuff())
				self.caster.level.show_effect(u.x, u.y, Tags.Buff_Apply, Tags.Holy.color)

class Dominate(Spell):

	def on_init(self):
		self.name = "Dominate"
		self.range = 4
		self.max_charges = 4

		self.tags = [Tags.Arcane, Tags.Enchantment]
		self.level = 3

		self.damage = 40
		self.check_cur_hp = 0

		self.upgrades['damage'] = (60, 4, 'Conqueror', 'Increase the maximum HP threshold of units which can be Dominated')
		self.upgrades['check_cur_hp'] = (1, 3, 'Brute Force', 'Dominate units based on their current HP instead of max HP')
		self.upgrades['cult_leader'] = (1, 7, "Cult Leader", "Dominated units can cast your Dominate on a 30 turn cooldown")
		self.upgrades['death_lord'] = (1, 8, "Death Lord", "You may Dominate [Undead] units regardless of their HP", [Tags.Dark])

	def can_cast(self, x, y):
		if not Spell.can_cast(self, x, y): return False
		unit = self.caster.level.get_unit_at(x, y)
		if unit is None: return False
		return self.is_good_target(unit)

	def can_harm(self, target_unit):
		return self.is_good_target(target_unit)

	def is_good_target(self, unit):
		if not are_hostile(self.caster, unit): return False
		if unit.team == self.caster.team: return False
		if self.get_stat('death_lord') and Tags.Undead in unit.tags: return True
		hp = unit.cur_hp if self.get_stat('check_cur_hp') else unit.max_hp
		return hp <= self.get_stat('damage')

	def cast(self, x, y):
		unit = self.caster.level.get_unit_at(x, y)
		if not unit: return # abort if the unit has died somehow from effects that went off before arriving at cast method.
		if self.get_stat('cult_leader'):
			wizard = self.statholder if self.statholder else self.caster
			unit.wizard = wizard  # store wizard ref on the unit so when they pass the spell off in chains, they can refer to the wizard quickly
			grant_minion_spell(Dominate, unit, wizard, 30, pre_insert=True)
		unit.team = self.caster.team
		yield

	def get_description(self):
		return ("Target enemy with no more than [{damage}:damage] max HP becomes your minion")

class ElementalEyeBuff(Buff):

	def __init__(self, element, damage, freq, spell):
		Buff.__init__(self)
		self.spell = spell
		self.element = element
		self.damage = damage
		self.freq = max(1, freq)
		self.cooldown = self.freq
		self.color = element.color
		self.buff_type = BUFF_TYPE_BLESS
		self.stack_type = STACK_REPLACE
		self.ionized = self.spell.get_stat('ionized')
		self.beam = self.spell.get_stat('beam')
		self.bonus_cast = self.spell.get_stat('bonus_cast')
		self.cascade = self.spell.get_stat('cascade')
		if self.bonus_cast: self.bonus_spell_name = self.spell.bonus_spell().name

		freq_str = "each turn" if self.freq == 1 else ("every %d turns" % self.freq)
		self.description = "Deals %d %s damage to a random enemy in your line of sight %s" % (self.damage, self.element.name, freq_str)

	def get_description(self):
		if self.freq <= 1:
			desc = "Each turn, deal [{damage}:damage] {tag} damage to a random enemy in your line of sight"
			fmt = {"damage": self.damage, "tag": formatted_tag(self.element), "cooldown": self.cooldown}
		else:
			desc = "Every [{freq}:cooldown] turns, deal [{damage}:damage] {tag} damage to a random enemy in your line of sight"
			fmt = {"freq": self.freq, "damage": self.damage, "tag": formatted_tag(self.element), "cooldown": self.cooldown}
		if self.beam:
			desc += "\nShots deal damage in a beam to the target"
			desc += "\nAllies in the beam's path heal for [{damage}:damage] HP and gain [1 SH:shields]"
		if self.bonus_cast: desc += "\nCast %s on shot targets" % self.bonus_spell_name
		if self.cascade: desc += "\nIf the shot kills an enemy, shoot again"
		if self.ionized: desc += "\nPrefers enemies with the lowest [Lightning] resistance"
		return (desc + "\nShot cooldown: [{cooldown}:cooldown] turns", fmt)

	def on_advance(self):

		self.cooldown -= 1
		if self.cooldown <= 0:
			self.cooldown = self.freq
			possible_targets = self.owner.level.units
			possible_targets = [t for t in possible_targets if self.owner.level.are_hostile(t, self.owner)]
			possible_targets = [t for t in possible_targets if self.owner.level.can_see(t.x, t.y, self.owner.x, self.owner.y)]

			if possible_targets:
				target = random.choice(possible_targets)
				if self.ionized:
					min_res = min(u.resists[Tags.Lightning] for u in possible_targets)
					candidates = [u for u in possible_targets if u.resists[Tags.Lightning] == min_res]
					target = random.choice(candidates)
				self.owner.level.queue_spell(self.shoot(Point(target.x, target.y)))
				self.cooldown = self.freq

	def shoot(self, target):
		self.owner.level.show_effect(0, 0, Tags.Sound_Effect, 'sorcery')
		path = self.owner.level.get_points_in_line(Point(self.owner.x, self.owner.y), target, find_clear=True)

		if self.beam:  # for archon eye
			dmg = self.damage
			for point in path[1:-1]:  # skip owner and final target, putting here so it happens during shot, after doesn't make sense.
				u = self.owner.level.get_unit_at(point.x, point.y)
				if u:
					if are_hostile(u, self.owner):
						u.deal_damage(dmg, self.element, self.spell)
					else:
						u.heal(dmg, self.spell)
						u.add_shields(1)
				else:
					self.owner.level.show_effect(point.x, point.y, self.element)
		else:
			for point in path: self.owner.level.show_effect(point.x, point.y, self.element)

		unit = self.owner.level.get_unit_at(target.x, target.y)

		if self.bonus_cast:
			bonus_spell = self.owner.get_or_make_spell(self.spell.bonus_spell)
			for _ in self.owner.level.act_cast(self.owner, bonus_spell, target.x, target.y, pay_costs=False, queue=False):
				pass

		self.owner.level.deal_damage(target.x, target.y, self.damage, self.element, self.spell)

		if unit and self.cascade and not unit.is_alive():
				possible_targets = self.owner.level.units
				possible_targets = [t for t in possible_targets if self.owner.level.are_hostile(t, self.owner)]
				possible_targets = [t for t in possible_targets if self.owner.level.can_see(t.x, t.y, self.owner.x, self.owner.y)]

				if possible_targets:
					target = random.choice(possible_targets)
					self.owner.level.queue_spell(self.shoot(target))

		self.on_shoot(target)
		yield

	def on_shoot(self, target):
		pass

class RageEyeBuff(ElementalEyeBuff):

	def __init__(self, freq, berserk_duration, spell):
		ElementalEyeBuff.__init__(self, Tags.Physical, 0, freq, spell)
		self.berserk_duration = berserk_duration
		self.name = "Eye of Rage"
		self.color = Tags.Nature.color
		self.asset = ['status', 'rage_eye']
		self.connected_group = self.spell.get_stat('connected_group')
		self.lycanthrophy = self.spell.get_stat('lycanthrophy')
		self.fiery_aura = self.spell.get_stat('fiery_aura')
		self.fiery_aura_radius = self.spell.get_stat('radius', base=2)

	def get_description(self):
		if self.freq <= 1:
			desc = "Each turn, inflict [berserk] on a random enemy in your line of sight for [{duration}:duration] turns"
			if self.connected_group: desc = "Each turn, inflict [berserk] on the connected group containing a random enemy in your line of sight for [{duration}:duration] turns"
			fmt = {"duration": self.berserk_duration, "cooldown": self.cooldown}
		else:
			desc = "Every [{freq}:cooldown] turns, inflict [berserk] on a random enemy in your line of sight for [{duration}:duration] turns"
			if self.connected_group: desc = "Every [{freq}:cooldown] turns, inflict [berserk] on the connected group containing a random enemy in your line of sight for [{duration}:duration] turns"
			fmt = {"freq": self.freq, "duration": self.berserk_duration, "cooldown": self.cooldown}
		if self.lycanthrophy: desc += "\n[Living] targets with 25% or less HP are killed and raised as friendly Werewolves"
		if self.fiery_aura: desc += "\nTargeted units gain Burning Rage for [{duration}:duration] turns"
		return (desc + "\nShot cooldown: [{cooldown}:cooldown] turns", fmt)

	def on_shoot(self, target):
		units = [self.owner.level.get_unit_at(target.x, target.y)]
		if self.connected_group:
			units = self.owner.level.get_connected_group_from_point(target.x, target.y, check_hostile=self.owner)
		for unit in units:
			if unit:
				if self.lycanthrophy and Tags.Living in unit.tags and unit.cur_hp <= (unit.max_hp // 4):
					unit.kill()
					u = self.spell.make_werewolf()
					u.max_hp = unit.max_hp
					self.spell.summon(u, target=unit)
					u.apply_buff(BerserkBuff(), 4)

				else:
					unit.apply_buff(BerserkBuff(), self.berserk_duration)
					if self.fiery_aura:
						fiery_aura_buff = DamageAuraBuff(2, Tags.Fire, self.fiery_aura_radius, friendly_fire=True)
						fiery_aura_buff.name = "Burning Rage"
						unit.apply_buff(fiery_aura_buff, self.berserk_duration)


class PenetratingGazeBuff(Buff):

	def on_init(self):
		self.name = "Electrified"
		self.color = Tags.Lightning.color
		self.resists[Tags.Lightning] = -50
		self.stack_type = STACK_REPLACE
		self.asset = ['status', 'amplified_lightning']

# Split these into 2 classes so they stack properly
class LightningEyeBuff(ElementalEyeBuff):

	def __init__(self, damage, freq, spell):
		ElementalEyeBuff.__init__(self, Tags.Lightning, damage, freq, spell)
		self.name = "Eye of Lightning"
		self.color = Tags.Lightning.color
		self.asset = ['status', 'lightning_eye']
		self.applies_buff = self.spell.get_stat('applies_buff')

	def get_description(self):
		desc = [ElementalEyeBuff.get_description(self)]
		if self.applies_buff: desc.append("\nShots reduce the target's [Lightning] resistance by [50% Lightning:lightning]")
		return desc

	def on_shoot(self, target):
		if self.applies_buff:
			unit = self.owner.level.get_unit_at(target.x, target.y)
			if unit: unit.apply_buff(PenetratingGazeBuff())

class PrometheanBuff(Buff):

	def __init__(self, res):
		Buff.__init__(self)
		self.name = "Promethean Blessing"
		self.buff_type = BUFF_TYPE_BLESS
		self.stack_type = STACK_NONE
		self.color = Tags.Fire.color
		self.resists[Tags.Fire] = res

	def on_applied(self, owner):
		if Tags.Fire not in self.owner.tags:
			self.nonmetal = True
			self.owner.tags.append(Tags.Fire)
		else: self.nonmetal = False

	def on_unapplied(self):
		if Tags.Fire in self.owner.tags and self.nonmetal: self.owner.tags.remove(Tags.Fire)

class FireEyeBuff(ElementalEyeBuff):

	def __init__(self, damage, freq, spell):
		ElementalEyeBuff.__init__(self, Tags.Fire, damage, freq, spell)
		self.name = "Eye of Fire"
		self.color = Tags.Fire.color
		self.asset = ['status', 'fire_eye']
		self.promethean = self.spell.get_stat('promethean')
		self.summon_eyeball = self.spell.get_stat('summon_eyeball')

	def get_description(self):
		desc = [ElementalEyeBuff.get_description(self)]
		if self.promethean:
			desc.append("\nIf this shoots a [Fire] unit, remove its [Fire] tag and positive [Fire] resistance")
			desc.append("\nGrant that [Fire] tag and resistance to an ally without the [Fire] tag")
		if self.summon_eyeball: desc.append("\nWhen this buff ends, summon a Flaming Eyeball")
		return desc

	def on_shoot(self, target):
		unit = self.owner.level.get_unit_at(target.x, target.y)
		if unit and self.promethean and Tags.Fire in unit.tags:
			unit.tags.remove(Tags.Fire)
			res = unit.resists[Tags.Fire]
			if res > 0: unit.resists[Tags.Fire] = 0

			elligible_allies = [u for u in self.owner.level.units if not are_hostile(self.owner, u) and Tags.Fire not in u.tags and not u==self.owner]
			if elligible_allies:
				ally = random.choice(elligible_allies)
				ally.apply_buff(PrometheanBuff(res))

	def on_unapplied(self):
		for i in range(self.summon_eyeball):
			unit = self.spell.make_flaming_eye()
			self.spell.summon(unit, self.owner)

class IceEyeBuff(ElementalEyeBuff):

	def __init__(self, damage, freq, spell):
		ElementalEyeBuff.__init__(self, Tags.Ice, damage, freq, spell)
		self.name = "Eye of Ice"
		self.color = Tags.Ice.color
		self.asset = ['status', 'ice_eye']
		self.freezing = self.spell.get_stat('freezing')
		self.freeze_duration = self.spell.get_stat('duration', base=2)
		self.summon_eyeball = self.spell.get_stat('summon_eyeball')

	def get_description(self):
		desc = [ElementalEyeBuff.get_description(self)]
		if self.freezing: desc.append(("\nShots [freeze] the target for [{duration}:duration] turns", {'duration': self.freeze_duration}))
		if self.summon_eyeball: desc.append("\nWhen this buff ends, summon a Frosty Eyeball")
		return desc

	def on_shoot(self, target):
		unit = self.owner.level.get_unit_at(target.x, target.y)
		if unit and self.freezing:
			unit.apply_buff(FrozenBuff(), self.freeze_duration)

	def on_unapplied(self):
		for i in range(self.summon_eyeball):
			unit = self.spell.make_frost_eye()
			self.spell.summon(unit, self.owner)

class BloodEyeBuff(ElementalEyeBuff):

	def __init__(self, damage, freq, spell):
		ElementalEyeBuff.__init__(self, Tags.Dark, damage, freq, spell)
		self.name = "Eye of Blood"
		self.color = Tags.Blood.color
		self.global_triggers[EventOnDamaged] = self.on_damaged
		self.hags_eye = self.spell.get_stat('hags_eye')
		self.plasmoid = self.spell.get_stat('plasmoid')

	def get_description(self):
		if self.freq == 1:
			desc = "Each turn, deal [{damage}:damage] [Dark] damage to a random enemy in your line of sight"
			if self.hags_eye: desc = "Each turn, deal [{damage}:damage] [Dark] damage to enemies in your line of sight"
			fmt = {"damage": self.damage, "cooldown": self.cooldown}
		else:
			desc = "Every [{freq}:cooldown] turns, deal [{damage}:damage] [Dark] damage to a random enemy in your line of sight"
			if self.hags_eye: desc = "Every [{freq}:cooldown] turns, deal [{damage}:damage] [Dark] damage to enemies in your line of sight"
			fmt = {"freq": self.freq, "damage": self.damage, "cooldown": self.cooldown}
		if self.bonus_cast: desc += "\nCast %s on shot targets" % self.bonus_spell_name
		if self.plasmoid: desc += "\nWhen this deals damage, reduce the target's max HP by the damage dealt and summon a Blood Slime nearby"
		return (desc + "\nHeal for damage dealt\nShot cooldown: [{cooldown}:cooldown] turns", fmt)

	def on_advance(self):
		self.cooldown -= 1
		if self.cooldown <= 0:
			self.cooldown = self.freq
			targets = [t for t in self.owner.level.get_units_in_los(self.owner) if are_hostile(self.owner, t)]
			if targets:
				if self.hags_eye:
					for target in targets:
						self.owner.level.queue_spell(self.shoot(Point(target.x, target.y)))

				else:
					target = random.choice(targets)
					self.owner.level.queue_spell(self.shoot(Point(target.x, target.y)))
				self.cooldown = self.freq

	def on_damaged(self, evt):
		if not evt.source:
			return
		if evt.source == self.spell:
			if self.plasmoid and evt.unit:
				if evt.unit.is_alive():
					drain_max_hp(evt.unit, evt.damage)
				self.spell.summon(self.spell.make_slime(), target=evt.unit)
			self.owner.heal(evt.damage, self.spell)

class BloodAccelerant(Upgrade):

	def on_init(self):
		self.name = "Blood Accelerant"
		self.level = 3
		self.description = "Reduce the active shot cooldown of your Eye of Blood buff by 1 each time you cast a [Blood] spell"
		self.owner_triggers[EventOnSpellCast] = self.on_cast

	def on_cast(self, evt):
		if Tags.Blood not in evt.spell.tags: return
		buff = self.owner.get_buff(BloodEyeBuff)
		if not buff: return
		buff.cooldown -= 1

class EyeOfBloodSpell(Spell):

	def on_init(self):
		self.tags = [Tags.Blood, Tags.Enchantment, Tags.Eye]
		self.level = 2
		self.range = 0
		self.max_charges = 2
		self.name = "Eye of Blood"
		self.damage = 10
		self.damage_type = [Tags.Dark]
		self.duration = 20
		self.shot_cooldown = 3
		self.hp_cost = 10

		self.bonus_spell = LifedrainSpell
		self.stats.append('shot_cooldown')

		self.upgrades['bonus_cast'] = (1, 4, "Eye of Lifedrain", "Eye of Blood also casts Lifedrain on units it shoots")
		self.upgrades[('hags_eye', 'shot_cooldown')] = ([1, 3], 7, "Hag's Eye", "Shoots at all targets in line of sight")
		self.upgrades['plasmoid'] = (1, 3, "Eye of Plasmoid", "When it deals damage, the target's max HP is reduced by the damage dealt and a Blood Slime is summoned nearby", [Tags.Slime])
		self.add_upgrade(BloodAccelerant())

		self.add_upgrade_tooltip("Eye of Plasmoid", self.make_slime)

	def get_eye_buff(self):
		buff = BloodEyeBuff(self.get_stat('damage'), self.get_stat('shot_cooldown'), self)
		buff.element = self.damage_type[0]
		return buff

	def cast_instant(self, x, y):
		buff = self.get_eye_buff()
		self.caster.apply_buff(buff, self.get_stat('duration'))

	def get_description(self):
		return ("Every [{shot_cooldown}:shot_cooldown] turns, deal [{damage}:damage] [Dark] damage to a random enemy in line of sight\n"
				"Heal for damage dealt\n"
				"Lasts [{duration}:duration] turns")

	def make_slime(self):
		u = BloodSlime()
		apply_minion_bonuses(self, u)
		u.buffs[0].spawner = lambda: self.make_slime()
		return u

	def get_extra_examine_tooltips(self):
		return [self.get_eye_buff()] + self.get_upgrade_tooltips()

class EyeOfFireSpell(Spell):

	def on_init(self):
		self.tags = [Tags.Fire, Tags.Enchantment, Tags.Eye]
		self.level = 2
		self.range = 0
		self.max_charges = 4
		self.name = "Eye of Fire"
		self.damage = 15
		self.damage_type = [Tags.Fire]
		self.duration = 30
		self.shot_cooldown = 3

		self.bonus_spell = ImmolateSpell

		self.stats.append('shot_cooldown')

		self.upgrades['bonus_cast'] = (1, 5, "Eye of Immolation", "Eye of Fire also casts Immolate on units it shoots")
		self.upgrades['summon_eyeball'] = (1, 2, "Fiery Onlooker", "Summon a Flaming Eyeball when Eye of Fire is removed", [Tags.Conjuration])
		self.upgrades['cascade'] = (1, 2, "Eye of Conflagration", "When Eye of Fire kills an enemy, it shoots again")
		self.upgrades['promethean'] = (1, 4, "Promethean Eye", "If Eye of Fire targets a [Fire] unit, it removes the [Fire] tag and their [Fire] resistance\nThe [Fire] tag and resistance are then granted to an ally without the [Fire] tag")

		self.add_upgrade_tooltip("Fiery Onlooker", self.make_flaming_eye)

	def get_eye_buff(self):
		buff = FireEyeBuff(self.get_stat('damage'), self.get_stat('shot_cooldown'), self)
		buff.element = self.damage_type[0]
		return buff

	def cast_instant(self, x, y):
		buff = self.get_eye_buff()
		self.caster.apply_buff(buff, self.get_stat('duration'))

	def make_flaming_eye(self):
		unit = FlamingEye()
		apply_minion_bonuses(self, unit)
		return unit

	def get_description(self):
		return ("Every [{shot_cooldown}:shot_cooldown] turns, deal [{damage}:damage] [Fire] damage to a random enemy in line of sight\n"
				"Lasts [{duration}:duration] turns")

	def get_extra_examine_tooltips(self):
		return [self.get_eye_buff()] + self.get_upgrade_tooltips()

class EyeOfLightningSpell(Spell):

	def on_init(self):
		self.tags = [Tags.Lightning, Tags.Enchantment, Tags.Eye]
		self.damage_type = [Tags.Lightning]
		self.level = 2
		self.range = 0
		self.max_charges = 4
		self.name = "Eye of Lightning"
		self.damage = 15
		self.duration = 30
		self.shot_cooldown = 3

		self.stats.append('shot_cooldown')

		self.bonus_spell = ThunderStrike

		self.upgrades['beam'] = (1, 3, "Archon Eye", "Eye of Lightning deals damage to enemies in a beam instead of only at the target\nAllies along the beam are healed for [{damage}:damage] and gain [1 Shield:shields]", [Tags.Holy], None, {'damage':15})
		self.upgrades['bonus_cast'] = (1, 4, "Eye of Thunder", "Eye of Lightning also casts Thunder Strike on units it shoots")
		self.upgrades['applies_buff'] = (1, 2, "Penetrating Gaze", "Eye of Lightning shots reduce the target's [Lightning] resistance by 50%")
		self.upgrades['ionized'] = (1, 1, "Ionized Sight", "Eye of Lightning will prefer to shoot targets with the lower [Lightning] resistance")

		self.add_upgrade_tooltip("Penetrating Gaze", PenetratingGazeBuff)

	def get_eye_buff(self):
		buff = LightningEyeBuff(self.get_stat('damage'), self.get_stat('shot_cooldown'), self)
		buff.element = self.damage_type[0]
		return buff

	def cast_instant(self, x, y):
		buff = self.get_eye_buff()
		self.caster.apply_buff(buff, self.get_stat('duration'))

	def get_description(self):
		return ("Every [{shot_cooldown}:shot_cooldown] turns, deal [{damage}:damage] [Lightning] damage to a random enemy in line of sight\n"
				"Lasts [{duration}:duration] turns")

	def get_extra_examine_tooltips(self):
		return [self.get_eye_buff()] + self.get_upgrade_tooltips()

class EyeOfIceSpell(Spell):

	def on_init(self):
		self.range = 0
		self.max_charges = 4
		self.name = "Eye of Ice"
		self.damage = 15
		self.damage_type = [Tags.Ice]
		self.duration = 30
		self.shot_cooldown = 3

		self.bonus_spell = Icicle

		self.stats.append('shot_cooldown')

		self.upgrades['freezing'] = (1, 1, "Freezing", "Eye of Ice [freezes] the target for [{duration}:duration] turns", None, None, {'duration':2})
		self.upgrades['summon_eyeball'] = (1, 2, "Frosty Onlooker", "Summon a Frosty Eyeball when Eye of Ice is removed", [Tags.Conjuration])
		self.upgrades['array'] = (1, 4, "Icy Array", "You can have multiple instances of Eye of Ice active simultaneously")
		self.upgrades['bonus_cast'] = (1, 6, "Eye of Icicles", "Eye of Ice also casts Icicle on units it shoots")
		self.add_upgrade_tooltip("Frosty Onlooker", self.make_frost_eye)

		self.tags = [Tags.Ice, Tags.Enchantment, Tags.Eye]
		self.level = 2

	def get_eye_buff(self):
		buff = IceEyeBuff(self.get_stat('damage'), self.get_stat('shot_cooldown'), self)
		buff.element = self.damage_type[0]
		if self.get_stat('array'): buff.stack_type = STACK_INTENSITY
		return buff

	def cast_instant(self, x, y):
		buff = self.get_eye_buff()
		self.caster.apply_buff(buff, self.get_stat('duration'))

	def make_frost_eye(self):
		unit = FrostEye()
		apply_minion_bonuses(self, unit)
		return unit

	def get_description(self):
		return ("Every [{shot_cooldown}:shot_cooldown] turns, deal [{damage}:damage] [Ice] damage to a random enemy in line of sight\n"
				"Lasts [{duration}:duration] turns")

	def get_extra_examine_tooltips(self):
		return [self.get_eye_buff()] + self.get_upgrade_tooltips()

class EyeOfRageSpell(Spell):

	def on_init(self):
		self.range = 0
		self.max_charges = 4
		self.name = "Eye of Rage"
		self.duration = 20
		self.shot_cooldown = 3
		self.stats.append('shot_cooldown')

		self.berserk_duration = 2
		self.stats.append('berserk_duration')

		self.upgrades[('lycanthrophy', 'minion_damage', 'minion_range')] = ([1, 6, 3], 2, "Lycanthropy", "When Eye of Rage shoots a [Living] unit with 25% or less HP, that unit is killed and raised as a friendly Werewolf\nThe Werewolf inherits the max HP of the slain unit and is [berserked] for 4 turns")
		self.upgrades['connected_group'] = (1, 5, "Infectious Rage", "Eye of Rage shots affect enemies in a connected group")
		self.upgrades[('fiery_aura', 'damage', 'radius')] = ([1, 2, 2], 2, "Burning Rage", "Targeted units gain a fiery aura that deals [{damage}:damage] [Fire] damage to units within [{radius}:radius] tiles", [Tags.Fire])
		self.upgrades['berserk_duration'] = (10, 3, "Enduring Rage")

		self.add_upgrade_tooltip("Burning Rage", self.get_burning_rage_buff)
		self.add_upgrade_tooltip("Lycanthropy", self.make_werewolf)

		self.tags = [Tags.Nature, Tags.Enchantment, Tags.Eye]
		self.level = 2

	def get_eye_buff(self):
		buff = RageEyeBuff(self.get_stat('shot_cooldown'), self.get_stat('berserk_duration'), self)
		return buff

	def cast_instant(self, x, y):
		buff = self.get_eye_buff()
		self.caster.apply_buff(buff, self.get_stat('duration'))

	def get_burning_rage_buff(self):
		return DamageAuraBuff(self.get_stat('damage', base=2), Tags.Fire, self.get_stat('radius', base=2), custom_name="Burning Rage", friendly_fire=True)

	def make_werewolf(self):
		u = Werewolf()
		apply_minion_bonuses(self, u)
		u.max_hp = 0
		return u

	def get_description(self):
		return ("Every [{shot_cooldown}:shot_cooldown] turns, inflict [berserk] on a random enemy in line of sight for [{berserk_duration}:duration] turns\n"
				"Lasts [{duration}:duration] turns")

	def get_extra_examine_tooltips(self):
		return [self.get_eye_buff()] + self.get_upgrade_tooltips()

class NightmareBuff(DamageAuraBuff):

	def __init__(self, spell):
		self.spell = spell
		DamageAuraBuff.__init__(self, damage=self.spell.aura_damage, radius=self.spell.get_stat('radius'), damage_type=spell.damage_type, friendly_fire=False)
		self.sleep = self.spell.get_stat('sleep')
		self.sleep_dur = self.spell.get_stat('duration', base=3)
		self.ice = self.spell.get_stat('ice')
		self.dream = self.spell.get_stat('dark_dream')
		self.stack_type = STACK_REPLACE
		self.color = Tags.Arcane.color
		self.name = "Nightmare Aura"
		self.source = spell

	def on_hit(self, unit):
		if self.ice: unit.deal_damage(2, Tags.Ice, self)

	def on_damage(self, unit):
		if not self.sleep: return
		unit.apply_buff(SleepBuff(), self.sleep_dur)

	def on_unapplied(self):
		if not self.dream: return
		creatures = [(Witch, 30), (Werewolf, 30), (Raven, 30)]
		for spawner, cost in creatures:
			for i in range(self.damage_dealt // cost):
				unit = spawner()
				apply_minion_bonuses(self.spell, unit)
				self.summon(unit, sort_dist=False, radius=self.radius)

	def get_description(self):
		desc = [("Each turn, deal 2 [Arcane] or [Dark] damage to enemies within [{radius}:radius] tiles", {'radius':self.radius})]
		if self.ice: desc.append("\nAlso deals 2 [Ice] damage to enemies within the radius")
		if self.sleep: desc.append(("\nDamaged enemies are put to [sleep] for [{duration}:duration] turns", {'duration': self.sleep_dur}))
		if self.dream: desc.append("\nWhen this buff ends, summon a Raven, Werewolf, and Witch for every 30 damage it dealt")
		if self.dream: desc.append(("\n{val} damage dealt" , {"val": self.damage_dealt}))
		return desc

class NightmareSpell(Spell):

	def on_init(self):

		self.tags = [Tags.Enchantment, Tags.Dark, Tags.Arcane]
		self.damage_type = [Tags.Dark, Tags.Arcane]
		self.level = 3
		self.range = 0
		self.max_charges = 1
		self.name = "Nightmare Aura"
		self.aura_damage = 2
		self.radius = 5
		self.duration = 20

		self.stats.append('aura_damage')

		self.upgrades['radius'] = (3, 4, "Nightmare Flood")
		self.upgrades['ice'] = (1, 3, "Chilling Dream", "Nightmare Aura deals an additional [Ice] damage hit", [Tags.Ice])
		self.upgrades['sleep'] = (1, 5, "Slumbering Aura", "Enemies damaged by Nightmare Aura are put to [sleep] for [{duration}:duration] turns", None, None, {'duration':3} )
		self.upgrades['dark_dream'] = (1, 4, "Dark Dream", "Upon expiring, summon a Raven, a Werewolf, and a Witch for every 30 damage dealt by Nightmare Aura", [Tags.Conjuration])

		self.add_upgrade_tooltip("Dark Dream", lambda: make_minion(self, Raven), lambda: make_minion(self, Werewolf), lambda: make_minion(self, Witch))

	def cast_instant(self, x, y):
		buff = NightmareBuff(self)
		self.caster.apply_buff(buff, self.get_stat('duration'))

	def get_extra_examine_tooltips(self):
		return [NightmareBuff(self)] + self.get_upgrade_tooltips()

	def get_description(self):
		return ("Each turn, deal 2 [Arcane] or [Dark] damage to enemies within [{radius}:radius] tiles\n"
				"Lasts [{duration}:duration] turns")


class WatcherFormBuff(Stun):

	def __init__(self, spell):
		Stun.__init__(self)
		self.spell = spell
		self.transform_asset = ['char', "watcher"]
		self.stack_type = STACK_TYPE_TRANSFORM
		self.resists[Tags.Physical] = 100
		self.resists[Tags.Lightning] = 100
		self.resists[Tags.Fire] = 75
		self.resists[Tags.Poison] = 100
		self.void_watcher = self.spell.get_stat('void_watcher')
		self.pyrostatic_watcher = self.spell.get_stat('pyrostatic_watcher')
		self.holy_watcher = self.spell.get_stat('holy_watcher')
		self.chain_lightning_watcher = self.spell.get_stat('chain_lightning_watcher')
		if self.void_watcher: self.resists[Tags.Arcane] = 100
		if self.pyrostatic_watcher: self.resists[Tags.Fire] = 100
		if self.holy_watcher: self.resists[Tags.Holy] = 100
		self.color = Tags.Enchantment.color
		self.name = "Watcher Form"
		self.buff_type = BUFF_TYPE_BLESS

	def get_description(self):
		desc = "Each turn, cast Lightning Bolt at the farthest enemy in line of sight"
		if self.holy_watcher: desc += "\nAlso casts Silver Spear"
		if self.pyrostatic_watcher: desc += "\nAlso casts Pyrostatic Pulse"
		if self.void_watcher: desc += "\nAlso casts Void Beam"
		if self.chain_lightning_watcher: desc += "\nAlso casts Chain Lightning"
		desc += "\nCannot move or manually cast spells"
		return desc

	def advance(self):
		self.on_advance()
		if not self.applied or self.turns_left <= 0: return
		self.turns_left -= 1

	def on_pre_advance(self):
		if self.turns_left != 0: return
		self.owner.remove_buff(self)

	def on_advance(self):
		owner = self.owner
		level = owner.level
		targets = level.get_units_by_distance(owner, enemy = True, require_los = not self.void_watcher)
		if targets: self.owner.level.queue_spell(self.shoot(targets[-1]))
		else: level.show_effect(owner.x, owner.y, Tags.Lightning) # fizzle

	def shoot(self, target):
		spells_to_cast = [self.owner.get_or_make_spell(LightningBoltSpell)]
		if self.holy_watcher: spells_to_cast.append(self.owner.get_or_make_spell(SilverSpearSpell))
		if self.pyrostatic_watcher: spells_to_cast.append(self.owner.get_or_make_spell(PyrostaticPulse))
		if self.void_watcher: spells_to_cast.append(self.owner.get_or_make_spell(VoidBeamSpell))
		if self.chain_lightning_watcher: spells_to_cast.append(self.owner.get_or_make_spell(ChainLightningSpell))
		for s in spells_to_cast:
			for _ in self.owner.level.act_cast(self.owner, s, target.x, target.y, pay_costs=False, queue=False):
				yield

	def on_attempt_apply(self, owner):
		return True

	def on_unapplied(self):
		self.owner.apply_buff(StunImmune(), 1)

	def on_applied(self, owner):
		pass

class WatcherFormSpell(Spell):

	def on_init(self):
		self.name = "Watcher Form"
		self.range = 0
		self.max_charges = 3
		self.duration = 5
		self.tags = [Tags.Enchantment, Tags.Lightning, Tags.Eye]
		self.level = 4

		self.upgrades['holy_watcher'] = (1, 4, "Holy Watcher Form", "Watcher Form also casts Silver Spear each turn\nGrants [100 Holy:holy] resist", [Tags.Holy, Tags.Metallic])
		self.upgrades['pyrostatic_watcher'] = (1, 5, "Pyrostatic Watcher Form", "Watcher Form also casts Pyrostatic Pulse each turn\nGrants [100 Fire:fire] resist instead of 75", [Tags.Fire])
		self.upgrades['void_watcher'] = (1, 6, "Void Watcher Form", "Watcher Form also casts Void Beam each turn\nGrants [100 Arcane:arcane] resist\nCan fire at targets outside of line of sight", [Tags.Arcane])
		self.upgrades['chain_lightning_watcher'] = (1, 7, "Chain Watcher Form", "Watcher Form also casts Chain Lightning each turn")

	def cast_instant(self, x, y):
		self.caster.apply_buff(WatcherFormBuff(self), self.get_stat('duration'))

	def get_description(self):
		return ("Each turn, cast Lightning Bolt at the farthest enemy in line of sight\n"
				"You cannot move or manually cast spells while in Watcher Form\n"
				"Gain [100 Physical:physical], [100 Lightning:lightning], and [100 Poison:poison] resistance\n"
				"Gain [75 Fire:fire] resistance\n"
				"Lasts [{duration}:duration] turns")

	def get_extra_examine_tooltips(self):
		return [WatcherFormBuff(self)] + self.get_upgrade_tooltips()

class ImpCallBuff(Buff):

	def __init__(self, spell):
		Buff.__init__(self)
		self.name = "Imp Call"
		self.spell = spell
		self.buff_type = BUFF_TYPE_BLESS
		self.asset = ['status', 'imp_call']

		self.num_summons = self.spell.get_stat('num_summons')

		choices = [spell.fire_imp, spell.spark_imp, spell.iron_imp]
		if spell.get_stat('metalswarm'): choices.extend([spell.copper_imp, spell.furnace_imp, spell.tungsten_imp])
		if spell.get_stat('darkswarm'): choices.extend([spell.rot_imp, spell.void_imp, spell.insanity_imp])
		self.imp_choices = choices

	def get_description(self):
		return ("Each turn, summon [{num_summons}:num_summons] temporary imps nearby", {'num_summons': self.num_summons})


	def on_applied(self, owner):
		self.casts = 0
		self.cast_this_turn = False
		self.color = Tags.Conjuration.color

	def on_advance(self):
		self.owner.level.queue_spell(self.summon_imps())

	def summon_imps(self):
		for i in range(self.num_summons):
			imp = random.choice(self.imp_choices)()
			self.spell.summon(imp, self.owner)
			yield

class EndlessSwarm(Upgrade):

	def on_init(self):
		self.name = "Endless Swarm"
		self.counter = 7
		self.level = 4
		self.num_summons = 4

	def get_description(self):
		return "Every 6 turns, summon [{num_summons}:num_summons] temporary imps\nAlways Active"

	def on_advance(self):
		self.counter -= 1
		if self.counter <= 0:
			spell = self.owner.get_or_make_spell(ImpGateSpell)
			for i in range(self.get_stat('num_summons')):
				imp = random.choice(spell.get_imp_choices())()
				self.summon(imp)
			self.counter = 7


class ImpGateSpell(Spell):

	def on_init(self):
		self.name = "Imp Swarm"
		self.range = 0
		self.max_charges = 2
		self.duration = 4
		self.tags = [Tags.Enchantment, Tags.Conjuration, Tags.Chaos]
		self.level = 4

		self.minion_health = 5
		self.minion_damage = 3
		self.minion_duration = 8
		self.minion_range = 3
		self.num_summons = 2

		self.upgrades[('metalswarm', 'num_summons')] = ([1, 1], 3, "Metal Swarm", "Imp Swarm can also summon Copper, Tungsten, and Furnace Imps", [Tags.Metallic])
		self.upgrades[('darkswarm', 'num_summons')] = ([1, 1], 3, "Dark Swarm", "Imp Swarm can also summon Rot, Void, and Insanity Imps", [Tags.Dark])
		self.upgrades[('minion_health', 'minion_damage', 'minion_range')] = ([5, 3, 3], 6, "Elite Swarm")
		self.add_upgrade(EndlessSwarm())

		self.add_upgrade_tooltip("Metal Swarm", self.copper_imp, self.tungsten_imp, self.furnace_imp)
		self.add_upgrade_tooltip("Dark Swarm", self.rot_imp, self.void_imp, self.insanity_imp)

	def fire_imp(self):
		unit = FireImp()
		apply_minion_bonuses(self, unit)
		return unit

	def spark_imp(self):
		unit = SparkImp()
		apply_minion_bonuses(self, unit)
		return unit

	def iron_imp(self):
		unit = IronImp()
		apply_minion_bonuses(self, unit)
		return unit

	def copper_imp(self):
		unit = CopperImp()
		apply_minion_bonuses(self, unit)
		return unit

	def furnace_imp(self):
		unit = FurnaceImp()
		apply_minion_bonuses(self, unit)
		return unit

	def tungsten_imp(self):
		unit = TungstenImp()
		apply_minion_bonuses(self, unit)
		return unit

	def rot_imp(self):
		unit = RotImp()
		apply_minion_bonuses(self, unit)
		return unit

	def void_imp(self):
		unit = VoidImp()
		apply_minion_bonuses(self, unit)
		return unit

	def insanity_imp(self):
		unit = InsanityImp()
		apply_minion_bonuses(self, unit)
		return unit

	def get_extra_examine_tooltips(self):
		return [ImpCallBuff(self), self.fire_imp(), self.spark_imp(), self.iron_imp()] + self.get_upgrade_tooltips()


	def get_imp_choices(self):
		choices = [self.fire_imp, self.spark_imp, self.iron_imp]
		if self.get_stat('metalswarm'): choices.extend([self.copper_imp, self.furnace_imp, self.tungsten_imp])
		if self.get_stat('darkswarm'): choices.extend([self.rot_imp, self.void_imp, self.insanity_imp])
		return choices

	def cast_instant(self, x, y):
		self.caster.apply_buff(ImpCallBuff(self), self.get_stat('duration'))

	def get_description(self):
		return ("Each turn, summon [{num_summons}:num_summons] temporary imps near the caster\n"
				"Each imp is either a [Fire], [Spark:lightning], or [Iron:physical] imp\n"
				"Lasts [{duration}:duration] turns")


class LightningHaloBuff(Buff):

	def __init__(self, spell):
		Buff.__init__(self)
		self.spell = spell
		self.name = "Lightning Halo"
		self.radius = spell.get_stat('radius')
		self.damage = spell.get_stat('damage')
		self.duration = spell.get_stat('duration')
		self.ring_of_fire = spell.get_stat('ring_of_fire')
		self.radioactivity = spell.get_stat('radioactivity')
		self.expanding = spell.get_stat('expanding')
		self.cage = spell.get_stat('cage')
		self.color = Tags.Lightning.color
		self.asset = ['status', 'lightning_halo']
		if self.cage: self.resists[Tags.Lightning] = 100

		self.buff_type = BUFF_TYPE_BLESS
		self.stack_type = STACK_INTENSITY

		self.connected_targets = []
		self.owner_triggers[EventOnMoved] = self.on_moved

	def on_moved(self, evt):
		self.connected_targets = []

	def get_description(self):
		if self.owner and not self.connected_targets: # gather impacted tiles
			fire_bonus = self.ring_of_fire # 0 if we don't have it, 1 if we do
			points = self.owner.level.get_points_in_ball(self.owner.x, self.owner.y, self.radius + fire_bonus)
			self.connected_targets = [p for p in points if distance(self.owner, p) >= self.radius - 1]
		desc = [("Deal [{damage}:damage] [Lightning] damage in a [{radius}:radius] tile ring each turn", {'damage': self.damage, 'radius': self.radius})]
		if self.radioactivity:
			desc.append(("\nEnemies inside the halo take [{damage}:damage] [Poison] damage and are [poisoned] for [{duration}:duration] turns", {'damage': self.damage, 'duration': self.duration}))
		if self.ring_of_fire:
			desc.append(("\nDeal [{damage}:damage] [Fire] damage in a second outer ring each turn", {'damage': self.damage}))
		if self.expanding:
			desc.append("\nEach turn, this halo gains +1 radius")
		return desc

	def on_advance(self):
		points = self.owner.level.get_points_in_ball(self.owner.x, self.owner.y, self.radius)
		points = [p for p in points if p != Point(self.owner.x, self.owner.y) and distance(self.owner, p) >= self.radius - 1]
		dmg = self.damage
		dur = self.duration

		for p in points: self.owner.level.deal_damage(p.x, p.y, dmg, Tags.Lightning, self.spell)

		if self.radioactivity:
			targets = self.owner.level.get_units_in_ball(Point(self.owner.x, self.owner.y), self.radius - 1)
			targets = [u for u in targets if are_hostile(u, self.owner)]

			for t in targets:
				t.deal_damage(dmg, Tags.Poison, self.spell)
				if t.is_alive(): t.apply_buff(Poison(), dur)

		if self.ring_of_fire:
			points_fire = self.owner.level.get_points_in_ball(self.owner.x, self.owner.y, self.radius + 1)
			points_fire = [p for p in points_fire if  p != Point(self.owner.x, self.owner.y) and distance(self.owner, p) >= self.radius]
			for p in points_fire: self.owner.level.deal_damage(p.x, p.y, dmg, Tags.Fire, self.spell)

		if self.expanding:
			self.radius += 1
			self.connected_targets = []



class LightningHaloSpell(Spell):

	def on_init(self):
		self.name = "Lightning Halo"
		self.range = 0
		self.max_charges = 2
		self.duration = 12
		self.tags = [Tags.Enchantment, Tags.Lightning]
		self.damage_type = [Tags.Lightning]
		self.level = 3
		self.damage = 15

		self.radius = 3

		self.upgrades['ring_of_fire'] = (1, 2, "Ring of Fire",  "Lightning Halo creates an additional outer ring that deals [Fire] damage", [Tags.Fire], [Tags.Fire])
		self.upgrades['radioactivity'] = (1, 4, "Radioactive Field", "Enemies inside the halo take [Poison] damage and are [poisoned] for [{duration}:duration] turns", None, [Tags.Poison], {"duration": 15})
		self.upgrades['cage'] = (1, 3, "Faraday Cage", "Lightning Halo grants [100% Lightning:lightning] resist and [{duration}:duration] turns of clarity when cast", [Tags.Metallic], None, {'duration':12})
		self.upgrades['expanding'] = (1, 5, "Lightning Nova", "The halo grows by +1 radius each turn")

		self.add_upgrade_tooltip("Faraday Cage", lambda: ResistBuff(Tags.Lightning, 100), StunImmune)

	def get_lightning_halo_buff(self):
		return LightningHaloBuff(self)

	def get_extra_examine_tooltips(self):
		return [self.get_lightning_halo_buff()] + self.get_upgrade_tooltips()

	def cast_instant(self, x, y):
		self.caster.apply_buff(self.get_lightning_halo_buff(), self.get_stat('duration'))
		if self.get_stat('cage'): self.caster.apply_buff(StunImmune(), self.get_stat('duration'))

	def get_impacted_tiles(self, x, y):
		c = self.caster
		lvl = c.level
		r = self.get_stat('radius')
		origin = Point(x, y)
		points = list(lvl.get_points_in_ball(x, y, r))
		if not self.get_stat('radioactivity'): # exclude interior points of ring unless you have radioactivity
			points = [p for p in points if p != origin and distance(c, p) >= r - 1] # uses euclidian to hand back the outermost ring.

		if self.get_stat('ring_of_fire'): # if you have ring of fire, add another ring around the outside
			points_fire = list(lvl.get_points_in_ball(x, y, r + 1))
			points_fire = [p for p in points_fire if  p != origin and distance(c, p) >= r]
			points.extend(points_fire)

		return points

	def get_description(self):
		return ("Deal [{damage}:damage] [Lightning] damage in a [{radius}:radius] tile ring each turn\n"
				"Lasts [{duration}:duration] turns")


class MysticVision(Spell):

	def on_init(self):
		self.name = "Mystic Vision"
		self.range = 0
		self.max_charges = 2
		self.duration = 6
		self.bonus = 5
		self.tags = [Tags.Enchantment, Tags.Arcane, Tags.Eye]
		self.level = 3

		self.upgrades['superior_sight'] = (5, 4, "Superior Sight", "Mystic Vision grants [10 range:range] instead of [5 range:range]")
		self.upgrades['aura'] = (1, 5, "Vision Aura", "Mystic Vision is also applied to your allies")
		self.upgrades['overwatch'] = (1, 4, "Overwatch", "When you cast Mystic Vision, cast Floating Eye on unoccupied adjacent tiles")
		self.upgrades['truesight'] = (1, 8, "Truesight", "Mystic Vision also lets you ignore line of sight requirements for casting spells")

	def get_extra_examine_tooltips(self):
		return [self.get_vision_buff()] + self.get_upgrade_tooltips()

	def get_vision_bonus(self):
		return self.get_stat('bonus') + self.get_stat('superior_sight')

	def get_vision_buff(self):
		buff = GlobalAttrBonus('range', self.get_vision_bonus())
		if self.get_stat('truesight'): buff.global_bonuses['requires_los'] = -1
		buff.name = "Mystic Vision"
		buff.stack_type = STACK_DURATION
		buff.color = Tags.Arcane.color
		return buff

	def cast_instant(self, x, y):
		caster = self.caster
		buff = self.get_vision_buff()

		duration = self.get_stat('duration')
		caster.apply_buff(buff, duration)

		if self.get_stat('overwatch') and caster.is_player_controlled:
			act_cast = caster.level.act_cast
			spell = caster.get_or_make_spell(SummonFloatingEye)
			for p in caster.level.get_adjacent_points(caster, filter_walkable=False, check_unit=True, r=caster.radius):
				if caster.level.tiles[p.x][p.y].is_wall(): continue
				if spell.can_cast(p.x, p.y):
					for _ in act_cast(caster, spell, p.x, p.y, pay_costs=False, queue=False):
						pass

		if self.get_stat('aura'):
			for u in caster.get_allies():
				u.apply_buff(self.get_vision_buff(), duration)

	def get_description(self):
		return ("All spells and equipment gain {bonus} [range]\n"
				"Lasts [{duration}:duration] turns")

	def fmt_dict(self):
		d = Spell.fmt_dict(self)
		d['bonus'] = self.get_vision_bonus()
		return d

class MysticPower(Spell):

	def on_init(self):
		self.name = "Mystic Power"
		self.range = 0
		self.max_charges = 4
		self.duration = 8
		self.bonus_damage = 7
		self.tags = [Tags.Enchantment, Tags.Arcane]
		self.level = 3

		self.upgrades[('duration', 'bonus_damage')] = ([8, 7], 6, "Mystic Arcanum")
		self.upgrades['explosive_power'] = (1, 4, "Explosive Power", "Mystic Power also grants +2 [radius] to all spells and equipment")
		self.upgrades[('bonus_damage', 'hp_cost')] = ([7, 25], 1, "Blood is Power", "", [Tags.Blood])
		self.upgrades[('occult_power', 'radius')] = ([1, 4], 4, "Occult Power", "When you cast Mystic Power, sacrifice allies within [{radius}:radius] tiles\nIncrease the duration and damage bonus by the number of allies sacrificed\nSubsequent casts no longer stack duration, but instead replace the previous instance", [Tags.Dark])

	def get_extra_examine_tooltips(self):
		return [self.get_mystic_buff()] + self.get_upgrade_tooltips()

	def get_mystic_buff(self):
		buff = GlobalAttrBonus('damage', self.get_stat('bonus_damage'))
		if self.get_stat('explosive_power'): buff.global_bonuses['radius'] = 2
		if self.get_stat('occult_power'):
			buff.name = "Occult Power"
			buff.color = Tags.Dark.color
			buff.stack_type = STACK_REPLACE
		else:
			buff.name = "Mystic Power"
			buff.stack_type = STACK_DURATION
			buff.color = Tags.Arcane.color
		return buff

	def cast_instant(self, x, y):
		sacrificed = 0
		buff = GlobalAttrBonus('damage', self.get_stat('bonus_damage'))
		buff.name = "Mystic Power"
		buff.stack_type = STACK_DURATION
		buff.color = Tags.Arcane.color

		if self.get_stat('occult_power'):
			sacrifices = [u for u in self.caster.level.get_units_in_ball(self.caster, self.get_stat('radius', base=4)) if not are_hostile(u, self.caster) and not u==self.caster and not u.is_player_controlled]
			for u in sacrifices:
				self.caster.level.show_effect(u.x, u.y, Tags.Dark)
				u.kill()
				sacrificed += 1
			buff.global_bonuses['damage'] += sacrificed
			buff.name = "Occult Power"
			buff.color = Tags.Dark.color
			buff.stack_type = STACK_REPLACE

		if self.get_stat('explosive_power'): buff.global_bonuses['radius'] = 2

		self.caster.apply_buff(buff, self.get_stat('duration') + sacrificed)

	def get_description(self):
		return ("All spells and equipment gain {bonus_damage} [damage]\n"
				"Lasts [{duration}:duration] turns")

	def get_impacted_tiles(self, x, y):
		if self.get_stat('occult_power'):
			points = self.caster.level.get_points_in_ball(self.caster.x, self.caster.y, self.get_stat('radius', base=4))
			for p in points:
				unit = self.caster.level.get_unit_at(p.x, p.y)
				if unit and not are_hostile(unit, self.caster):
					yield p
		else:
			return Point(x, y)

class FlameBurstSpell(Spell):

	def on_init(self):
		self.name = "Flame Burst"
		self.range = 0
		self.max_charges = 3
		self.damage = 40
		self.tags = [Tags.Fire, Tags.Sorcery]
		self.level = 4
		self.radius = 5

		self.upgrades['meltflame'] = (1, 2, "Melting Flame", "Melt walls adjacent to the blast")
		self.upgrades['echo'] = (1, 5, "Dual Burst", "Auto recasts at the end of your next turn")
		self.upgrades['dawnflame'] = (1, 4, "Bright Flame", "Deal [Holy] damage instead of [Fire]\nGrants allies [1 SH:shields] instead of damaging them", [Tags.Holy])
		self.upgrades['spreadflame'] = (1, 6, "Spreading Flame", "Casting Flame Burst consumes all remaining charges\nFor each charge consumed, it gets +1 [radius]\nSlain units create additional explosions with half radius and damage\nWill not harm the caster")

	def get_impacted_tiles(self, x, y):
		radius = self.get_stat('radius')
		if self.get_stat('spreadflame'): radius += self.cur_charges
		return [p for stage in Burst(self.caster.level, Point(x, y), radius, ignore_walls=not self.get_stat('requires_los')) for p in stage]

	def cast(self, x, y, secondary=False, last_radius=None, last_damage=None, is_echo=False):

		caster = self.caster
		level = caster.level
		getu = level.get_unit_at
		get_adjacent_points = level.get_adjacent_points
		tiles = level.tiles

		dawnflame = self.get_stat('dawnflame')
		spreading = self.get_stat('spreadflame')
		melting = self.get_stat('meltflame')

		if self.get_stat('echo') and not is_echo: caster.apply_buff(EchoCast(self), 2)

		if secondary:
			radius = last_radius // 2
			damage = last_damage // 2

			if radius < 2: return
			if damage < 0: return

		else:
			radius = self.get_stat('radius')
			damage = self.get_stat('damage')

		if not secondary and spreading:
			radius += self.cur_charges
			self.cur_charges = 0

		to_melt = set()
		slain = []

		stagenum = 0

		for stage in Burst(level, Point(x, y), radius, ignore_walls=not self.get_stat('requires_los')):
			dtype = Tags.Holy if dawnflame else Tags.Fire
			stagenum += 1

			for p in stage:
				u = getu(p.x, p.y)
				if u == caster: continue
				if u:
					if dawnflame and not are_hostile(caster, u): u.add_shields(1)
					else:
						level.deal_damage(p.x, p.y, damage, dtype, self)
						if spreading and not u.is_alive(): slain.append(u)

				else: level.deal_damage(p.x, p.y, damage, dtype, self)

				if melting:
					for q in get_adjacent_points(p, False, False):
						if tiles[q.x][q.y].is_wall(): to_melt.add(q)

			yield

		if spreading:
			for unit in slain:
				level.queue_spell(self.cast(unit.x, unit.y, secondary=True, last_damage=damage, last_radius=radius, is_echo=True))

		if melting:
			for q in get_adjacent_points(Point(x, y), False, False):
				if tiles[q.x][q.y].is_wall(): to_melt.add(q)
			for p in to_melt:
				level.make_floor(p.x, p.y)
				level.show_effect(p.x, p.y, dtype)

	def get_description(self):
		return ("Deal [{damage}:damage] [Fire] damage in a [{radius}:radius] tile burst around the caster")


def make_giant_drake_if_possible(spell, x, y, spawn_fn, upgrade_attr, summoned_level_ids, consume=False):
	if not spell.get_stat(upgrade_attr): return None
	level_id = spell.caster.level.level_id
	if level_id in summoned_level_ids: return None
	dragon = spell.make_drake(spawn_fn)
	if not spell.caster.level.can_stand(x, y, dragon): return None
	if consume: summoned_level_ids.add(level_id)
	return dragon


class SummonFireDrakeSpell(Spell):

	def on_init(self):
		self.name = "Fire Drake"
		self.range = 4
		self.max_charges = 3
		self.tags = [Tags.Fire, Tags.Conjuration, Tags.Dragon]
		self.level = 4

		self.minion_health = 48
		self.minion_damage = 9
		self.minion_range = 5

		self.upgrades['dragon_mage'] = (1, 4, "Dragon Mage", "Fire Drakes gain the [Arcane] tag and can cast your Blazerip on a 4 turn cooldown", [Tags.Arcane])
		self.upgrades['superheated'] = (1, 3, "Superheated Flames", "Fire Drakes' breath attack melts walls")
		self.upgrades['lava'] = (1, 3, "Lava Born", "If you cast this spell targeting a lava chasm, the summoned drake's HP, Breath Damage, and Breath Range are tripled")
		self.upgrades['cindervein'] = (1, 9, "Cindervein", "When you cast this spell, if there is room, summon Cindervein instead of a Fire Drake\nCan only activate once each level")
		self.add_upgrade_tooltip("Cindervein", lambda: self.make_drake(Cindervein))

		self.cindervein_level_ids = set()
		self.must_target_empty = True

	def make_drake(self, spawn_fn=FireDrake):
		u = spawn_fn()
		apply_minion_bonuses(self, u)
		if self.get_stat('superheated'): u.get_spell(BreathWeapon).ignore_walls = True
		if self.get_stat('dragon_mage'):
			grant_minion_spell(Blazerip, u, self.caster, cool_down=4)
			if Tags.Arcane not in u.tags: u.tags.append(Tags.Arcane)
		return u

	def get_impacted_tiles(self, x, y):
		drake = make_giant_drake_if_possible(self, x, y, Cindervein, 'cindervein', self.cindervein_level_ids)
		if drake: return self.caster.level.get_points_in_ball(x, y, drake.radius, diag=True)
		return [Point(x, y)]

	def cast_instant(self, x, y):
		drake = make_giant_drake_if_possible(self, x, y, Cindervein, 'cindervein', self.cindervein_level_ids, consume=True)
		level = self.caster.level
		target = Point(x, y)

		if not drake: drake = self.make_drake()

		if self.get_stat('lava'):
			tile = level.tiles[x][y]
			if tile.is_chasm and tile.chasm_type == 'lava':
				drake.max_hp *= 3
				s = drake.get_spell(BreathWeapon)
				s.damage *= 3
				s.range *= 3

		self.summon(drake, target)

	def get_description(self):
		return "Summon a Fire Drake"

	def get_extra_examine_tooltips(self):
		return [self.make_drake()] + self.get_upgrade_tooltips()


class SummonStormDrakeSpell(Spell):

	def on_init(self):
		self.name = "Storm Drake"
		self.range = 4
		self.max_charges = 3
		self.tags = [Tags.Lightning, Tags.Conjuration, Tags.Dragon]
		self.level = 4

		self.minion_health = 48
		self.minion_damage = 10
		self.minion_range = 5

		self.upgrades['spirit'] = (1, 3, "Spirit Drakes", "Storm Drakes gain 5 HP when you cast a [Lightning] spell targeting a tile in their line of sight")
		self.upgrades['dragon_mage'] = (1, 3, "Dragon Mage", "Storm Drakes can cast your Chain Lightning on a 9 turn cooldown")
		self.upgrades[('storm_legion', 'num_summons')] = ([1, 2], 7, "Storm Summoning", "When you cast Storm Drake, up to [{num_summons}:num_summons] [Storm Clouds:lightning] in line of sight of the target are converted into Storm Drakes")
		self.upgrades['stormcrest'] = (1, 9, "Stormcrest", "When you cast this spell, if there is room, summon Stormcrest instead of a Storm Drake\nCan only activate once each level")

		self.add_upgrade_tooltip("Stormcrest", lambda: self.make_drake(Stormcrest))

		self.stormcrest_level_ids = set()
		self.must_target_empty = True

	def get_extra_examine_tooltips(self):
		return [self.make_drake()] + self.get_upgrade_tooltips()

	def make_drake(self, spawn_fn=StormDrake):
		drake = spawn_fn()
		apply_minion_bonuses(self, drake)
		if self.get_stat('dragon_mage'): grant_minion_spell(ChainLightningSpell, drake, self.caster, 9)
		if self.get_stat('spirit'): drake.apply_buff(self.get_spirit_buff())
		return drake

	def get_spirit_buff(self):
		return SpiritBuff(Tags.Lightning, 5)

	def get_impacted_tiles(self, x, y):
		drake = make_giant_drake_if_possible(self, x, y, Stormcrest, 'stormcrest', self.stormcrest_level_ids)
		if drake: return self.caster.level.get_points_in_ball(x, y, drake.radius, diag=True)
		return [Point(x, y)]

	def cast_instant(self, x, y):
		summon_targets = [Point(x, y)]

		stormcrest = make_giant_drake_if_possible(self, x, y, Stormcrest, 'stormcrest', self.stormcrest_level_ids, consume=True)

		if self.get_stat('storm_legion'):
			extra_targets = [t for t in self.caster.level.iter_tiles() if self.caster.level.can_see(x, y, t.x, t.y) and isinstance(t.cloud, StormCloud)]
			random.shuffle(extra_targets)
			extra_targets = extra_targets[:self.get_stat('num_summons')]
			for t in extra_targets: t.cloud.kill()
			summon_targets.extend(extra_targets)

		for t in summon_targets:
			drake = self.make_drake() if not stormcrest else stormcrest
			self.owner.level.show_beam(Point(x, y), t, Tags.Lightning, minor=True)
			self.summon(drake, t)
			stormcrest = None

	def get_description(self):
		return "Summon a Storm Drake"

class EssenceDrakeBuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)

	def on_init(self):
		self.global_triggers[EventOnDeath] = self.on_death

	def on_death(self, evt):
		if not evt.damage_event:
			return
		if not are_hostile(self.owner, evt.unit):
			return
		if not evt.damage_event.source.owner == self.owner:
			return

		candidates = [u for u in self.owner.level.units if not are_hostile(u, self.owner) and u.turns_to_death]
		if not candidates:
			return

		candidate = random.choice(candidates)
		candidate.turns_to_death = None


class VoidMutations(Upgrade):

	def on_init(self):
		self.name = "Void Mutations"
		self.level = 5
		self.mutated_level_ids = set()
		self.owner_triggers[EventOnUnitAdded] = self.on_added
		self.bonus_attrs = ['minion_health', 'minion_range', 'minion_damage']

	def get_description(self):
		if self.owner:
			bonus = self.owner.get_mastery(Tags.Arcane)
			return ("At the beginning of each level, Void Drake gains a permanent [{bonus}%:arcane] bonus to [minion_health], [minion_damage], and [minion_range]\n"
					"The bonus is equal to your [Arcane] mastery", {'bonus': bonus})
		return ("At the beginning of each level, Void Drake gains a permanent percentage bonus to [minion_health], [minion_damage], and [minion_range]\n"
				"The bonus is equal to your [Arcane] mastery")

	def on_added(self, evt):
		level_id = self.owner.level.level_id
		if level_id in self.mutated_level_ids: return
		self.mutated_level_ids.add(level_id)
		bonus = self.owner.get_mastery(Tags.Arcane)
		for attr in self.bonus_attrs:
			self.owner.adjust_spell_bonus(type(self.prereq), attr, bonus, pct=True)
			self.owner.level.log(("Void Drake's {attr} increased by {bonus}%", {"attr": attr_label(attr), "bonus": bonus}))
		self.prereq.do_ui_flash(Tags.Arcane)


class SummonVoidDrakeSpell(Spell):

	def on_init(self):
		self.name = "Void Drake"
		self.range = 4
		self.max_charges = 3
		self.tags = [Tags.Arcane, Tags.Conjuration, Tags.Dragon]
		self.level = 4

		self.minion_health = 48
		self.minion_damage = 9
		self.minion_range = 5

		self.upgrades['shields'] = (10, 3, "Shields", "")
		self.upgrades['dragon_mage'] = (1, 3, "Dragon Mage", "Void Drakes can cast your Magic Missile on a 3 turn cooldown")
		self.upgrades['essence_drake'] = (1, 1, "Essence Drake", "When a Void Drake kills an enemy, a random temporary ally becomes permanent")
		self.add_upgrade(VoidMutations())

		self.must_target_empty = True

	def make_drake(self):
		u = VoidDrake()
		if self.get_stat('shields'): u.shields += self.get_stat('shields')
		apply_minion_bonuses(self, u)
		if self.get_stat('dragon_mage'): grant_minion_spell(MagicMissile, u, self.caster, 3)
		if self.get_stat('essence_drake'): u.apply_buff(EssenceDrakeBuff(self))
		return u

	def cast_instant(self, x, y):
		drake = self.make_drake()
		self.summon(drake, Point(x, y))

	def get_description(self):
		return "Summon a Void Drake"

	def get_extra_examine_tooltips(self):
		return [self.make_drake()] + self.get_upgrade_tooltips()

class SummonIceDrakeSpell(Spell):

	def on_init(self):
		self.name = "Ice Drake"
		self.range = 4
		self.max_charges = 3
		self.tags = [Tags.Ice, Tags.Conjuration, Tags.Dragon]
		self.level = 4

		self.minion_range = 5
		self.minion_health = 48
		self.minion_damage = 8

		self.upgrades[('minion_health', 'minion_damage', 'minion_range')] = ([16, 4, 1], 3, "Elite Drakes")
		self.upgrades['dragon_mage'] = (1, 2, "Dragon Mage", "Ice Drakes gain the [Dark] tag and can cast your Death Chill on a 6 turn cooldown", [Tags.Dark])
		self.upgrades['embrace'] = (1, 3, "Cold Embrace", "Instead of harming allies, the Ice Drake's breath grants them 5% [Ice] resist and 1 [SH:shields]")
		self.upgrades['winterbringer'] = (1, 9, "Winterbringer", "When you cast this spell, if there is room, summon Winterbringer instead of an Ice Drake\nCan only activate once each level")

		self.add_upgrade_tooltip("Winterbringer", lambda: self.make_drake(Winterbringer))

		self.winterbringer_level_ids = set()
		self.must_target_empty = True

	def get_extra_examine_tooltips(self):
		return [self.make_drake()] + self.get_upgrade_tooltips()

	def make_drake(self, spawn_fn=IceDrake):
		u = make_minion(self, spawn_fn)
		if self.get_stat('dragon_mage'):
			grant_minion_spell(DeathChill, u, self.caster, cool_down=6, pre_insert=True)
			if Tags.Dark not in u.tags: u.tags.append(Tags.Dark)
		if self.get_stat('embrace'): u.get_spell(IceBreath).embrace = True
		return u

	def get_impacted_tiles(self, x, y):
		u = make_giant_drake_if_possible(self, x, y, Winterbringer, 'winterbringer', self.winterbringer_level_ids)
		if u: return self.caster.level.get_points_in_ball(x, y, u.radius, diag=True)
		return [Point(x, y)]

	def cast_instant(self, x, y):
		u = make_giant_drake_if_possible(self, x, y, Winterbringer, 'winterbringer', self.winterbringer_level_ids, consume=True)
		if not u: u = self.make_drake()
		self.summon(u, Point(x, y))

	def get_description(self):
		return "Summon an Ice Drake"


class ChainLightningSpell(Spell):

	def on_init(self):
		self.name = "Chain Lightning"
		self.range = 5
		self.max_charges = 3
		self.tags = [Tags.Lightning, Tags.Sorcery]
		self.damage_type = [Tags.Lightning]
		self.level = 3
		self.damage = 24

		self.upgrades['chain_fireball'] = (1, 7, "Chain Fireball", "Cast Fireball on each tile Chain Lightning arcs to", [Tags.Fire], [Tags.Fire])
		self.upgrades['weathercraft'] = (1, 2, "Cloud Conductance", "Chain Lightning can arc to [Blizzards:ice], [Rain Clouds:nature], and [Storm Clouds:lightning]", [Tags.Nature])
		self.upgrades['shield'] = (1, 3, "Lightning Shield", "Chain Lightning can arc to friendly targets\nFriendly units hit by Chain Lightning gain [1 SH:shields] instead of being damaged")
		self.upgrades['jolting'] = (1, 1, "Jolting Chain", "Affected units are [stunned:stun] for 1 turn")

	def get_description(self):
		return ("Unleash an arcing bolt of electricity dealing [{damage}:damage] [Lightning] damage\n"
				"The bolt repeatedly arcs to new targets within range of the previous target\n"
				"Each arc deals damage to units in a beam\n"
				"The bolt terminates when it cannot arc to any new targets")

	def cast(self, x, y):

		prev = self.caster
		target = self.caster.level.get_unit_at(x, y) or Point(x, y)
		already_hit = set()

		shield = self.get_stat('shield')
		dmg = self.get_stat('damage')
		jolting = self.get_stat('jolting')

		def hit_square(x, y):
			unit = self.caster.level.get_unit_at(x, y)
			if unit and are_friendly(unit, self.caster) and shield: unit.add_shields(1)
			else:
				self.caster.level.deal_damage(x, y, dmg, Tags.Lightning, self)
				if unit and jolting: unit.apply_buff(Stun(), 1)

		fireball = self.caster.get_or_make_spell(FireballSpell)

		while target:
			for p in self.caster.level.get_points_in_line(prev, target, find_clear=True)[1:]:
				hit_square(p.x, p.y)
			for i in range(2): yield

			if self.get_stat('chain_fireball'):
				s = self.owner.level.act_cast(self.owner, fireball, target.x, target.y, pay_costs=False, queue=False)
				for _ in s: pass
				yield

			already_hit.add(Point(target.x, target.y))

			def can_arc(p, prev):
				if p in already_hit:
					return False
				if not self.caster.level.can_see(prev.x, prev.y, p.x, p.y):
					return False

				u = self.caster.level.get_unit_at(p.x, p.y)
				if u and are_hostile(self.caster, u):
					return True

				if u and not are_hostile(self.caster, u) and self.get_stat('shield'):
					return True

				c = self.caster.level.tiles[p.x][p.y].cloud
				if c and (type(c) in [StormCloud, BlizzardCloud, RainCloud]) and self.get_stat('weathercraft'):
					return True

				return False

			potential_targets = [p for p in self.caster.level.get_points_in_ball(target.x, target.y, self.get_stat('range')) if can_arc(p, target)]

			prev = target
			if potential_targets: target = random.choice(potential_targets)
			else: target = None

class SoulCharge(Buff):

	def on_init(self):
		self.name = "Soulcharge"
		self.buff_type = BUFF_TYPE_BLESS
		self.color = Tags.Dark.color
		self.tag_bonuses[Tags.Dark]['damage'] = 1
		self.stack_type = STACK_INTENSITY

class DeathBolt(Spell):

	def on_init(self):
		self.name = "Death Bolt"
		self.tags = [Tags.Dark, Tags.Sorcery, Tags.Conjuration]
		self.damage_type = [Tags.Dark]
		self.can_target_empty = False
		self.level = 1
		self.damage = 10
		self.range = 6
		self.max_charges = 20
		self.minion_damage = 5

		self.upgrades[('blood', 'hp_cost')] = ([1, 1], 2, "Blood Bolt", "Death Bolt heals the caster for any damage it deals", [Tags.Blood])
		self.upgrades['winter'] = (1, 2, "Winter Bolt", "Deathbolt also deals [Ice] damage", [Tags.Ice], [Tags.Ice])
		self.upgrades['battery'] = (1, 3, "Soul Battery", "The Wizard gains [Soulcharge:dark] when Death Bolt kills a target\n[Soulcharge:dark] grants 1 [damage] to [Dark] spells and equipment until the level ends")
		self.upgrades[('explosion', 'radius')] = ([1, 2], 5, "Corpse Explosion", "Killing a unit with Death Bolt deals [{damage}:damage] [Dark] and [Physical] damage to enemies in a [{radius}:radius] tile radius around them", None, None, {'damage':3})

	def cast(self, x, y):
		caster = self.caster
		level = caster.level

		damage = self.get_stat('damage')

		winter = self.get_stat('winter')
		blood = self.get_stat('blood')
		battery = self.get_stat('battery')
		explosion = self.get_stat('explosion')

		unit = level.get_unit_at(x, y)
		if unit and Tags.Living in unit.tags: level.queue_spell(self.try_raise(caster, unit))
		level.show_beam(caster, Point(x, y), Tags.Dark, minor=False)

		dealt = level.deal_damage(x, y, damage, Tags.Dark, self)
		if winter: dealt += level.deal_damage(x, y, damage, Tags.Ice, self)
		if dealt and blood: caster.heal(dealt, self)

		yield

		if unit and unit.is_alive(): return
		if battery: level.player_unit.apply_buff(SoulCharge())

		if not explosion: return
		explosion_damage = self.get_stat('damage', base=3)
		explosion_radius = self.get_stat('radius')
		units = set(u for u in level.get_units_in_ball(Point(x, y), explosion_radius) if are_hostile(caster, u))
		while units:
			unit = units.pop()
			if unit and Tags.Living in unit.tags: level.queue_spell(self.try_raise(caster, unit))
			dealt = level.deal_damage(unit.x, unit.y, explosion_damage, Tags.Dark, self)
			dealt += level.deal_damage(unit.x, unit.y, explosion_damage, Tags.Physical, self)
			if winter: dealt += level.deal_damage(unit.x, unit.y, damage, Tags.Ice, self)
			if dealt and blood: caster.heal(dealt, self)
			if unit and unit.is_alive(): continue
			if battery: level.player_unit.apply_buff(SoulCharge())
			units.update(set(u for u in level.get_units_in_ball(unit, explosion_radius) if are_hostile(caster, u)))
			yield

	def try_raise(self, caster, unit):
		if unit and unit.cur_hp <= 0 and not self.caster.level.get_unit_at(unit.x, unit.y):
			skeleton = raise_skeleton(caster, unit, source=self)
			if skeleton:
				apply_minion_bonuses(self, skeleton)
				skeleton.cur_hp = skeleton.max_hp # Since we've already added unit to level in this case
			yield

	def get_description(self):
		return ("Deals [{damage}:damage] [Dark] damage to a target\n"
				"Slain [Living] units are raised as Skeletons\n"
				"Raised skeletons inherit the max HP of the slain unit")

	def get_extra_examine_tooltips(self):
		return [make_minion(self, Skeleton)] + self.get_upgrade_tooltips()

class DeathCycle(Upgrade):

	def on_init(self):
		self.name = "Death Cycle"
		self.description = ("When a unit dies to [Dark] damage, there is a 10% chance to cast Wheel of Death"
							"\nIf the cast fails to trigger, the chance for it to cast on the next instance increases by 10%"
							"\nAlways Active")
		self.level = 7
		self.global_triggers[EventOnDeath] = self.on_death
		self.chance = 0

	def on_death(self, evt):
		dvt = evt.damage_event
		if not dvt: return
		if dvt.damage_type != Tags.Dark: return

		chance = self.chance + .1
		if random.random() < chance:
			self.chance = 0
			u = self.owner
			self.owner.level.act_cast(u, u.get_or_make_spell(WheelOfDeath), u.x, u.y, pay_costs=False)
		else:
			self.chance = chance


class WheelOfDeath(Spell):

	def on_init(self):
		self.name = "Wheel of Death"
		self.damage = 200
		self.range = 0
		self.tags = [Tags.Dark, Tags.Sorcery]
		self.damage_type = [Tags.Dark]
		self.level = 4
		self.max_charges = 9

		self.upgrades['cheater'] = (1, 2, "Cheat Fate", "Wheel of Death will prefer to hit unshielded and [Dark] vulnerable enemies")
		self.upgrades[('shared', 'num_targets')] = ([1, 2], 5, "Shared Misfortune", "Wheel of Death instead deals damage to [{num_targets}:num_targets] targets\nThe damage dealt to each target is divided by the number of targets hit")
		self.upgrades[('ritual', 'max_channel')] = ([1, 4], 5, "Ritual of Death", "Wheel of Death can be channeled for up to [{max_channel}:max_channel] turns\nIf the ritual is completed, all [Living] enemies lose 10% of their max HP", [Tags.Ritual])
		self.add_upgrade(DeathCycle())

	def cast(self, x, y, channel_cast=False):
		caster = self.caster
		level = caster.level

		ritual = self.get_stat('ritual')
		cheater = self.get_stat('cheater')

		if ritual and not channel_cast and self.is_manual_cast():
			caster.apply_buff(ChannelBuff(self.cast, Point(x, y)), self.get_stat('max_channel'))
			return

		valid_targets = [u for u in level.units if level.are_hostile(caster, u)]
		if not valid_targets: return
		targets = [random.choice(valid_targets)]

		if cheater:
			preferred_targets = [t for t in valid_targets if t.resists[Tags.Dark] < 100]
			more_preferred_targets = [t for t in preferred_targets if not t.shields]
			if more_preferred_targets: valid_targets = more_preferred_targets
			elif preferred_targets: valid_targets = preferred_targets
			weights = [max(0, t.cur_hp * (100 -t.resists[Tags.Dark])) for t in valid_targets]
			if sum(weights) > 0: targets = [random.choices(valid_targets, weights=weights, k=1)[0]]

		if self.get_stat('shared'):
			if cheater:
				n = min(self.get_stat('num_targets'), len(valid_targets))
				targets = []
				pool = list(valid_targets)
				while len(targets) < n and pool: # have to loop so the same target doesn't get picked multiple times since random.choices() doens't support no-replacement
					weights = [max(0, t.cur_hp * (100 - t.resists[Tags.Dark])) for t in pool]
					if sum(weights) == 0: # fallback if all immune
						targets.extend(pool[:n - len(targets)])
						break
					pick = random.choices(pool, weights=weights, k=1)[0]
					targets.append(pick)
					pool.remove(pick)
			else:
				random.shuffle(valid_targets)
				targets = valid_targets[:self.get_stat('num_targets')]

		dmg = self.get_stat('damage')
		for target in targets:
			target.deal_damage(dmg // len(targets), Tags.Dark, self)
			level.show_path_effect(caster, target, Tags.Dark, minor=True)
			for i in range(3): yield

		if ritual and channel_cast and not caster.has_buff(ChannelBuff): # final turn
			for enemy in [u for u in level.units if Tags.Living in u.tags and are_hostile(caster, u)]:
				level.show_path_effect(caster, enemy, Tags.Dark)
				enemy.max_hp = max(1, int(enemy.max_hp * 0.9))
				enemy.cur_hp = max(1, min(enemy.cur_hp, enemy.max_hp))
				for i in range(3): yield

	def get_description(self):
		return "Deal [{damage}:damage] [Dark] damage to a random enemy"

class TouchOfDeath(Spell):

	def on_init(self):
		self.damage = 200
		self.range = 1.5
		self.melee = True
		self.can_target_self = False
		self.max_charges = 9
		self.name = "Touch of Death"
		self.tags = [Tags.Dark, Tags.Sorcery]
		self.damage_type = [Tags.Dark]
		self.level = 2

		self.can_target_empty = False

		self.upgrades['fire_damage'] = (1, 4, "Flametouch", "Touch of Death also deals [Fire] damage", [Tags.Fire], [Tags.Fire])
		self.upgrades[('vampire', 'minion_health', 'minion_damage')] = ([1, 32, 7], 2, 'Touch of the Vampire', 'When a [Living] target is damaged by Touch of Death, you heal for the damage dealt\nIf it dies to Touch of Death it is raised as Vampire', [Tags.Blood, Tags.Conjuration])
		self.upgrades[('hand_of_death', 'num_targets')] = ([1, 4], 2, 'Hand of Death', 'Touch of Death hits up to [{num_targets}:num_targets] more targets adjacent to the caster')
		self.upgrades['final_touch'] = (1, 8, 'Final Touch', "Touch of Death deals additional damage equal to the target's max HP")

		self.add_upgrade_tooltip("Touch of the Vampire", self.get_vamp)

	def get_vamp(self):
		vamp = Vampire()
		apply_minion_bonuses(self, vamp)
		vamp.buffs[0].spawner = self.get_vamp_bat
		return vamp

	def get_vamp_bat(self):
		bat = VampireBat()
		apply_minion_bonuses(self, bat)
		bat.buffs[0].spawner = self.get_vamp
		return bat

	def cast_instant(self, x, y):
		caster = self.caster
		level = caster.level
		unit = level.get_unit_at(x, y)
		targets = [unit]

		if self.get_stat('hand_of_death'):
			potential_extra_targets = [u for u in level.get_adjacent_units(caster) if are_hostile(caster, u) and u != unit]
			random.shuffle(potential_extra_targets)
			targets.extend(potential_extra_targets[:self.get_stat('num_targets')])

		dmg = self.get_stat('damage')
		final = self.get_stat('final_touch')
		vamp = self.get_stat('vampire')

		damage_types = self.get_stat('damage_type')

		for u in targets:
			if not u: continue
			dealt = 0
			for dtype in damage_types:
				if final: dealt += u.deal_damage(dmg+u.max_hp, dtype, self)
				else: dealt += u.deal_damage(dmg, dtype, self)

			if vamp and Tags.Living in u.tags:
				if dealt: caster.heal(dealt, self)
				if not u.is_alive(): self.summon(self.get_vamp(), Point(u.x, u.y))

	def get_description(self):
		return "Deal [{damage}:damage] [Dark] damage to the target"


class SealedFateBuff(Buff):

	def __init__(self, spell):
		Buff.__init__(self)
		self.spell = spell
		self.name = "Sealed Fate"
		self.buff_type = BUFF_TYPE_CURSE
		self.stack_type = STACK_INTENSITY
		self.asset = ['status', 'sealed_fate']
		self.heaven = self.spell.get_stat('heaven')
		self.spreads = self.spell.get_stat('spreads')
		self.delay = self.spell.get_stat('delay')
		self.damage = self.spell.get_stat('damage')
		self.damage_type = list(self.spell.get_stat('damage_type'))

	def on_applied(self, owner):
		self.color = Tags.Dark.color

	def get_description(self):
		if self.heaven:
			desc = [("After {delay} turns, take [{damage}:damage] [Dark] and [Holy] damage", {'delay': self.delay, 'damage': self.damage})]
		else:
			desc = [("After {delay} turns, take [{damage}:damage] [Dark] damage", {'delay': self.delay, 'damage': self.damage})]
		if self.spreads:
			desc.append("\nWhen Sealed Fate expires, it jumps to a random enemy in line of sight")
		return desc

	def on_advance(self):
		if self.turns_left == 1:
			for dtype in self.damage_type:
				self.owner.deal_damage(self.damage, dtype, self.spell)

			if self.spreads:
				possible_targets = [u for u in self.owner.level.get_units_in_los(self.owner) if u != self.owner and are_hostile(u, self.spell.owner)]
				if possible_targets:
					target = random.choice(possible_targets)
					target.apply_buff(self.spell.get_sealed_fate_buff(), self.delay)

class SealFate(Spell):

	def on_init(self):
		self.name = "Seal Fate"
		self.range = 6
		self.max_charges = 13
		self.tags = [Tags.Enchantment, Tags.Dark]
		self.damage_type = [Tags.Dark]
		self.level = 3
		self.delay = 4
		self.stats.append('delay')
		self.damage = 160

		self.upgrades['requires_los'] = (-1, 1, "Blindcasting", "Seal Fate can be cast outside your line of sight")
		self.upgrades['spreads'] = (1, 2, "Spreading Curse", "When Sealed Fate's duration expires, it jumps to a random enemy in line of sight")
		self.upgrades['heaven'] = (1, 4, "Heavenly Mandate", "Sealed Fate also deals [Holy] damage", [Tags.Holy], [Tags.Holy])
		self.upgrades['fatebound'] = (1, 8, "Fatebound", "Seal Fate affects all enemies with the same name as target")

		self.can_target_empty = False

	def cast(self, x, y):
		unit = self.caster.level.get_unit_at(x, y)
		if not unit: return
		if self.get_stat('fatebound'): units = [u for u in self.caster.level.units if u.name == self.caster.level.get_unit_at(x, y).name and are_hostile(self.caster, u)]
		else: units = [unit]
		for unit in units:
			self.caster.level.show_path_effect(self.caster, unit, Tags.Dark, minor=True)
			unit.apply_buff(self.get_sealed_fate_buff(), self.get_stat('delay'))
		yield

	def get_description(self):
		return "After {delay} turns, deal [{damage}:damage] [Dark] damage to the target unit"

	def get_sealed_fate_buff(self):
		return SealedFateBuff(self)

	def get_extra_examine_tooltips(self):
		return [self.get_sealed_fate_buff()] + self.get_upgrade_tooltips()

	def get_impacted_tiles(self, x, y):
		if self.get_stat('fatebound'): return [u for u in self.caster.level.units if u.name == self.caster.level.get_unit_at(x, y).name and are_hostile(self.caster, u)]
		else: return Spell.get_impacted_tiles(self, x, y)

class Volcano(Spell):

	def on_init(self):
		self.name = "Volcanic Eruption"
		self.max_charges = 5
		self.radius = 3
		self.damage = 52
		self.damage_type = [Tags.Fire]

		self.cast_on_walls = True

		self.tags = [Tags.Fire, Tags.Nature, Tags.Sorcery]
		self.level = 4
		self.range = 10

		self.upgrades[('resist', 'duration')] = ([1, 4], 2, "Lava Coat", "Gain 100% [Fire] and [Physical] resist for [{duration}:duration] turns when you cast Volcanic Eruption")
		self.upgrades['requires_los'] = (-1, 2, "Blindcasting", "Volcanic Eruption can be cast outside your line of sight")
		self.upgrades['wall_cast']= (1, 4, "Wallcano", "In addition to chasms, Volcanic Eruption may target walls\nDoing so turns connected walls inside the initial burst into chasms")
		self.upgrades['shower'] = (1, 7, "Meteor Shower", "Casting Volcanic Eruption also casts a single turn of your Rain of Fire spell")

		self.add_upgrade_tooltip("Lava Coat", lambda: ResistBuff(Tags.Fire, 100), lambda: ResistBuff(Tags.Physical, 100))

	def get_description(self):
		return ("Create a [{radius}:radius] tile burst of lava in a chasm\n"
				"The burst flows up to [{radius}:radius] tiles out of the chasm\n"
				"The lava deals [{damage}:damage] [Fire] damage")

	def get_chasm_points(self, caster, x, y):
		chasm_points = {Point(x, y)}

		for i in range(self.get_stat('radius')):
			for point in list(chasm_points):
				for adj in self.caster.level.get_points_in_ball(point.x, point.y, 1):
					tile = self.caster.level.tiles[adj.x][adj.y]
					if tile.is_chasm or (tile.is_wall() and self.get_stat('wall_cast')):
						chasm_points.add(adj)

		return chasm_points

	def get_impacted_tiles(self, x, y):
		aoe = set(self.get_chasm_points(self.caster, x, y))
		for i in range(self.get_stat('radius')):
			for point in set(aoe):
				for adj in self.caster.level.get_points_in_ball(point.x, point.y, 1):
					if self.caster.level.tiles[adj.x][adj.y].can_see:
						aoe.add(adj)
		return aoe

	def cast(self, x, y):
		chasms = set(self.get_chasm_points(self.caster, x, y))
		dmg = self.get_stat('damage')
		level = self.caster.level

		wall_cast = self.get_stat('wall_cast')

		if self.get_stat('resist'):
			self.caster.apply_buff(ResistBuff(Tags.Fire, 100), self.get_stat('duration'))
			self.caster.apply_buff(ResistBuff(Tags.Physical, 100), self.get_stat('duration'))
			yield

		for point in chasms:
			level.set_group_tileset([point], 'volcano', 'lava')
			if wall_cast and level.tiles[point.x][point.y].is_wall(): level.make_chasm(point.x, point.y)
			level.deal_damage(point.x, point.y, dmg, Tags.Fire, self)

		yield

		for i in range(self.get_stat('radius')):
			for point in set(chasms):
				for adj in level.get_points_in_ball(point.x, point.y, 1):
					if level.tiles[adj.x][adj.y].can_see and adj not in chasms:
						level.deal_damage(adj.x, adj.y, dmg, Tags.Fire, self)
						level.set_group_tileset([adj], 'volcano', 'lava')
						chasms.add(adj)
			yield

		if self.get_stat('shower'):
			level.act_cast(self.caster, self.caster.get_or_make_spell(MeteorShower), x, y, pay_costs=False)

	def can_cast(self, x, y):
		tile = self.caster.level.tiles[x][y]
		if self.get_stat('wall_cast'):
			if not tile.is_chasm and not tile.is_wall(): return False
		else:
			if not tile.is_chasm: return False

		return Spell.can_cast(self, x, y)

class UnderworldPortal(Spell):

	def on_init(self):
		self.requires_los = False
		self.range = 99
		self.name = "Underworld Passage"
		self.max_charges = 6
		self.tags = [Tags.Dark, Tags.Sorcery, Tags.Translocation]
		self.level = 2

		self.upgrades['quick_cast'] = (1, 2, "Quickcast", "Underworld Passage gains quickcast")
		self.upgrades[('summon_rockworms', 'num_summons', 'minion_health', 'minion_damage')] = ([1, 2, 25, 7], 3, "Tremorsensitivity", "Summon [{num_summons}:num_summons] Rock Worms at your original and target locations", [Tags.Conjuration])
		self.upgrades['make_entrance'] = (1, 3, "Make Entrance", "You can cast this spell from any location\nCreate a chasm in the location you cast from")
		self.upgrades['drag'] = ([1, 2], 4, "Return to Hell", "[Demon] enemies adjacent to your original location are killed\n\nDoes not affect giant units")

		self.add_upgrade_tooltip("Tremorsensitivity", self.make_rockwurm)

	def get_description(self):
		return ("Teleport to any tile adjacent to a chasm\n"
				"Can only be cast while adjacent to a chasm")

	def can_cast(self, x, y):

		if not self.caster.level.can_stand(x, y, self.caster):
			return False

		locations = [self.caster, Point(x, y)]
		if self.get_stat('make_entrance'):
			locations = [Point(x, y)]

		for center in locations:
			next_to_chasm = False
			for p in self.caster.level.get_points_in_ball(center.x, center.y, 1.5, diag=True):
				if self.caster.level.tiles[p.x][p.y].is_chasm:
					next_to_chasm = True
					break
			if not next_to_chasm:
				return False
		return Spell.can_cast(self, x, y)

	def get_impacted_tiles(self, x, y):
		impacted = [Point(x, y)]
		if self.get_stat('drag'):
			enemies = [u for u in self.caster.level.get_adjacent_units(self.caster) if are_hostile(self.caster, u) and Tags.Demon in u.tags and not u.radius]
			impacted.extend(enemies)
		return impacted

	def make_rockwurm(self):
		u = RockWorm()
		apply_minion_bonuses(self, u)
		return u

	def cast_instant(self, x, y):
		caster = self.caster
		level = caster.level

		if not level.can_move(caster, x, y, teleport=True): return # do nothing if we are somehow casting where we shouldn't be able to a-la cantrip cascade
		old_loc = Point(caster.x, caster.y)

		if self.get_stat('drag'):
			enemies = [u for u in level.get_adjacent_units(caster) if are_hostile(caster, u) and Tags.Demon in u.tags and not u.radius]
			for e in enemies:
				level.show_effect(e.x, e.y, Tags.Translocation)
				e.kill()

		level.act_move(caster, x, y, teleport=True)

		if self.get_stat('make_entrance'): level.make_chasm(old_loc.x, old_loc.y)

		if self.get_stat('summon_rockworms'):
			for p in [old_loc, caster]:
				for i in range(self.get_stat('num_summons')):
					self.summon(self.make_rockwurm(), target=p)


class VampiricismBuff(Buff):

	def on_init(self):
		self.name = "Vampiricism"
		self.buff_type = BUFF_TYPE_BLESS
		self.color = Tags.Blood.color
		self.asset = ["status", "blood_tap"]
		self.global_triggers[EventOnDamaged] = self.on_damage
		self.description= "Heals the owner for any damage they deal\nGrants flying"

	def on_applied(self, owner):
		owner.flying += 1

	def on_unapplied(self):
		self.owner.flying -= 1

	def on_damage(self, evt):
		if not evt.source: return
		if not evt.source.owner: return
		if not evt.source.owner == self.owner: return
		if evt.damage <= 0: return
		self.owner.heal(evt.damage, evt.source)

class Vampiricism(Spell):

	def on_init(self):
		self.name = "Vampiricism"
		self.tags = [Tags.Blood, Tags.Enchantment]
		self.level = 3
		self.range = 1.5
		self.melee = True
		self.can_target_self = False
		self.can_target_empty = False
		self.hp_cost = 15

		self.upgrades['vampiric_regent'] = (1, 5, "Vampiric Regent", "Grant the target your Dominate spell on a 20 turn cool down")
		self.upgrades[('wicked_fangs', 'minion_damage')] = ([1, 7], 2, "Wicked Fangs", "The target's spells gain +[{minion_damage}:minion_damage] damage")
		self.upgrades['enthrall'] = (1, 5, "Enthrall", "You may cast this on [Living] enemies if you have more health than them\nIf you do, they become your ally")
		self.upgrades['quicken'] = (1, 3, "Quickening", "The target gains [quickstep:translocation], and their spells gain quick cast")

	def get_description(self):
		return "Grant an ally [vampiricism:blood], causing them to heal for any damage they deal, and allowing them to fly"

	def can_cast(self, x, y):
		if not Spell.can_cast(self, x, y): return False
		unit = self.caster.level.get_unit_at(x, y)
		if not unit: return False
		if unit.has_buff(VampiricismBuff): return False
		if are_hostile(self.caster, unit):
			if self.get_stat('enthrall'):
				if Tags.Living not in unit.tags: return False
				if unit.cur_hp > self.caster.cur_hp: return False
			else: return False
		return True

	def cast_instant(self, x, y):
		caster = self.caster

		u = caster.level.get_unit_at(x, y)
		if not u: return
		u.apply_buff(VampiricismBuff())
		caster.level.show_effect(x, y, Tags.Blood)

		if self.get_stat('vampiric_regent'): grant_minion_spell(Dominate, u, caster, cool_down=20)
		if self.get_stat('enthrall'):
			if u.team != caster.team:
				u.team = caster.team
		if self.get_stat('wicked_fangs'):
			damage_bonus = self.get_stat('minion_damage')
			for spell in u.spells:
				if hasattr(spell, 'damage') and spell.damage:
					spell.damage += damage_bonus
		if self.get_stat('quicken'):
			u.apply_buff(QuickmoveBuff())
			for spell in u.spells: spell.quick_cast = True


class SummonEarthElemental(Spell):

	def on_init(self):
		self.tags = [Tags.Nature, Tags.Conjuration]
		self.name = "Earthen Sentinel"
		self.max_charges = 3
		self.level = 3
		self.minion_damage = 20
		self.minion_health = 120

		self.upgrades[('mobile', 'radius')] = ([1, 3], 1, "Mobile Menhir", "Earth Elementals have a 33% chance to randomly teleport to a location within [{radius}:radius] tiles that they can see each turn")
		self.upgrades['stinging_totem'] = (1, 4, "Stinging Totem", "Earth Elementals can cast your Poison Sting with no cooldown")
		self.upgrades['holy_totem'] = (1, 6, "Holy Totem", "Earth Elementals can cast your Heavenly Blast on a 3 turn cooldown", [Tags.Holy])
		self.upgrades[('earth_shaper', 'num_summons', 'cast_on_walls')] = ([1, 2, 1], 8, "Earth Shaper", "You can cast this spell targeting a wall\nIf you do, that wall and up to [{num_summons}:num_summons] adjacent walls are transformed into Earth Elementals")

	def can_cast(self, x, y):
		tile = self.caster.level.tiles[x][y]
		if self.get_stat('cast_on_walls') and tile.is_wall(): return Spell.can_cast(self, x, y)
		return tile.unit is None and tile.can_walk and Spell.can_cast(self, x, y)

	def get_impacted_tiles(self, x, y):
		target = Point(x, y)
		level = self.caster.level
		if not self.get_stat('earth_shaper') or level.tiles[x][y].can_walk : return [target]
		adj_tiles = [level.tiles[p.x][p.y] for p in level.get_adjacent_points(target, filter_walkable=False)]
		legal_targets = [t for t in adj_tiles if t.is_wall() and not t.unit]
		if not legal_targets: return [target]
		num = min(len(legal_targets), self.get_stat('num_summons'))
		candidates = set(legal_targets)
		targets = []
		while candidates and len(targets) < num: targets.append(candidates.pop())
		targets.append(target)
		return targets

	def cast(self, x, y):
		shaper = self.get_stat('earth_shaper')
		level = self.caster.level
		tiles = level.tiles
		for t in self.get_impacted_tiles(x, y):
			if shaper and tiles[t.x][t.y].is_wall(): level.make_floor(t.x, t.y)
			self.summon(self.get_ele(), target=t)
			yield

	def get_ele(self):
		ele = make_minion(self, EarthElemental)
		if self.get_stat('stinging_totem'): grant_minion_spell(PoisonSting, ele, self.caster, cool_down=0, pre_insert=False)
		if self.get_stat('holy_totem'): grant_minion_spell(HolyBlast, ele, self.caster, cool_down=3)
		if self.get_stat('mobile'): ele.apply_buff(TeleportyBuff(radius=self.get_stat('radius'), chance=.33, hop=True))
		return ele

	def get_description(self):
		return "Summon an Earth Elemental"

	def get_extra_examine_tooltips(self):
		return [self.get_ele()] + self.get_upgrade_tooltips()

class HauntedBuff(Buff):

	def __init__(self, spell):
		Buff.__init__(self)
		self.spell = spell
		self.num_summons = self.spell.get_stat('num_summons') if spell.caster else 3
		self.color = Tags.Dark.color

	def on_init(self):
		self.name = "Haunted"
		self.color = Tags.Dark.color
		self.buff_type = BUFF_TYPE_CURSE
		self.stack_type = STACK_DURATION

	def get_description(self):
		return "Summon Ghosts nearby each turn"

	def on_advance(self):
		for _ in range(self.num_summons): self.spell.summon(make_minion(self.spell, Ghost), self.owner)

class Ghostball(Spell):

	def on_init(self):
		self.tags = [Tags.Dark, Tags.Conjuration, Tags.Sorcery]
		self.name = "Ghostball"
		self.level = 3
		self.max_charges = 6

		self.radius = 1
		self.minion_damage = 1
		self.minion_health = 4
		self.minion_duration = 10

		self.damage = 10
		self.damage_type = [Tags.Dark]

		self.upgrades[('haunted', 'num_summons', 'duration')] = ([1, 3, 3], 2, "Haunting", "Curse affected enemies with [haunted:dark], which summons [{num_summons}:num_summons] Ghosts near them each turn\nLasts for [{duration}:duration] turns", [Tags.Enchantment])
		self.upgrades['memorial'] = (1, 5, "Memorialize", "If Ghostball targets an enemy and kills it, raise a Tombstone at their location")
		self.upgrades[('ignis', 'duration')] = ([1, 3], 6, "Ignis Fatuus", "Ghostball also inflicts [Fire] damage and [{duration}:duration] turns of [berserk]", [Tags.Fire], [Tags.Fire])
		self.upgrades['mass'] = (1, 9, "Ghost Mass", "Summon Ghostly Masses instead of Ghosts")

		self.add_upgrade_tooltip("Haunting", self.get_haunted_buff)
		self.add_upgrade_tooltip("Memorialize", self.get_tombstone)
		self.add_upgrade_tooltip("Ghost Mass", lambda: make_minion(self, GhostMass))

	def get_ai_target(self):
		targets = [p for p in self.owner.level.get_points_in_ball(self.owner.x, self.owner.y, self.get_stat('range')) if self.can_cast(p.x, p.y)]
		empty_targets = [p for p in targets if not self.owner.level.get_unit_at(p.x, p.y)]
		if empty_targets: return random.choice(empty_targets)
		elif targets: return random.choice(targets)

	def get_haunted_buff(self):
		return HauntedBuff(self)

	def cast_instant(self, x, y):
		caster = self.caster
		level = caster.level
		damage = self.get_stat('damage')
		dtypes = self.get_stat('damage_type')

		mass = self.get_stat('mass')
		ghost_constructor = GhostMass if mass else Ghost

		haunt = self.get_stat('haunted')
		ignis = self.get_stat('ignis')
		dur = self.get_stat('duration')

		memorial = self.get_stat('memorial')
		target_unit = level.get_unit_at(x, y)

		points = level.get_points_in_ball(x, y, self.get_stat('radius'))
		for point in points:
			unit = level.tiles[point.x][point.y].unit
			if unit is None and level.tiles[point.x][point.y].can_see: self.summon(make_minion(self, ghost_constructor), point); continue
			elif unit is None: continue
			elif unit and not are_hostile(unit, caster): continue
			for dtype in dtypes: level.deal_damage(point.x, point.y, damage, dtype, self)
			if not unit.is_alive(): continue
			if haunt: unit.apply_buff(HauntedBuff(self), dur)
			if ignis: unit.apply_buff(BerserkBuff(), 3)


		if memorial and target_unit and are_hostile(caster, target_unit) and not target_unit.is_alive():
			tombstone = make_minion(self, Tombstone)
			tombstone.turns_to_death = None
			self.summon(tombstone, target_unit)

	def get_description(self):
		return ("Deal [{damage}:damage] [Dark] damage to enemies in a [{radius}:radius] tile burst\n"
				"Summon temporary Ghosts in affected empty tiles")

	def get_impacted_tiles(self, x, y):
		return [p for p in self.caster.level.get_points_in_ball(x, y, self.get_stat('radius'))]

	def get_tombstone(self):
		u = make_minion(self, Tombstone)
		u.turns_to_death = None
		return u

	def get_extra_examine_tooltips(self):
		return [make_minion(self, Ghost)] + self.get_upgrade_tooltips()


class PermenanceBuff(Buff):

	def __init__(self, spell):
		Buff.__init__(self)
		self.spell = spell
		self.solidify = spell.get_stat('solidify')
		self.immutable = spell.get_stat('immutable')
		if self.immutable: self.owner_triggers[EventOnDamaged] = self.on_damaged

	def on_init(self):
		self.global_bonuses['minion_duration'] = 5
		self.global_bonuses['duration'] = 5
		self.name = "Permanence"
		self.color = Tags.Enchantment.color
		self.buff_type = BUFF_TYPE_BLESS
		self.asset = ['status', 'permenance']
		self.stack_type = STACK_REPLACE

	def get_description(self):
		if not self.immutable: return ''
		return "Heal for half of all damage dealt to you"

	def on_applied(self, owner):
		if not self.solidify: return
		temp_allies = [u for u in owner.level.units if not are_hostile(owner, u) and u.turns_to_death]
		for u in temp_allies: u.turns_to_death = None

	def on_damaged(self, evt):
		if evt.damage > 0: evt.unit.heal(evt.damage//2, self.spell)


class Permanence(Spell):

	def on_init(self):
		self.max_charges = 4
		self.duration = 20
		self.name = "Permanence"
		self.tags = [Tags.Enchantment]
		self.level = 4
		self.range = 0

		self.upgrades['true_permanence'] = (1, 3, "True Permanence", "Permanence duration is now permanent")
		self.upgrades['solidify'] = (1, 4, "Reality Hold", "On cast, temporary allies become permanent")
		self.upgrades[('hp_cost', 'immutable')] = ([15, 1], 4, "Immutable Flesh", "You heal for half of all damage dealt to you",[Tags.Blood])
		self.upgrades['reinforce'] = (1, 6, "Temporal Reinforcement", "On cast, double the remaining duration of your other temporary buffs")


	def cast_instant(self, x, y):
		if self.get_stat('reinforce'):
			tb = [b for b in self.caster.buffs if b.buff_type != BUFF_TYPE_CURSE and b.turns_left > 0]
			for b in tb: b.turns_left *= 2
		if self.get_stat('true_permanence'): self.caster.apply_buff(PermenanceBuff(self))
		else: self.caster.apply_buff(PermenanceBuff(self), self.get_stat('duration'))

	def get_description(self):
		return ("All spells and equipment gain [5 minion duration:minion_duration]\n"
				"All spells and equipment gain [5 duration:duration]\n"
				"Lasts [{duration}:duration] turns")

	def get_extra_examine_tooltips(self):
		return [PermenanceBuff(self)] + self.get_upgrade_tooltips()

class VampiricGazeSpell(Spell):

	def on_init(self):
		self.name = "Vampiric Gaze"
		self.range = 0
		self.tags = [Tags.Dark, Tags.Blood, Tags.Sorcery, Tags.Eye]
		self.level = 4
		self.max_charges = 8
		self.damage = 6
		self.hp_cost = 10

		self.upgrades['toxic_gaze'] = (1, 3, "Toxic Gaze", "Vampiric Gaze also deals [Poison] damage", [Tags.Nature])
		self.upgrades['vampire_tax'] = (1, 5, "Vampiric Tax", "Vampiric Gaze heals you for any damage it deals")
		self.upgrades['refract'] = (1, 6, "Refracting Gaze", "Each bolt bounces once to an enemy in line of sight of its target")
		self.upgrades[('coagulation', 'minion_health', 'minion_damage', 'minion_range')] = ([1, 10, 3, 3], 4, "Coagulation", "Summon a Blood Slime when Vampiric Gaze kills a unit", [Tags.Slime])

		self.add_upgrade_tooltip("Coagulation", self.make_slime)

	def get_impacted_tiles(self, x, y):
		for u in self.caster.level.units:
			if are_friendly(self.caster, u):
				if u == self.caster: continue
				yield u

	def get_description(self):
		return ("A bolt of darkness shoots forth from each of your allies at a random enemy in their line of sight\n"
				"Each bolt deals [{damage}:damage] [Dark] damage\n"
				"Allies are healed for the damage dealt by their corresponding bolt")


	def make_slime(self):
		u = BloodSlime()
		apply_minion_bonuses(self, u)
		u.buffs[0].spawner = lambda: self.make_slime()
		return u

	def cast(self, x, y):
		bolts = []
		for unit in self.caster.level.units:
			if unit == self.caster or self.caster.level.are_hostile(self.caster, unit): continue
			possible_targets = [u for u in self.caster.level.units if self.caster.level.are_hostile(unit, u) and self.caster.level.can_see(unit.x, unit.y, u.x, u.y)]
			if possible_targets:
				target = random.choice(possible_targets)
				bolts.append(self.bolt(unit, target))

		while bolts:
			bolts = [b for b in bolts if next(b)]
			yield

	def bolt(self, source, target, bounce_origin=None):

		disp_tag = Tags.Dark
		bolt_start = bounce_origin if bounce_origin else source
		for point in Bolt(self.caster.level, bolt_start, target):
			self.caster.level.show_effect(point.x, point.y, disp_tag)
			if self.get_stat('toxic_gaze'):
				if disp_tag == Tags.Dark: disp_tag = Tags.Poison
				else: disp_tag = Tags.Dark
			yield True

		damage = self.get_stat('damage')
		dealt = target.deal_damage(damage, Tags.Dark, self)
		if self.get_stat('toxic_gaze'): dealt += target.deal_damage(damage, Tags.Poison, self)

		if dealt:
			source.heal(dealt, self) # Heal the unit
			if self.get_stat('vampire_tax'): self.caster.heal(dealt, self) # Heal the caster if upgraded
			if not target.is_alive() and self.get_stat('coagulation'): self.summon(self.make_slime(), target=target)

		if (bounce_origin is None) and self.get_stat('refract'):
			possible_targets = [u for u in self.caster.level.units if self.caster.level.are_hostile(self.owner, u) and self.caster.level.can_see(target.x, target.y, u.x, u.y)]
			if possible_targets:
				new_target = random.choice(possible_targets)
				bolt = self.bolt(source, new_target, bounce_origin=target)
				while next(bolt): yield True

		yield False

class BoneBarrageSpell(Spell):

	def on_init(self):
		self.name = "Bone Barrage"
		self.range = 14
		self.tags = [Tags.Dark, Tags.Sorcery]
		self.level = 4
		self.max_charges = 7
		self.can_target_empty = False
		self.damage_type = [Tags.Physical]

		self.upgrades['beam'] = (1, 2, "Bone Spears", "Bone Barrage damages units in a beam from each of your affected allies to the target")
		self.upgrades['conduction'] = (1, 1, "Marrow Conduction", "Bones pulled from [Lightning] allies also deal [Lightning] damage", [Tags.Lightning], [Tags.Lightning])
		self.upgrades['pistons'] = (1, 2, "Piston Spears", "Damage dealt by [Metallic] allies' bones is multiplied by 4", [Tags.Metallic])
		self.upgrades['dark'] = (1, 5, "Cursed Bones", "Bone Barrage also deals [Dark] damage", None, [Tags.Dark])

	def get_description(self):
		return ("Your allies in line of sight of the target take [Physical] damage equal to half their health\n"
				"Each affected ally deals that much [Physical] damage to the target")

	def get_impacted_tiles(self, x, y):
		start = Point(x, y)
		yield start
		for u in self.caster.level.get_units_in_los(start):
			if not are_hostile(u, self.caster) and u != self.caster:
				yield u
				if self.get_stat('beam'):
					for p in self.caster.level.get_points_in_line(u, Point(x, y), find_clear=True):
						yield p

	def cast(self, x, y):
		bolts = []
		target = Point(x, y)

		pistons = self.get_stat('pistons')
		beam = self.get_stat('beam')
		conduction = self.get_stat('conduction')
		dark = self.get_stat('dark')

		for u in self.caster.level.get_units_in_los(target):
			if u == self.caster: continue
			if are_hostile(u, self.caster): continue
			if u.resists[Tags.Physical] >= 100: continue

			damage = u.deal_damage((u.cur_hp + 1) // 2, Tags.Physical, self)
			if damage > 0 and pistons and Tags.Metallic in u.tags: damage *= 4
			if damage > 0:
				dtags = [Tags.Physical]
				if conduction and Tags.Lightning in u.tags: dtags.append(Tags.Lightning)
				if dark: dtags.append(Tags.Dark)
				bolts.append(self.bolt(u, target, damage, dtags, beam))

		while bolts:
			bolts = [b for b in bolts if next(b)]
			yield

	def bolt(self, source, target, damage, dtags, beam):

		for point in Bolt(self.caster.level, source, target):

			self.caster.level.projectile_effect(point.x, point.y, proj_name='bone_spear', proj_origin=source, proj_dest=target)
			yield True

			unit = self.caster.level.get_unit_at(point.x, point.y)
			if beam and unit:
				for dtype in dtags:
					unit.deal_damage(damage, dtype, self)

		unit = self.caster.level.get_unit_at(target.x, target.y)
		if unit:
			for dtype in dtags:
				unit.deal_damage(damage, dtype, self)

		yield False

class SavageSpree(Upgrade):

	def on_init(self):
		self.level = 9
		self.name = "Savage Spree"
		self.description = "When your allies kill a unit, cast Invoke Savagery\nAlways Active"
		self.global_triggers[EventOnDeath] = self.on_death

	def on_death(self, evt):
		if not evt.damage_event: return
		if not evt.damage_event.source: return
		if not evt.damage_event.source.owner: return
		u = evt.damage_event.source.owner
		if u == self.owner: return
		if not are_hostile(self.owner, u):
			spell = self.owner.get_or_make_spell(InvokeSavagerySpell)
			self.owner.level.act_cast(self.owner, spell, self.owner.x, self.owner.y, pay_costs=False)

class InvokeSavagerySpell(Spell):

	def on_init(self):
		self.name = "Invoke Savagery"
		self.range = 0
		self.tags = [Tags.Nature, Tags.Sorcery]
		self.level = 2
		self.max_charges = 6
		self.damage = 18
		self.duration = 2

		self.kills = 0
		self.targets = []

		self.upgrades['poison'] = (1, 1, "Venomous Bite", "The attack also permanently [poisons] the target")
		self.upgrades['nature'] = (1, 3, "Nature's Wrath", "Invoke Savagery also affects your [Nature] allies")
		self.upgrades[('leap_attack', 'radius')] = ([1, 3], 6, "Savage Leap", "Instead of a melee attack, allies do a leap attack with a range of [{radius}:radius]")
		self.add_upgrade(SavageSpree())

	def get_impacted_tiles(self, x, y):
		return [u for u in self.caster.level.units if u != self.caster and not are_hostile(u, self.caster) and (Tags.Living in u.tags or (self.get_stat('nature') and Tags.Nature in u.tags))]

	def cast(self, x, y):
		self.targets = []
		if self.get_stat('leap_attack'): attack = LeapAttack(damage=self.get_stat('damage'), range=self.get_stat('radius'), buff=Stun, buff_duration=self.get_stat('duration'))
		else: attack = SimpleMeleeAttack(damage=self.get_stat('damage'), buff=Stun, buff_duration=self.get_stat('duration'))
		poison = self.get_stat('poison')

		caster = self.caster
		level = caster.level
		candidate_targets = [u for u in level.units if are_hostile(u, caster)]

		for unit in self.get_impacted_tiles(x, y):
			candidate_targets = [u for u in candidate_targets if u.is_alive() and are_hostile(caster, u)]
			if not candidate_targets: return
			possible_targets = []
			for target in candidate_targets:
				if abs(target.x - unit.x) > attack.range + target.radius: continue
				if abs(target.y - unit.y) > attack.range + target.radius: continue
				if level.unit_distance(unit, target, diag=True) <= attack.range: possible_targets.append(target)
			if possible_targets:
				target = random.choice(possible_targets)
				attack.statholder = unit
				attack.caster = unit
				attack.owner = unit
				for _ in self.caster.level.act_cast(unit, attack, target.x, target.y, pay_costs=False, queue=False): pass
				if poison: target.apply_buff(Poison())
				yield


	def get_description(self):
		return ("Your [Living] allies attack a random enemy in melee range\n"
				"The attack inflicts [{damage}:damage] [Physical] damage and [{duration}:duration] turns of [stun]")

class MagicMissile(Spell):

	def on_init(self):
		self.name = "Magic Missile"
		self.range = 9
		self.tags = [Tags.Arcane, Tags.Sorcery]
		self.level = 1

		self.damage = 11
		self.damage_type = [Tags.Arcane]

		self.max_charges = 20
		self.shield_burn = 0

		self.upgrades['shield_burn'] = (1, 2, "Shield Burn", "Magic Missile removes all [SH:shields] from the target before dealing damage")
		self.upgrades['disruption'] = (1, 3, "Disruption Bolt", "If Magic Missile targets an [Arcane] unit, it deals [Dark] and [Holy] damage instead of [Arcane]", None, [Tags.Dark, Tags.Holy])
		self.upgrades[('barrage', 'num_targets')] = ([1, 3], 1, "Arcane Crossfire", "When you manually cast Magic Missile, up to [{num_targets}:num_targets] additional missiles are fired by [Arcane] allies in line of sight of the target")
		self.upgrades[('ricochet', 'num_targets')] = ([1, 2], 5, "Ricochet", "Magic Missile bounces up to [{num_targets}:num_targets] times to targets in range and line of sight of the target")

	def cast(self, x, y):
		dtypes = [Tags.Arcane]

		caster = self.caster
		level = caster.level

		dmg = self.get_stat('damage')
		r = self.get_stat('range')
		num_targets = self.get_stat('num_targets')
		shield_burn = self.get_stat('shield_burn')
		disruption = self.get_stat('disruption')

		bolts = [(caster, Point(x, y))]

		if self.get_stat('barrage') and self.is_manual_cast():
			candidates = [u for u in level.get_units_in_los(Point(x, y))]
			candidates = [c for c in candidates if Tags.Arcane in c.tags and not are_hostile(caster, c)]

			random.shuffle(candidates)

			for c in candidates[:num_targets]:
				s = c.get_or_make_spell(MagicMissile)
				s.statholder = caster
				s.caster = c
				self.caster.level.act_cast(c, s, x, y, pay_costs=False, queue=True)

		if self.get_stat('ricochet'):
			prev_target = Point(x, y)
			targets = [level.get_unit_at(x, y)] # make a list of them so no repeats
			for _ in range(num_targets):
				candidates = [u for u in level.get_units_in_los(prev_target)  # in los
							  if are_hostile(caster, u)  # are hostile
							  and level.unit_distance(u, prev_target) < r
							  and u not in targets] # in range and not the target itself or a previous target
				if not candidates:
					break

				next_target_unit = min(candidates, key=lambda u: level.unit_distance(prev_target, u)) # hit the closest candidate
				targets.append(next_target_unit) # add them to the list so they don't get hit again
				next_target = Point(next_target_unit.x, next_target_unit.y)
				bolts.append((prev_target, next_target))
				prev_target = next_target

		for origin, target in bolts:
			level.show_beam(origin, target, Tags.Arcane)

			unit = level.get_unit_at(target.x, target.y)

			if unit:
				if shield_burn: unit.shields = 0
				dtypes = [Tags.Holy, Tags.Dark] if disruption and Tags.Arcane in unit.tags else [Tags.Arcane]

			for dtype in dtypes:
				level.deal_damage(target.x, target.y, dmg, dtype, self)
				if len(dtypes)> 1:
					for i in range(3): yield

			yield

	def get_description(self):
		return "Deal [{damage}:damage] [Arcane] damage to the target"

class DevourMind(Spell):

	def on_init(self):
		self.name = "Devour Mind"
		self.range = 3
		self.tags = [Tags.Arcane, Tags.Conjuration, Tags.Dark, Tags.Sorcery]
		self.damage_type = [Tags.Arcane, Tags.Dark]
		self.max_charges = 7
		self.level = 3
		self.damage = 24

		self.minion_damage = 5

		self.requires_los = False

		self.upgrades['horde_mode'] = (1, 7, "Horde Mode", "Zombies raised by this spell can cast it on a 9 turn cooldown")
		self.upgrades['drain'] = (1, 2, "Arcane Drain", "If Devour Mind kills the target, regain a charge of a random [Arcane] spell")
		self.upgrades[('hp_cost', 'gluttony')] = ([8, 1], 3, "Gluttony", "If Devour Mind kills the target, heal for half the target's max HP", [Tags.Blood])
		self.upgrades[('brain_freeze', 'duration')] = ([1, 3], 4, "Brain Freeze", "Devour Mind also deals [Ice] damage\n"
															   "If the target lives, they are [frozen] for [{duration}:duration] turns\n"
															   "Additionally, each of their spells gains +[{duration}:duration] cooldown", [Tags.Ice], [Tags.Ice])

	def get_description(self):
		return ("Deal [{damage}:damage] [Arcane] and [Dark] damage to an enemy\n"
				"Then, if the target is below 50% HP, deal that damage again\n"
				"If this kills the target, they are raised as a Zombie\n"
				"Can only target [Living], [Demon], and [Arcane] enemies")

	def get_extra_examine_tooltips(self):
		return [self.make_zombie()] + self.get_upgrade_tooltips()

	def can_cast(self, x, y):
		unit = self.caster.level.get_unit_at(x, y)
		if not unit: return False
		if not are_hostile(self.caster, unit): return False
		legal_tags = [Tags.Living, Tags.Demon, Tags.Arcane]
		for tag in legal_tags:
			if tag in unit.tags:
				return Spell.can_cast(self, x, y)

		return False

	def cast(self, x, y):
		caster = self.caster
		level = caster.level

		dmg = self.get_stat('damage')
		dtypes = self.get_stat('damage_type')


		unit = level.get_unit_at(x, y)
		if not unit: return

		for dtype in dtypes:
			level.deal_damage(x, y, dmg, dtype, self)
			yield

		if unit.cur_hp / unit.max_hp < .5:
			for i in range(3): yield
			for dtype in dtypes:
				level.deal_damage(x, y, dmg, dtype, self)
				yield

		if not unit.is_alive():
			self.caster.level.queue_spell(self.do_summon(unit))
			if self.get_stat('drain'):
				candidates = [s for s in caster.spells if Tags.Arcane in s.tags and s.cur_charges < s.get_stat('max_charges')]
				if candidates: random.choice(candidates).refund_charges(1)
			if self.get_stat('gluttony'): caster.heal(unit.max_hp//2, self)

		elif self.get_stat('brain_freeze'):
			dur = self.get_stat('duration')
			unit.apply_buff(FrozenBuff(), dur)
			for s in unit.spells: s.cool_down += dur

	def do_summon(self, unit):
		self.summon(self.make_zombie(unit), target=unit)
		yield

	def make_zombie(self, unit=None):
		u = Zombie()
		apply_minion_bonuses(self, u)

		if unit: u.max_hp = unit.max_hp
		else: u.max_hp = 0

		if self.get_stat('horde_mode'):
			if self.owner.is_player_controlled: wizard = self.owner
			else: wizard = getattr(self.owner, 'wizard', self.owner)  # fallback to owner itself if something went wrong
			u.wizard = wizard  # store wizard ref on the unit so when they pass the spell off in chains, they can refer to the wizard quickly
			grant_minion_spell(DevourMind, u, wizard, cool_down=9, pre_insert=True)

		return u


class DeathShock(Spell):

	def on_init(self):
		self.name = "Death Shock"
		self.range = 6
		self.tags = [Tags.Sorcery, Tags.Dark, Tags.Lightning]
		self.damage_type = [Tags.Dark, Tags.Lightning]
		self.max_charges = 6
		self.level = 5
		self.damage = 17

		self.can_target_empty = False

		self.upgrades['fire'] = (1, 4, 'Fire Shock', "Death Shock also deals [Fire] damage", [Tags.Fire], [Tags.Fire])
		self.upgrades['shield_burn'] = (1, 2, 'Shield Burn', "Before dealing damage, removes all [SH:shields]")
		self.upgrades['momentum'] = (1, 6, 'Shocking Momentum', 'When Death Shock kills its target, its damage increases by 25% before moving to its next target')
		self.upgrades[('corpse', 'minion_damage', 'minion_range')] = ([1, 12, 4], 3, 'Corpse Construct', "If Death Shock kills one or more units, summon a Corpse Construct that inherits the combined HP of the slain units", [Tags.Conjuration])

		self.add_upgrade_tooltip("Corpse Construct", self.make_construct)

	def get_description(self):
		return ("Deal [{damage}:damage] [Lightning] and [Dark] damage to the target\n"
				"If the target is slain, this effect bounces to another enemy within range of the slain unit")

	def make_construct(self, hp=0):
		unit = Unit()
		unit.name = "Corpse Construct"
		unit.tags = [Tags.Undead, Tags.Lightning]
		dmg = self.get_stat('minion_damage')
		unit.max_hp = hp
		leap = LeapAttack(dmg, self.get_stat('minion_range'), Tags.Lightning)
		melee = SimpleMeleeAttack(dmg, attacks=2)
		unit.spells = [melee, leap]
		unit.buffs = [QuickmoveBuff()]
		return unit


	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		deal_damage = level.deal_damage
		get_ball = level.get_units_in_ball

		unit = level.get_unit_at(x, y)

		first_time = True
		targets_hit = 0
		delay = 5
		dtypes = self.get_stat('damage_type')
		dmg = self.get_stat('damage')
		cascade_range = self.get_stat('range')

		momentum = self.get_stat('momentum')
		shield_burn = self.get_stat('shield_burn')


		killed_hp = 0
		summon_loc = None


		while unit or first_time:
			if unit and shield_burn: unit.shields = 0
			for dtype in dtypes:
				target_point = Point(x, y) if first_time else unit
				deal_damage(target_point.x, target_point.y, dmg, dtype, self)
				for i in range(delay): yield

			if unit and unit.cur_hp <= 0:
				killed_hp += unit.max_hp
				summon_loc = unit
				candidates = [u for u in get_ball(unit, cascade_range) if are_hostile(caster, u)]
				if candidates:
					unit = random.choice(candidates)
					if momentum: dmg = math.ceil(dmg*1.25)
				else: unit = None
			else: unit = None

			# Speed up near the end to prevent waiting
			targets_hit += 1
			if targets_hit > 3: delay = max(2, delay - targets_hit // 4)
			if targets_hit > 100: delay = 1
			first_time = False

		if self.get_stat('corpse') and killed_hp: level.queue_spell(self.do_summon(killed_hp, summon_loc))


	def do_summon(self, hp, target):
		self.summon(self.make_construct(hp), target=target)
		yield

class MeltBuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)

	def on_init(self):
		self.resists[Tags.Physical] = -100
		self.stack_type = STACK_DURATION
		self.color = Tags.Fire.color
		self.name = "Melted Armor"
		self.buff_type = BUFF_TYPE_CURSE

class MeltFlame(Upgrade):

	def on_init(self):
		self.level = 5
		self.name = "White Flame"
		self.description = "When you cast a [Fire] or [Chaos] spell other than Melt targeting an enemy, Melt is also cast at the target\nAlways Active"
		self.owner_triggers[EventOnSpellCast] = self.on_cast

	def on_cast(self, evt):
		if Tags.Fire not in evt.spell.tags and Tags.Chaos not in evt.spell.tags: return
		if isinstance(evt.spell, MeltSpell): return
		unit = self.owner.level.get_unit_at(evt.x, evt.y)
		if not unit: return
		if are_friendly(self.owner, unit): return
		spell = self.owner.get_or_make_spell(MeltSpell)
		self.owner.level.defer_cast(self.owner, spell, evt.x, evt.y, pay_costs=False)

class MeltingPoint(Upgrade):

	def __init__(self, spell):
		self.spell = spell
		Upgrade.__init__(self, spell)

	def on_init(self):
		self.level = 3
		self.name = "Melting Point"
		self.description = "If you end your turn in range of a [frozen] or soaked enemy, cast Melt on them"

	def on_advance(self):
		targets = [u for u in self.owner.level.get_units_in_ball(self.owner, self.spell.get_stat('range')) if (u.has_buff(FrozenBuff) or u.has_buff(SoakedBuff)) and are_hostile(self.owner, u)]
		for t in targets:
			self.owner.level.act_cast(self.owner, self.spell, t.x, t.y, pay_costs=False)

class MeltSpell(Spell):

	def on_init(self):
		self.tags = [Tags.Fire, Tags.Sorcery]
		self.level = 2
		self.max_charges = 14
		self.name = "Melt"
		self.damage = 22
		self.damage_type = [Tags.Fire]
		self.range = 5
		self.duration = 3

		self.can_target_empty = False

		self.upgrades[('plasmify', 'minion_health', 'minion_damage', 'minion_range')] = ([1, 10, 3, 3], 3, "Plasmify", "Summon 2 Red Slimes when Melt kills its target", [Tags.Slime])
		self.upgrades[('mass_melt', 'num_targets')] = ([1, 6], 3, "Mass Melt", "Melt affects up to [{num_targets}:num_targets] enemies in a connected group")
		self.add_upgrade(MeltingPoint(self))
		self.add_upgrade(MeltFlame())
		self.add_upgrade_tooltip("Plasmify", self.make_slime)


	def get_impacted_tiles(self, x, y):
		targets = []

		if self.get_stat('mass_melt'):
			connected_group = self.caster.level.get_connected_group_from_point(x, y, check_hostile=self.caster, num_targets=self.get_stat('num_targets'))
			for target in connected_group:
				targets.append(target)
		else:
			unit = self.caster.level.get_unit_at(x, y)
			if unit: targets.append(unit)

		return targets

	def cast_instant(self, x, y):

		targets = self.get_impacted_tiles(x, y)

		for target in targets:
			self.caster.level.deal_damage(target.x, target.y, self.get_stat('damage'), self.damage_type[0], self)
			if target.is_alive():
					target.apply_buff(MeltBuff(self), self.get_stat('duration'))
			elif self.get_stat('plasmify'):
				for _ in range(2):
					self.summon(self.make_slime(), target)

	def make_slime(self):
		u = RedSlime()
		apply_minion_bonuses(self, u)
		u.buffs[0].spawner = lambda: self.make_slime()
		return u

	def get_description(self):
		return "Target takes [{damage}:damage] [Fire] damage and loses [100 Physical:physical] resist"

	def get_extra_examine_tooltips(self):
		return [MeltBuff(self)] + self.get_upgrade_tooltips()

class IronSkinBuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)
		self.name = "Ironized"
		self.buff_type = BUFF_TYPE_BLESS
		self.color = Tags.Metallic.color
		self.asset = ['status', 'protection']

	def on_init(self):
		self.resist = self.spell.get_stat('resist')
		self.resist_arcane = self.spell.get_stat('resist_arcane')
		for tag in [Tags.Physical, Tags.Fire, Tags.Lightning]:
			self.resists[tag] = self.resist
		if self.resist_arcane:
			self.resists[Tags.Arcane] = self.resist

	def get_description(self):
		desc = "Gain [{resist} Physical:physical], [{resist} Fire:fire], and [{resist} Lightning:lightning] resist\nBecome [Metallic]"
		if self.resist_arcane: desc = "Gain [{resist} Physical:physical], [{resist} Fire:fire], [{resist} Lightning:lightning], and [{resist} Arcane:arcane] resist\nBecome [Metallic]"
		return (desc, {'resist': self.resist})

	def on_applied(self, owner):
		if Tags.Metallic not in self.owner.tags:
			self.nonmetal = True
			self.owner.tags.append(Tags.Metallic)
		else:
			self.nonmetal = False

	def on_unapplied(self):
		if self.nonmetal:
			self.owner.tags.remove(Tags.Metallic)

class Ironize(Spell):

	def on_init(self):
		self.name = "Ironize"
		self.resist = 50
		self.stats.append('resist')
		self.duration = 10
		self.max_charges = 4
		self.level = 3

		self.tags = [Tags.Enchantment, Tags.Conjuration, Tags.Metallic]
		self.range = 0
		self.resist_arcane = 0

		self.upgrades['armor_plating'] = (1, 2, "Armor Plating", "Ironize also grants allies [2 SH:shields]")
		self.upgrades['permanence'] = (1, 3, "Permanent Transmutation", "Ironize gains a permanent duration")
		self.upgrades['resist_arcane'] = (1, 1, "Arcane Insulation", "Ironize also grants [50 Arcane:arcane] resist", [Tags.Arcane])
		self.upgrades['thorns'] = (1, 3, "Jagged Armor", "Ironized allies also gain the Jagged Armor buff, which inflicts [{duration}:duration] turns of [bleed] on melee attackers", None, None, {'duration':3})

		self.add_upgrade_tooltip("Jagged Armor", self.get_jagged_armor)

	def get_extra_examine_tooltips(self):
		return [IronSkinBuff(self)] + self.get_upgrade_tooltips()

	def get_jagged_armor(self):
		b = CurseRetaliation(name="Jagged Armor", buff=BleedBuff, buff_dur=self.get_stat('duration', base=3), color_tag=Tags.Metallic, melee=True)
		return b

	def cast_instant(self, x, y):
		caster =  self.caster
		lvl = caster.level
		perm = self.get_stat('permanence')
		shield = self.get_stat('armor_plating')
		thorns = self.get_stat('thorns')
		dur = 0 if perm else self.get_stat('duration')

		allies = [u for u in lvl.units if not are_hostile(u, caster) and u != caster]
		for unit in allies:
			unit.apply_buff(IronSkinBuff(self), dur)
			if thorns: unit.apply_buff(self.get_jagged_armor(), dur)
			if shield: unit.add_shields(2)
			lvl.show_effect(unit.x, unit.y, Tags.Physical)

	def get_description(self):
		return ("Allies gain [{resist} Physical:physical] resist, [{resist} Fire:fire] resist, and [{resist} Lightning:lightning] resist and become [Metallic]\n"
				"Lasts [{duration}:duration] turns")

class EchoCast(Buff):

	def __init__(self, spell):
		Buff.__init__(self)
		self.spell = spell
		self.name = "Echo Cast " + spell.name
		self.color = spell.tags[0].color
		self.stack_type = STACK_INTENSITY

	def on_unapplied(self):
		self.owner.level.queue_spell(self.spell.cast(self.owner.x, self.owner.y, is_echo=True))

	def get_description(self):
		return "Recast {spell} in {val} turns", {'spell':self.spell.name, 'val':self.turns_left}

class DeathDealer(Upgrade):

	def __init__(self, spell):
		self.spell = spell
		Upgrade.__init__(self, spell)

	def on_init(self):
		self.name = "Death Tax"
		self.level = 5
		self.global_triggers[EventOnDeath] = self.on_death

	def get_description(self):
		return "When an enemy dies, all enemies of the same name lose 10% of their current and max HP\nAlways Active"

	def on_death(self, evt):
		if not are_hostile(evt.unit, self.owner): return
		targets = [u for u in self.owner.level.units if are_hostile(self.owner, u) and u.is_alive() and u.name == evt.unit.name]
		self.owner.level.queue_spell(self.do_cut(targets))

	def do_cut(self, targets):
		lifesteal = self.spell.get_stat('lifesteal')
		heal_counter = 0
		owner = self.owner
		for u in targets:
			if not u.is_alive(): continue
			to_cut_cur = u.cur_hp // 10
			to_cut_max = u.max_hp // 10
			u.cur_hp -= to_cut_cur
			u.cur_hp = max(1, u.cur_hp)
			if lifesteal: heal_counter += to_cut_max
			u.max_hp -= to_cut_max
			u.max_hp = max(1, u.max_hp)
		yield

		if heal_counter: owner.heal(heal_counter, self.spell)


class WordOfUndeath(Spell):

	def on_init(self):
		self.name = "Word of Undeath"

		self.tags = [Tags.Dark, Tags.Word]
		self.level = 7
		self.max_charges = 1
		self.range = 0

		self.upgrades[('hatred_of_life', 'damage')] = ([1, 36], 3, "Hatred of Life", "Other [Living] units take [{damage}:damage] [Poison] damage")
		self.upgrades['dominion'] = (1, 9, "Word of Dominion", "Cast Dominate on all legal targets for it after you cast this spell\nUses Dominate's range and line of sight requirements")
		self.upgrades[('lifesteal', 'hp_cost')] = ([1, 50], 4, "Vampiric Word", "You heal for any max HP reduction inflicted by Word of Undeath", [Tags.Blood])
		self.add_upgrade(DeathDealer(self))

	def get_impacted_tiles(self, x, y):
		return [u for u in self.caster.level.units if u != self.caster]

	def get_description(self):
		return ("[Undead] units have their current and maximum HP doubled\n"
				"Other units lose half their current and maximum HP\n"
				"Does not affect the caster")

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		showeffect = level.show_effect

		lifesteal = self.get_stat('lifesteal')
		heal_counter = 0
		hatred = self.get_stat('hatred_of_life')
		damage = self.get_stat('damage')

		units = list(level.units)
		random.shuffle(units)
		for unit in units:
			if unit.is_player_controlled: continue
			if Tags.Undead in unit.tags:
				unit.max_hp *= 2
				unit.heal(unit.cur_hp, self)
				continue
			unit.cur_hp //= 2
			unit.cur_hp = max(1, unit.cur_hp)
			if lifesteal: heal_counter += unit.max_hp // 2; level.show_beam(unit, caster, Tags.Blood, minor=True);
			unit.max_hp //= 2
			unit.max_hp = max(1, unit.max_hp)
			showeffect(unit.x, unit.y, Tags.Dark, minor=False)
			if hatred and Tags.Living in unit.tags: unit.deal_damage(damage, Tags.Poison, self)
			yield

		if heal_counter: caster.heal(heal_counter, self); yield

		if self.get_stat('dominion'):
			s = caster.get_or_make_spell(Dominate)
			targets = [u for u in level.units if s.can_cast(u.x, u.y)]
			for u in targets: level.act_cast(caster, s, u.x, u.y, pay_costs=False); yield

class WordOfChaos(Spell):

	def on_init(self):
		self.name = "Word of Chaos"
		self.damage = 66
		self.duration = 6
		self.range = 0

		self.tags = [Tags.Chaos, Tags.Word]
		self.level = 7
		self.max_charges = 1

		self.upgrades['destruction'] = (1, 7, "Word of Destruction", "If you cast Word of Chaos on the 9th turn of the level, the damage and resist stripping effects of the spell affect all enemies instead of only those with specific tags")
		self.upgrades['stun'] = (1, 5, "Stunning Word", "Word of Chaos will always [stun] enemies instead of inflicting [berserk] or [fear]")
		self.upgrades[('reanimation', 'minion_health', 'minion_damage', 'minion_range')] = ([1, 36, 11, 6], 4, "Animated Chaos", "When Word of Chaos kills a unit, summon a Chaos Spirit at their location")
		self.upgrades['echo'] = (1, 5, "Echoing Chaos", "Auto recasts in 10 turns")
		self.add_upgrade_tooltip("Animated Chaos", self.make_chaos_spirit)

	def get_description(self):
		return ("Teleport each enemy to random tiles"
				"\nThey are randomly [stunned], [berserked], or [feared] for [{duration}:duration] turns"
				"\nDeal [{damage}:damage] [Lightning] damage to all [Fire] enemies"
				"\nDeal [{damage}:damage] [Fire] damage to all [Lightning] enemies"
				"\nEnemy [Constructs:construct] lose all [Physical] resistance and take [{damage}:damage] [Physical] damage")

	def make_chaos_spirit(self):
		u = ChaosSpirit()
		apply_minion_bonuses(self, u)
		return u

	def get_impacted_tiles(self, x, y):
		return [u for u in self.owner.level.units if u != self.caster and are_hostile(u, self.caster)]

	def cast(self, x, y, is_echo=False):
		if self.get_stat('echo') and not is_echo: self.caster.apply_buff(EchoCast(self), 10)
		dur = self.get_stat('duration')
		dmg = self.get_stat('damage')

		reanimation = self.get_stat('reanimation')
		if self.get_stat('stun'): debuff_opts = [Stun]
		else: debuff_opts = [Stun, BerserkBuff, FearBuff]

		caster = self.caster
		level = caster.level

		destruction = self.get_stat('destruction') and level.turn_no == 9


		units = list(level.units)
		random.shuffle(units)
		for unit in units:
			if not level.are_hostile(caster, unit): continue
			teleport_target = level.get_random_stand_tile(unit)
			if not teleport_target: continue
			level.show_path_effect(unit, teleport_target, Tags.Chaos)
			level.act_move(unit, teleport_target.x, teleport_target.y, teleport=True)
			unit.apply_buff(random.choice(debuff_opts)(), dur)
			if destruction or Tags.Construct in unit.tags: unit.resists[Tags.Physical] = 0; unit.deal_damage(dmg, Tags.Physical, self)
			if destruction or Tags.Lightning in unit.tags: unit.deal_damage(dmg, Tags.Fire, self)
			if destruction or Tags.Fire in unit.tags: unit.deal_damage(dmg, Tags.Lightning, self)
			if reanimation and not unit.is_alive(): u = self.make_chaos_spirit(); self.summon(u, target=unit)
			yield

class UnmarredBeauty(Buff):

	def on_init(self):
		self.name = "Unmarred Beauty"
		self.description = "Lost when you take damage or pay HP"
		self.owner_triggers[EventOnDamaged] = self.on_damaged
		self.owner_triggers[EventOnSpendHP] = self.on_spend
		self.stack_type = STACK_REPLACE
		self.color = Tags.Holy.color

	def on_damaged(self, evt):
		if evt.damage <= 0: return
		self.owner.remove_buff(self)

	def on_spend(self, evt):
		self.owner.remove_buff(self)

	def on_applied(self, owner):
		self.global_bonuses_pct['damage'] = owner.max_hp

class WordOfBeauty(Spell):

	def on_init(self):
		self.name = "Word of Beauty"
		self.damage = 100
		self.duration = 7
		self.range = 0
		self.tags = [Tags.Holy, Tags.Lightning, Tags.Word]
		self.level = 7
		self.max_charges = 1

		self.upgrades['venom'] = (1, 4, "Venomous Word", "If Word of Beauty would heal an enemy, they are first [poisoned] for [{duration}:duration] turns", [Tags.Dark], None, {'duration':7})
		self.upgrades['echo'] = (1, 4, "Echoing Beauty", "Auto recast in 10 turns")
		self.upgrades['symmetry'] = (1, 7, "Divine Symmetry", "Allies that would be healed first have their max HP set equal to the wizard's")
		self.upgrades['unmarred'] = (1, 8, "Unmarred Beauty", "When you cast Word of Beauty, gain a percent damage bonus to all spells and equipment equal to your maximum health\nThis bonus does not stack and is lost when you take damage or pay HP")

	def get_impacted_tiles(self, x, y):
		return [u for u in self.caster.level.units if u != self.caster and u.has_tags([Tags.Living, Tags.Dark, Tags.Demon, Tags.Undead, Tags.Arcane])]

	def get_description(self):
		return ("Heal yourself and other [Living] units to full health"
				"\nDeal [{damage}:damage] [Lightning] damage to [Dark], [Demon] and [Undead] units"
				"\n[Arcane] units are [stunned] for [{duration}:duration] turns")

	def cast(self, x, y, is_echo=False):
		caster = self.caster
		level = caster.level
		if self.get_stat('unmarred'): caster.apply_buff(UnmarredBeauty())
		if self.get_stat('echo') and not is_echo: caster.apply_buff(EchoCast(self), 10)

		venom = self.get_stat('venom')

		boon_tags = [Tags.Living]
		bane_tags = [Tags.Dark, Tags.Demon, Tags.Undead]
		damage = self.get_stat('damage')
		duration = self.get_stat('duration')


		symmetry = self.get_stat('symmetry')
		player_hp = level.player_unit.max_hp

		units = list(level.units)
		random.shuffle(units)

		for unit in units:
			if unit.is_player_controlled or unit.has_tags(boon_tags):
				if are_hostile(caster, unit):
					if venom: unit.apply_buff(Poison(), duration)
				elif symmetry : unit.max_hp = player_hp
				unit.heal(unit.max_hp, self)
			if unit.has_tags(bane_tags): unit.deal_damage(damage, Tags.Lightning, self)
			if Tags.Arcane in unit.tags: unit.apply_buff(Stun(), duration)
			yield

class WordOfMadness(Spell):

	def on_init(self):
		self.name = "Word of Madness"
		self.duration = 5
		self.tags = [Tags.Word, Tags.Dark, Tags.Arcane]
		self.level = 7
		self.max_charges = 1

		self.duration = 5
		self.range = 0

		self.upgrades[('howling', 'damage')] = ([1, 25], 4, "Howling Void", "Deal [{damage}:damage] [Dark] and [Arcane] damage to enemies on or adjacent to chasms", None, [Tags.Arcane, Tags.Dark])
		self.upgrades['selective_madness'] = (1, 3, "Selective Madness", "No longer heals enemies\nNo longer damages or [berserks] allies")
		self.upgrades['echo'] = (1, 3, "Echoing Madness", "Auto recast in 10 turns")
		self.upgrades[('guardians', 'num_summons', 'minion_damage', 'minion_duration')] = ([1, 6, 2, 15], 6, "Guardians of Madness", "Summon [{num_summons}:num_summons] temporary Mind Devourers, Floating Eyeballs, and Troublers at random locations", [Tags.Conjuration])
		self.add_upgrade_tooltip("Guardians of Madness", self.make_mind_devourer, self.make_floating_eye, self.make_troubler)

	def get_description(self):
		return ("[Berserk] all units except the caster for [{duration}:duration] turns\n"
				"Deal [Dark] damage to all [Constructs:construct] equal to half their max HP\n"
				"Fully heal all [Demon] and [Arcane] units")

	def get_impacted_tiles(self, x, y):
		caster = self.caster
		selective = self.get_stat('selective_madness')
		return [u for u in self.caster.level.units if u != self.caster and (not selective or are_hostile(caster, u) or u.has_tags([Tags.Arcane, Tags.Demon]))]

	def make_mind_devourer(self):
		u = MindDevourer()
		apply_minion_bonuses(self, u)
		return u

	def make_floating_eye(self):
		u = FloatingEye()
		apply_minion_bonuses(self, u)
		return u

	def make_troubler(self):
		u = Troubler()
		apply_minion_bonuses(self, u)
		return u

	def cast(self, x, y, is_echo=False):
		caster = self.caster
		level = caster.level
		duration = self.get_stat('duration')

		if self.get_stat('echo') and not is_echo: caster.apply_buff(EchoCast(self), 10)

		if self.get_stat('guardians'):
			num_summons = self.get_stat('num_summons')
			for s in [self.make_mind_devourer, self.make_floating_eye, self.make_troubler]:
				for i in range(num_summons):
					self.summon(s(), radius=12, sort_dist=False)

		selective = self.get_stat('selective_madness')
		howling = self.get_stat('howling')
		damage = self.get_stat('damage')

		heal_tags = [Tags.Arcane, Tags.Demon]

		units = list(self.caster.level.units)
		random.shuffle(units)
		for unit in units:
			if unit == caster: continue
			if are_hostile(caster, unit):
				unit.apply_buff(BerserkBuff(), duration)
				if Tags.Construct in unit.tags: unit.deal_damage(unit.max_hp // 2, Tags.Dark, self)
				if not selective and unit.has_tags(heal_tags): unit.heal(unit.max_hp, self)
				if howling and any(t for t in level.get_tiles_in_ball(unit.x, unit.y, 1, diag=True) if t.is_chasm):
					unit.deal_damage(damage, Tags.Dark, self)
					unit.deal_damage(damage, Tags.Arcane, self)
				yield
			else:
				if unit.has_tags(heal_tags): unit.heal(unit.max_hp, self)
				if selective: continue
				unit.apply_buff(BerserkBuff(), duration)
				if Tags.Construct in unit.tags: unit.deal_damage(unit.max_hp // 2, Tags.Dark, self)
				yield

class InevitableCurse(Buff):

	def on_init(self):
		self.name = "Inevitable Decay"
		self.color = Tags.Dark.color
		self.stack_type = STACK_INTENSITY
		self.buff_type = BUFF_TYPE_CURSE
		for dt in damage_tags:
			self.resists[dt] = -1

	def on_advance(self):
		for dt in damage_tags:
			self.resists[dt] -= 1
			self.owner.resists[dt] -= 1

class CurseHarvester(Upgrade):

	def on_init(self):
		self.name = "Curse Harvester"
		self.level = 8
		self.description = "When a unit dies, heal 1 HP for each debuff they had\nAlways Active"
		self.global_triggers[EventOnDeath] = self.on_death

	def on_death(self, evt):
		if evt.unit == self.owner: return
		heal = len([b for b in evt.unit.buffs if b.buff_type == BUFF_TYPE_CURSE])
		if heal:
			self.owner.level.show_path_effect(evt.unit, self.owner, Tags.Dark, minor=True)
			self.owner.heal(heal, self)

class LitanyOfCurses(Spell):

	def on_init(self):
		self.name = "Litany of Curses"
		self.level = 9
		self.tags = [Tags.Dark, Tags.Ritual, Tags.Word]

		self.max_charges = 1
		self.range = 0
		self.max_channel = 6
		self.duration = 3
		self.num_targets = 1

		self.curses = [Poison, BleedBuff, NecrosisBuff, BerserkBuff, HemorrhageBuff, Silence]
		self.progression = 0

		self.upgrades['vocab'] = (1, 1, "Cursed Vocabulary", "This spell's debuff duration is increased by 1 for each other [Dark] or [Word] spell you know")
		self.upgrades[('dread', 'damage')] = ([1, 1], 5, "Dreadful Refrain", "Litany of Curses deals [{damage}:damage] [Dark] damage before it attempts to apply a debuff")
		self.upgrades['inevitable'] = (1, 7, "Curse of Inevitability", "If ritual is completed, enemies also receive a permanent debuff that decreases all of their resistances by 1 each turn")
		self.add_upgrade(CurseHarvester())


	def get_description(self):
		return ("Each turn spent channeling this spell inflicts [{duration}:duration] turns of a debuff on each enemy, along with a fresh stack of each of the previous debuffs\n"
				"If you complete the ritual, up to [{num_targets}:num_targets] of each enemy's debuffs will be made permanent\n"
				"The debuffs are applied in the following order:\n[Poison], [bleed], [necrosis], [berserk], [hemorrhage], [silence]")

	def cast(self, x, y, channel_cast=False):

		if not channel_cast:
			self.progression = 0 # reset the list if we autocast somehow
			if self.is_manual_cast():
				self.caster.apply_buff(ChannelBuff(self.cast, Point(x, y)), self.get_stat('max_channel'))
				return

		self.progression += 1
		cb = self.caster.get_buff(ChannelBuff)
		if cb: curses = self.curses[:self.progression]
		elif channel_cast: curses = self.curses[:]
		else: curses = self.curses[0:]

		enemies = [u for u in self.caster.level.units if are_hostile(self.caster, u)]
		if not enemies: return

		duration = self.get_stat('duration')
		if self.get_stat('vocab'): duration += (len([s for s in self.caster.spells if (Tags.Word in s.tags or Tags.Dark in s.tags)]) - 1)
		complete = channel_cast and not cb
		num_perm = self.get_stat('num_targets')
		inevitable = self.get_stat('inevitable')
		dread = self.get_stat('dread')
		damage = self.get_stat('damage')

		for u in enemies:
			for c in curses:
				if dread: u.deal_damage(damage, Tags.Dark, self)
				u.apply_buff(c(), duration)

			if complete:
				debuffs = [d for d in u.buffs if d.buff_type == BUFF_TYPE_CURSE and d.turns_left != 0]
				num = min(len(debuffs), num_perm)
				to_perm = random.sample(debuffs, num)
				for b in to_perm: b.turns_left = 0

				if inevitable:
					if dread: u.deal_damage(damage, Tags.Dark, self)
					u.apply_buff(InevitableCurse())

				self.caster.level.show_path_effect(self.caster, u, Tags.Dark)

		yield


class EyeForAnEye(Upgrade):

	def __init__(self, spell):
		self.spell = spell
		Upgrade.__init__(self, spell)

	def on_init(self):
		self.name = "Eye for an Eye"
		self.level = 3
		self.description = "When an enemy damages you for the first time, summon your Floating Eye nearby\n(Once per enemy)"
		self.owner_triggers[EventOnDamaged] = self.on_damaged
		self.owner_triggers[EventOnUnitAdded] = self.on_added
		self.hit_by = set()

	def on_damaged(self, evt):
		if not evt.source: return
		if not evt.source.owner: return
		u = evt.source.owner
		owner = self.owner
		if not are_hostile(u, owner): return
		if u in self.hit_by: return
		self.hit_by.add(u)
		owner.level.act_cast(owner, self.spell, owner.x, owner.y, pay_costs=False)

	def on_added(self, evt):
		self.hit_by.clear()


class SummonFloatingEye(Spell):

	def on_init(self):
		self.name = "Floating Eye"

		self.tags = [Tags.Eye, Tags.Arcane, Tags.Conjuration]
		self.level = 2
		self.max_charges = 12

		ex = FloatingEye()

		self.minion_health = ex.max_hp
		self.minion_damage = ex.spells[0].damage
		self.shields = ex.shields

		self.minion_duration = 20

		self.upgrades['stone_gaze'] = (1, 3, "Stone Gaze", "Floating Eyeball can cast your Petrify on a 3 turn cooldown")
		self.upgrades['eyemage'] = (1, 4, "Eyemage", "Floating Eyeball can cast your other level 2 [Eye] spells on 15 turn cooldowns")
		self.upgrades['regen_shields'] = (1, 2, "Regenerating Shields", "Floating Eyeball gains [2 SH:shields] per turn")
		self.add_upgrade(EyeForAnEye(self))

		self.must_target_empty = True

	def make_eye(self):
		eye = make_minion(self, FloatingEye)
		caster = self.caster
		if self.get_stat('eyemage'):
			for spell in caster.spells:
				if Tags.Eye in spell.tags and spell != self and spell.level == 2:
					grant_minion_spell(type(spell), eye, caster, cool_down=15)

		if self.get_stat('regen_shields'): eye.apply_buff(RegenShieldsBuff())
		if self.get_stat('stone_gaze'): grant_minion_spell(PetrifySpell, eye, caster, cool_down=3)
		return eye

	def cast_instant(self, x, y):
		eye = self.make_eye()
		self.summon(eye, Point(x,y))

	def get_description(self):
		return "Summon a temporary Floating Eyeball"

	def get_extra_examine_tooltips(self):
		return [self.make_eye()] + self.get_upgrade_tooltips()

class ArcLightning(Spell):

	def on_init(self):
		self.name = "Arc Lightning"
		self.tags = [Tags.Lightning, Tags.Sorcery]
		self.damage_type = [Tags.Lightning]
		self.max_charges = 1
		self.level = 6
		self.num_targets = 4

		self.damage = 32
		self.range = 18

		self.upgrades['num_targets'] = (4, 4, "Multi Flash")
		self.upgrades['proton'] = (1, 6, "Proton Storm", "Arc Lightning deals [{damage}:damage] [Arcane] damage to units in line of sight of each arc target", [Tags.Arcane], [Tags.Arcane], {'damage':4})
		self.upgrades['invigoration'] = (1, 5, "Invigoration", "Arc Lightning heals allies instead of damaging them")
		self.upgrades['weld'] = (1, 7, "Arc Welder", "When Arc Lightning begins at or arcs to a unit, cast Immolate on them\nIf it's a [Metallic] unit, also cast Magnetize on it", [Tags.Fire, Tags.Metallic])

	def get_description(self):
		return ("Lightning arcs to [{num_targets}:num_targets] enemies in line of sight of the target tile\n"
				"Each arc deals [{damage}:damage] [Lightning] damage in a beam\n"
				"Then, this process repeats once for half damage, originating from each arc target")

	def do_weld(self, unit):
		to_cast = [ImmolateSpell]
		if Tags.Metallic in unit.tags: to_cast.append(MagnetizeSpell)
		for spell in to_cast:
			s = self.caster.get_or_make_spell(spell)
			self.caster.level.act_cast(self.caster, s, unit.x, unit.y, pay_costs=False)

	def cast(self, x, y, is_echo=False):
		caster = self.caster
		level = caster.level
		dmg = self.get_stat('damage') // 2 if is_echo else self.get_stat('damage')
		num_targets = self.get_stat('num_targets')

		proton = self.get_stat('proton')
		proton_dmg = self.get_stat('damage', base=4)
		invigoration = self.get_stat('invigoration')
		weld = self.get_stat('weld')

		center_unit = level.get_unit_at(x, y)
		if center_unit: # if there's a unit
			if are_hostile(center_unit, caster) or not invigoration: center_unit.deal_damage(dmg, Tags.Lightning, self) # hurt enemies or allies if appropriate
			elif invigoration: center_unit.heal(dmg, self) # heal allies when appropriate
			if weld: self.do_weld(center_unit) # try to weld the starting target (this is also the arced to targets on the subsequent casts)
		else: level.show_effect(x, y, Tags.Lightning) # shortcut show effect if no enemy there
		yield

		targets = set(t for t in level.get_units_in_los(Point(x, y)) if level.are_hostile(t, caster))
		if center_unit: targets.discard(center_unit) # don't want an arc to choose itself to arc to

		chosen_targets = []
		for i in range(num_targets):
			if not targets: break
			target = targets.pop()
			chosen_targets.append(target)

			if proton:
				for u in level.get_units_in_los(target):
					if invigoration and are_friendly(caster, u): u.heal(proton_dmg, self)
					else: u.deal_damage(proton_dmg, Tags.Arcane, self)
				yield

			for p in level.get_points_in_line(Point(x, y), target, find_clear=True)[1:]:
				unit = level.get_unit_at(p.x, p.y)
				if invigoration and unit and are_friendly(unit, caster): unit.heal(dmg, self)
				else: level.deal_damage(p.x, p.y, dmg, Tags.Lightning, self)

			if weld and is_echo: self.do_weld(target) # arc targets on first pass already welded b/c they're 'center_unit'

			yield

		if not is_echo:
			recursions = [self.cast(t.x, t.y, is_echo=True) for t in chosen_targets]
			sentinel = object()
			while recursions:
				recursions = [r for r in recursions if next(r, sentinel) is not sentinel]
				yield

		yield

class StingingRebuke(Upgrade):

	def __init__(self, spell):
		self.spell = spell
		Upgrade.__init__(self, spell)

	def on_init(self):
		self.level = 4
		self.name = "Stinging Rebuke"
		self.description = "Each turn, cast Poison Sting on up to [2:num_targets] enemies in line of sight who dealt damage to you"
		self.owner_triggers[EventOnDamaged] = self.on_damaged
		self.num_targets = 2
		self.new_attributes = {'num_targets':2}
		self.casts = 0

	def on_damaged(self, evt):
		if self.casts >= self.spell.get_stat('num_targets', base=2): return
		if evt.damage <= 0: return
		if not evt.source: return
		if not evt.source.owner: return
		if evt.source.owner == self.owner: return
		if not are_hostile(evt.source.owner, self.owner): return
		self.owner.level.queue_spell(self.sting(evt.source.owner)) # double-queued in this way to prevent wizard from stinging themselves in trample situations

	def on_advance(self):
		self.casts = 0

	def sting(self, unit):
		if not unit.is_alive(): return
		for _ in self.owner.level.act_cast(self.owner, self.spell, unit.x, unit.y, pay_costs=False, queue=False): yield
		self.casts += 1
		yield

	def get_description(self):
		return ("Each turn, cast Poison Sting on up to [{num}:num_targets] enemies in line of sight who dealt damage to you\nAlways Active" , {'num': self.spell.get_stat('num_targets', base=2)})

class PoisonSting(Spell):

	def on_init(self):
		self.name = "Poison Sting"
		self.tags = [Tags.Sorcery, Tags.Nature]
		self.max_charges = 26
		self.duration = 30
		self.damage = 9
		self.damage_type = [Tags.Physical]
		self.range = 10
		self.level = 1

		self.upgrades['antigen'] = (1, 2, "Acidity", "Applies [Acidified:poison] to the target, reducing [Poison] resist by 100%")
		self.upgrades['webs'] = (1, 1, "Silk Shot", "Immobilizes target and creates Webs in a line to the target\n"
													"Units in the line are immobilized for [{duration}:duration] turns\n"
													"Webs immobilize non-[Spider] units that enter them for one turn", None, None, {'duration':3})
		self.upgrades[('barrage', 'radius')] = ([1, 3], 3, "Stinger Barrage", "Hits every [poisoned] enemy within [{radius}:radius] tiles of the target")
		self.add_upgrade(StingingRebuke(self))

		self.add_upgrade_tooltip("Acidity", Acidified)

	def can_harm(self, target_unit):
		if Spell.can_harm(self, target_unit): return True
		if target_unit.debuff_immune: return False
		if target_unit.resists[Tags.Poison] < 100 and not target_unit.has_buff(Poison): return True
		return bool(self.get_stat('antigen') and not target_unit.has_buff(Acidified))

	def get_impacted_tiles(self, x, y):
		if self.get_stat('webs'):
			for p in self.caster.level.get_points_in_line(self.caster, Point(x, y), find_clear=True)[1:-1]: yield p
		if self.get_stat('barrage'):
			for u in self.caster.level.get_units_in_ball(Point(x, y), self.get_stat('radius')):
				if u.has_buff(Poison) and are_hostile(self.caster, u): yield u
		yield Point(x, y)

	def cast(self, x, y):
		target = Point(x, y)
		targets = {target}
		caster = self.caster
		level = caster.level

		damage = self.get_stat('damage')
		dur = self.get_stat('duration')

		acidify = self.get_stat('antigen')
		webs = self.get_stat('webs')
		web_dur = self.get_stat('duration', base=3)

		if self.get_stat('barrage'):
			for u in level.get_units_in_ball(target, self.get_stat('radius')):
				if u.has_buff(Poison) and are_hostile(caster, u): targets.add(Point(u.x, u.y))

		for pt in targets:
			for p in level.get_points_in_line(caster, pt, find_clear=True)[1:-1]:
				level.show_effect(p.x, p.y, Tags.Poison, minor=True)
				if webs:
					u = level.get_unit_at(p.x, p.y)
					if u: u.apply_buff(ImmobilizeBuff(), web_dur)
					else: web = SpiderWeb(); web.owner = caster; level.add_obj(web, p.x, p.y)
			yield

			level.deal_damage(pt.x, pt.y, damage, Tags.Physical, self)
			unit = level.get_unit_at(pt.x, pt.y)
			if unit:
				if acidify: unit.apply_buff(Acidified())
				unit.apply_buff(Poison(), dur)
				yield
				if webs: unit.apply_buff(ImmobilizeBuff(), web_dur)


	def get_description(self):
		return ("Deal [{damage}:damage] [Physical] damage to the target\n"
				"Applies [{duration}:duration] turns of [poison]")

class WildfireCharge(Buff):

	def on_init(self):
		self.name = "Wildfire"
		self.buff_type = BUFF_TYPE_BLESS
		self.color = Tags.Fire.color
		self.spell_bonuses[FanOfFlames]['range'] = 1
		self.stack_type = STACK_INTENSITY

	def on_advance(self):
		for b in self.owner.buffs:
			if isinstance(b, ChannelBuff) and isinstance(getattr(b.spell, '__self__', None), FanOfFlames): return # still channeling fan
		self.owner.level.queue_spell(self.clear_charges())

	def clear_charges(self):
		while self.owner.has_buff(WildfireCharge): # have to run this because if you cast again then stop, these on_advance run before the channel gets unapplied
			b = self.owner.get_buff(WildfireCharge)
			if b: self.owner.remove_buff(b)
		yield

class FanOfFlames(Spell):

	def on_init(self):
		self.name = "Fan of Flames"
		self.tags = [Tags.Sorcery, Tags.Fire]
		self.max_charges = 8
		self.damage = 9
		self.damage_type = [Tags.Fire]
		self.range = 5
		self.angle = math.pi / 6.0
		self.level = 2
		self.can_target_self = False
		self.max_channel = 10

		self.upgrades[('damage', 'range')] = ([6, 2,], 2, "Roaring Flames")
		self.upgrades['heal'] = (1, 1, "Healing Hearthfire", "Fan of Flames heals allies instead of damaging them")
		self.upgrades['frostfire'] = (1, 4, "Fan of Frostfire", "Fan of Flames also deals [Ice] damage", [Tags.Ice], [Tags.Ice])
		self.upgrades['wildfire'] = (1, 5, "Wildfire", "Fan of Flames gains 1 [range] for each enemy it kills until you stop channeling it", None, None, {'max_channel':10})

	def get_description(self):
		return ("Deal [{damage}:damage] [Fire] damage in a cone each turn\n"
				"This spell can be channeled for up to [{max_channel}:max_channel] turns")

	def aoe(self, x, y):
		target = Point(x, y)
		return Burst(self.caster.level,
				     Point(self.caster.x, self.caster.y),
				     self.get_stat('range'),
				     burst_cone_params=BurstConeParams(target, self.angle),
				     ignore_walls=not self.get_stat('requires_los'))

	def cast(self, x, y, channel_cast=False):

		if not channel_cast and self.is_manual_cast():
			self.caster.apply_buff(ChannelBuff(self.cast, Point(x, y)), self.get_stat('max_channel'))
			return

		dmg = self.get_stat('damage')
		caster = self.caster
		level = caster.level
		healing = self.get_stat('heal')
		wildfire = self.get_stat('wildfire')
		dtypes = self.get_stat('damage_type')

		getu = level.get_unit_at
		deal_damage = level.deal_damage
		show_effect = level.show_effect

		for stage in self.aoe(x, y):
			for point in stage:
				if point.x == caster.x and point.y == caster.y: continue
				unit = getu(point.x, point.y)
				if unit:
					if are_hostile(unit, caster) or not healing:
						for dtype in dtypes: deal_damage(point.x, point.y, dmg, dtype, self)
					else:
						for _ in dtypes: unit.heal(dmg, self)

					if wildfire and not unit.is_alive(): caster.apply_buff(WildfireCharge())

				else:
					for dtype in dtypes: deal_damage(point.x, point.y, dmg, dtype, self)

			yield

	def get_impacted_tiles(self, x, y):
		return [p for stage in self.aoe(x, y) for p in stage]

class GuardianLions(Upgrade):

	def __init__(self, spell):
		self.spell = spell
		Upgrade.__init__(self, spell)

	def on_init(self):
		self.name = "Lion Saviors"
		self.level = 4
		self.num_summons = 3
		self.new_attributes = {'num_summons':3}
		self.owner_triggers[EventOnUnitAdded] = self.on_added
		self.owner_triggers[EventOnDamaged] = self.on_damaged
		self.owner_triggers[EventOnSpendHP] = self.on_damaged
		self.triggered = False

	def get_description(self):
		return "The first time you fall below 50% HP each level, cast Blue Lion [{num_summons}:num_summons] times nearby"

	def on_added(self, evt):
		self.triggered = False

	def on_advance(self):
		self.do_check()

	def on_damaged(self, evt):
		self.do_check()

	def do_check(self):
		if self.triggered: return
		o = self.owner
		if o.cur_hp > (o.max_hp // 2): return  # don't call them in yet
		if not o.is_alive(): return  # reinforcements couldn't make it in time
		self.triggered = True
		o.level.queue_spell(self.do_summon())

	def do_summon(self):
		o = self.owner
		summoned = False
		for _ in range(self.spell.get_stat('num_summons')):
			p = o.level.get_summon_point(o.x, o.y, radius_limit=9, flying=True)
			if p is None:
				if not summoned: self.triggered = False # don't use up the effect if failed to summoned
				return
			yield from o.level.show_path_effect(o, p, Tags.Holy, pause_frames=1)
			o.level.act_cast(o, self.spell, p.x, p.y, pay_costs=False)
			summoned = True
		yield

class SummonBlueLion(Spell):

	def on_init(self):
		self.name = "Blue Lion"
		self.tags = [Tags.Nature, Tags.Holy, Tags.Conjuration, Tags.Arcane]
		self.max_charges = 2
		self.level = 5
		self.minion_health = 28
		self.minion_damage = 7

		self.upgrades[('holy_bolt', 'minion_range')] = ([1, 4], 2, "Holy Bolt", "Blue Lion gains a ranged [{minion_range}:minion_range] [Holy] attack")
		self.upgrades['healing_light_spell'] = (1, 3, "Shimmermane", "Blue Lion can cast your Healing Light on a 7 turn cooldown")
		self.upgrades[('lamasu', 'minion_range', 'radius')] = ([1, 4, 5], 9, "Summon Lamasu", "Instead of a Blue Lion, summon a Lamasu")
		self.add_upgrade(GuardianLions(self))

		self.add_upgrade_tooltip("Summon Lamasu", self.make_lamasu)

	def make_lion(self):
		lion = make_minion(self, BlueLion)

		if self.get_stat('holy_bolt'):
			bolt = SimpleRangedAttack(damage=self.get_stat('minion_damage'), damage_type=Tags.Holy, range=self.get_stat('minion_range'))
			bolt.name = "Blue Lion Bolt"
			lion.spells.insert(1, bolt)

		if self.get_stat('healing_light_spell'):
			grant_minion_spell(HealingLight, lion, self.caster, cool_down=7)

		return lion

	def make_lamasu(self):

		lion = make_minion(self, Lamasu)

		if self.get_stat('holy_bolt'):
			bolt = SimpleRangedAttack(damage=self.get_stat('minion_damage'), damage_type=Tags.Holy, range=self.get_stat('minion_range'))
			bolt.name = "Holy Bolt"
			lion.spells.insert(2, bolt)

		if self.get_stat('healing_light_spell'):
			grant_minion_spell(HealingLight, lion, self.caster, cool_down=7)

		lion.get_buff(HealAuraBuff).radius = self.get_stat('radius', base=5)

		return lion

	def cast_instant(self, x, y):
		lion = self.make_lamasu() if self.get_stat('lamasu') else self.make_lion()
		self.summon(lion, Point(x, y))

	def get_description(self):
		return "Summon a Blue Lion"

	def get_extra_examine_tooltips(self):
		return [self.make_lion()] + self.get_upgrade_tooltips()

class DeathCleaveBuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)
		self.stack_type = STACK_DURATION
		self.buff_type = BUFF_TYPE_BLESS
		self.asset = ['status', 'death_cleave']
		self.color = Tags.Dark.color
		self.lightning_cleave = self.spell.get_stat('lightning_cleave')
		self.cleaving_whirlwind = self.spell.get_stat('cleaving_whirlwind')
		self.marked_for_death = self.spell.get_stat('marked_for_death')
		if self.lightning_cleave:
			self.tag_bonuses_pct[Tags.Lightning]['num_targets'] = 100
			self.tag_bonuses_pct[Tags.Lightning]['radius'] = 100

	def on_init(self):
		self.name = "Death Cleave"
		self.targets = set()
		self.spellcasts = set()
		self.reaper_targets = set()
		self.pending_cleaves = []
		self.owner_triggers[EventOnSpellCast] = self.on_spell_cast
		self.global_triggers[EventOnDeath] = self.on_death
		self.global_triggers[EventOnDamaged] = self.on_damage

	def get_description(self):
		desc = "When a spell you cast kills its target, recast that spell on a random valid enemy target"
		if self.cleaving_whirlwind: desc += "\nWhen Death Cleave triggers, attempt to teleport to the slain target's location"
		if self.marked_for_death: desc += "\nIf a spell you manually cast on an enemy fails to kill its target, summon a Reaper near their location\nThe Reaper will disappear if the marked target dies"
		return desc

	def on_spell_cast(self, evt):
		u = evt.caster.level.get_unit_at(evt.x, evt.y)
		if not u: return
		self.targets.add(u)
		self.spellcasts.add(evt.spell)
		if evt.pay_costs and self.marked_for_death and are_hostile(self.owner, u): self.reaper_targets.add(u)

	def on_death(self, evt):
		if not evt.damage_event: return
		self.try_queue_cleave(evt.unit, evt.damage_event.source)

	def on_damage(self, evt):
		if not evt.unit.killed: return
		self.try_queue_cleave(evt.unit, evt.source)

	def try_queue_cleave(self, unit, source):
		if unit not in self.targets: return
		if not source: return
		if not isinstance(source, Spell): return
		if source not in self.spellcasts: return
		self.targets.discard(unit)
		self.pending_cleaves.append((unit, source))
		if len(self.pending_cleaves) == 1:
			self.owner.level.queue_spell(self.resolve_cleaves())

	def resolve_cleaves(self):
		unit, spell = self.pending_cleaves[0]
		yield from self.cleave(unit, spell)
		self.pending_cleaves.pop(0)
		if self.pending_cleaves: self.owner.level.queue_spell(self.resolve_cleaves())

	def cleave(self, unit, spell):
		owner = self.owner
		lvl = owner.level
		if self.cleaving_whirlwind and lvl.can_move(owner, unit.x, unit.y, teleport=True):
			lvl.show_effect(owner.x, owner.y, Tags.Translocation)
			lvl.act_move(owner, unit.x, unit.y, teleport=True)
			yield

		def can_cleave(t):
			if not are_hostile(t, self.owner): return False
			if not spell.can_cast(t.x, t.y): return False
			return True

		cleave_targets = [u for u in lvl.units if can_cleave(u)]

		if cleave_targets:
			target = random.choice(cleave_targets)
			for p in lvl.get_points_in_line(unit, target)[:-1]: lvl.show_effect(p.x, p.y, Tags.Dark, minor=True)
			cast_iter = lvl.act_cast(owner, spell, target.x, target.y, pay_costs=False, queue=False)
			if cast_iter: yield from cast_iter
		else: lvl.queue_spell(self.show_fizzle(self.owner))

	def on_advance(self):
		if self.marked_for_death:
			for u in list(self.reaper_targets):
				if u.is_alive():
					reaper = self.spell.make_reaper()
					self.spell.summon(reaper, u)
					if reaper: u.apply_buff(MarkedForDeath(reaper))
			self.reaper_targets.clear()

		self.targets.clear()
		self.spellcasts.clear()

	def show_fizzle(self, center):
		points = list(self.owner.level.get_adjacent_points(center, filter_walkable=False))
		random.shuffle(points)
		for p in points:
			if p == center:
				continue
			etype = random.choice([Tags.Arcane, Tags.Dark])
			self.owner.level.show_effect(p.x, p.y, etype, minor=True)
			if random.random() < .5:
				yield

class MarkedForDeath(Buff):

	def __init__(self, unit):
		Buff.__init__(self)
		self.connected_unit = unit

	def on_init(self):
		self.name = "Marked for Death"
		self.color = Tags.Dark.color
		self.buff_type = BUFF_TYPE_CURSE
		self.stack_type = STACK_INTENSITY
		self.owner_triggers[EventOnDeath] = self.on_death

	def on_advance(self):
		if not self.connected_unit.is_alive():
			self.owner.remove_buff(self)

	def on_death(self, evt):
		if self.connected_unit and self.connected_unit.is_alive():
			self.connected_unit.kill()

	def on_unapplied(self):
		if self.connected_unit and self.connected_unit.is_alive():
			self.connected_unit.kill()

class DeathBountyBuff(Buff):

	def __init__(self, spell):
		Buff.__init__(self)
		self.origin = spell

	def on_init(self):
		self.name = "Death Bounty"
		self.color = Tags.Dark.color
		self.asset = ['status', 'death_bounty']

	def get_description(self):
		return "When this unit dies, cast Death Cleave again for free"

	def on_unapplied(self):
		u = self.origin.caster
		self.owner.level.act_cast(u, self.origin, u.x, u.y, pay_costs=False)


class DeathCleaveSpell(Spell):

	def on_init(self):
		self.name = "Death Cleave"
		self.duration = 4
		self.max_charges = 3
		self.range = 0
		self.level = 4
		self.tags = [Tags.Enchantment, Tags.Arcane, Tags.Dark]

		self.upgrades['lightning_cleave'] = (1, 2, "Lightning Cleave", "Your [Lightning] spells and equipment gain the following bonuses:\n+100% [num targets:num_targets]\n+100% [radius:radius]", [Tags.Lightning])
		self.upgrades['cleaving_whirlwind'] = (1, 2, "Cleaving Whirlwind", "When your spell kills its primary target, attempt to teleport to that location", [Tags.Translocation])
		self.upgrades['execution_ledger'] = (1, 3, "Execution Ledger", "When you cast this spell, a random enemy gains the [Death Bounty:dark] debuff\nWhen they die, cast Death Cleave again for free")
		self.upgrades[('marked_for_death', 'minion_health', 'minion_damage')] = ([1, 31, 200], 4, "Marked for Death", "If a spell you manually cast on an enemy fails to kill its target, summon a Reaper near their location\nThe Reaper will disappear if the marked target dies", [Tags.Conjuration])

		self.add_upgrade_tooltip("Execution Ledger", self.get_death_bounty_buff)
		self.add_upgrade_tooltip("Marked for Death", self.make_reaper)

	def cast(self, x, y):
		self.caster.apply_buff(self.get_death_cleave_buff(), self.get_stat('duration'))
		yield
		if self.get_stat('execution_ledger'):
			candidates = [u for u in self.caster.level.units if u.is_alive() and are_hostile(u, self.caster) and not u.get_buff(DeathBountyBuff)]
			if not candidates: return
			target = random.choice(candidates)
			yield from self.caster.level.show_path_effect(self.caster, target, Tags.Dark, pause_frames=1)
			target.apply_buff(self.get_death_bounty_buff())


	def get_description(self):
		return ("When a spell you cast kills its target, that spell is recast on a random valid enemy target\n"
		  		"Lasts [{duration}:duration] turns")

	def get_death_cleave_buff(self):
		return DeathCleaveBuff(self)

	def get_death_bounty_buff(self):
		return DeathBountyBuff(self)

	def get_extra_examine_tooltips(self):
		return [self.get_death_cleave_buff()] + self.get_upgrade_tooltips()

	def make_reaper(self):
		u = Reaper()
		apply_minion_bonuses(self, u)
		return u


class CantripCascade(Spell):

	def on_init(self):
		self.name = "Cantrip Cascade"
		self.level = 5
		self.tags = [Tags.Arcane, Tags.Sorcery]
		self.max_charges = 3
		self.angle = math.pi / 6
		self.range = 5

		self.upgrades[('range', 'max_charges')] = ([2, 3], 3, "Relentless Cascade")
		self.upgrades[('cantrip_burst', 'radius')] = ([1, 4], 3, "Cantrip Burst", "Instead of a cone, Cantrip Cascade affects tiles in a [{radius}:radius] tile burst")
		self.upgrades['multi'] = (1, 4, "Triple Tap", "One of your cantrips is selected to be cast 3 times instead of only once per enemy")
		self.upgrades['cast_twos'] = (1, 6, "Evocation Amalgamation", "Cantrip Cascade also casts a random level 2 [Sorcery] spell you know on each affected unit")

	def get_impacted_tiles(self, x, y):
		target = Point(x, y)
		burst = None
		if self.get_stat('cantrip_burst'):
			burst = Burst(self.caster.level, Point(x, y), self.get_stat('radius'), ignore_walls=not self.get_stat('requires_los'))
			points = [p for stage in burst for p in stage]
		else:
			burst = Burst(self.caster.level, self.caster, self.get_stat('range'), expand_diagonals=True, burst_cone_params=BurstConeParams(target, self.angle), ignore_walls=not self.get_stat('requires_los'))
			points = [p for stage in burst for p in stage]

		return points

	def cast_instant(self, x, y):
		spells = [s for s in self.caster.spells if s.level == 1 and Tags.Sorcery in s.tags and not s.melee]
		units = [self.caster.level.get_unit_at(p.x, p.y) for p in self.get_impacted_tiles(x, y)]
		enemies = set([u for u in units if u and are_hostile(u, self.caster)])

		if self.get_stat('multi') and spells:
			spells += [random.choice(spells)] * 3

		if self.get_stat('cast_twos'):
			twos = [s for s in self.caster.spells if s.level == 2 and Tags.Sorcery in s.tags and not s.melee]
			if twos: spells.append(random.choice(twos))

		pairs = list(itertools.product(enemies, spells))
		random.shuffle(pairs)
		for enemy, spell in pairs:
			self.caster.level.act_cast(self.caster, spell, enemy.x, enemy.y, pay_costs=False)

	def get_description(self):
		return ("Cast each of your level 1 ranged [Sorcery] spells on each enemy in a cone")

class Preparedness(Upgrade):

	def on_init(self):
		self.name = "Preparedness"
		self.description = "Cast Multicast at the beginning of each level"
		self.level = 7
		self.owner_triggers[EventOnUnitAdded] = self.on_added

	def on_added(self, _evt):
		self.owner.level.act_cast(self.owner, self.owner.get_or_make_spell(MulticastSpell), self.owner.x, self.owner.y, pay_costs=False)

class TargetedMulticastBuff(Buff):

	def __init__(self, spell_target):
		self.spell_target = spell_target
		Buff.__init__(self)
		self.stack_type = STACK_INTENSITY
		self.color = Tags.Arcane.color
		self.name = f"Multicast {spell_target.name}"
		self.owner_triggers[EventOnSpellCast] = self.on_spell_cast

	def get_description(self):
		return ("When you manually cast {spell}, cast it again for free", {'spell':self.spell_target.name})

	def on_spell_cast(self, evt):
		if not evt.pay_costs: return
		if evt.spell != self.spell_target: return
		if evt.spell.can_cast(evt.x, evt.y): evt.caster.level.queue_spell(self.copy_spell(evt))

	def copy_spell(self, evt):
		for _ in evt.caster.level.act_cast(evt.caster, evt.spell, evt.x, evt.y, pay_costs=False, queue=False): yield
		yield

class MulticastBuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)
		self.stack_type = STACK_DURATION
		self.color = Tags.Arcane.color
		self.buff_type = BUFF_TYPE_BLESS
		self.asset = ['status', 'multicast']


	def on_init(self):
		self.name = "Multicast"
		self.description = "When you manually cast a [Sorcery] spell, cast it again for free"
		self.can_copy = True
		self.owner_triggers[EventOnSpellCast] = self.on_spell_cast
		self.copies = self.spell.get_stat('copies')
		if self.spell.get_stat('spell_weaving'):
			self.global_bonuses['quick_cast'] = 1
			self.tag_bonuses[Tags.Sorcery]['quick_cast'] = -1

	def on_spell_cast(self, evt):
		if not evt.pay_costs: return
		if Tags.Sorcery not in evt.spell.tags: return

		if self.can_copy:
			self.can_copy = False
			copies = self.copies if evt.spell.can_cast(evt.x, evt.y) else 0
			evt.caster.level.queue_spell(self.copy_spell(evt, copies))

	def copy_spell(self, evt, copies):
		for _ in range(copies):
			for _ in evt.caster.level.act_cast(evt.caster, evt.spell, evt.x, evt.y, pay_costs=False, queue=False): yield
			yield
		self.can_copy = True
		yield

class MulticastSpell(Spell):

	def on_init(self):
		self.name = "Multicast"
		self.duration = 5
		self.copies = 1
		self.max_charges = 2
		self.range = 0
		self.level = 7
		self.tags = [Tags.Enchantment, Tags.Arcane]

		self.upgrades['spell_weaving'] = (1, 3, "Spell Weaving", "Multicast grants your non [Sorcery] spells quick cast")
		self.upgrades['copies'] = (1, 4, "Echo Mage", "Multicast copies your [Sorcery] spells an additional time")
		self.upgrades['multi'] = (1, 5, "Multi Mastery", "When you cast this spell, one of your [Sorcery] spells is selected at random\nUntil the end of the level, manually casting that spell will cast it again for free\nThis is independent of and stacks with the normal Multicast buff")
		self.add_upgrade(Preparedness())

	def get_multicast_buff(self):
		return MulticastBuff(self)

	def get_extra_examine_tooltips(self):
		return [self.get_multicast_buff()] + self.get_upgrade_tooltips()

	def cast_instant(self, x, y):
		self.caster.apply_buff(self.get_multicast_buff(), self.get_stat('duration'))
		if not self.get_stat('multi'): return
		opts = [s for s in self.caster.spells if Tags.Sorcery in s.tags]
		if not opts: return
		s = random.choice(opts)
		self.caster.apply_buff(TargetedMulticastBuff(s))


	def get_description(self):
		return "When you manually cast a [Sorcery] spell, cast it again for free\nLasts [{duration}:duration] turns"

class FaeCourt(Spell):

	def on_init(self):
		self.name = "Fae Court"
		self.level = 5
		self.tags = [Tags.Nature, Tags.Arcane, Tags.Conjuration]
		self.max_charges = 2
		self.range = 0

		self.num_summons = 4
		self.heal = 5
		self.minion_range = 4
		self.minion_duration = 25
		self.minion_health = 9
		self.shields = 1
		self.minion_damage = 4

		self.upgrades['ward'] = (1, 3, "Fae Protection", "When you cast this spell, the summoned Faeries cast your Arcane Warding on themselves")
		self.upgrades['winter_fae'] = (1, 4, "Winter Faery", "Summon Winter Faeries instead\nWinter Faeries can cast your Freeze spell on a 5 turn cooldown", [Tags.Ice])
		self.upgrades['gardeners'] = (1, 6, "Gardeners", "Faeries can cast your Psychic Seedling spell on a 10 turn cool down")
		self.upgrades['summon_queen'] = (1, 8, "Summon Queen", "Summon a Fae Queen in addition to the Faeries\nIf you have the Winter Faery upgrade as well, summons a Winter Fae Queen instead, which can cast your Blizzard spell on a 15 turn cooldown")

		self.add_upgrade_tooltip("Winter Faery", self.get_winter_faery)
		self.add_upgrade_tooltip("Summon Queen", self.get_faery_queen, self.get_snow_queen)

	def get_description(self):
		return "Summon [{num_summons}:num_summons] temporary Faeries near the caster"

	def get_extra_examine_tooltips(self):
		return [self.get_faery()] + self.get_upgrade_tooltips()

	def get_faery(self):
		unit = make_minion(self, Faery)
		unit.name = "Faery"
		if self.get_stat('gardeners'): grant_minion_spell(PsychicSeedling, unit, self.owner, cool_down=10)
		return unit

	def get_winter_faery(self):
		unit = self.get_faery()
		unit.name = "Winter Faery"
		unit.asset_name = "faery_ice"
		unit.tags.append(Tags.Ice)

		grant_minion_spell(Freeze, unit, self.caster, cool_down=5)

		unit.resists[Tags.Ice] = 100
		unit.resists[Tags.Fire] = -50

		return unit

	def get_snow_queen(self):
		unit = self.get_faery_queen()
		unit.name = "Winter Fae Queen"
		unit.asset_name = "snow_queen"
		unit.tags.append(Tags.Ice)

		summon = unit.get_spell(SimpleSummon)
		summon.spawn_func = self.get_winter_faery
		summon.calc_text()

		grant_minion_spell(BlizzardSpell, unit, self.caster, cool_down=15)

		unit.resists[Tags.Ice] = 100
		unit.resists[Tags.Fire] = -50

		return unit

	def get_faery_queen(self):
		unit = ThornQueen()
		summon = unit.get_spell(SimpleSummon)
		summon.spawn_func = self.get_faery
		summon.calc_text()
		if self.get_stat('gardeners'): grant_minion_spell(PsychicSeedling, unit, self.owner, cool_down=10)
		apply_minion_bonuses(self, unit)
		return unit

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		winter = self.get_stat('winter_fae')
		ward = self.get_stat('ward')
		if self.get_stat('summon_queen'):
			if winter: u = self.summon(self.get_snow_queen(), Point(x,y))
			else: u = self.summon(self.get_faery_queen(), Point(x,y))
			if u and ward:
				s = u.get_or_make_spell(ArcaneWardingSpell); s.caster = u; s.statholder = caster
				for _ in level.act_cast(u, s, u.x, u.y, pay_costs=False, queue=False): pass
		u = None
		for i in range(self.get_stat('num_summons')):
			if winter: unit = self.get_winter_faery()
			else: unit = self.get_faery()
			u = self.summon(unit, sort_dist=False)
			if u and ward:
				s = u.get_or_make_spell(ArcaneWardingSpell); s.caster = u; s.statholder = caster
				for _ in level.act_cast(u, s, u.x, u.y, pay_costs=False, queue=False): pass
			yield


class HolyBlast(Spell):

	def on_init(self):

		self.name = "Heavenly Blast"
		self.range = 6
		self.radius = 1
		self.damage = 14
		self.damage_type = [Tags.Holy]
		self.max_charges = 10
		self.level = 2
		self.tags = [Tags.Holy, Tags.Sorcery]

		self.upgrades[('spiritbind', 'minion_health', 'minion_damage', 'minion_range', 'minion_duration')] = ([1, 4, 2, 3, 7], 3, "Spirit Bind", "Slain enemies are raised as temporary Holy Ghosts")
		self.upgrades['shield'] = (1, 2, "Shield", "Affected allies gain [2 SH:shields]")
		self.upgrades['judgement'] = (1, 4, "Judgement", "Holy Blast deals double damage to enemies at full health")
		self.upgrades['immolate'] = (1, 7, "Immolating Blast", "Casting Heavenly Blast on an enemy also casts Immolate on them", [Tags.Fire])

		self.add_upgrade_tooltip("Spirit Bind", lambda: make_minion(self, HolyGhost))

	def get_description(self):
		return ("Deal [{damage}:damage] [Holy] damage in a beam and in a [{radius}:radius] tile burst around the target\n"
				"Allies are healed instead of damaged")

	def can_harm(self, target_unit):
		if are_friendly(self.caster, target_unit): return True
		return Spell.can_harm(self, target_unit)

	def get_impacted_tiles(self, x, y):
		burst = set(p for stage in Burst(self.caster.level, Point(x, y), self.get_stat('radius'), ignore_walls=not self.get_stat('requires_los')) for p in stage)
		beam = set(Bolt(self.caster.level, self.caster, Point(x, y), find_clear=self.get_stat('requires_los')))
		return burst.union(beam)

	def get_ai_target(self):
		r = self.get_stat('radius')
		p = self.get_corner_target(r) # gets enemies first
		if p: return p
		def wounded_ally(u): return are_friendly(self.caster, u) and u != self.caster and u.can_be_healed()
		p = self.get_corner_target(r, unit_filter=wounded_ally)
		return p # will be None if no valid allies to heal

	def cast(self, x, y):
		target = Point(x, y)
		c = self.caster
		lvl = c.level
		dmg = self.get_stat('damage')

		sh = self.get_stat('shield')
		judgement = self.get_stat('judgement')
		immolate = self.get_stat('immolate')
		spirit_bind = self.get_stat('spiritbind')


		def deal_damage(p):
			u = lvl.get_unit_at(p.x, p.y)
			if not u: lvl.show_effect(p.x, p.y, Tags.Holy); return
			if u == c: return
			if are_friendly(u, c):
				u.heal(dmg, self)
				if sh: u.add_shields(2)
			else:
				d = dmg
				if judgement and u.cur_hp == u.max_hp: d *= 2
				u.deal_damage(d, Tags.Holy, self)
				if spirit_bind and u and not u.is_alive():
					spirit = make_minion(self, HolyGhost)
					self.summon(spirit, target=u)

		points_hit = set()
		for point in Bolt(self.caster.level, self.caster, target, find_clear=self.get_stat('requires_los')):
			deal_damage(point)
			points_hit.add(point)
			yield

		for stage in Burst(self.caster.level, target, self.get_stat('radius'), ignore_walls=not self.get_stat('requires_los')):
			for point in stage:
				if point in points_hit: continue
				deal_damage(point)
			yield

		if immolate:
			u = lvl.get_unit_at(x, y)
			if u and u.is_alive() and are_hostile(c, u):
				for _ in lvl.act_cast(c, c.get_or_make_spell(ImmolateSpell), x, y, pay_costs=False, queue=False): yield

class TitheOfTheFallen(Upgrade):

	def on_init(self):
		self.name = "Tithe Of The Fallen"
		self.level = 3
		self.description = "When a [Holy] ally dies, regain a charge of Holy Fire"
		self.global_triggers[EventOnDeath] = self.on_death

	def on_death(self, evt):
		if are_hostile(evt.unit, self.owner): return
		if Tags.Holy not in evt.unit.tags: return
		s = self.owner.get_spell(HolyFlame)
		if s:
			s.refund_charges(1)
			self.owner.level.show_path_effect(evt.unit, self.owner, Tags.Holy, minor=True)


class HolyFlame(Spell):

	def on_init(self):
		self.name = "Holy Fire"
		self.level = 3
		self.tags = [Tags.Fire, Tags.Holy, Tags.Sorcery]
		self.damage_type = [Tags.Fire, Tags.Holy]

		self.max_charges = 7
		self.damage = 22
		self.duration = 3
		self.radius = 2
		self.range = 6

		self.upgrades['holy_smite'] = (1, 1, "Holy Smite", "Holy Fire also deals [Lightning] damage to its target", [Tags.Lightning], [Tags.Lightning])
		self.upgrades['divine_blaze'] = (1, 4, "Divine Blaze", "Casting Holy Fire also casts Blazerip on the target", [Tags.Arcane])
		self.upgrades['heaven_call'] = (1, 6, "Heaven Call", "When Holy Fire kills its target, cast Call Seraph where it died")
		self.add_upgrade(TitheOfTheFallen())

	def get_description(self):
		return ("Deal [{damage}:damage] [Fire] damage in a vertical line\n"
				"Deal [{damage}:damage] [Holy] damage in a horizontal line\n"
				"[Stun] affected [Demon] and [Undead] units for [{duration}:duration] turns")

	def get_impacted_tiles(self, x, y):
		rad = self.get_stat('radius')
		for i in range(-rad, rad + 1):
			yield Point(x+i, y)
			if i != 0: yield Point(x, y+i)
		if self.get_stat('divine_blaze'):
			blazerip_spell = self.caster.get_or_make_spell(Blazerip)
			for p in blazerip_spell.get_impacted_tiles(x, y): yield p

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		deal_damage = level.deal_damage
		good_point = level.is_point_in_bounds

		rad = self.get_stat('radius')
		dmg = self.get_stat('damage')
		dur = self.get_stat('duration')

		target_unit = level.get_unit_at(x, y)

		for i in range(y - rad, y + rad + 1):
			if not good_point(Point(x, i)): continue
			unit = level.get_unit_at(x, i)
			deal_damage(x, i, dmg, Tags.Fire, self)
			if not unit: continue
			if unit.is_alive() and unit.has_tags([Tags.Demon, Tags.Undead]): unit.apply_buff(Stun(), dur)
			yield

		for i in range(3): yield

		for i in range(x - rad, x + rad + 1):
			if not good_point(Point(i, y)): continue
			unit = level.get_unit_at(i, y)
			deal_damage(i, y, dmg, Tags.Holy, self)
			if not unit: continue
			if unit.is_alive() and unit.has_tags([Tags.Demon, Tags.Undead]): unit.apply_buff(Stun(), dur)
			yield

		for i in range(3): yield

		if self.get_stat('holy_smite'): deal_damage(x, y, dmg, Tags.Lightning, self)

		if self.get_stat('divine_blaze'):
			blazerip_spell = caster.get_or_make_spell(Blazerip)
			for _ in level.act_cast(caster, blazerip_spell, x, y, pay_costs=False, queue=False): yield

		if self.get_stat('heaven_call') and target_unit and not target_unit.is_alive():
			seraph_spell = caster.get_or_make_spell(SummonSeraphim)
			for _ in level.act_cast(caster, seraph_spell, x, y, pay_costs=False, queue=False): yield



class ChoirOfAngels(Spell):

	def on_init(self):
		self.name = "Choir of Angels"
		self.level = 4
		self.tags = [Tags.Holy, Tags.Conjuration]

		self.max_charges = 2
		self.range = 0

		self.minion_health = 12
		self.shields = 2
		self.minion_duration = 12
		self.num_summons = 3
		self.minion_damage = 2

		self.upgrades['salvation'] = (1, 3, "Song of Salvation", "When an Angelic Singer would heal an ally, it removes a debuff first")
		self.upgrades['unending_song'] = (1, 2, "Unending Song", "Angelic Singers reincarnate once on death")
		self.upgrades['num_summons'] = (3, 5, "Massive Chorus")
		self.upgrades['cast_deathbolt'] = (1, 6, "Dual Angels", "Angelic Singers gain the [Dark] tag and can cast your Death Bolt on a 4 turn cooldown\nTheir song now heals only allies and damages only enemies", [Tags.Dark])


	def get_description(self):
		return "Summon [{num_summons}:num_summons] temporary Angelic Singers"

	def get_impacted_tiles(self, x, y):
		return [Point(x, y)]

	def angel(self):
		angel = make_minion(self, AngelicSinger)
		if self.get_stat('unending_song'): angel.apply_buff(ReincarnationBuff())
		if self.get_stat('cast_deathbolt'):
			angel.tags.append(Tags.Dark)
			angel.get_spell(AngelSong).friendly_fire = False
			grant_minion_spell(DeathBolt, angel, self.caster, cool_down=4)
		if self.get_stat('salvation'): angel.get_spell(AngelSong).salvation = True
		return angel

	def cast(self, x, y):
		for i in range(self.get_stat('num_summons')):
			self.summon(self.angel(), Point(x, y))
			yield

	def get_extra_examine_tooltips(self):
		return [self.angel()] + self.get_upgrade_tooltips()

class HeavensWrath(Spell):

	def on_init(self):

		self.name = "Heaven's Wrath"
		self.tags = [Tags.Holy, Tags.Lightning, Tags.Sorcery]
		self.damage_type = [Tags.Holy, Tags.Lightning]
		self.range = 0
		self.num_targets = 3
		self.damage = 22
		self.level = 6
		self.max_charges = 4

		self.upgrades['culling'] = (1, 4, "Culling" ,"Heaven's Wrath also damages the units with the lowest current HP")
		self.upgrades[('stun', 'duration')] = ([1, 3], 2, "Halt Heretics", "Heaven's Wrath also [stuns] affected units for [{duration}:duration] turns")
		self.upgrades['deal_fire'] = (1, 3, "Fiery Wrath", "Heaven's Wrath also deals [Fire] damage", [Tags.Fire], [Tags.Fire])
		self.upgrades['promise'] = (1, 6, "Heaven's Promise", "Cast Seal Fate on units which survive the damage from Heaven's Wrath", [Tags.Dark])

	def get_description(self):
		return ("Deal [{damage}:damage] [Lightning] and [Holy] damage to the [{num_targets}:num_targets] enemies with the highest current HP")

	def cast(self, x, y):

		orders = [-1]
		if self.get_stat('culling'): orders.append(1)

		caster = self.caster

		dmg = self.get_stat('damage')
		dtypes = self.get_stat('damage_type')
		deal_damage = caster.level.deal_damage

		stun = self.get_stat('stun')
		dur = self.get_stat('duration') if stun else 0

		promise = self.get_stat('promise')
		if promise: cast_seal = caster.level.act_cast; seal = caster.get_or_make_spell(SealFate)

		for order in orders:
			units = [u for u in caster.level.units if are_hostile(u, caster)]
			random.shuffle(units)
			units = sorted(units,  key=lambda u: order * u.cur_hp)
			units = units[:self.get_stat('num_targets')]

			for unit in units:
				for dtype in dtypes: deal_damage(unit.x, unit.y, dmg, dtype, self)
				for i in range(3): yield
				if stun: unit.apply_buff(Stun(), dur)
				if promise and unit.is_alive(): cast_seal(caster, seal, unit.x, unit.y, pay_costs=False)

class MortalityDeferredBuff(Buff):

	def __init__(self):
		Buff.__init__(self)
		self.heal = 1
		self.stack_type = STACK_NONE
		self.name = "Regeneration"
		self.buff_type = BUFF_TYPE_PASSIVE
		self.color = Tags.Holy.color
		self.asset = ['status', 'heal']

	def get_description(self):
		return ("Regenerates {heal} HP per turn", {"heal": self.heal})

	def on_applied(self, owner):
		for b in owner.buffs:
			if b.buff_type == BUFF_TYPE_CURSE:
				owner.remove_buff(b)

	def on_advance(self):
		if self.owner.cur_hp < self.owner.max_hp:
			self.owner.deal_damage(-self.heal, Tags.Heal, self)

class BestowImmortality(Spell):

	def on_init(self):

		self.name = "Suspend Mortality"
		self.tags = [Tags.Dark, Tags.Holy, Tags.Enchantment]

		self.lives = 1
		self.level = 3

		self.max_charges = 5

		self.requires_los = False
		self.range = 5

		self.upgrades['deferred'] = (1, 2, "Mortality Deferred", "Cleanses all debuffs from the target and grants them a stacking regeneration effect that heals 1 HP each turn\nThis buff persists across reincarnations")
		self.upgrades['essence'] = (1, 3, "Twilight Essence", "Affected unit gains the [Holy] and [Undead] tags along with 100% [Holy] and [Dark] resist")
		self.upgrades['lives'] = (2, 4, "Endlessness", "Grants 3 reincarnations instead of just 1")
		self.upgrades['mass'] = (1, 7, "Mass Immortality", "Allies with the same name as the target are also affected")

	def get_description(self):
		return "Target ally gains the ability to reincarnate on death"

	def can_cast(self, x, y):
		unit = self.caster.level.get_unit_at(x, y)
		return unit and unit != self.caster and not unit.is_player_controlled and unit.team == self.caster.team and Spell.can_cast(self, x, y)

	def can_harm(self, target_unit):
		return target_unit != self.caster and not target_unit.is_player_controlled and target_unit.team == self.caster.team

	def get_impacted_tiles(self, x, y):
		unit = self.caster.level.get_unit_at(x, y)
		units = [unit]
		if self.get_stat('mass'): units = [u for u in self.owner.level.units if unit.team == u.team and u.name == unit.name]

		return [Point(u.x, u.y) for u in units]

	def cast(self, x, y):
		unit = self.caster.level.get_unit_at(x, y)
		units = [unit]
		if self.get_stat('mass'): units = [u for u in self.owner.level.units if u.team == unit.team and u.name == unit.name]

		deferred = self.get_stat('deferred')
		lives = self.get_stat('lives')
		essence = self.get_stat('essence')

		for u in units:
			buff = u.get_buff(ReincarnationBuff)
			if not buff: u.apply_buff(ReincarnationBuff(lives))
			if buff: buff.lives += lives

			if deferred:
				b = u.get_buff(MortalityDeferredBuff)
				if not b: u.apply_buff(MortalityDeferredBuff())
				elif b: b.heal += 1

			if essence:
				u.resists[Tags.Dark] += 100
				u.resists[Tags.Holy] += 100
				if Tags.Undead not in u.tags: u.tags.append(Tags.Undead)
				if Tags.Holy not in u.tags: u.tags.append(Tags.Holy)

			self.owner.level.show_path_effect(self.caster, u, [Tags.Holy, Tags.Dark], minor=True, inclusive=False)
			yield
			self.owner.level.show_effect(u.x, u.y, Tags.Buff_Apply, Tags.Holy.color)
			yield

	def get_ai_target(self):
		elligible_targets = [u for u in self.caster.level.get_units_in_ball(self.caster, self.range) if self.can_cast(u.x, u.y)]
		if elligible_targets:
			random.shuffle(elligible_targets)
			def return_reincarnations(unit):
				buff = unit.get_buff(ReincarnationBuff)
				if buff: return buff.lives
				else: return -1
			return min(elligible_targets, key=lambda u: return_reincarnations(u))
		else: return None

class SoulDebt(Buff):

	def __init__(self, caster=None):
		Buff.__init__(self)
		self.wizard = caster

	def on_init(self):
		self.name = "Soul Debt"
		self.color = Tags.Blood.color
		self.stack_type = STACK_NONE
		self.buff_type = BUFF_TYPE_CURSE

	def on_applied(self, owner):
		if not self.wizard: return
		def heal_handler(amount, damage_type, source, redirect_chain):
			if amount > 0: return None
			lvl = owner.level
			dealt = lvl.deal_redirected_damage(self, self.wizard.x, self.wizard.y, amount, damage_type, source, redirect_chain)
			if dealt: lvl.show_path_effect(owner, self.wizard, Tags.Blood, minor=True)
			return dealt
		owner.grant_redirect(self, heal_handler)

	def on_unapplied(self):
		self.owner.remove_redirect(self)

	def get_description(self):
		return "Any healing is redirected to the inflictor"

class SoulTax(Spell):

	def on_init(self):

		self.name = "Soul Tax"

		self.level = 5
		self.range = 4

		self.tags = [Tags.Sorcery, Tags.Dark, Tags.Holy]
		self.damage_type = [Tags.Holy, Tags.Dark]
		self.max_charges = 3
		self.arcane = 0

		self.upgrades['arcane'] = (1, 3, "Arcane Taxation", "Soul Tax deals an additional third of the target's remaining HP as [Arcane] damage", [Tags.Arcane], [Tags.Arcane])
		self.upgrades['quick_cast'] = (1, 2, "Insta Tax", "Soul Tax gains quickcast")
		self.upgrades['target_group'] = (1, 6, "Mass Taxation", "Affects a connected group of enemies")
		self.upgrades[('debt', 'hp_cost')] = ([1, 25], 5, "Soul Debt", "Soul Tax inflicts the [Soul Debt:blood] debuff\n[Soul Debt:blood] redirects healing from the cursed unit to you", [Tags.Blood])

		self.add_upgrade_tooltip("Soul Debt", lambda: SoulDebt(self.caster))

	def get_description(self):
		return ("Deal damage to the target equal to one third of its HP as [Holy] damage, and then one third of its remaining HP as [Dark] damage\n"
				"Heals the caster for the damage dealt")

	def can_cast(self, x, y):
		unit = self.caster.level.get_unit_at(x, y)
		if not unit: return False
		if unit.is_player_controlled: return False
		return Spell.can_cast(self, x, y)

	def get_impacted_tiles(self, x, y):
		if not self.get_stat('target_group'): return [Point(x, y)]
		else: return self.caster.level.get_connected_group_from_point(x, y, check_hostile=self.caster)

	def cast(self, x, y):
		units = [self.caster.level.get_unit_at(x, y)]
		if self.get_stat('target_group'): units = self.caster.level.get_connected_group_from_point(x, y, check_hostile=self.caster)
		debt = self.get_stat('debt')
		dtypes = self.damage_type
		for unit in units:
			if not unit: break
			for dtype in dtypes:
				damage = unit.cur_hp // 3
				dealt = unit.deal_damage(damage, dtype, self)
				self.caster.deal_damage(-dealt, Tags.Heal, self)
				for i in range(4): yield
				if not unit.is_alive(): break
			if debt and unit.is_alive(): unit.apply_buff(SoulDebt(self.caster))
			yield


class BlindingLightSpell(Spell):

	def on_init(self):
		self.name = "Blinding Light"

		self.range = 0
		self.max_charges = 3
		self.duration = 4
		self.damage = 5

		self.tags = [Tags.Holy, Tags.Eye, Tags.Sorcery]
		self.damage_type = [Tags.Holy]
		self.level = 3

		self.upgrades['inflict_stun'] = (1, 5, "Halting Light", "[Stuns] affected enemies for [{duration} turn:duration] turns", None, None, {'duration':2})
		self.upgrades['deal_fire'] = (1, 4, "Searing Light", "Blinding Light also deals [{damage}:damage] [Fire] damage to enemies in line of sight", [Tags.Fire], [Tags.Fire], {'damage':5})
		self.upgrades['quick_cast'] = (1, 3, "Quickcast", "Blinding Light gains quickcast")
		self.upgrades['angel'] = (100, 5, "Angelic Visions", "For every 100 damage dealt by a single cast of Blinding Light, cast your Choir of Angels spell")

	def get_description(self):
		return ("[Blind] units in line of sight of the caster for [{duration}:duration] turns"
				"\nDeal [{damage}:damage] [Holy] damage to affected [Undead] and [Demon] units")

	def get_impacted_tiles(self, x, y):
		return [u for u in self.caster.level.get_units_in_los(self.caster) if u != self.caster]

	def cast(self, x, y):
		caster = self.caster
		level = caster.level

		targets = [u for u in level.get_units_in_los(caster) if u != caster]
		targets = sorted(targets, key=lambda u: distance(u, caster))
		dmg = self.get_stat('damage')
		dur = self.get_stat('duration')

		fire = self.get_stat('deal_fire')
		stun = self.get_stat('inflict_stun')
		stun_dur = self.get_stat('duration', base=2)

		dealt = 0

		for target in targets:
			target.apply_buff(BlindBuff(), dur)
			if target.has_tags([Tags.Undead, Tags.Demon]): dealt += target.deal_damage(dmg, Tags.Holy, self)
			if are_friendly(caster, target): continue
			if fire: dealt += target.deal_damage(dmg, Tags.Fire, self)
			if stun: target.apply_buff(Stun(), stun_dur)
			yield

		angel = self.get_stat('angel')
		if angel and dealt >= angel:
			s = caster.get_or_make_spell(ChoirOfAngels)
			while dealt >= angel:
				for _ in level.act_cast(caster, s, caster.x, caster.y, pay_costs=False, queue=False): yield
				dealt -= angel

class FlockOfEaglesSpell(Spell):

	def on_init(self):
		self.tags = [Tags.Conjuration, Tags.Nature, Tags.Holy]
		self.level = 5
		self.name = "Flock of Eagles"
		self.range = 0

		self.minion_health = 22
		self.minion_damage = 5
		self.minion_range = 5
		self.num_summons = 4
		self.shields = 0

		self.max_charges = 3

		self.upgrades['shields'] = (3, 1, "Shielded Eagles")
		self.upgrades['awe'] = (1, 4, "Untouchable Majesty", "Eagles deal 10 [Holy] damage to enemies that damage them")
		self.upgrades['thunderbirds'] = (1, 5, "Thunder Claw", "Summon a Flock of Thunder Birds instead, which can cast your Thunder Strike on a 15 turn cool down", [Tags.Lightning])
		self.upgrades['num_summons'] = (4, 6, "Army of Eagles")

		self.add_upgrade_tooltip("Thunder Claw", lambda: self.make_eagle(Thunderbird))

	def get_extra_examine_tooltips(self):
		return [self.make_eagle()] + self.get_upgrade_tooltips()

	def get_description(self):
		return "Summon [{num_summons}:num_summons] Eagles nearby"

	def make_eagle(self, spawn_fn=None):
		if spawn_fn is None: spawn_fn = Thunderbird if self.get_stat('thunderbirds') else Eagle
		eagle = make_minion(self, spawn_fn)
		if spawn_fn == Thunderbird: grant_minion_spell(ThunderStrike, eagle, self.caster, cool_down=15)
		if self.get_stat('awe'): eagle.buffs.append(RetaliationBuff(damage=10, dtype=Tags.Holy))
		if self.get_stat('shields'): eagle.shields += self.get_stat('shields')
		return eagle

	def cast_instant(self, x, y):
		for i in range(self.get_stat('num_summons')):
			self.summon(self.make_eagle(), Point(x, y))

class BeautyIdolBuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)

	def on_init(self):
		self.buff_type = BUFF_TYPE_PASSIVE

	def on_applied(self, owner):
		self.name = "Beauty"

	def on_advance(self):
		units = self.owner.level.get_units_in_los(self.owner)
		for u in units:
			if u == self.owner: continue
			if are_hostile(u, self.owner): u.deal_damage(1, Tags.Holy, self)
			else: u.heal(1, self)
		if len(units) == 1 and self.spell.get_stat('move'): randomly_teleport(self.owner, 25) # if the only thing it can see is itself, move

	def get_tooltip(self):
		return "Deals 1 [Holy] damage to enemies in line of sight\nHeals allies in line of sight for 1 HP"

class HeavenlyIdolShieldGazeSpell(Spell):

	def on_init(self):
		self.name = "Shield Gaze"
		self.can_target_self = True

	def get_description(self):
		return ("Set the SH of a unit with less than 4 SH to 4 SH")

	def can_harm(self, target_unit):
		return not are_hostile(target_unit, self.caster) and target_unit != self.caster and target_unit.shields < 4

	def cast(self, x, y):
		unit = self.caster.level.get_unit_at(x, y)
		if unit:
			unit.shields = 4
			for p in self.caster.level.get_points_in_line(self.caster, unit):
				self.caster.level.deal_damage(p.x, p.y, 0, Tags.Holy, self)
		yield

	def get_ai_target(self):
		elligible_targets = [u for u in self.caster.level.units
							 if not are_hostile(u, self.caster)
							 and u.shields < 4
							 and u != self.caster
							 and self.can_cast(u.x, u.y)]
		if not elligible_targets: return None
		random.shuffle(elligible_targets)
		unit = min(elligible_targets, key=lambda u: u.shields)
		return unit



class HeavenlyIdol(Spell):

	def on_init(self):

		self.name = "Heavenly Idol"

		self.level = 5
		self.tags = [Tags.Holy, Tags.Conjuration]

		self.max_charges = 4
		self.minion_health = 35
		self.shields = 2
		self.minion_duration = 15

		self.upgrades['move'] = (1, 1, "Lonely Idol", "If there are no units in the idol's line of sight at the end of its turn, it will teleport to a random location", [Tags.Translocation])
		self.upgrades[('fire_gaze', 'minion_damage', 'minion_range')] = ([1, 10, 10], 4, "Fire Gaze", "Heavenly Idol gains a [{minion_damage}:minion_damage] damage, [{minion_range}:minion_range] range, [Fire] attack", [Tags.Fire])
		self.upgrades['shield_gaze'] = (1, 3, "Shield Gaze", "Heavenly Idol gains Shield Gaze, which sets the [SH:shields] of an ally with less than [4 SH:shields] to [4 SH:shields]")
		self.upgrades['immortality'] = (1, 5, "Bastion of Immortality", "Heavenly Idol can cast your Suspend Mortality on a 5 turn cooldown\nCannot target the Wizard")

		self.must_target_walkable = True
		self.must_target_empty = True

	def get_description(self):
		return "Summon a Heavenly Idol"

	def make_idol(self):
		idol = Unit()
		idol.name = "Heavenly Idol"
		idol.asset_name = "heavenly_idol"

		idol.max_hp = self.get_stat('minion_health')
		idol.shields = self.get_stat('shields')
		idol.stationary = True

		idol.resists[Tags.Physical] = 75

		idol.tags = [Tags.Construct, Tags.Holy]

		idol.buffs.append(BeautyIdolBuff(self))
		idol.turns_to_death = self.get_stat('minion_duration')
		return idol

	def cast_instant(self, x, y):
		idol = self.make_idol()
		if self.get_stat('immortality'):
			grant_minion_spell(BestowImmortality, idol, self.caster, cool_down=5)
		if self.get_stat('shield_gaze'):
			gaze = HeavenlyIdolShieldGazeSpell()
			idol.spells.append(gaze)
		if self.get_stat("fire_gaze"):
			idol.spells.append(SimpleRangedAttack(name='Fiery Gaze', damage=self.get_stat('minion_damage'), range=self.get_stat('minion_damage'), damage_type=Tags.Fire))
		self.summon(idol, Point(x, y))

	def get_extra_examine_tooltips(self):
		return [self.make_idol()] + self.get_upgrade_tooltips()

class SummonGoldDrakeSpell(Spell):

	def on_init(self):
		self.name = "Gold Drake"
		self.range = 4
		self.max_charges = 2
		self.tags = [Tags.Holy, Tags.Conjuration, Tags.Dragon]
		self.level = 6
		self.must_target_empty = True

		self.minion_health = 48
		self.minion_damage = 9
		self.minion_range = 5

		self.upgrades['immortal_dragon'] = (1, 2, "Immortal Dragon", "Gold Drake will reincarnate 3 times")
		self.upgrades['dragon_saint'] = (1, 4, "Dragon Saint", "Gold Drake deals [{minion_damage}:minion_damage] [Holy] damage to enemies that damage it", None, None, {'minion_damage':14})
		self.upgrades['dragon_mage'] = (1, 3, "Dragon Mage", "Gold Drakes can cast your Healing Light on an 8 turn cooldown")
		self.upgrades['treasure_seekers'] = (1, 1, "Treasure Seekers", "If you cast this spell targeting a Component or a Memory Orb, it is added to your inventory as though you had picked it up\nIf it was a Component with an On Pickup effect, that effect is also applied to the drake")


	def make_gold_drake(self):
		u = GoldDrake()
		if self.get_stat('dragon_saint'): buff = RetaliationBuff(self.get_stat('minion_damage', base=14), Tags.Holy); buff.name = "Dragon Saint"; u.apply_buff(buff)
		if self.get_stat('immortal_dragon'): u.apply_buff(ReincarnationBuff(3))
		if self.get_stat('dragon_mage'): grant_minion_spell(HealingLight, u, self.caster, cool_down=8, pre_insert=True)
		apply_minion_bonuses(self, u)
		return u

	def cast_instant(self, x, y):
		u = self.summon(self.make_gold_drake(), Point(x, y))
		if not self.get_stat('treasure_seekers'): return
		level = self.caster.level
		prop = level.tiles[x][y].prop
		if not prop: return
		if not isinstance(prop, (ComponentPickup, MemoryOrb)): return
		if isinstance(prop, MemoryOrb): prop.on_player_enter(level.player_unit)
		elif isinstance(prop, ComponentPickup):
			prop.on_player_enter(level.player_unit)
			if not u: return
			prop.component.on_pickup(u, level)


	def get_description(self):
		return "Summon a Gold Drake"

	def get_extra_examine_tooltips(self):
		return [self.make_gold_drake()] + self.get_upgrade_tooltips()

class SeraphimSwordSwing(Spell):

	def on_init(self):
		self.name = "Flaming Sword"
		self.description = "Deals damage in an arc"
		self.range = 1.5
		self.melee = True
		self.can_target_self = False

		self.damage = 14
		self.damage_type = [Tags.Fire, Tags.Holy]

	def get_impacted_tiles(self, x, y):
		ball = self.caster.level.get_points_in_ball(x, y, 1, diag=True)
		aoe = [p for p in ball if 1 <= distance(p, self.caster, diag=True) < 2]
		return aoe

	def cast(self, x, y):
		dtypes = [Tags.Fire, Tags.Holy]
		if self.arcane: dtypes += [Tags.Arcane]
		for p in self.get_impacted_tiles(x, y):
			for dtype in dtypes:
				# Never hit friendly units, is angel
				unit = self.caster.level.get_unit_at(p.x, p.y)
				if unit and not are_hostile(self.caster, unit):
					continue
				self.caster.level.deal_damage(p.x, p.y, self.get_stat('damage'), dtype, self)
				yield
#
class SummonSeraphim(Spell):

	def on_init(self):
		self.level =4
		self.name = "Call Seraph"
		self.range = 4
		self.must_target_empty = True
		self.max_charges = 3
		self.tags = [Tags.Holy, Tags.Fire, Tags.Conjuration]

		self.minion_health = 96
		self.shields = 8
		self.minion_damage = 14
		self.minion_duration = 20

		self.upgrades['quick'] = (1, 2, "Quickened Seraphs", "The Seraphs gain [quickstep:translocation]")
		self.upgrades['moonblade'] = (1, 3, "Moonblade", "The Seraphs' cleave attack also deals [Arcane] damage", [Tags.Arcane])
		self.upgrades[('heal', 'radius')] = ([4, 3], 4, "Healing Aura", "The Seraphs heal allies within [{radius}:radius] tiles for 4 HP each turn")
		self.upgrades[('holy_fire', 'radius')] = ([1, 3], 7, "Holy Fire Aura", "The Seraphs gain a damage aura, dealing [{minion_damage}:minion_damage] [Fire] or [Holy] damage to enemies within [{radius}:radius] tiles each turn", None, None, {'minion_damage':2})


	def get_description(self):
		return "Summon a temporary Seraph"

	def make_angel(self):
		angel = Unit()
		angel.name = "Seraph"
		angel.asset_name = "seraphim"
		angel.tags = [Tags.Holy]

		angel.max_hp = self.get_stat('minion_health')
		angel.shields = self.get_stat('shields')

		angel.resists[Tags.Holy] = 100
		angel.resists[Tags.Dark] = 75
		angel.resists[Tags.Fire] = 75

		sword = SeraphimSwordSwing()
		sword.damage = self.get_stat('minion_damage')
		sword.arcane = self.get_stat('moonblade')
		if self.get_stat('moonblade'): sword.damage_type = [Tags.Fire, Tags.Holy, Tags.Arcane]

		angel.spells.append(sword)
		angel.flying = True
		if self.get_stat('heal'): angel.buffs.append(HealAuraBuff(self.get_stat('heal'), self.get_stat('radius')))

		if self.get_stat('holy_fire'):
			aura = DamageAuraBuff(damage=self.get_stat('minion_damage', base=2), damage_type=[Tags.Fire, Tags.Holy], radius=self.get_stat('radius'))
			angel.buffs.append(aura)

		if self.get_stat('quick'): angel.buffs.append(QuickmoveBuff())

		angel.turns_to_death = self.get_stat('minion_duration')
		return angel

	def cast_instant(self, x, y):
		angel = self.make_angel()
		self.summon(angel, Point(x, y))

	def get_extra_examine_tooltips(self):
		return [self.make_angel()] + self.get_upgrade_tooltips()

class ArchonLightning(Spell):

	def on_init(self):
		self.name = "Archon Beam"
		self.description = "Beam attack\nAllies gain [1 SH:shields] instead"
		self.damage_type = [Tags.Lightning]
		self.damage = 14
		self.range = 7
		self.flood = False
		self.healing = False
		self.cascade = False


	def cast_instant(self, x, y):
		target = Point(x, y)
		damage = self.get_stat('damage')
		level = self.caster.level
		pts = level.get_points_in_line(self.caster, target, find_clear=self.get_stat('requires_los'))[1:]
		if self.cascade:
			eligible_units = [u for u in level.get_units_in_los(target) if are_hostile(u, self.caster)]
			if eligible_units: pts.extend(self.caster.level.get_points_in_line(Point(x, y), random.choice(eligible_units), find_clear=True)[1:])

		for p in pts:
			if self.flood: level.add_obj(RainCloud(self.caster), p.x, p.y)
			u = level.get_unit_at(p.x, p.y)
			if u and are_friendly(u, self.caster):
				u.add_shields(1)
				if self.healing: u.heal(damage, self)
				continue # go on to next pt if a friend was there
			for dt in self.damage_type: level.deal_damage(p.x, p.y, damage, dt, self)

class SummonArchon(Spell):

	def on_init(self):

		self.level = 5
		self.name = "Call Archon"
		self.tags = [Tags.Lightning, Tags.Holy, Tags.Conjuration]
		self.max_charges = 3
		self.must_target_empty = True

		self.minion_health = 77
		self.shields = 3
		self.minion_damage = 14
		self.minion_range = 7
		self.minion_duration = 14

		self.upgrades['flood'] = (1, 1, "Flood Heralds", "The Archon's beam summons [Rain Clouds:nature] on affected tiles")
		self.upgrades['healing'] = (1, 2, "Healing Beam", "The Archon's beam also heals allies it passes through")
		self.upgrades['cascade'] = (1, 4, "Beam Arc", "The Archon's beam arcs once to an enemy in line of sight of its target")
		self.upgrades['storm_archon'] = (1, 5, "Storm Archon", "Archons gain the [Ice] tag, [50% Ice:ice] resist, and their beam also deals [Ice] damage", [Tags.Ice])

		self.add_upgrade_tooltip("Storm Archon", self.make_storm_archon)

	def get_description(self):
		return "Summon a temporary Archon"

	def make_archon(self):
		angel = Unit()
		angel.name = "Archon"
		angel.tags = [Tags.Holy]

		angel.max_hp = self.get_stat('minion_health')
		angel.shields = self.get_stat('shields')

		angel.resists[Tags.Holy] = 100
		angel.resists[Tags.Dark] = 75
		angel.resists[Tags.Lightning] = 75

		lightning = ArchonLightning()
		lightning.damage = self.get_stat('minion_damage')
		lightning.range = self.get_stat('minion_range')
		lightning.healing = self.get_stat('healing')
		lightning.cascade = self.get_stat('cascade')
		lightning.flood = self.get_stat('flood')

		angel.spells.append(lightning)
		angel.flying = True

		angel.turns_to_death = self.get_stat('minion_duration')
		return angel

	def make_storm_archon(self):
		angel = self.make_archon()
		angel.name = "Storm Archon"
		angel.asset_name = "archon_storm"
		angel.tags.append(Tags.Ice)
		angel.resists[Tags.Ice] = 50
		angel.spells[0].damage_type = [Tags.Ice, Tags.Lightning]
		return angel

	def cast_instant(self, x, y):
		if self.get_stat('storm_archon'): angel = self.make_storm_archon()
		else: angel = self.make_archon()
		self.summon(angel, Point(x, y))

	def get_extra_examine_tooltips(self):
		return [self.make_archon()] + self.get_upgrade_tooltips()

class PainMirror(Buff):

	def __init__(self, source=None):
		self.source = source
		Buff.__init__(self)

	def on_init(self):
		self.name = "Pain Mirror"
		trigger = EventOnPreDamaged if self.source.get_stat('illusory') else EventOnDamaged
		self.owner_triggers[trigger] = self.on_damage
		self.owner_triggers[EventOnSpendHP] =self.on_spend_hp
		self.color = Tags.Dark.color
		self.dmg_tags = [Tags.Dark]
		self.dealt = 0
		self.do_summon = 0
		self.asset = ["status", "pain_mirror"]

	def on_damage(self, event):
		if event.damage <= 0: return
		self.owner.level.queue_spell(self.reflect(event.damage))

	def on_spend_hp(self, evt):
		self.owner.level.queue_spell(self.reflect(evt.hp))

	def reflect(self, damage):
		for u in self.owner.level.get_units_in_los(self.owner):
			if are_hostile(self.owner, u):
				for tag in self.dmg_tags:
					self.dealt += u.deal_damage(damage, tag, self.source or self)
					yield

		if not self.do_summon: return
		while self.dealt > 30:
			self.summon(make_minion(self.source, Pain), sort_dist=False)
			self.dealt -= 30

	def get_description(self):
		desc =  ["When you take damage or spend HP, deal that much [Dark] damage to enemies in line of sight"]
		if self.do_summon: desc.append(("Dealt:\n {dealt} / 30", {"dealt":self.dealt}))
		return desc


class PainMirrorSpell(Spell):

	def on_init(self):
		self.tags = [Tags.Blood, Tags.Enchantment]
		self.name = "Pain Mirror"
		self.range = 0
		self.duration = 14
		self.hp_cost = 11
		self.level = 4
		self.max_charges = 1

		self.upgrades['seeker'] = (1, 2, "Pain Seeker", "Casting Pain Mirror also grants [quickstep:translocation] for the same duration", [Tags.Translocation])
		self.upgrades['illusory'] = (1, 1, "Illusory Pain", "Pain Mirror's outgoing damage is based on pre-resistance values, rather than actual damage taken")
		self.upgrades['deal_fire'] = (1, 6, "Burning Pain", "Pain Mirror also deals [Fire] damage", [Tags.Fire])
		self.upgrades[('do_summon', 'minion_health', 'minion_range', 'minion_damage', 'minion_duration')] = ([1, 24, 4, 6, 3], 7, "Spirits of Pain", "For every 30 damage dealt by Pain Mirror, summon a temporary Pain nearby", [Tags.Conjuration, Tags.Lightning])

		self.add_upgrade_tooltip("Spirits of Pain", lambda: make_minion(self, Pain))

	def get_pain_mirror_buff(self):
		buff = PainMirror(self)
		if self.get_stat('deal_fire'): buff.dmg_tags.append(Tags.Fire)
		buff.do_summon = self.get_stat('do_summon')
		return buff

	def cast_instant(self, x, y):
		buff = self.get_pain_mirror_buff()
		dur = self.get_stat('duration')
		self.caster.apply_buff(buff, dur)
		if self.get_stat('seeker'): self.caster.apply_buff(QuickmoveBuff(), dur)

	def get_description(self):
		return ("When you take damage or spend HP, deal that much [Dark] damage to enemies in your line of sight\n"
				"Lasts [{duration}:duration] turns")

	def get_extra_examine_tooltips(self):
		return [self.get_pain_mirror_buff()] + self.get_upgrade_tooltips()

class PyrostaticPulse(Spell):

	def on_init(self):
		self.name = "Pyrostatic Pulse"
		self.level = 2

		self.damage = 16

		self.max_charges = 10
		self.range = 5
		self.tags = [Tags.Fire, Tags.Lightning, Tags.Sorcery]
		self.damage_type = [Tags.Fire, Tags.Lightning]

		self.upgrades['chaos'] = (1, 4, "Chaos Pulse", "Pyrostatic Pulse gains a [Physical] damage outer layer", [Tags.Chaos], [Tags.Physical])
		self.upgrades['range'] = (25, 3, "Unstoppable Pulse")
		self.upgrades[('greater_cascade', 'num_targets')] = ([1, 2], 7, "Forking Cascade", "Secondary pulses trigger from the target to up to [{num_targets}:num_targets] random enemies in line of sight of the target")
		self.upgrades[('spirit_calling', 'minion_health', 'minion_damage')] = ([1, 10, 5], 6, "Spirit Calling", "Summons Fire Spirits for units killed by the [Fire] beam, and Spark Spirits for those killed by the [Lightning] beams\nIf you have the Chaos Pulse upgrade, any units killed by this spell summon Chaos Spirits instead", [Tags.Conjuration])
		self.add_upgrade_tooltip("Spirit Calling", self.make_fire_spirit_preview, self.make_spark_spirit_preview, self.make_chaos_spirit_preview)

		self.dt_to_spirit_dict = {Tags.Fire: FireSpirit, Tags.Lightning: SparkSpirit}

	def get_description(self):
		return ("Deal [{damage}:damage] [Fire] damage in a beam\n"
				"Deal [{damage}:damage] [Lightning] damage to tiles adjacent to the beam")


	def make_fire_spirit_preview(self):
		return make_minion(self, FireSpirit)

	def make_spark_spirit_preview(self):
		return make_minion(self, SparkSpirit)

	def make_chaos_spirit_preview(self):
		return make_minion(self, ChaosSpirit)

	def get_impacted_tiles(self, x, y):
		center_beam = self.caster.level.get_points_in_line(self.caster, Point(x, y), find_clear=True)[1:]
		side_beam = []
		physical_beam = []
		for p in center_beam:
			for q in self.caster.level.get_points_in_ball(p.x, p.y, 1.5):
				if q.x == self.caster.x and q.y == self.caster.y: continue
				if q not in center_beam and q not in side_beam: side_beam.append(q)

		chaos = self.get_stat('chaos')
		if chaos:
			for p in side_beam:
				for q in self.caster.level.get_points_in_ball(p.x, p.y, 1.5):
					if q.x == self.caster.x and q.y == self.caster.y: continue
					if chaos and q not in center_beam and q not in side_beam and q not in physical_beam:
						physical_beam.append(q)

		return center_beam + side_beam + physical_beam

	def cast(self, x, y, fork_point=None):
		caster = self.caster
		level = caster.level

		# Build the beams
		start = fork_point if fork_point else caster

		center_beam = level.get_points_in_line(start, Point(x, y), find_clear=True)[1:]
		side_beam = []
		physical_beam = []

		for p in center_beam:
			for q in level.get_points_in_ball(p.x, p.y, 1.5):
				if q.x == caster.x and q.y == caster.y: continue
				if q not in center_beam and q not in side_beam: side_beam.append(q)

		chaos = self.get_stat('chaos')

		if chaos: # only build if we have the upgrade
			for p in side_beam:
				for q in level.get_points_in_ball(p.x, p.y, 1.5):
					if q.x == caster.x and q.y == caster.y: continue
					if chaos and q not in center_beam and q not in side_beam and q not in physical_beam:
						physical_beam.append(q)

		dmg = self.get_stat('damage')
		spirits = self.get_stat('spirit_calling')

		killed = set()

		for p in center_beam:
			unit = level.get_unit_at(p.x, p.y)
			level.deal_damage(p.x, p.y, dmg, Tags.Fire, self)
			if spirits and unit and not unit.is_alive(): killed.add((unit, Tags.Fire))
		yield

		for p in side_beam:
			unit = level.get_unit_at(p.x, p.y)
			level.deal_damage(p.x, p.y, dmg, Tags.Lightning, self)
			if spirits and unit and not unit.is_alive(): killed.add((unit, Tags.Lightning))
		yield

		for p in physical_beam:
			unit = level.get_unit_at(p.x, p.y)
			level.deal_damage(p.x, p.y, dmg, Tags.Physical, self)
			if spirits and unit and not unit.is_alive(): killed.add((unit, Tags.Physical))
		yield

		yield

		if self.get_stat('greater_cascade') and fork_point is None:
			elligible_targets = [u for u in level.get_units_in_los(Point(x, y)) if are_hostile(u, caster)]
			random.shuffle(elligible_targets)
			for t in elligible_targets[:self.get_stat('num_targets')]:
				level.queue_spell(self.cast(t.x, t.y, fork_point=Point(x, y)))

		if killed: level.queue_spell(self.do_summons(killed))

	def do_summons(self, targets):
		if self.get_stat('chaos'): summon_fn = lambda dt: ChaosSpirit
		else: summon_fn = lambda dt: self.dt_to_spirit_dict.get(dt)
		for target, dt in targets: self.summon(make_minion(self, summon_fn(dt)), target=target)
		yield

class OcularShieldsBuff(TagAttrBonus):

	def __init__(self, shields):
		TagAttrBonus.__init__(self, Tags.Eye, 'damage', shields*10, custom_name="Ocular Shield Lensing", pct=True)
		self.stack_type = STACK_REPLACE
		self.owner_triggers[EventOnShieldRemoved] = self.on_unshielded

	def on_unshielded(self, evt):
		if self.owner.shields: return
		self.owner.remove_buff(self)

class RetributiveSiphon(Upgrade):

	def __init__(self, spell):
		self.spell = spell
		Upgrade.__init__(self, spell)

	def on_init(self):
		self.name = "Retributive Siphon"
		self.description = "If a shielded unit damages you, steal one of their shields\nAlways Active"
		self.level = 3
		self.owner_triggers[EventOnDamaged] = self.on_damaged

	def on_damaged(self, evt):
		if evt.damage < 1: return
		if not evt.source: return
		if not evt.source.owner: return
		if evt.source.owner == self.owner: return
		if not evt.source.owner.shields: return
		evt.source.owner.shields -= 1
		self.owner.level.show_effect(evt.source.owner.x, evt.source.owner.y, Tags.Shield_Expire)
		self.owner.add_shields(1)

		if not self.spell.get_stat('shield_burn'): return
		evt.source.owner.deal_damage(self.spell.get_stat('damage'), Tags.Fire, self.spell)


class ShieldSiphon(Spell):

	def on_init(self):
		self.name = "Siphon Shields"

		self.max_charges = 2
		self.level = 3

		self.tags = [Tags.Arcane, Tags.Enchantment]
		self.range = 0
		self.shield_steal = 3

		self.upgrades[('shield_burn', 'damage')] = ([1, 5], 2, "Shield Burn", "Deal [{damage}:damage] [Fire] damage for each shield stolen", [Tags.Fire])
		self.upgrades['shield_steal'] = (7, 3)
		self.upgrades['lensing'] = (1, 4, "Ocular Lensing", "After casting Siphon Shields, your [Eye] spells get a 10% [damage] bonus for each [SH:shields] you have\nThis bonus lasts until your shields are completely removed or you cast this spell again", [Tags.Eye])
		self.add_upgrade(RetributiveSiphon(self))


	def get_impacted_tiles(self, x, y):
		return [u for u in self.caster.level.get_units_in_los(self.caster) if are_hostile(u, self.caster) and u.shields]

	def get_description(self):
		return ("Steal up to [{shield_steal} SH:shields] from all enemies in line of sight")

	def cast(self, x, y):
		caster = self.caster
		level = caster.level

		total = 0
		targets = [u for u in level.get_units_in_los(caster) if are_hostile(u, caster) and u.shields]
		burn = self.get_stat('shield_burn')
		damage = self.get_stat('damage') if burn else 0

		for u in targets:
			stolen = min(self.get_stat('shield_steal'), u.shields)
			level.show_effect(u.x, u.y, Tags.Shield_Expire)
			u.shields -= stolen
			if burn:
				for i in range(stolen):
					u.deal_damage(damage, Tags.Fire, self)
			total += stolen
			yield
		if total: self.caster.add_shields(total)
		if self.get_stat('lensing'): self.caster.apply_buff(OcularShieldsBuff(self.caster.shields))
		yield


class SummonHungryMaw(Spell):

	def on_init(self):
		self.name = "Hungry Maw"

		self.max_charges = 12
		self.level = 2
		self.tags = [Tags.Arcane, Tags.Conjuration]
		self.range = 4

		self.minion_range = 7
		self.minion_damage = 9
		self.minion_health = 8
		self.minion_duration = 12
		self.shields = 2

		self.upgrades[('devour', 'num_targets')] = ([1, 4], 2, "Gnashing Teeth", "Hungry Maw gains a [Physical] melee attack which hits [{num_targets}:num_targets] times")
		self.upgrades['shields'] = (18, 2, "Invincible Maw")
		self.upgrades[('void', 'minion_range')] = ([1, 3], 3, "Void Maw", "Hungry Maws gain a wall melting, [Arcane] beam attack on a 3 turn cooldown")
		self.upgrades['chasm_dweller'] = (1, 1, "Chasm Dweller", "Hungry Maws summoned over chasms are permanent, rather than temporary")

		self.must_target_empty = True

	def get_description(self):
		return "Summon a temporary Hungry Maw"

	def get_extra_examine_tooltips(self):
		return [self.make_maw()] + self.get_upgrade_tooltips()

	def make_maw(self):
		u = HungryMaw()
		u.shields = self.get_stat('shields')
		apply_minion_bonuses(self, u)

		if self.get_stat('void'):
			beam = SimpleRangedAttack(damage=self.get_stat('minion_damage'), range=self.get_stat('minion_range')+3, melt=True,
			 						  damage_type=Tags.Arcane, beam=True)
			beam.cool_down = 3
			u.spells.insert(0, beam)

		if self.get_stat('devour'):
			devour = SimpleMeleeAttack(damage=self.get_stat('minion_damage'), attacks=self.get_stat('num_targets'))
			devour.name = "Gnashing Teeth"
			u.spells.insert(0, devour)

		return u

	def cast_instant(self, x, y):
		u = self.make_maw()
		if self.get_stat('chasm_dweller') and self.caster.level.tiles[x][y].is_chasm: u.turns_to_death = None
		self.summon(u, Point(x, y))

class ShrapnelBlast(Spell):

	def on_init(self):
		self.name = "Shrapnel Blast"

		self.tags = [Tags.Fire, Tags.Metallic, Tags.Sorcery]
		self.level = 3
		self.max_charges = 8
		self.radius = 3
		self.range = 7
		self.damage = 12
		self.requires_los = False
		self.num_targets = 16

		self.upgrades[('bleed', 'duration')] = ([1, 3], 1, "Slicing Shrapnel", "Shrapnel Blast shards inflict [{duration}:duration] turns of [bleed]")
		self.upgrades['puncture'] = (1, 3, "Chain Blast", "The shrapnel can penetrate and destroy walls\n"
														  "If it would destroy a wall besides the initial target, there is a 25% chance to cast Shrapnel Blast on that wall")
		self.upgrades['homing'] = (1, 6, "Magnetized Shards", "The shrapnel shards always target enemies if possible")
		self.upgrades[('range', 'remote')] = ([10, 1], 2, "Remote Detonation", "Shrapnel Blast can be used to detonate [Metallic] and [Construct] allies in addition to walls\n"
																		 "Detonating a unit kills it, and increases the damage of the initial blast by its max HP")


	def get_description(self):
		return ("Detonate target wall tile\n"
				"The initial explosion deals [{damage}:damage] [Fire] damage to adjacent tiles\n"
				"Then, [{num_targets}:num_targets] shards deal [{damage}:damage] [Physical] damage to random tiles within [{radius}:radius] tiles")

	def can_cast(self, x, y):
		if not self.is_good_target(x, y): return False
		return Spell.can_cast(self, x, y)

	def is_good_target(self, x, y):
		caster = self.caster
		level = caster.level
		if self.get_stat('remote'):
			u = level.get_unit_at(x, y)
			if u and (Tags.Metallic in u.tags or Tags.Construct in u.tags):
				if not are_hostile(u, caster):
					return True
		return level.tiles[x][y].is_wall()

	def cast(self, x, y):
		if not self.is_good_target(x, y): return
		caster = self.caster
		level = caster.level
		getu = level.get_unit_at
		can_see = level.can_see
		tiles = level.tiles
		make_floor = level.make_floor
		deal_damage = level.deal_damage

		target = Point(x, y)
		bonus_fire = 0

		r = self.get_stat('radius')
		damage = self.get_stat('damage')

		puncture = self.get_stat('puncture')
		homing = self.get_stat('homing')
		bleed = self.get_stat('bleed')
		dur = self.get_stat('duration')

		aoe = list(level.get_points_in_ball(x, y, r))
		if not puncture: aoe = [t for t in aoe if can_see(x, y, t.x, t.y, light_walls=True) and not tiles[t.x][t.y].is_wall()]

		adjacent_r = 0
		if self.get_stat('remote'):
			u = getu(x, y)
			if u:
				adjacent_r = u.radius
				level.show_effect(x, y, Tags.Fire)
				bonus_fire = u.max_hp
				u.kill()

		if tiles[x][y].is_wall(): make_floor(x, y)

		# initial explosion
		for p in level.get_adjacent_points(target, False, False, adjacent_r): deal_damage(p.x, p.y, damage+bonus_fire, Tags.Fire, self)

		for _ in range(self.get_stat('num_targets')):
			pool = aoe
			if homing:
				enemy_pool = []

				for t in aoe:
					u = getu(t.x, t.y)
					if u and are_hostile(caster, u): enemy_pool.append(t)

				if enemy_pool: pool = enemy_pool

			if pool:

				target = random.choice(pool)

				deal_damage(target.x, target.y, damage, Tags.Physical, self)

				if bleed:
					u = getu(target.x, target.y)
					if u: u.apply_buff(BleedBuff(), dur)

				if puncture and tiles[target.x][target.y].is_wall():
					if random.random() > 0.25: make_floor(target.x, target.y)
					else: level.act_cast(caster, self, target.x, target.y, pay_costs=False); continue

			yield

	def get_impacted_tiles(self, x, y):
		level = self.caster.level
		tiles = level.tiles
		can_see = level.can_see

		puncture = self.get_stat('puncture')
		remote = self.get_stat('remote')

		target = Point(x, y)

		adj_r = 0
		if remote:
			u = level.get_unit_at(x, y)
			if u: adj_r = u.radius

		if puncture: fire_targets = [p for p in level.get_adjacent_points(target, False, False, adj_r)]
		else: fire_targets = [p for p in level.get_adjacent_points(target, False, False, adj_r) if not tiles[p.x][p.y].is_wall()]

		possible_targets = list(level.get_points_in_ball(x, y, self.get_stat('radius')))
		if not puncture: possible_targets = [t for t in possible_targets if can_see(x, y, t.x, t.y, light_walls=True) and not tiles[t.x][t.y].is_wall()]

		return set(fire_targets + possible_targets)

	def get_ai_target(self):
		eligible_targets = [u for u in self.caster.level.units if are_hostile(u, self.caster) and (distance(Point(u.x, u.y), Point(self.caster.x, self.caster.y)) <= (self.range+self.radius))] # look for a hostile unit that is close enough to hit
		eligible_targets = [u for u in eligible_targets if any(tile.is_wall() for tile in self.caster.level.get_tiles_in_ball(u.x, u.y, self.radius))] # if they're close enough to a wall to get hit by shrapnel
		if not eligible_targets: return None
		random.shuffle(eligible_targets)
		for unit in eligible_targets: # well try to hit each one, and just shoot off the first one we can
			wall_targets = [tile for tile in unit.level.get_tiles_in_ball(unit.x, unit.y, self.radius) if tile.is_wall() and self.can_cast(tile.x, tile.y)] # tile targets which could be targeted and maybe hit that unit
			for wall in wall_targets: # for each one
				for target in self.get_impacted_tiles(wall.x, wall.y): # look at the impacted tiles
					if self.caster.level.get_unit_at(target.x, target.y) == unit: # if the unit is in the impacted tiles
						return wall # fire away

		else: return None

class DamagePerTurnCurse(Buff):

	def __init__(self, name, color, damage, dtype):
		Buff.__init__(self)
		self.name = name
		self.color = color
		self.damage = damage
		self.dtype = dtype
		self.buff_type = BUFF_TYPE_CURSE
		self.stack_type = STACK_INTENSITY

	def get_description(self):
		return "Deal {dmg} {dtype} damage each turn", {'dmg':self.damage, 'dtype':formatted_tag(self.dtype)}

	def on_advance(self):
		self.owner.deal_damage(self.damage, self.dtype, self)

class TormentorsBrandBuff(Buff):

	def on_init(self):
		self.name = "Tormentor's Brand"
		self.description = "Dealing damage to an enemy brands them, causing them to take 1 [Dark] damage each turn"
		self.global_triggers[EventOnDamaged] = self.on_damage

	def on_damage(self, evt):
		if not evt.source or evt.source.owner != self.owner: return
		if evt.damage <= 0: return
		if not are_hostile(self.owner, evt.unit): return
		evt.unit.apply_buff(DamagePerTurnCurse("Tormentor's Brand", Tags.Dark.color, 1, Tags.Dark))

class TithesOfTorment(Upgrade):

	def __init__(self, spell):
		self.spell = spell
		Upgrade.__init__(self, spell)
		self.name = "Tithes of Torment"
		self.level = 8
		self.description = "Heal 1 HP when your [Demon] allies deal damage\nAlways Active"
		self.global_triggers[EventOnDamaged] = self.on_damaged

	def on_damaged(self, evt):
		if evt.damage < 1: return
		if not evt.source or not evt.source.owner: return
		if are_hostile(evt.source.owner, self.owner): return
		if Tags.Demon not in evt.source.owner.tags: return
		self.owner.heal(1, self)

class SummonFieryTormentor(Spell):

	def on_init(self):
		self.name = "Fiery Tormentor"

		self.minion_health = 34
		self.minion_damage = 7
		self.minion_duration = 40
		self.minion_range = 2

		self.radius = 4

		self.max_charges = 4
		self.level = 4

		self.requires_los = False
		self.range = 8


		self.upgrades['frostfire'] = (1, 3, "Frostfire Tormentor", "Summon a Frostfire Tormentor instead", [Tags.Ice])
		self.upgrades['brand'] = (1, 5, "Torturer's Brand", "When the tormentor damages enemies it inflicts the Tormentor's Brand debuff\nTormentor's Brand deals 1 [Dark] damage each turn")
		self.upgrades['mass'] = (1, 4, "Tormenting Mass", "Summon a Fiery Tormenting Mass instead\nIf you also have the Frostfire Tormentor upgrade, summon a Frostfire Tormenting Mass instead")
		self.add_upgrade(TithesOfTorment(self))

		self.add_upgrade_tooltip("Frostfire Tormentor", lambda: self.make_tormentor(FrostfireTormentor))
		self.add_upgrade_tooltip("Tormenting Mass", lambda: self.make_tormentor(FieryTormentorMass), lambda: self.make_tormentor(FrostfireTormentorMass))
		self.add_upgrade_tooltip("Torturer's Brand", lambda: DamagePerTurnCurse("Tormentor's Brand", Tags.Dark.color, 1, Tags.Dark))


		self.tags = [Tags.Dark, Tags.Fire, Tags.Conjuration]

		self.must_target_walkable = True
		self.must_target_empty = True

	def get_description(self):
		return "Summon a Fiery Tormentor"

	def get_impacted_tiles(self, x, y):
		for stage in Burst(self.caster.level, Point(x, y), self.get_stat('radius'), ignore_walls=not self.get_stat('requires_los')):
			for p in stage:
				yield p

	def make_tormentor(self, base_class):
		frostfire = self.get_stat('frostfire')
		mass = self.get_stat('mass')
		u = make_minion(self, base_class)
		if mass:
			b = u.get_buff(SpawnOnDeath)
			if b:
				if frostfire: b.set_spawners(lambda : self.make_tormentor(FrostfireTormentor))
				else: b.set_spawners(lambda : self.make_tormentor(FieryTormentor))

		if self.get_stat('brand'): u.apply_buff(TormentorsBrandBuff())

		radius = self.get_stat('radius')
		for s in u.spells:
			if hasattr(s, 'radius') and s.radius > 0: s.radius = radius
		return u

	def cast(self, x, y):
		if self.get_stat('frostfire'):
			if self.get_stat('mass'): u = self.make_tormentor(FrostfireTormentorMass)
			else: u = self.make_tormentor(FrostfireTormentor)
		elif self.get_stat('mass'): u = self.make_tormentor(FieryTormentorMass)
		else: u = self.make_tormentor(FieryTormentor)
		self.summon(u, Point(x, y))
		yield

	def get_extra_examine_tooltips(self):
		return [self.make_tormentor(FieryTormentor)] + self.get_upgrade_tooltips()

class DispersionFieldBuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)
		self.rad = self.spell.get_stat('radius')
		self.planar = self.spell.get_stat('planar_travel')
		self.bombs = self.spell.get_stat('bombs_away')
		self.num = self.spell.get_stat('num_targets')
		self.fear = self.spell.get_stat('fear')
		self.fear_dur = self.spell.get_stat('duration', base=2)


	def on_init(self):
		self.name = "Dispersion Field"
		self.stack_type = STACK_DURATION
		self.color = Tags.Translocation.color

	def get_description(self):
		desc = [("Each turn, teleport [{num_targets}:num_targets] enemies in a [{radius}:radius] tile radius to random locations on the map", {'num_targets': self.num, 'radius': self.rad})]
		if self.planar:
			desc.append("\nTeleported enemies take damage of a random type equal to the distance traveled")
		if self.fear:
			desc.append(("\nTeleported enemies gain [Fear:dark] for [{duration}:duration] turns", {'duration': self.fear_dur}))
		if self.bombs:
			desc.append("\nTeleported enemies receive [Time Bomb:arcane]")
		return desc

	def on_advance(self):
		tped = 0
		owner = self.owner
		level = owner.level

		units = level.get_units_in_ball(owner, self.rad)
		random.shuffle(units)
		for u in units:
			if are_friendly(owner, u): continue
			target_point = level.get_random_stand_tile(u)
			if not target_point: continue
			dist = int(distance(u, target_point))

			level.show_effect(u.x, u.y, Tags.Translocation)
			level.act_move(u, target_point.x, target_point.y, teleport=True)
			level.show_effect(u.x, u.y, Tags.Translocation)


			if self.bombs: u.apply_buff(TimeBombBuff(self.spell))
			if self.fear: u.apply_buff(FearBuff(), self.fear_dur)
			if self.planar: u.deal_damage(dist, random.choice(damage_tags), self.spell)

			tped += 1
			if tped > self.num: break

class TimeBombBuff(Buff):

	def __init__(self, spell):
		Buff.__init__(self)
		self.spell = spell
		self.stack_type = STACK_INTENSITY
		self.buff_type = BUFF_TYPE_CURSE
		self.name = "Time Bomb"
		self.color = Tags.Arcane.color
		self.damage = self.spell.get_stat('damage', base=25)
		self.radius = self.spell.get_stat('radius', base=2)

	def get_description(self):
		return ("Take [1 Arcane:arcane] damage each turn\n"
				"If this buff is removed or the unit dies, it explodes, destroying walls and dealing [{damage}:damage] [Arcane] damage in a [{radius}:radius] tile radius",
				{'damage': self.damage, 'radius': self.radius})

	def on_advance(self):
		self.owner.deal_damage(1, Tags.Arcane, self.spell)

	def on_unapplied(self):
		self.owner.level.queue_spell(self.explode())

	def explode(self):
		for p in self.owner.level.get_points_in_ball(self.owner.x, self.owner.y, self.radius):
			self.owner.level.deal_damage(p.x, p.y, self.damage, Tags.Arcane, self.spell)
			if self.owner.level.tiles[p.x][p.y].is_wall():
				self.owner.level.make_floor(p.x, p.y)
		yield

class DispersionFieldSpell(Spell):

	def on_init(self):
		self.name = "Dispersion Field"
		self.level = 3
		self.tags = [Tags.Enchantment, Tags.Arcane, Tags.Translocation]

		self.max_charges = 3
		self.duration = 10
		self.num_targets = 3

		self.range = 0
		self.radius = 4

		self.upgrades['num_targets'] = (3, 2)
		self.upgrades['fear'] = (1, 4, "Hodophobia", "Enemies are [feared] for [{duration}:duration] turns after being dispersed", None, None, {"duration":2})
		self.upgrades['planar_travel'] = (1, 1, "Planar Travel", "Teleported enemies take damage of a random type equal to the distance traveled", [Tags.Chaos])
		self.upgrades[('bombs_away', 'damage')] = ([1, 25], 4, "Bombs Away", "Teleported enemies receive the Time Bomb debuff\n"
														   "Time Bomb deals a fixed [1 Arcane:arcane] damage per turn\n"
														   "If the debuff is removed or the unit dies, the bomb explodes, destroying walls and dealing [{damage}:damage] [Arcane] damage in a [{radius}:radius] tile burst", None, None, {'radius':2})

		self.add_upgrade_tooltip("Bombs Away", self.get_time_bomb_buff)

	def get_description(self):
		return ("Each turn, teleport [{num_targets}:num_targets] enemies in a [{radius}:radius] tile radius to random locations on the map\n"
				"Lasts [{duration}:duration] turns")

	def get_dispersion_field_buff(self):
		return DispersionFieldBuff(self)

	def get_time_bomb_buff(self):
		return TimeBombBuff(self)

	def get_extra_examine_tooltips(self):
		return [self.get_dispersion_field_buff()] + self.get_upgrade_tooltips()

	def cast_instant(self, x, y):
		self.caster.apply_buff(self.get_dispersion_field_buff(), self.get_stat('duration'))

class KnightBuff(Buff):

	def __init__(self, summoner):
		Buff.__init__(self)
		self.summoner = summoner

	def on_init(self):
		self.name = "Bound Knight"
		self.owner_triggers[EventOnDeath] = self.on_death

	def on_death(self, evt):
		self.summoner.deal_damage(40, Tags.Holy, self)

class SummonKnights(Spell):

	def on_init(self):
		self.name = "Knightly Oath"
		self.level = 6
		self.max_charges = 3
		self.tags = [Tags.Conjuration, Tags.Holy]

		self.minion_health = 200
		self.minion_damage = 8
		self.minion_range = 3
		self.range = 0

		self.rand_knight_turn = None
		self.knight_dict = {Tags.Arcane:VoidKnight, Tags.Lightning:StormKnight, Tags.Ice:StormKnight, Tags.Chaos:ChaosKnight, Tags.Blood:BloodKnight}
		self.knight_types = [VoidKnight, StormKnight, ChaosKnight, BloodKnight]

		self.upgrades['ouranic'] = (1, 2, "Ouranic Knights","Knights gain flying and [quickstep:translocation]")
		self.upgrades['armageddon'] = (1, 4, "Armageddon Court", "When you cast Knightly Oath, cast Armageddon Blade on the summoned Knight", [Tags.Chaos])
		self.upgrades['call'] = (1, 3, "Call to Arms", "When you cast Knightly Oath, consume remaining charges to summon that many additional knights")
		self.upgrades['slime'] = (1, 9, "Slime Knights", "Knights gain the [Slime] tag and the Slime buff, healing over time, gaining max HP until it is double the original before splitting in two", [Tags.Slime])


	def get_description(self):
		knight = f"a {self.get_knight()().name}" if self.caster and self.caster.is_player_controlled else "either a void knight, a storm knight, a chaos knight, or a blood knight"
		return ("Summon a {knight_name}\n"
				"The summoned knight will match the spell school you have spent the most SP on\n"
				"Void Knight: [Arcane]\n"
				"Storm Knight: [Lightning] or [Ice]\n"
				"Chaos Knight: [Chaos]\n"
				"Blood Knight: [Blood]\n"
				"The caster takes [40 Holy:holy] damage when a knight dies", {'knight_name':knight})

	def get_deterministic_random_knight_constructor(self, base=None):
		if not (self.caster and self.caster.is_player_controlled):  return
		choices = base if base is not None else self.knight_types
		if not self.rand_knight_turn or self.rand_knight_turn[1] != self.caster.level.turn_no:
			self.rand_knight_turn = (self.caster.level.random.choice(choices), self.caster.level.turn_no)
		return self.rand_knight_turn[0]

	def get_knight(self):
		if not (self.caster and self.caster.is_player_controlled):  return
		highest = 0
		constructors = []
		for tag, knight in self.knight_dict.items():
			mastery = self.caster.get_mastery(tag)
			if mastery > highest: highest = mastery; constructors = [knight]
			elif mastery == highest: constructors.append(knight)
		if not constructors: knight = self.get_deterministic_random_knight_constructor()
		elif len(constructors) > 1: knight = self.get_deterministic_random_knight_constructor(constructors)
		else: knight = constructors[0]
		return knight

	def make_knight(self, constructor=None, summoner=None):
		knight_constructor = constructor or self.get_knight() or self.get_deterministic_random_knight_constructor()
		if not knight_constructor: knight_constructor = random.choice(self.knight_types)
		knight = knight_constructor()
		apply_minion_bonuses(self, knight)

		if self.get_stat('ouranic'): knight.apply_buff(FlyingBuff()); knight.apply_buff(QuickmoveBuff())
		if self.get_stat('slime'):
			if Tags.Slime not in knight.tags: knight.tags.append(Tags.Slime)
			knight.apply_buff(SlimeBuff(spawner=lambda kc=knight_constructor, sm=summoner: self.make_knight(kc, sm), name="knights"))
		if summoner: knight.buffs.append(KnightBuff(summoner))
		return knight

	def cast(self, x, y):
		caster = self.caster
		if self.get_stat('call'): num = max(1, self.cur_charges + 1); self.cur_charges = 0
		else: num = 1
		armageddon = self.get_stat('armageddon')
		armageddon_blade = caster.get_or_make_spell(ArmageddonBladeSpell) if armageddon else None
		for _ in range(num):
			u = self.summon(self.make_knight(summoner=caster))
			yield
			if u and armageddon:
				for _ in self.caster.level.act_cast(caster, armageddon_blade, u.x, u.y, pay_costs=False, queue=False):
					yield

	def get_extra_examine_tooltips(self):
		return [self.make_knight(c) for c in self.knight_types] + self.get_upgrade_tooltips()

class ToxinBurst(Spell):

	def on_init(self):

		self.name = "Toxin Burst"
		self.level = 2

		self.tags = [Tags.Sorcery, Tags.Nature, Tags.Dark]
		self.damage_type = [Tags.Poison]

		self.max_charges = 8
		self.damage = 1
		self.radius = 3
		self.duration = 16
		self.requires_los = False
		self.range = 6

		self.upgrades['chemical_remedy'] = (1, 1, "Herbal Remedy", "Heals allies and removes their [poison] instead of harming them")
		self.upgrades['accelerant'] = (1, 3, "Naphtha Accelerant", "Toxin Burst inflicts [-25% Fire:fire] resistance for its duration", [Tags.Fire])
		self.upgrades[('wither', 'damage')] = ([1, 3], 4, "Withertoxin", "Toxin Burst also deals [Dark] damage and inflicts [necrosis]", None, [Tags.Dark])
		self.upgrades['chain'] = (1, 8, "Burst Chain", "Slain enemies create additional explosions with a [{radius}:radius] tile radius", None, None, {'radius':2})

		self.add_upgrade_tooltip("Naphtha Accelerant", lambda: ResistBuff(Tags.Fire, -25))

	def cast(self, x, y, secondary=False):
		caster = self.caster
		level = caster.level
		radius = self.get_stat('radius', base=2) if secondary else self.get_stat('radius')
		dmg = self.get_stat('damage')
		dur = self.get_stat('duration')

		wither = self.get_stat('wither')
		chem = self.get_stat('chemical_remedy')
		accelerant = self.get_stat('accelerant')
		chain = self.get_stat('chain')

		points = list(level.get_points_in_ball(x, y, radius))
		random.shuffle(points)
		slain = set()
		for p in points:
			u = level.get_unit_at(p.x, p.y)
			if not u: level.show_effect(p.x, p.y, Tags.Poison); continue
			if chem and are_friendly(caster, u):
				u.remove_buffs(Poison)
				u.heal(dmg, self)
				continue
			level.deal_damage(p.x, p.y, dmg, Tags.Poison, self)
			if wither:
				level.deal_damage(p.x, p.y, dmg, Tags.Dark, self)
				u.apply_buff(NecrosisBuff(), dur)

			u.apply_buff(Poison(), dur)
			if accelerant: u.apply_buff(ResistBuff(Tags.Fire, -25), dur)
			if chain and not u.is_alive(): slain.add(u)
			if random.random() < .3: yield

		if chain and slain:
			for unit in slain:
				self.owner.level.queue_spell(self.cast(unit.x, unit.y, secondary=True))

	def get_description(self):
		return "Inflict [{damage}:damage] [Poison] damage and [{duration}:duration] turns of [poison] on units in a [{radius}:radius] tile burst"

class SlimeRustBuff(Buff):

	def on_init(self):
		self.name = "Slime Rust"
		self.color = Tags.Slime.color
		for type in damage_tags:
			self.resists[type] = -10
		self.stack_type = STACK_NONE
		self.buff_type = BUFF_TYPE_CURSE

class Slimeshot(Spell):

	def on_init(self):
		self.name = "Slimeshot"
		self.level = 2
		self.tags = [Tags.Sorcery, Tags.Slime]
		self.damage_type = [Tags.Poison]
		self.damage = 12
		self.range = 6
		self.radius = 3
		self.duration = 10
		self.max_charges = 5

		self.upgrades['slimify'] = (1, 6, "Slimification Shot", "Cast Slimify on affected enemies")
		self.upgrades['chucker'] = (1, 2, "Slime Chucker", "Adjacent [Slime] allies are sacrificed, and their max HP is added to the spell's damage")
		self.upgrades['slime_rust'] = (1, 3, "Slime Rust", "Slimeshot also deals [Physical] damage\n"
														   "Affected units receive [Slime Rust:slime] which reduces all of their resistances by 10%\n"
														   "Does not affect [Slime] units", [Tags.Metallic], [Tags.Physical])

		self.upgrades['transmute'] = (1, 4, "Storm Transmutation", "Storms over affected tiles are consumed, and turned into slimes of matching types\n"
																   "[Lightning Storms:lightning] become Electric Slimes\n"
																   "[Blizzards:ice] become Ice Slimes\n"
																   "[Rain Clouds:nature] become Green Slimes", [Tags.Nature])

		self.add_upgrade_tooltip("Storm Transmutation", self.make_electric_slime, self.make_ice_slime, self.make_green_slime)
		self.add_upgrade_tooltip("Slime Rust", SlimeRustBuff)


	def get_description(self):
		return ("Deal [{damage}:damage] [Poison] damage in a [{radius}:radius] tile burst\n"
				"If the target is an allied [Slime], it explodes, adding its max HP to the spell's damage\n"
				"Inflict [{duration}:duration] turns of soaked on non [Slime] units\n"
				"Turns water chasms into swamp chasms")

	def cast(self, x, y):
		caster = self.caster
		level = caster.level

		damage = self.get_stat('damage')
		dur = self.get_stat('duration')

		rust = self.get_stat('slime_rust')
		slimify = self.get_stat('slimify')
		transmute = self.get_stat('transmute')

		if self.get_stat('chucker'):
			for p in level.get_adjacent_points(caster, filter_walkable=False):
				u = level.get_unit_at(p.x, p.y)
				if u and Tags.Slime in u.tags and are_friendly(u, caster):
					level.show_beam(u, caster, Tags.Slime)
					damage += u.max_hp
					u.kill()
					yield

		level.show_beam(caster, Point(x, y), Tags.Poison, inclusive=False)
		target_u = level.get_unit_at(x, y)

		if target_u and are_friendly(caster, target_u) and Tags.Slime in target_u.tags:
			damage += target_u.max_hp
			target_u.kill()

		for stage in self.get_aoe(x, y):
			for point in stage:
				level.deal_damage(point.x, point.y, damage, Tags.Poison, self)
				yield
				unit = level.get_unit_at(point.x, point.y)
				if unit:
					if Tags.Slime not in unit.tags:
						unit.apply_buff(SoakedBuff(), dur)
						if rust:
							unit.deal_damage(damage, Tags.Physical, self)
							unit.apply_buff(SlimeRustBuff())
					if slimify and are_hostile(caster, unit):
						level.act_cast(caster, caster.get_or_make_spell(Slimify), unit.x, unit.y, pay_costs=False)

				tile = level.tiles[point.x][point.y]
				cloud = tile.cloud
				if cloud and transmute and not type(cloud)==SpiderWeb:
					slime = self.get_cloud_matching_slime(cloud)
					if slime:
						cloud.kill()
						level.queue_spell(self.summon_slime(slime, point))

				if tile.chasm_type == 'water':
					level.set_tile_style(tile, tile.tileset, 'swamp')

			yield

		return

	def summon_slime(self, slime, point):
		self.summon(slime, target=point)
		yield

	def get_aoe(self, x, y):
		yield from Burst(self.caster.level, Point(x, y), self.get_stat('radius'), ignore_walls=not self.get_stat('requires_los'))

	def get_impacted_tiles(self, x, y):
		for stage in self.get_aoe(x, y):
			for point in stage:
				yield point
		if self.get_stat('chucker'):
			for p in self.caster.level.get_adjacent_points(self.caster, filter_walkable=False):
				u = self.caster.level.get_unit_at(p.x, p.y)
				if u and Tags.Slime in u.tags and are_friendly(u, self.caster):
					yield p

	def make_electric_slime(self):
		u = ElectricSlime()
		apply_minion_bonuses(self, u)
		u.buffs[0].spawner = lambda: self.make_electric_slime()
		return u

	def make_ice_slime(self):
		u = IceSlime()
		apply_minion_bonuses(self, u)
		u.buffs[0].spawner = lambda: self.make_ice_slime()
		return u

	def make_green_slime(self):
		u = GreenSlime()
		apply_minion_bonuses(self, u)
		u.buffs[0].spawner = lambda: self.make_green_slime()
		return u

	def get_cloud_matching_slime(self, cloud):
		if type(cloud) == StormCloud: return self.make_electric_slime()
		elif type(cloud) == BlizzardCloud: return self.make_ice_slime()
		elif type(cloud) == RainCloud: return self.make_green_slime()


	def get_ai_target(self):
		return Spell.get_corner_target(self, self.get_stat('radius'))

def Slimy(monster):
	candidates = get_matching_slimes(monster)
	monster.apply_buff(SlimyBuff(spawner=candidates))
	if Tags.Slime not in monster.tags: monster.tags.append(Tags.Slime)
	monster.name = "Slimy %s" % monster.name
	monster.modified = True

	# give it proper slime resists
	set_resist(monster, Tags.Poison, 100)
	set_resist(monster, Tags.Physical, 50)

	return monster

def apply_modifier(modifier, unit, propagate=True):
	unit.asset_name = unit.get_asset_name()
	if getattr(unit, 'modified', False): return # early out, have modifiers set a modified attr to true, stops inf recursion

	if propagate:
		def make_child(spawner, modifier=modifier):
			def spawn_child():
				child = spawner()
				apply_modifier(modifier, child)
				return child
			return spawn_child

		for buff in [b for b in unit.buffs if isinstance(b, SpawnOnDeath)]:
			if isinstance(buff.spawners, (list, tuple)): spawners = [make_child(spawner) for spawner in buff.spawners]
			else: spawners = make_child(buff.spawners)
			buff.set_spawners(spawners)

		for b_type in [MatureInto, RespawnAs, ChanceToBecome, GeneratorBuff, Generator2Buff,  SplittingBuff, SlimeBuff]:
			buffs = [b for b in unit.buffs if isinstance(b, b_type)]
			for buff in buffs:
				buff.spawner = make_child(buff.spawner)

		for s in unit.spells:
			if not isinstance(s, SimpleSummon): continue
			def make_child(spawner=s.spawn_func, modifier=modifier): return apply_modifier(modifier, spawner())
			s.spawn_func = make_child
			s.calc_text()

	modifier(unit)
	return unit

class SlimyBuff(Buff):

	def __init__(self, spawner, name='slimes', growth_chance=.5):
		Buff.__init__(self)
		self.name = "Slimy"
		self.asset = ['status', 'slimy']
		self.color = Tags.Slime.color
		self.spawner = spawner
		self.spawner_name = name
		self.buff_type = BUFF_TYPE_PASSIVE # for showing description if applied post unit-creation
		self.stack_type = STACK_REPLACE
		self.growth_chance = growth_chance
		self.description = ("50% chance to heal for 2 HP each turn\n"
							"Excess healing from this effect raises max HP\n"
							"When this creature is damaged, a slime is spawned nearby\n"
							"Spawned slimes will match this unit's tags when possible, and be green slimes in all other cases")


	def on_applied(self, owner):
		self.growth = 2
		self.owner_triggers[EventOnDamaged] = self.on_damaged

	def on_advance(self):
		if random.random() < self.growth_chance: return
		if (self.owner.cur_hp + self.growth) >= self.owner.max_hp: self.owner.max_hp = self.owner.cur_hp + self.growth
		self.owner.deal_damage(-self.growth, Tags.Heal, self)

	def on_damaged(self, evt):
		unit = random.choice(self.spawner)()  # spawn the unit based on the spawner fxn
		self.summon(unit, self.owner)

class AmalgamateSlime(Spell):

	def on_init(self):
		self.name = "Amalgamate Slime"
		self.tags = [Tags.Slime, Tags.Sorcery]
		self.level = 3
		self.range = RANGE_GLOBAL
		self.max_charges = 3

		self.can_target_empty = False
		self.requires_los = False
		self.can_self_target = False

		self.upgrades['global_network'] = (1, 2, "Global Network", "Affects all [Slime] allies, instead of only those in a connected group")
		self.upgrades['can_self_target'] = (1, 1, "Slime Drinking", "You may target yourself with this spell\n"
																   "Casting it on yourself causes you to heal for the total absorbed health instead of summoning a creature")
		self.upgrades[('hp_cost', 'absorption', 'damage')] = ([5, 1, 1], 3, "Absorption", "[Slime] allies steal [{damage}:damage] max HP from adjacent enemies before amalgamating", [Tags.Blood])
		self.upgrades['slimy_mimic'] = (1, 4, "Slimy Mimic", "Instead of consolidating into the target slime, summons a random monster with the Slimy buff\n"
															 "The monster summoned depends on the total health of the absorbed slimes, with higher health pools yielding potentially more powerful monsters\n"
															 "The summoned monster's max HP is set to the total health of the absorbed slimes\n"
															 "The damage of the monster's spells scales with their increased HP", [Tags.Chaos])

	def can_cast(self, x, y):
		u = self.caster.level.get_unit_at(x, y)
		if self.get_stat('can_self_target') and u == self.caster: # if you have the upgrade, then go ahead and cast it on yourself
			return True
		if u and not are_hostile(self.caster, u) and Tags.Slime in u.tags: # normally, cast on friendly slimes only
			return True
		return False

	def get_impacted_tiles(self, x, y):
		if not self.can_cast(x, y): # if you can't cast there, no tiles will be impacted
			return []

		if self.get_stat('global_network'): # get all the friendly slimes!
			return [u for u in self.caster.level.units if Tags.Slime in u.tags and not are_hostile(self.caster, u)]

		# Use adjacent friendly slimes as roots for their connected groups when self-targeting
		if self.get_stat('can_self_target') and self.caster.level.get_unit_at(x, y) == self.caster:
			adj_slimes = [u for u in self.caster.level.get_adjacent_units(self.caster) if Tags.Slime in u.tags and not are_hostile(u, self.caster)]
			affected_units = set()
			affected_units.add(self.caster)
			if not adj_slimes:
				return [self.caster]
			for u in adj_slimes:
				for u in self.caster.level.get_connected_group_from_point(u.x, u.y, required_tags=[Tags.Slime], check_friendly=self.caster):
					affected_units.add(u)
			return list(affected_units)

		else: # normal cast, grab the slimes in a group
			return [u for u in self.caster.level.get_connected_group_from_point(x, y, required_tags=[Tags.Slime], check_friendly=self.caster)]

	def do_absorption(self, u):
		cumulative_hp = 0
		dmg = self.get_stat('damage')
		for unit in self.caster.level.get_adjacent_units(u):
			if are_hostile(self.caster, unit):  # only drain from hostiles
				prev_max = unit.max_hp
				drain_max_hp(unit, dmg)
				self.caster.level.show_effect(unit.x, unit.y, Tags.Blood)
				cumulative_hp += (prev_max - unit.max_hp)  # only add as much hp as was actually drained
		return cumulative_hp

	def cast(self, x, y):
		target_unit = self.caster.level.get_unit_at(x, y)
		group = self.get_impacted_tiles(x, y)
		absorb = self.get_stat('absorption')
		cumulative_hp = 0

		if self.get_stat('can_self_target') and target_unit == self.caster: # casting on yourself won't do the other fancy bits, just care about hp
			for u in group:
				if u != self.caster:
					self.caster.level.show_beam(u, self.caster, Tags.Poison)
					heal = u.max_hp
					if absorb: heal += self.do_absorption(u)
					self.caster.heal(heal, self)
					u.kill()
					yield
			return

		if self.get_stat('slimy_mimic'): # if we're making a new monster, we don't care about the amalgamating, just the hp to find out how scary of a monster we make
			for u in group:
				cumulative_hp += u.max_hp
				if absorb: cumulative_hp += self.do_absorption(u)
				self.caster.level.show_effect(target_unit.x, target_unit.y, Tags.Chaos)
				self.caster.level.show_beam(u, target_unit, Tags.Poison)
				u.kill()
				yield
			summon_diff = max(1, min(9, cumulative_hp // 20)) # get the difficulty level of the unit to be summoned.
			candidates = [u for u in spawn_options if u[1] <= summon_diff] # grab the monster at or below the appropriate difficulty
			candidate = random.choice(candidates)[0]() # pick a random one and build a monster from it
			candidate = apply_modifier(Slimy, candidate)
			mult = max(1, cumulative_hp // candidate.max_hp) # grab the multiplier to use for damage based off scaled hp
			for s in candidate.spells:
				if getattr(s, 'damage', None): s.damage *= mult
			candidate.max_hp  = cumulative_hp # fix its max hp equal to the amalgamated hp
			self.summon(candidate, Point(x, y))
			yield
			return

		spell_map = {} # track all the spells added and their cumulative damage
		new_spells = [] # list of spells from units besides the target
		tag_set = set() # all relevant tags on impacted units
		resistances = {} # track the highest resistance values of combined units
		for u in group:
			cumulative_hp += u.max_hp
			if self.get_stat('absorption'): cumulative_hp += self.do_absorption(u)
			if u == target_unit: continue # not absorbing the target, so don't need to do next parts to it

			for resist_type, value in u.resists.items(): # look at resistances of absorbed units
				if resist_type not in resistances or value > resistances[resist_type]: # if target doesn't have that resistance or the to be absorbed unit's resistance is greater to a given damage type, store that
					resistances[resist_type] = value

			for s in u.spells:
				if hasattr(s, 'damage'): # track spells with damage in the spell_map, so they can be cumulated later
					spell_map[s.name] = spell_map.get(s.name, 0) + s.damage
				new_spells.append(s) # add their spells to the new_spells list

			for t in u.tags: # track the absorbed units' tags, so they can be added to the target
				tag_set.add(t)

			self.caster.level.show_beam(u, target_unit, Tags.Poison) # vfx for the spell
			u.kill()
			yield

		hp_deficit = target_unit.max_hp - target_unit.cur_hp
		target_unit.max_hp = cumulative_hp # set max hp to the cumulative total
		target_unit.cur_hp = cumulative_hp - hp_deficit # keep the difference between cur_hp and max_hp the same

		existing_names = set(s.name for s in target_unit.spells) # track spells which the target already has

		for s in target_unit.spells: # stack dmg from spell_map into existing spells
			if s.name in spell_map and hasattr(s, 'damage'): # if one of the units existing spells is in the spell map (name matched)
				s.damage += spell_map[s.name] # then add the absorbed spell of the same names damage to the units spell
				del spell_map[s.name] # then get rid of that entry in the spell_map

		for s in new_spells: # for all the absorbed spells
			if s.name not in existing_names: # if the target doesn't already have the spell
				if hasattr(s, 'damage') and s.name in spell_map: # if the spell has a damage attribute and is in the spell map
					s.damage = spell_map[s.name] # make the new spell's damage equal to the sum of all the same_named spells
					del spell_map[s.name] # get rid of the map entry
				target_unit.add_spell(s) # then give the unit the spell
				existing_names.add(s.name)  # prevent further duplicates

		target_unit.spells.sort(key=lambda s : getattr(s, 'damage', 0), reverse=True) # highest damage spells preferred, so they go at the top of the list

		for tag in tag_set: # give the target tags they don't already have from absorbed units
			if tag not in target_unit.tags: target_unit.tags.append(tag)

		for resist_type, value in resistances.items(): # set the targets resistances for each dmg type to the max of any absorbed unit
			target_unit.resists[resist_type] = max(target_unit.resists[resist_type], value)

		buff = target_unit.get_buff(SlimeBuff) # if they have base slime buff, grab it
		if buff: target_unit.remove_buff(buff) # get rid of it (having the base buff causes them to split immediately and reverts their health, which makes the spell pretty awful)
		candidates = get_matching_slimes(target_unit) # we want to know what kind of slimes to spawn for the slimy buff we're going to apply
		target_unit.apply_buff(SlimyBuff(candidates))


	def get_description(self):
		return ("[Slime] allies in a connected group are amalgamated onto the target\n"
				"Target gains the max HP, resists, spells, and spell damage, of affected units\n"
				"Target loses the base slime buff, and gains the Slimy buff which causes its health to increase over time and to shed slimes when damaged\n"
				"This spell must target a [Slime] ally")

class SlimifyBuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		self.damage = spell.get_stat('damage')
		self.rainbow = spell.get_stat('rainbow')
		self.decomp = spell.get_stat('rapid_decomposition')
		self.contagion = spell.get_stat('contagion')

		Buff.__init__(self)


	def on_init(self):
		self.name = "Slimify"
		self.color = Tags.Slime.color
		self.buff_type = BUFF_TYPE_CURSE
		if self.decomp: self.owner_triggers[EventOnDamaged] = self.on_damaged
		if self.contagion: self.owner_triggers[EventOnDeath] = self.on_death
		self.stack_type = STACK_DURATION

	def get_description(self):
		desc = ["Deals [{damage}:damage] [Physical] damage each turn\n"
				"If the target takes damage from this effect, their max HP is reduced by the same amount\n"
				"Summons a {slime_kw} nearby after dealing damage"]
		if self.decomp: desc.append("\nThese effects trigger when this unit takes damage from a [Slime]")
		if self.contagion: desc.append("\nRemaining duration jumps to the nearest enemy in line of sight if this unit dies")
		return desc

	def fmt_dict(self):
		damage = self.damage
		slime_kw = 'random slime' if self.rainbow else "Green Slime"
		return {'damage': damage, 'slime_kw': slime_kw}

	def on_advance(self):
		dmg = self.owner.deal_damage(self.damage, Tags.Physical, self.spell)
		if dmg:
			if self.rainbow: slime_type = self.spell.choose_random_slime()
			else: slime_type = GreenSlime
			self.spell.summon(self.spell.make_slime(slime_type), self.owner, radius=4, sort_dist=True)
			drain_max_hp(self.owner, dmg)

	def on_damaged(self, evt):
		if evt.damage < 1: return
		if not evt.source: return
		if evt.source == self.spell: return
		if not evt.source.owner: return
		if Tags.Slime in evt.source.owner.tags: self.on_advance()

	def on_death(self, evt):
		targets = [u for u in self.owner.level.get_units_by_distance(self.owner, require_los=True) if are_hostile(self.spell.owner, u)]
		if targets:
			self.owner.level.show_path_effect(self.owner, targets[0], Tags.Poison)
			targets[0].apply_buff(SlimifyBuff(self.spell), self.turns_left)

class Slimify(Spell):

	def on_init(self):
		self.name = "Slimify"
		self.tags = [Tags.Enchantment, Tags.Blood, Tags.Conjuration, Tags.Slime]
		self.damage_type = [Tags.Physical]
		self.range = 3
		self.max_charges = 12
		self.level = 2
		self.damage = 10
		self.duration = 4
		self.minion_health = 10
		self.minion_damage = 3
		self.can_target_empty = False
		self.hp_cost = 5

		self.upgrades['touch'] = (1, 1, "Genetic Scramble", "If cast on an adjacent unit, the duration is permanent")
		self.upgrades['rainbow'] = (1, 3, "Rainbow Slimes", "Slimes can be of any variety", [Tags.Chaos])
		self.upgrades['contagion'] = (1, 2, "Contagion", "Slimify's remaining duration will jump to the nearest enemy in line of sight if the affected unit dies")
		self.upgrades['rapid_decomposition'] = (1, 4, "Rapid Decomposition", "Slimify's effects are triggered if the affected target takes damage from a [Slime]")


	def get_description(self):
		return ("Target is Slimified\n"
				"Slimified deals [{damage}:damage] [Physical] damage each turn\n"
				"When it successfully deals damage, the victim's max HP is decreased by the damage dealt, and a Green Slime is summoned nearby\n"
				"Lasts [{duration}:duration] turns")

	def cast_instant(self, x, y):
		unit = self.caster.level.get_unit_at(x, y)
		if not unit: return
		dur = self.get_stat('duration')
		if self.get_stat('touch') and self.caster.level.unit_distance(unit, self.caster) < 2: dur = 0
		self.owner.level.show_beam(self.caster, Point(x, y), Tags.Poison, inclusive=False)
		unit.apply_buff(SlimifyBuff(self), dur)

	def make_slime(self, slime_type=GreenSlime):
		u = slime_type()
		apply_minion_bonuses(self, u)
		# Make sure bonuses propogate
		u.buffs[0].spawner = lambda: self.make_slime(slime_type)
		return u

	def choose_random_slime(self):
		candidates = [GreenSlime, RedSlime, IceSlime, VoidSlime, ElectricSlime, BloodSlime]
		return random.choice(candidates)

	def get_slimify_buff(self):
		return SlimifyBuff(self)

	def get_extra_examine_tooltips(self):
		return [SlimifyBuff(self), self.make_slime()] + self.get_upgrade_tooltips()


class IgnitePoison(Spell):

	def on_init(self):
		self.name = "Combust Poison"
		self.level = 4
		self.tags = [Tags.Sorcery, Tags.Fire, Tags.Nature]
		self.range = 0
		self.max_charges = 3
		self.radius = 1

		self.upgrades[('ignition', 'damage')] = ([1, 10], 2, "Ignition Principle", "The [Fire] damage cannot be less than [{damage}:damage], regardless of the remaining [poison] duration")
		self.upgrades['healing'] = (1, 3, "Flame Rave", "The flames heal allies instead of harming them")
		self.upgrades['deal_poison'] = (1, 4, "Toxic Embers", "The explosion applies [poison] to damaged targets for half of the [Fire] damage taken")
		self.upgrades[('stun', 'duration')] = ([1, 2], 5, "Paralyzing Combustion", "[Stuns] the [poisoned] targets for [{duration}:duration] turns")


	def get_impacted_tiles(self, x, y):
		tiles = set()
		radius = self.get_stat('radius')
		for u in self.caster.level.units:
			if not u.has_buff(Poison): continue
			if not are_hostile(u, self.caster): continue
			points = [p for stage in Burst(self.caster.level, u, radius, ignore_walls=not self.get_stat('requires_los')) for p in stage]
			for p in points: tiles.add(p)
		return tiles

	def get_description(self):
		return ("Consume all [poison] on enemies\n"
				"Deal [Fire] damage in a [{radius}:radius] tile burst around each affected enemy equal to the remaining duration of the [poison] consumed")

	def burst(self, damage, u):
		damage_dealt = 0
		if self.get_stat('stun') and u.is_alive(): u.apply_buff(Stun(), self.get_stat('duration'))
		for stage in Burst(self.caster.level, u, self.get_stat('radius'), ignore_walls=not self.get_stat('requires_los')):
			for point in stage:
				unit = self.caster.level.get_unit_at(point.x, point.y)
				if unit:
					if are_hostile(self.caster, unit) or not self.get_stat('healing'):
						damage_dealt = self.caster.level.deal_damage(point.x, point.y, damage, Tags.Fire, self)
					elif self.get_stat('healing'):
						damage_dealt = 0
						self.caster.level.deal_damage(point.x, point.y, -damage, Tags.Heal, self)
					if self.get_stat('deal_poison'):
						if damage_dealt >= 2:
							unit.apply_buff(Poison(), damage_dealt // 2)
				else:
					self.caster.level.deal_damage(point.x, point.y, damage, Tags.Fire, self)

	def cast(self, x, y):

		units = [u for u in self.caster.level.units if are_hostile(u, self.caster) and u.has_buff(Poison)]
		random.shuffle(units)
		ignition = self.get_stat('ignition')
		ignition_dmg = self.get_stat('damage')
		bursts = []

		for u in units:
			if not u.has_buff(Poison): continue

			buff = u.get_buff(Poison)
			damage = buff.turns_left
			if ignition: damage = max(damage, ignition_dmg)
			u.remove_buff(buff)
			bursts.append([damage, u])


		for b in bursts:
			self.burst(b[0], b[1])
			yield

class VenomBeastThorns(Buff):

	def on_init(self):
		self.name = "Poison Skin"
		self.global_triggers[EventOnSpellCast] = self.on_spell
		self.description = "[Poisons] melee attackers for 5 turns"
		self.color = Tags.Poison.color

	def on_spell(self, evt):
		if evt.x != self.owner.x or evt.y != self.owner.y: return
		if not (isinstance(evt.spell, LeapAttack) or isinstance(evt.spell, PullAttack) or evt.spell.melee): return
		self.owner.level.queue_spell(self.do_thorns(evt.caster))

	def do_thorns(self, unit):
		unit.apply_buff(Poison(), 5)
		yield

class UrticatingHairs(Upgrade):

	def __init__(self, spell):
		self.spell = spell
		Upgrade.__init__(self, spell)

	def on_init(self):
		self.name = "Urticating Hairs"
		self.level = 2
		self.tags = [Tags.Nature, Tags.Conjuration]
		self.description = "[Spider] allies gain [50% Physical:physical] resist and permanently [poison] melee attackers\nAlways Active"
		self.global_triggers[EventOnUnitAdded] = self.on_unit_added

	def on_unit_added(self, evt):
		if are_hostile(self.owner, evt.unit): return
		if evt.unit == self.owner: return
		if Tags.Spider not in evt.unit.tags: return
		b = CurseRetaliation(name="Urticating Hairs", buff=Poison, buff_dur=0, color_tag=Tags.Poison, melee=True)
		b.resists[Tags.Physical] = 50
		evt.unit.apply_buff(b)

	def on_applied(self, owner):
		Upgrade.on_applied(self, owner)
		existing = [u for u in owner.level.units if Tags.Spider in u.tags and not are_hostile(owner, u)]
		for u in existing:
			b = CurseRetaliation(name="Urticating Hairs", buff=Poison, buff_dur=0, color_tag=Tags.Poison, melee=True)
			b.resists[Tags.Physical] = 25
			u.apply_buff(b)

class VampireQueen(Upgrade):

	def __init__(self, spell):
		self.spell = spell
		Upgrade.__init__(self, spell)

	def on_init(self):
		self.name = "Vampire Queen"
		self.level = 7
		self.added_tags = [Tags.Blood]
		self.tags = [Tags.Nature, Tags.Conjuration, Tags.Blood]
		self.description = "[Spider] allies gain the [Blood] tag and can cast your Lifedrain on a 4 turn cooldown\nAlways Active\nAdds the [Blood] tag"
		self.global_triggers[EventOnUnitAdded] = self.on_unit_added

	def on_unit_added(self, evt):
		if are_hostile(self.owner, evt.unit): return
		if evt.unit == self.owner: return
		if Tags.Spider in evt.unit.tags:
			grant_minion_spell(LifedrainSpell, evt.unit, self.owner, cool_down=4, pre_insert=True)
			evt.unit.tags.append(Tags.Blood)

	def on_applied(self, owner):
		Upgrade.on_applied(self, owner)
		existing = [u for u in owner.level.units if Tags.Spider in u.tags and not are_hostile(owner, u)]
		for u in existing:
			grant_minion_spell(LifedrainSpell, u, owner, cool_down=4, pre_insert=True)
			u.tags.append(Tags.Blood)



class SummonSpiderQueen(Spell):

	def on_init(self):
		self.name = "Spider Queen"
		self.level = 3

		self.tags = [Tags.Nature, Tags.Conjuration]
		self.must_target_walkable = True
		self.must_target_empty = True

		self.minion_damage = 16
		self.minion_health = 96
		self.max_charges = 2

		self.upgrades['aether'] = (1, 5, "Aether Queen", "Summon an Aether Spider Queen instead", [Tags.Arcane])
		self.upgrades['dryder'] = (1, 9, "Dryder Guards", "Also summon a pair of Dryders near the Spider Queen")
		self.add_upgrade(VampireQueen(self))
		self.add_upgrade(UrticatingHairs(self))

		self.add_upgrade_tooltip("Aether Queen", self.make_aether_spider_queen, lambda: make_minion(self, PhaseSpider), self.make_baby_phase_spider)
		self.add_upgrade_tooltip("Dryder Guards", lambda: make_minion(self, Dryder))

	def get_description(self):
		return "Summon a Spider Queen"

	def make_baby_spider(self):
		u = BabySpider()
		apply_minion_bonuses(self, u)
		u.source = self
		return u

	def make_baby_phase_spider(self):
		u = BabyPhaseSpider()
		apply_minion_bonuses(self, u)
		u.source = self
		return u

	def make_spider_queen(self):
		u = GiantSpiderQueen()
		apply_minion_bonuses(self, u)
		return u

	def make_aether_spider_queen(self):
		u = PhaseSpiderQueen()
		apply_minion_bonuses(self, u)
		return u

	def cast_instant(self, x, y):
		target = Point(x, y)
		if self.get_stat('aether'): unit = self.make_aether_spider_queen()
		else: unit = self.make_spider_queen()
		self.summon(unit, target=Point(x, y))
		if self.get_stat('dryder'):
			self.summon(make_minion(self, Dryder), target=target)
			self.summon(make_minion(self, Dryder), target=target)

	def get_extra_examine_tooltips(self):
		return [self.make_spider_queen(), make_minion(self, GiantSpider), self.make_baby_spider()] + self.get_upgrade_tooltips()

class RefreezeBuff(Buff):

	def on_init(self):
		self.name = "Refreezing"
		self.color = Tags.Ice.color
		self.buff_type = BUFF_TYPE_CURSE

	def get_description(self):
		return ("Each turn, if the owner is [frozen], increase [frozen] duration by 1\n"
				"Otherwise, inflict [frozen] for 1 turn")

	def on_advance(self):
		self.has_buff = False
		if self.owner.get_buff(FrozenBuff):
			buff = self.owner.get_buff(FrozenBuff)
			buff.turns_left += 1
		else: self.owner.apply_buff(FrozenBuff(), 1)

class Frostbite(Upgrade):

	def on_init(self):
		self.name = "Frostbite"
		self.level = 4
		self.added_tags = [Tags.Dark]
		self.tags = [Tags.Ice, Tags.Dark, Tags.Enchantment]
		self.damage = 3
		self.new_attributes = {'damage': 3}

	def get_description(self):
		return "Each turn all [frozen] enemies take [{damage}:damage] [Dark] and [Ice] damage\nAlways Active\nAdds the [Dark] tag"

	def on_advance(self):
		units = list(self.owner.level.units)
		random.shuffle(units)
		for u in units:
			if are_hostile(self.owner, u) and u.has_buff(FrozenBuff):
				u.deal_damage(self.get_stat('damage'), Tags.Dark, self)
				u.deal_damage(self.get_stat('damage'), Tags.Ice, self)

	def on_applied(self, owner):
		Upgrade.on_applied(self, owner)
		self.spell_damage_type_update(Freeze, Tags.Dark)
		self.spell_damage_type_update(Freeze, Tags.Ice)

	def on_unapplied(self):
		Upgrade.on_unapplied(self)
		self.spell_damage_type_update(Freeze, Tags.Dark, add=False)
		self.spell_damage_type_update(Freeze, Tags.Ice, add=False)

class Freeze(Spell):

	def on_init(self):
		self.tags = [Tags.Enchantment, Tags.Ice]
		self.level = 2
		self.name = "Freeze"

		self.duration = 5

		self.max_charges = 20

		self.range = 8

		self.upgrades['refreezing'] = (1, 3, "Refreezing", "The target is refrozen every turn for the duration")
		self.upgrades['freeze_group'] = (1, 4, "Mass Freeze", "Freeze affects a connected group of enemies")
		self.upgrades['quick_cast'] = (1, 2, "Quickcast", "Freeze gains quickcast")
		self.add_upgrade(Frostbite())

		self.add_upgrade_tooltip("Refreezing", RefreezeBuff)

	def get_impacted_tiles(self, x, y):
		tiles = [Point(x, y)]
		if self.get_stat('freeze_group'):
			tiles = self.caster.level.get_connected_group_from_point(x, y, check_hostile=self.caster)

		return tiles

	def can_cast(self, x, y):
		return self.caster.level.get_unit_at(x, y) and Spell.can_cast(self, x, y)

	def can_harm(self, target_unit):
		return are_hostile(self.caster, target_unit) and target_unit.can_be_stunned() and target_unit.resists[Tags.Ice] < 100

	def get_ai_target(self):
		return Spell.get_ai_target(self, check_harm=True)

	def cast(self, x, y):
		targets = [self.caster.level.get_unit_at(x, y)]
		if self.get_stat('freeze_group'):
			targets = self.caster.level.get_connected_group_from_point(x, y, check_hostile=self.caster)

		for target in targets:
			if target:
				target.apply_buff(FrozenBuff(), self.get_stat('duration')-self.get_stat('refreezing')) #subtracting refreezing because that adds a stack due to the logic
				if self.get_stat('refreezing'):
					target.apply_buff(RefreezeBuff(), self.get_stat('duration'))
				self.owner.level.show_beam(self.caster, target, Tags.Ice, minor=True, inclusive=False)
			yield
		yield #2 yields just in case no targets

	def get_description(self):
		return ("Target is [frozen] for [{duration}:duration] turns")


class Iceball(Spell):

	def on_init(self):
		self.tags = [Tags.Sorcery, Tags.Ice]
		self.damage_type = [Tags.Ice]
		self.level = 2
		self.name = "Iceball"

		self.damage = 14
		self.duration = 3
		self.radius = 2

		self.range = 7

		self.max_charges = 8

		self.upgrades['cloud_combustion'] = (1, 2, "Cloud Combustion", "Gain +2 radius and x2 damage if cast on a [Blizzard:ice]\nConsumes the [Blizzard:ice]")
		self.upgrades['icecrush'] = (1, 1, "Ice Crush", "Units inside of the area of effect which are already [frozen] take [Physical] damage before being [frozen] again", None, [Tags.Physical])
		self.upgrades[('summon_faery', 'minion_health', 'minion_damage', 'minion_range')] = ([1, 9, 2, 4], 3, "Fae Ball", "When you cast Iceball, summon an Ice Faery for every 4 enemies it damages", [Tags.Conjuration])
		self.upgrades['subzero'] = (1, 5, "Subzero Ice", "Instead of inflicting [frozen], cast your Freeze spell on affected units")
		self.add_upgrade_tooltip("Fae Ball", self.make_faerie)

	def get_description(self):
		return "Inflicts [{damage}:damage] [Ice] damage and [{duration}:duration] turns of [frozen] in a [{radius}:radius] tile burst"

	def cast(self, x, y):
		target = Point(x, y)
		caster = self.caster
		level = caster.level

		dmg = self.get_stat('damage')
		dur = self.get_stat('duration')

		crush = self.get_stat('icecrush')
		fae = self.get_stat('summon_faery')
		subzero = self.get_stat('subzero')

		dmged = set() # for tracking enemies hit for summoning winter fae

		bonus_radius = 0
		damage_multiplier = 1
		c = level.tiles[x][y].cloud
		if c and (type(c) == BlizzardCloud) and self.get_stat('cloud_combustion'):
			bonus_radius = 2
			damage_multiplier = 2
			c.kill()

		dmg = dmg*damage_multiplier

		for stage in Burst(level, target, self.get_stat('radius') + bonus_radius, ignore_walls=not self.get_stat('requires_los')):
			for point in stage:
				unit = level.get_unit_at(point.x, point.y)
				crush_dmg = None
				if crush and unit and unit.has_buff(FrozenBuff):
					crush_dmg = unit.deal_damage(dmg, Tags.Physical, self)

				dmg_dealt = level.deal_damage(point.x, point.y, dmg, Tags.Ice, self)

				if unit:
					if subzero: level.act_cast(caster, caster.get_or_make_spell(Freeze), unit.x, unit.y, pay_costs=False)
					else: unit.apply_buff(FrozenBuff(), dur)

				if fae and unit and are_hostile(caster, unit) and (dmg_dealt or crush_dmg) and unit not in dmged:
					dmged.add(unit)
					if len(dmged) % 4 == 0:
						ice_faery = self.make_faerie()
						self.summon(ice_faery, Point(x, y))

			for i in range(3): yield

		return

	def make_faerie(self):
		u = FaeryIce()
		apply_minion_bonuses(self, u)
		return u

	def get_impacted_tiles(self, x, y):
		if self.get_stat('cloud_combustion') and self.caster.level.tiles[x][y].cloud and isinstance(self.caster.level.tiles[x][y].cloud, BlizzardCloud):
			return [p for stage in Burst(self.caster.level, Point(x, y), self.get_stat('radius') + 2, ignore_walls=not self.get_stat('requires_los')) for p in stage]
		else:
			return [p for stage in Burst(self.caster.level, Point(x, y), self.get_stat('radius'), ignore_walls=not self.get_stat('requires_los')) for p in stage]



class BlizzardHarvest(Upgrade):

	def on_init(self):
		self.name = "Blizzard Harvest"
		self.description = "Every 300 damage dealt by this spell's [Blizzards:ice], regain a charge of a random [Ice] spell"
		self.owner_triggers[EventOnUnitAdded] = self.on_unit_added
		self.global_triggers[EventOnDamaged] = self.on_damage
		self.level = 6
		self.damage_dealt = 0
		self.cap = 300

	def on_unit_added(self, evt):
		self.damage_dealt = 0

	def on_damage(self, evt):
		if isinstance(evt.source, BlizzardSpell):
			self.damage_dealt += evt.damage
			while self.damage_dealt >= self.cap:
				self.damage_dealt -= self.cap
				opts = [s for s in self.owner.spells if Tags.Ice in s.tags and s.cur_charges < s.get_stat('max_charges')]
				if opts: random.choice(opts).refund_charges(1)

class BlizzardSpell(Spell):

	def on_init(self):

		self.name = "Blizzard"
		self.tags = [Tags.Enchantment, Tags.Ice, Tags.Nature]
		self.level = 4
		self.max_charges = 3
		self.range = 6
		self.radius = 3
		self.damage = 5
		self.duration = 5

		self.upgrades[('beast', 'minion_health', 'minion_damage', 'num_summons')] = ([1, 36, 8, 3], 4, "Blizzard Beasts", "Casting Blizzard also summons up to [{num_summons}:num_summons] Blizzard Beasts in unoccupied affected tiles", [Tags.Conjuration])
		self.upgrades['cast_icicle'] = (1, 7, "Hailstorm", "For each cloud created by Blizzard, there is a 25% chance for you to cast Icicle on it each turn")
		self.upgrades['blind'] = (1, 2, "Blinding Squall", "Damage dealt by this spell's [Blizzards:ice] inflict [{duration}:duration] turns of [blind]", None, None, {'duration':5})
		self.add_upgrade(BlizzardHarvest())

		self.add_upgrade_tooltip("Blizzard Beasts", self.get_beast)

	def get_description(self):
		return ("Create [Blizzards:ice] over tiles in a [{radius}:radius] tile radius\n"
				"[Blizzards:ice] deal [{damage}:damage] [Ice] damage each turn and have a 50% chance to inflict [frozen]\n"
				"The clouds last for [{duration}:duration] turns")

	def get_beast(self):
		return make_minion(self, BlizzardBeast)

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		add_obj = level.add_obj

		dur = self.get_stat('duration')
		dmg = self.get_stat('damage')

		icicle = self.get_stat('cast_icicle')
		blind = self.get_stat('blind')

		for stage in Burst(level, Point(x, y), self.get_stat('radius'), ignore_walls=not self.get_stat('requires_los')):
			for p in stage:
				cloud = BlizzardCloud(caster, dmg, dur)
				cloud.source = self
				if icicle: cloud.spellcast = Icicle
				if blind: cloud.status_on_damage.append((BlindBuff, dur)) # tuple of (buffcls, duration)
				yield add_obj(cloud, p.x, p.y)

		if self.get_stat('beast'):
			target = Point(x, y)
			radius = self.get_stat('radius')
			for _ in range(self.get_stat('num_summons')):
				self.summon(self.get_beast(), target, radius, sort_dist=False)

	def get_impacted_tiles(self, x, y):
		return [p for stage in Burst(self.caster.level, Point(x, y), self.get_stat('radius'), ignore_walls=not self.get_stat('requires_los')) for p in stage]

class HydraRegrowthBuff(Buff):

	def on_init(self):
		self.name = "Hydra Regrowth"
		self.description = "Each turn heal for any missing HP"

	def on_advance(self):
		to_heal = self.owner.max_hp - self.owner.cur_hp
		if not to_heal: return
		self.owner.heal(to_heal, self)

class SummonFrostfireHydra(Spell):

	def on_init(self):
		self.name = "Frostfire Hydra"

		self.tags = [Tags.Ice, Tags.Fire, Tags.Dragon, Tags.Conjuration]
		self.level = 3
		self.max_charges = 4

		self.minion_range = 5
		self.minion_damage = 8
		self.minion_health = 24

		self.must_target_walkable = True
		self.must_target_empty = True

		self.upgrades['crystal_eyes'] = (1, 4, "Crystalline Hydra", "Half the damage dealt by the hydra is redealt as [Arcane] damage", [Tags.Arcane])
		self.upgrades['regen'] = (1, 4, "Hydra Regrowth", "Hydras heal for any missing HP each turn")
		self.upgrades['dual'] = (1, 3, "Double Dragon", "Also summons a Hydra in a symmetrical position behind the caster")
		self.upgrades['orochi'] = (1, 9, "Orochi", "When you cast this spell, if there is room, summon Orochi instead of a Frostfire Hydra")

		self.add_upgrade_tooltip('Orochi', self.get_orochi)

	def get_description(self):
		return "Summon a Frostfire Hydra"

	def get_hydra(self):
		if self.get_stat('crystal_eyes'): unit = make_minion(self, CrystallineFrostfireHydra)
		else: unit = make_minion(self, FrostfireHydra)
		if self.get_stat('regen'): unit.apply_buff(HydraRegrowthBuff())
		return unit

	def get_orochi(self):
		if self.get_stat('crystal_eyes'): unit = make_minion(self, CrystallineOrochi)
		else: unit = make_minion(self, Orochi)
		if self.get_stat('regen'): unit.apply_buff(HydraRegrowthBuff())
		return unit

	def cast_instant(self, x, y):
		pts = [Point(x, y)]
		if self.get_stat('dual'): pts.append(Point(2 * self.caster.x - x, 2 * self.caster.y - y))
		for p in pts:
			if not self.can_cast(p.x, p.y): continue
			u = self.orochi_if_possible(p.x, p.y) or self.get_hydra()
			self.summon(u, p)

	def orochi_if_possible(self, x, y):
		if not self.get_stat('orochi'): return None
		orochi = self.get_orochi()
		if not self.caster.level.can_stand(x, y, orochi): return None
		return orochi

	def get_impacted_tiles(self, x, y):
		pts = [Point(x, y)]
		final = []
		if self.get_stat('dual'): pts.append(Point(2 * self.caster.x - x, 2 * self.caster.y - y))
		for p in pts:
			if not self.can_cast(p.x, p.y): continue
			u = self.orochi_if_possible(p.x, p.y)
			if u: final.extend([p for p in self.caster.level.get_points_in_ball(p.x, p.y, u.radius, diag=True)])
			else: final.append(p)
		return final

	def get_extra_examine_tooltips(self):
		return [self.get_hydra()] + self.get_upgrade_tooltips()

class RitualOfStormsBuff(Buff):

	def on_init(self):
		self.name = "Ritual of Storms"
		self.color = Tags.Ritual.color
		self.stack_type = STACK_INTENSITY
		self.spell_bonuses[StormBurst]['radius'] = 1
		self.spell_bonuses[StormBurst]['duration'] = 1

class StormBurst(Spell):

	def on_init(self):
		self.name = "Storm Burst"
		self.level = 4
		self.tags = [Tags.Ice, Tags.Lightning, Tags.Sorcery]
		self.damage_type = [Tags.Ice, Tags.Lightning]

		self.max_charges = 3

		self.damage = 20
		self.duration = 3
		self.radius = 5
		self.range = 0

		self.upgrades['stormshield'] = (100, 2, "Stormshield", "Grant affected allies [Ice] and [Lightning] immunity for [{duration}:duration] turns instead of harming them", None, None, {'duration':4})
		self.upgrades['dual'] = (1, 5, "Dual Nova", "Deal both [Lightning] and [Ice] damage to affected tiles")
		self.upgrades[('ritual', 'max_channel')] = ([1, 3], 7, "Ritual of Storms", "Storm Burst can be channeled for up to [{max_channel}:max_channel] turns"
																				"\nIf the ritual is completed, Storm Burst's [radius] and [duration] increase by 1 for the remainder of the level", [Tags.Ritual])
		self.upgrades[('threshold', 'minion_health', 'minion_damage', 'minion_range')] = ([60, 36, 11, 6], 5, "Spirit Nova", "Summon a Storm Spirit for every 60 damage dealt in a single cast", [Tags.Conjuration])

		self.add_upgrade_tooltip("Spirit Nova", self.make_storm_spirit)
		self.add_upgrade_tooltip("Stormshield", lambda: ResistBuff(Tags.Ice, 100), lambda: ResistBuff(Tags.Lightning, 100))

	def get_description(self):
		return ("Deal [{damage}:damage] [Ice] or [Lightning] damage to each tile in a [{radius}:radius] tile burst around the caster\n"
				"Units hit with [Ice] damage are [frozen] for [{duration}:duration] turns\n"
				"Units hit with [Lightning] damage are [stunned] for [{duration}:duration] turns")

	def make_storm_spirit(self):
		u = StormSpirit()
		apply_minion_bonuses(self, u)
		return u

	def cast(self, x, y, channel_cast=False):

		ritual = self.get_stat('ritual')
		if ritual and not channel_cast and self.is_manual_cast():
			self.caster.apply_buff(ChannelBuff(self.cast, Point(x, y)), self.get_stat('max_channel'))
			return

		caster = self.caster
		level = caster.level
		
		damage = self.get_stat('damage')
		duration = self.get_stat('duration')
		
		stormshield = self.get_stat('stormshield')
		dual = self.get_stat('dual')
		threshold = self.get_stat('threshold')
		
		dmg_dealt = 0

		dtypes = self.get_stat('damage_type')

		for stage in Burst(level, caster, self.get_stat('radius'), ignore_walls=not self.get_stat('requires_los')):
			for p in stage:
				if (p.x, p.y) == (caster.x, caster.y): continue
				dtype = random.choice(dtypes)
				unit = level.get_unit_at(p.x, p.y)
				if not unit: level.show_effect(p.x, p.y, dtype); continue

				if stormshield and are_friendly(caster, unit):
					unit.apply_buff(ResistBuff(Tags.Ice, 100), duration)
					unit.apply_buff(ResistBuff(Tags.Lightning, 100), duration)
					continue

				if dtype == Tags.Lightning or dual:
					dmg_dealt += level.deal_damage(p.x, p.y, damage, Tags.Lightning, self)
					unit.apply_buff(Stun(), duration)
				if dtype == Tags.Ice or dual:
					dmg_dealt += level.deal_damage(p.x, p.y, damage, Tags.Ice, self)
					unit.apply_buff(FrozenBuff(), duration)

			yield

		if threshold:
			while dmg_dealt >= threshold:
				self.summon(self.make_storm_spirit(), caster)
				dmg_dealt -= threshold
				yield

		if ritual and channel_cast and not caster.has_buff(ChannelBuff): caster.apply_buff(RitualOfStormsBuff())

	def get_impacted_tiles(self, x, y):
		return [p for stage in Burst(self.caster.level, Point(x, y), self.get_stat('radius'), ignore_walls=not self.get_stat('requires_los')) for p in stage]

class DeathChillDebuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)

	def on_init(self):
		self.name = "Death Chill"
		self.color = Tags.Dark.color
		self.buff_type = BUFF_TYPE_CURSE
		self.owner_triggers[EventOnDeath] = self.on_death
		self.asset = ['status', 'deathchill']
		self.damage = self.spell.get_stat('damage')
		self.radius = self.spell.get_stat('radius')
		self.duration = self.spell.get_stat('duration')
		self.deal_poison = self.spell.get_stat('deal_poison')

	def get_description(self):
		if self.deal_poison: desc = "Each turn, deal [{damage}:damage] [Dark] and [Poison] damage"
		else: desc = "Each turn, deal [{damage}:damage] [Dark] damage"
		desc += "\nOn death, inflict [{damage}:damage] [Ice] damage and [{duration}:duration] turns of [frozen] on enemies within [{radius}:radius] tiles"
		return (desc, {'damage': self.damage, 'radius': self.radius, 'duration': self.duration})

	def on_advance(self):
		self.owner.deal_damage(self.damage, Tags.Dark, self.spell)
		if self.deal_poison: self.owner.deal_damage(self.damage, Tags.Poison, self.spell)

	def on_death(self, evt):
		self.owner.level.queue_spell(self.burst())

	def burst(self):
		spellowner = self.spell.owner
		owner = self.owner
		showbeam = owner.level.show_beam
		for unit in owner.level.get_units_in_ball(owner, self.radius):
			if are_hostile(spellowner, unit):
				showbeam(owner, unit, Tags.Ice, minor=True)
				unit.deal_damage(self.damage, Tags.Ice, self.spell)
				unit.apply_buff(FrozenBuff(), self.duration)
				yield

class DeathChill(Spell):

	def on_init(self):

		self.name = "Death Chill"

		self.level = 3
		self.tags = [Tags.Enchantment, Tags.Dark, Tags.Ice]
		self.damage_type = [Tags.Dark] # only dark b/c don't want things casting it on dark immune thinking it will do ice dmg

		self.duration = 5
		self.radius = 3
		self.damage = 11
		self.range = 6
		self.max_charges = 7

		self.can_target_empty = False

		self.upgrades['deal_poison'] = (1, 2, "Slaughter Chill", "Death Chill also deals [Poison] damage each turn", None, [Tags.Poison])
		self.upgrades['mass_deathchill'] = (1, 7, "Mass Death Chill", "Applies Death Chill to a connected group of enemies")
		self.upgrades['intensity'] = (1, 2, "Compounding Chill", "Death Chill will stack instead of refreshing the duration on subsequent applications")
		self.upgrades['lockjaw'] = (1, 3, "Lockjaw", "Applying Death Chill applies [silence] for the same duration")

	def get_impacted_tiles(self, x, y):
		tiles = [Point(x, y)]
		if self.get_stat('mass_deathchill'): tiles = self.caster.level.get_connected_group_from_point(x, y, check_hostile=self.caster)
		return tiles

	def get_description(self):
		return ("Deal [{damage}:damage] [Dark] damage to the target each turn for [{duration}:duration] turns\n"
				"When a unit dies while afflicted with Death Chill, they explode in a flurry of ice\n"
				"The explosion inflicts [{damage}:damage] [Ice] damage and [{duration}:duration] turns of [frozen] on enemies within [{radius}:radius] tiles")

	def get_death_chill_buff(self):
		buff = DeathChillDebuff(self)
		if self.get_stat('intensity'): buff.stack_type = STACK_INTENSITY
		return buff

	def get_extra_examine_tooltips(self):
		return [self.get_death_chill_buff(), FrozenBuff()] + self.get_upgrade_tooltips()

	def cast_instant(self, x, y):
		targets = [self.caster.level.get_unit_at(x, y)]
		if self.get_stat('mass_deathchill'):
			targets = self.caster.level.get_connected_group_from_point(x, y, check_hostile=self.caster) #Currently it's going to apply death chill to allies as well, let me know if you want this to change

		for target in targets:
			if target:
				dur = self.get_stat('duration')
				buff = self.get_death_chill_buff()
				target.apply_buff(buff, dur)
				if self.get_stat('lockjaw'):
					target.apply_buff(Silence(), dur)

class IcePhoenixBuff(Buff):

	def __init__(self, radius):
		Buff.__init__(self)
		self.radius = radius

	def on_init(self):
		self.owner_triggers[EventOnDeath] = self.on_death
		self.name = "Phoenix Freeze"

	def get_tooltip(self):
		return "On death, inflict 25 [Ice] damage and 4 turns of [frozen] on enemies in a [{radius}:radius] tile burst\nAllies gain [2 SH:shields] instead"

	def fmt_dict(self):
		return {'radius':self.radius}

	def on_death(self, evt):
		for p in self.owner.level.get_points_in_ball(self.owner.x, self.owner.y, self.radius):
			unit = self.owner.level.get_unit_at(*p)
			if unit:
				if are_hostile(unit, self.owner):
					self.owner.level.deal_damage(p.x, p.y, 25, Tags.Ice, self)
					unit.apply_buff(FrozenBuff(), 4)
				else: unit.add_shields(2)
			else: self.owner.level.show_effect(p.x, p.y, Tags.Ice)

class SummonIcePhoenix(Spell):

	def on_init(self):
		self.name = "Ice Phoenix"
		self.level = 5
		self.max_charges = 2
		self.tags = [Tags.Conjuration, Tags.Ice, Tags.Holy]

		self.minion_health = 125
		self.minion_damage = 9
		self.minion_range = 4
		self.lives = 2

		self.radius = 4

		self.upgrades['regen'] = (1, 5, "Restorative Phoenix", "The Ice Phoenix can cast your Regeneration Aura on a 12 turn cooldown")
		self.upgrades['lives'] = (3, 2, "Reincarnations", "The Ice Phoenix will reincarnate 3 additional times")
		self.upgrades['ice_aura'] = (1, 6, "Polar Aura", "The Ice Phoenix deals 2 [Ice] damage to enemies within [{radius}:radius] tiles each turn", None, None, {'radius':4})
		self.upgrades['freezing'] = (1, 1, "Freezing Attack", "The Ice Phoenix's ranged attack [freezes] its target for 3 turns")

		self.must_target_empty = True


	def get_description(self):
		return "Summon an Ice Phoenix"

	def make_phoenix(self):
		phoenix = Unit()
		phoenix.max_hp = self.get_stat('minion_health')
		phoenix.name = "Ice Phoenix"

		phoenix.tags = [Tags.Ice, Tags.Holy]
		phoenix.buffs.append(IcePhoenixBuff(self.get_stat('radius')))
		phoenix.buffs.append(ReincarnationBuff(self.get_stat('lives')))

		if self.get_stat('ice_aura'): phoenix.buffs.append(DamageAuraBuff(damage=2, damage_type=Tags.Ice, radius=self.get_stat('radius')))
		if self.get_stat('regen'): grant_minion_spell(RegenAuraSpell, phoenix, self.owner, cool_down=12)
		phoenix.flying = True
		phoenix.resists[Tags.Ice] = 100
		phoenix.resists[Tags.Dark] = -50
		if self.get_stat('freezing'): phoenix.spells.append(SimpleRangedAttack(damage=self.get_stat('minion_damage'), range=self.get_stat('minion_range'), damage_type=Tags.Ice, buff=FrozenBuff, buff_duration=3))
		else: phoenix.spells.append(SimpleRangedAttack(damage=self.get_stat('minion_damage'), range=self.get_stat('minion_range'), damage_type=Tags.Ice))
		return phoenix

	def cast_instant(self, x, y):
		phoenix = self.make_phoenix()
		self.summon(phoenix, target=Point(x, y))

	def get_extra_examine_tooltips(self):
		return [self.make_phoenix()] + self.get_upgrade_tooltips()


class WordOfIce(Spell):

	def on_init(self):
		self.name = "Word of Ice"
		self.level = 7
		self.tags = [Tags.Ice, Tags.Word]
		self.max_charges = 1
		self.duration = 5
		self.damage = 50
		self.range = 0

		self.upgrades['killer'] = (1, 6, "Killer Cold", "[Ice] damage is dealt to all enemies, not only those with the [Fire] tag")
		self.upgrades['echo'] = (1, 5, "Echoing Ice", "Auto recast in 10 turns")
		self.upgrades['endless_ice'] = (1, 2, "Endless Ice", "Regain a charge of your other [Ice] spells on cast")
		self.upgrades[('word_of_wind', 'num_targets')] = ([1, 3], 7, "Word of Wind", "Casts Chill Wind on up to [{num_targets}:num_targets] random enemies")


	def cast(self, x, y, is_echo=False):
		caster = self.caster
		level = caster.level
		if self.get_stat('echo') and not is_echo: caster.apply_buff(EchoCast(self), 10)

		if self.get_stat('endless_ice'):
			eligible_spells = [s for s in caster.spells if Tags.Ice in s.tags and s != self]
			for s in eligible_spells: s.refund_charges(1); s.do_ui_flash(Tags.Ice)

		if self.get_stat('word_of_wind'):
			targets = [u for u in level.units if are_hostile(caster, u)]
			if targets:
				random.shuffle(targets)
				chill_wind = caster.get_or_make_spell(IceWind)
				hits = 0
				maxhits = self.get_stat('num_targets')
				for u in targets:
					if not u.is_alive(): continue
					for _ in level.act_cast(self.caster, chill_wind, u.x, u.y,  pay_costs=False, queue=False): pass
					hits += 1
					if hits >= maxhits: break

		units = [u for u in level.units if are_hostile(u, caster)]
		random.shuffle(units)
		duration = self.get_stat('duration')
		damage = self.get_stat('damage')
		killer = self.get_stat('killer')
		for u in units:
			u.apply_buff(FrozenBuff(), duration)
			if killer or Tags.Fire in u.tags: u.deal_damage(damage, Tags.Ice, self)
			if random.random() < .3: yield

	def get_impacted_tiles(self, x, y):
		return [u for u in self.caster.level.units if are_hostile(u, self.caster) and (u.resists[Tags.Ice] < 100 or Tags.Fire in u.tags)]

	def get_description(self):
		return ("All enemies are [frozen] for [{duration}:duration] turns\n"
				"Deal [{damage}:damage] [Ice] damage to [Fire] enemies")

class CorrosionDebuff(Buff):

	def on_init(self):
		self.name = "Corrosion"
		self.buff_type = BUFF_TYPE_CURSE
		self.stack_type = STACK_INTENSITY
		self.color = Tags.Dark.color

	def on_applied(self, owner):
		self.resists[random.choice(damage_tags)] = -10

	def get_tooltip(self):
		return "Decrease a random damage resistance by 10%"

class Icicle(Spell):

	def on_init(self):

		self.name = "Icicle"

		self.tags = [Tags.Ice, Tags.Sorcery]
		self.damage_type = [Tags.Ice, Tags.Physical]

		self.radius = 1
		self.damage = 6
		self.level = 1

		self.range = 6

		self.max_charges = 14

		self.upgrades[('freezing', 'duration')] = ([1, 3], 1, "Freezing", "[Freeze] the target for [{duration}:duration] turns")
		self.upgrades['ice_spear'] = (1, 2, "Ice Spear", "Deals [Physical] damage in a beam to the target")
		self.upgrades['storm_spike'] = (1, 5, "Storm Spike", "Icicle also deals [Lightning] damage to affected tiles\nIcicle can be cast on any tile containing a cloud", [Tags.Lightning], [Tags.Lightning])
		self.upgrades['corrosive_shard'] = (1, 5, "Corrosive Shard", "Icicle also deals [Poison] and [Dark] damage to the target\nReduces a random resistance by 10%", [Tags.Dark], [Tags.Poison, Tags.Dark])

		self.add_upgrade_tooltip("Corrosive Shard", CorrosionDebuff)


	def get_description(self):
		return ("Deal [{damage}:damage] [Physical] damage to the target\n"
				"Then, deal [{damage}:damage] [Ice] damage to the target and a [{radius}:radius] tile burst around it\n"
				"Turns chasms into floors")

	def can_cast(self, x, y):
		if self.get_stat('storm_spike'):
			cloud = self.caster.level.tiles[x][y].cloud
			if cloud and not isinstance(cloud, SpiderWeb): return True
		return Spell.can_cast(self, x, y)

	def get_targetable_tiles(self):
		tiles = Spell.get_targetable_tiles(self)
		if not self.get_stat('storm_spike'): return tiles
		seen = set(tiles)
		for cloud in self.caster.level.clouds:
			if isinstance(cloud, SpiderWeb): continue
			point = Point(cloud.x, cloud.y)
			if point in seen: continue
			tiles.append(point)
			seen.add(point)
		return tiles

	def get_ai_target(self):
		tiles = self.get_targetable_tiles()
		if not tiles: return None
		random.shuffle(tiles)
		caster = self.caster
		getu = caster.level.get_unit_at
		for t in tiles:
			u = getu(t.x, t.y)
			if not u: continue
			if not are_hostile(u, caster): continue
			if not self.can_harm(u): continue
			return t
		return None

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		dmg = self.get_stat('damage')
		spike = self.get_stat('storm_spike')

		if self.get_stat('ice_spear'):
			for p in level.get_points_in_line(caster, Point(x, y), find_clear=True)[1:-1]:
				level.projectile_effect(p.x, p.y, proj_name='ice_bolt', proj_origin=caster, proj_dest=Point(x, y))
				yield
				level.deal_damage(p.x, p.y, dmg, Tags.Physical, self)

		else:
			for p in level.get_points_in_line(caster, Point(x, y), find_clear=True)[1:-1]:
				level.show_effect(p.x, p.y, Tags.Physical, minor=True)

		unit = level.get_unit_at(x, y)
		level.deal_damage(x, y, dmg, Tags.Physical, self)

		if unit and self.get_stat('freezing'): unit.apply_buff(FrozenBuff(), self.get_stat('duration'))

		if unit and self.get_stat('corrosive_shard'):
			unit.apply_buff(CorrosionDebuff())
			unit.deal_damage(dmg, Tags.Poison, self)
			unit.deal_damage(dmg, Tags.Dark, self)

		yield

		tiles = level.tiles
		make_floor = level.make_floor
		for stage in Burst(level, Point(x, y), self.get_stat('radius'), ignore_walls=not self.get_stat('requires_los')):
			for p in stage:
				level.deal_damage(p.x, p.y, dmg, Tags.Ice, self)
				if spike: level.deal_damage(p.x, p.y, dmg, Tags.Lightning, self)
				if tiles[p.x][p.y].is_chasm: make_floor(p.x, p.y)
			yield



	def get_impacted_tiles(self, x, y):

		points = [p for stage in Burst(self.caster.level, Point(x, y), self.get_stat('radius'), ignore_walls=not self.get_stat('requires_los')) for p in stage]
		if self.get_stat('ice_spear'):
			beam = [p for p in self.caster.level.get_points_in_line(self.caster, Point(x, y))[1:-1]]
			points.extend(beam)

		return points

class IceWind(Spell):

	def on_init(self):
		self.name = "Chill Wind"

		self.level = 5
		self.tags = [Tags.Ice, Tags.Sorcery]

		self.max_charges = 3

		self.damage = 21
		self.duration = 6

		self.range = RANGE_GLOBAL
		self.requires_los = False

		self.upgrades[('damage', 'duration')] = ([21, 6], 4, "Harsh Winds", "")
		self.upgrades['storm'] = (1, 4, "Storm Front", "Chill Wind creates [Blizzards:ice] on affected tiles\nThe clouds deal [{damage}:damage] [Ice] damage and last for [{duration}:duration] turns", [Tags.Nature], None, {'damage':5, 'duration':5})
		self.upgrades['mirror'] = (1, 4, "Dual Wind", "Chill Wind also affects a symmetric area behind the caster")
		self.upgrades['blaze'] = (1, 6, "Arcane Storm", "When Chill Wind kills a unit, cast Blazerip at their location", [Tags.Arcane])

	def get_description(self):
		return ("Inflict [{damage}:damage] [Ice] damage and [{duration}:duration] turns of [frozen] on units in a 3 tile wide line perpendicular to the caster")

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		deal_damage = level.deal_damage
		getu = level.get_unit_at

		damage = self.get_stat('damage')
		duration = self.get_stat('duration')

		storm = self.get_stat('storm')
		if storm: storm_dmg = self.get_stat('damage', base=5); storm_dur = self.get_stat('duration', base=5)

		blaze = self.get_stat('blaze')
		if blaze: blazerip = caster.get_or_make_spell(Blazerip)


		for p in self.get_impacted_tiles(x, y):
			unit = getu(p.x, p.y)
			deal_damage(p.x, p.y, damage, Tags.Ice, self)

			if unit:
				if unit.is_alive():
					unit.apply_buff(FrozenBuff(), duration)
				elif blaze:
					for _ in level.act_cast(caster, blazerip, p.x, p.y, pay_costs=False, queue=False): pass

			if random.random() < .4: yield
			if storm: yield level.add_obj(BlizzardCloud(caster, damage=storm_dmg, duration=storm_dur), p.x, p.y)


	def get_impacted_tiles(self, x, y):
		line = self.caster.level.get_perpendicular_line(self.caster, Point(x, y))
		result = set()
		for p in line:
			for q in self.caster.level.get_points_in_rect(p.x-1, p.y-1, p.x+1, p.y+1):
				result.add(q)
		if self.get_stat('mirror'):
			mirrored_line = self.caster.level.get_perpendicular_line(self.caster, Point(2*self.caster.x-x, 2*self.caster.y-y))
			for p in mirrored_line:
				for q in self.caster.level.get_points_in_rect(p.x-1, p.y-1, p.x+1, p.y+1):
					result.add(q)
		return result

class HungryIceWallBuff(Buff):

	def on_init(self):
		self.name = "Hungry Wall"
		self.description = "Gain +1 duration when Ice Lash hits an enemy"
		self.owner_triggers[EventOnSpellCast] = self.on_cast

	def on_cast(self, evt):
		if self.owner.turns_to_death is None: return
		if not isinstance(evt.spell, PullAttack): # wrong spell, return
			return
		self.owner.turns_to_death += 1

class IceWall(Spell):

	def on_init(self):
		self.name = "Wall of Ice"
		self.minion_health = 36
		self.minion_duration = 15
		self.minion_range = 3
		self.minion_damage = 5

		self.level = 4
		self.max_charges = 2

		self.tags = [Tags.Conjuration, Tags.Ice]

		self.range = 6
		self.radius = 2

		self.upgrades[('minion_range', 'hungry_wall')] = ([3, 1], 2, "Hungry Wall", "The Ice Elementals' attack is replaced with Ice Lash\nIce Lash drags the target 1 tile toward the elemental and grants them +1 remaining duration")
		self.upgrades[('excavate', 'requires_los')] = ([1, -1], 4, "Glacial Excavator", "Walls and chasms in the impacted area are turned to floors before having Ice Elementals summoned on them")
		self.upgrades['ice_box'] = (1, 6, "Ice Box", "Affects tiles in lines rotated around the caster, forming a square")
		self.upgrades['radius'] = (50, 7, "Endless Wall")

	def fmt_dict(self):
		d = Spell.fmt_dict(self)
		d['width'] = 1 + 2*d['radius']
		return d

	def get_description(self):
		return "Summons a group of temporary Ice Elementals in a [{width}:radius] tile line perpendicular to the caster"

	def make_elemental(self):
		elemental = Unit()
		elemental.name = "Ice Elemental"
		if self.get_stat('hungry_wall'):
			ice_lash = (PullAttack(damage=self.get_stat('minion_damage'), damage_type=Tags.Ice, range=self.get_stat('minion_range'), color=Tags.Ice.color))
			ice_lash.name = "Ice Lash"
			elemental.spells.append(ice_lash)
		else:
			snowball = SimpleRangedAttack(damage=self.get_stat('minion_damage'), damage_type=Tags.Ice, range=self.get_stat('minion_range'))
			snowball.name = "Snowball"
			elemental.spells.append(snowball)

		elemental.max_hp = self.get_stat('minion_health')
		elemental.stationary = True
		elemental.tags = [Tags.Ice]
		elemental.resists[Tags.Physical] = 50
		elemental.resists[Tags.Fire] = -100
		elemental.resists[Tags.Ice] = 100
		elemental.turns_to_death = self.get_stat('minion_duration')

		return elemental

	def cast(self, x, y):
		level = self.caster.level
		hungry = self.get_stat('hungry_wall')
		excavate = self.get_stat('excavate')

		for p in self.get_impacted_tiles(x, y):
			elemental = self.make_elemental()
			if hungry: elemental.apply_buff(HungryIceWallBuff())
			if excavate and (level.tiles[p.x][p.y].is_wall() or level.tiles[p.x][p.y].is_chasm): level.make_floor(p.x, p.y)
			self.summon(elemental, target=p, radius=0)
			yield

	def get_impacted_tiles(self, x, y):
		caster = self.caster
		level = caster.level
		length = self.get_stat('radius')

		dx, dy = x - caster.x, y - caster.y
		rotations = [(dx, dy)]
		if self.get_stat('ice_box'): rotations += [(-dy, dx), (-dx, -dy), (dy, -dx)]
		pts = []
		for vx, vy in rotations:
			dest = Point(caster.x + vx, caster.y + vy)
			pts.extend(level.get_perpendicular_line(caster, dest, length=length))
		if self.get_stat('excavate'): pts = [p for p in pts if not level.get_unit_at(p.x, p.y)]
		else: pts = [p for p in pts if level.can_walk(p.x, p.y, check_unit=True)]
		return list(dict.fromkeys(pts))

	def get_extra_examine_tooltips(self):
		return [self.make_elemental()] + self.get_upgrade_tooltips()

class AftershocksBuff(Buff):

	def on_init(self):
		self.name = "Aftershocks"
		self.buff_type = BUFF_TYPE_BLESS
		self.color = Tags.Nature.color
		self.spell_bonuses[EarthquakeSpell]['radius'] = 2
		self.stack_type = STACK_INTENSITY

class EarthquakeSpell(Spell):

	def on_init(self):
		self.name = "Earthquake"

		self.radius = 5
		self.max_charges = 3
		self.range = 0

		self.damage = 21
		self.level = 3
		self.tags = [Tags.Sorcery, Tags.Nature]
		self.damage_type = [Tags.Physical]

		self.upgrades['breach'] = (1, 4, "Chthonic Breach", "Eldritch tendrils reach forth from affected chasm tiles, each dealing [{damage}:damage] [Arcane] damage to the nearest enemy", [Tags.Arcane], [Tags.Arcane], {'damage':7})
		self.upgrades[('radius_buff', 'duration')] = ([1, 2], 3, "Aftershocks", "When you cast Earthquake, it gains +2 radius for [{duration}:duration] turns")
		self.upgrades[('stun', 'duration')] = ([1, 2], 4, "Magnitude 8.0", "Earthquake is guaranteed to affect all tiles in the area, and [stuns] affected units for [{duration}:duration] turns")
		self.upgrades['shrapnel_quake'] = (1, 3, "Shrapnel Quake", "Cast Shrapnel Blast on affected wall tiles", [Tags.Metallic, Tags.Fire])


	def get_description(self):
		return ("Invoke an earthquake with a [{radius}:radius] tile radius\n"
				"Each tile in the area has a 50% chance to be affected\n"
				"Enemies on affected tiles take [{damage}:damage] [Physical] damage\n"
				"Walls on affected tiles are destroyed")

	def cast(self, x, y):
		caster = self.caster
		level = caster.level

		damage = self.get_stat('damage')
		duration = self.get_stat('duration')

		stun = self.get_stat('stun')
		shrapnel_quake = self.get_stat('shrapnel_quake')
		shrapnel_spell = caster.get_or_make_spell(ShrapnelBlast) if shrapnel_quake else None

		breach = self.get_stat('breach')
		breach_damage = self.get_stat('damage', base=7)

		points = list(level.get_points_in_ball(x, y, radius=self.get_stat('radius')))
		random.shuffle(points)
		for p in points:
			unit = level.get_unit_at(p.x, p.y)
			if unit == caster: continue
			if unit and are_friendly(caster, unit): continue
			if not stun and random.random() < .5: continue # only hits 50% unless you have stun upgrade
			level.show_effect(p.x, p.y, Tags.Physical)
			if random.random() < .3: yield
			if unit:
				if stun: unit.apply_buff(Stun(), duration)
				unit.deal_damage(damage, Tags.Physical, self)
				continue

			tile = level.tiles[p.x][p.y]
			if not tile.can_see:
				if shrapnel_quake: level.act_cast(caster, shrapnel_spell, p.x, p.y, pay_costs=False)
				else: caster.level.make_floor(p.x, p.y)

			if breach and tile.is_chasm:
				targets = [u for u in level.units if are_hostile(caster, u)]
				if targets:
					random.shuffle(targets)
					targets = sorted(targets, key=lambda u: level.unit_distance(p, u))
					target = targets[0]
					level.show_path_effect(p, targets[0], Tags.Arcane)
					level.deal_damage(target.x, target.y, breach_damage, Tags.Arcane, self)
					yield


		if self.get_stat('radius_buff'): caster.apply_buff(AftershocksBuff(), duration)

class SearingSealBuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)

	def on_init(self):
		self.name = "Seal of Searing"
		self.color = Tags.Fire.color
		self.chaos_seal = self.spell.get_stat('chaos_seal')
		self.inner_fire = self.spell.get_stat('inner_fire')
		self.rebuke = self.spell.get_stat('rebuke')
		self.fire_harvest = self.spell.get_stat('fire_harvest')
		self.dtypes = [Tags.Fire]
		self.charges = [0]
		if self.chaos_seal:
			self.dtypes = [Tags.Fire, Tags.Lightning, Tags.Physical]
			self.charges = [0, 0, 0]
			self.color = Tags.Chaos.color
		if self.inner_fire:
			self.tag_bonuses_pct[Tags.Fire]['damage'] = self.spell.caster.get_mastery(Tags.Fire)
		self.stack_type = STACK_REPLACE
		self.buff_type = BUFF_TYPE_BLESS
		self.global_triggers[EventOnDamaged] = self.on_damage
		if self.rebuke:
			self.owner_triggers[EventOnDamaged] = self.on_owner_damaged
			self.damage = self.spell.get_stat('damage')

	def get_description(self):
		num_charges = [0, 0, 0]
		for i in range(len(self.charges)): num_charges[i] += self.charges[i]
		fmt = {'fire_charges': num_charges[0]}

		if self.chaos_seal:
			fmt['lightning_charges'] = num_charges[1]
			fmt['physical_charges'] = num_charges[2]
			desc = ("When an enemy takes [Fire], [Lightning], or [Physical] damage, gain that many charges\n"
					"On expiration, for each damage type, deal 1 damage to each enemy in line of sight for every 5 charges\n"
					"[Fire] charges: {fire_charges}\n"
					"[Lightning] charges: {lightning_charges}\n"
					"[Physical] charges: {physical_charges}")
		else:
			desc = ("When an enemy takes [Fire] damage, gain that many charges\n"
					"On expiration, deal 1 damage to each enemy in line of sight for every 5 charges\n"
					"[Fire] charges: {fire_charges}")

		if self.rebuke:
			desc += "\nWhen an enemy damages you, deal [{damage}:damage] [Fire] damage to them"
			fmt['damage'] = self.damage
		if self.fire_harvest:
			desc += "\nOn expiration, summon a Fire Spirit for every 100 [Fire] charges"
		return (desc, fmt)


	def on_damage(self, evt):
		if evt.damage < 1: return
		if not are_hostile(self.owner, evt.unit): return
		for i in range(len(self.dtypes)):
			if evt.damage_type == self.dtypes[i]:
				self.charges[i] += evt.damage

	def on_owner_damaged(self, evt):
		if not evt.source or not evt.source.owner: return
		if not are_hostile(self.owner, evt.source.owner): return
		evt.source.owner.deal_damage(self.damage, Tags.Fire, self.spell)

	def on_unapplied(self):
		self.owner.level.queue_spell(self.sear())

	def sear(self):
		enemies = [u for u in self.owner.level.get_units_in_los(self.owner) if are_hostile(self.owner, u)]
		for i in range(len(self.dtypes)):
			damage = self.charges[i] // 5
			for u in enemies:
				u.deal_damage(damage, self.dtypes[i], self.spell)
				yield

		if self.fire_harvest:
			while self.charges[0] >= 100:
				self.charges[0] -= 100
				self.summon(self.spell.make_fire_spirit())

class SearingSealSpell(Spell):

	def on_init(self):
		self.name = "Searing Seal"

		self.tags = [Tags.Fire, Tags.Enchantment]
		self.level = 4
		self.max_charges = 4
		self.range = 0
		self.duration = 8

		self.upgrades['inner_fire'] = (1, 1, "Inner Fire", "Searing Seal grants a percentage [damage] bonus to [Fire] spells and equipment\nThe percentage is equal to your [Fire] mastery")
		self.upgrades[('rebuke', 'damage')] = ([1, 1], 3, "Searing Rebuke", "Searing Seal deals [{damage}:damage] [Fire] damage to enemies that damage you")
		self.upgrades['chaos_seal'] = (1, 5, "Chaos Seal", "Gain charges separately for [Fire], [Lightning], and [Physical] damage, and deal damage of each type each on expiration", [Tags.Chaos])
		self.upgrades[('fire_harvest', 'minion_health', 'minion_range', 'minion_damage')] = ([1, 10, 5, 5], 4, "Fire Harvest", "For every 100 charges stored, summon a Fire Spirit", [Tags.Conjuration])

		self.add_upgrade_tooltip("Fire Harvest", self.make_fire_spirit)

	def get_description(self):
		return ("Gain Seal of Searing for [{duration}:duration] turns\n"
				"When enemies take [Fire] damage, the seal gains that many charges\n"
				"When Seal of Searing is removed, it deals [1 Fire:fire] damage to enemies in line of sight for every 5 charges it has")

	def make_fire_spirit(self):
		u = FireSpirit()
		apply_minion_bonuses(self, u)
		return u

	def cast_instant(self, x, y):
		self.caster.apply_buff(SearingSealBuff(self), self.get_stat('duration'))

	def get_extra_examine_tooltips(self):
		return [SearingSealBuff(self)] + self.get_upgrade_tooltips()

class DepravityBuff(Buff):

	def on_init(self):
		self.name = 'Depravity'
		self.color = Tags.Blood.color
		self.global_triggers[EventOnDeath] = self.on_death
		self.global_bonuses['damage'] = 0
		self.stack_type = STACK_DURATION

	def get_description(self):
		return 'Pay 1 HP when a unit dies to gain +1 [damage] to all spells and equipment'

	def on_death(self, evt):
		if self.owner.cur_hp < 2: return
		self.owner.cur_hp -= 1
		self.owner.level.log(("[{unit}:{color}] paid {amount} HP to feed their [Depravity:blood]", {"unit": self.owner.name, "color": log_color(self.owner), "amount": 1}))
		self.owner.level.event_manager.raise_event(EventOnSpendHP(self.owner, 1), self.owner)
		self.owner.level.show_effect(self.owner.x, self.owner.y, Tags.Blood, minor=True)
		self.global_bonuses['damage'] += 1
		self.owner.adjust_global_bonus('damage', 1) # mutate the owner's bonus dictionary, the unapply should remove the mutated total of the buff, evening out


class PurityBuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)

	def on_init(self):
		self.name = "Purity"
		self.description = "Immune to debuffs"
		self.stack_type = STACK_REPLACE
		self.color = Tags.Holy.color
		self.asset = ['status', 'purity']
		self.crusader = self.spell.get_stat('crusader')
		self.sin_eater = self.spell.get_stat('sin_eater')
		self.depravity = self.spell.get_stat('depravity')
		self.depravity_duration = self.spell.get_stat('duration')
		if self.crusader: self.owner_triggers[EventOnSpellCast] = self.on_cast

		if self.sin_eater:
			self.owner_triggers[EventOnBuffAttemptApply] = self.on_attempt
			self.resists[Tags.Dark] = 100

	def get_description(self):
		desc = "Immune to debuffs"
		if self.sin_eater: desc += "\nGain [3 SH:shields] when Purity removes or blocks a debuff"
		if self.crusader: desc += "\nCasting a [Holy] spell extends Purity by 3 turns"
		if self.depravity: desc += "\nWhen Purity ends, gain [Depravity:blood] for [{duration}:duration] turns"
		return (desc, {'duration': self.depravity_duration})

	def on_applied(self, owner):
		self.owner.debuff_immune = True

		buffs = list(self.owner.buffs)
		for b in buffs:
			if b.buff_type == BUFF_TYPE_CURSE:
				self.owner.remove_buff(b)
				if self.sin_eater: self.owner.add_shields(3)

	def on_attempt(self, evt):
		if evt.buff.buff_type == BUFF_TYPE_CURSE: self.owner.add_shields(3)

	def on_unapplied(self):
		self.owner.debuff_immune = False
		if self.depravity: self.owner.apply_buff(DepravityBuff(), self.depravity_duration)

	def on_cast(self, evt):
		if not Tags.Holy in evt.spell.tags: return
		self.turns_left += 3

class PuritySpell(Spell):

	def on_init(self):
		self.name = "Purity"
		self.duration = 6
		self.level = 4
		self.max_charges = 4
		self.range = 0
		self.tags = [Tags.Holy, Tags.Enchantment]

		self.upgrades['sin_eater'] = (1, 5, "Sin Eater", "Purity grants [100% Dark:dark] resist\nEach debuff removed or blocked by Purity grants [3 SH:shields]", [Tags.Dark])
		self.upgrades['crusader'] = (1, 1, "Crusader", "Casting a [Holy] spell extends Purity's remaining duration by 3 turns")
		self.upgrades[('aura', 'radius')] = ([1, 5], 2, "Aura of Purity", "Purity is also applied to allies within [{radius}:radius] tiles")
		self.upgrades['depravity'] = (1, 3, "Depravity", "When Purity ends, gain [Depravity:blood] for [{duration}:duration] turns\n[Depravity:blood] causes you to pay 1 HP when a unit dies to gain a +1 damage bonus to all spells and equipment while it lasts", [Tags.Blood], None, {'duration':6})

		self.add_upgrade_tooltip("Depravity", DepravityBuff)

	def get_description(self):
		return ("Lose all debuffs\n"
				"You cannot gain new debuffs\n"
				"Lasts [{duration}:duration] turns")

	def get_impacted_tiles(self, x, y):
		if not self.get_stat('aura'): return [self.caster]
		return [u for u in self.caster.level.get_units_in_ball(self.caster, self.get_stat('radius')) if u.team==self.caster.team]

	def cast_instant(self, x, y):
		dur = self.get_stat('duration')
		for u in self.get_impacted_tiles(x, y):
			u.apply_buff(PurityBuff(self), dur)
			u.level.show_effect(u.x, u.y, Tags.Holy)

	def get_extra_examine_tooltips(self):
		return [PurityBuff(self)] + self.get_upgrade_tooltips()

class TwilightGazeBuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)

	def on_init(self):
		self.name = "Twilight"
		self.buff_type = BUFF_TYPE_CURSE
		self.resists[Tags.Dark] = -self.spell.get_stat('resistance_debuff')
		self.resists[Tags.Holy] = -self.spell.get_stat('resistance_debuff')
		if self.spell.get_stat('arcane'): self.resists[Tags.Arcane] = -self.spell.get_stat('resistance_debuff')
		if self.spell.get_stat('eclipse'): self.global_bonuses_pct['range'] = -50
		self.color = Tags.Dark.color
		self.stack_type = STACK_DURATION


class TwilightGazeSpell(Spell):

	def on_init(self):
		self.name = "Twilight Gaze"
		self.tags = [Tags.Holy, Tags.Dark, Tags.Enchantment, Tags.Eye]
		self.range = 0
		self.level = 6
		self.max_charges = 4

		self.resistance_debuff = 50
		self.duration = 10

		self.upgrades['resistance_debuff'] = (50, 5)
		self.upgrades['piercing_gaze'] = (1, 4, "Piercing Gaze", "Twilight Gaze affects all enemies, not just those in your light of sight")
		self.upgrades['arcane'] = (1, 3, "Arcane Gaze", "Twilight Gaze also reduces [Arcane] resist", [Tags.Arcane])
		self.upgrades['eclipse'] = (1, 2, "Shrouded Twilight", "Twilight Gaze also inflicts a 50% range penalty on enemy spells")

	def get_description(self):
		return ("Enemies in your line of sight lose {resistance_debuff} [Dark] and [Holy] resist\n"
				"Lasts [{duration}:duration] turns")

	def cast(self, x, y):
		if self.get_stat('piercing_gaze'): units = [u for u in self.caster.level.units if are_hostile(u, self.caster)]
		else: units = [u for u in self.caster.level.get_units_in_los(self.caster) if are_hostile(u, self.caster)]
		path_tags = [Tags.Dark, Tags.Holy]
		if Tags.Arcane in self.tags: path_tags.append(Tags.Arcane)
		for u in units:
			self.caster.level.show_path_effect(self.caster, u, path_tags)
			u.apply_buff(TwilightGazeBuff(self), self.get_stat('duration'))
			yield

	def get_extra_examine_tooltips(self):
		return [TwilightGazeBuff(self)] + self.get_upgrade_tooltips()

class SlimeformBuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)

	def on_init(self):
		self.name = "Slime Form"
		self.transform_asset = ["char", "slime_form"]
		self.stack_type = STACK_TYPE_TRANSFORM
		self.color = Tags.Slime.color
		self.resists[Tags.Poison] = 100
		self.resists[Tags.Physical] = 50

		self.num_summons = 0

		spawners = []
		if self.spell.get_stat('fire_slimes'): spawners.append(RedSlime)
		if self.spell.get_stat('ice_slimes'): spawners.append(IceSlime)
		if self.spell.get_stat('electric_slimes'): spawners.append(ElectricSlime)
		if self.spell.get_stat('void_slimes'): spawners.append(VoidSlime)
		if self.spell.get_stat('blood_slimes'): spawners.append(BloodSlime)
		self.chromatic = self.spell.get_stat('chromatic_oozemancer')
		self.num_summons = self.spell.get_stat('num_summons') if self.chromatic else 0
		if not spawners: spawners.append(GreenSlime)
		self.spawners = spawners


	def get_description(self):
		lines = []
		for spawn_func in self.spawners:
			slime_name = spawn_func().name
			article = "an" if slime_name[0].lower() in "aeiou" else "a"
			lines.append("Each turn, summon %s %s" % (article, slime_name))
		if self.chromatic:
			lines.append("Each turn, summon [{num_summons}:num_summons] additional random slimes")
			lines.append("Additional random slimes can be any slime type and can repeat")
		return ("\n".join(lines), {'num_summons': self.num_summons})

	def on_advance(self):
		spawners = list(self.spawners)
		if self.chromatic:
			for i in range(self.num_summons):
				spawners.append(random.choice(slime_types))

		for spawn_func in spawners:
			unit = make_minion(self.spell, spawn_func) # self.make_summon(spawn_func)
			self.spell.summon(unit)

class SlimeformSpell(Spell):

	def on_init(self):
		self.name = "Slime Form"
		self.tags = [Tags.Enchantment, Tags.Conjuration, Tags.Slime]
		self.level = 3
		self.max_charges = 2
		self.range = 0
		self.duration = 12

		self.upgrades['fire_slimes'] = (1, 3, "Fire Slime", "Instead of a Green Slime, summon a Fire Slime", [Tags.Fire])
		self.upgrades['ice_slimes'] = (1, 3, "Ice Slime", "Instead of a Green Slime, summon an Ice Slime", [Tags.Ice])
		self.upgrades['electric_slimes'] = (1, 3, "Electric Slime", "Instead of a Green Slime, summon an Electric Slime", [Tags.Lightning])
		self.upgrades['void_slimes'] = (1, 3, "Void Slime", "Instead of a Green Slime, summon a Void Slime", [Tags.Arcane])
		self.upgrades[('hp_cost', 'blood_slimes')] = ([3, 1], 3, "Blood Slime", "Instead of a Green Slime, summon a Blood Slime", [Tags.Blood])
		self.upgrades[('num_summons', 'chromatic_oozemancer')] = ([4, 1], 9, "Chromatic Oozemancer", "Summon [{num_summons}:num_summons] additional random slimes each turn", [Tags.Chaos])

		self.add_upgrade_tooltip("Fire Slime", lambda: self.make_slime(RedSlime))
		self.add_upgrade_tooltip("Ice Slime", lambda: self.make_slime(IceSlime))
		self.add_upgrade_tooltip("Electric Slime", lambda: self.make_slime(ElectricSlime))
		self.add_upgrade_tooltip("Void Slime", lambda: self.make_slime(VoidSlime))
		self.add_upgrade_tooltip("Blood Slime", lambda: self.make_slime(BloodSlime))


		ex = GreenSlime()

		self.minion_health = ex.max_hp
		self.minion_damage = ex.spells[0].damage
		self.minion_range = 3

	def get_description(self):
		return ("Assume Slime Form for [{duration}:duration] turns\n"
				"Gain [50 Physical:physical] and [100 Poison:poison] resistance\n"
				"Each turn, summon a Green Slime nearby\n"
				"If you have multiple upgrades that would replace the Green Slime, summon one of each")

	def cast_instant(self, x, y):
		self.caster.apply_buff(SlimeformBuff(self), self.get_stat('duration'))

	def make_slime(self, spawner=GreenSlime):
		unit = spawner()
		apply_minion_bonuses(self, unit)
		unit.buffs[0].spawner = lambda : self.make_slime(spawner)
		unit.source = self
		return unit

	def get_extra_examine_tooltips(self):
		return [SlimeformBuff(self), self.make_slime()] + self.get_upgrade_tooltips()

class OozingTrailBuff(Buff):

	def __init__(self, spell):
		Buff.__init__(self)
		self.spell = spell

	def on_init(self):
		self.name = "Oozing Trail"
		self.description = "Each time you move, summon a Green Slime nearby"
		self.owner_triggers[EventOnMoved] = self.on_moved

	def make_slime(self, spawner):
		return self.spell.make_slime(spawner)

	def on_moved(self, evt):
		u = self.make_slime(get_matching_slimes(self.owner)[0])
		self.summon(u, self.owner)

class SwampDwellerBuff(Buff):

	def on_init(self):
		self.name = "Swamp Dweller"
		self.description = "Activate the slime buff three times if it ends its turn over a swamp chasm"

	def on_advance(self):
		o = self.owner
		tile = o.level.tiles[o.x][o.y]
		if not tile.is_chasm: return
		if not tile.chasm_type == 'swamp': return
		b = self.owner.get_buff(SlimeBuff)
		if not b: return
		for _ in range(3): b.on_advance()

class SummonSlimeDrake(Spell):

	def on_init(self):
		self.name = "Slime Drake"
		self.level = 8
		self.tags = [Tags.Conjuration, Tags.Dragon, Tags.Slime]
		self.max_charges = 1
		self.range = 5

		self.must_target_empty = True

		self.minion_damage = 8
		self.minion_health = 140
		self.minion_range = 5

		self.upgrades['swamp'] = (1, 3, "Swamp Dweller", "Slime Drakes gain the Swamp Dweller buff\nIf it ends its turn over a swamp chasm it activates its slime buff three additional times")
		self.upgrades['oozing_trail'] = (1, 2, "Oozing Trail", "When the Slime Drake moves, it will attempt to summon a Green Slime nearby")
		self.upgrades['dragon_mage'] = (1, 5, "Dragon Mage", "The Slime Drake can cast your Slimeshot on a 6 turn cooldown")
		self.upgrades['minion_health'] = (280, 6, "Slime Tank")

		self.add_upgrade_tooltip("Oozing Trail", self.make_slime)

	def get_extra_examine_tooltips(self):
		return [self.make_slime_drake()] + self.get_upgrade_tooltips()

	def get_description(self):
		return "Summon a Slime Drake"

	def make_slime(self, spawner=GreenSlime):
		u = spawner()
		apply_minion_bonuses(self, u)
		u.buffs[0].spawner = lambda : self.make_slime(spawner)
		u.source = self
		return u

	def make_slime_drake(self):
		u = SlimeDrake()
		if self.get_stat('dragon_mage'): grant_minion_spell(Slimeshot, u, self.owner, cool_down=6)
		if self.get_stat('oozing_trail'): u.apply_buff(OozingTrailBuff(self))
		if self.get_stat('swamp'): u.apply_buff(SwampDwellerBuff())
		apply_minion_bonuses(self, u)
		u.buffs[0].spawner = lambda : self.make_slime_drake() # propogate bonuses
		u.source = self
		return u

	def cast(self, x, y):
		self.summon(self.make_slime_drake(), Point(x, y))
		yield


class AetherSicknessBuff(Buff):

	def __init__(self, damage):
		Buff.__init__(self)
		self.damage = damage

	def on_init(self):
		self.name = "Aether Poison"
		self.buff_type = BUFF_TYPE_CURSE
		self.color = Tags.Arcane.color
		self.resists[Tags.Arcane] = -50

	def on_advance(self):
		self.owner.deal_damage(self.damage, Tags.Arcane, self)

	def get_description(self):
		return ("Deals {damage} [Arcane] damage each turn", {'damage':self.damage})

class Blazerip(Spell):

	def on_init(self):
		self.name = "Blazerip"
		self.tags = [Tags.Arcane, Tags.Fire, Tags.Sorcery]
		self.damage_type = [Tags.Arcane, Tags.Fire]
		self.level = 3
		self.max_charges = 6
		self.damage = 12
		self.range = 5
		self.requires_los = False
		self.radius = 3

		self.upgrades['mirror'] = (1, 2, "Dual Blazerip", "Blazerip also affects a symmetric area behind the caster")
		self.upgrades['assassin'] = (1, 4, "Arcane Assassin", "Blazerip deals double damage when cast on a target outside your line of sight")
		self.upgrades[('aether_poison', 'duration')] = ([1, 10], 4, "Aether Poison", "Inflict [{duration}:duration] turns of [Aether Poison:arcane] on affected units\n[Aether Poison:arcane] reduces [Arcane] resist by 50 and deals [{damage}:damage] [Arcane] damage each turn", None, None, {'damage':1})
		self.upgrades[('reality_rip', 'minion_health', 'minion_damage', 'minion_range')] = ([1, 30, 5, 7], 6, "Reality Rip", "When Blazerip kills an enemy, summon a Flame Rift or Void Rift depending on the damage type that killed them", [Tags.Conjuration])

		self.add_upgrade_tooltip("Reality Rip", lambda: make_minion(self, VoidRift), lambda: make_minion(self, FlameRift))
		self.add_upgrade_tooltip("Aether Poison", lambda: AetherSicknessBuff(self.get_stat('damage', base=1)))


	def cast(self, x, y):
		points = self.get_impacted_tiles(x, y)
		caster = self.caster
		level = caster.level
		dmg = self.get_stat('damage')
		aether = self.get_stat('aether_poison')
		aether_dmg = self.get_stat('damage', base=1)
		aether_dur = self.get_stat('duration')
		rip = self.get_stat('reality_rip')
		if self.get_stat('assassin') and not level.can_see(caster.x, caster.y, x, y): dmg *= 2

		for p in points:
			u = level.get_unit_at(p.x, p.y)
			if u and aether: u.apply_buff(AetherSicknessBuff(aether_dmg), aether_dur)
			level.deal_damage(p.x, p.y, dmg, Tags.Arcane, self)
			if level.tiles[p.x][p.y].is_wall(): level.make_floor(p.x, p.y)
			if rip and u and not u.is_alive() and are_hostile(caster, u): level.queue_spell(self.do_summon(make_minion(self, VoidRift), u))
			yield

		for p in reversed(points):
			u = level.get_unit_at(p.x, p.y)
			level.deal_damage(p.x, p.y, dmg, Tags.Fire, self)
			if rip and u and not u.is_alive() and are_hostile(caster, u): level.queue_spell(self.do_summon(make_minion(self, FlameRift), u))
			yield

	def do_summon(self, unit, target):
		self.summon(unit, target)
		yield

	def fmt_dict(self):
		d = Spell.fmt_dict(self)
		d['width'] = 1 + 2*d['radius']
		return d

	def get_description(self):
		return ("Deal [{damage}:damage] [Arcane] and [Fire] damage in a [{width}:radius] tile line perpendicular to the caster\n"
				"Melts walls")

	def get_impacted_tiles(self, x, y):
		points = self.caster.level.get_perpendicular_line(self.caster, Point(x, y), length=self.get_stat('radius'))
		if self.get_stat('mirror'):
			mirrored_points = self.caster.level.get_perpendicular_line(self.caster, Point(2*self.caster.x-x, 2*self.caster.y-y), length=self.get_stat('radius'))
			for p in mirrored_points:
				points.append(p)
		return points

class IceVortex(Spell):

	def on_init(self):
		self.name = "Ice Vortex"
		self.damage = 11
		self.tags = [Tags.Ice, Tags.Arcane, Tags.Sorcery]
		self.damage_type = [Tags.Arcane, Tags.Ice]
		self.level = 3
		self.max_charges = 6
		self.duration = 3
		self.range = 8
		self.requires_los = False
		self.radius = 3

		self.upgrades['embodied'] = (1, 3, "Embodied Vortex", "You may cast Ice Vortex on yourself, if you do, it gains +2 radius")
		self.upgrades[('ritual', 'max_channel')] = ([1, 4], 3, "Ritual of Winter", "Ice Vortex can be channeled for up to [{max_channel}:max_channel] turns"
																				"\nIf the ritual is completed, it regains a charge", [Tags.Ritual])
		self.upgrades['storm'] = (1, 3, "Storm Vortex", "Casting Ice Vortex targeting a unit with a cloud over it improves the spell\n[Blizzard:ice] : +2 [radius]\n[Storm Cloud:lightning] : Deal [Lightning] damage in addition to [Ice] and [Arcane]\n[Rain Cloud:nature] : Inflict [{duration}:duration] turns of Soaked before dealing damage", [Tags.Nature], None, {'duration':12})
		self.upgrades['drake_call'] = (1, 8, "Drake Calling", "If a unit is killed by this spell, cast your Ice Drake spell at their location", [Tags.Dragon])

	def can_cast(self, x, y):
		u = self.caster.level.get_unit_at(x, y)
		if not u: return False
		if self.get_stat('embodied') and u==self.caster: return True
		if not u.has_buff(FrozenBuff): return False
		return Spell.can_cast(self, x, y)

	def get_description(self):
		return ("Enemies within [{radius}:radius] tiles of the target are pulled toward it, [frozen] for [{duration}:duration] turns, and dealt [{damage}:damage] [Arcane] and [Ice] damage\n"
				"Must target a [frozen] unit")

	def get_impacted_tiles(self, x, y):
		effective_radius = self.get_stat('radius')
		if self.get_stat('storm'):
			cloud = self.caster.level.tiles[x][y].cloud
			if isinstance(cloud, BlizzardCloud): effective_radius += 2
		if self.get_stat('embodied') and x == self.caster.x and y == self.caster.y: effective_radius += 2
		return self.caster.level.get_points_in_ball(x, y, effective_radius)

	def modify_test_level(self, level):
		first_enemy = [u for u in level.units if u.team != TEAM_PLAYER][0]
		first_enemy.apply_buff(FrozenBuff(), 5)

	def cast(self, x, y, channel_cast=False):
		ritual = self.get_stat('ritual')
		if ritual and not channel_cast and self.is_manual_cast():
			self.caster.apply_buff(ChannelBuff(self.cast, Point(x, y)), self.get_stat('max_channel'))
			return

		caster = self.caster
		level = caster.level

		target_unit = level.get_unit_at(x, y)
		target = Point(x, y)

		radius = self.get_stat('radius')
		if caster == target_unit and self.get_stat('embodied'): radius += 2
		damage = self.get_stat('damage')
		duration = self.get_stat('duration')

		dtypes = self.get_stat('damage_type')[:]
		effect_types = dtypes
		effect_idx = 0

		drake_call = self.get_stat('drake_call')
		if drake_call: drake_spell = caster.get_or_make_spell(SummonIceDrakeSpell)

		crackle = False
		crackling = self.get_stat('crackling')
		if crackling and target_unit and not are_hostile(caster, target_unit): crackle = True
		if crackle: crackle_damage = self.get_stat('damage', base=22)

		storm = self.get_stat('storm')
		soak = False
		if storm:
			cloud = level.tiles[x][y].cloud
			if cloud:
				if isinstance(cloud, BlizzardCloud): radius += 2
				elif isinstance(cloud, StormCloud): dtypes.append(Tags.Lightning)
				elif isinstance(cloud, RainCloud): soak = True; soak_dur = self.get_stat('duration', base=12)

		units = [u for u in level.get_units_in_ball(target, radius) if u != target_unit and are_hostile(caster, u)]
		random.shuffle(units)
		units.sort(key=lambda u: level.unit_distance(u, target))

		for u in units:

			for p in level.get_points_in_line(Point(x, y), u):
				level.show_effect(p.x, p.y, effect_types[effect_idx], minor=True)
				effect_idx = (effect_idx + 1) % len(effect_types)

			pull(u, target, radius)
			u.apply_buff(FrozenBuff(), duration)
			yield
			pre_hp = u.cur_hp
			if soak: u.apply_buff(SoakedBuff(), soak_dur)
			for dt in dtypes: u.deal_damage(damage, dt, self)
			yield
			if drake_call and pre_hp > 0 and not u.is_alive(): level.act_cast(caster, drake_spell, u.x, u.y, pay_costs=False)

		if ritual and channel_cast and not self.caster.has_buff(ChannelBuff): self.refund_charges(1)

class UnstableUndead(Upgrade):

	def on_init(self):
		self.name = "Unstable Undead"
		self.level = 5
		self.radius = 2
		self.damage = 10
		self.damage_type = [Tags.Dark, Tags.Physical]
		self.new_attributes = {'damage': 10, 'radius': 2}
		self.global_triggers[EventOnUnitAdded] = self.on_added

	def get_description(self):
		return ("[Undead] allies explode on death, dealing [{damage}:damage] [Physical] and [Dark] damage in a [{radius}:radius] tile burst"
				"\nAlways Active")

	def on_added(self, evt):
		u = evt.unit
		if Tags.Undead not in u.tags: return
		if are_hostile(u, self.owner): return
		u.apply_buff(DeathExplosion(self.get_stat('damage'), self.get_stat('radius'), self.damage_type, custom_name="Unstable Undead", custom_color=Tags.Dark.color))

	def on_applied(self, owner):
		Upgrade.on_applied(self, owner)
		for u in owner.level.units:
			if Tags.Undead not in u.tags: continue
			if are_hostile(u, owner): continue
			if u == owner: continue
			u.apply_buff(DeathExplosion(self.get_stat('damage'), self.get_stat('radius'), self.damage_type, custom_name="Unstable Undead", custom_color=Tags.Dark.color))


class RestlessDeadBuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)

	def on_init(self):
		self.global_triggers[EventOnDamaged] = self.on_damaged
		self.name = "Restless Dead"
		self.color = Tags.Dark.color
		self.raise_friendly = self.spell.get_stat('friendly')
		self.salvage = self.spell.get_stat('salvage')
		self.restless = self.spell.get_stat('restless')

	def on_damaged(self, damage_event):
		if damage_event.unit.cur_hp > 0: return
		owner = self.owner
		level = owner.level
		u = damage_event.unit
		if are_friendly(owner, u):
			if not self.raise_friendly: return
			elif u.max_hp < 2: return # don't try to raise friendlies with only 1 max hp, since rounding down would/should yield 0
		if Tags.Living in u.tags: level.queue_spell(self.raise_skeleton(u))
		elif self.salvage and Tags.Construct in u.tags: level.queue_spell(self.raise_golem(u))

	def raise_skeleton(self, unit):
		if unit and unit.cur_hp <= 0:
			skeleton = raise_skeleton(self.owner, unit, source=self.spell)
			if skeleton:
				if are_friendly(self.owner, unit): skeleton.max_hp = max(1, skeleton.max_hp // 2)
				s = skeleton.get_spell(SimpleMeleeAttack)
				s.damage = self.spell.get_stat('minion_damage')
			if skeleton and self.restless:
				for _ in self.owner.level.take_turn(skeleton):
					yield
			yield

	def raise_golem(self, unit):
		if unit and unit.cur_hp <= 0 and not self.owner.level.get_unit_at(unit.x, unit.y):
			g = Golem()
			g.asset_name = 'golem_junk'
			g.name = "Junk Golem"
			g.spells = [SimpleMeleeAttack(self.spell.get_stat('minion_damage'))]
			g.tags.append(Tags.Undead)
			g.max_hp = unit.max_hp
			if are_friendly(self.owner, unit): g.max_hp = max(1, g.max_hp // 2)
			u = self.summon(g, target=unit)
			if u and self.restless:
				for _ in self.owner.level.take_turn(u):
					yield
		yield


	def get_description(self):
		return ("When a [Living] enemy dies, raise it as a Skeleton\n"
				"Raised Skeletons inherit the HP of the slain unit\n"
				"Skeletons of flying units can fly")

class RestlessDead(Spell):

	def on_init(self):
		self.name = "The Restless Dead"
		self.level = 4
		self.tags = [Tags.Dark, Tags.Enchantment, Tags.Conjuration]
		self.duration = 20
		self.range = 0
		self.max_charges = 2
		self.minion_damage = 5

		self.upgrades['salvage'] = (1, 1, "Junk Golems", "The Restless Dead also raises [Constructs:construct] as Junk Golems", [Tags.Metallic])
		self.upgrades['friendly'] = (1, 2, "Minion Recycling", "Allies can also be raised by Restless Dead but do so with 50% max HP")
		self.upgrades['restless'] = (1, 6, "Restless Turning", "Units raised by The Restless Dead take an extra turn immediately after being raised")
		self.add_upgrade(UnstableUndead())

		self.add_upgrade_tooltip("Junk Golems", self.example_junk_golem)

	def get_description(self):
		return ("When a [Living] enemy dies, raise it as a Skeleton\n"
				"Raised Skeletons inherit the HP of the slain unit\n"
				"Skeletons of flying units can fly\n"
				"Lasts [{duration}:duration] turns")

	def get_impacted_tiles(self, x, y):
		return [Point(x, y)]

	def get_extra_examine_tooltips(self):
		return [RestlessDeadBuff(self)] + self.get_upgrade_tooltips()

	def cast_instant(self, x, y):
		self.caster.apply_buff(RestlessDeadBuff(self), self.get_stat('duration'))

	def example_skeleton(self):
		skeleton = Skeleton()
		skeleton.get_spell(SimpleMeleeAttack).damage = self.get_stat('minion_damage')
		return skeleton

	def example_junk_golem(self):
		g = Golem()
		g.asset_name = 'golem_junk'
		g.name = "Junk Golem"
		g.spells = [SimpleMeleeAttack(self.get_stat('minion_damage'))]
		g.tags.append(Tags.Undead)
		g.max_hp = 0
		return g

	def get_extra_examine_tooltips(self):
		return [self.example_skeleton()] + self.get_upgrade_tooltips()

class ChaosCast(Upgrade):

	def on_init(self):
		self.level = 5
		self.added_tags = [Tags.Chaos]
		self.tags = [Tags.Fire, Tags.Lightning, Tags.Enchantment, Tags.Chaos]
		self.name = "Pyrostatic Chaos"
		self.description = ("When you cast another [Chaos] spell, cast Pyrostatic Curse at the target"
							"\nAdds the [Chaos] tag")
		self.owner_triggers[EventOnSpellCast] = self.on_cast

	def on_cast(self, evt):
		if (not Tags.Chaos in evt.spell.tags) or (isinstance(evt.spell, PyrostaticCurse)):
			return

		spell = self.owner.get_or_make_spell(PyrostaticCurse)
		self.owner.level.defer_cast(self.owner, spell, evt.x, evt.y, pay_costs=False)

class PyroStaticHexBuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)

	def on_init(self):
		self.name = "Pyrostatic Hex"
		self.beam = self.spell.get_stat('beam')
		self.num_targets = self.spell.get_stat('num_targets')
		self.remove_resistance = self.spell.get_stat('remove_resistance')
		self.buff_type = BUFF_TYPE_CURSE
		self.color = Tags.Fire.color
		self.owner_triggers[EventOnDamaged] = self.on_damage
		self.asset = ['status', 'pyrostatic_hex']
		if self.remove_resistance: self.resists[Tags.Fire] = -50

	def get_description(self):
		if self.beam: desc = "When this unit takes [Fire] damage, deal that much [Lightning] damage in a beam targeting up to [{num_targets}:num_targets] enemies in line of sight"
		else: desc = "When this unit takes [Fire] damage, deal that much [Lightning] damage to up to [{num_targets}:num_targets] enemies in line of sight"
		return desc

	def fmt_dict(self):
		return {'num_targets': self.num_targets}

	def on_damage(self, evt):
		if evt.damage_type != Tags.Fire: return
		self.owner.level.queue_spell(self.redeal(evt))

	def redeal(self, evt):
		targets = [u for u in self.owner.level.get_units_in_los(self.owner) if are_hostile(u, self.spell.owner) and u != self.owner]
		num_targets = min(self.num_targets, len(targets))
		if num_targets <= 0: return
		for t in random.sample(targets, num_targets):
			if not t.is_alive(): continue
			if not self.beam:
				self.owner.level.show_beam(self.owner, t, Tags.Lightning, minor=False)
				t.deal_damage(evt.damage, Tags.Lightning, self.spell)
			else:
				for p in self.owner.level.get_points_in_line(self.owner, t)[1:]:
					self.owner.level.deal_damage(p.x, p.y, evt.damage, Tags.Lightning, self.spell)
		yield

class Cursebringer(Upgrade):

	def on_init(self):
		self.name = "Cursebringer"
		self.description = "Cast Pyrostatic Curse at your location at the beginning of each level"
		self.level = 2
		self.owner_triggers[EventOnUnitAdded] = self.on_added

	def on_added(self, _evt):
		self.owner.level.act_cast(self.owner, self.owner.get_or_make_spell(PyrostaticCurse), self.owner.x, self.owner.y, pay_costs=False)

class PyrostaticCurse(Spell):

	def on_init(self):
		self.name = "Pyrostatic Curse"

		self.tags = [Tags.Fire, Tags.Lightning, Tags.Enchantment]
		self.level = 3
		self.max_charges = 2

		self.radius = 4
		self.range = 7
		self.duration = 6
		self.num_targets = 2

		self.upgrades['remove_resistance'] = (1, 3, "Resistance Melting", "Pyrostatic Curse removes [50% Fire:fire] resist from affected targets")
		self.add_upgrade(ChaosCast())
		self.add_upgrade(Cursebringer())
		self.upgrades['beam'] = (1, 1, "Linear Conductance", "[Lightning] damage is dealt in a beam instead of to a single target")

	def get_extra_examine_tooltips(self):
		return [PyroStaticHexBuff(self)] + self.get_upgrade_tooltips()

	def get_description(self):
		return ("Curse enemies in a [{radius}:radius] tile burst for [{duration}:duration] turns\n"
				"When a cursed unit takes [Fire] damage, [{num_targets}:num_targets] enemies in line of sight of it take that much [Lightning] damage")

	def cast_instant(self, x, y):
		for p in self.owner.level.get_points_in_ball(x, y, self.get_stat('radius')):
			u = self.owner.level.get_unit_at(p.x, p.y)
			if u and are_hostile(u, self.caster):
				u.apply_buff(PyroStaticHexBuff(self), self.get_stat('duration'))

class SpikeballFactory(Spell):

	def on_init(self):
		self.name = "Spikeball Factory"
		self.tags = [Tags.Metallic, Tags.Conjuration]
		self.level = 7
		self.max_charges = 1

		self.minion_health = 60
		self.minion_damage = 10

		self.range = 0

		self.upgrades[('defense', 'minion_range')] = ([1, 5], 3, "Defense System", "Spike Ball Spawners gain a [{minion_damage}:minion_damage] [Physical] damage, [{minion_range}:minion_range] range, ranged attack", None, None, {'minion_damage':10})
		self.upgrades['manufactory'] = (1, 6, "Manufactory", "Surrounds the initially summoned spawners with another layer of spawners")
		self.upgrades['copper'] = (1, 7, "Copper Spikeballs", "Summons Copper Spike Ball Spawners instead", [Tags.Lightning])
		self.upgrades['overclocked'] = (1, 9, "Overclocked Assembly", "The spawners' summoning spell cooldown is halved")

		self.add_upgrade_tooltip("Copper Spikeballs", lambda: self.spikeball(True))

	def get_description(self):
		return "Summon Spike Ball Spawners in unoccupied adjacent tiles"

	def spikeball(self, copper=None):
		if copper is None: copper = self.get_stat('copper')
		if copper: spikeball = SpikeBallCopper()
		else: spikeball = SpikeBall()
		apply_minion_bonuses(self, spikeball)
		return spikeball

	def get_gate(self):
		gate = MonsterSpawner((self.spikeball))
		apply_minion_bonuses(self, gate)
		if self.get_stat('overclocked'):
			s = gate.get_spell(SimpleSummon)
			s.cool_down //= 2
			gate.cool_downs[s] //= 2
		if self.get_stat('defense'):
			spell = SimpleRangedAttack(damage=self.get_stat('minion_damage'), range=self.get_stat('minion_range'))
			gate.add_spell(spell)
		return gate

	def cast(self, x, y):
		for p in self.get_impacted_tiles(x, y):
			gate = self.get_gate()
			self.summon(gate, p)
			yield

	def get_impacted_tiles(self, x, y):
		points = set()
		for p in self.owner.level.get_adjacent_points(self.caster, filter_walkable=True, check_unit=True): points.add(p); yield p
		if self.get_stat('manufactory'):
			for p in points:
				for q in self.owner.level.get_adjacent_points(p, filter_walkable=True, check_unit=True): yield q

	def get_extra_examine_tooltips(self):
		return [self.spikeball(False)] + self.get_upgrade_tooltips()

class MercurizeBuff(Buff):

	def __init__(self, spell):
		if spell.use_owner_spell:
			self.spell = spell.owner.get_or_make_spell(MercurizeSpell)
		else:
			self.spell = spell
		self.retrograde = self.spell.get_stat('retrograde')
		self.mad_hatter = self.spell.get_stat('mad_hatter')
		self.vengeance = self.spell.get_stat('vengeance')
		self.damage = self.spell.get_stat('damage')
		self.dtypes = self.spell.get_stat('damage_type').copy()
		Buff.__init__(self)

	def on_init(self):
		self.buff_type = BUFF_TYPE_CURSE
		self.name = "Mercurized"
		self.asset = ['status', 'mercurized']
		self.owner_triggers[EventOnDeath] = self.on_death

	def get_description(self):
		lines = []
		for dtype in self.dtypes:
			lines.append(("Each turn, take [{damage}:damage] {tag} damage", {"damage": self.damage, "tag": formatted_tag(dtype)}))
		if self.retrograde: lines.append("Spell cooldowns do not advance")
		if self.mad_hatter: lines.append("Each turn, if below half HP, become [berserk] for the remaining duration")
		lines.append("On death, summon a temporary Mercurial Geist with max HP equal to this unit's max HP")
		desc = []
		for line in lines:
			if desc: desc.append("\n")
			desc.append(line)
		return desc

	def on_advance(self):
		for dtype in self.dtypes:
			self.owner.deal_damage(self.damage, dtype, self.spell)
			if not self.owner.is_alive(): break
		if self.owner.is_alive():
			if self.mad_hatter:
				if self.owner.cur_hp < (self.owner.max_hp // 2):
					self.owner.apply_buff(BerserkBuff(), self.turns_left)
			if self.retrograde:
				for s in self.owner.cool_downs: self.owner.cool_downs[s] += 1

	def on_death(self, evt):
		self.owner.level.queue_spell(self.do_summon())

	def do_summon(self):
		geist = self.spell.get_geist()
		geist.max_hp = self.owner.max_hp
		self.spell.summon(geist, target=self.owner)
		if self.vengeance: geist.apply_buff(MercurialVengeance(self.spell))
		yield

class MercurialVengeance(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)

	def on_init(self):
		self.name = "Mercurial Vengeance"
		self.owner_triggers[EventOnDeath] = self.on_death

	def get_description(self):
		return "On death, cast Mercurize on the killer"

	def on_death(self, evt):
		# cast a Mercurize with the summoner's buffs
		if not evt.damage_event: return
		if not evt.damage_event.source: return
		if not evt.damage_event.source.owner: return
		self.owner.level.queue_spell(self.do_vengeance(evt.damage_event.source.owner))

	def do_vengeance(self, unit):
		yield
		if not unit.is_alive(): return
		spell = MercurizeSpell()
		spell.owner = self.owner
		spell.caster = self.owner
		spell.statholder = self.spell.statholder or self.spell.caster
		for _ in self.owner.level.act_cast(self.owner, spell, unit.x, unit.y, pay_costs=False, queue=False): yield

class MercurizeSpell(Spell):

	def on_init(self):
		self.name = "Mercurize"

		self.level = 2
		self.tags = [Tags.Dark, Tags.Metallic, Tags.Enchantment, Tags.Conjuration]
		self.damage_type = [Tags.Poison, Tags.Physical]

		self.damage = 2
		self.max_charges = 5
		self.duration = 6
		self.range = 5

		self.minion_damage = 10
		self.minion_duration = 10
		self.use_owner_spell = False

		self.upgrades['dark'] = (1, 2, "Morbidity", "Mercurized also deals [Dark] damage", None, [Tags.Dark])
		self.upgrades['retrograde'] = (1, 4, "Retrograde", "The cooldowns of the target's spells will not progress while they are Mercurized")
		self.upgrades['vengeance'] = (1, 4, "Mercurial Vengeance", "When a Mercurial Geist is killed, its killer is afflicted with Mercurized")
		self.upgrades['mad_hatter'] = (1, 4, "Mercurial Temper", "Each turn, units affected by Mercurized with less than half health become [berserk] for the remainder of its duration")
		self.add_upgrade_tooltip("Mercurial Vengeance", lambda: MercurialVengeance(self))

	def get_description(self):
		return ("Afflict the target with Mercurized for [{duration}:duration] turns\n"
				"Mercurized units take [{damage}:damage] [Poison] and [Physical] damage each turn\n"
				"If the target dies while Mercurized, it is raised as a temporary Mercurial Geist\n"
				"The Geist inherits the max HP of the Mercurized unit")

	def can_cast(self, x, y):
		return self.caster.level.get_unit_at(x, y) is not None and Spell.can_cast(self, x, y)

	def cast_instant(self, x, y):
		for p in self.owner.level.get_points_in_line(self.caster, Point(x, y))[1:-1]:
			self.owner.level.show_effect(p.x, p.y, Tags.Dark, minor=True)
		unit = self.caster.level.get_unit_at(x, y)
		if not unit: return
		unit.apply_buff(MercurizeBuff(self), self.get_stat('duration'))

	def get_geist(self):
		geist = Ghost()
		geist.name = "Mercurial Geist"
		geist.asset_name = "mercurial_geist"
		geist.max_hp = 0
		geist.tags.append(Tags.Metallic)
		trample = SimpleMeleeAttack(damage=self.get_stat('minion_damage'))
		geist.spells = [trample]
		geist.turns_to_death = self.get_stat('minion_duration')
		return geist


	def get_extra_examine_tooltips(self):
		return [MercurizeBuff(self), self.get_geist()] + self.get_upgrade_tooltips()

class MagnetizeBuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)
		self.stack_type = STACK_INTENSITY
		self.damage = spell.get_stat('damage')
		self.radius = spell.get_stat('radius')

		self.electromag = spell.get_stat('electromagnetism')
		self.radioactive = spell.get_stat('radioactivity')
		self.mercurial = spell.get_stat('cast_mercurize')
		self.merc_dur = spell.get_stat('duration', base=1)

		self.name = "Magnetized"
		self.asset = ['status', 'magnetized']

	def get_description(self):
		desc = "Each turn, pull enemies within [{radius}:radius] tiles 1 tile toward the owner"
		if self.electromag: desc += "\nDeal [{damage}:damage] [Lightning] damage to enemies in range"
		else: desc += "\nAdjacent enemies take [{damage}:damage] [Lightning] damage"
		if self.radioactive:
			desc += "\nIf applied to an enemy, it loses 75 [Lightning] and [Arcane] resist"
			desc += "\nIf applied to an ally, it gains 75 [Lightning] and [Arcane] resist"
			desc += "\nEnemies in range take [{damage}:damage] [Poison] damage each turn"
		if self.mercurial: desc += "\nAdjacent enemies are afflicted with Mercurize"
		return (desc, {'radius': self.radius, 'damage': self.damage})


	def on_applied(self, owner):
		self.buff_type = BUFF_TYPE_CURSE if are_hostile(self.owner, self.spell.owner) else BUFF_TYPE_BLESS
		if self.radioactive:
			if self.buff_type == BUFF_TYPE_CURSE:
				self.resists[Tags.Lightning] = -75
				self.resists[Tags.Arcane] = -75
			else:
				self.resists[Tags.Lightning] = 75
				self.resists[Tags.Arcane] = 75

	def on_advance(self):
		# pull stuff towards self
		o = self.owner
		lvl = o.level
		electromag = self.electromag
		radioactive = self.radioactive
		mercurial = self.mercurial
		dmg = self.damage
		merc_dur = self.merc_dur

		units = [u for u in lvl.get_units_in_ball(o, self.radius) if u != o]
		random.shuffle(units)
		units.sort(key=lambda u: self.owner.level.unit_distance(u, o))
		for u in units:

			if are_friendly(u, self.spell.owner): continue
			for p in lvl.get_points_in_line(o, u): lvl.show_effect(p.x, p.y, Tags.Lightning, minor=True)
			pull(u, o, 1)

			if electromag: u.deal_damage(dmg, Tags.Lightning, self.spell) # dmg to all in range if electromag
			if radioactive: u.deal_damage(dmg, Tags.Poison, self.spell) # poison to all in range if radioactive

			if lvl.are_adjacent(o, u):
				if mercurial:
					spell = MercurizeSpell()
					spell.owner = spell.caster = spell.statholder = self.spell.owner
					spell.use_owner_spell = True
					spell.duration = merc_dur
					lvl.act_cast(self.spell.owner, spell, u.x, u.y, pay_costs=False, queue=True) # make the wizard cast the spell.

				if not electromag: u.deal_damage(dmg, Tags.Lightning, self.spell) # base behavior, dmg to adjacent enemies (gate to not doublehit)


class MagnetizeSpell(Spell):

	def on_init(self):
		self.name = "Magnetize"
		self.tags = [Tags.Lightning, Tags.Metallic, Tags.Enchantment]
		self.damage_type = [Tags.Lightning]

		self.level = 2
		self.max_charges = 18
		self.radius = 3
		self.damage = 10
		self.range = 8
		self.requires_los = False
		self.duration = 10

		self.upgrades['radioactivity'] = (1, 3, "Radioactivity", "Lowers an enemy's or raises an ally's [Lightning] and [Arcane] resistances by 75%\nMagnetize also deals [Poison] damage to all enemies in its radius each turn")
		self.upgrades['electromagnetism'] = (1, 4, "Electromagnetism", "Deals [Lightning] damage to all enemies in its radius rather than just adjacent ones")
		self.upgrades['cast_mercurize'] = (1, 6, "Liquid Magnetism", "At the end of a Magnetized unit's turn, cast Mercurize on adjacent enemies for [{duration}:duration] turns", None, None, {'duration':1})
		self.upgrades[('hp_cost', 'hemomagnetism')] = ([4, 1], 1, "Hemomagnetism", "Magnetism can also target [Living] units", [Tags.Blood])

	def can_cast(self, x, y):
		unit = self.owner.level.get_unit_at(x, y)
		if not unit: return False
		if self.get_stat('hemomagnetism'):
			if Tags.Living not in unit.tags and Tags.Metallic not in unit.tags:
				return False
		else:
			if Tags.Metallic not in unit.tags:
				return False
		return Spell.can_cast(self, x, y)

	def cast_instant(self, x, y):
		unit = self.owner.level.get_unit_at(x, y)
		if unit: unit.apply_buff(self.get_magnetize_buff(), self.get_stat('duration'))

	def get_description(self):
		return ("Magnetize target [Metallic] unit\n"
				"Enemies within [{radius}:radius] tiles of the magnetized unit are pulled 1 tile toward it each turn\n"
				"Then, deal [{damage}:damage] [Lightning] damage to adjacent enemies\n"
				"Lasts [{duration}:duration] turns")

	def get_magnetize_buff(self):
		return MagnetizeBuff(self)

	def get_extra_examine_tooltips(self):
		return [self.get_magnetize_buff()] + self.get_upgrade_tooltips()

class SilverSpearSpell(Spell):

	def on_init(self):
		self.name = "Silver Spear"
		self.level = 3
		self.max_charges = 15
		self.tags = [Tags.Holy, Tags.Metallic, Tags.Sorcery]
		self.damage = 27
		self.range = 7
		self.radius = 1

		self.upgrades['deal_lightning'] = (1, 5, "Copper Shaft", "Silver Spear deals [Lightning] damage to enemies in the spear's radius", [Tags.Lightning])
		self.upgrades[('pin', 'duration')] = ([1,5], 2, "Impalement", "Target is immobilized and [bleeds] for [{duration}:duration] turns")
		self.upgrades['requires_los'] = (-1, 1, "Astral Spear", "", [Tags.Arcane])
		self.upgrades['strip'] = (1, 4, "Irresistible Strike", "Silver Spear removes the target's [Physical] and [Holy] resistances")

	def get_description(self):
		return ("Deal [{damage}:damage] [Physical] damage to the target\n"
				"Deal [{damage}:damage] [Holy] damage to [Dark] and [Arcane] units within [{radius}:radius] tiles of the spear's path")

	def get_impacted_tiles(self, x, y):
		spear_offsets = [Point(0, 0)]
		points = set()
		for spear in spear_offsets:
			for p in self.caster.level.get_points_in_line(Point(self.caster.x + spear.x, self.caster.y + spear.y), Point(x + spear.x, y + spear.y))[1:]:
				for q in self.caster.level.get_points_in_ball(p.x, p.y, self.get_stat('radius')):
					if q not in points:
						yield q
						points.add(q)

	def cast(self, x, y):
		spear_offsets = [Point(0, 0)]
		hits = set()
		caster = self.caster
		level = caster.level
		radius = self.get_stat('radius')
		damage = self.get_stat('damage')

		lightning = self.get_stat('deal_lightning')

		target_unit = self.caster.level.get_unit_at(x, y)
		if target_unit and self.get_stat('strip'):
			if target_unit.resists[Tags.Holy] > 0: target_unit.resists[Tags.Holy] = 0
			if target_unit.resists[Tags.Physical] > 0: target_unit.resists[Tags.Physical] = 0

		for spear_offset in spear_offsets:

			start_x = caster.x + spear_offset.x
			start_y = caster.y + spear_offset.y

			start = Point(start_x, start_y)

			end = Point(0, 0)

			end_x = x + spear_offset.x
			end_y = y + spear_offset.y

			end = Point(end_x, end_y)

			for p in level.get_points_in_line(start, end)[1:]:
				level.projectile_effect(p.x, p.y, proj_name='silver_spear', proj_origin=start, proj_dest=end)
				units = level.get_units_in_ball(p, radius)
				for unit in units:
					if unit in hits:
						continue
					hits.add(unit)
					if Tags.Arcane in unit.tags or Tags.Dark in unit.tags: unit.deal_damage(damage, Tags.Holy, self)
					if lightning and are_hostile(unit, caster): unit.deal_damage(damage, Tags.Lightning, self)
				yield

		if target_unit:
			target_unit.deal_damage(damage, Tags.Physical, self)
			if self.get_stat('pin') and target_unit.is_alive():
				dur = self.get_stat('duration')
				target_unit.apply_buff(BleedBuff(), dur)
				target_unit.apply_buff(ImmobilizeBuff(), dur)

class LightningSpireArc(Spell):

	def on_init(self):
		self.name = "Zap"

		self.damage = 5
		self.num_targets = 2
		self.range = 0
		self.radius = 4
		self.requires_los = True
		self.damage_type = [Tags.Lightning]

	def get_ai_target(self):
		if self.get_targets(): return self.owner
		else: return None

	def can_target(self, t):
		if t.resists[Tags.Lightning] >= 100 and not self.get_stat('resistance_debuff'): return False
		if not are_hostile(self.owner, t): return False
		if not self.owner.level.can_see(self.owner.x, self.owner.y, t.x, t.y): return self.get_stat('requires_los')
		return True

	def get_targets(self):
		potential_targets = self.owner.level.get_units_in_ball(self.owner, self.get_stat('radius'))
		potential_targets = [t for t in potential_targets if self.can_target(t)]
		random.shuffle(potential_targets)
		return potential_targets[:self.get_stat('num_targets')]

	def can_threaten(self, x, y):
		return distance(self.owner, Point(x, y)) <= self.get_stat('radius') and self.owner.level.can_see(self.owner.x, self.owner.y, x, y)

	def can_cast(self, x, y):
		return self.get_targets() and Spell.can_cast(self, x, y)

	def cast(self, x, y):
		targets = self.get_targets()
		for t in targets:
			for p in self.owner.level.get_points_in_line(self.owner, t)[1:-1]:
				self.owner.level.show_effect(p.x, p.y, Tags.Lightning, minor=True)
			self.owner.level.deal_damage(t.x, t.y, self.get_stat('damage'), Tags.Lightning, self)
			if self.get_stat('resistance_debuff'):
				t.apply_buff(Electrified())
			yield

class SpireNetwork(Upgrade):

	def __init__(self, spell):
		Upgrade.__init__(self, spell)
		self.spell = spell

	def on_init(self):
		self.name = "Spire Network"
		self.level = 4
		self.spire_set = set()
		self.damage = 3
		self.new_attributes = {'damage': 3}
		self.spell_bonuses[LightningSpire]['range'] = 6
		self.spell_bonuses[LightningSpire]['requires_los'] = -1

	def get_description(self):
		return "Each turn, beams arc between each of your Lightning Spires, dealing [{damage}:damage] [Lightning] damage in a line"

	def on_applied(self, owner):
		Upgrade.on_applied(self, owner)
		self.build_spire_set()

	def build_spire_set(self):
		if not self.owner : return
		if not self.owner.level: return
		for u in self.owner.level.units:
			if not u.is_alive(): continue
			if not u.source or u.source != self.prereq: continue
			self.spire_set.add(u)

	def on_advance(self):
		owner = self.owner
		level = owner.level
		dmg = self.spell.get_stat('damage')
		self.spire_set = {u for u in self.spire_set if u.is_alive() and u.level is level}
		targets = list(self.spire_set)
		for i, t in enumerate(targets):
				for j in targets[i+1:]:
					for p in level.get_points_in_line(t, j, inclusive=False):
						level.deal_damage(p.x, p.y, dmg, Tags.Lightning, self)

class LightningSpire(Spell):

	def on_init(self):

		self.name = "Lightning Spire"
		self.minion_health = 60
		self.minion_damage = 8
		self.radius = 3
		self.max_charges = 4
		self.level = 3
		self.range = 4
		self.num_targets = 4

		self.must_target_empty = True
		self.must_target_walkable = True

		self.requires_los = 1
		self.stats.append('requires_los') # so spire network upgrade will show -1 requires los
		
		self.tags = [Tags.Lightning, Tags.Metallic, Tags.Conjuration]

		self.upgrades[('num_targets', 'radius')] = ([4,2], 4, "Mass Blasting")
		self.upgrades['blindcasting'] = (1, 4, "Wall Penetration", "Lightning Spires can zap enemies through walls")
		self.upgrades['resistance_debuff'] = (1, 6, "Resistance Penetration", "Zapped units lose [10% Lightning:lightning] resistance")
		self.add_upgrade(SpireNetwork(self))

		self.add_upgrade_tooltip("Resistance Penetration", Electrified)

	def get_description(self):
		return "Summon a Lightning Spire"

	def get_impacted_tiles(self, x, y):
		for p in self.owner.level.get_points_in_ball(x, y, self.get_stat('radius')):
			if self.get_stat('blindcasting'): yield p
			elif self.owner.level.can_see(x, y, p.x, p.y): yield p

	def spire(self):
		unit = Unit()
		unit.name = "Lightning Spire"

		unit.max_hp = self.get_stat('minion_health')
		unit.tags = [Tags.Metallic, Tags.Construct, Tags.Lightning]

		arc = LightningSpireArc()
		arc.damage = self.get_stat('minion_damage')
		arc.num_targets = self.get_stat('num_targets')
		arc.radius = self.get_stat('radius')
		arc.requires_los = self.get_stat('blindcasting')
		arc.resistance_debuff = self.get_stat('resistance_debuff')

		unit.spells = [arc]
		unit.stationary = True
		return unit

	def cast_instant(self, x, y):
		unit = self.spire()
		summoned = self.summon(unit, target=Point(x, y))
		if summoned:
			b = self.caster.get_buff(SpireNetwork)
			if b: b.spire_set.add(unit)

	def get_extra_examine_tooltips(self):
		return [self.spire()] + self.get_upgrade_tooltips()

class EssenceFlux(Spell):

	def on_init(self):
		self.name = "Essence Flux"
		self.tags = [Tags.Arcane, Tags.Chaos, Tags.Enchantment]

		self.max_charges = 5
		self.level = 4
		self.range = 6
		self.radius = 4

		self.upgrades['stabilize'] = (1, 3, "Essence Stabilizer", "Allies' resistances match the higher of each pair, rather than being swapped")
		self.upgrades['degrade'] = (1, 2, "Essence Degradation", "Enemies' resistances match the lower of each pair, rather than being swapped")
		self.upgrades['banish'] = (1, 1, "Banishment", "Temporary units in the affected area are killed", [Tags.Sorcery])
		self.upgrades[('flummox', 'duration')] = ([1, 4], 4, "Flummoxed", "Affected enemies are [silenced] for [{duration}:duration] turns")


	def get_description(self):
		return ("Swap the resistances of units in a [{radius}:radius] tile burst\n"
				"[Fire] swaps with [Ice]\n"
				"[Lightning] swaps with [Physical]\n"
				"[Dark] swaps with [Holy]\n"
				"[Poison] swaps with [Arcane]\n"
				"Does not affect the Wizard")

	def cast(self, x, y):
		caster = self.caster
		lvl = caster.level
		stabilize = self.get_stat('stabilize')
		degrade = self.get_stat('degrade')
		banish = self.get_stat('banish')
		flummox = self.get_stat('flummox')
		dur = self.get_stat('duration')

		exempt = {lvl.player_unit or caster}
		points = list(lvl.get_points_in_ball(x, y, self.get_stat('radius')))
		random.shuffle(points)

		for p in points:
			unit = lvl.get_unit_at(p.x, p.y)
			if unit and unit not in exempt:
				exempt.add(unit)
				hostile = are_hostile(caster, unit)
				old_resists = unit.resists.copy()
				for e1, e2 in [
					(Tags.Fire, Tags.Ice),
					(Tags.Lightning, Tags.Physical),
					(Tags.Dark, Tags.Holy),
					(Tags.Poison, Tags.Arcane)]:

					if old_resists[e1] == 0 and old_resists[e2] == 0: continue
					if old_resists[e1] == old_resists[e2]: continue

					unit.resists[e1] = old_resists[e2]
					unit.resists[e2] = old_resists[e1]

					if stabilize and not hostile:
						unit.resists[e1] = max(unit.resists[e1], old_resists[e1])
						unit.resists[e2] = max(unit.resists[e2], old_resists[e2])
					if hostile:
						if degrade:
							unit.resists[e1] = min(unit.resists[e1], old_resists[e1])
							unit.resists[e2] = min(unit.resists[e2], old_resists[e2])

					color = e1.color if old_resists[e1] > old_resists[e2] else e2.color
					lvl.show_effect(unit.x, unit.y, Tags.Debuff_Apply, fill_color=color)
				if banish and unit.turns_to_death is not None: unit.kill()
				if hostile and flummox: unit.apply_buff(Silence(), dur)
			else: lvl.show_effect(p.x, p.y, Tags.Chaos)
			if random.random() < .25: yield


class FaehauntGardenBuff(Buff):

	def __init__(self, spell):
		Buff.__init__(self)
		self.name = "Faehaunt Gardener"
		self.buff_type = BUFF_TYPE_BLESS
		self.color = Tags.Arcane.color
		self.counter = 0
		self.summon_count = 0
		self.global_triggers[EventOnDamaged] = self.on_damaged

		self.spell = spell
		self.counter_max = spell.get_stat('minion_health')
		self.prune = spell.get_stat('prune')
		self.glass = spell.get_stat('glass')
		self.pupil = spell.get_stat('pupil')

	def get_description(self):
		return (("For every [{cmax}:minion_health] [Lightning] or [Arcane] damage you deal, summon a Butterfly Demon\n"
				"Damage dealt: {c} / [{cmax}:minion_health]", {'cmax':self.counter_max, 'c':self.counter}))

	def on_damaged(self, evt):
		if evt.damage_type not in [Tags.Arcane, Tags.Lightning]: return
		if not evt.source or not evt.source.owner == self.owner: return
		owner = self.owner

		self.counter += evt.damage
		if self.prune and not are_hostile(evt.unit, owner): self.counter += evt.damage

		while self.counter > self.counter_max:
			self.counter -= self.counter_max
			self.summon_count += 1
			if self.glass: butterfly = self.spell.get_glass_butterfly()
			else: butterfly = self.spell.get_butterfly()
			if self.pupil and self.summon_count % 3 == 0:
				butterfly.spells = []
				grant_minion_spell(LightningBoltSpell, butterfly, self.spell.caster, cool_down=2)
				grant_minion_spell(VoidBeamSpell, butterfly, self.spell.caster, cool_down=3)
			bfly = self.summon(butterfly, target=evt.unit, sort_dist=False)
			if bfly: owner.level.show_path_effect(owner, bfly, [Tags.Arcane, Tags.Lightning], minor=True, inclusive=False)

class FaehauntGardenSpell(Spell):

	def on_init(self):
		self.name = "Faehaunt Garden"
		self.tags = [Tags.Enchantment, Tags.Arcane, Tags.Nature, Tags.Lightning, Tags.Conjuration]
		self.level = 6
		self.max_charges = 2
		self.duration = 9
		self.minion_duration = 6
		self.range = 0

		example = ButterflyDemon()
		self.minion_health = example.max_hp
		self.minion_range = example.spells[0].range
		self.minion_damage = example.spells[0].damage

		self.upgrades['prune'] = (1, 2, "Garden Pruning", "Damage dealt to allies counts double towards summoning Butterflies")
		self.upgrades[('gnomes', 'num_summons')] = ([1, 4], 3, "Guardian Gnomes", "Summon [{num_summons}:num_summons] Gnomes on casting Faehaunt Garden")
		self.upgrades['glass'] = (1, 4, "Glass Garden", "Summon Glass Butterflies instead of Butterfly Demons")
		self.upgrades['pupil'] = (1, 7, "Fae Pupils", "Every 3rd Butterfly summoned has its Void Beam replaced with your Void Beam and its Lightning Beam replaced with your Lightning Bolt")

		self.add_upgrade_tooltip("Guardian Gnomes", self.get_gnome)
		self.add_upgrade_tooltip("Glass Garden", self.get_glass_butterfly)

	def get_gnome(self):
		gnome = Gnome()
		apply_minion_bonuses(self, gnome)
		return gnome

	def get_butterfly(self):
		u = ButterflyDemon()
		apply_minion_bonuses(self, u)
		return u

	def get_glass_butterfly(self):
		u = GlassButterfly()
		apply_minion_bonuses(self, u)
		return u

	def get_extra_examine_tooltips(self):
		return [self.get_butterfly()] + self.get_upgrade_tooltips()

	def get_description(self):
		return ("For every [{minion_health}:minion_health] [Lightning] or [Arcane] damage you deal, summon a Butterfly Demon\n"
				"Lasts [{duration}:duration] turns")

	def cast_instant(self, x, y):
		self.caster.apply_buff(FaehauntGardenBuff(self), self.get_stat('duration'))

		if self.get_stat('gnomes'):
			for _ in range(self.get_stat('num_summons')):
				gnome = self.get_gnome()
				self.summon(gnome)

class FurnaceOfSorceryBuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)

		self.purity = spell.get_stat('purity')
		self.smithy = spell.get_stat('smithy')

	def on_init(self):

		self.global_triggers[EventOnDamaged] = self.on_damage
		self.counter = 0
		self.counter_max = 100
		self.tag = Tags.Sorcery

		self.imp_counter = 0
		self.imp_counter_max = 50

	def get_description(self):
		return ("For every {val} damage dealt to enemies with {tag} spells and equipment, summon a Furnace Hound"
				"\n\nDamage Dealt: {dealt}", {"val": self.counter_max, "tag": formatted_tag(self.tag), "dealt": self.counter})

	def on_damage(self, evt):
		if not evt.source: return
		if not hasattr(evt.source, 'tags'): return
		if Tags.Sorcery not in evt.source.tags: return

		self.counter += evt.damage
		if self.purity and evt.damage_type in [Tags.Fire, Tags.Holy]: self.counter += evt.damage
		self.owner.level.show_effect(self.owner.x, self.owner.y, Tags.Fire)

		while self.counter >= self.counter_max:
			self.counter -= self.counter_max
			hound = self.summon(self.spell.make_hound(), sort_dist=False)
			if hound: self.owner.level.show_path_effect(self.owner, hound, [Tags.Dark, Tags.Fire], minor=True)

		if not self.smithy: return
		self.imp_counter += evt.damage

		while self.imp_counter >= self.imp_counter_max:
			self.imp_counter -= self.imp_counter_max
			imp = self.summon(make_minion(self.spell, FurnaceImp), sort_dist=False)
			if imp: self.owner.level.show_path_effect(self.owner, imp, [Tags.Dark, Tags.Fire], minor=True)



class FurnaceOfSorcerySpell(Spell):

	def on_init(self):
		self.name = "Furnace of Sorcery"
		self.tags = [Tags.Sorcery, Tags.Metallic, Tags.Fire, Tags.Conjuration]
		self.level = 6

		self.must_target_empty = True
		self.must_target_walkable = True
		self.max_charges = 1

		example = FurnaceHound()

		self.minion_damage = example.spells[0].damage
		self.minion_range = example.spells[1].range
		self.minion_health = example.max_hp
		self.radius = 4

		self.upgrades['purity'] = (1, 4, "Furnace of Purity", "[Holy] and [Fire] damage count double", [Tags.Holy])
		self.upgrades['flames'] = (1, 3, "Flames of Sorcery", "The furnace can cast your Flame Burst on a 5 turn cooldown")
		self.upgrades['smithy'] = (1, 5, "Imp Smithy", "The furnace also summons a Furnace Imp for every 50 damage dealt", [Tags.Dark])
		self.upgrades['lasers'] = (1, 7, "Arcane Eyebolts", "Furnace Hounds can cast your Magic Missile on a 4 turn cooldown", [Tags.Arcane])

		self.add_upgrade_tooltip("Imp Smithy", lambda: make_minion(self, FurnaceImp))

	# Do not show radius on targeting
	def get_impacted_tiles(self, x, y):
		if self.get_stat('flames'):
			spell = self.caster.get_or_make_spell(FlameBurstSpell)
			return spell.get_impacted_tiles(x, y)
		return [Point(x, y)]

	def get_extra_examine_tooltips(self):
		return [self.crucible(), self.make_hound()] + self.get_upgrade_tooltips()

	def get_description(self):
		return "Summon a Furnace of Sorcery which summons Furnace Hounds for every 100 damage dealt by [Sorcery] spells and equipment"

	def make_hound(self):
		hound = FurnaceHound()
		apply_minion_bonuses(self, hound)
		hound.buffs[1].radius = self.get_stat('radius')
		if self.get_stat('lasers'): grant_minion_spell(MagicMissile, hound, self.caster, cool_down=4)
		return hound

	def crucible(self):
		crucible = Idol()
		crucible.tags.append(Tags.Metallic)
		crucible.name = "Furnace of Sorcery"
		crucible.asset_name = "crucible_of_pain_idol"
		crucible.buffs.append(FurnaceOfSorceryBuff(self))
		apply_minion_bonuses(self, crucible)
		if self.get_stat('flames'): grant_minion_spell(FlameBurstSpell, crucible, self.caster, cool_down=5)
		return crucible

	def cast_instant(self, x, y):
		self.summon(self.crucible(), target=Point(x, y))



class GoldSkullSummonSpell(Spell):

	def on_init(self):
		self.name = "Golden Skull"
		self.tags = [Tags.Dark, Tags.Holy, Tags.Metallic, Tags.Conjuration]
		self.level = 5
		self.max_charges = 2

		self.minion_damage = 13
		self.minion_range = 7
		self.minion_health = 78

		self.must_target_empty = True


		self.upgrades['bloodshift'] = (1, 4, "Blood Skull", "The Golden Skull can cast your Bloodshift on a 3 turn cooldown", [Tags.Blood])
		self.upgrades['helmet'] = (1, 5, "Armored Skulls", "The Golden Skull is equipped with a copy of your headwear if you own any")
		self.upgrades['wheel'] = (1, 6, "Golden Wheel", "The Golden Skull can cast your Wheel of Death on a 12 turn cooldown")
		self.upgrades['sentry'] = (1, 5, "Skull Sentry", "When you cast this spell, if there is room, summon a Skull Sentry instead of a Golden Skull")

		self.add_upgrade_tooltip("Skull Sentry", self.skullsentry)

	def get_extra_examine_tooltips(self):
		return [self.skull()] + self.get_upgrade_tooltips()

	def skull(self):
		skull = GoldSkull()
		apply_minion_bonuses(self, skull)
		if self.get_stat('wheel'): grant_minion_spell(WheelOfDeath, skull, self.caster, cool_down=12)
		if self.get_stat('bloodshift'): grant_minion_spell(Bloodshift, skull, self.caster, cool_down=3)
		return skull

	def skullsentry(self):
		skull = SkullSentry()
		apply_minion_bonuses(self, skull)
		if self.get_stat('wheel'): grant_minion_spell(WheelOfDeath, skull, self.caster, cool_down=12)
		if self.get_stat('bloodshift'): grant_minion_spell(Bloodshift, skull, self.caster, cool_down=3)
		return skull

	def skullsentry_if_possible(self, x, y):
		if not self.get_stat('sentry'): return None
		skull = self.skullsentry()
		if not self.caster.level.can_stand(x, y, skull): return None
		return skull

	def get_description(self):
		return "Summon a Golden Skull"

	def get_impacted_tiles(self, x, y):
		skull = self.skullsentry_if_possible(x, y)
		if skull: return self.caster.level.get_points_in_ball(x, y, skull.radius, diag=True)
		return [Point(x, y)]

	def cast_instant(self, x, y):
		skull = self.skullsentry_if_possible(x, y) or self.skull()

		unit = self.summon(skull, target=Point(x, y))

		if unit and self.get_stat('helmet'):
			helm = next((i for i in self.caster.equipment if i.slot == SLOT_HELMET), None)
			if helm: self.caster.grant_equipment_copy_to_minion(unit, helm)

class IncubatorUpgrade(Upgrade):

	def __init__(self, spell):
		self.spell = spell
		Upgrade.__init__(self)

	def on_init(self):
		self.name = "Incubation Exposure"
		self.description = "When one of your wyrm eggs is killed, the wyrm it spawns gains 100% resistance to the damage type that killed it"
		self.level = 3
		self.global_triggers[EventOnDeath] = self.on_death
		self.global_triggers[EventOnUnitAdded] = self.on_unit_added
		self.owner_triggers[EventOnUnitAdded] = self.on_owner_added
		self.eggs = dict()

	def on_owner_added(self, evt):
		self.eggs.clear()

	def on_death(self, evt):
		if not evt.damage_event: return
		if evt.unit not in self.eggs: return
		self.eggs[evt.unit] = evt.damage_event.damage_type # stash the dtype that killed them

	def on_unit_added(self, evt):
		if evt.unit.source != self.spell: return # didn't come from the spell, ignore
		parent = evt.unit.parent
		if not parent: self.eggs[evt.unit] = None; return # it's an egg, store it in the dict; get out
		dtype = self.eggs.get(parent) # it's a wyrm, find out what killed it
		if parent in self.eggs: del self.eggs[parent] # clear the entry so it doesn't balloon
		if dtype is None: return # no buff if it was killed by non-damage
		bonus = 100 - evt.unit.resists[dtype]
		evt.unit.apply_buff(ResistBuff(dtype, bonus)) # grant buff

class ScaleHarvestUpgrade(Upgrade):

	def on_init(self):
		self.name = "Scale Harvest"
		self.description = "For every 8 [Dragon] allies that die, regain a charge of Wyrm Eggs\nAlways Active"
		self.level = 5
		self.global_triggers[EventOnDeath] = self.on_death
		self.global_triggers[EventOnUnitAdded] = self.on_unit_added
		self.deaths = 0
		self.threshold = 8

	def on_unit_added(self, evt):
		if evt.unit.is_player_controlled:
			self.deaths = 0

	def on_death(self, evt):
		if Tags.Dragon in evt.unit.tags and not are_hostile(evt.unit, self.owner): self.deaths += 1
		while self.deaths >= self.threshold:
			self.deaths -= self.threshold
			self.owner.get_or_make_spell(WyrmEggs).refund_charges(1)

class WyrmEggs(Spell):

	def on_init(self):
		self.name = "Wyrm Eggs"
		self.tags = [Tags.Fire, Tags.Ice, Tags.Dragon, Tags.Conjuration]
		self.level = 7
		self.max_charges = 1
		self.range = 5
		self.requires_los = False
		self.range = 0
		self.num_summons = 4

		example = IceWyrm()
		self.minion_health = example.max_hp
		self.minion_damage = example.spells[1].damage
		self.minion_range = example.spells[0].range

		self.upgrades['magic_eggs'] = (1, 4, "Magic Eggs", "Fire eggs can cast your Fireball on a 3 turn cooldown\nIce eggs can cast your Icicle on a 3 turn cooldown")
		self.upgrades[('radiant_eggs', 'damage', 'radius')] = ([1, 1, 3], 3, "Radiant Eggs", "Wyrm Eggs gain a damaging aura with a [{radius}:radius] tile radius\nThe aura deals [{damage}:damage] [Fire] or [Ice] damage to match the egg's type")
		self.add_upgrade(ScaleHarvestUpgrade())
		self.add_upgrade(IncubatorUpgrade(self))

	def get_description(self):
		return ("Summons [{num_summons}:num_summons] Wyrm eggs near the caster\n"
				"Each egg will hatch into either a [Fire] or an [Ice] wyrm on death")

	def cast(self, x, y):
		for i in range(self.get_stat('num_summons')):
			egg = random.choice((self.make_fire_wyrm_egg, self.make_ice_wyrm_egg))
			self.summon(egg(), radius=4, sort_dist=False)
			yield

	def make_fire_wyrm_egg(self):
		u = FireWyrmEgg()
		if self.get_stat('magic_eggs'): grant_minion_spell(FireballSpell, u, self.caster, cool_down=3)
		if self.get_stat('radiant_eggs'): u.buffs.append(DamageAuraBuff(damage=self.get_stat('damage'), damage_type=Tags.Fire, radius=self.get_stat('radius')))
		apply_minion_bonuses(self, u)
		return u

	def make_fire_wyrm(self):
		u = FireWyrm()
		apply_minion_bonuses(self, u)
		return u

	def make_ice_wyrm_egg(self):
		u = IceWyrmEgg()
		if self.get_stat('magic_eggs'): grant_minion_spell(Icicle, u, self.caster, cool_down=3)
		if self.get_stat('radiant_eggs'): u.buffs.append(DamageAuraBuff(damage=self.get_stat('damage'), damage_type=Tags.Ice, radius=self.get_stat('radius')))
		apply_minion_bonuses(self, u)
		return u

	def make_ice_wyrm(self):
		u = IceWyrm()
		apply_minion_bonuses(self, u)
		return u

	def get_extra_examine_tooltips(self):
		return [self.make_fire_wyrm_egg(), self.make_fire_wyrm(), self.make_ice_wyrm_egg(), self.make_ice_wyrm()] + self.get_upgrade_tooltips()

class GlaiveWarden(Upgrade):

	def on_init(self):
		self.name = "Glaive Warden"
		self.description = "Moon Glaive gains +1 [damage] each time a [Living] or [Nature] ally is summoned\nBonus damage lasts until next realm\nAlways Active\nAdds [Nature] tag"
		self.level = 5
		self.added_tags = [Tags.Nature]
		self.tags = [Tags.Metallic, Tags.Arcane, Tags.Sorcery, Tags.Nature]
		self.global_triggers[EventOnUnitAdded] = self.on_added

	def on_added(self, evt):
		if are_hostile(self.owner, evt.unit): return
		if evt.unit == self.owner: return
		self.owner.level.queue_spell(self.check_added_unit(evt.unit))

	def check_added_unit(self, unit):
		if Tags.Living in unit.tags or Tags.Nature in unit.tags:
			self.owner.apply_buff(GlaiveWardenBuff())
		yield

class GlaiveWardenBuff(Buff):

	def on_init(self):
		self.name = "Glaive Warden"
		self.buff_type = BUFF_TYPE_BLESS
		self.color = Tags.Nature.color
		self.spell_bonuses[MoonGlaive]['damage'] = 1
		self.stack_type = STACK_INTENSITY

class GravityBladeBuff(Buff):

	def __init__(self, spell):

		self.spell = spell
		self.radius = spell.get_stat('radius')

		Buff.__init__(self)
		self.name = "Gravity Blade"
		self.buff_type = BUFF_TYPE_BLESS
		self.color = Tags.Metallic.color

	def get_description(self):
		return ("Each turn, pull enemies within [{radius}:radius] tiles toward the glaive", {'radius': self.radius})

	def on_applied(self, owner):
		self.on_advance()

	def on_advance(self):
		# pull stuff towards blade
		units = [u for u in self.owner.level.get_units_in_ball(self.owner, self.radius) if are_hostile(u, self.spell.owner)]
		units.sort(key=lambda u: self.owner.level.unit_distance(u, self.owner)) # pull closest first
		for u in units:
			for _ in range(self.radius):
				self.owner.level.queue_spell(self.pull(u))

	def pull(self, u):
		if not u.is_alive(): return
		self.owner.level.show_beam(u, self.owner, Tags.Arcane, minor=True)
		pull(u, self.owner, 1)
		yield

class MoonGlaiveBuff(Buff):

	def __init__(self, spell, unit):
		self.spell = spell
		self.unit = unit
		self.damage = spell.get_stat('damage')
		self.damage_type = spell.get_stat('damage_type')
		Buff.__init__(self)

	def on_init(self):
		self.buff_type = BUFF_TYPE_BLESS
		self.stack_type = STACK_INTENSITY
		self.name = "Moon Glaive"

	def get_description(self):
		return "When this buff ends, Moon Glaive returns to you and deals [{damage}:damage] [Arcane] and [Physical] damage in a line", {'damage': self.damage}

	def on_unapplied(self):

		if not self.owner.is_alive(): return
		if not self.unit.is_alive(): return

		origin = Point(self.unit.x, self.unit.y)
		self.unit.kill()
		level = self.spell.caster.level
		damage = self.damage
		# deal damage along the beam and show proj effect
		for p in level.get_points_in_line(origin, self.owner)[:-1]:
			level.projectile_effect(p.x, p.y, proj_name='moon_glaive', proj_dest=self.spell.caster, proj_origin=origin)
			if level.get_unit_at(p.x, p.y):
				for dtype in self.damage_type:
					level.deal_damage(p.x, p.y, damage, dtype, self)
			else: level.show_effect(p.x, p.y, Tags.Arcane, minor=True)

		self.owner.remove_buff(self)


class MoonGlaive(Spell):

	def on_init(self):
		self.name = "Moon Glaive"
		self.tags = [Tags.Metallic, Tags.Arcane, Tags.Sorcery]
		self.damage_type = [Tags.Physical, Tags.Arcane]
		self.level = 2
		self.max_charges = 7
		self.range = 9
		self.damage = 14

		self.upgrades['los_hit'] = (1, 4, "Glimmerblade", "Deals [{damage}:damage] [Arcane] damage to enemies in line of sight of the target", None, None, {'damage':1})
		self.upgrades[('lightning_hit', 'radius')] = ([1, 2], 3, "Electroblade", "Moon Glaive also deals [Lightning] damage as it travels\n"
		"When it reaches its destination, Moon Glaive deals [{damage}:damage] [Lightning] damage to enemies within [{radius}:radius] tiles", [Tags.Lightning], [Tags.Lightning], {'damage':14})
		self.upgrades[('gravity_blade', 'radius', 'duration')] = ([1, 3, 4], 3, "Gravityblade", "Moon Glaive now pulls all enemies within [{radius} tiles:radius] toward itself each turn"
																								"\nIt will linger for [{duration}:duration] turns before returning")
		self.add_upgrade(GlaiveWarden())
		self.add_upgrade_tooltip("Gravityblade", self.get_gravity_blade_buff)

		self.must_target_empty = True

	def get_moon_glaive_buff(self, unit=None):
		return MoonGlaiveBuff(self, unit)

	def get_gravity_blade_buff(self):
		return GravityBladeBuff(self)

	def get_impacted_tiles(self, x, y):
		for p in self.caster.level.get_points_in_line(self.caster, Point(x, y))[1:]:
			yield p

	def cast(self, x, y, returning=False):
		caster = self.caster
		level = caster.level

		damage = self.get_stat('damage')
		los_hit = self.get_stat('los_hit')
		los_damage = self.get_stat('damage', base=1)

		# deal damage along the beam and show proj effect
		for p in level.get_points_in_line(caster, Point(x, y))[1:]:
			level.projectile_effect(p.x, p.y, proj_name='moon_glaive', proj_origin=caster, proj_dest=Point(x, y))
			yield
			if level.get_unit_at(p.x, p.y):
				for dtype in self.damage_type:
					level.deal_damage(p.x, p.y, damage, dtype, self)
					yield
			else: level.show_effect(p.x, p.y, Tags.Arcane, minor=True)

		if los_hit:
			for u in level.get_units_in_los(Point(x, y)):
				if are_hostile(caster, u): u.deal_damage(los_damage, Tags.Arcane, self)

		if self.get_stat('lightning_hit'):
			possible_targets = [t for t in level.get_units_in_ball(Point(x, y), self.get_stat('radius')) if are_hostile(t, caster)]
			random.shuffle(possible_targets)
			for u in possible_targets: level.deal_damage(u.x, u.y, damage, Tags.Lightning, self)

		# Make unit
		unit = self.make_glaive()
		if self.get_stat('gravity_blade'): unit.buffs.append(GravityBladeBuff(self))
		summoned_unit = self.summon(unit, target=(Point(x, y)))
		if not summoned_unit: return

		# apply buff
		if self.get_stat('gravity_blade'): duration = self.get_stat('duration')
		else: duration = 2
		self.caster.apply_buff(self.get_moon_glaive_buff(unit), duration=duration)

	def make_glaive(self):
		unit = Unit()
		unit.tags = [Tags.Metallic, Tags.Arcane, Tags.Construct]
		unit.name = "Moon Glaive"
		unit.asset_name = "glaive_placeholder"
		unit.max_hp = 16
		for dtype in damage_tags: unit.resists[dtype] = 100
		unit.stationary = True
		unit.flying = True
		return unit

	def get_description(self):
		return ("Hurl a Moon Glaive at the target\n"
				"Deal [{damage}:damage] [Arcane] and [Physical] damage in a line\n"
				"The glaive will linger on the target tile for 1 turn, and return at the end of your next turn, dealing damage again\n"
				"Must target an unoccupied tile")


class CarnivalOfPainBuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		self.num_targets = spell.get_stat('num_targets')
		self.crowd_participation = spell.get_stat('allied')
		self.deathpower = spell.get_stat('death_power')
		self.torment = spell.get_stat('summon_tormentor')
		self.lifesteal = spell.get_stat('lifesteal')

		Buff.__init__(self)

	def on_init(self):
		self.name = "Carnival of Pain"
		self.global_triggers[EventOnDamaged] = self.on_damage
		self.kills = 0
		self.buff_type = BUFF_TYPE_BLESS
		self.color = Tags.Chaos.color

	def get_description(self):
		if self.crowd_participation:
			desc = [("When a unit takes [Physical], [Fire], or [Lightning] damage, the [{num_targets}:num_targets] nearest enemies in line of sight take half that much [Dark] damage", {'num_targets': self.num_targets})]
		else:
			desc = [("When an enemy takes [Physical], [Fire], or [Lightning] damage, their [{num_targets}:num_targets] nearest allies in line of sight take half that much [Dark] damage", {'num_targets': self.num_targets})]
		if self.deathpower:
			desc.append("\nIf the triggering damage killed the unit, the [Dark] damage is doubled")
		if self.torment:
			desc.append("\nEvery 3rd kill by Carnival of Pain casts your Fiery Tormentor spell at the slain unit's location")
		if self.lifesteal:
			desc.append("\nHeal for half the [Dark] damage dealt by Carnival of Pain")
		return desc

	def on_damage(self, evt):
		if not are_hostile(self.owner, evt.unit) and not self.crowd_participation: return
		if evt.damage_type not in [Tags.Fire, Tags.Physical, Tags.Lightning]: return
		self.owner.level.queue_spell(self.do_damage(evt))

	def do_damage(self, evt):
		evt_u = evt.unit
		modifier = .5
		if self.deathpower and not evt_u.is_alive(): modifier = 1
		friendly = are_hostile(self.owner, evt_u)
		enemy = not friendly
		num_targets = self.num_targets
		targets = self.owner.level.get_units_by_distance(evt_u, friendly=friendly, enemy=enemy, require_los=True, max_results=num_targets)
		if not targets: return
		damage_dealt = 0
		dmg = int(evt.damage * modifier)
		summon_tormentor = self.torment
		show_beam = self.owner.level.show_beam

		for u in targets:
			if not u.is_alive(): continue
			if u.resists[Tags.Dark] < 100: show_beam(evt_u, u, Tags.Dark)
			damage_dealt += u.deal_damage(dmg, Tags.Dark, self.spell)
			if summon_tormentor and not u.is_alive():
				self.kills += 1
				if self.kills >= 3:
					self.kills -= 3
					tormentor_spell = self.owner.get_or_make_spell(SummonFieryTormentor)
					self.owner.level.defer_cast(self.spell.caster, tormentor_spell, u.x, u.y, pay_costs=False)
			yield

		if self.lifesteal: self.spell.caster.deal_damage(-damage_dealt//2, Tags.Heal, self)

class CarnivalOfPain(Spell):

	def on_init(self):

		self.name = "Carnival of Pain"
		self.tags = [Tags.Dark, Tags.Chaos, Tags.Enchantment]
		self.level = 4
		self.max_charges = 1
		self.duration = 5
		self.num_targets = 3

		self.range = 0

		self.kills = 0

		self.upgrades[('hp_cost', 'lifesteal')] = ([100, 1], 5, "Lifesteal", "Carnival of Pain heals you for 50% the damage it deals", [Tags.Blood])
		self.upgrades['death_power'] = (1, 3, "Death Power", "If the triggering damage killed the enemy, the bolt coming out of that enemy deals double damage")
		self.upgrades['summon_tormentor'] = (1, 7, "Torment", "Every 3rd kill by Carnival of Pain casts your Fiery Tormentor spell at the slain unit's location", [Tags.Conjuration])
		self.upgrades['allied'] = (1, 7, 'Crowd Participation', "Carnival of Pain triggers when any unit takes damage, not only enemies")


	def get_description(self):
		return ("When an enemy takes [Physical], [Fire], or [Lightning] damage, their [{num_targets}:num_targets] nearest allies in line of sight take half that much [Dark] damage\n"
				"Lasts [{duration}:duration] turns")

	def get_carnival_of_pain_buff(self):
		return CarnivalOfPainBuff(self)

	def get_extra_examine_tooltips(self):
		return [self.get_carnival_of_pain_buff()] + self.get_upgrade_tooltips()

	def cast_instant(self, x, y):
		self.caster.apply_buff(self.get_carnival_of_pain_buff(), self.get_stat('duration'))

class MassCalcification(Spell):

	def on_init(self):
		self.name = "Mass Calcification"
		self.tags = [Tags.Dark, Tags.Enchantment]
		self.level = 4
		self.range = 0
		self.max_charges = 3

		self.upgrades[('shards', 'damage', 'num_targets')] = ([1, 7, 3], 4, "Bone Shards", "Slain allies explode, dealing [{damage}:damage] [Physical] damage to up to [{num_targets}:num_targets] enemies in their line of sight")
		self.upgrades[('blood', 'hp_cost')] = ([1, 10], 5, "Blood Salvage", "Heal for the current HP of allies slain by this spell", [Tags.Blood])
		self.upgrades['aggregate'] = (1, 2, "Osseous Amalgam", "Instead of summoning individual Bone Shamblers, summon a single massive Bone Shambler with the slain units' combined HP")
		self.upgrades['harvest'] = (1, 5, "Dark Harvest", "Regain a charge of another [Dark] spell when you kill an ally with Mass Calcification")

	def get_description(self):
		return ("Non [Undead] allies are killed and raised as Bone Shamblers\n"
				"Bone Shamblers inherit the HP of slain units, and have a melee attack that deals damage equal to a quarter of their max HP")

	def get_impacted_tiles(self, x, y):
		return [u for u in self.owner.level.units if u != self.owner and not are_hostile(u, self.owner) and Tags.Undead not in u.tags]

	def make_shambler(self, hp):
		shambler = BoneShambler(hp)
		apply_minion_bonuses(self, shambler)
		return shambler

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		shards = self.get_stat('shards')
		blood = self.get_stat('blood')
		aggregate = self.get_stat('aggregate')
		harvest = self.get_stat('harvest')

		total = 0
		allies_slain = 0

		path_tags = [Tags.Dark]
		if blood: path_tags.append(Tags.Blood)

		num_targets = self.get_stat('num_targets')
		dmg = self.get_stat('damage')

		units = [u for u in level.units if u != caster and Tags.Undead not in u.tags and are_friendly(u, caster)]
		random.shuffle(units)

		for u in units:
			level.show_path_effect(caster, u, path_tags, minor=True, inclusive=False)
			yield
			if shards:
				targets = [unit for unit in level.get_units_in_los(u) if are_hostile(u, unit)]
				if targets:
					random.shuffle(targets)
					for i in range(min(num_targets, len(targets))):
						level.show_path_effect(u, targets[i], Tags.Physical, minor=True, inclusive=False)
						targets[i].deal_damage(dmg, Tags.Physical, self)
					yield
			level.show_effect(u.x, u.y, Tags.Dark)

			if blood:
				level.show_path_effect(u, caster, path_tags)
				caster.heal(u.cur_hp, self)

			u.kill()
			allies_slain += 1

			if aggregate:
				total += u.max_hp
				level.show_path_effect(u, caster, path_tags)
			else:
				shambler = self.make_shambler(u.max_hp)
				self.summon(shambler, target=u)

			yield

		if harvest and allies_slain:
			candidates = [s for s in caster.spells if Tags.Dark in s.tags and s != self and s.cur_charges < s.get_stat('max_charges')]
			for i in range(allies_slain):
				if not candidates: break
				s = random.choice(candidates)
				s.refund_charges(1)
				if s.cur_charges == s.get_stat('max_charges'): candidates.remove(s)

		if aggregate and total: self.summon(self.make_shambler(total)); yield

class ScourgeBuff(Stun):

	def __init__(self, spell):
		self.spell = spell
		Stun.__init__(self)

	def on_init(self):
		self.buff_type = BUFF_TYPE_CURSE
		self.stack_type	= STACK_NONE
		self.name = "Scourged"
		self.color = Tags.Holy.color
		self.asset = ['status', 'stun']
		self.radius = self.spell.get_stat('radius')
		self.damage = self.spell.get_stat('damage')
		self.ascension = self.spell.get_stat('ascension')
		self.painful_lesson = self.spell.get_stat('painful_lesson')
		self.fear_duration = self.spell.get_stat('duration')
		self.description = "Cannot act\nEach turn, this unit and nearby units take [Holy] damage"
		if self.ascension: self.owner_triggers[EventOnDeath] = self.on_death
		self.freeze_animation = True

	def get_description(self):
		desc = "Cannot act\nEach turn, this unit and units within [{radius}:radius] tiles take [{damage}:damage] [Holy] damage"
		if self.ascension: desc += "\nOn death, if this unit is a [Demon], cast a random [Holy] [Conjuration] spell you know at its location"
		if self.painful_lesson: desc += "\nWhen this buff ends, inflict [fear] for [{duration}:duration] turns"
		return (desc, {'radius': self.radius, 'damage': self.damage, 'duration': self.fear_duration})

	def on_advance(self):
		for t in self.owner.level.get_tiles_in_ball(self.owner.x, self.owner.y, self.radius):
			self.owner.level.deal_damage(t.x, t.y, self.damage, Tags.Holy, self.spell)

	def on_death(self, evt):
		spell = None
		if self.ascension and Tags.Demon in evt.unit.tags:
			spells = [s for s in self.spell.owner.spells if Tags.Holy in s.tags and Tags.Conjuration in s.tags]
			if spells: spell = random.choice(spells)
		if spell: self.owner.level.act_cast(self.spell.owner, spell, evt.unit.x, evt.unit.y, pay_costs=False)

	def on_unapplied(self):
		if self.painful_lesson: self.owner.apply_buff(FearBuff(), self.fear_duration)
		else: Stun.on_unapplied(self)

class ScourgeSpell(Spell):

	def on_init(self):
		self.name = "Scourge"
		self.level = 3
		self.max_charges = 6
		self.tags = [Tags.Holy, Tags.Enchantment]
		self.damage = 5
		self.duration = 3
		self.radius = 1
		self.range = 4
		self.can_target_empty = False

		self.upgrades['ascension'] = (1, 6, "Ascension", "When a Scourged [Demon] dies, casts a random [Holy] [Conjuration] you know at that location")
		self.upgrades['mass_scourge'] = (1, 7, "Mass Scourge", "Affects a connected group of enemies")
		self.upgrades['painful_lesson'] = (1, 2, "Painful Lesson", "Scourged inflicts [{duration}:duration] turns of [fear] after it ends", None, None, {'duration':3})
		self.upgrades['exile'] = (1, 4, "Scourged Exile", "Scourge also applies [berserk] for the same duration")

	def get_impacted_tiles(self, x, y):
		tiles = [Point(x, y)]
		if self.get_stat('mass_scourge'):
			tiles += self.caster.level.get_connected_group_from_point(x, y, check_hostile=self.caster)
		return tiles

	def get_description(self):
		return ("The target is Scourged for [{duration}:duration] turns\n"
				"Scourged units cannot act\n"
				"Each turn, the target and units within [{radius}:radius] tiles take [{damage}:damage] [Holy] damage")

	def get_scourge_buff(self):
		return ScourgeBuff(self)

	def get_extra_examine_tooltips(self):
		return [self.get_scourge_buff()] + self.get_upgrade_tooltips()

	def cast_instant(self, x, y):
		targets = [self.caster.level.get_unit_at(x, y)]
		if self.get_stat('mass_scourge'):
			targets += self.caster.level.get_connected_group_from_point(x, y, check_hostile=self.caster) #Currently it's going to scourge allies as well, let me know if you want this to change

		dur = self.get_stat('duration')
		for target in targets:
			if target:
				target.apply_buff(self.get_scourge_buff(), dur)
				if self.get_stat('exile'):
					target.apply_buff(BerserkBuff(), dur)

class ImmolateBuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)

	def on_init(self):
		self.name = "Immolated"
		self.buff_type = BUFF_TYPE_CURSE
		self.stack_type = STACK_INTENSITY
		self.color = Tags.Fire.color
		self.damage = self.spell.get_stat('damage')
		self.damage_growth = self.damage
		self.radiant_heat = self.spell.get_stat('radiant_heat')
		self.radius = self.spell.get_stat('radius')
		self.blind_duration = self.spell.get_stat('duration', base=3)
		self.dragon_soul = self.spell.get_stat('dragon_soul')
		self.cursed = self.spell.get_stat('curse_immolation')
		self.asset = ['status', 'burning']
		self.show_effect = False

		if self.dragon_soul: self.owner_triggers[EventOnDeath] = self.on_death

		self.damage_type = [Tags.Fire]
		if self.cursed: self.damage_type.append(Tags.Dark)

	def get_description(self):
		desc = "Each turn, take [{damage}:damage] [Fire] damage"
		if self.cursed:
			desc += "\nEach turn, take [{damage}:damage] [Dark] damage"
		desc += "\nEach turn, this damage increases by [{damage_growth}:damage]"
		if self.radiant_heat:
			desc += "\nEach turn, enemies within [{radius}:radius] tile radius take half this damage"
			desc += "\nInflict [blind] for [{blind_duration}:duration] turns on those enemies"
		if self.dragon_soul: desc += "\nOn death, regain a charge of another [Dragon] spell"
		return (desc, {'damage': self.damage, 'damage_growth': self.damage_growth, 'radius': self.radius, 'blind_duration': self.blind_duration})

	def on_advance(self):
		for dt in self.damage_type: self.owner.deal_damage(self.damage, dt, self.spell)

		if self.radiant_heat:
			targets = [t for t in self.owner.level.get_units_in_ball(self.owner, self.radius) if are_hostile(self.spell.owner, t)]
			radiant_damage = self.damage // 2
			for u in targets:
				for dt in self.damage_type:
					u.deal_damage(radiant_damage, dt, self.spell)
				u.apply_buff(BlindBuff(), self.blind_duration)

		self.damage += self.damage_growth

	def on_death(self, evt):
		spells = [s for s in self.spell.caster.spells if Tags.Dragon in s.tags if s.cur_charges < s.get_stat('max_charges') and s != self.spell]
		if spells:
			spell = random.choice(spells)
			spell.refund_charges(1)


class ImmolateSpell(Spell):

	def on_init(self):
		self.name = "Immolate"
		self.tags = [Tags.Fire, Tags.Enchantment]
		self.damage_type = [Tags.Fire]
		self.level = 2
		self.must_target_empty = False

		self.damage = 3
		self.duration = 8
		self.range = 4
		self.max_charges = 6


		self.upgrades['mass_immolate'] = (1, 7, "Conflagration", "Immolate affects a connected group of enemies")
		self.upgrades[('radiant_heat', 'radius')] = ([1, 3], 3, "Radiant Heat", "Immolate inflicts [{duration}:duration] turns of [blind] and deals half damage to enemies within [{radius}:radius] tiles each turn", None, None, {'duration':3})
		self.upgrades['dragon_soul'] = (1, 1, "Dragon Soul", "When an immolated enemy dies, regain a charge of another [Dragon] spell you know", [Tags.Dragon])
		self.upgrades['unquenchable'] = (1, 4, "Unquenchable Flames", "Immolate gains permanent duration")
		self.upgrades['curse_immolation'] = (1, 5, "Cursed Flames", "Immolate will also deal [Dark] damage\nManually casting Immolate will remove all debuffs from the caster, and be cast again for free for each debuff removed", [Tags.Dark], [Tags.Dark])

		self.can_target_empty = False

	def get_description(self):
		return ("Target enemy takes [{damage}:damage] [Fire] damage each turn for [{duration}:duration] turns\n"
				"This damage increases by [{damage}:damage] each turn")

	def get_immolate_buff(self):
		return ImmolateBuff(self)

	def get_extra_examine_tooltips(self):
		return [self.get_immolate_buff()] + self.get_upgrade_tooltips()

	def get_impacted_tiles(self, x, y):
		if self.get_stat('mass_immolate'): return self.caster.level.get_connected_group_from_point(x, y, check_hostile=self.caster)
		else: return [Point(x, y)]

	def cast(self, x, y):
		dur = 0 if self.get_stat('unquenchable') else self.get_stat('duration')
		caster = self.caster
		level = caster.level

		level.show_beam(caster, Point(x, y), Tags.Fire, minor=True)
		for t in self.get_impacted_tiles(x, y):
			u = level.get_unit_at(t.x, t.y)
			if u:
				level.show_effect(t.x, t.y, Tags.Immolate)
				u.apply_buff(self.get_immolate_buff(), dur)
				yield
		yield

		if self.get_stat('curse_immolation'):
			if not self.is_manual_cast(): return
			debuffs = 0
			buffs = list(caster.buffs)
			for b in buffs:
				if b.buff_type == BUFF_TYPE_CURSE:
					caster.remove_buff(b)
					debuffs += 1
			if debuffs:
				level.show_effect(caster.x, caster.y, Tags.Immolate)
				for _ in range(debuffs):
					level.act_cast(caster, self, x, y, pay_costs=False)



class ArmageddonArmorBuff(Buff):

	def __init__(self, spell):
		Buff.__init__(self)
		self.spell = spell

	def on_init(self):
		self.name = "Armor of Armageddon"
		self.color = Tags.Chaos.color
		self.description = "Deals 6 [Fire], [Lightning], and [Physical] damage to enemies that harm the owner"

		self.resists[Tags.Fire] = 50
		self.resists[Tags.Lightning] = 50
		self.resists[Tags.Physical] = 50

		self.owner_triggers[EventOnDamaged] = self.on_damaged

	def on_damaged(self, evt):
		if not evt.source: return
		if not evt.source.owner: return
		if not are_hostile(evt.source.owner, self.owner): return
		for tag in [Tags.Fire, Tags.Lightning, Tags.Physical]: evt.source.owner.deal_damage(6, tag, self)

class ArmageddonForetold(Upgrade):

	def on_init(self):
		self.name = "Armageddon Foretold"
		self.level = 4

	def get_description(self):
		return "On the 9th turn of the level, cast Armageddon Blade on allies in your line of sight\nAlways Active"

	def on_advance(self):
		if self.owner.level.turn_no != 8: return
		o = self.owner
		lvl = o.level
		allies = [u for u in lvl.get_units_in_los(o) if not are_hostile(o, u) and o != u]
		for u in allies: lvl.act_cast(o, self.prereq, u.x, u.y, pay_costs=False)

class DoombrandDebuff(Buff):

	def on_init(self):
		self.name = "Doom"
		self.color = Tags.Chaos.color
		self.stack_type = STACK_NONE
		self.buff_type = BUFF_TYPE_CURSE
		for dtype in damage_tags: self.resists[dtype] = -25

class DoombrandBuff(Buff):

	def on_init(self):
		self.name = "Doombrand"
		self.color = Tags.Chaos.color
		self.stack_type = STACK_NONE
		self.buff_type = BUFF_TYPE_BLESS
		self.owner_triggers[EventOnSpellCast] = self.on_cast

	def on_cast(self, evt):
		if not (isinstance(evt.spell, AnnihilateSpell) and evt.spell.melee): return
		u = self.owner.level.get_unit_at(evt.x, evt.y)
		if not u: return
		u.apply_buff(DoombrandDebuff())

class ArmageddonBladeSpell(Spell):

	def on_init(self):
		self.name = "Armageddon Blade"
		self.tags = [Tags.Chaos, Tags.Metallic, Tags.Enchantment]
		self.level = 4
		self.max_charges = 6

		self.can_target_empty = False

		armor_upgrade_text = "Grants a buff which provides 50% resistance to [Fire], [Lightning], and [Physical] damage\nThe buff also deals 6 [Fire], [Lightning], and [Physical] damage to enemies that harm the owner"
		self.upgrades['armor'] = (1, 2, "Armor of Armageddon", armor_upgrade_text)
		self.upgrades['connected_group'] = (1, 7, "Mass Armaments", "Affects a connected group of allies")
		self.upgrades['doombrand'] = (1, 3, "Doombrand", "When the unit uses their Annihilate on an enemy, they inflict the Doom debuff\nDoom reduces all resistances by 25%")
		self.add_upgrade(ArmageddonForetold())

		self.add_upgrade_tooltip("Doombrand", DoombrandDebuff)

	def get_description(self):
		return ("Grant target ally a melee version of your Annihilate spell")

	def cast_instant(self, x, y):
		if self.get_stat('connected_group'): units = self.caster.level.get_connected_group_from_point(x, y, check_friendly=self.caster)
		else: units = [self.owner.level.get_unit_at(x, y)]
		doom = self.get_stat('doombrand')
		armor = self.get_stat('armor')
		for unit in units:
			if unit and unit is not self.caster and not are_hostile(unit, self.caster):
				blade = AnnihilateSpell()
				blade.statholder = self.owner
				blade.melee = True
				blade.range = 1
				blade.max_charges = 0
				unit.add_spell(blade, prepend=True)

				if armor: unit.apply_buff(ArmageddonArmorBuff(self))
				if doom: unit.apply_buff(DoombrandBuff())

				self.owner.level.show_effect(unit.x, unit.y, Tags.ArmageddonBlade, speed=2)

	def get_impacted_tiles(self, x, y):
		if self.get_stat('connected_group'):
			units = self.caster.level.get_connected_group_from_point(x, y, check_friendly=self.caster)
			impacted = []
			for unit in units:
				if unit == self.caster: continue
				impacted.append(self.caster.level.tiles[unit.x][unit.y])
			return impacted
		else: return Spell.get_impacted_tiles(self, x, y)

	def can_cast(self, x, y):
		target = self.caster.level.get_unit_at(x, y)
		if target and are_hostile(self.caster, target): return False
		return Spell.can_cast(self, x, y)

class Bonespear(Spell):

	def on_init(self):

		self.name = "Bone Spear"
		self.tags = [Tags.Sorcery, Tags.Blood]
		self.damage_type = [Tags.Physical]

		self.hp_cost = 3
		self.range = 6
		self.damage = 16
		self.level = 2

		self.upgrades['hellfire'] = (1, 6, "Hellfire Spear", "Bone Spear also deals [Fire] and [Dark] damage", [Tags.Fire, Tags.Dark], [Tags.Fire, Tags.Dark])
		self.upgrades['recall'] = (1, 2, "Osseous Recall", "Bone Spear returns to the caster, dealing damage again to units on its path")
		self.upgrades[('stun', 'duration')] = ([1, 3], 3, "Stunning Spear", "Bone Spear applies [stun] for [{duration}:duration] turns")
		self.upgrades[('damage', 'range', 'hp_cost')] = ([16, 6, 3], 2, "Bone Ballista")

		self.cast_on_walls = True

	def get_impacted_tiles(self, x, y):
		return self.owner.level.get_points_in_line(self.caster, Point(x, y))

	def get_description(self):
		return ("Deal [{damage}:damage] [Physical] damage in a line\nThis spell can target and destroy a wall tile")

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		getu = level.get_unit_at
		projectile_effect = level.projectile_effect
		deal_damage = level.deal_damage
		damage = self.get_stat('damage')
		dtypes = self.get_stat('damage_type')

		stun = self.get_stat('stun')
		dur = self.get_stat('duration')

		target = Point(x, y)

		paths = [(level.get_points_in_line(caster, target)[1:], caster, target)]
		if self.get_stat('recall'): paths.append((reversed(paths[0][0]), target, caster))

		for path in paths:
			origin = path[1]
			dest = path[2]
			for p in path[0]:
				projectile_effect(p.x, p.y, proj_name='bone_spear', proj_origin=origin, proj_dest=dest)
				unit = getu(p.x, p.y)
				flash = unit is not None # dont show damage type effects on every tile hit, just for units
				for dt in dtypes: deal_damage(p.x, p.y, damage, dt, self, flash=flash)
				if unit and stun: unit.apply_buff(Stun(), dur)
				yield

		if level.tiles[x][y].is_wall(): level.make_floor(x, y)

class WormHost(Upgrade):

	def on_init(self):
		self.name = "Worm Host"
		self.level = 6

	def get_description(self):
		return "Lumbriogenesis max charges removed\nYou regenerate 3 HP each turn\nAlways Active"

	def on_applied(self, owner):
		setattr(self.prereq, 'max_charges', 0)

	def on_unapplied(self):
		setattr(self.prereq, 'max_charges', 2)

	def on_advance(self):
		self.owner.heal(3, self)

class Lumbriogenesis(Spell):

	def on_init(self):
		self.name = "Lumbriogenesis"
		self.level = 3
		self.tags = [Tags.Blood, Tags.Nature, Tags.Conjuration]
		self.max_charges = 4
		self.range = 1
		self.melee = True

		self.must_target_empty = True
		self.must_target_walkable = True
		self.target_empty = True

		self.upgrades['toxic'] = (1, 3, "Toxogenesis", "Also summon a Toxic Worm Ball")
		self.upgrades['iron'] = (1, 5, "Mechanogenesis", "Also summon an Iron Worm Ball", [Tags.Metallic])
		self.upgrades['ghostly'] = (1, 4, "Ectogenesis", "Also summon a Ghost Worm Ball", [Tags.Dark])
		self.add_upgrade(WormHost())

		self.add_upgrade_tooltip("Toxogenesis", lambda: self.make_worm_ball(WormBallToxic))
		self.add_upgrade_tooltip("Mechanogenesis", lambda: self.make_worm_ball(WormBallIron))
		self.add_upgrade_tooltip("Ectogenesis", lambda: self.make_worm_ball(WormBallGhostly))

	def get_description(self):
		return ("Pay half your current HP rounded up to summon a Worm Ball with that much health\n"
				"Worm Balls have a melee attack that deals damage equal to half their max HP\n"
				"If you sacrificed 50 or more HP, summon a Worm Shambler instead")

	def can_pay_costs(self):
		if self.caster.cur_hp <= 1: return False
		return Spell.can_pay_costs(self)

	def cast_instant(self, x, y):
		hp = (self.caster.cur_hp + 1) // 2
		if not self.caster.pay_hp(hp, self.name): return
		units = [self.make_worm_ball(hp=hp)]
		if self.get_stat('toxic'): units.append(self.make_worm_ball(WormBallToxic, hp))
		if self.get_stat('iron'): units.append(self.make_worm_ball(WormBallIron, hp))
		if self.get_stat('ghostly'): units.append(self.make_worm_ball(WormBallGhostly, hp))
		for unit in units: self.summon(unit, target=Point(x, y))

	def make_worm_ball(self, spawn_fn=WormBall, hp=None):
		unit = spawn_fn() if hp is None else spawn_fn(hp)
		apply_minion_bonuses(self, unit)
		return unit

	def get_extra_examine_tooltips(self):
		return [self.make_worm_ball(), self.make_worm_ball(hp=50)] + self.get_upgrade_tooltips()

class IgnoreDemonDamageBuff(Buff):

	def on_init(self):
		self.name = "Hellbound"
		self.description = "Negates damage from [Demon] units"

	def on_applied(self, owner):
		def demon_handler(amount, damage_type, source, redirect_chain):
			if amount <= 0: return None
			if not source.owner: return None
			if not Tags.Demon in source.owner.tags: return None
			return 0
		owner.grant_redirect(self, demon_handler)

	def on_unapplied(self):
		self.owner.remove_redirect(self)

class HagSummon(Spell):

	def on_init(self):

		self.name = "Night Hag"
		self.level = 5
		self.hp_cost = 30
		self.max_charges = 0
		self.requires_los = False
		self.range = 8
		self.tags = [Tags.Blood, Tags.Dark, Tags.Conjuration]

		self.must_target_empty = True

		self.minion_health = 84
		self.minion_damage = 2

		self.upgrades["bone_spear"] = (1, 3, "Spear Hag", "The Night Hag can cast your Bone Spear on a 4 turn cooldown")
		self.upgrades["nightmare"] = (1, 5, "Nightmare Hag", "The Night Hag can cast your Nightmare Aura on a 30 turn cooldown", [Tags.Arcane])
		self.upgrades['demonic'] = (1, 4, "Hellbound", "The Night Hag gains the [Demon] tag, and negates incoming damage from other [Demons:demon]")
		self.upgrades[('coven', 'num_summons')] = ([1, 3], 6, "Coven Matron", "Casting this spell also summons [{num_summons}:num_summons] Witches near the Night Hag\nThese Witches will mature into Night Hags after 12 turns")
		self.add_upgrade_tooltip("Coven Matron", self.witch)


	def witch(self):
		u = Witch()
		u.buffs.append(MatureInto(self.hag, 12))
		apply_minion_bonuses(self, u)
		return u

	def hag(self):
		hag = NightHag()
		apply_minion_bonuses(self, hag)
		if self.get_stat('bone_spear'): grant_minion_spell(Bonespear, hag, self.caster, 4)
		if self.get_stat('nightmare'): grant_minion_spell(NightmareSpell, hag, self.caster, 30)
		if self.get_stat('demonic'):
			if Tags.Demon not in hag.tags: hag.tags.append(Tags.Demon)
			hag.apply_buff(IgnoreDemonDamageBuff())
		return hag

	def get_description(self):
		return ("Summon a Night Hag")

	def get_extra_examine_tooltips(self):
		return [self.hag()] + self.get_upgrade_tooltips()

	def cast_instant(self, x, y):
		target = Point(x, y)
		self.summon(self.hag(), Point(x, y))
		if self.get_stat('coven'):
			for _ in range(self.get_stat('num_summons')):
				self.summon(self.witch(), target, sort_dist=False)


class LifedrainDebuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)

	def on_init(self):
		self.buff_type = BUFF_TYPE_CURSE
		self.stacking = self.spell.get_stat('stacking')
		self.damage = self.spell.get_stat('damage')
		self.chain = self.spell.get_stat('chain')
		self.radius = self.spell.get_stat('radius')
		self.num_targets = self.spell.get_stat('num_targets')
		self.stack_type = STACK_INTENSITY if self.stacking else STACK_REPLACE
		self.name = "Lifedrain"
		self.color = Tags.Blood.color
		self.asset = ["status", "blood_tap"]

	def get_description(self):
		desc = "Drain [{dmg}:damage] health per turn"
		if self.chain: desc += "\nAlso drain up to [{num_targets}:num_targets] enemies within [{radius}:radius] tiles"
		return (desc, {"dmg":self.damage, 'num_targets': self.num_targets, 'radius': self.radius})

	def on_advance(self):
		if not self.spell.caster.is_alive(): self.owner.remove_buff(self); return

		for p in self.owner.level.get_points_in_line(self.owner, self.spell.caster)[1:-1]:
			self.owner.level.show_effect(p.x, p.y, Tags.Blood, minor=True)

		dmg = self.owner.deal_damage(self.damage, Tags.Dark, self.spell)
		if dmg: self.spell.caster.deal_damage(-dmg, Tags.Heal, self.spell)

		# Chain targets
		if self.chain:
			potential_targets = self.owner.level.get_units_in_ball(self.owner, self.radius)
			potential_targets = [t for t in potential_targets if are_hostile(self.spell.caster, t) and t != self.owner]
			random.shuffle(potential_targets)

			for u in potential_targets[:self.num_targets]:
				self.owner.level.show_path_effect(self.owner, u, Tags.Blood)
				dmg = u.deal_damage(self.damage, Tags.Dark, self)
				if dmg: self.spell.caster.deal_damage(-dmg, Tags.Heal, self.spell)

class BloodHexes(Upgrade):

	def on_init(self):
		self.level = 6
		self.name = "Blood Hexes"
		self.description = "When you cast an [Enchantment] spell other than Lifedrain targeting an enemy, Lifedrain is also cast on that target\nAlways Active"
		self.owner_triggers[EventOnSpellCast] = self.on_cast

	def on_cast(self, evt):
		if Tags.Enchantment not in evt.spell.tags: return
		if isinstance(evt.spell, LifedrainSpell): return
		unit = self.owner.level.get_unit_at(evt.x, evt.y)
		if not unit: return
		if not are_hostile(self.owner, unit): return
		spell = self.owner.get_spell(LifedrainSpell)
		if not spell: return
		self.owner.level.defer_cast(self.owner, spell, evt.x, evt.y, pay_costs=False)


class LifedrainSpell(Spell):

	def on_init(self):
		self.name = "Lifedrain"
		self.tags = [Tags.Blood, Tags.Dark, Tags.Enchantment]
		self.damage_type = [Tags.Dark]
		self.level = 1
		self.hp_cost = 1
		self.max_charges = 16
		self.duration = 15
		self.damage = 3
		self.range = 4
		self.can_target_empty = False

		self.upgrades['stacking'] = (1, 2, "Exsanguinate", "Lifedrain will stack instead of replacing the previous instance on subsequent applications")
		self.upgrades[('chain', 'num_targets', 'radius')] = ([1, 2, 3], 3, "Life Funnel", "Lifedrain will also deal damage to and drain life from up to [{num_targets}:num_targets] enemies within [{radius}:radius] tiles of the target each turn")
		self.upgrades[('requires_los', 'range')] = ([-1, 8], 2, "Blood Horizon")
		self.add_upgrade(BloodHexes())

	def get_ai_target(self):
		if self.get_stat('stacking'): return Spell.get_ai_target(self) # if it stacks, we can just pile on, otherwise find a new target

		caster = self.caster
		lvl = caster.level
		r = self.get_stat('range')
		requires_los = self.get_stat('requires_los')
		blind = caster.is_blind()
		blind_range = 1 + caster.radius
		potentials = []
		fov = lvl.get_fov_map(caster.x, caster.y, self.cast_on_walls) if requires_los else None
		for u in lvl.units:
			if not are_hostile(u, caster): continue
			if u.has_buff(LifedrainDebuff): continue
			dx = abs(caster.x - u.x)
			dy = abs(caster.y - u.y)
			if dx > r + u.radius + caster.radius or dy > r + u.radius + caster.radius: continue
			pts = list(u.iter_occupied_points()) if u.radius else [Point(u.x, u.y)]
			lvl.random.shuffle(pts)
			candidate = None
			for p in pts:
				pdx = abs(caster.x - p.x)
				pdy = abs(caster.y - p.y)
				if blind and max(pdx, pdy) > blind_range: continue
				if pdx > r or pdy > r: continue
				if pdx * pdx + pdy * pdy > r * r: continue
				if requires_los and not fov[p.y, p.x]:
					if not lvl.can_see(caster.x, caster.y, p.x, p.y, light_walls=self.cast_on_walls):
						continue
				candidate = p
				break
			if candidate: potentials.append(candidate)
		if potentials: return lvl.random.choice(potentials)

	def get_impacted_tiles(self, x, y):
			if not self.get_stat('chain'): return [Point(x, y)]
			else: return Spell.get_impacted_tiles(self, x, y)

	def get_description(self):
		return ("Deal [{damage}:damage] [Dark] damage to the target each turn\n"
				"Heals the caster for damage dealt\n"
				"Lasts [{duration}:duration] turns")

	def get_lifedrain_debuff(self):
		return LifedrainDebuff(self)

	def get_extra_examine_tooltips(self):
		return [self.get_lifedrain_debuff()] + self.get_upgrade_tooltips()

	def cast_instant(self, x, y):
		u = self.owner.level.get_unit_at(x, y)
		if not u: return
		for p in self.owner.level.get_points_in_line(self.caster, Point(x, y)):
			self.owner.level.show_effect(p.x, p.y, Tags.Blood, minor=True)
		if u: u.apply_buff(self.get_lifedrain_debuff(), self.get_stat('duration'))

	def can_threaten(self, x, y):
		return distance(self.caster, Point(x, y)) < self.get_stat('range') and self.caster.level.can_see(self.caster.x, self.caster.y, x, y)

class RitualOfRevelation(Spell):

	def on_init(self):
		self.name = "Ritual of Revelation"
		self.tags = [Tags.Holy, Tags.Blood, Tags.Ritual]
		self.level = 8

		self.max_charges = 1
		self.hp_cost = 77
		self.max_channel = 12
		self.range = 0
		self.num_summons = 7
		self.num_targets = 3

		self.minion_health = 48
		self.minion_range = 6
		self.minion_damage = 8

		self.upgrades['num_summons'] = (4, 6, "Holy Horde")
		self.upgrades['arcane_revelation'] = (1, 8, "Arcane Revelation", "Channeling Ritual of Revelation also casts Blazerip on [{num_targets}:num_targets] enemies each turn", [Tags.Arcane], None, {'num_targets':3})
		self.upgrades['witness'] = (1, 5, "The Witness", "Channeling Ritual of Revelation also casts Blinding Light each turn")
		self.upgrades['arbiters'] = (1, 3, "Arbiter's Revelation", "Instead of False Prophets, summon Arbiters", [Tags.Eye])
		self.add_upgrade_tooltip("Arbiter's Revelation", self.make_arbiter)

	def get_description(self):
		return ("Channel the Ritual of Revelation for [{max_channel}:max_channel] turns\n"
				"Each turn while you channel, Holy Fire will be cast on up to [{num_targets}:num_targets] enemies in line of sight\n"
				"If you complete the ritual, summon [{num_summons}:num_summons] False Prophets nearby")

	def get_extra_examine_tooltips(self):
		return [self.make_prophet()] + self.get_upgrade_tooltips()

	def cast(self, x, y, channel_cast=False):
		if not channel_cast and self.is_manual_cast():
			self.caster.apply_buff(ChannelBuff(self.cast, Point(x, y)), self.get_stat('max_channel'))
			return

		caster = self.caster
		level = caster.level

		num_targets = self.get_stat('num_targets')

		holy_fire = caster.get_or_make_spell(HolyFlame)

		all_targets = [u for u in level.get_units_in_los(self.caster) if are_hostile(caster, u)]
		if all_targets: random.shuffle(all_targets)
		targets = all_targets[:num_targets]
		for u in targets: level.act_cast(caster, holy_fire, u.x, u.y, pay_costs=False); yield

		if self.get_stat('arcane_revelation'):
			blazerip = caster.get_or_make_spell(Blazerip)
			all_targets = [u for u in level.get_units_in_los(self.caster) if are_hostile(caster, u)]
			if all_targets: random.shuffle(all_targets)
			targets = all_targets[:num_targets]
			for u in targets: level.act_cast(caster, blazerip, u.x, u.y, pay_costs=False); yield

		if self.get_stat('witness'):
			light = caster.get_or_make_spell(BlindingLightSpell)
			level.act_cast(caster, light, caster.x, caster.y, pay_costs=False)
			yield

		# ritual complete
		if channel_cast and not caster.has_buff(ChannelBuff):
			summon_func = self.make_arbiter if self.get_stat('arbiters') else self.make_prophet
			for _ in range(self.get_stat('num_summons')):
				self.summon(summon_func(), radius=7)
				yield

	def make_prophet(self):
		u = FalseProphet()
		apply_minion_bonuses(self, u)
		return u

	def make_arbiter(self):
		u = Arbiter()
		apply_minion_bonuses(self, u)
		return u

class DevourFlesh(Spell):

	def on_init(self):
		self.tags = [Tags.Blood]
		self.name = "Devour Flesh"
		self.max_charges = 0
		self.level = 3
		self.range = 1
		self.melee = True

		self.upgrades['control'] = (1, 1, "Controlled Appetite", "Instead of killing the target, only steal as much HP as you are missing, leaving the target with at least 1 HP")
		self.upgrades[('heal_allies', 'radius')] = ([1, 2], 2, "Mass Feeding", "Also heals your other allies within [{radius}:radius] tiles of the target")
		self.upgrades['demon'] = (1, 2, "Demonic Appetite", "Devour Flesh can target [Demon:demon] allies", [Tags.Chaos])
		self.upgrades['absorption'] = (1, 5, "Resistance Absorption", "Gain resistance to the target's most resisted damage type equal to their resistance\nLasts until the end of the level")

	def get_description(self):
		return "Devour an allied [Living] unit to heal yourself for its current HP"

	def can_cast(self, x, y):
		unit = self.owner.level.get_unit_at(x, y)
		if not unit: return False
		if are_hostile(unit, self.caster): return False
		if not ((Tags.Living in unit.tags) or (self.get_stat('demon') and Tags.Demon in unit.tags)): return False
		return Spell.can_cast(self, x, y)

	def cast_instant(self, x, y):
		caster = self.caster
		level = caster.level

		u = level.get_unit_at(x, y)
		if not u: return False

		hp_taken = 0

		if self.get_stat('absorption'):
			highest_resists = []
			highest_val = 0
			for entry in u.resists.items():
				dtype, val = entry
				if dtype == Tags.Heal: continue # don't steal resistance to healing
				if val <= 0: continue # don't steal negative resists
				if val > highest_val: highest_resists = [entry]; highest_val = val
				elif val == highest_val: highest_resists.append(entry)
				else: continue
			if highest_resists:
				dtype, val = random.choice(highest_resists)
				caster.apply_buff(ResistBuff(dtype, val))

		if self.get_stat('control'):
			hp_taken = min(caster.max_hp - caster.cur_hp, u.cur_hp - 1)
			if hp_taken:
				u.cur_hp -= hp_taken
				caster.heal(hp_taken, self)

		else:
			hp_taken = u.cur_hp
			caster.heal(hp_taken, self)
			level.show_effect(u.x, u.y, Tags.Physical)
			u.kill()

		if self.get_stat('heal_allies'):
			elligible_units = [unit for unit in level.get_units_in_ball(Point(x, y), self.get_stat('radius')) if are_friendly(caster, unit) and unit != caster and unit != u]
			for unit in elligible_units: unit.heal(hp_taken, self)

class Bloodshift(Spell):

	def on_init(self):
		self.name = "Bloodshift"
		self.level = 3
		self.tags = [Tags.Blood, Tags.Dark, Tags.Sorcery]
		self.damage_type = [Tags.Dark]
		self.damage = 18
		self.range = 5
		self.radius = 4
		self.max_charges = 6
		self.hp_cost = 8

		self.upgrades[('freeze', 'duration')] = ([1, 3], 2, "Blood Freeze", "Affected enemies are [frozen] for [{duration}:duration] turns", [Tags.Ice])
		self.upgrades['toxicity'] = (1, 5, "Toxic Shift", "Bloodshift also deals [Poison] damage", None, [Tags.Poison])
		self.upgrades['greed'] = (1, 3, "Blood Greed", "You and only you are healed by this spell, even if you are out of the targeted area")
		self.upgrades['boil'] = (1, 4, "Boiling Bloodshift", "Allies in the affected area receive a buff to their damage, as though you had cast Boiling Blood", [Tags.Fire])


	def get_description(self):
		return ("Enemies in a [{radius}:radius] tile burst take [{damage}:damage] [Dark] damage\n"
				"Damage dealt this way heals you or a wounded ally in the targeted area for half that amount")

	def cast(self, x, y):
		target = Point(x, y)
		caster = self.caster
		level = caster.level
		getu = level.get_unit_at
		show_effect = level.show_effect
		deal_damage = level.deal_damage

		rad = self.get_stat('radius')
		dmg = self.get_stat('damage')

		greed = self.get_stat('greed')
		toxicity = self.get_stat('toxicity')
		freeze = self.get_stat('freeze')
		freeze_dur = self.get_stat('duration')
		boil = self.get_stat('boil')
		if boil: boil_apply = caster.get_or_make_spell(BoilingBlood).do_buff

		ally_candidates = set()
		if greed: ally_candidates = {caster}

		if boil or not greed: # need to check for allies if we can boil their blood or if we aren't being greedy
			for stage in Burst(level, target, rad, ignore_walls=not self.get_stat('requires_los')):
				for point in stage:
					unit = getu(point.x, point.y)
					if not unit: continue
					if are_hostile(unit, caster): continue # looking for allies only
					if boil and unit is not caster: yield from boil_apply(unit) # boil allies if that's what we're doing
					if greed: continue # don't try to heal allies if we're being greedy
					if unit.cur_hp < unit.max_hp: ally_candidates.add(unit) # only try to heal hurt units


		ally_candidates = list(ally_candidates)

		effect_tags = [Tags.Blood]
		if toxicity: effect_tags.append(Tags.Poison)
		if freeze: effect_tags.append(Tags.Ice)

		dts = self.get_stat('damage_type')

		for stage in Burst(level, target, rad, ignore_walls=not self.get_stat('requires_los')):
			for point in stage:
				unit = getu(point.x, point.y)
				if not unit: show_effect(point.x, point.y, random.choice(effect_tags), minor=True); continue
				if are_friendly(caster, unit): continue

				dealt = 0
				if freeze: unit.apply_buff(FrozenBuff(), freeze_dur)
				for dt in dts: dealt += deal_damage(point.x, point.y, dmg, dt, self)

				heal = dealt // 2
				if not heal: continue
				if not ally_candidates: continue
				candidate = random.choice(ally_candidates)
				candidate.heal(heal, self)
				if candidate.cur_hp >= candidate.max_hp: ally_candidates.remove(candidate)

			yield

		return

	def get_impacted_tiles(self, x, y):
		return [p for stage in Burst(self.caster.level, Point(x, y), self.get_stat('radius'), ignore_walls=not self.get_stat('requires_los')) for p in stage]

class FleshFiendSpell(Spell):

	def on_init(self):
		self.name = "Flesh Fiend"
		self.tags = [Tags.Blood, Tags.Conjuration]
		self.hp_cost = 80
		self.max_charges = 4
		self.level = 5

		self.must_target_walkable = True
		self.must_target_empty = True

		ex = FleshFiend()
		self.minion_health = ex.max_hp
		self.minion_damage = ex.spells[0].damage

		self.upgrades[('belly_flop', 'minion_range')] = ([1, 5], 3, "Belly Flop", "Flesh Fiend gains a [{minion_range}:minion_range] range [{minion_damage}:minion_damage] damage leap attack on a 7 turn cooldown", None, None, {'minion_damage':25})
		self.upgrades['worm_lord'] = (1, 8, "Worm Lord", "Flesh Fiends can cast your Lumbriogenesis on a 13 turn cooldown")
		self.upgrades[('cursed', 'duration')] = ([1, 10], 3, "Cursed Flesh", "Flesh Fiends gain the [Dark] tag\nEnemies who attack them with melee attacks receive [{duration}:duration] turns of [necrosis]", [Tags.Dark])
		self.upgrades['flaming'] = (1, 4, "Flaming Fiend", "Summon a Flaming Flesh Fiend instead", [Tags.Fire])

		self.add_upgrade_tooltip("Flaming Fiend", lambda: self.make_fiend(1))


	def get_extra_examine_tooltips(self):
		return [self.make_fiend()] + self.get_upgrade_tooltips()

	def get_description(self):
		return "Summon a Flesh Fiend"

	def make_fiend(self, flaming=0):
		fiend = FlamingFleshFiend() if flaming else FleshFiend()
		if self.get_stat('belly_flop'):
			flop = LeapAttack(damage=self.get_stat("minion_damage", base=25), range=self.get_stat('minion_range'))
			flop.cool_down = 7
			fiend.spells.insert(0, flop)
		apply_minion_bonuses(self, fiend)
		if self.get_stat('worm_lord'): grant_minion_spell(Lumbriogenesis, fiend, self.caster, cool_down=13)
		if self.get_stat('cursed'):
			fiend.apply_buff(CurseRetaliation(name="Cursed Flesh", buff=NecrosisBuff, buff_dur=self.get_stat('duration'), color_tag=Tags.Dark, melee=True))
			if Tags.Dark not in fiend.tags: fiend.tags.append(Tags.Dark)
		return fiend

	def cast_instant(self, x, y):
		fiend = self.make_fiend(flaming=self.get_stat('flaming'))
		self.summon(fiend, target=Point(x, y))

class HelgateSpell(Spell):

	def on_init(self):
		self.name = "Gates of Helheim"
		self.tags = [Tags.Dark, Tags.Lightning, Tags.Conjuration]
		self.level = 8
		self.max_charges = 3

		self.num_summons = 3
		self.range = 0

		self.minion_health = 18
		self.minion_damage = 6
		self.minion_range = 8

		self.upgrades['shields'] = (20, 4, "Unassailable Gates", "The spawners have [{shields} SH:shields]")
		self.upgrades['horde'] = (1, 5, "Aelf Horde", "The spawners' summon cooldown is halved")
		self.upgrades['guards'] = (1, 6, "Gate Guards", "Summon a pair of Aelves near each gate immediately")
		self.upgrades['elite'] = (1, 5, "Elite Aelves", "The Spawners summon Aelf Lightning Artists instead")

		self.add_upgrade_tooltip("Elite Aelves", self.elite_elf)

	def get_description(self):
		return "Summon [{num_summons}:num_summons] Aelf Spawners at random locations"

	def get_extra_examine_tooltips(self):
		return [self.elf()] + self.get_upgrade_tooltips()

	def elf(self):
		unit = Elf()
		apply_minion_bonuses(self, unit)
		return unit

	def elite_elf(self):
		unit = ElfLightningLord()
		apply_minion_bonuses(self, unit)
		return unit

	def cast(self, x, y):
		elf = self.elite_elf if self.get_stat('elite') else self.elf
		guards = self.get_stat('guards')
		guard_num = 2
		num_summons = self.get_stat('num_summons')
		shields = self.get_stat('shields')
		for _ in range(num_summons):
			gate = MonsterSpawner(elf)
			if self.get_stat('horde'):
				gate.get_spell(SimpleSummon).cool_down //= 2
				gate.cool_downs[gate.get_spell(SimpleSummon)] = gate.get_spell(SimpleSummon).cool_down
			apply_minion_bonuses(self, gate)
			gate.shields += shields
			result = self.summon(gate, radius=99, sort_dist=False)
			if result:
				self.owner.level.show_path_effect(self.caster, result, [Tags.Dark, Tags.Lightning], minor=True)
				if guards:
					for _ in range(guard_num):
						self.summon(elf(), target=result)

			yield

class HordeOfHalfmen(Spell):

	def on_init(self):
		self.name = "Horde of Halfmen"

		self.tags = [Tags.Nature, Tags.Blood, Tags.Conjuration]
		self.level = 8
		self.hp_cost = 99
		self.range = 5
		self.num_summons = 3

		self.minion_health = 45
		self.minion_damage = 12
		self.minion_range = 6


		self.upgrades['party'] = (1, 5, "Pandemonium Party", "Also summon Pan")
		self.upgrades['bull'] = (1, 6, "Golden Bull", "Also summon Minos")
		self.upgrades['horses'] = (1, 4, "All the King's Horses", "Also summon [{num_summons}:num_summons] Centaurs", None, None, {'num_summons':3})
		self.upgrades[('goat', 'hp_cost')] = ([1, 66], 3, "Baphomet's Horde", "Also cast your Goatia Offering spell [{num_summons}:num_summons] times nearby", [Tags.Dark], None, {'num_summons': 3})

		self.add_upgrade_tooltip("Pandemonium Party", lambda: make_minion(self, Pan))
		self.add_upgrade_tooltip("Golden Bull", lambda: make_minion(self, GoldenBull))
		self.add_upgrade_tooltip("All the King's Horses", lambda: make_minion(self, Centaur))

	def get_description(self):
		return "Summon [{num_summons}:num_summons] Satyrs and [{num_summons}:num_summons] Minotaurs"

	def get_extra_examine_tooltips(self):
		return [make_minion(self, Satyr), make_minion(self, Minotaur)] + self.get_upgrade_tooltips()

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		unit_fns = [Satyr, Minotaur]
		if self.get_stat('horses'): unit_fns.append(Centaur)
		goat = self.get_stat('goat')
		s = caster.get_or_make_spell(GoatOffering) if goat else None

		for i in range(self.get_stat('num_summons')):
			for unit in unit_fns:
				u = make_minion(self, unit)
				monster = self.summon(u, target=Point(x, y), radius=12)
				if monster: level.show_path_effect(self.caster, monster, [Tags.Blood, Tags.Poison], minor=True)
				if goat and s: level.act_cast(caster, s, x, y, pay_costs=False)
				yield

		if self.get_stat('party'): self.summon(make_minion(self, Pan), Point(x, y), radius=12)
		if self.get_stat('bull'): self.summon(make_minion(self, GoldenBull), Point(x, y), radius=12)
		yield

class ScapeGoats(Upgrade):

	def on_init(self):
		self.name = "Scape Goats"
		self.level = 9
		self.description = "Damage that would be dealt to you is redirected toward your [Demon] allies\nAlways Active"

	def on_applied(self, owner):
		def goat_handler(amount, damage_type, source, redirect_chain):
			if amount <= 0: return None
			lvl = owner.level
			allies = owner.get_allies(tag_req=[Tags.Demon])
			if not allies: return None

			scapegoat = random.choice(allies)
			dealt = lvl.deal_redirected_damage(self, scapegoat.x, scapegoat.y, amount, damage_type, source, redirect_chain)
			if dealt: lvl.show_path_effect(owner, scapegoat, Tags.Blood, minor=True, inclusive=False)
			return dealt

		owner.grant_redirect(self, goat_handler)

	def on_unapplied(self):
		self.owner.remove_redirect(self)

class GoatOffering(Spell):

	def on_init(self):
		self.name = "Goatia Offering"
		self.tags = [Tags.Blood, Tags.Dark, Tags.Nature, Tags.Conjuration]
		self.level = 2
		self.hp_cost = 3

		self.minion_health = 17
		self.minion_damage = 5
		self.minion_range = 3
		self.minino_duration = 12

		self.upgrades['reincarnation'] = (1, 3, "Reincarnation", "The Goatia reincarnates once upon death")
		self.upgrades['pain'] = (1, 3, "Pain Aura", "The Goatia deals [{minion_damage}:minion_damage] [Dark] damage to enemies that damage it", None, None, {'minion_damage':5})
		self.upgrades[('maggot_host', 'num_summons')] = ([1, 2], 2, "Maggot Host", "On death, the Goatia summons [{num_summons}:num_summons] Mind Maggots")
		self.add_upgrade(ScapeGoats())

		self.add_upgrade_tooltip("Maggot Host", lambda: make_minion(self, MindMaggot))

	def gotia(self):
		unit = GoatHead()

		if self.get_stat('reincarnation'):
			unit.buffs.append(ReincarnationBuff(1))
		if self.get_stat('pain'):
			unit.buffs.append(RetaliationBuff(self.get_stat('minion_damage'), Tags.Dark))
		if self.get_stat('maggot_host'):
			unit.buffs.append(SpawnOnDeath(MindMaggot, self.get_stat('num_summons')))

		apply_minion_bonuses(self, unit)

		return unit

	def cast(self, x, y):
		unit = self.gotia()
		self.summon(unit, target=Point(x, y))
		yield

	def get_extra_examine_tooltips(self):
		return [self.gotia()] + self.get_upgrade_tooltips()

	def get_description(self):
		return "Summon a Goatia"


class BurningHungerBuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)
		self.counter = 0
		self.counter_max = 500
		self.name = "Burning Hunger"
		self.bone_explosion = self.spell.get_stat('bone_explosion')
		self.glutton = self.spell.get_stat('glutton')
		self.hunger = self.spell.get_stat('hunger')
		self.tyrant = self.spell.get_stat('tyrant')
		self.damage = self.spell.get_stat('minion_damage')
		self.radius = self.spell.get_stat('radius')
		self.num_targets = self.spell.get_stat('num_targets') if self.glutton else 1

	def get_description(self):
		kw = 'unit' if self.hunger else 'ally'
		if self.glutton:
			kw = 'units' if self.hunger else 'allies'
			desc = [('Consumes the {num} lowest HP {kw} each turn, dealing [{damage}:minion_damage] [Fire] damage to enemies within [{radius}:radius] tiles', {'num':self.num_targets, 'kw':kw, 'damage':self.damage, 'radius':self.radius})]
		else:
			desc = [('Consumes the lowest HP {kw} each turn, dealing [{damage}:minion_damage] [Fire] damage to enemies within [{radius}:radius] tiles', {'kw':kw, 'damage':self.damage, 'radius':self.radius})]
		if self.bone_explosion: desc.append("\nAlso deals [Physical] damage equal to half the sacrificed unit's max HP")
		desc.append(('\nAllies in the explosion are healed instead', {'radius':self.radius, 'damage':self.damage}))
		if self.tyrant: desc.append(('\nSacrificed: {counter} / {max}', {'counter':self.counter, 'max':self.counter_max}))
		return desc

	def on_advance(self):
		owner = self.owner
		level = owner.level
		allies = []
		enemies = []

		for u in level.units:
			if not are_hostile(u, owner): allies.append(u)
			else: enemies.append(u)

		if not enemies: return # early out if no enemies, don't keep killing allies for nothing
		units = allies + enemies if self.hunger else allies
		random.shuffle(units)
		units.sort(key=lambda u: u.cur_hp)

		for target in units[:self.num_targets]:
			level.show_path_effect(owner, target, Tags.Dark, minor=True)
			bone_dmg = target.max_hp // 2
			if self.tyrant: self.counter += target.max_hp
			target.kill()
			level.show_effect(target.x, target.y, Tags.Fire)

			for p in level.get_points_in_ball(target.x, target.y, self.radius):
				u = level.get_unit_at(p.x, p.y)
				if not u: level.show_effect(p.x, p.y, Tags.Fire, minor=True); continue # aoe fire effect
				if are_friendly(owner, u): u.heal(self.damage, self); continue
				u.deal_damage(self.damage, Tags.Fire, self)
				if self.bone_explosion: u.deal_damage(bone_dmg, Tags.Physical, self)

			if self.tyrant and self.counter >= self.counter_max:
				self.counter = 0
				self.spell.summon(self.spell.make_tyrant(), target=target)


class BurningIdolSpell(Spell):

	def on_init(self):
		self.name = "Burning Idol"
		self.tags = [Tags.Fire, Tags.Conjuration, Tags.Metallic, Tags.Dark]
		self.level = 4
		self.max_charges = 2
		self.radius = 3
		self.minion_health = 100
		self.minion_damage = 20
		self.must_target_empty = True
		self.must_target_walkable = True

		self.upgrades['bone_explosion'] = (1, 3, "Bone Explosion", "The idol's explosion also deals [Physical] damage equal to half of the sacrificed unit's max HP")
		self.upgrades[('glutton', 'num_targets')] = ([1, 2], 2, "Gluttonous Sacrifice", "Consumes the [{num_targets}:num_targets] lowest HP allies instead of just one")
		self.upgrades['hunger'] = (1, 5, "Indiscriminate Hunger", "The Idol of Burning Sacrifice will instead consume the lowest HP unit each turn, regardless of their alignment")
		self.upgrades[('tyrant', 'minion_duration')] = ([1, 25], 6, "Sufficient Sacrifice", "After sacrificing 500 HP worth of units, summon a temporary Gilded Tyrant near the sacrificed unit", [Tags.Holy])

		self.add_upgrade_tooltip("Sufficient Sacrifice", self.make_tyrant)

	def get_impacted_tiles(self, x, y):
		return [Point(x, y)]

	def get_description(self):
		return ("Summon an Idol of Burning Sacrifice\n"
			    "Each turn, the idol consumes its lowest HP ally, dealing [{minion_damage}:minion_damage] [Fire] damage to enemies and healing allies in a [{radius}:radius] tile burst around the sacrificed unit\n"
			    "The idol and the Wizard are both legal sacrifices")

	def make_idol(self):
		unit = Idol()
		unit.max_hp = 100
		unit.shields = 0
		unit.name = "Idol of Burning Sacrifice"
		unit.asset_name = 'burning_idol'
		unit.buffs.append(BurningHungerBuff(self))
		apply_minion_bonuses(self, unit)
		unit.turns_to_death = None # cancel out gilded tyrant minion dur if spell has it
		return unit

	def make_tyrant(self):
		u = GildedTyrant()
		apply_minion_bonuses(self, u)
		return u

	def cast_instant(self, x, y):
		self.summon(self.make_idol(), target=Point(x, y))

	def get_extra_examine_tooltips(self):
		return [self.make_idol()] + self.get_upgrade_tooltips()

class DrainPulse(Spell):

	def on_init(self):
		self.tags = [Tags.Dark, Tags.Blood, Tags.Sorcery]
		self.damage = 16
		self.max_charges = 3
		self.level = 4
		self.radius = 5
		self.range = 0
		self.hp_cost = 8
		self.name = "Drain Pulse"

		self.afflictions = [BleedBuff, NecrosisBuff, Poison]

		self.upgrades[('sickening', 'duration')] = ([1, 4], 2, "Sickening Pulse", "Drain Pulse also inflicts [{duration}:duration] turns of [bleed], [necrosis], and [poison]")
		self.upgrades['radius'] = (3, 4, "World Drain")
		self.upgrades['desperation'] = (1, 5, "Desperation", "Damage is increased by 1 for every 10 HP you are missing")
		self.upgrades[('felomancy', 'minion_health', 'minion_damage')] = ([1, 10, 3], 3, "Felomancy", "Slain units are raised as Breathstealers", [Tags.Conjuration])

		self.add_upgrade_tooltip("Felomancy", self.make_cat)


	def get_description(self):
		return ("Deal [{damage}:damage] [Dark] and [Poison] damage in a [{radius} tile:radius] burst\n"
				"Heal for half the damage dealt")


	def get_impacted_tiles(self, x, y):
		radius = self.get_stat('radius')
		return [p for stage in Burst(self.caster.level, Point(x, y), radius, ignore_walls=not self.get_stat('requires_los')) for p in stage]

	def cast(self, x, y):
		dmg = 0
		damage = self.get_stat('damage')
		if self.get_stat('desperation'): damage += (self.caster.max_hp - self.caster.cur_hp) // 10
		sickening = self.get_stat('sickening')
		dur = self.get_stat('duration')

		kills = []
		level = self.caster.level

		for stage in Burst(level, Point(x, y), self.get_stat('radius'), ignore_walls=not self.get_stat('requires_los')):
			for point in stage:
				if point == Point(x, y): continue
				unit = level.get_unit_at(*point)
				dmg += level.deal_damage(point.x, point.y, damage, Tags.Dark, self)
				if unit and not unit.is_alive(): kills.append(unit)
			yield

		back_burst_stages = reversed([s for s in Burst(level, Point(x, y), self.get_stat('radius'), ignore_walls=not self.get_stat('requires_los'))])

		for stage in back_burst_stages:
			for point in stage:
				if point == Point(x, y): continue
				unit = level.get_unit_at(*point)
				dmg += level.deal_damage(point.x, point.y, damage, Tags.Poison, self)
				if unit:
					if not unit.is_alive(): kills.append(unit)
					elif sickening:
						for b in self.afflictions: unit.apply_buff(b(), dur)
			yield

		if dmg > 1: self.caster.heal((dmg // 2), self)

		if self.get_stat('felomancy') and kills: level.queue_spell(self.summon_cats(kills))

	def summon_cats(self, targets):
		for target in targets: self.summon(self.make_cat(), target=target)
		yield

	def make_cat(self):
		u = BreathStealer()
		apply_minion_bonuses(self, u)
		return u

class SummonWizard(Spell):

	def on_init(self):
		self.name = "Summon Wizard"
		self.tags = [Tags.Conjuration, Tags.Arcane]
		self.level = 8
		self.max_charges = 1
		self.must_target_empty = True
		self.must_target_walkable = True

		self.upgrades[('wizard_army', 'num_summons')] = ([1, 3], 9, "Wizard Gang", "Summon [{num_summons}:num_summons] wizards instead of one")
		self.upgrades[('jealousy', 'num_targets')] = ([1, 2], 5, "Jealousy", "When you cast this spell, up to [{num_targets}:num_targets] enemy wizards in line of sight of the summoned wizard become your allies")
		self.upgrades['dragon_wizard'] = (1, 3, "Dragon Wizard", "Always summon the Dragon Wizard", [Tags.Dragon])
		self.upgrades[('requires_los', 'range')] = ([-1, 99], 2, "Global Summoning")

		self.add_upgrade_tooltip("Dragon Wizard", self.make_dragon_wizard)

	def get_description(self):
		return "Summons a random wizard"

	def make_dragon_wizard(self):
		u = DragonMage()
		apply_minion_bonuses(self, u)
		return u

	def cast_instant(self, x, y):
		import RareMonsters  # GROSS\nBut neccecary.

		number_summoned = 1 if not self.get_stat('wizard_army') else self.get_stat('num_summons')

		for i in range(number_summoned):
			wizard = random.choice(RareMonsters.WIZARDS)[0]()
			if self.get_stat('dragon_wizard'):
				wizard = DragonMage()


			apply_minion_bonuses(self, wizard)

			self.summon(wizard, target=Point(x, y))

			if self.get_stat('jealousy'):
				wizards = [u for u in self.caster.level.get_units_in_los(Point(x, y)) if hasattr(u, 'is_wizard') and u.is_wizard and are_hostile(u, self.caster)]
				if wizards:
					random.shuffle(wizards)
					targets = wizards[:self.get_stat('num_targets')]
					for target in targets:
						target.team = self.caster.team
						self.caster.level.show_effect(target.x, target.y, Tags.Arcane)

class RedRiderSeal(Buff):

	def on_init(self):
		self.name = "Red Rider's Seal"
		self.color = Tags.Fire.color
		self.buff_type = BUFF_TYPE_PASSIVE

	def on_advance(self):
		options = [u for u in self.owner.level.get_units_by_distance(self.owner, enemy=True) if not u.has_buff(BerserkBuff)]
		if not options: return
		options[0].apply_buff(BerserkBuff())
		self.owner.level.show_path_effect(self.owner, options[0], Tags.Blood)

class BlackRiderSeal(Buff):

	def on_init(self):
		self.name = "Black Rider's Seal"
		self.color = Tags.Dark.color
		self.buff_type = BUFF_TYPE_PASSIVE
		self.global_triggers[EventOnUnitAdded] = self.on_unit_added

	def on_unit_added(self, evt):
		u = evt.unit
		if are_hostile(u, self.owner) and u.cur_hp > 1: u.cur_hp //= 2 # don't instagib 1hp enemies

class SummonRider(Spell):

	def on_init(self):
		self.name = "Summon Rider"
		self.tags = [Tags.Conjuration, Tags.Dark, Tags.Holy, Tags.Word]
		self.level = 9
		self.max_charges = 1
		self.must_target_empty = True
		self.must_target_walkable = True
		self.target_empty = True

		self.minion_health = 374
		self.minion_damage = 7
		self.minion_range = 9

		self.upgrades['entourage'] = (1, 9, "Four Horsemen", "Summon all four Horsemen instead of just one")
		self.upgrades[('peal', 'duration')] = ([1, 3], 7, "Peal of Thunder", "All enemies are [stunned] for [{duration}:duration] turns when you cast this spell")
		self.upgrades['white'] = (1, 3, "White Rider's Seal", "The White Rider can cast your Dominate with no cooldown")
		self.upgrades[('red', 'duration')] = ([1, 3], 3, "Red Rider's Seal", "The Red Rider [berserks] the nearest enemy for [{duration}:duration] turns at the end of each of their turns")
		self.upgrades['black'] = (1, 3, "Black Rider's Seal", "The Black Rider halves the HP of newly summoned enemies")
		self.upgrades['pale'] = (1, 3, "Pale Rider's Seal", "The Pale Rider cannot be killed by damage while the wizard lives")

	def get_description(self):
		if self.get_stat('entourage'): return "Summon the four Horsemen"
		if self.caster: return ("Summon the [{rider}:demon]", {'rider':self.get_rider()().name})
		return "Summon one of the four Horsemen"

	def get_rider(self):
		riders = self.get_riders()
		return riders[(self.caster.level.turn_no - 1) % len(riders)]

	def get_riders(self):
		import RareMonsters as r
		return r.horsemen

	def get_extra_examine_tooltips(self):
		units = [self.make_rider(u) for u in self.get_riders()]
		return units + self.get_upgrade_tooltips()

	def make_rider(self, fn):
		import RareMonsters as r
		u = make_minion(self, fn)
		if fn is r.WhiteRider and self.get_stat('white'): grant_minion_spell(Dominate, u, self.caster, cool_down=0)
		if fn is r.RedRider and self.get_stat('red'): u.apply_buff(RedRiderSeal())
		if fn is r.BlackRider and self.get_stat('black'): u.apply_buff(BlackRiderSeal())
		if fn is r.PaleRider and self.get_stat('pale'): u.apply_buff(Soulbound(self.caster))
		return u

	def cast(self, x, y):
		to_spawn = self.get_riders() if self.get_stat('entourage') else [self.get_rider()]
		t = Point(x, y)

		for fn in to_spawn:
			u = self.make_rider(fn)
			self.summon(u, target=t)
			yield

		if self.get_stat('peal'):
			enemies = [u for u in self.caster.level.units if are_hostile(u, self.caster)]
			for e in enemies: e.apply_buff(Stun(), self.get_stat('duration'))
			yield


class BrainSeedParasiteBuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)
		self.damage = spell.get_stat('damage')
		self.forest = spell.get_stat('psychic_forest')
		self.num_summons = spell.get_stat('num_summons') if self.forest else 1


		self.asset = ['status', 'brain_seed']
		self.color = Tags.Arcane.color
		self.name = "Psychic Parasite"
		self.buff_type = BUFF_TYPE_CURSE
		self.owner_triggers[EventOnDeath] = self.on_death

	def on_advance(self):
		self.owner.deal_damage(self.damage, Tags.Arcane, self.spell)

	def get_description(self):
		desc = "Take [{damage}:damage] [Arcane] damage each turn"
		num_units = 1
		if self.forest: num_units = self.num_summons
		if num_units == 1: desc += "\nOn death, summon a Brain Tree at its location"
		else: desc += "\nOn death, summon [{num_summons}:num_summons] Brain Trees at its location"
		return (desc, {'damage': self.damage, 'num_summons': num_units})

	def on_death(self, evt):
		self.owner.level.queue_spell(self.do_summon())

	def do_summon(self):
		for i in range(self.num_summons):
			unit = self.spell.make_brain_tree()
			self.spell.summon(unit, target=self.owner)
			yield

class MindHarvester(Upgrade):

	def __init__(self, spell):
		self.spell = spell
		Upgrade.__init__(self, spell)

	def on_init(self):
		self.name = "Mind Harvester"
		self.level = 6
		self.description = "When one of your [Living] allies dies, a Brain Sapling is summoned nearby\nAlways Active"
		self.global_triggers[EventOnDeath] = self.on_death

	def on_death(self, evt):
		o = self.owner
		if are_hostile(o, evt.unit): return
		if Tags.Living not in evt.unit.tags: return
		self.spell.summon(self.spell.make_brain_sapling(), target=evt.unit)

class PsychicSeedling(Spell):

	def on_init(self):
		self.name = "Psychic Seedling"
		self.level = 3
		self.max_charges = 4
		self.tags = [Tags.Conjuration, Tags.Arcane, Tags.Nature]

		self.minion_damage = 3
		self.minion_health = 65
		self.minion_range = 7

		self.upgrades['rapid_evolution'] = (1, 4, "Rapid Evolution", "Increase the probability that a sapling will become a tree from 2% to 10%")
		self.upgrades[('parasite', 'damage', 'duration')] = ([1, 1, 25], 3, "Parasitic Growth", "May target an enemy instead of an empty tile\nTargeted enemy takes [{damage}:damage] [Arcane] damage per turn for [{duration}:duration] turns\nIf the enemy dies while under this effect, summon a Brain Tree where it died", [Tags.Enchantment], [Tags.Arcane])
		self.upgrades[('psychic_forest', 'num_summons')] = ([1, 4], 5, "Psychic Fields", "Plant [{num_summons}:num_summons] saplings instead of one")
		self.add_upgrade(MindHarvester(self))

		self.add_upgrade_tooltip("Parasitic Growth", self.get_parasite_buff)

	def get_description(self):
		return "Plant a Brain Sapling\nIt will eventually mature into a forest of Brain Trees"

	def get_extra_examine_tooltips(self):
		return [self.make_brain_sapling(), self.make_brain_tree()] + self.get_upgrade_tooltips()

	def get_parasite_buff(self):
		return BrainSeedParasiteBuff(self)

	def get_ai_target(self):
		caster = self.caster
		lvl = caster.level
		r = self.get_stat('range')
		if not self.get_stat('parasite'): # cast anywhere if it's just regular summon
			candidates = list(lvl.get_points_in_ball(caster.x, caster.y, r)) # grab points in range
			random.shuffle(candidates) # shuffle em up
			return next((p for p in candidates if self.can_cast(p.x, p.y)), None) # call can_cast as few times as we need to

		good_units = []
		for u in lvl.units: # look at units in the level
			if are_friendly(u, caster): continue
			if abs(u.x - caster.x) > r + u.radius + caster.radius or abs(u.y - caster.y) > r + u.radius + caster.radius: continue
			if u.has_buff(BrainSeedParasiteBuff): continue
			if getattr(self, 'damage_type', None) and not self.can_harm(u): continue
			good_units.append(u)

		random.shuffle(good_units)
		for u in good_units:
			pts = list(u.iter_occupied_points()) if u.radius else [Point(u.x, u.y)]
			random.shuffle(pts)
			candidate = next((p for p in pts if self.can_cast(p.x, p.y)), None)
			if candidate: return candidate

		return None

	def can_cast(self, x, y):
		unit = self.owner.level.get_unit_at(x, y)
		can_cast = Spell.can_cast(self, x, y)
		if not can_cast: return False
		if not unit: return True
		return bool(self.get_stat('parasite'))

	def cast_instant(self, x, y):

		target = self.owner.level.get_unit_at(x, y)
		if target and self.get_stat('parasite'):
			target.apply_buff(BrainSeedParasiteBuff(self), self.get_stat('duration'))
			return

		num_units = 1
		if self.get_stat('psychic_forest'): num_units = self.get_stat('num_summons')

		for i in range(num_units):
			unit = self.make_brain_sapling()
			self.summon(unit, target=(Point(x, y)))

	def make_brain_sapling(self):
		u = BrainSapling()
		b = u.get_buff(ChanceToBecome)
		b.spawner = self.make_brain_tree
		if self.get_stat('rapid_evolution'): b.chance *= 5
		apply_minion_bonuses(self, u)
		return u

	def make_brain_tree(self):
		u = BrainTree()
		b = u.get_buff(GeneratorBuff)
		b.spawner = self.make_brain_sapling
		apply_minion_bonuses(self, u)
		return u

class SoulWindSpell(Spell):

	def on_init(self):
		self.tags = [Tags.Blood, Tags.Holy, Tags.Dark, Tags.Sorcery, Tags.Conjuration]
		self.hp_cost = 100
		self.requires_los = False
		self.range = RANGE_GLOBAL
		self.max_charges = 0
		self.level = 7
		self.damage = 44
		self.minion_health = 4
		self.minion_damage = 1
		self.name = "Soul Wind"
		self.damage_type = [Tags.Dark, Tags.Holy]

		self.holy_dealers = [Tags.Undead, Tags.Demon, Tags.Dark]

		self.upgrades[('share', 'duration')] = ([1, 9], 9, "Shared Soul", "Enemies that share a name with a unit slain by Soul Wind are afflicted with Shared Pain for [{duration}:duration] turns")
		self.upgrades['death'] = (1, 6, "Soul Death", "Summon Death instead of a Ghost")
		self.upgrades['arcane'] = (1, 4, "Arcane Wind", "Soul Wind also deals [Arcane] damage", [Tags.Arcane], [Tags.Arcane])
		self.upgrades['mirror'] = (1, 3, "Dual Wind", "Soul Wind also affects a symmetric area behind the caster")

		self.add_upgrade_tooltip('Soul Death', self.make_death)
		self.add_upgrade_tooltip('Shared Soul', SharedPainBuff)

	def get_description(self):
		return ("Deal [{damage}:damage] [Dark] damage in a 3 tile wide line perpendicular to the caster\n"
			   "[Undead], [Dark], and [Demon] units in the area take [Holy] damage instead of [Dark]\n"
			   "Summon a Ghost near each [Living] unit in the affected area")

	def get_impacted_tiles(self, x, y):
		line = self.caster.level.get_perpendicular_line(self.caster, Point(x, y))
		result = set()
		for p in line:
			for q in self.caster.level.get_points_in_rect(p.x-1, p.y-1, p.x+1, p.y+1):
				result.add(q)
		if self.get_stat('mirror'):
			mirrored_line = self.caster.level.get_perpendicular_line(self.caster, Point(2*self.caster.x-x, 2*self.caster.y-y))
			for p in mirrored_line:
				for q in self.caster.level.get_points_in_rect(p.x-1, p.y-1, p.x+1, p.y+1):
					result.add(q)
		return result

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		getu = level.get_unit_at
		summon_targets = set()
		dealdmg = level.deal_damage
		damage = self.get_stat('damage')

		arcane = self.get_stat('arcane')
		dtypes = self.get_stat('damage_type')
		share = self.get_stat('share')
		share_kills = set()

		for p in self.get_impacted_tiles(x, y):
			unit = getu(p.x, p.y)
			if unit is not None:
				if unit.has_tags(self.holy_dealers): dtype = Tags.Holy
				else: dtype = Tags.Dark
				dealdmg(p.x, p.y, damage, dtype, self)
				if arcane: dealdmg(p.x, p.y, damage, Tags.Arcane, self)
				if Tags.Living in unit.tags: summon_targets.add(Point(unit.x, unit.y))
				if share and not unit.is_alive(): share_kills.add(unit.name)
			else:
				effect_tag = random.choice(dtypes)
				level.show_effect(p.x, p.y, effect_tag, minor=True)
			if random.random() < .4: yield

		yield

		if summon_targets:
			ghost_fn = self.make_death if self.get_stat('death') else self.make_ghost
			for target in summon_targets:
				self.summon(ghost_fn(), target=target)

		yield

		if share and share_kills:
			duration = self.get_stat('duration')
			for u in list(level.units):
				if u.name in share_kills and are_hostile(caster, u):
					u.apply_buff(SharedPainBuff(), duration)

	def make_ghost(self):
		ghost = Ghost()
		apply_minion_bonuses(self, ghost)
		return ghost

	def make_death(self):
		ghost = Death()
		apply_minion_bonuses(self, ghost)
		return ghost

	def get_extra_examine_tooltips(self):
		return [self.make_ghost()] + self.get_upgrade_tooltips()

class ElephantFormBuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)

	def on_init(self):
		self.name = "Stampede Form"
		self.resists[Tags.Physical] = 50
		self.allowed_tags = [Tags.Nature]

		self.metallic = self.spell.get_stat('ironhide')
		self.tag_added = False
		if self.metallic:
			self.allowed_tags.append(Tags.Metallic)
			for dt in [Tags.Fire, Tags.Ice, Tags.Lightning]:
				self.resists[dt] = 50

		self.loyalty = self.spell.get_stat('loyalty')
		self.turns_on = 0

		self.heavyweight = self.spell.get_stat('heavyweights')

		self.rage = self.spell.get_stat('rage')
		if self.rage:
			self.global_triggers[EventOnDeath] = self.on_death
			self.allowed_tags.append(Tags.Fire)

		self.melee_damage = self.spell.get_stat('minion_damage')

		self.transform_asset = ["char", "player_elephant"]
		self.buff_type = BUFF_TYPE_BLESS
		self.stack_type = STACK_TYPE_TRANSFORM
		self.owner_triggers[EventOnSpellCast] = self.on_spell_cast
		self.connected_targets = []

	def get_description(self):
		desc = [(("You are a Pachyderm\n"
				 "While in this form, attempting to move onto an enemy occupied tile will cause you to use a trampling melee attack\n"
				 "This attack deals [{damage}:minion_damage] damage and will move single-tile units out of the way"), {'damage':self.melee_damage})]
		if self.turns_on: desc.append(("\nLoyal Pachyderms: {num}", {'num':self.turns_on}))
		return desc

	def on_spell_cast(self, evt):
		if evt.spell == self.owner.melee_spell: return
		if not evt.pay_costs: return
		if any(t in self.allowed_tags for t in evt.spell.tags): return
		self.owner.remove_buff(self)

	def on_advance(self):
		if not self.loyalty: return
		self.turns_on += 1

	def on_applied(self, owner):
		if self.heavyweight: trample = SimpleMeleeAttack(damage=self.melee_damage, buff=Stun, buff_duration=2, trample=True)
		else: trample = SimpleMeleeAttack(damage=self.melee_damage, trample=True)
		trample.owner = self.owner
		trample.caster = self.owner
		self.owner.melee_spell = trample
		if self.metallic and Tags.Metallic not in owner.tags: owner.tags.append(Tags.Metallic); self.tag_added = True
		self.turns_on = 0

	def on_unapplied(self):
		self.owner.melee_spell = None
		to_kill = [e for e in self.connected_targets if e.is_alive()]
		if self.turns_on: to_kill = to_kill[self.turns_on:]
		for e in to_kill: self.owner.level.queue_spell(self.kill(e))
		if self.tag_added and Tags.Metallic in self.owner.tags: self.owner.tags.remove(Tags.Metallic)

	def kill(self, e):
		e.kill(trigger_death_event=False)
		self.owner.level.show_effect(e.x, e.y, Tags.Translocation)
		yield

	def on_death(self, evt):
		if evt.unit.source != self.spell: return
		o = self.owner
		o.level.act_cast(o, o.get_or_make_spell(BoilingBlood), o.x, o.y, pay_costs=False)

class StampedeFormSpell(Spell):

	def on_init(self):
		self.name = "Stampede Form"
		self.tags = [Tags.Nature, Tags.Conjuration, Tags.Enchantment]
		self.level = 3

		self.max_charges = 2
		self.duration = 12
		self.range = 0

		self.minion_damage = 12
		self.minion_health = 60
		self.num_summons = 7

		self.upgrades['ironhide'] = (1, 3, "Ironhide", "You and your Pachyderm allies gain the [Metallic] tag, along with +50% resistance to [Fire], [Ice], and [Lightning] damage\nYou may cast [Metallic] spells without ending Stampede Form", [Tags.Metallic])
		self.upgrades['loyalty'] = (1, 5, "Loyalty", "For each turn you spend in Stampede Form, one of the remaining Pachyderms is not unsummoned when the buff ends")
		self.upgrades['heavyweights'] = (1, 2, "Heavyweights", "Your and your Pachyderm allies' melee attacks inflict 2 turns of [stun]")
		self.upgrades['rage'] = (1, 4, "Enraged Stampede", "While Pachyderm Form is active, if one of your Pachyderms dies, cast Boiling Blood\nYou may cast [Fire] spells without ending Stampede Form", [Tags.Fire])

	def get_description(self):
		return ("Become a Pachyderm and summon [{num_summons}:num_summons] Pachyderms nearby\n"
				"Gain 50 [Physical] resistance\n"
				"Walking onto an enemy will move them and deal [{minion_damage}:minion_damage] [Physical] damage\n"
				"Pachyderms are unsummoned when Stampede Form ends\n"
				"Lasts [{duration}:duration] turns or until you cast a non [Nature] spell")

	def get_elephant(self):
		elephant = Elephant()
		if self.get_stat('heavyweights'): elephant.spells[0] = SimpleMeleeAttack(9, Stun, 2, trample=True)
		apply_minion_bonuses(self, elephant)
		if self.get_stat('ironhide') and Tags.Metallic not in elephant.tags:
			elephant.tags.append(Tags.Metallic)
			for dt in [Tags.Fire, Tags.Ice, Tags.Lightning]:
				elephant.resists[dt] = 50

		return elephant

	def get_extra_examine_tooltips(self):
		return [self.get_elephant()] + self.get_upgrade_tooltips()

	def cast(self, x, y):
		buff = ElephantFormBuff(self)
		self.caster.apply_buff(buff, self.get_stat('duration'))
		buff = self.caster.get_buff(ElephantFormBuff) # want to add new elephants to existing buff if we already had elephant form turned on

		for i in range(self.get_stat('num_summons')):
			elephant = self.get_elephant()
			u = self.summon(elephant)
			if u and u not in buff.connected_targets: buff.connected_targets.append(elephant)
			yield

class ChannelMalevolence(Spell):

	def on_init(self):
		self.tags = [Tags.Fire, Tags.Dark, Tags.Sorcery]
		self.level = 8
		self.max_charges = 3
		self.num_targets = 4
		self.max_channel = 5
		self.damage = 30
		self.name = "Hatebolts"
		self.range = 0
		self.requires_los = False

		self.damage_type = [Tags.Fire, Tags.Dark]

		self.upgrades['returning'] = (1, 3, "Boomerang Bolts", "The bolts return after they reach their target, dealing damage a second time")
		self.upgrades[('toxic', 'duration')] = ([1, 13], 2, "Toxic Hatred", "Affected units are also [poisoned] for [{duration}:duration] turns", [Tags.Nature])
		self.upgrades[('cold', 'num_targets')] = ([1, 2], 4, "Cold Fury", "Hatebolts can also deal [Ice] damage\nIt also deals you an additional 1 [Ice] damage per remaining enemy when you stop channeling", [Tags.Ice], [Tags.Ice])
		self.upgrades['ritual', 'max_channel'] = ([1, 5], 8, "Ritual of Malevolence", "If you complete the ritual, permanently increase either your [Fire] or [Dark] resistance by 10%", [Tags.Ritual])

	def get_description(self):
		return ("Unleash seeking bolts toward up to [{num_targets}:num_targets] random enemies each turn, dealing [{damage}:damage] [Fire] or [Dark] damage to units on the path\n"
				"Can be channeled for up to [{max_channel}:max_channel] turns\n"
				"When you stop channeling this spell, it deals you 1 [Fire] and [Dark] damage for each remaining enemy")

	def cast(self, x, y, channel_cast=False):

		if not channel_cast and self.is_manual_cast():
			self.caster.apply_buff(ChannelBuff(self.cast, Point(x, y), on_stop=self.on_stop), self.get_stat('max_channel'))
			return

		caster = self.caster
		level = caster.level
		findpath = level.find_path

		targets = [u for u in level.units if are_hostile(caster, u)]
		random.shuffle(targets)
		wisps_left = self.get_stat('num_targets')
		wisps = []

		returning = self.get_stat('returning')

		damage_types = self.get_stat('damage_type')
		random.shuffle(damage_types)
		i = 0
		imax = len(damage_types)

		while wisps_left and targets:
			target = targets.pop()
			path = findpath(caster, target, flying_path_probe, cosmetic=True, pythonize=True, unit_penalty=0)
			if not path: continue
			if returning: ret_path = path[:-1]; ret_path.reverse(); path = path + ret_path
			else: path.reverse()

			dtype = damage_types[i]
			i = (i + 1) % imax

			wisps.append((path, dtype))
			wisps_left -= 1

		getu = level.get_unit_at
		deal_damage = level.deal_damage

		toxic = self.get_stat('toxic')
		duration = self.get_stat('duration')

		damage = self.get_stat('damage')

		while any(wisp[0] for wisp in wisps):
			for path, dtype in wisps:
				if not path: continue
				p = path.pop()
				unit = getu(p.x, p.y)
				deal_damage(p.x, p.y, damage, dtype, self)
				if unit and toxic: unit.apply_buff(Poison(), duration)
			yield

		if self.get_stat('ritual') and channel_cast and not caster.has_buff(ChannelBuff): # final turn
			dtype = random.choice([Tags.Fire, Tags.Dark])
			caster.resists[dtype] += 10

	def on_stop(self):
		self.owner.level.queue_spell(self.revenge())

	def revenge(self):
		dtypes = self.get_stat('damage_type')
		caster = self.caster
		show_path = caster.level.show_path_effect
		for u in self.owner.level.units:
			if not are_hostile(caster, u): continue
			show_path(u, caster, dtypes, minor=True, inclusive=False)
			for dt in dtypes: self.owner.deal_damage(1, dt, self)
			yield

class IonTentaclesBuff(Buff):

	def __init__(self, spell):
			self.spell = spell
			Buff.__init__(self)

	def on_init(self):
			self.name = "Ion Tentacles"
			self.color = Tags.Arcane.color
			self.buff_type = BUFF_TYPE_BLESS
			self.stack_type = STACK_REPLACE

			self.base_num_targets = self.spell.get_stat('num_targets')

			if self.spell.get_stat('bloody_tendrils'): self.global_triggers[EventOnDamaged] = self.on_damaged
			self.num_known_eyes = 0
			if self.spell.get_stat('cthulhu'): self.num_known_eyes = len([s for s in self.spell.owner.spells if Tags.Eye in s.tags]) * 2

			self.smart = self.spell.get_stat('smart')

			self.growing_power = self.spell.get_stat('growing_power')
			self.growing_damage = self.spell.get_stat('damage', base=1)

			self.damage = self.spell.get_stat('damage')

			self.total_duration = 0
			self.last_turns_left = 0

	def on_applied(self, owner):
			self.total_duration = self.turns_left
			self.last_turns_left = self.turns_left

	def sync_duration(self):
			if self.turns_left > self.last_turns_left: self.total_duration += self.turns_left - self.last_turns_left
			self.last_turns_left = self.turns_left

	def get_charge(self):
			self.sync_duration()
			elapsed = self.total_duration - self.turns_left
			return max(0, min(elapsed, self.total_duration - elapsed))

	def on_advance(self):
			charge = self.get_charge()
			self.owner.level.queue_spell(self.do_effect(charge))

	def get_description(self):
			charge = self.get_charge()
			num_targets = self.base_num_targets  + charge + self.num_known_eyes
			damage = self.damage
			if self.growing_power: damage += charge * self.growing_damage
			return ("Deal [{damage}:damage] [Arcane] or [Lightning] damage to the nearest [{num_targets}:num_targets] enemies each turn", {'damage': damage, 'num_targets': num_targets})

	def do_effect(self, charge):
			enemies = self.owner.level.get_units_by_distance(self.owner, enemy=True)
			num_targets = self.base_num_targets  + charge + self.num_known_eyes
			damage = self.damage
			if self.growing_power: damage += charge * self.growing_damage
			smart = self.smart
			dtypes = [Tags.Arcane, Tags.Lightning]
			for t in enemies[:num_targets]:
					if smart:
						a_res = t.resists[Tags.Arcane]
						l_res = t.resists[Tags.Lightning]
						if a_res < l_res: dtype = Tags.Arcane
						elif l_res < a_res: dtype = Tags.Lightning
						else: dtype = random.choice(dtypes)
					else: dtype = random.choice(dtypes)
					t.deal_damage(damage, dtype, self.spell)
					self.owner.level.show_path_effect(self.owner, t, dtype, minor=True)
					yield

	def on_damaged(self, evt):
			if evt.damage <= 0: return
			if not evt.source: return
			if evt.source == self.spell: self.owner.heal(evt.damage // 2, self.spell)

class IonTentaclesSpell(Spell):

	def on_init(self):
		self.name = "Ion Tentacles"
		self.level = 8
		self.tags = [Tags.Lightning, Tags.Arcane, Tags.Enchantment]

		self.num_targets = 1
		self.damage = 7
		self.duration = 14
		self.range = 0
		self.max_charges = 1

		self.upgrades['growing_power'] = (1, 8, "Growing Power", "Ion Tentacles' damage increases by [{damage}:damage] each turn for the first half of the duration, then decreases by [{damage}:damage] each turn for the second half", None, None, {'damage':1})
		self.upgrades[('hp_cost', 'bloody_tendrils')] = ([25, 1], 5, "Bloody Tendrils", "Ion Tentacles heals you for 50% of the damage it deals", [Tags.Blood])
		self.upgrades['smart'] = (1, 3, "Coordination", "Tentacles deal the damage type their target is least resistant to between [Arcane] and [Lightning]")
		self.upgrades['cthulhu'] = (1, 4, "Cthulhu Form", "Increase the starting number of targets by 2 for each [Eye] spell you know", [Tags.Eye])

	def get_description(self):
		return ("Deal [{damage}:damage] [Arcane] or [Lightning] damage to the nearest [{num_targets}:num_targets] enemies each turn\n"
			    "For the first half of the duration the number of tentacles increases by 1 each turn, then decreases by 1 each turn for the second half\n"
			    "Lasts [{duration}:duration] turns")

	def get_ion_tentacles_buff(self):
		return IonTentaclesBuff(self)

	def get_extra_examine_tooltips(self):
		return [self.get_ion_tentacles_buff()] + self.get_upgrade_tooltips()

	def cast_instant(self, x, y):
		self.caster.apply_buff(self.get_ion_tentacles_buff(), self.get_stat('duration'))

class WaveOfDread(Spell):

	def on_init(self):
		self.name = "Wave of Dread"
		self.damage = 22
		self.max_charges = 5
		self.duration = 5
		self.tags = [Tags.Sorcery, Tags.Dark]
		self.damage_type =[Tags.Dark]
		self.level = 3
		self.range = 5
		self.angle = math.pi / 6.0

		self.upgrades['poison'] = (1, 4, "Wilting Wave", "Wave of Dread also deals [Poison] damage and inflicts [{duration}:duration] turns of [poison]", [Tags.Nature], [Tags.Poison], {'duration':5})
		self.upgrades[('domination', 'range')] = ([1, 2], 5, "Wave of Tyranny", "If Wave of Dread deals more than half of the target's max HP, they join your team")
		self.upgrades[('ritual', 'max_channel')] = ([1, 3], 4, "Ritual of Gnawing Dread", "Wave of Dread can be channeled for up to [{max_channel}:max_channel] turns"
																							"\nIf the ritual is completed, enemies with [fear] are afflicted with permanent [necrosis]", [Tags.Ritual])
		self.upgrades[('fearfaces', 'minion_duration', 'minion_health', 'minion_damage')] = ([1, 12, 1, 2], 6, "Fear Spirits", "On killing a unit, summon a temporary Fearface", [Tags.Conjuration])

		self.add_upgrade_tooltip("Fear Spirits", self.make_fearface)

	def get_description(self):
		return "Inflict [{damage}:damage] [Dark] damage and [{duration}:duration] turns of [fear] to units in a cone"

	def aoe(self, x, y):
		target = Point(x, y)
		return Burst(self.caster.level,
				     Point(self.caster.x, self.caster.y),
				     self.get_stat('range'),
				     burst_cone_params=BurstConeParams(target, self.angle),
				     ignore_walls=self.get_stat('melt_walls') or not self.get_stat('requires_los'))

	def cast(self, x, y, channel_cast=False):
		caster = self.caster
		ritual = self.get_stat('ritual')

		if ritual and not channel_cast and self.is_manual_cast():
			caster.apply_buff(ChannelBuff(self.cast, Point(x, y)), self.get_stat('max_channel'))
			return

		level = caster.level
		dmg = self.get_stat('damage')
		dur = self.get_stat('duration')

		poison = self.get_stat('poison')
		fearfaces = self.get_stat('fearfaces')
		domination = self.get_stat('domination')

		for stage in self.aoe(x, y):
			for point in stage:
				if point.x == caster.x and point.y == caster.y: continue
				damage_dealt = 0
				unit = level.get_unit_at(point.x, point.y)
				damage_dealt +=	level.deal_damage(point.x, point.y, dmg, Tags.Dark, self)
				if poison: damage_dealt += level.deal_damage(point.x, point.y, dmg, Tags.Poison, self)
				if unit:
					if unit.is_alive():
						unit.apply_buff(FearBuff(), dur)
						if poison: unit.apply_buff(Poison(), dur)
						if domination and damage_dealt > unit.max_hp // 2: unit.team = caster.team
					elif fearfaces: self.summon(self.make_fearface(), target=point)
			yield

		if ritual and channel_cast and not caster.has_buff(ChannelBuff):
			for target in caster.get_hostiles():
				if target.has_buff(FearBuff): target.apply_buff(NecrosisBuff())


	def make_fearface(self):
		u = Fearface()
		u.turns_to_death = self.get_stat('minion_duration', base=6)
		apply_minion_bonuses(self, u)
		return u


	def get_impacted_tiles(self, x, y):
		return [p for stage in self.aoe(x, y) for p in stage]

class LivingRainBuff(Upgrade):

	def __init__(self, spell):
		self.spell = spell
		Upgrade.__init__(self, spell)

	def on_init(self):
		self.name = "Living Rain"
		self.level = 4
		self.num_summons = 2
		self.new_attributes = {'num_summons':2, 'minion_health':40, 'minion_damage':9}
		self.added_tags = [Tags.Conjuration]
		self.tags = [Tags.Nature, Tags.Enchantment, Tags.Conjuration]

	def on_advance(self):
		eligible_clouds = [t.cloud for t in self.owner.level.iter_tiles() if t.cloud and isinstance(t.cloud, RainCloud)]
		if not eligible_clouds: return

		for i in range(self.spell.get_stat('num_summons')):
			target = random.choice(eligible_clouds)
			unit = self.spell.make_water_elemental()
			self.summon(unit, target=target)

	def get_description(self):
		return ("Each turn, summon [{num_summons}:num_summons] Water Elementals from [Rain Clouds:nature] you control\nAlways Active\n"
				"Adds the [Conjuration] tag")

class RainStormSpell(Spell):

	def on_init(self):
		self.name = "Rain Storm"
		self.tags = [Tags.Nature, Tags.Enchantment]
		self.level = 2
		self.duration = 10
		self.radius = 4
		self.range = 10
		self.max_charges = 3

		self.upgrades['personal'] = (1, 2, "Personal Storms", "[Rain Clouds:nature] also appear over enemy occupied tiles")
		self.upgrades[('poison', 'damage')] = ([1, 9], 4, "Acid Rain", "The [Rain Clouds:nature] created by this spell deal [{damage}:damage] [Poison] damage each turn")
		self.upgrades['healing'] = (1, 4, "Healing Rain", "The [Rain Clouds:nature] created by this spell will heal the Wizard and their allies for 10 HP each turn")
		self.add_upgrade(LivingRainBuff(self))

		self.add_upgrade_tooltip("Living Rain", self.make_water_elemental)

	def get_description(self):
		return ("Create [Rain Clouds:nature] over tiles in a [{radius}:radius] tile radius\n"
				"Rain Clouds apply 2 turns of Soaked to units each turn\n"
				"The clouds last for [{duration}:duration] turns")

	def make_water_elemental(self):
		return make_minion(self, WaterElemental)

	def get_impacted_tiles(self, x, y):
		pts = set()
		for stage in Burst(self.caster.level, Point(x, y), self.get_stat('radius'), ignore_walls=not self.get_stat('requires_los')):
			for point in stage:
				pts.add(point)
		if self.get_stat('personal'):
			for u in self.caster.get_hostiles():
				for p in u.iter_occupied_points():
					pts.add(p)
		return list(pts)

	def make_cloud(self):
		cloud = RainCloud(self.caster, spell=self)
		cloud.duration = self.get_stat('duration')
		return cloud

	def cast(self, x, y):
		for point in self.get_impacted_tiles(x, y):
			self.owner.level.add_obj(self.make_cloud(), point.x, point.y)
			yield

class WizardReplica(Spell):

	def on_init(self):
		self.name = "Wizard Replica"
		self.max_charges = 1
		self.range = 3
		self.level = 9
		self.hp_cost = 50
		self.tags = [Tags.Arcane, Tags.Blood, Tags.Conjuration, Tags.Metallic]

		self.minion_health = 10
		self.minion_damage = 5

		self.must_target_walkable = True
		self.must_target_empty = True

		self.upgrades[('minion_health', 'minion_damage')] = ([40, 5], 1, "Sturdy Construction")
		self.upgrades['reclamation'] = (1, 2, "Blood Reclamation", "If the Wizard Replica dies, this spell regains a charge")
		self.upgrades['investiture'] = (1, 3, "Investiture", "The Wizard Replica gains up to three of your level 1 spells and can cast them on a 3 turn cooldown")
		self.upgrades['idolatry'] = (1, 4, "Wizard Colossus", "When you cast this spell, if there is room, summon a Wizard Colossus instead of a Wizard Replica\n"
		"A Wizard Colossus is a giant immobile version of the Wizard Replica, whose health and melee damage are multiplied by the number of equipment it owns")

		self.add_upgrade_tooltip("Wizard Colossus", self.Colossus)

	def get_description(self):
		return "Summon a replica of the wizard with their equipment"

	def get_extra_examine_tooltips(self):
		return [self.WizardReplica()] + self.get_upgrade_tooltips()

	def WizardReplica(self):
		unit = Unit()
		unit.tags = [Tags.Arcane, Tags.Blood, Tags.Conjuration, Tags.Construct, Tags.Living, Tags.Metallic]
		unit.name = 'Wizard Replica'
		unit.asset_name = "miniature_wizard"
		unit.max_hp = self.get_stat('minion_health')
		unit.shields = 3
		unit.spells.append(SimpleMeleeAttack(damage=self.get_stat('minion_damage')))
		return unit

	def Colossus(self):
		colossus = self.WizardReplica()
		colossus.radius = 1
		colossus.max_hp = (self.get_stat('minion_health') * max(1, len([b for b in self.caster.buffs if b.buff_type == BUFF_TYPE_ITEM])))
		colossus.spells = [SimpleMeleeAttack(damage=self.get_stat('minion_damage') * max(1, len([b for b in self.caster.buffs if b.buff_type == BUFF_TYPE_ITEM])))]
		colossus.name = "Wizard Colossus"
		colossus.stationary = True
		colossus.asset_name = "massive_wizard_statue"
		return colossus

	def colossus_if_possible(self, x, y):
		if not self.get_stat('idolatry'): return None
		colossus = self.Colossus()
		if not self.owner.level.can_stand(x, y, colossus): return None
		return colossus

	def get_impacted_tiles(self, x, y):
		colossus = self.colossus_if_possible(x, y)
		if colossus: return self.owner.level.get_points_in_ball(x, y, colossus.radius, diag=True)
		return [Point(x, y)]

	def can_cast(self, x, y):
		if not self.owner.level.can_stand(x, y, self.WizardReplica()): return False
		return Spell.can_cast(self, x, y)

	def cast(self, x, y):
		unit = self.colossus_if_possible(x, y) or self.WizardReplica()
		if self.get_stat('reclamation'): unit.buffs.append(ReclamationBuff())
		if self.get_stat('investiture'):
			cantrips = [c for c in self.caster.spells if c.level == 1]
			if len(cantrips) > 3: cantrips = cantrips[:3]
			for cantrip in reversed(cantrips): # give it your cantrips
				spell = type(cantrip) # make an instance of the spell to hand over
				grant_minion_spell(spell, unit, self.caster, cool_down=3)

		u = self.summon(unit, Point(x,y))
		if not u: return
		# equip after hitting the level to trigger on-enter effects.
		for equipment in self.caster.equipment: self.caster.grant_equipment_copy_to_minion(u, equipment)
		yield

class ReclamationBuff(Buff):

	def on_init(self):
		self.name = "Reclamation"
		self.owner_triggers[EventOnDeath] = self.on_death

	def on_death(self, _evt):
		for unit in self.owner.level.units:
			if unit.is_player_controlled:
				spell = unit.get_spell(WizardReplica)
				if spell:
					spell.refund_charges(1)
				unit.level.show_effect(unit.x, unit.y, Tags.Blood, minor=True)

class Starbask(Buff):

	def on_init(self):
		self.global_triggers[EventOnDamaged] = self.on_damage
		self.name = "Starbask"

	def on_damage(self, evt):
		if evt.damage_type != Tags.Arcane: return
		if evt.damage < 2: return
		self.owner.heal(evt.damage // 2, self)

class HungeringDepths(Upgrade):

	def __init__(self, spell):
		self.spell = spell
		Upgrade.__init__(self)

	def on_init(self):
		self.name = "Hungering Depths"
		self.level = 6
		self.description = "If an enemy dies on or adjacent to a chasm while channeling Dream the Starwhale, cast Hungry Maw at their location"
		self.global_triggers[EventOnDeath] = self.on_death

	def on_death(self, evt):
		owner = self.owner
		b = owner.get_buff(ChannelBuff)
		if not b: return
		if b.spell != self.spell.cast: return
		if not are_hostile(evt.unit, owner): return
		if any(t for t in evt.unit.level.get_tiles_in_ball(evt.unit.x, evt.unit.y, 1, diag=True) if t.is_chasm):
			owner.level.defer_cast(owner, owner.get_or_make_spell(SummonHungryMaw), evt.unit.x, evt.unit.y, pay_costs=False)

class StarwhaleDream(Spell):

	def on_init(self):
		self.name = "Dream the Starwhale"

		self.max_channel = 12

		self.max_charges = 1
		self.range = 6
		self.level = 7
		self.requires_los = False
		self.tags = [Tags.Nature, Tags.Ice, Tags.Arcane, Tags.Conjuration]

		self.whale = None
		self.channel_buff = None

		self.minion_health = 2600
		self.minion_damage = 65
		self.minion_range = 5
		self.radius = 4

		self.upgrades[('icedream', 'duration')] = ([1, 2], 5, "Ice Dream", "Starwhale's aura [freezes] affected enemies for [{duration}:duration] turns")
		self.upgrades['starbask'] = (1, 4, "Starbask", "While channeling, you and the Starwhale heal for half of any [Arcane] damage dealt")
		self.upgrades[('ritual', 'max_channel')] = ([1, 12], 7, "Ritual of Stars", "If you complete the ritual, the Starwhale is not unsummoned, and you are not [frozen]", [Tags.Ritual])
		self.add_upgrade(HungeringDepths(self))

	def get_description(self):
		return ("Summon a Starwhale\n"
				"Gain 100% [Ice] and [Arcane] resistance while channeling\n"
				"The Starwhale is unsummoned and you are [frozen] for 3 turns when you stop channeling\n"
				"Can be channeled for up to [{max_channel} turns:max_channel]")

	def get_extra_examine_tooltips(self):
		return [self.make_starwhale()] + self.get_upgrade_tooltips()

	def get_impacted_tiles(self, x, y):
		return self.owner.level.get_points_in_ball(x, y, 1, diag=True)

	def can_cast(self, x, y):
		test_whale = self.Starwhale()
		if not self.owner.level.can_stand(x, y, test_whale): return False
		return Spell.can_cast(self, x, y)

	def Starwhale(self):
		unit = Unit()
		unit.radius = 1
		unit.asset_name = "starwhale"
		unit.name = "Starwhale"

		unit.tags = [Tags.Nature, Tags.Ice, Tags.Arcane, Tags.Living]

		unit.flying = True
		unit.burrowing = True

		unit.max_hp = self.get_stat('minion_health')

		unit.resists[Tags.Ice] = 100
		unit.resists[Tags.Arcane] = 100

		aura = DamageAuraBuff(damage=self.get_stat('damage', base=5), radius=self.get_stat('radius'), damage_type=[Tags.Arcane, Tags.Ice])
		aura.name = "Ice Crystal Aura"
		if self.get_stat('icedream'):
			def apply_freeze(unit): unit.apply_buff(FrozenBuff(), self.get_stat('duration'))
			aura.on_hit = apply_freeze
		unit.buffs = [aura]

		if self.get_stat('starbask'): unit.buffs.append(Starbask())

		freezebreath = IceBreath()
		freezebreath.damage = 65
		freezebreath.cool_down = 4
		freezebreath.range = 7

		gore = SimpleMeleeAttack(damage=65, damage_type=Tags.Arcane)

		unit.spells = [freezebreath, gore]

		return unit

	def make_starwhale(self):
		u = self.Starwhale()
		apply_minion_bonuses(self, u)
		u.turns_to_death = None  # cancel out starhost making it temporary
		return u

	def cast(self, x, y, channel_cast=False):

		if not channel_cast and self.is_manual_cast():

			for t in self.get_impacted_tiles(x, y):
				if not self.owner.level.tiles[t.x][t.y].can_fly:
					self.owner.level.make_chasm(t.x, t.y)

			if self.whale: self.whale.kill(trigger_death_event=False); self.whale = None

			buff = ChannelBuff(self.cast, Point(x, y), on_stop = self.on_channel_stop)
			buff.resists[Tags.Arcane] = 100
			buff.resists[Tags.Ice] = 100
			buff.stack_type = STACK_REPLACE

			self.caster.apply_buff(buff, self.get_stat('max_channel'))
			self.channel_buff = buff
			whale = self.make_starwhale()
			self.whale = self.summon(whale, target=Point(x, y))

			if self.get_stat('starbask'): self.owner.apply_buff(Starbask())

			return

		yield

	def on_channel_stop(self):
		b = self.channel_buff
		self.channel_buff = None
		self.owner.remove_buffs(Starbask)
		if b and self.get_stat('ritual') and b.channel_turns >= b.max_channel: self.whale = None; return
		if self.whale: self.whale.kill(trigger_death_event=False); self.whale = None
		self.owner.level.queue_spell(self.do_freeze())

	def do_freeze(self):
		self.owner.apply_buff(FrozenBuff(), 3)
		yield

class BladeRites(Buff):

	def __init__(self, spell):
		Buff.__init__(self)
		self.blade = spell.make_blade
		self.stack_type = STACK_INTENSITY

	def on_init(self):
		self.name = "Blade Rites"
		self.color = Tags.Metallic.color
		self.description = "Summon a blade nearby each turn"

	def on_advance(self):
		self.summon(self.blade(), self.owner)

class SummonBlade(Spell):

	def on_init(self):
		self.name = "Summon Blade"
		self.level = 1
		self.tags = [Tags.Arcane, Tags.Conjuration, Tags.Metallic]

		self.max_charges = 7
		self.range = 3

		self.minion_health = 9
		self.shields = 2
		self.minion_damage = 9
		self.minion_range = 3
		self.minion_duration = 9

		self.must_target_empty = True
		self.target_empty = True

		self.upgrades[('serrated', 'duration')] = ([1, 3], 1, "Serrated Blades", "The blades' leap attack inflicts [{duration}:duration] turns of [bleed]", [Tags.Blood])
		self.upgrades[('bladeworks', 'num_summons')] = ([1, 2], 6, "Bladeworks", "Summon [{num_summons}:num_summons] blades instead of one")
		self.upgrades[('ritual', 'max_channel')] = ([1, 8], 9, "Ritual of Blades", "You may channel this spell for [{max_channel} turns:max_channel]\nIf you complete the ritual, gain the [Blade Rites:metallic] buff for [{max_channel}:max_channel] turns, which summons a blade near you each turn", [Tags.Ritual])
		self.upgrades['light'] = (1, 3, "Swords of Light", "Summon Swords of Light instead of Dancing Blades", [Tags.Holy])

		self.add_upgrade_tooltip("Swords of Light", lambda: self.make_blade(True))

	def get_description(self):
		return "Summon a temporary Dancing Blade"

	def get_extra_examine_tooltips(self):
		return [self.make_blade(False)] + self.get_upgrade_tooltips()

	def cast(self, x, y, channel_cast=False):
		ritual = self.get_stat('ritual')
		if ritual and not channel_cast and self.is_manual_cast():
			self.caster.apply_buff(ChannelBuff(self.cast, Point(x, y)), self.get_stat('max_channel'))
			return

		num = 1
		if self.get_stat('bladeworks'): num = self.get_stat('num_summons')
		for i in range(num):
			u = self.make_blade()
			self.summon(u, Point(x, y))
			yield

		if ritual and channel_cast and not self.owner.has_buff(ChannelBuff): # final turn
			self.caster.apply_buff(BladeRites(self), self.get_stat('max_channel'))

	def make_blade(self, light=None):
		if light is None: light = self.get_stat('light')
		f = SwordOfLight if light else DancingBlade
		u = f()
		if self.get_stat('serrated'):
			s = u.get_spell(LeapAttack)
			s.buff = BleedBuff
			s.buff_name = BleedBuff().name
			s.buff_duration = self.get_stat('duration')
		apply_minion_bonuses(self, u)
		return u

	def get_ai_target(self):
		pts = list(self.caster.level.get_points_in_ball(self.caster.x, self.caster.y, self.get_stat('range')))
		random.shuffle(pts)
		return next((p for p in pts if self.can_cast(p.x, p.y)), None)

class DragonTutor(Upgrade):

	def __init__(self, spell):
		self.spell = spell
		Upgrade.__init__(self, spell)

	def on_init(self):
		self.name = "Dragon Tutor"
		self.description = "When an allied [Dragon] is summoned, replace their normal melee attack with your Dragon Claw spell\nAlways Active"
		self.level = 2
		self.global_triggers[EventOnUnitAdded] = self.on_unit_added

	def on_unit_added(self, evt):
		if not self.owner.is_player_controlled: return  # don't want recursion on the grant, would slowthings down
		if are_hostile(self.owner, evt.unit): return
		if Tags.Dragon not in evt.unit.tags: return
		melee = evt.unit.get_spell(SimpleMeleeAttack)
		if not melee: return
		grant_minion_spell(DragonClaw, evt.unit, self.owner, cool_down=0, pre_insert=False, replace=melee)
		self.owner.level.queue_spell(self.owner.level.show_path_effect(self.owner, evt.unit, Tags.Physical, pause_frames=1))
		b = evt.unit.get_buff(DragonTutor)
		if b: evt.unit.remove_buff(b)


class DragonClaw(Spell):

	def on_init(self):
		self.name = "Dragon Claw"
		self.level = 1
		self.tags = [Tags.Dragon, Tags.Sorcery]
		self.range = 1.5
		self.melee = True
		self.can_target_self = False

		self.damage = 20
		self.charges = 0
		self.damage_type = [Tags.Physical]

		self.upgrades[('bleed', 'duration')] = ([1, 6], 1, "Serrated Steel Claws", "Dragon Claw also inflicts [{duration}:duration] turns of [bleed]", [Tags.Metallic])
		self.upgrades[('frenzy', 'num_targets')] = ([1, 3], 4, "Frenzied Swipes", "Dragon Claw hits [{num_targets}:num_targets] times")
		self.upgrades['chaos'] = (1, 5, "Chaos Claws", "Dragon Claw also deals [Fire] and [Lightning] damage", [Tags.Chaos], [Tags.Fire, Tags.Lightning])
		self.add_upgrade(DragonTutor(self))

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		deal_damage = level.deal_damage
		getu = level.get_unit_at

		target_unit = getu(x, y)

		dmg = self.get_stat('damage')
		dur = self.get_stat('duration')
		bleed = self.get_stat('bleed')
		num_hits = self.get_stat('num_targets') if self.get_stat('frenzy') else 1
		dtypes = self.get_stat('damage_type')

		for i in range(num_hits):
			for p in self.get_impacted_tiles(x, y):
				level.show_effect(p.x, p.y, Tags.Dragon)
				for dtype in dtypes:
					unit = getu(p.x, p.y)
					if unit and are_friendly(caster, unit) and unit != target_unit: continue # ignore friendlies not directly targeted
					deal_damage(p.x, p.y, dmg, dtype, self, flash=False)
					if unit and bleed: unit.apply_buff(BleedBuff(), dur)
					if i == 0: yield
		yield

	def get_impacted_tiles(self, x, y):
		ball = self.caster.level.get_points_in_ball(x, y, 1, diag=False)
		if not self.caster.radius: return [p for p in ball if distance(p, self.caster, diag=True) == 1] # 1x1
		caster_pts = set(self.caster.iter_occupied_points())
		return [p for p in ball if p not in caster_pts and any(distance(p, o, diag=True) == 1 for o in caster_pts)] # more complex for 3x3s

	def get_description(self):
		return "Deal [{damage}:damage] [Physical] damage in an arc\nWill not damage allies unless directly targeted"


class MeasuredBreathing(Upgrade):

	def on_init(self):
		self.name = "Measured Breathing"
		self.level = 3
		self.description = "If you do not manually cast a spell on your turn, regain a charge of Dragon Breath\nAlways Active"
		self.owner_triggers[EventOnSpellCast] = self.on_cast
		self.did_cast = False

	def on_cast(self, evt):
		if evt.pay_costs: self.did_cast = True

	def on_advance(self):
		if self.did_cast: self.did_cast = False; return
		s = self.owner.get_spell(DragonBreath)
		if not s: return
		s.refund_charges(1)

class DragonBreath(Spell):

	def on_init(self):
		self.name = "Dragon Breath"
		self.tags = [Tags.Dragon, Tags.Sorcery]
		self.max_charges = 16
		self.damage = 7
		self.range = 5
		self.angle = math.pi / 6.0
		self.level = 2
		self.can_target_self = False

		self.upgrades[('morph', 'duration')] = ([1, 5], 2, "Chromatic Aspect", "Dragon Breath grants you 100% resistance to its damage type(s) for [{duration}:duration] turns")
		self.upgrades['lungs'] = (1, 4, "Dragon Lungs", "Dragon Breath deals additional damage equal to its remaining charges")
		self.upgrades['speaker'] = (1, 9, "Dragon Speaker", "Dragon Breath deals an additional random damage type for each other [Dragon] spell you know", [Tags.Word])
		self.add_upgrade(MeasuredBreathing())

	def get_description(self):
		return ("Deal [{damage}:damage] damage of a random type in a cone\n"
				"If you target a unit with this spell, the damage type will instead be the one they are most vulnerable to")

	def aoe(self, x, y):
		target = Point(x, y)
		return Burst(self.caster.level,
				     Point(self.caster.x, self.caster.y),
				     self.get_stat('range'),
				     burst_cone_params=BurstConeParams(target, self.angle),
				     ignore_walls=not self.get_stat('requires_los'))

	def cast(self, x, y):
		dmg = self.get_stat('damage')
		if self.get_stat('lungs'): dmg += self.cur_charges
		caster = self.caster
		level = caster.level

		unit = level.get_unit_at(x, y)
		if unit:
			lowest_res = min(unit.resists.get(t, 0) for t in damage_tags)
			candidates = [t for t in damage_tags if unit.resists.get(t, 0) == lowest_res]
			dtypes = [random.choice(candidates)]
		else:
			dtypes = [random.choice(damage_tags)]

		if self.get_stat('speaker'):
			bonus = max(0, sum(1 for s in caster.spells if Tags.Dragon in s.tags and s is not self))
			pool = [t for t in damage_tags if t != dtypes[0]]
			extras = random.sample(pool, k=min(bonus, len(pool)))
			dtypes.extend(extras)

		if self.get_stat('morph'):
			for dtype in dtypes:
				self.caster.apply_buff(ResistBuff(dtype, 100), self.get_stat('duration'))

		for stage in self.aoe(x, y):
			for point in stage:
				if level.get_unit_at(point.x, point.y) == caster: continue
				for dtype in dtypes: level.deal_damage(point.x, point.y, dmg, dtype, self)
			yield

	def get_impacted_tiles(self, x, y):
		return [p for stage in self.aoe(x, y) for p in stage]

class ShadowHexBuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		self.stacking = self.spell.get_stat('stacking')
		self.devouring = self.spell.get_stat('devour')
		self.damage = self.spell.get_stat('damage')
		self.remove_resistance = self.spell.get_stat('remove_resistance')
		Buff.__init__(self)

	def on_init(self):
		self.name = "Shadow Hex"
		self.asset = ['status', 'shadow_hex']
		self.buff_type = BUFF_TYPE_CURSE
		self.stack_type = STACK_INTENSITY if self.stacking else STACK_DURATION
		self.color = Tags.Dark.color
		self.devour_bonus = 0
		if self.remove_resistance: self.resists[Tags.Dark] = -25

	def get_description(self):
		desc = "Each turn, take [{damage}:damage] [Dark] damage"
		if self.devouring: desc += "\nEach turn, remove temporary buffs\nEach buff removed this way increases the damage by {devour} for the remaining duration"
		return (desc, {'damage': self.damage + self.devour_bonus, 'devour':self.damage})

	def on_advance(self):
		if self.devouring:
			targets = [b for b in self.owner.buffs if b.buff_type == BUFF_TYPE_BLESS]
			for t in targets:
				self.owner.remove_buff(t)
				self.devour_bonus += self.damage
		self.owner.deal_damage(self.damage + self.devour_bonus, Tags.Dark, self.spell)

class ShadowHexSpell(Spell):

	def on_init(self):
		self.name = "Shadow Hex"
		self.level = 2
		self.tags = [Tags.Dark, Tags.Enchantment]
		self.max_charges = 5
		self.range = 8
		self.damage = 9
		self.radius = 3
		self.duration = 10

		self.upgrades['remove_resistance'] = (1, 3, "Insatiable Shadows", "The Shadow Hex debuff removes [25% Dark:dark] resistance")
		self.upgrades['devour'] = (1, 2, "Devouring Shadows", "The Shadow Hex debuff removes temporary buffs at the end of each turn\n"
		"Each buff removed this way increases its damage by [{damage}:damage] for the remainder of its duration", None, None, {'damage':9})

		self.upgrades['stacking'] = (1, 4, "Compounding Curses", "Shadow Hex will stack instead of extending its duration on subsequent applications")
		self.upgrades[('knot', 'hp_cost')] = ([1, 25], 7, "Hex Knot", "Affected units also receive the [Shared Pain:blood] debuff for [{duration}:duration] turns", [Tags.Blood], None, {'duration':3})
		self.add_upgrade_tooltip("Hex Knot", SharedPainBuff)

	def get_description(self):
		return ("Curse enemies in a [{radius} tile:radius] radius with the Shadow Hex for [{duration}:duration] turns\n"
				"Cursed targets take [{damage}:damage] [Dark] damage each turn")

	def get_shadow_hex_buff(self):
		return ShadowHexBuff(self)

	def get_extra_examine_tooltips(self):
		return [self.get_shadow_hex_buff()] + self.get_upgrade_tooltips()

	def cast_instant(self, x, y):
		targets = []
		for p in self.owner.level.get_points_in_ball(x, y, self.get_stat('radius')):
			u = self.owner.level.get_unit_at(p.x, p.y)
			if u and are_hostile(u, self.caster) and u not in targets: targets.append(u)

		knot = self.get_stat('knot')
		dur = self.get_stat('duration')
		shared_dur = self.get_stat('duration', base=3)

		for unit in targets:
			unit.apply_buff(self.get_shadow_hex_buff(), dur)
			if knot: unit.apply_buff(SharedPainBuff(), shared_dur)


BOARD_W = BOARD_H = 18
CENTER_X = (BOARD_W - 1) / 2.0
CENTER_Y = (BOARD_H - 1) / 2.0
HUB_MIN_X = BOARD_W // 2 - 1
HUB_MIN_Y = BOARD_H // 2 - 1
HUB_TILES = [
	Point(HUB_MIN_X, HUB_MIN_Y),
	Point(HUB_MIN_X + 1, HUB_MIN_Y),
	Point(HUB_MIN_X, HUB_MIN_Y + 1),
	Point(HUB_MIN_X + 1, HUB_MIN_Y + 1)
]

OUTER_R2 = 74  # ~8.6^2
INNER_R2 = 42  # ~6.5^2
CLOCK_RING = [
	Point(x, y)
	for x in range(BOARD_W)
	for y in range(BOARD_H)
	if INNER_R2 <= (x - CENTER_X) * (x - CENTER_X) + (y - CENTER_Y) * (y - CENTER_Y) <= OUTER_R2
]


def build_clock_hands():
	hands = {}
	hand_len = math.sqrt(INNER_R2) - 1.0

	def bresenham(x0, y0, x1, y1):
		pts = []
		dx, dy = abs(x1 - x0), abs(y1 - y0)
		sx, sy = (1 if x0 < x1 else -1), (1 if y0 < y1 else -1)
		err = dx - dy
		while True:
			pts.append(Point(x0, y0))
			if x0 == x1 and y0 == y1: break
			e2 = 2 * err
			if e2 > -dy: err -= dy; x0 += sx
			if e2 < dx: err += dx; y0 += sy
		return pts

	def round_nearest(v):
		return int(math.floor(v + 0.5))

	for hour in range(12):
		ang = 2 * math.pi * hour / 12.0 - math.pi / 2  # 12 o’clock up
		vx, vy = math.cos(ang), math.sin(ang)
		pts = set()
		for hub in HUB_TILES:
			x1 = round_nearest(hub.x + vx * hand_len)
			y1 = round_nearest(hub.y + vy * hand_len)
			for p in bresenham(hub.x, hub.y, x1, y1):
				if 0 <= p.x < BOARD_W and 0 <= p.y < BOARD_H: pts.add(p)
		hands[hour] = list(pts)
	return hands


CLOCK_HANDS = build_clock_hands()

class DeathClock(Spell):

	def on_init(self):
		self.name = "Death Clock"
		self.tags = [Tags.Dark, Tags.Metallic, Tags.Sorcery]
		self.level = 3
		self.max_charges = 12
		self.damage = 12
		self.range = 0
		self.damage_type = [Tags.Physical, Tags.Dark]

		self.upgrades['echo'] = (1, 1, "Daily Death", "Casts again in 24 turns")
		self.upgrades[('stopwatch', 'duration')] = ([1, 3], 4, "Stopwatch", "[Stun] duration now scales with [duration:duration]")
		self.upgrades['sundial'] = (1, 5, "Sundial", "Death Clock also deals [Fire] damage", [Tags.Fire], [Tags.Fire])
		self.upgrades[('ritual', 'max_channel')] = ([1, 12], 8, "Ritual of Mortality", "Death Clock may be channeled for up to [{max_channel}:max_channel] turns\nIf you complete the ritual, units hit by the final cast have their max HP halved", [Tags.Ritual])

	def get_description(self):
		return ("Deal [{damage}:damage] [Dark] and [Physical] damage in the shape of a clock\n"
				"The direction of the hour hand is determined by the current turn number\n"
				"Affected units are [stunned:stun] for 1 turn\n"
				"Will not affect the caster")

	def get_impacted_tiles(self, x, y):
		hour = self.caster.level.turn_no % 12
		area = set(CLOCK_RING)
		area.update(CLOCK_HANDS[hour])
		area.discard(Point(self.caster.x, self.caster.y))
		return area

	def cast(self, x, y, is_echo=False, channel_cast=False):
		if self.get_stat('echo') and not is_echo: self.caster.apply_buff(EchoCast(self), 24)

		if self.get_stat('ritual') and not channel_cast and self.is_manual_cast():
			self.caster.apply_buff(ChannelBuff(self.cast, Point(x, y)), self.get_stat('max_channel'))
			return

		caster = self.caster
		level = caster.level
		deal_damage = level.deal_damage
		getu = level.get_unit_at
		dmg = self.get_stat('damage')
		dur = self.get_stat('duration') if self.get_stat('stopwatch') else 1
		dtypes = self.get_stat('damage_type')
		mortality = (self.get_stat('ritual') and channel_cast and not caster.has_buff(ChannelBuff))

		for p in self.get_impacted_tiles(x, y):
			for dtype in dtypes: deal_damage(p.x, p.y, dmg, dtype, self)
			unit = getu(p.x, p.y)
			if unit and unit.is_alive():
				unit.apply_buff(Stun(), dur)
				if mortality:
					unit.max_hp = max(unit.max_hp // 2, 1)
					unit.cur_hp = min(unit.cur_hp, unit.max_hp)
		yield


class ShatterSpell(Spell):

	def on_init(self):
		self.name = "Shatter"
		self.tags = [Tags.Ice, Tags.Sorcery]
		self.damage_type = [Tags.Physical]
		self.level = 3
		self.range = 0
		self.max_charges = 6
		self.damage = 80

		self.upgrades['gather'] = (1, 1, "Gather Ice", "Gain 1 [SH:shields] for each damaged target in your line of sight")
		self.upgrades[('sharp', 'duration')] = ([1, 12], 2, "Razor Ice", "Shatter also inflicts [{duration}:duration] turns of [hemorrhage]")
		self.upgrades[('excise', 'hp_cost')] = ([1, 10], 3, "Glacial Excision", "After dealing damage, Shatter reduces affected enemies' max HP to match their current HP", [Tags.Blood])
		self.upgrades[('steam', 'minion_hp', 'minion_damage', 'minion_range', 'minion_duration')] = ([1, 20, 10, 4, 6], 6, "Steam Anima", "Shatter also deals [Fire] damage\nWhen Shatter kills a unit, summon a temporary Steam Elemental at its location", [Tags.Conjuration, Tags.Fire], [Tags.Fire])

		self.add_upgrade_tooltip("Steam Anima", lambda: make_minion(self, SteamElemental))
		self.add_upgrade_tooltip("Razor Ice", HemorrhageBuff)

	def get_description(self):
		return "[Frozen:ice] enemies take [{damage}:damage] [Physical:physical] damage"

	def get_impacted_tiles(self, x, y):
		return [u for u in self.caster.level.units if are_hostile(u, self.caster) and u.has_buff(FrozenBuff)]

	def cast(self, x, y):
		targets = [u for u in self.caster.level.units if are_hostile(u, self.caster) and u.has_buff(FrozenBuff)]
		if not targets: yield; return

		caster = self.caster
		level = caster.level

		dmg = self.get_stat('damage')
		excise = self.get_stat('excise')
		sharp = self.get_stat('sharp')
		dur = self.get_stat('duration')
		gather = self.get_stat('gather')
		steam = self.get_stat('steam')
		dts = self.get_stat('damage_type')

		for t in targets:
			dealt = 0
			for dt in dts: dealt += t.deal_damage(dmg, dt, self)
			if not dealt: continue
			if t.is_alive():
				if excise: t.max_hp = t.cur_hp
				if sharp: t.apply_buff(HemorrhageBuff(), dur)
			elif steam: self.summon(make_minion(self, SteamElemental), t)
			if gather and level.can_see(caster.x, caster.y, t.x, t.y):
				level.show_beam(t, caster, Tags.Ice)
				caster.add_shields(1)
			yield

class SummonBoneKnights(Spell):

	def on_init(self):
		self.name = "Summon Bone Knights"
		self.level = 2
		self.tags = [Tags.Conjuration, Tags.Dark]
		self.max_charges = 2
		self.num_summons = 2
		self.minion_health = 40
		self.minion_damage = 9
		self.range = 0

		self.upgrades[('multi', 'num_targets')] = ([1, 2], 2, "Double Hit", "Knights now hit [{num_targets}:num_targets] times")
		self.upgrades[('steel', 'minion_health')] = ([1, 20], 3, "Bones of Steel", "Knights receive the [Metallic] tag, gaining [Lightning] immunity along with increased resistance to [Fire], [Ice], and [Physical] damage", [Tags.Metallic])
		self.upgrades[('knightmares', 'duration')] = ([1, 10], 8, "Knightmares", "Apply your Nightmare Aura buff for [{duration}:duration] turns to each of the knights when they are summoned")
		self.upgrades['squad'] = (1, 5, "Bone Squadron", "Summon half as many Bone Knight Archers to accompany the Bone Knights")

		self.add_upgrade_tooltip("Bone Squadron", self.make_archer)

	def get_description(self):
		return "Summon [{num_summons}:num_summons] Bone Knights nearby"

	def get_extra_examine_tooltips(self):
		return [self.make_knight()] + self.get_upgrade_tooltips()

	def make_knight(self):
		u = make_minion(self, BoneKnight)
		num_attacks = self.get_stat('num_targets') if self.get_stat('multi') else 1
		u.get_spell(SimpleMeleeAttack).attacks = num_attacks
		if self.get_stat('steel'): u.tags.append(Tags.Metallic); u.resists[Tags.Physical] += 50
		return u

	def make_archer(self):
		u = make_minion(self, BoneKnightArcher)
		num_attacks = self.get_stat('num_targets') if self.get_stat('multi') else 1
		u.get_spell(SimpleRangedAttack).attacks = num_attacks
		if self.get_stat('steel'): u.tags.append(Tags.Metallic); u.resists[Tags.Physical] += 50
		return u

	def cast(self, x, y):
		knightmare = self.get_stat('knightmares')
		nightmare = self.caster.get_or_make_spell(NightmareSpell)
		nightmare_duration = self.get_stat('duration')

		num_attacks = self.get_stat('num_targets') if self.get_stat('multi') else 1
		archers = self.get_stat('squad')
		steel = self.get_stat('steel')

		units = []
		for _ in range(self.get_stat('num_summons')):
			units.append(make_minion(self, BoneKnight))
		if archers:
			for _ in range(self.get_stat('num_summons') // 2):
				units.append(make_minion(self, BoneKnightArcher))

		for u in units:
			s = u.get_spell(SimpleMeleeAttack) or u.get_spell(SimpleRangedAttack)
			s.attacks = num_attacks
			if steel: u.tags.append(Tags.Metallic); u.resists[Tags.Physical] += 50
			knight = self.summon(u)
			if knight and knightmare: knight.apply_buff(NightmareBuff(nightmare), nightmare_duration)
			yield

class RoarOfAnguish(Upgrade):

	def __init__(self, spell):
		self.spell = spell
		Upgrade.__init__(self, spell)

	def on_init(self):
		self.name = "Roar of Anguish"
		self.level = 4
		self.owner_triggers[EventOnDamaged] = self.on_damage
		self.triggered = False

	def on_advance(self):
		self.triggered = False

	def on_damage(self, evt):
		if evt.damage < 1: return
		if self.triggered: return
		self.triggered = True
		self.owner.level.defer_cast(self.owner, self.spell, self.owner.x, self.owner.y, pay_costs=False)

	def get_description(self):
		return "The first time you take damage each turn, cast Dragon Roar\nAlways Active"

class DragonRoar(Spell):

	def on_init(self):
		self.name = "Dragon Roar"
		self.level = 3
		self.tags = [Tags.Dragon, Tags.Sorcery]
		self.max_charges = 7
		self.range = 0
		self.radius = 4
		self.damage = 9
		self.push_distance = 3
		self.stats.append('push_distance')
		self.damage_type = [Tags.Physical]

		self.upgrades[('max_charges', 'radius', 'push_distance')] = ([7, 2, 2], 3, "Forceful Roar")
		self.upgrades[('frighten', 'duration')] = ([1, 2], 4, "Frightening Presence", "Affected enemies with less health than you are [feared] for [{duration}:duration] turns")
		self.upgrades['rally'] = (1, 4, "Rallying Roar", "Allies in the radius gain +1 damage to their spells\n[Dragon] allies gain +4 instead")
		self.add_upgrade(RoarOfAnguish(self))

	def get_description(self):
		return ("Deal [{damage}:damage] [Physical] damage to enemies in a [{radius}:radius] tile burst around the caster\n"
				"Push affected enemies up to {push_distance} tiles away")

	def get_impacted_tiles(self, x, y):
		return [p for stage in Burst(self.caster.level, self.caster, self.get_stat('radius'), ignore_walls=not self.get_stat('requires_los')) for p in stage]

	def cast(self, x, y):
		pushed = set()
		allies = set()
		lvl = self.caster.level
		dmg = self.get_stat('damage')
		push_distance = self.get_stat('push_distance')
		rally = self.get_stat('rally')
		stages = list(Burst(lvl, self.caster, self.get_stat('radius'), ignore_walls=not self.get_stat('requires_los')))
		for stage in reversed(stages): # push outer rings first so inner rings have somewhere to go
			for p in stage:
				u = lvl.get_unit_at(p.x, p.y)
				if u:
					if are_hostile(self.caster, u):
						u.deal_damage(dmg, Tags.Physical, self)
						if u not in pushed:
							push(u, self.caster, push_distance) # only push each unit once
							pushed.add(u)
						yield
					else:
						if rally: allies.add(u)
				else:
					lvl.show_effect(p.x, p.y, Tags.Physical, minor=True)
			yield

		if self.get_stat('frighten'):
			dur = self.get_stat('duration')
			chp = self.caster.cur_hp
			for u in pushed:
				if u.cur_hp < chp:
					u.apply_buff(FearBuff(), dur)

		if rally:
			for u in allies:
				if u is self.caster: continue
				bonus = 4 if Tags.Dragon in u.tags else 1
				u.apply_buff(BloodrageBuff(bonus))

class DragonRideBuff(Buff):

	def __init__(self, spell):
		Buff.__init__(self)
		self.spell = spell
		self.name = "Drake Rider"
		self.buff_type = BUFF_TYPE_BLESS
		self.stack_type = STACK_TYPE_TRANSFORM
		self.transform_asset = ["char", "player_dragon"]
		self.color = Tags.Dragon.color
		if spell.get_stat('iron'):
			self.resists[Tags.Physical] = 50
			self.transform_asset = ["char", "player_dragon_armor"]
		self.breath = self.spell.get_stat('breath')

	def get_description(self):
		desc = [("Grants [quickstep:translocation] and flying\n"
				"If you lose this buff while over a chasm, unless you have other methods of flight, you will be deposited at the nearest valid tile\n"
				"If no such tile exists, fall to your death")]
		if self.breath:
			desc.append("\nEach turn, cast Dragon Breath spell for free at the nearest enemy in line of sight")
		return desc

	def on_applied(self, owner):
		owner.flying += 1
		owner.quick_move += 1

	def on_unapplied(self):
		self.owner.flying -= 1
		self.owner.quick_move -= 1
		if not self.owner.level.can_stand(self.owner.x, self.owner.y, self.owner): self.owner.level.queue_spell(self.place(self.owner))

	def on_advance(self):
		if not self.breath: return
		s = self.owner.get_or_make_spell(DragonBreath)
		e = self.owner.level.get_units_by_distance(self.owner, enemy=True, require_los=s.get_stat('requires_los'))
		if not e: return
		else: e = e[0]
		for p in e.iter_occupied_points():
			if s.can_cast(p.x, p.y):
				self.owner.level.act_cast(self.owner, s, p.x, p.y, pay_costs=False, queue=True)
				return

	def place(self, o):
		if o.flying: return # if they somehow got flying from another source in the meantime, cancel
		path = o.level.find_shortest_path_to_nearest_valid_tile(o.x, o.y, o)
		if not path: o.kill(); return
		for point in path: o.level.leap_effect(point.x, point.y, Tags.Dragon.color, o)
		o.level.act_move(o, path[-1].x, path[-1].y, teleport=True)
		yield

class DragonRideSpell(Spell):

	def on_init(self):
		self.name = "Ride Drake"
		self.level = 2
		self.tags = [Tags.Dragon, Tags.Translocation]
		self.range = 0
		self.duration = 10
		self.max_charges = 4

		self.upgrades['shields'] = (6, 2, "Evasive Maneuvers", "Gain [6 SH:shields] on cast")
		self.upgrades['iron'] = (1, 1, "Armored Drake", "While mounted, gain [50% Physical:physical] resist", [Tags.Metallic])
		self.upgrades['breath'] = (1, 7, "Strafing Run", "While mounted, cast Dragon Breath at the closest nearby enemy each turn")
		self.upgrades['dragonflight'] = (1, 7, "Flight of the Dragons", "When you manually cast Ride Drake, cast your other [Dragon] [Conjuration] spells nearby")

	def get_description(self):
		return ("Beckon forth a draconic mount, gaining [quickstep:translocation] and flying\n"
				"Lasts [{duration}:duration] turns")

	def get_dragon_ride_buff(self):
		return DragonRideBuff(self)

	def get_extra_examine_tooltips(self):
		return [self.get_dragon_ride_buff()] + self.get_upgrade_tooltips()

	def cast(self, x, y):
		self.caster.apply_buff(self.get_dragon_ride_buff(), self.get_stat('duration'))
		if self.get_stat('shields'): self.caster.add_shields(self.get_stat('shields'))
		if self.get_stat('dragonflight') and self.is_manual_cast():
			for s in self.caster.spells:
				if s == self: continue # don't allow inf looping with spellgraft shenanigans
				if Tags.Dragon not in s.tags or Tags.Conjuration not in s.tags: continue
				self.caster.level.act_cast(self.caster, s, self.caster.x, self.caster.y, pay_costs=False)
		yield

ruinous_stats = [
			'range',
			'damage',
			'radius',
			'duration',
			'shields',
			'num_targets',
			'minion_duration',
			'minion_damage',
			'minion_health',
			'minion_range',
			'num_summons',
		]

class RuinousOfferingBuff(Buff):

	def __init__(self, spell, bonus, gate):
		Buff.__init__(self)
		self.name = "Ruinous " + spell.name
		self.spell = spell
		self.color = Tags.Chaos.color
		self.stack_type = STACK_INTENSITY
		for stat in ruinous_stats: self.spell_bonuses_pct[type(spell)][stat] = bonus
		if gate: self.global_triggers[EventOnUnitPreAdded] = self.on_added # add demon tag

	def on_added(self, evt):
		if Tags.Demon in evt.unit.tags: return
		if evt.unit.source == self.spell:
			evt.unit.tags.append(Tags.Demon)


class RuinousOffering(Spell):

	def on_init(self):
		self.name = "Ruinous Offering"
		self.tags = [Tags.Blood, Tags.Chaos, Tags.Enchantment]
		self.level = 4
		self.max_charges = 6
		self.hp_cost = 50
		self.range = 0
		self.duration = 12

		self.upgrades['panoply'] = (1, 2, "Panoply of Ruin", "Ruinous Offering is no longer limited to only [Chaos] and [Blood] spells")
		self.upgrades['gate'] = (1, 3, "Ruinous Gate", "Units summoned by the empowered spell gain the [Demon] tag")
		self.upgrades['renewal'] = (1, 6, "Sanguine Renewal", "The empowered spell regains all charges")
		self.upgrades[('multi', 'num_targets')] = ([1, 2], 7, "Blessing of Ruin", "Ruinous Offering empowers up to [{num_targets}:num_targets] different spells instead of one")


	def get_description(self):
		return ("Empower one of your other spells at the cost of your life\n"
				"Gain a stacking [{bonus}%:blood] bonus to the attributes of another [Chaos] or [Blood] spell you know\n"
				"Lasts [{duration}:duration] turns", {'bonus':self.get_stat('hp_cost') // 2})

	def cast(self, x, y):
		opts = [s for s in self.caster.spells if s != self]
		if not self.get_stat('panoply'): opts = [s for s in opts if Tags.Chaos in s.tags or Tags.Blood in s.tags]
		if not opts: return
		if self.get_stat('multi'): k = min(len(opts), self.get_stat('num_targets'))
		else: k = 1
		spells = random.sample(opts, k=k)
		for spell in spells:
			self.caster.apply_buff(RuinousOfferingBuff(spell, self.get_stat('hp_cost') // 2, self.get_stat('gate')), self.get_stat('duration'))
			spell.do_ui_flash(tag=Tags.Chaos)
			if self.get_stat('renewal'): spell.refund_charges(spell.get_stat('max_charges'))
			yield

class TheGateAndTheKeyBuff(Buff):

	def __init__(self, spell, target):
		Buff.__init__(self)
		self.spell = spell
		self.target = target
		self.buff_type = BUFF_TYPE_BLESS
		self.stack_type = STACK_NONE
		self.name = "The Gate And The Key"
		self.color = Tags.Translocation.color
		self.counters = [0]
		self.counter_max = 6
		self.connected_targets = [target] # for drawing overlay and stacking

	def on_advance(self):
		for i in range(len(self.counters)): # separate turn tracking per rift
			self.counters[i] += 1
			if self.counters[i] < self.counter_max: continue
			self.spell.summon(self.spell.get_demon(bind=False), self.connected_targets[i])
			self.counters[i] = 0

	def get_description(self):
		return "Every 6 turns, summon an allied [Fiend:demon] from each bound Rift"


class RitualBound(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)

	def on_init(self):
		self.name = "Ritual Bound"
		self.color = Tags.Ritual.color
		self.buff_type = BUFF_TYPE_BLESS
		self.stack_type = STACK_REPLACE

	def on_unapplied(self):
		if not self.spell: return
		self.owner.team = TEAM_ENEMY
		self.owner.turns_to_death = self.spell.get_stat('max_channel')

	def get_description(self):
		if not self.spell:
			return "This is bound to your will"
		return ("If this buff is removed before the ritual is complete, this unit joins the enemy team and disappears [{duration}:duration] turns later",
				{'duration': self.spell.get_stat('max_channel')})

	def get_tooltip(self):
		if self.spell: return "Ritual Bound"
		else: return "Ritual Bound: Sealed"

class DemonicRitual(Spell):

	def on_init(self):
		self.name = "Demonic Ritual"
		self.tags = [Tags.Blood, Tags.Chaos, Tags.Conjuration, Tags.Ritual]
		self.level = 6
		self.max_charges = 6
		self.max_channel = 6
		self.range = 0
		self.hp_cost = 66

		self.minion_health = 166
		self.minion_range = 6
		self.minion_damage = 8

		self.opts = [ChaosFiend,
					 AshFiend,
					 InsanityFiend,
					 FurnaceFiend,
					 CopperFiend,
					 RotFiend]
		self.demon_names = [o().name for o in self.opts]

		self.upgrades[('stun', 'duration')] = ([1, 3], 1, "Solomon's Binding", "Enemy [Demons:demon] are [stunned] for [{duration}:duration] turns each turn you channel this spell", [Tags.Word])
		self.upgrades['circle'] = (1, 3, "Inviolate Ritual", "Gain 100% resistance to all damage types while channeling Demonic Ritual")
		self.upgrades['gate'] = (1, 5, "The Gate and the Key", "Once per Rift, if you complete the ritual while standing atop it, an allied [fiend:demon] will come forth from that location every 6 turns until the realm is complete", [Tags.Translocation])
		self.upgrades[('grand', 'max_channel')] = ([1, 12], 7, "Grand Ritual", "Rather than a single [fiend:demon], summon one of each")

		self.add_upgrade_tooltip("The Gate and the Key", self.get_gate_and_key_buff)


	def get_description(self):
		if self.caster and hasattr(self.caster, 'level'):
			return (("Summon a powerful [{demon}:demon] with the [Ritual Bound:ritual] buff\n"
					"If the ritual is interrupted or [Ritual Bound:ritual] is removed before the ritual is complete, the [fiend:demon] joins the enemy team before disappearing [{max_channel}:max_channel] turns later"),
					{'demon':self.demon_names[self.caster.level.turn_no % len(self.demon_names)]})

		return ("Summon a powerful [fiend:demon] with the [Ritual Bound:ritual] buff\n"
				"If the ritual is interrupted or [Ritual Bound:ritual] is removed before the ritual is complete, the [fiend:demon] joins the enemy team before disappearing [{max_channel}:max_channel] turns later")

	def get_extra_examine_tooltips(self):
		return [RitualBound(self)] + [self.get_demon(spawn_fn=o) for o in self.opts] + self.get_upgrade_tooltips()

	def get_gate_and_key_buff(self):
		return TheGateAndTheKeyBuff(self, Point(0, 0))

	def get_demon(self, spawn_fn=None, bind=True):
		if spawn_fn: u = spawn_fn()
		else: u = self.opts[self.caster.level.turn_no % len(self.opts)]()
		apply_minion_bonuses(self, u)
		if bind: u.apply_buff(RitualBound(self))
		return u

	def cast(self, x, y, channel_cast=False):
		if not channel_cast and self.is_manual_cast():
			b = ChannelBuff(self.cast, Point(x, y), on_failure=self.on_failure)

			if self.get_stat('circle'):
				for d in damage_tags:
					b.resists[d] = 100

			self.caster.apply_buff(b, self.get_stat('max_channel'))
			if self.get_stat('grand'):
				for spawner in self.opts:
					self.summon(self.get_demon(spawn_fn=spawner), radius=10)
					yield
			else:
				self.summon(self.get_demon(), radius=10) # big sacrifice, be willing to look further
			return

		completed = channel_cast and not self.caster.has_buff(ChannelBuff)
		if not completed and not self.get_stat('stun'): return # early out if we don't need to walk the list

		demons = [u for u in self.caster.level.units if Tags.Demon in u.tags]

		if self.get_stat('stun'):
			dur = self.get_stat('duration')
			for u in demons:
				if are_hostile(self.caster, u):
					u.apply_buff(Stun(), dur)

		if completed:
			demons = [u for u in demons if u.has_buff(RitualBound) and u.get_buff(RitualBound).spell == self]

			for u in demons:
				u.get_buff(RitualBound).spell = None # if we complete the spell, remove the spell from the buff, telling it to not change teams
				self.caster.level.show_beam(self.caster, u, Tags.Blood)
				yield

			if self.get_stat('gate'):
				p = self.caster.level.tiles[self.owner.x][self.owner.y].prop
				if not p or not isinstance(p, Portal): return
				target = Point(self.owner.x, self.owner.y)
				existing = self.caster.get_buff(TheGateAndTheKeyBuff)
				if existing:
					if target in existing.connected_targets: return # does a namedtuple equality compare rather than identity for membership
					else:
						existing.connected_targets.append(target)
						existing.counters.append(0)
				else: self.caster.apply_buff(TheGateAndTheKeyBuff(self, target))

	def on_failure(self):
		if hasattr(self.caster, 'game') and self.caster.game.level_cleared: return # don't make them flip on you if you beat the level while channeling, since you aren't choosing to stop channeling?
		demons = [u for u in self.caster.level.units if Tags.Demon in u.tags]
		for u in demons:
			b = u.get_buff(RitualBound)
			if not b or not b.spell: continue
			self.caster.level.show_beam(u, self.caster, Tags.Blood, minor=True)
			u.remove_buff(b)

class SniperBuff(Buff):

	def __init__(self, bonus):
		Buff.__init__(self)
		self.name = "Sniper"
		self.color = Tags.Metallic.color
		self.spell_bonuses[BloodBullet]['damage'] = bonus
		self.spell_bonuses[BloodBullet]['range'] = 1
		self.spell_bonuses[BloodBullet]['requires_los'] = -1
		self.owner_triggers[EventOnMoved] = self.on_move
		self.buff_type = BUFF_TYPE_BLESS
		self.stack_type = STACK_INTENSITY

	def on_move(self, evt):
		self.owner.remove_buff(self)

class SniperUpgrade(Upgrade):

	def on_init(self):
		self.name = "Sniper's Trance"
		self.level = 5
		self.damage = 10
		self.counter = 0
		self.counter_max = 3
		self.owner_triggers[EventOnPass] = self.on_pass

	def get_description(self):
		return ("Pass the turn to gain the [Sniper:metallic] buff\n"
				"[Sniper:metallic] grants a stacking +1 [range] and +[{damage}:damage] damage bonus to Blood Bullet, and removes its line of sight requirement\n"
				"All stacks of [Sniper:metallic] are removed when you move")

	def on_pass(self, evt):
		self.owner.apply_buff(SniperBuff(self.get_stat('damage')))

class BloodBullet(Spell):

	def on_init(self):
		self.name = "Blood Bullet"
		self.level = 1
		self.tags = [Tags.Blood, Tags.Metallic, Tags.Sorcery]
		self.max_charges = 0
		self.hp_cost = 1
		self.range = 10
		self.damage = 10
		self.damage_type = [Tags.Physical]
		self.bless_tags = {Tags.Dark, Tags.Demon, Tags.Undead}

		self.upgrades['rime'] = (1, 2, "Rime Coated Rounds", "Blood Bullet also deals [Ice] damage", [Tags.Ice], [Tags.Ice])
		self.upgrades['blessed'] = (1, 4, "Blessed Blood", "Blood Bullet also deals [Holy] damage\nBlood Bullet will penetrate [Dark], [Demon], and [Undead] units", [Tags.Holy], [Tags.Holy])
		self.upgrades[('six', 'num_targets')] = ([1, 2], 4, "Double Tap", "Shoot [{num_targets}:num_targets] bullets instead of one")
		self.add_upgrade(SniperUpgrade())

	def get_description(self):
		return "Shoot a projectile that deals [{damage}:damage] [Physical] damage to the first unit in its path"

	def get_impacted_tiles(self, x, y):
		return self.caster.level.get_points_in_line(self.caster, Point(x, y), find_clear=self.get_stat('requires_los'))[1:]

	def cast(self, x, y):
		num_shots = self.get_stat('num_targets') if self.get_stat('six') else 1
		dmg = self.get_stat('damage')
		dtypes = self.get_stat('damage_type')
		level = self.caster.level
		for _ in range(num_shots):
			target = Point(x, y)
			for p in self.get_impacted_tiles(x, y):
				u = level.get_unit_at(p.x, p.y)
				level.projectile_effect(p.x, p.y, proj_name='blood_bullet', proj_origin=self.caster, proj_dest=target, proj_duration=1) # low duration, otherwise see a string of bullets
				yield
				if not u or not u.is_alive(): continue
				for dtype in dtypes: level.deal_damage(p.x, p.y, dmg, dtype, self)
				if self.get_stat('blessed') and any(t in self.bless_tags for t in u.tags):
					continue # keep going to the next point if we're blesed and hit a demon
				break

			yield

def Orb():
	u = Unit()
	u.name = "Orb"
	u.max_hp = 100
	u.tags = [Tags.Construct, Tags.Orb]
	for dt in damage_tags: u.resists[dt] = 0
	u.resists[Tags.Poison] = 100
	u.stationary = True
	u.flying = True
	return u

class NightPulse(DamageAuraBuff):

	def __init__(self, damage, radius, friendly_fire=False, engulf=False, feed=False):
		DamageAuraBuff.__init__(self, damage=damage, damage_type=Tags.Dark, radius=radius, custom_name="Night Pulse", friendly_fire=friendly_fire)
		self.engulf = engulf
		self.kill_count = 0
		if feed: self.global_triggers[EventOnSpellCast] = self.on_cast

	def on_cast(self, evt):
		if Tags.Dark in evt.spell.tags: self.owner.heal(10, evt.spell)

	def on_kill(self, evt):
		if not self.engulf: return
		self.kill_count += 1
		if self.kill_count < self.radius: return
		self.kill_count -= self.radius
		self.radius += 1
		detonate = self.owner.get_buff(DarkDetonationBuff)
		if detonate: detonate.radius += 1 # bump detonation to reflect 'shared' radius increase

	def on_hit(self, unit):
		unit.apply_buff(BlindBuff(), 2)

	def get_tooltip(self):
		desc = [DamageAuraBuff.get_tooltip(self)]
		desc.append("\nInflict 2 turns of [blind] to affected units")
		if self.engulf: desc.append(("\nAura radius increases by 1 after killing {num} more units", {'num':self.radius - self.kill_count}))
		return desc

class DarkDetonationBuff(Buff):

	def __init__(self, radius):
		Buff.__init__(self)
		self.radius = radius

	def on_init(self):
		self.color = Tags.Dark.color
		self.owner_triggers[EventOnDeath] = self.on_death
		self.name = "Dark Detonation"

	def get_tooltip(self):
		if self.owner: return ("On death, deal {val} [Dark] damage to enemies within {radius} tiles", {'val':self.owner.max_hp, 'radius':self.radius})
		else: return ("On death, deal [Dark] damage to enemies within {radius} tiles", {'radius':self.radius})

	def on_death(self, evt):
		owner = self.owner
		deal_damage = owner.level.deal_damage
		getu = owner.level.get_unit_at
		dmg = owner.max_hp

		for p in owner.level.get_points_in_ball(owner.x, owner.y, self.radius):
			unit = getu(*p)
			if unit and not are_hostile(unit, owner): continue
			else: deal_damage(p.x, p.y, dmg, Tags.Dark, self)

class DarkTendrilsBuff(Buff):

	def __init__(self, num_targets):
		Buff.__init__(self)
		self.num_targets = num_targets

	def get_tooltip(self):
		return ("Tendrils of darkness drag the nearest {num_targets} enemies along paths toward the Orb of Night each turn", {'num_targets':self.num_targets})

	def on_advance(self):
		targets = self.owner.level.get_units_by_distance(self.owner, enemy=True)[:self.num_targets]
		for t in targets: self.owner.level.queue_spell(self.do_pull(t))

	def do_pull(self, t):
		path = get_pull_along_path(t, self.owner, RANGE_GLOBAL)
		if path:
			for p in reversed(path): self.owner.level.show_effect(p.x, p.y, Tags.Dark, minor=True)
			yield
			p = path[0]
			if t.level.can_move(t, p.x, p.y, teleport=True): t.level.act_move(t, p.x, p.y, teleport=True)  # abridged pull
		elif not self.owner.level.are_adjacent(self.owner, t):
			yield from t.level.show_path_effect(self.owner, t, Tags.Dark, pause_frames=2)
		yield

class OrbOfNight(Spell):

	def on_init(self):
		self.name = "Orb of Night"
		self.level = 4
		self.tags = [Tags.Orb, Tags.Dark, Tags.Conjuration]
		self.must_target_empty = True
		self.max_charges = 2
		self.range = 7

		self.minion_health = 100
		self.minion_damage = 10

		self.radius = 4

		self.upgrades['feed'] = (1, 1, "Feed the Darkness", "Orb of Night heals for 10 HP when you cast a [Dark] spell")
		self.upgrades['explode'] = (1, 4, "Dark Detonation", "Orb of Night explodes on death, dealing [Dark] damage equal to its max HP to enemies in its radius")
		self.upgrades['engulf'] = (1, 6, "Engulfing Darkness", "Orb of Night's aura will grow by +1 radius after it kills a number of units equal to its current radius")
		self.upgrades[('tendrils', 'num_targets')] = ([1, 3], 5, "Dark Tendrils", "Tendrils of darkness drag the nearest [{num_targets}:num_targets] enemies along paths toward the Orb of Night each turn")


	def get_description(self):
		return ("Summon an Orb of Night\n"
				"Each turn, the orb inflicts [{minion_damage}:minion_damage] [Dark] damage and 2 turns of [blind] on enemies within [{radius}:radius] tiles\n"
				"Only one Orb of Night may exist at a time\n"
				"Casting this spell while an Orb of Night exists will cause it to teleport to the selected location")

	def get_impacted_tiles(self, x, y):
		existing = next((u for u in self.caster.level.units if u.source is self and u.is_alive()), None)
		if existing: r = existing.get_buff(NightPulse).radius
		else: r = self.get_stat('radius')
		for p in self.caster.level.get_points_in_ball(x, y, r): yield p

	def get_extra_examine_tooltips(self):
		return [self.make_orb()] + self.get_upgrade_tooltips()

	def make_orb(self):
		u = Orb()
		u.name = "Orb of Night"
		u.asset_name = "orb_dark"
		u.tags.append(Tags.Dark)
		u.resists[Tags.Holy] = -100
		u.resists[Tags.Dark] = 100

		u.buffs.append(NightPulse(self.get_stat('minion_damage'),
								  self.get_stat('radius'),
								  friendly_fire=False,
								  engulf=self.get_stat('engulf'),
								  feed=self.get_stat('feed')))

		apply_minion_bonuses(self, u)
		if self.get_stat('explode'): u.buffs.append(DarkDetonationBuff(self.get_stat('radius')))
		if self.get_stat('tendrils'): u.buffs.append(DarkTendrilsBuff(self.get_stat('num_targets')))
		return u

	def cast(self, x, y):
		existing = next((u for u in self.caster.level.units if u.source is self and u.is_alive()), None)
		if existing:
			if self.caster.level.can_move(existing, x, y, teleport=True):
				self.caster.level.act_move(existing, x, y, teleport=True)
		else:
			self.summon(self.make_orb(), target=Point(x, y))
		yield

class AssimilationBuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)

	def on_init(self):
		self.name = "Assimilation"
		self.global_triggers[EventOnSpellCast] = self.on_cast

	def on_cast(self, evt):
		if not evt.caster.is_player_controlled: return # player spell
		if not evt.pay_costs: return # manual only
		if evt.x != self.owner.x or evt.y != self.owner.y: return # on me
		if Tags.Sorcery not in evt.spell.tags: return # with sorcery
		drain_amt = evt.spell.cur_charges
		cool_down = max(0, 10 - drain_amt)
		if self.spell.get_stat('intake'): drain_amt = 0; cool_down = evt.spell.level
		existing = next((s for s in self.owner.spells if type(s) == type(evt.spell)), None)
		if existing: cool_down = min(cool_down, existing.cool_down); self.owner.cool_downs.pop(existing, None) # will replace existing with better of two cd options if it already has the spell
		evt.spell.cur_charges -= drain_amt
		evt.spell.do_ui_flash(Tags.Arcane)
		if self.spell.get_stat('learn'): evt.caster.adjust_spell_bonus(type(evt.spell), 'max_charges', 10, pct=True)
		grant_minion_spell(type(evt.spell), self.owner, evt.caster, cool_down=cool_down, pre_insert=existing is None, replace=existing)

class DamageAssimilationBuff(Buff):

	def on_init(self):
		self.name = "Damage Assimilation"
		self.description = "On taking damage, gain that much resistance to that damage type"
		self.owner_triggers[EventOnDamaged] = self.on_damage

	def on_damage(self, evt):
		if evt.damage <= 0: return
		self.resists[evt.damage_type] += evt.damage
		self.owner.resists[evt.damage_type] += evt.damage


class SpellMasteryBuff(Buff):

	def on_init(self):
		self.name = "Spell Mastery"
		self.description = "Casting a spell reduces its other spells' active cooldowns by 1"
		self.owner_triggers[EventOnSpellCast] = self.on_cast

	def on_cast(self, evt):
		owner = self.owner
		for s in list(owner.cool_downs):
			if s == evt.spell: continue
			if owner.cool_downs[s] > 1:
				owner.cool_downs[s] -= 1

class OrbOfAssimilation(Spell):

	def on_init(self):
		self.name = "Orb of Assimilation"
		self.level = 5
		self.tags = [Tags.Orb, Tags.Arcane, Tags.Conjuration]

		self.must_target_empty = True
		self.max_charges = 2
		self.range = 7

		self.minion_health = 100

		self.upgrades['intake'] = (1, 3, "Spell Sampling", "Granting the Orb of Assimilation a spell no longer drains its charges\nInstead, the orb's cooldown for the spell will be set equal to the spell's level")
		self.upgrades['resist'] = (1, 4, "Damage Assimilation", "When the Orb of Assimilation takes damage, it gains that much resistance to that damage type")
		self.upgrades['master'] = (1, 5, "Assimilation Mastery", "Each time the Orb of Assimilation casts a spell, it lowers the active cooldown of its other spells by 1")
		self.upgrades['learn'] = (1, 9, "Spell Exhaustion", "Casting a [Sorcery] spell targeting the Orb of Assimilation grants you a permanent +10% bonus to that spell's [max charges:max_charges]")

	def get_description(self):
		return ("Summon an Orb of Assimilation\n"
				"When you manually cast a [Sorcery] spell targeting the Orb of Assimilation, it gains that spell on a 10 turn cooldown\n"
				"Granting a spell in this way consumes its remaining charges, reducing the Orb's cooldown by 1 for each charge consumed\n"
				"Only one Orb of Assimilation may exist at a time\n"
				"Casting this spell while an Orb of Assimilation exists will cause it to teleport to the selected location")

	def get_extra_examine_tooltips(self):
		return [self.make_orb()] + self.get_upgrade_tooltips()

	def make_orb(self):
		u = Orb()
		u.name = "Orb of Assimilation"
		u.asset_name = "orb_arcane"
		u.tags.append(Tags.Arcane)
		u.resists[Tags.Arcane] = 100
		u.buffs.append(AssimilationBuff(self))
		if self.get_stat('resist'): u.buffs.append(DamageAssimilationBuff())
		if self.get_stat('master'): u.buffs.append(SpellMasteryBuff())
		apply_minion_bonuses(self, u)
		return u

	def cast(self, x, y):
		existing = next((u for u in self.caster.level.units if u.source is self and u.is_alive()), None)
		if existing:
			if self.caster.level.can_move(existing, x, y, teleport=True):
				self.caster.level.act_move(existing, x, y, teleport=True)
		else:
			self.summon(self.make_orb(), target=Point(x, y))
		yield

class UnravelingDebuff(Buff):

	def on_init(self):
		self.name = "Unraveling"
		self.buff_type = BUFF_TYPE_CURSE
		self.color = Tags.Chaos.color
		self.description = "Takes 33% of max HP as [Fire], [Lightning], or [Physical] damage each turn\nSpreads to adjacent allies on death"
		self.dtypes = [Tags.Fire, Tags.Lightning, Tags.Physical]
		self.owner_triggers[EventOnDeath] = self.on_death

	def on_advance(self):
		dmg = max(self.owner.max_hp // 3, 1)
		self.owner.deal_damage(dmg, random.choice(self.dtypes), self)

	def on_death(self, evt):
		owner = self.owner
		level = owner.level
		for u in level.get_adjacent_units(owner):
			if not are_hostile(owner, u): u.apply_buff(UnravelingDebuff())

class UnravelingDetonationBuff(Buff):

	def __init__(self, radius):
		Buff.__init__(self)
		self.radius = radius

	def on_init(self):
		self.color = Tags.Chaos.color
		self.owner_triggers[EventOnDeath] = self.on_death
		self.name = "Unraveling Detonation"

	def get_tooltip(self):
		return ("On death, afflicts enemies within {radius} tiles with [Unraveling:chaos]", {'radius':self.radius})

	def on_death(self, evt):
		seen = set()
		for p in self.owner.level.get_points_in_ball(self.owner.x, self.owner.y, self.radius):
			unit = self.owner.level.get_unit_at(*p)
			if unit and are_hostile(unit, self.owner): seen.add(unit)
		for u in seen:
			self.owner.level.show_beam(self.owner, u, Tags.Chaos)
			u.apply_buff(UnravelingDebuff())

class UnravelingAuraBuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)

	def on_init(self):
		self.name = "Unraveling Aura"
		self.damage = self.spell.get_stat('minion_damage')
		self.radius = self.spell.get_stat('radius')

		self.destroy_terrain = self.spell.get_stat('destroy_terrain')
		self.terrain_types = ['chasm', 'floor', 'wall']
		if self.spell.get_stat('accelerated_decay'): self.owner_triggers[EventOnDamaged] = self.on_damaged

		self.damage_type = [Tags.Physical, Tags.Fire, Tags.Lightning]

	def on_damaged(self, evt):
		if evt.damage <= 0: return
		self.owner.level.queue_spell(self.trigger_advance())

	def trigger_advance(self):
		self.on_advance()
		yield

	def on_advance(self):
		owner = self.owner
		level = owner.level
		damage = self.damage
		dtypes = self.damage_type

		destroy_terrain = self.destroy_terrain

		for p in self.owner.level.get_points_in_ball(self.owner.x, self.owner.y, self.radius):
			unit = self.owner.level.get_unit_at(p.x, p.y)
			damage_type = random.choice(dtypes)

			if unit:
				if unit == owner: continue
				if not are_hostile(owner, unit): continue
				dealt = unit.deal_damage(damage, damage_type, self)
				if dealt: unit.resists[random.choice(damage_tags)] -= dealt

			else:
				level.show_effect(p.x, p.y, damage_type, minor=True)
				if destroy_terrain and damage_type == Tags.Physical and not level.tiles[p.x][p.y].prop: self.flip_terrain(p)

	def flip_terrain(self, p):
		level = self.owner.level
		tile = level.tiles[p.x][p.y]
		if tile.can_walk: level.make_chasm(tile.x, tile.y)
		elif tile.is_chasm: level.make_wall(tile.x, tile.y)
		elif not tile.can_see: level.make_floor(tile.x, tile.y)

	def can_threaten(self, x, y):
		return distance(self.owner, Point(x, y)) <= self.radius

	def get_tooltip(self):
		return (("Each turn, deal {damage} [Fire], [Lightning], or [Physical] damage to enemies within {radius} tiles\n\n"
				"Damage dealt this way removes that much resistance to a random damage type", {"damage": self.damage, "radius": self.radius}))


class OrbOfUnraveling(Spell):

	def on_init(self):
		self.name = "Orb of Unraveling"
		self.level = 4
		self.tags = [Tags.Orb, Tags.Chaos, Tags.Conjuration]

		self.must_target_empty = True
		self.max_charges = 2
		self.range = 7

		self.radius = 4
		self.minion_health = 100
		self.minion_damage = 5

		self.upgrades['destroy_terrain'] = (1, 2, "World Breaker", "When the Orb of Unraveling deals [Physical] damage to an unoccupied tile, it will warp the terrain, turning floors to chasms, chasms to walls, and walls to floors")
		self.upgrades['detonation'] = (1, 3, "Unraveling Curse", "When the Orb of Unraveling is destroyed, enemies within its radius are afflicted with the [Unraveling:chaos] debuff, which deals [Fire], [Lightning], or [Physical] damage equal to 33% of their max HP each turn\nWhen a creature with the [Unraveling:chaos] debuff dies, it passes to their adjacent allies")
		self.upgrades['accelerated_decay'] = (1, 6, "Accelerated Decay", "When the Orb of Unraveling takes damage, its aura activates")
		self.upgrades[('radius', 'minion_damage')] = ([2, 5], 7, "Locus of Chaos")

		self.add_upgrade_tooltip("Unraveling Curse", UnravelingDebuff)

	def get_description(self):
		return ("Summon an Orb of Unraveling\n"
				"Each turn, the orb deals [Fire], [Lightning], or [Physical] damage to enemies within [{radius}:radius] tiles\n"
				"Damage dealt by orb's aura removes that much resistance to a random damage type\n"
				"Only one Orb of Unraveling may exist at a time\n"
				"Casting this spell while an Orb of Unraveling exists will cause it to teleport to the selected location")

	def get_extra_examine_tooltips(self):
		return [self.make_orb()] + self.get_upgrade_tooltips()

	def make_orb(self):
		u = Orb()
		u.name = "Orb of Unraveling"
		u.asset_name = "orb_chaos"
		u.tags.append(Tags.Chaos)
		u.resists[Tags.Fire] = 100
		u.resists[Tags.Lightning] = 100
		u.resists[Tags.Physical] = 100
		u.buffs.append(UnravelingAuraBuff(self))
		if self.get_stat('detonation'): u.buffs.append(UnravelingDetonationBuff(self.get_stat('radius')))
		apply_minion_bonuses(self, u)
		return u

	def cast(self, x, y):
		existing = next((u for u in self.caster.level.units if u.source is self and u.is_alive()), None)
		if existing:
			if self.caster.level.can_move(existing, x, y, teleport=True):
				self.caster.level.act_move(existing, x, y, teleport=True)
		else:
			self.summon(self.make_orb(), target=Point(x, y))
		yield

class AnimaBuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)

	def on_init(self):
		self.name = "Anima"
		self.num_targets = self.spell.get_stat('num_targets')
		if self.spell.get_stat('offering'): self.global_triggers[EventOnSpendHP] = self.on_spend_hp
		if self.spell.get_stat('reclamation'): self.global_triggers[EventOnDeath] = self.on_death
		self.vengeance = self.spell.get_stat('vengeance')

	def get_tooltip(self):
		return (("Each turn, the Orb of Anima heals up to {num_targets} wounded allies in its line of sight\n\n"
		"The Orb of Anima uses its own HP to heal its allies and will attempt to heal them to full health", {'num_targets':self.num_targets}))

	def on_advance(self):
		owner = self.owner
		candidates = [u for u in owner.level.get_units_in_los(owner) if u.cur_hp < u.max_hp and not are_hostile(owner, u) and not u.has_buff(Poison) and u!=owner]
		if not candidates: return
		level = owner.level
		num = min(len(candidates), self.num_targets)
		to_heal = random.sample(candidates, num)
		for u in to_heal:
			if not owner.cur_hp: break
			level.show_beam(owner, u, Tags.Blood)
			debt = u.max_hp - u.cur_hp
			heal_amt = min(debt, owner.cur_hp)
			u.heal(heal_amt, self)
			owner.cur_hp -= heal_amt
			if self.vengeance: u.apply_buff(BloodrageBuff(1), heal_amt)
		if owner.cur_hp <= 0: owner.kill()

	def on_spend_hp(self, evt):
		if not evt.unit.is_player_controlled: return
		to_heal = evt.hp // 2
		if not to_heal: return
		self.owner.level.show_beam(evt.unit, self.owner, Tags.Blood)
		self.owner.heal(to_heal, self)

	def on_death(self, evt):
		if evt.unit == self.owner: return
		if are_hostile(self.owner, evt.unit): return
		if not self.owner.level.can_see_unit(self.owner, evt.unit): return
		to_heal = evt.unit.max_hp // 2
		if not to_heal: return
		self.owner.max_hp += to_heal
		self.owner.heal(to_heal, self)

class LifeThiefBuff(Buff):

	def __init__(self, dmg, radius):
		self.dmg = dmg
		self.radius = radius
		Buff.__init__(self)

	def on_init(self):
		self.name = "Life Thief"

	def get_description(self):
		return "Each turn, drains up to {dmg} max HP from enemies within {radius} tiles, healing for the amount drained", {'dmg':self.dmg, 'radius':self.radius}

	def on_advance(self):
		owner = self.owner
		dmg = self.dmg
		to_heal = 0
		show_beam = owner.level.show_beam
		for u in owner.level.get_units_in_ball(owner, self.radius):
			if not are_hostile(owner, u): continue
			to_steal = min(u.max_hp - 1, dmg)
			if not to_steal: continue
			u.max_hp -= to_steal
			u.cur_hp = min(u.cur_hp, u.max_hp)
			to_heal += to_steal
			show_beam(u, owner, Tags.Blood, minor=True)

		if to_heal: owner.heal(to_heal, self)

class OrbOfAnima(Spell):

	def on_init(self):
		self.name = "Orb of Anima"
		self.level = 5
		self.tags = [Tags.Orb, Tags.Blood, Tags.Conjuration]

		self.must_target_empty = True
		self.max_charges = 2
		self.range = 7

		self.minion_health = 100
		self.num_targets = 2

		self.upgrades['reclamation'] = (1, 2, "Anima Reclaimed", "When an ally dies while in line of sight of the Orb of Anima, it gains max HP and heals for half the slain unit's max HP")
		self.upgrades['offering'] = (1, 1, "Blood Offerings", "When you pay any amount of HP, the Orb of Anima heals for half that amount")
		self.upgrades['vengeance'] = (1, 4, "Anima's Vengeance", "Units healed by the Orb of Anima gain [Bloodrage:blood] for a number of turns equal to the HP healed")
		self.upgrades[('drain', 'minion_damage', 'radius')] = ([1, 10, 2], 3, "Blood Thief", "Each turn, the Orb of Anima drains up to [{minion_damage}:minion_damage] max HP from enemies within [{radius}:radius] tiles, healing itself for the amount drained")

		self.add_upgrade_tooltip("Anima's Vengeance", self.get_bloodrage_buff)

	def get_description(self):
		return ("Summon an Orb of Anima\n"
				"Each turn, the Orb of Anima heals up to [{num_targets}:num_targets] wounded allies in its line of sight\n"
				"The Orb of Anima uses its own HP to heal its allies and will attempt to heal them to full health\n"
				"Only one Orb of Anima may exist at a time\n"
				"Casting this spell while an Orb of Anima exists will cause it to teleport to the selected location")

	def get_extra_examine_tooltips(self):
		return [self.make_orb()] + self.get_upgrade_tooltips()

	def get_bloodrage_buff(self):
		return BloodrageBuff(1)

	def make_orb(self):
		u = Orb()
		u.name = "Orb of Anima"
		u.asset_name = "orb_blood"
		u.tags.append(Tags.Blood)
		u.buffs.append(AnimaBuff(self))
		if self.get_stat('drain'): u.buffs.append(LifeThiefBuff(self.get_stat('minion_damage'), self.get_stat('radius')))
		apply_minion_bonuses(self, u)
		return u

	def cast(self, x, y):
		existing = next((u for u in self.caster.level.units if u.source is self and u.is_alive()), None)
		if existing:
			if self.caster.level.can_move(existing, x, y, teleport=True):
				self.caster.level.act_move(existing, x, y, teleport=True)
		else:
			self.summon(self.make_orb(), target=Point(x, y))
		yield

class PrismaticBeam(Spell):

	def on_init(self):
		self.name = "Prismatic Beam"
		self.tags = [Tags.Holy, Tags.Ice, Tags.Sorcery]
		self.level = 6
		self.range = 10
		self.num_targets = 4
		self.damage = 40
		self.damage_type = [Tags.Holy]
		self.max_charges = 8

		self.upgrades['arcane'] = (1, 2, "Arcane Refraction", "Prismatic Beam also refracts when it encounters [petrified] or [glassed] units", [Tags.Arcane])
		self.upgrades[('diffusion', 'radius')] = ([1, 2], 3, "Cold Diffusion", "When the beam refracts, it deals [Ice] damage in a [{radius}:radius] tile burst centered on the [frozen] unit")
		self.upgrades['heal'] = (1, 4, "Softened Light", "Prismatic Beam heals allies instead of damaging them")
		self.upgrades['pulse'] = (1, 4, "Prismatic Pulse", "The initial beam is instead a wide pulse which also impacts tiles adjacent to the center beam")


	def get_description(self):
		return ("Deal [{damage}:damage] [Holy] damage in a beam\n"
				"If the beam encounters a [frozen] unit, it refracts, creating up to [{num_targets}:num_targets] more beams which shoot from that unit toward enemies in line of sight of it\n"
				"A beam created by refraction can create half as many beams as the beam that created it")

	def aoe(self, origin, target, is_refraction=False):
		u = self.caster.level.get_unit_at(origin.x, origin.y)
		excluded = {origin}
		if u:
			for p in u.iter_occupied_points():
				excluded.add(p)
		beam = [p for p in self.caster.level.get_points_in_line(origin, target, find_clear=self.get_stat('requires_los')) if p not in excluded]
		pulse = []
		if self.get_stat('pulse') and not is_refraction:
			for p in beam:
				pulse.append(p)
				for q in self.caster.level.get_points_in_ball(p.x, p.y, 1.5):
					if q in excluded: continue
					if q not in pulse: pulse.append(q)
			return pulse

		return beam

	def get_impacted_tiles(self, x, y):
		return self.aoe(self.caster, Point(x, y))

	def cast(self, x, y, origin=None, splits_left=None):
		damage = self.get_stat('damage')
		heal = self.get_stat('heal')
		refract_buffs = (PetrifyBuff, GlassPetrifyBuff, FrozenBuff) if self.get_stat('arcane') else (FrozenBuff,) # isinstance can check all types in a tuple
		diffusion = self.get_stat('diffusion')
		radius = self.get_stat('radius')

		caster = self.caster
		level = caster.level
		getu = level.get_unit_at
		get_units_in_los = level.get_units_in_los
		deal_damage = level.deal_damage
		show_effect = level.show_effect
		target = Point(x, y)

		is_refraction = splits_left is not None
		if splits_left is None: splits_left = self.get_stat('num_targets')
		if origin is None: origin = caster

		recursions = []
		refracted_units = set()

		def handle_point(x, y):
			u = getu(x, y)
			if not u or not u.is_alive(): show_effect(x, y, Tags.Holy); return
			if u not in refracted_units and any(isinstance(b, refract_buffs) for b in u.buffs):
				refracted_units.add(u) # refract once per unit, not once per unit tile hit
				if splits_left > 0:  # if splits left is 0, then no new beams will be created.
					targets = [unit for unit in get_units_in_los(u) if are_hostile(caster, unit) and unit != u and unit.is_alive()]
					num = min(len(targets), splits_left)
					for t in random.sample(targets, num): recursions.append(self.cast(t.x, t.y, origin=u, splits_left=splits_left // 2))

				if diffusion:
					for stage in Burst(level, u, radius, ignore_walls=not self.get_stat('requires_los')):
						for point in stage:
							diffunit = getu(point.x, point.y)
							if not diffunit: show_effect(point.x, point.y, Tags.Ice); continue
							if are_hostile(caster, diffunit) or not heal: deal_damage(point.x, point.y, damage, Tags.Ice, self)
							elif heal: deal_damage(point.x, point.y, -damage, Tags.Heal, self)

			if are_hostile(caster, u) or not heal: deal_damage(x, y, damage, Tags.Holy, self)
			elif heal: deal_damage(x, y, -damage, Tags.Heal, self)

		for p in self.aoe(origin, target, is_refraction=is_refraction):
			handle_point(p.x, p.y)
			yield

		sentinel = object()
		while recursions:
			recursions = [r for r in recursions if next(r, sentinel) is not sentinel]
			yield

class LordOfRot(Upgrade):

	def __init__(self, spell):
		self.spell = spell
		Upgrade.__init__(self, spell)

	def on_init(self):
		self.name = "Lord of Rot"
		self.level = 6
		self.description = "If you would receive the [poison] status or take [Poison] damage, you instead gain a charge of Rot Gaze\nAlways Active"
		self.owner_triggers[EventOnBuffAttemptApply] = self.on_attempt_poison

	def on_attempt_poison(self, evt):
		if isinstance(evt.buff, Poison):
			evt.buff.on_applied = lambda owner: ABORT_BUFF_APPLY
			self.spell.refund_charges(1)

	def on_applied(self, owner):
		def poison_handler(amount, damage_type, source, redirect_chain):
			if damage_type != Tags.Poison: return None # ignore non-poison damage
			self.spell.refund_charges(1)
			self.spell.do_ui_flash(Tags.Poison)
			return 0
		owner.grant_redirect(self, poison_handler)

	def on_unapplied(self):
		self.owner.remove_redirect(self)

class RotGaze(Spell):

	def on_init(self):
		self.name = "Rot Gaze"
		self.level = 3
		self.tags = [Tags.Dark, Tags.Nature,Tags.Eye, Tags.Sorcery]
		self.max_charges = 12
		self.damage = 3
		self.duration = 3
		self.range = 0

		self.upgrades[('flies', 'minion_health', 'minion_damage')] = ([1, 6, 1], 8, "Rot Feast", "Summon a Fly Swarm near each affected enemy", [Tags.Conjuration])
		self.upgrades[('necrosis', 'duration')] = ([1, 6], 1, "Necrotic Gaze", "Inflicts [necrosis] in addition to [poison]")
		self.upgrades['strip'] = (1, 4, "Felling All Foes", "Enemies receive -10% [Dark] and [Poison] resistance before the spell deals damage")
		self.add_upgrade(LordOfRot(self))

		self.add_upgrade_tooltip("Rot Feast", lambda: make_minion(self, FlyCloud))
		self.add_upgrade_tooltip("Felling All Foes", self.get_rotting_buff)

	def get_description(self):
		return "Enemies in line of sight take [{damage}:damage] [Dark] damage and are [poisoned] for [{duration}:duration] turns"

	def get_rotting_buff(self):
		buff = ResistBuff(Tags.Dark, -10)
		buff.name = "Rotting"
		buff.resists[Tags.Poison] = -10
		return buff

	def get_impacted_tiles(self, x, y):
		return [u for u in self.caster.level.get_units_in_los(self.caster) if are_hostile(self.caster, u)]

	def cast(self, x, y):
		damage = self.get_stat('damage')
		duration = self.get_stat('duration')
		strip = self.get_stat('strip')
		flies = self.get_stat('flies')
		necrosis = self.get_stat('necrosis')

		caster = self.caster
		level = caster.level
		showbeam = level.show_beam

		for u in level.get_units_in_los(caster):
			if not are_hostile(u, caster): continue
			showbeam(caster, u, Tags.Dark)
			if strip: u.apply_buff(self.get_rotting_buff())
			u.deal_damage(damage, Tags.Dark, self)
			u.apply_buff(Poison(), duration)
			if necrosis: u.apply_buff(NecrosisBuff(), duration)
			if flies: self.summon(make_minion(self, FlyCloud), u)
			yield

class WallOfFlameBuff(Buff):

	def __init__(self, spell, connected_targets):
		self.spell = spell
		self.damage = spell.get_stat('damage')

		Buff.__init__(self)
		self.stack_type = STACK_REPLACE
		self.connected_targets = connected_targets
		self.name = "Wall of Flame"
		self.color = Tags.Fire.color

		if spell.get_stat('feed'): self.global_triggers[EventOnDeath] = self.on_death

	def on_advance(self):
		for p in self.connected_targets: self.owner.level.deal_damage(p.x, p.y, self.damage, Tags.Fire, self.spell)

	def on_death(self, evt):
		if not evt.damage_event: return
		if evt.damage_event.source == self.spell and self.turns_left != 0: self.turns_left += 1

class WallOfFlame(Spell):

	def on_init(self):
		self.name = "Wall of Flame"
		self.tags = [Tags.Fire, Tags.Sorcery]
		self.level = 7
		self.max_charges = 4
		self.range = 6
		self.radius = 3
		self.duration = 8
		self.damage = 30

		self.upgrades['feed'] = (1, 2, "Feed the Flames", "Wall of Flames' remaining duration increases by 1 when it kills a unit")
		self.upgrades['thick'] = (1, 4, "Thickened Wall", "Wall of Flame is now 3 tiles thick instead of a line")
		self.upgrades['box'] = (1, 6, "Fortress of Flame", "Affects tiles in lines rotated around the caster, forming a square")
		self.upgrades['pillar'] = (1, 9, "Flames of Heaven", "When you cast Wall of Flame, cast Pillar of Fire on each affected tile", [Tags.Holy])

	def get_description(self):
		return ("Create a [{width} tile:radius] line of flames perpendicular to the caster\n"
				"The flames deal [{damage}:damage] [Fire] damage in the affected tiles each turn\n"
				"Only a single Wall of Flame can be maintained at a time\n"
				"Casting the spell again removes the previous wall\n"
				"Lasts [{duration}:duration] turns")

	def fmt_dict(self):
		d = Spell.fmt_dict(self)
		d['width'] = 1 + 2*d['radius']
		return d

	def get_impacted_tiles(self, x, y):
		caster = self.caster
		level = caster.level
		length = self.get_stat('radius')
		thick = self.get_stat('thick')

		dx, dy = x - caster.x, y - caster.y
		rotations = [(dx, dy)]
		if self.get_stat('box'): rotations += [(-dy, dx), (-dx, -dy), (dy, -dx)]
		pts = []
		for vx, vy in rotations:
			dest = Point(caster.x + vx, caster.y + vy)
			line = level.get_perpendicular_line(caster, dest, length=length)
			if not thick: pts.extend(line)
			else:
				result = set()
				for p in line:
					for q in level.get_points_in_rect(p.x-1, p.y-1, p.x+1, p.y+1):
						result.add(q)
				pts.extend(result)
		return list(dict.fromkeys(pts))

	def cast(self, x, y):
		self.caster.apply_buff(WallOfFlameBuff(self, self.get_impacted_tiles(x, y)), self.get_stat('duration'))
		if self.get_stat('pillar'):
			s = self.caster.get_or_make_spell(FlameStrikeSpell)
			for p in self.get_impacted_tiles(x, y):
				self.caster.level.act_cast(self.caster, s, p.x, p.y, pay_costs=False)
				yield

class DivineRebuke(Upgrade):

	def __init__(self, spell):
		self.spell = spell
		Upgrade.__init__(self, spell)

	def on_init(self):
		self.level = 3
		self.name = "Divine Rebuke"
		self.description = "Each turn, cast Sanction on the first unsanctioned enemy that damages you\nAlways Active"
		self.owner_triggers[EventOnDamaged] = self.on_damaged
		self.triggered = False

	def on_damaged(self, evt):
		if self.triggered: return
		if evt.damage <= 0: return
		if not evt.source: return
		if not evt.source.owner: return
		if not are_hostile(evt.source.owner, self.owner): return
		if evt.source.owner.has_buff(SanctionBuff): return
		self.owner.level.queue_spell(self.sanction(evt.source.owner))

	def on_advance(self):
		self.triggered = False

	def sanction(self, unit):
		if self.triggered: return
		if not unit.is_alive(): return
		for _ in self.owner.level.act_cast(self.owner, self.spell, unit.x, unit.y, pay_costs=False, queue=False): yield
		self.triggered = True
		yield

class SanctionBuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)
		self.damage = spell.get_stat('damage')
		self.name = "Sanctioned"
		self.color = Tags.Holy.color
		self.stack_type = STACK_INTENSITY
		self.buff_type = BUFF_TYPE_CURSE
		self.do_strip = self.spell.get_stat('strip')
		self.owner_triggers[EventOnSpellCast] = self.on_cast
		self.owner_triggers[EventOnDamaged] = self.on_damaged
		self.asset = ['status', 'sanction']

	def get_description(self):
		desc = "Deals [{damage}:damage] [Holy] damage when the owner casts a spell or takes [Holy] damage from another source\nHeals the inflictor 1 HP when it deals damage"
		if self.do_strip: desc += "\nRemoves all positive resistances"
		return (desc, {'damage': self.damage})

	def on_applied(self, owner):
		if self.do_strip:
			for tag, val in owner.resists.items():
				if val <= 0: continue
				self.resists[tag] = -val

	def on_cast(self, evt):
		self.owner.deal_damage(self.damage, Tags.Holy, self.spell)
		self.spell.caster.heal(1, self.spell)

	def on_damaged(self, evt):
		if evt.source == self.spell: return
		if evt.damage_type != Tags.Holy: return
		self.owner.deal_damage(self.damage, Tags.Holy, self.spell)
		self.spell.caster.heal(1, self.spell)


class Sanction(Spell):

	def on_init(self):
		self.name = "Sanction"
		self.level = 6
		self.tags = [Tags.Blood, Tags.Holy, Tags.Enchantment]

		self.range = RANGE_GLOBAL
		self.requires_los = False
		self.can_target_empty = False

		self.max_charges = 10
		self.hp_cost = 10
		self.damage = 30


		self.upgrades[('exile', 'duration')] = ([1, 5], 3, "Exiled One", "Sanctioned units are [berserked] for [{duration}:duration] turns")
		self.upgrades[('mass', 'num_targets')] = ([1, 4], 4, "Mass Sanction", "Sanction affects up to [{num_targets}:num_targets] enemies in a connected group")
		self.upgrades['strip'] = (1, 6, "Stripped Bare", "Sanction reduces all resistances to 0")
		self.add_upgrade(DivineRebuke(self))


	def get_description(self):
		return ("Sanction the target\n"
				"Sanction deals [{damage}:damage] [Holy] damage to the cursed unit when they cast a spell or take [Holy] damage from another source\n"
				"You are healed for 1 HP when Sanction deals damage")

	def get_extra_examine_tooltips(self):
		return [SanctionBuff(self)] + self.get_upgrade_tooltips()


	def get_impacted_tiles(self, x, y):
		targets = []
		if self.get_stat('mass'):
			for target in self.caster.level.get_connected_group_from_point(x, y, check_hostile=self.caster, num_targets=self.get_stat('num_targets')):
				targets.append(target)
		else:
			unit = self.caster.level.get_unit_at(x, y)
			if unit: targets.append(unit)
		return targets

	def cast_instant(self, x, y):
		targets = self.get_impacted_tiles(x, y)
		exile = self.get_stat('exile')
		dur = self.get_stat('duration')
		for target in targets:
			target.apply_buff(SanctionBuff(self))
			if exile: target.apply_buff(BerserkBuff(), dur)

class Miasma(Spell):

	def on_init(self):
		self.name = "Miasma"
		self.level = 6
		self.tags = [Tags.Dark, Tags.Nature, Tags.Sorcery]
		self.damage_type = [Tags.Poison]

		self.max_charges = 3
		self.max_channel = 4
		self.radius = 3
		self.duration = 6
		self.damage = 10
		self.range = RANGE_GLOBAL
		self.requires_los = False

		self.growth = 0
		self.growth_rate = 1
		self.stats.append('growth_rate')

		self.upgrades['corrupt'] = (1, 4, "Consumptive Vapors", "Miasma also inflicts [necrosis] and [bleed]")
		self.upgrades['ritual'] = (1, 3, "Ritual of Suffocation", "If the ritual is completed, all [poisoned] enemies on the level take [{damage}:damage] [Dark] and [Poison] damage", [Tags.Ritual], [Tags.Dark], {'damage':30})
		self.upgrades['growth_rate'] = (1, 4, "Rapid Growth", "Miasma's radius expands twice as fast")
		self.upgrades['plague'] = (1, 8, "Plague Bringer", "Cast Rot Gaze for free each turn you channel Miasma")

	def get_description(self):
		return ("Create an expanding area of miasma in a [{radius}:radius] tile burst at the target location\n"
				"Enemies in affected tiles take [{damage}:damage] [Poison] damage and are afflicted with [blind], [silence], and [poison] for [{duration}:duration] turns\n"
				"Each turn spent channeling increases the radius of the affected area by {growth_rate}")

	def can_cast(self, x, y):
		if self.caster.level.tiles[x][y].is_wall(): return False
		return Spell.can_cast(self, x, y)

	def get_impacted_tiles(self, x, y):
		for stage in Burst(self.caster.level, Point(x, y), self.get_stat('radius'), ignore_walls=not self.get_stat('requires_los')):
			for p in stage:
				yield p

	def cast(self, x, y, channel_cast=False):
		if not channel_cast and self.is_manual_cast():
			self.caster.apply_buff(ChannelBuff(self.cast, Point(x, y)), self.get_stat('max_channel'))
			self.growth = 0
			return

		level = self.caster.level
		tiles = level.tiles
		effective_radius = self.get_stat('radius') + self.growth
		duration = self.get_stat('duration')
		dmg = self.get_stat('damage')
		suffocation_dmg = self.get_stat('damage', base=30)
		seen = {None}

		if self.get_stat('corrupt'): debuffs = [Poison, Silence, BlindBuff, NecrosisBuff, BleedBuff]
		else: debuffs = [Poison, Silence, BlindBuff]

		for stage in Burst(level, Point(x, y), effective_radius, ignore_walls=not self.get_stat('requires_los')):
			for point in stage:
				level.show_effect(point.x, point.y, Tags.Poison)
				tile = tiles[point.x][point.y]
				if tile.chasm_type == 'water':
					level.set_tile_style(tile, tile.tileset, 'swamp')
				u = level.get_unit_at(point.x, point.y)
				if u not in seen and are_hostile(self.caster, u):
					for b in debuffs: u.apply_buff(b(), duration)
					u.deal_damage(dmg, Tags.Poison, self)

		channel_buff = self.caster.get_buff(ChannelBuff)
		if channel_buff:
			channel_buff.connected_targets = []
			for stage in Burst(level, Point(x, y), effective_radius + self.get_stat('growth_rate'), ignore_walls=not self.get_stat('requires_los')):
				for point in stage:
					channel_buff.connected_targets.append(point) # map out the next turn's impact zone

		self.growth += self.get_stat('growth_rate')

		completed = channel_cast and self.get_stat('ritual') and not channel_buff
		if completed:
			units = [u for u in level.units if are_hostile(u, self.caster) and u.has_buff(Poison)]
			for u in units:
				u.deal_damage(suffocation_dmg, Tags.Poison, self)
				u.deal_damage(suffocation_dmg, Tags.Dark, self)


		if self.get_stat('plague'):
			level.act_cast(self.caster, self.caster.get_or_make_spell(RotGaze), self.caster.x, self.caster.y, pay_costs=False)

		yield


class Torrent(Spell):

	def on_init(self):
		self.name = "Torrent"
		self.level = 3
		self.tags = [Tags.Nature, Tags.Sorcery]

		self.max_charges = 8
		self.range = 3
		self.cast_on_walls = True
		self.max_channel = 6
		self.damage = 22
		self.duration = 6
		self.damage_type = [Tags.Physical]

		self.clear_channel_state()

		self.upgrades['rubble'] = (1, 2, "Dangerous Debris", "When Torrent destroys a wall, adjacent units take [{damage}:damage] [Physical] damage and are [stunned] for [{duration}:duration] turns\nWill not affect the caster", None, None, {'damage':22, 'duration':3})
		self.upgrades['bend'] = (1, 3, "Water Bend", "If you cast Torrent while adjacent to a water or swamp chasm, it will lengthen twice as much each turn\nAlso works with lava chasms if you have the Boiling Torrent upgrade")
		self.upgrades['boil'] = (1, 4, "Boiling Torrent", "Torrent's waters also deal [Fire] damage", [Tags.Fire], [Tags.Fire])
		self.upgrades[('ritual', 'minion_health', 'minion_damage')] = ([1, 23, 5], 7, "Ritual of Carcinization", "If you complete the ritual, summon a Scuttler in each unoccupied affected floor tile", [Tags.Conjuration, Tags.Ritual])

		self.add_upgrade_tooltip("Ritual of Carcinization", lambda: make_minion(self, Scuttler))

	def get_description(self):
		return ("Channel a 3 tile wide beam of water that lengthens by 1 each turn\n"
				"Affected units take [{damage}:damage] [Physical] damage, are Soaked for [{duration}:duration] turns, and are pushed 1 tile away\n"
				"Can target and destroy walls\n"
				"Can be channeled for up to [{max_channel}:max_channel] turns")

	def aoe(self, x, y, center_line=None):
		if center_line is not None: line = center_line
		else: line = self.caster.level.get_points_in_line(self.caster, Point(x, y), two_pass=False, find_clear=False, no_diag=False)[1:]
		beam = set()
		for p in line:
			for q in self.caster.level.get_points_in_ball(p.x, p.y, 1.5):
				if q.x == self.caster.x and q.y == self.caster.y: continue
				beam.add(q)
		return list(beam)

	def get_impacted_tiles(self, x, y):
		return self.aoe(x, y)

	def clear_channel_state(self):
		self.center_line = None
		self.base_len = None
		self.stage = 0
		self.origin = None

	def do_summon(self, p):
		self.summon(make_minion(self, Scuttler), target=p, radius=0)
		yield

	def orient(self, x, y):
		base = self.caster.level.get_points_in_line(self.caster, Point(x, y), two_pass=False, find_clear=False, no_diag=False, inclusive=True)
		extended = self.caster.level.get_extended_path(self.caster, Point(x, y), two_pass=False, find_clear=False,  no_diag=False, inclusive=True)
		self.center_line = extended[1:]
		self.base_len = len(base) - 1

	def cast(self, x, y, channel_cast=False):
		if not channel_cast and self.is_manual_cast():
			self.caster.apply_buff(ChannelBuff(self.cast, Point(x, y), on_failure=self.clear_channel_state), self.get_stat('max_channel'))
			self.orient(x, y)
			self.stage = 0
			self.origin = Point(self.caster.x, self.caster.y)
			return

		caster = self.caster
		level = caster.level

		# if we are channeling but we've been moved, re-orient on the original cast location
		if channel_cast and self.center_line is not None and self.base_len is not None and self.origin is not None:
			if caster.x != self.origin.x or caster.y != self.origin.y:
				self.orient(x, y)
				self.origin = Point(caster.x, caster.y)

		center = None
		if channel_cast and self.center_line is not None and self.base_len is not None:
			length = min(len(self.center_line), self.base_len + self.stage)
			center = self.center_line[:length]
			self.stage += 1
			if self.get_stat('bend'):
				boil = self.get_stat('boil')
				for p in level.get_adjacent_points(caster, filter_walkable=False, check_unit=False, r=caster.radius):
					if level.tiles[p.x][p.y].is_chasm:
						if level.tiles[p.x][p.y].chasm_type != 'lava' or boil:
							self.stage += 1
							break

		damage = self.get_stat('damage')
		duration = self.get_stat('duration')

		dtypes = self.get_stat('damage_type')

		rubble = self.get_stat('rubble')
		stun_dur = self.get_stat('duration', base=3)

		ritual_complete = self.get_stat('ritual') and channel_cast and not caster.has_buff(ChannelBuff)

		deal_damage = level.deal_damage
		getu = level.get_unit_at
		show_effect = level.show_effect
		make_floor = level.make_floor
		tiles = level.tiles

		for p in self.aoe(x, y, center):
			for dtype in dtypes: deal_damage(p.x, p.y, damage, dtype, self, flash=False)

			if tiles[p.x][p.y].is_wall():
				make_floor(p.x, p.y)
				if rubble:
					for q in level.get_adjacent_points(p, filter_walkable=False):
						u = getu(q.x, q.y)
						if u and u != caster:
							deal_damage(q.x, q.y, damage, Tags.Physical, self)
							u.apply_buff(Stun(), stun_dur)

			show_effect(p.x, p.y, Tags.Water)
			u = getu(p.x, p.y)
			if u:
				u.apply_buff(SoakedBuff(), duration)
				push(u, caster, 1)
			if ritual_complete and level.tiles[p.x][p.y].can_walk and not getu(p.x, p.y):
				level.queue_spell(self.do_summon(p))
		yield

		if channel_cast and not caster.has_buff(ChannelBuff): self.clear_channel_state()

class DemonFormBuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)
		self.stack_type = STACK_TYPE_TRANSFORM
		self.transform_asset = ["char", "player_demon"]

	def on_init(self):
		self.name = "Demon Form"
		self.color = Tags.Chaos.color

		self.siphon = self.spell.get_stat('siphon')
		self.imps = self.spell.get_stat('imps')
		if self.siphon: self.global_triggers[EventOnDamaged] = self.on_damage
		if self.imps: self.global_triggers[EventOnDeath] = self.on_death
		self.chaos_types = [Tags.Physical, Tags.Lightning, Tags.Fire]
		for dt in self.chaos_types: self.resists[dt] = 50
		self.resists[Tags.Dark] = 100

	def get_description(self):
		desc = "Gain flying\nEach turn, your other [Chaos] spells regain 1 charge"
		if self.siphon:
			desc += "\nWhen another unit takes [Dark] damage, it loses 1 max HP and you heal 1 HP"
			desc += "\nIf your HP is full, gain 1 [SH:shields] instead"
		if self.imps:
			desc += "\nWhen an enemy is slain by [Fire], [Lightning], or [Physical] damage, summon a Chaos Imp at its location"
		desc += "\nIf you lose this buff while over a chasm, unless you have other methods of flight, you will be deposited at the nearest valid tile"
		desc += "\nIf no such tile exists, fall to your death"
		return desc

	def on_applied(self, owner):
		owner.flying += 1

	def on_unapplied(self):
		self.owner.flying -= 1
		if not self.owner.level.can_stand(self.owner.x, self.owner.y, self.owner): self.owner.level.queue_spell(self.place(self.owner))

	def on_advance(self):
		for s in self.owner.spells:
			if Tags.Chaos in s.tags:
				if s == self.spell: continue
				s.refund_charges(1)
				s.do_ui_flash(Tags.Chaos)

	def place(self, o):
		if o.flying: return  # if they somehow got flying from another source in the meantime, cancel
		path = o.level.find_shortest_path_to_nearest_valid_tile(o.x, o.y, o)
		if not path: o.kill(); return
		for point in path: o.level.leap_effect(point.x, point.y, Tags.Demon.color, o)
		o.level.act_move(o, path[-1].x, path[-1].y, teleport=True)
		yield

	def on_death(self, evt):
		if evt.damage_event and evt.damage_event.damage_type in self.chaos_types:
			if are_hostile(evt.unit, self.owner):
				self.spell.summon(self.spell.make_imp(), target=evt.unit)

	def on_damage(self, evt):
		if evt.damage_type != Tags.Dark: return
		if evt.unit == self.owner: return
		if evt.unit.max_hp < 2: return
		evt.unit.max_hp -= 1
		if self.owner.cur_hp == self.owner.max_hp: self.owner.add_shields(1)
		else: self.owner.heal(1, self)


class DemonFormSpell(Spell):

	def on_init(self):
		self.name = "Demon Form"
		self.level = 7
		self.tags = [Tags.Chaos, Tags.Enchantment]

		self.max_charges = 1
		self.duration = 12
		self.range = 0

		self.upgrades[('imps', 'minion_health', 'minion_damage', 'minion_range', 'minion_duration')] = ([1, 12, 6, 3, 7], 6, "Chaos Summoner", "When an enemy is slain by [Fire], [Lightning], or [Physical] damage, summon a Chaos Imp at their location", [Tags.Conjuration])
		self.upgrades['siphon'] = (1, 6, "Soul Hunger", "While in Demon Form, when another unit takes [Dark] damage they lose 1 max HP and you heal 1 HP\nIf your health is already full, gain 1 [SH:shields] instead", [Tags.Dark])
		self.upgrades['ultimate'] = (1, 8, "Ultimate Form", "Casting Demon Form first casts your other self-targeted [Enchantment] spells")
		self.upgrades['royal'] = (1, 9, "Demonic Royalty", "When you cast this spell, [Demons:demon] in your line of sight with less HP than you join your team")
		self.add_upgrade_tooltip("Chaos Summoner", self.make_imp)

	def get_description(self):
		return ("Transform into a flying [Demon]\n"
				"Each turn, your other [Chaos] spells regain 1 charge\n"
				"Gain [100 Dark:dark], [50 Physical:physical], [50 Fire:fire], and [50 Lightning:lightning] resistance\n"
				"Lasts [{duration}:duration] turns")

	def get_extra_examine_tooltips(self):
		return [DemonFormBuff(self)] + self.get_upgrade_tooltips()

	def cast(self, x, y):
		if self.get_stat('ultimate'):
			spells = [s for s in self.caster.spells if s.range == 0 and Tags.Enchantment in s.tags and s != self]
			for s in spells:
				for _ in self.caster.level.act_cast(self.caster, s, self.caster.x, self.caster.y, pay_costs=False, queue=False):
					yield

		self.caster.apply_buff(DemonFormBuff(self), self.get_stat('duration'))

		if self.get_stat('royal'):
			demons = [u for u in self.caster.level.get_units_in_los(self.caster) if Tags.Demon in u.tags and u.cur_hp < self.caster.cur_hp and u.team != self.caster.team]
			for u in demons:
				u.team = TEAM_PLAYER
				yield from self.caster.level.show_path_effect(self.caster, u, Tags.Chaos, pause_frames=1)

		yield

	def make_imp(self):
		return make_minion(self, ChaosImp)

class ArcaneWardingBuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)

	def on_init(self):
		self.name = "Arcane Warding"
		self.color = Tags.Arcane.color
		self.stack_type = STACK_REPLACE # so you can get an upgrade updated one if you buy upgrade then recast
		self.shields = self.spell.get_stat('shields')
		self.amp = self.spell.get_stat('amp')
		self.absorb = self.spell.get_stat('absorb')
		self.transmute = self.spell.get_stat('transmute')
		self.cycle = self.spell.get_stat('cycle')
		self.owner_triggers[EventOnPreDamaged] = self.on_pre_damaged

	def get_description(self):
		desc = ("Each turn, gain [{shields} SH:shields]\n"
				"When enemy damage is blocked by your shields, reflect that damage to the source")
		if self.absorb:
			desc += "\nWhen Arcane Warding reflects damage, heal half the blocked damage"
		if self.transmute:
			desc += "\nReflected damage uses a type the attacker is most vulnerable to"
		if self.amp:
			desc += "\nRelfected damage is double the blocked damage"
		if self.cycle:
			desc += "\nIf Arcane Warding kills a unit, extend its duration by 3 turns"
		return (desc, {'shields': self.shields})

	def on_advance(self):
		self.owner.add_shields(self.shields)

	def on_pre_damaged(self, evt):
		if evt.unresisted_damage <= 0: return # healing or completely resisted, ignore
		if not self.owner.shields: return # no shields, ignore
		if not isinstance(evt.source.owner, Unit): return # do nothing if it didn't come from a unit
		if not are_hostile(evt.source.owner, self.owner): return # do nothing if the unit was friendly
		self.owner.level.queue_spell(self.do_warding(evt))

	def do_warding(self, evt):
		if self.absorb: self.owner.heal(evt.damage//2, self)
		if not evt.source.owner.is_alive(): return # something already killed them, get out

		if self.transmute:
			lowest_res = min(evt.source.owner.resists.get(t, 0) for t in damage_tags)
			candidates = [t for t in damage_tags if evt.source.owner.resists.get(t, 0) == lowest_res]
			dt = random.choice(candidates)
		else: dt = evt.damage_type

		self.owner.level.show_beam(self.owner, evt.source.owner, dt, minor=True)
		mult = 2 if self.amp else 1
		self.owner.level.deal_damage(evt.source.owner.x, evt.source.owner.y, evt.damage * mult, dt, self.spell)
		yield
		if self.cycle:
			for _ in range(3): yield
			if not evt.source.owner.is_alive():
				self.owner.level.show_beam(evt.source.owner, self.owner, Tags.Dark, minor=True)
				self.turns_left += 3

class ArcaneWardingSpell(Spell):

	def on_init(self):
		self.name = "Arcane Warding"
		self.tags = [Tags.Arcane, Tags.Enchantment]
		self.level = 4
		self.range = 0
		self.max_charges = 2
		self.duration = 8
		self.shields = 3
		self.stats.append('shields')

		self.upgrades['transmute'] = (1, 3, "Transmutation Ward", "Instead of reflecting the same damage type, the damage type will instead be of a type that the targeted unit is most vulnerable to", [Tags.Chaos])
		self.upgrades['amp'] = (1, 4, "Amplifier Ward", "Arcane Ward deals twice as much damage as the blocked hit")
		self.upgrades['cycle'] = (1, 3, "Soul Thief", "If Arcane Ward kills a unit, it extends its remaining duration by 3", [Tags.Dark])
		self.upgrades['absorb'] = (1, 5, "Energy Absorber", "In addition to reflecting damage back at the attacker, heal for half the incoming damage")

	def get_description(self):
		return ("Each turn, gain [{shields} SH:shields]\n"
				"When enemy damage is blocked by your shields, reflect that damage to the source\n"
				"Lasts [{duration}:duration] turns")

	def cast_instant(self, x, y):
		self.caster.apply_buff(ArcaneWardingBuff(self), self.get_stat('duration'))

	def get_extra_examine_tooltips(self):
		return [ArcaneWardingBuff(self)] + self.get_upgrade_tooltips()

class BlackHoleSpell(Spell):

	def on_init(self):
		self.name = "Black Hole"
		self.tags = [Tags.Arcane, Tags.Sorcery, Tags.Translocation]
		self.level = 6
		self.range = 6
		self.max_charges = 2

		self.upgrades[('singularity', 'damage')] = ([1, 300], 3, "Singularity Crush", "Deal [{damage}:damage] [Physical] damage to the unit at the target tile after units have been teleported")
		self.upgrades[('freeze', 'radius', 'duration')] = ([1, 2, 3], 5, "Heat Death", "Enemies within [{radius}:radius] tiles of the target are [frozen] for [{duration}:duration] turns", [Tags.Ice])
		self.upgrades[('max_charges', 'range', 'requires_los')] = ([10, 10, -1], 6, "Cosmic Grasp")
		self.upgrades['quake'] = (1, 8, "Environmental Destruction", "Black Hole first casts Earthquake centered on the target before teleporting", [Tags.Nature])


	def get_description(self):
		return "Enemies in line of sight of the target are teleported as close as they can be toward it"

	def get_impacted_tiles(self, x, y):
		caster = self.caster
		return [u for u in caster.level.get_units_in_los(Point(x, y)) if are_hostile(caster, u)]

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		show_beam = level.show_beam
		target = Point(x, y)

		if self.get_stat('quake'):
			for _ in level.act_cast(caster, caster.get_or_make_spell(EarthquakeSpell), x, y, pay_costs=False, queue=False):
				yield

		units = [u for u in level.get_units_in_los(target) if are_hostile(caster, u)]
		can_stand = level.can_stand
		act_move = level.act_move
		rings = points_in_ring_at_center_cache[x][y]
		max_ring = MAX_RING_RADIUS

		for u in units:
			dest = None
			for r in range(max_ring + 1):
				for p in rings[r]:
					if not can_stand(p.x, p.y, u): continue
					dest = p
					break
				if dest: break

			if not dest: continue
			if dest.x == u.x and dest.y == u.y: continue
			show_beam(u, dest, Tags.Translocation, minor=True, inclusive=True)
			act_move(u, dest.x, dest.y, teleport=True)
			yield

		if self.get_stat('singularity'): level.deal_damage(x, y, self.get_stat('damage'), Tags.Physical, self)
		if self.get_stat('freeze'):
			dur = self.get_stat('duration')
			for u in level.get_units_in_ball(target, self.get_stat('radius')):
				if not are_hostile(caster, u): continue
				u.apply_buff(FrozenBuff(), dur)

class EarthenPassage(Spell):

	def on_init(self):
		self.name = "Earthen Passage"
		self.tags = [Tags.Nature, Tags.Sorcery, Tags.Translocation]
		self.level = 2
		self.max_charges = 8
		self.range = 99
		self.requires_los = False

		self.upgrades[('stone', 'shields')] = ([1, 3], 1, "Mineral Shielding", "Casting Earthen Passage grants [{shields} SH:shields]", [Tags.Metallic])
		self.upgrades['guard'] = (1, 2, "Guarded Entrance", "Casts your Earthen Sentinel spell on your original location")
		self.upgrades['mover'] = (1, 6, "Earthen Prison", "Enemies adjacent to your destination are entombed in stone\n\nUnoccupied tiles adjacent to the connected group of enemies become walls")
		self.upgrades[('fish', 'num_summons', 'minion_health', 'minion_damage', 'minion_range')] = ([1, 3, 75, 4, 3], 7, "Stonefisher", "Summon [{num_summons}:num_summons] Stonefish near the target", [Tags.Conjuration])
		self.add_upgrade_tooltip("Stonefisher", lambda: make_minion(self, StoneFish))

	def get_description(self):
		return ("Teleport through a connected group of walls, teleporting to any tile adjacent to the group\n"
				"Can only be cast while adjacent to a wall")


	def get_mover_outline(self, x, y):
		level = self.caster.level
		candidates = set()
		unit_group = set()

		for p in level.get_adjacent_points(Point(x, y), False, False):
			unit = level.get_unit_at(p.x, p.y)
			if not unit or not are_hostile(self.caster, unit): continue
			candidates.add(unit)

		while candidates:
			unit = candidates.pop()
			if unit in unit_group or not are_hostile(self.caster, unit): continue
			unit_group.add(unit)

			for adjacent_unit in level.get_adjacent_units(unit):
				if adjacent_unit not in unit_group: candidates.add(adjacent_unit)

		outline = set()
		for unit in unit_group:
			for q in unit.iter_occupied_points():
				for p in level.get_adjacent_points(Point(q.x, q.y), False, False):
					tile = level.tiles[p.x][p.y]
					if tile.unit or tile.prop or not tile.can_see: continue
					outline.add(p)

		return outline

	def get_impacted_tiles(self, x, y):
		impacted = {Point(x, y)}
		if not self.get_stat('mover'): return list(impacted)
		outline = self.get_mover_outline(x, y)
		impacted |= outline
		return list(impacted)

	def get_targetable_tiles(self):
		caster = self.caster
		level = caster.level
		cast_points = self.get_cast_points()
		if not cast_points: return []
		return [p for p in cast_points if level.can_stand(p.x, p.y, caster) and Spell.can_cast(self, p.x, p.y)]

	def get_cast_points(self):
		caster = self.caster
		level = caster.level
		tiles = level.tiles

		start_walls = {p for p in level.get_adjacent_points(caster, False, False) if not tiles[p.x][p.y].can_see}
		if not start_walls: return set()

		wall_points = start_walls
		frontier = list(start_walls)
		while frontier:
			point = frontier.pop()
			for p in level.get_adjacent_points(point, False, False):
				if p in wall_points: continue
				if not tiles[p.x][p.y].can_see:
					wall_points.add(p)
					frontier.append(p)

		cast_points = set()
		for point in wall_points:
			for p in level.get_adjacent_points(point, False, False):
				cast_points.add(p)

		return cast_points

	def can_cast(self, x, y):
		caster = self.caster
		level = caster.level
		tiles = level.tiles

		# make sure they can land where they're going
		if not level.can_stand(x, y, caster): return False

		# make sure where they start is next to a wall
		next_to_wall = False
		for t in level.get_adjacent_points(caster, False, False):
			if not tiles[t.x][t.y].can_see:
				next_to_wall = True
				break
		if not next_to_wall: return False

		# make sure the destination is coming out of the contiguous wall group
		if Point(x, y) not in self.get_cast_points(): return False

		return Spell.can_cast(self, x, y)

	def cast_instant(self, x, y):
		if not self.can_cast(x, y): return
		caster = self.caster
		origin = Point(caster.x, caster.y)
		target = Point(x, y)
		level = caster.level
		if not level.can_move(caster, x, y, teleport=True): return
		level.show_beam(origin, target, Tags.Nature, minor=True) # get a different effect here?
		level.act_move(caster, x, y, teleport=True)
		if self.get_stat('stone'): caster.add_shields(self.get_stat('shields'))
		if self.get_stat('guard'): level.act_cast(caster, caster.get_or_make_spell(SummonEarthElemental), origin.x, origin.y, pay_costs=False)

		if self.get_stat('mover'):
			for p in self.get_mover_outline(x, y):
				tile = level.tiles[p.x][p.y]
				if tile.unit or tile.prop or not tile.can_see: continue
				level.make_wall(p.x, p.y)

		if self.get_stat('fish'):
			for _ in range(self.get_stat('num_summons')):
				self.summon(make_minion(self, StoneFish), target=target)

class SummonLeghead(Spell):

	def on_init(self):
		self.name = "Leghead"
		self.level = 4
		self.max_charges = 3
		self.range = 3
		self.tags = [Tags.Arcane, Tags.Dark, Tags.Conjuration, Tags.Translocation]

		self.must_target_walkable = True
		self.must_target_empty = True
		self.target_empty = True

		self.minion_health = 45
		self.shields = 3
		self.minion_damage = 12

		self.upgrades[('rabid', 'duration')] = ([1, 3], 2, "Rabid Bite", "Leghead's bite attack also inflicts [{duration}:duration] turns of [berserk]")
		self.upgrades['running_start'] = (1, 5, "Running Start", "Leghead takes 3 turns immediately when summoned")
		self.upgrades['mismatch'] = (1, 6, "Mismatch", "Leghead is equipped with two different pairs of your footwear")
		self.upgrades['juggernaut'] = (1, 7, "Unstoppable Juggernaut", "Leghead is immune to debuffs")

	def get_description(self):
		return "Summon a Leghead\nIt is equipped with a copy of your footwear if you own any"

	def get_extra_examine_tooltips(self):
		return [self.get_leghead()] + self.get_upgrade_tooltips()

	def get_leghead(self):
		u = Leghead()
		if self.get_stat('rabid'):
			dur = self.get_stat('duration')
			def do_berserk(caster, target): target.apply_buff(BerserkBuff(), dur)
			onhit_desc = ("Apply [berserk] for {dur} turns", {'dur': dur})
			u.spells = [SimpleMeleeAttack(damage=12, buff=FearBuff, buff_duration=1, onhit=do_berserk, onhit_description=onhit_desc)]
		apply_minion_bonuses(self, u)
		if self.get_stat('juggernaut'): u.debuff_immune = True
		if self.caster:
			boots = [i for i in self.caster.equipment if i.slot == SLOT_BOOTS]
			if boots: u.asset_name = 'leghead_ally'
		return u

	def cast(self, x, y):
		u = self.get_leghead()
		boots = [i for i in self.caster.equipment if i.slot == SLOT_BOOTS]
		num = 2 if self.get_stat('mismatch') else 1
		u = self.summon(u, Point(x, y))
		if not u: return
		for b in boots[:num]: self.caster.grant_equipment_copy_to_minion(u, b)
		yield
		if self.get_stat('running_start'):
			for _ in range(3):
				for _ in self.caster.level.take_turn(u):
					yield

class BloodMeridian(Spell):

	def on_init(self):
		self.name = "Blood Meridian"
		self.tags = [Tags.Blood, Tags.Sorcery]
		self.level = 5
		self.range = 0
		self.max_charges = 3
		self.hp_cost = 36
		self.damage = 36
		self.damage_type = [Tags.Physical]
		self.duration = 3

		self.upgrades['wide'] = (1, 4, "Deep Division", "Instead of a line, Blood Meridian affects a 3 tile wide beam that extends above and below the caster")
		self.upgrades['lifesteal'] = (1, 3, "Lifesteal", "Heal for damage dealt by this spell")
		self.upgrades['wall'] = (1, 5, "Blood Wall", "After dealing damage, unoccupied tiles in the meridian become walls")
		self.upgrades['twilight'] = (1, 9, "Twilight Divide", "Enemies to the left of the meridian take [{damage}:damage] [Dark] damage\nEnemies to the right of the meridian take [{damage}:damage] [Holy] damage", [Tags.Dark, Tags.Holy], [Tags.Dark, Tags.Holy], {'damage':18})

	def get_description(self):
		return ("Inflict [{damage}:damage] [Physical] damage and [{duration}:duration] turns of [bleed] to other units in a line extending above and below the caster\n"
				"Enemies to the left of the meridian are put to [sleep] for [{duration}:duration] turns\n"
				"Enemies to the right of the meridian are [berserked] for [{duration}:duration] turns")

	def get_targetable_tiles(self):
		return [self.caster]

	def get_column_bounds(self, x):
		if self.get_stat('wide'):
			level = self.caster.level
			return max(0, x - 1), min(level.width - 1, x + 1)
		return x, x

	def get_impacted_tiles(self, x, y):
		level = self.caster.level
		tiles = level.tiles
		minx, maxx = self.get_column_bounds(x)
		for t in range(level.height):
			for cur_x in range(minx, maxx + 1):
				yield tiles[cur_x][t]

	def cast(self, x, y):
		caster = self.caster
		level = caster.level

		damage = self.get_stat('damage')
		duration = self.get_stat('duration')

		dmg = 0
		for t in self.get_impacted_tiles(x, y):
			level.show_effect(t.x, t.y, Tags.Blood)
			if not t.unit: continue
			elif t.unit == self.caster: continue
			else:
				dmg += level.deal_damage(t.x, t.y, damage, Tags.Physical, self, flash=False)
				if t.unit: t.unit.apply_buff(BleedBuff(), duration)
			yield

		minx, maxx = self.get_column_bounds(caster.x)

		twilight = self.get_stat('twilight')
		twilight_damage = self.get_stat('damage', base=18)
		for u in [u for u in level.units if are_hostile(u, caster) and u.is_alive()]:
			if u.x < minx:
				if twilight: dmg += u.deal_damage(twilight_damage, Tags.Dark, self)
				u.apply_buff(SleepBuff(), duration)
			elif u.x > maxx:
				if twilight: dmg += u.deal_damage(twilight_damage, Tags.Holy, self)
				u.apply_buff(BerserkBuff(), duration)

		if dmg and self.get_stat('lifesteal'): caster.heal(dmg, self)

		if self.get_stat('wall'):
			for t in self.get_impacted_tiles(x, y):
				if t.unit or t.prop or not t.can_see: continue
				level.make_wall(t.x, t.y)

		yield

class KillingTempo(Upgrade):

	def on_init(self):
		self.name = "Killing Tempo"
		self.level = 6
		self.global_triggers[EventOnDeath] = self.on_death
		self.description = "If the target of your Temporal Transfusion kills a unit, they immediately take an extra turn"

	def on_death(self, evt):
		# ignore non-damage or kills by non-units
		if not evt.damage_event or not evt.damage_event.source or not evt.damage_event.source.owner: return
		u = self.prereq.cur_target
		if not u: return
		if u != evt.damage_event.source.owner: return
		self.owner.level.queue_spell(self.do_extra_turn(u))

	def do_extra_turn(self, u):
		for _ in self.owner.level.take_turn(u): yield

class HasteBuff(Buff):

	def on_init(self):
		self.name = "Haste"
		self.color = Tags.Translocation.color
		self.description = "Takes an extra turn each round"
		self.buff_type = BUFF_TYPE_BLESS
		self.stack_type = STACK_NONE
		self.triggered = False

	def on_advance(self):
		if self.triggered: return
		self.triggered = True
		self.owner.level.queue_spell(self.do_turn())

	def do_turn(self):
		for _ in self.owner.level.take_turn(self.owner): yield
		self.triggered = False

class TemporalTransfusion(Spell):

	def on_init(self):
		self.name = "Temporal Transfusion"
		self.level = 5
		self.tags = [Tags.Arcane, Tags.Blood, Tags.Enchantment]
		self.max_charges = 5
		self.hp_cost = 18
		self.max_channel = 6
		self.range = 4

		self.can_target_self = False
		self.can_target_empty = False
		self.target_allies = True
		self.target_empty = False

		self.last_target = None
		self.cur_target = None

		self.upgrades['boost'] = (1, 3, "Chrono Boost", "Each turn spent channeling, reset the target's active spell cooldowns")
		self.upgrades[('scaling', 'num_targets')] = ([1, 5], 5, "Temporal Mastery", "The target takes [{num_targets}:num_targets] extra turns instead of 3")
		self.upgrades[('ritual', 'hp_cost')] = ([1, 18], 8, "Ritual of Haste", "If you complete the ritual, the target gains [Haste:translocation]", [Tags.Ritual])
		self.add_upgrade(KillingTempo())

		self.add_upgrade_tooltip("Ritual of Haste", HasteBuff)

	def get_description(self):
		if self.get_stat('scaling'): return "Each turn you channel this spell, the target unit takes [{num_targets}:num_targets] extra turns"
		return "Each turn you channel this spell, the target unit takes 3 extra turns"

	def cast(self, x, y, channel_cast=False):

		if not channel_cast and self.is_manual_cast():
			u = self.caster.level.get_unit_at(x, y)
			if not u: return
			self.cur_target = u # stash the unit we're targeting
			b = ChannelBuff(self.cast, u, on_stop=self.on_channel_stop)
			b.connected_targets = [u]
			self.caster.apply_buff(b, self.get_stat('max_channel'))
			return

		# if we've cast the spell but we don't have a target then notice what is there
		cur_target = self.cur_target or self.caster.level.get_unit_at(x, y)

		# if we are channeling but the current location contains the wrong unit or no unit or the original unit is dead, cancel the channel
		b = self.caster.get_buff(ChannelBuff)
		if not cur_target or (b and b.spell_target != cur_target) or not cur_target.is_alive():
			self.caster.remove_buff(b)
			return

		self.caster.level.show_path_effect(self.caster, cur_target, Tags.Arcane, minor=True)

		if self.get_stat('boost'):
			for s in list(cur_target.cool_downs):
				if cur_target.cool_downs[s] > 1:
					cur_target.cool_downs[s] = 0

		turns = self.get_stat('num_targets') if self.get_stat('scaling') else 3
		for _ in range(turns):
			for _ in self.caster.level.take_turn(cur_target):
				yield

		if self.get_stat('ritual') and not b and channel_cast:
			if self.last_target and self.last_target.is_alive():
				self.last_target.apply_buff(HasteBuff())
				self.last_target = None

	def on_channel_stop(self):
		self.last_target = self.cur_target
		self.cur_target = None # clear the unit storage

class EyeOnKill(Upgrade):

	def __init__(self, spell):
		self.spell = spell
		Upgrade.__init__(self)

	def on_init(self):
		self.name = "Waking The Witness"
		self.added_tags = [Tags.Dark]
		self.tags = [Tags.Eye, Tags.Ritual, Tags.Dark]
		self.level = 9
		self.description = "If an enemy dies in your line of sight while channeling the ritual, cast Floating Eye at their location\nAdds the [Dark] tag"
		self.global_triggers[EventOnDeath] = self.on_death

	def on_death(self, evt):
		owner = self.owner
		b = owner.get_buff(ChannelBuff)
		if not b: return
		if b.spell != self.spell.cast: return
		if not are_hostile(evt.unit, owner): return
		if not owner.level.can_see_unit(owner, evt.unit): return
		owner.level.defer_cast(owner, owner.get_or_make_spell(SummonFloatingEye), evt.unit.x, evt.unit.y, pay_costs=False)

class RitualOfTheOpeningEye(Spell):

	def on_init(self):
		self.name = "Ritual of the Opening Eye"
		self.level = 7
		self.tags = [Tags.Eye, Tags.Ritual]

		self.max_charges = 1
		self.range = 0
		self.max_channel = 8
		self.num_targets = 3
		self.num_summons = 20

		self.upgrades['free_shot'] = (1, 3, "Eternal Vigil", "Activations from the ritual will not decrease the [Eye] buffs' remaining duration")
		self.upgrades['sleep'] = (1, 5, "Unseen Dreamers", "When you begin the ritual, enemies outside your line of sight are put to [sleep] for [{max_channel}:max_channel] turns\nIf you fail to complete the ritual, all [sleeping:sleep] units wake up", None, None, {'max_channel':8})
		self.upgrades['open'] = (1, 6, "Rapturous Sight", "If you complete the ritual, cast your other self-targeted [Eye] spells")
		self.add_upgrade(EyeOnKill(self))


	def get_description(self):
		return ("Each turn, your [Eye] buffs activate [{num_targets}:num_targets] additional times\n"
				"If you complete the ritual, cast your Floating Eye spell up to [{num_summons}:num_summons] times in random unoccupied locations in your line of sight")

	def cast(self, x, y, channel_cast=False):
		caster = self.caster
		level = caster.level
		if not channel_cast and self.is_manual_cast():
			sleep = self.get_stat('sleep')
			self.caster.apply_buff(ChannelBuff(self.cast, caster, on_failure=self.on_failure if sleep else None), self.get_stat('max_channel'))
			if sleep:
				max_channel = self.get_stat('max_channel')
				for u in [u for u in level.units if are_hostile(caster, u) and not level.can_see_unit(caster, u)]:
					u.apply_buff(SleepBuff(), max_channel)
			return

		eye_buffs = []
		for b in caster.buffs:
			if b.buff_type != BUFF_TYPE_BLESS: continue
			try: # grab eye spell buffs and eye equipment buffs (they pass in themselves as spell)
				if Tags.Eye in b.spell.tags:
					eye_buffs.append(b)
			except AttributeError: continue

		num = self.get_stat('num_targets')
		free_shot =  self.get_stat('free_shot')
		for _ in range(num):
			for e in eye_buffs:
				if e.applied:
					if free_shot: e.on_advance()
					else: e.advance()
			yield

		if channel_cast and not caster.get_buff(ChannelBuff):
			level = caster.level
			get_unit = level.get_unit_at
			opts = [p for p in level.get_points_in_los(caster) if not get_unit(p.x, p.y)]
			random.shuffle(opts)
			s = caster.get_or_make_spell(SummonFloatingEye)
			for pt in opts[:self.get_stat('num_summons')]: level.act_cast(caster, s, pt.x, pt.y, pay_costs=False)
			yield
			if self.get_stat('open'):
				other_eyes = [e for e in caster.spells if Tags.Eye in e.tags and e.range == 0  and e != self]
				for s in other_eyes:
					level.act_cast(caster, s, caster.x, caster.y, pay_costs=False)
					yield

	def on_failure(self):
		sleepers = [u for u in self.owner.level.units if u.has_buff(SleepBuff)]
		for u in sleepers:
			b = u.get_buff(SleepBuff)
			if not b or not b.applied: continue
			u.remove_buff(b)

class BouncingSlimeball(Spell):

	def on_init(self):
		self.name = "Bouncing Slimeball"
		self.level = 2
		self.tags = [Tags.Sorcery, Tags.Chaos, Tags.Slime, Tags.Conjuration]
		self.max_charges = 12

		self.can_target_empty = False
		self.damage_type = [Tags.Physical]

		self.range = 6
		self.num_targets = 6

		self.minion_health = 10
		self.minion_damage = 3
		self.minion_range = 3

		self.rand_slime_turn = None

		self.upgrades['knockback'] = (1, 2, "Impact Kickback", "When Bouncing Slimeball hits a unit, it deals twice as much damage and pushes them back 2 tiles")
		self.upgrades[('pouch', 'duration')] = ([1, 3], 4, "Slime Ammo Pouch", "Bouncing Slimeball also deals damage and inflicts [{duration}:duration] turns of a status matching the type of slime that will be spawned\nYou can now see what kind of slime, the matching damage type, and the inflicted status type in this spell's description each turn")
		self.upgrades['slimepacolypse'] = (1, 3, "Slimepacolypse", "Bouncing Slimeball can now bounce to friendly [Slime] units\nIf it impacts a friendly [Slime], instead of any other effects, it grants them max health equal to its remaining bounces and heals them to full life")
		self.upgrades[('conserve', 'num_targets')] = ([1, 3] , 6, "Kinetic Conservation", "When Bouncing Slimeball kills a creature that it bounces to, its number of remaining bounces does not decrease")

	def get_description(self):
		if self.get_stat('pouch') and self.caster:
			slime_constructor = self.get_deterministic_slime_constructor()
			dtype = slime_types_to_damage.get(slime_constructor)
			debuff = slime_damage_type_to_status.get(dtype)
			return((
			"Fling a slime ball that bounces up to [{num_targets}:num_targets] times to random enemies in line of sight of the last hit\n"
			"Each bounce deals [Physical] and {dtype} damage equal to the remaining bounces and inflicts [{duration}:duration] turns of {debuff}\n"
			"The final impact summons a {slime_name} nearby"), {'slime_name':slime_constructor().name, 'dtype':formatted_tag(dtype), 'debuff':debuff().name})
		else:
			return (
				"Fling a slime ball that bounces up to [{num_targets}:num_targets] times to random enemies in line of sight of the last hit\n"
				"Each bounce deals [Physical] damage equal to the number of remaining bounces\n"
				"The final impact summons a random slime nearby")

	def get_deterministic_slime_constructor(self):
		if not self.caster: return GreenSlime
		if not self.rand_slime_turn or self.rand_slime_turn[1] != self.caster.level.turn_no:
			self.rand_slime_turn = (self.caster.level.random.choice(slime_types), self.caster.level.turn_no)
		return self.rand_slime_turn[0]

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		projectile_effect = level.projectile_effect

		remaining_impacts = self.get_stat('num_targets') + 1
		slimepacolypse = self.get_stat('slimepacolypse')
		conserve = self.get_stat('conserve')
		knockback = self.get_stat('knockback')
		knockback_mult = 2 if knockback else 1

		pouch = self.get_stat('pouch')
		slime_type = self.get_deterministic_slime_constructor() if pouch else None
		dtypes = list(self.get_stat('damage_type'))
		debuff = None
		if slime_type:
			bonus_damage_tag = slime_types_to_damage[slime_type]
			dtypes.append(bonus_damage_tag)
			debuff = slime_damage_type_to_status.get(bonus_damage_tag)

		dur = self.get_stat('duration')

		origin = caster
		target = level.get_unit_at(x, y) or Point(x, y)

		while remaining_impacts > 0:

			# show projectile bouncing ball
			for p in level.get_points_in_line(origin, target, find_clear=False)[1:]:
				projectile_effect(p.x, p.y, proj_name='slime_ball', proj_origin=origin, proj_dest=target, proj_duration=1)
				yield

			u = level.get_unit_at(target.x, target.y)
			hit_ally_slime = slimepacolypse and bool(u and u.is_alive() and not are_hostile(caster, u) and Tags.Slime in u.tags)

			if hit_ally_slime:
				u.max_hp += (remaining_impacts - 1)
				u.heal(u.max_hp, self)
				yield
			else:
				# deal damage on impact, gets more damage types with pouch upgrade
				for dtype in dtypes:
					level.deal_damage(target.x, target.y, (remaining_impacts-1) * knockback_mult, dtype, self)
					yield

				if u:
					if u.is_alive():
						if debuff is not None: u.apply_buff(debuff(), dur) # if we have a debuff to apply via the upgrade, do it
						if knockback: push(u, origin, 2)
					elif conserve: remaining_impacts += 1 # if the unit's dead and we have the upgrade, nullify the upcoming reminaing_impacts decrement

			# decrement remaining bounces
			remaining_impacts -= 1
			if remaining_impacts <= 0: break

			# look for bounce targets
			if slimepacolypse: candidates = [u for u in level.get_units_in_los(target) if (are_hostile(caster, u) or Tags.Slime in u.tags) and u.is_alive() and u != target]
			else: candidates = [u for u in level.get_units_in_los(target) if are_hostile(caster, u) and u.is_alive() and u != target]
			if not candidates: break

			# reset the origin/destinations
			origin = target
			target = random.choice(candidates)

		if slime_type: slime = make_minion(self, slime_type) # only gets set if we have pouch upgrade
		else: slime = make_minion(self, random.choice(slime_types)) # slime buff now hands down minion_bonuses
		self.summon(slime, target=target)
		yield

class RitualOfFlyingDaggers(Spell):

	def on_init(self):
		self.name = "Ritual of Flying Daggers"
		self.level = 6
		self.tags = [Tags.Metallic, Tags.Ritual]

		self.range = 0
		self.max_charges = 3
		self.max_channel = 9
		self.num_targets = 6
		self.damage = 9

		self.knives_stored = 0
		self.min_knives = 0
		self.ritual_completed = False

		self.upgrades[('weighted', 'damage')] = ([1, 9], 3, "Weighted Knives", "Enemies hit are [stunned] for one turn")
		self.upgrades['forest'] = (1, 2, "Forest of Flying Daggers", "An additional dagger is also fired from each of your [Nature] allies", [Tags.Nature])
		self.upgrades['experience'] = (1, 9, "Soul Blades", "Ritual of Flying Daggers permanently gains +1 to its Daggers Ready when it kills a unit")
		self.upgrades['blades'] = (1, 7, "Anima Thief", "When this spell kills a unit, cast your Summon Blade spell where it died", [Tags.Arcane])

	def get_description(self):
		return (("Each turn, ready [{num_targets}:num_targets] daggers\n"
				"When you stop channeling, the daggers are unleashed, each dealing [{damage}:damage] [Physical] damage to an enemy in your line of sight\n"
				"If the ritual is completed, the number of daggers is multiplied by [{num_targets}:num_targets]\n"
				"Daggers Ready: {num}", {'num':self.knives_stored}))

	def cast(self, x, y, channel_cast=False):
		caster = self.caster
		if not channel_cast and self.is_manual_cast():
			caster.apply_buff(ChannelBuff(self.cast, caster, on_stop=self.on_stop, on_ritual_completed=self.on_ritual_completed), self.get_stat('max_channel'))
			return
		self.knives_stored += self.get_stat('num_targets')
		yield

	def on_ritual_completed(self):
		self.ritual_completed = True

	def on_stop(self):
		self.caster.level.queue_spell(self.prepare_daggers())

	def prepare_daggers(self):
		daggers = self.knives_stored
		if self.ritual_completed: daggers *= self.get_stat('num_targets')
		self.ritual_completed = False
		self.knives_stored = self.min_knives
		if not daggers: return
		if daggers > 1000:
			from SteamAdapter import record_flying_daggers
			record_flying_daggers(daggers)
		self.caster.level.queue_spell(self.release_daggers(daggers))
		yield

	def release_daggers(self, daggers):
		caster = self.caster
		level = caster.level
		get_line = level.get_points_in_line
		show = level.show_effect
		deal_damage = level.deal_damage
		damage = self.get_stat('damage')


		weighted = self.get_stat('weighted')
		forest = self.get_stat('forest')
		experience = self.get_stat('experience')
		blades = self.get_stat('blades')

		blade_effect = Tags.AssassinBlade if blades else Tags.FlyingDagger

		hits = set()
		track_kills = (experience or blades)
		kills = set()

		enemies = []
		active_daggers = []

		if forest:
			allies = [u for u in level.units if u != caster and Tags.Nature in u.tags and not are_hostile(caster, u)]
			for ally in allies:
				targets = [u for u in level.get_units_in_los(ally) if are_hostile(ally, u) and u.is_alive()]
				if not targets: continue
				target = random.choice(targets)
				active_daggers.append([ally, target, get_line(ally, target, inclusive=False), 0])

		while daggers or active_daggers:
			if daggers and not enemies:
				enemies = [u for u in level.get_units_in_los(caster) if are_hostile(caster, u) and u.is_alive()]
				if not enemies and not active_daggers: break # no more targets to throw at
				random.shuffle(enemies)

			if daggers and enemies:
				while enemies:
					u = enemies.pop()
					if not u.is_alive(): continue
					active_daggers.append([caster, u, get_line(caster, u, inclusive=False), 0])
					daggers -= 1
					break

			for i in range(len(active_daggers) -1, -1, -1):
				origin, u, path, index = active_daggers[i]
				if not u.is_alive(): active_daggers.pop(i); continue
				if index < len(path):
					point = path[index]
					show(point.x, point.y, blade_effect)
					active_daggers[i][3] += 1
				else:
					deal_damage(u.x, u.y, damage, Tags.Physical, self)
					if u.is_alive():
						if weighted: hits.add(u)
					elif track_kills: kills.add(u)
					active_daggers.pop(i)
			yield


		if hits:
			for u in hits:
				if not u.is_alive(): continue
				u.apply_buff(Stun(), 1)

		if kills:
			if experience:
				self.min_knives += len(kills)
				self.knives_stored = self.min_knives
			if blades:
				blade_spell = caster.get_or_make_spell(SummonBlade)
				for u in kills: level.act_cast(caster, blade_spell, u.x, u.y, pay_costs=False)

class GolemReversionBuff(Buff):

	def on_init(self):
		self.name = "Return from Dust"
		self.owner_triggers[EventOnDeath] =  self.on_death

	def on_death(self, evt):
		owner = self.owner
		u = self.owner.level.get_unit_at(owner.x, owner.y)
		if u and u is not owner: return
		owner.level.show_effect(owner.x, owner.y, Tags.Arcane, minor=True)
		owner.level.make_wall(owner.x, owner.y)


class Stonewake(Spell):

	def on_init(self):
		self.name = "Stonewake"
		self.level = 5
		self.tags = [Tags.Arcane, Tags.Conjuration, Tags.Nature, Tags.Metallic]

		self.max_charges = 3
		self.range = 0
		self.radius = 3

		self.minion_health = 25
		self.minion_damage = 8
		self.minion_duration = 16

		self.upgrades['returning'] = (1, 3, "Return from Dust", "Golems transform back into walls when they die")
		self.upgrades['orbs'] = (1, 4, "Orb Guardians", "When you cast Stonewake, your [Orb] allies also cast your Stonewake", [Tags.Orb])
		self.upgrades['crystal'] = (1, 4, "Crystalline Core", "Adjacent walls are transformed into Crystal Golems instead")
		self.upgrades['supremacy'] = (1, 8, "Supremacy of Stone", "After the initial burst, every wall in your line of sight is also transformed into a Golem")

		self.add_upgrade_tooltip("Crystalline Core", self.get_crystal_golem)


	def get_description(self):
		return ("Walls within [{radius}:radius] tiles become floors, and are transformed into temporary Golems")

	def get_extra_examine_tooltips(self):
		return [self.make_golem()] + self.get_upgrade_tooltips()

	def get_crystal_golem(self):
		return self.make_golem(CrystalGolem)

	def make_golem(self, spawn_func=Golem):
		u = spawn_func()
		apply_minion_bonuses(self, u)
		if self.get_stat('returning'): u.apply_buff(GolemReversionBuff())
		return u

	def get_impacted_tiles(self, x, y):
		if not self.get_stat('orbs'): return Spell.get_impacted_tiles(self, x, y)
		caster = self.caster
		casters = [u for u in caster.level.units if Tags.Orb in u.tags and not are_hostile(caster, u)]
		casters.append(caster)
		impacted = []
		getball = caster.level.get_points_in_ball
		radius = self.get_stat('radius')
		for u in casters:
			for p in getball(u.x, u.y, radius):
				if p not in impacted:
					impacted.append(p)
		return impacted

	def cast(self, x, y):

		caster = self.caster
		level = caster.level
		make_floor = level.make_floor
		show_effect = level.show_effect
		tiles = level.tiles
		target = Point(x, y)

		crystal = self.get_stat('crystal')
		stage_num = 0

		for stage in Burst(level, target, self.get_stat('radius'), ignore_walls=True):
			for p in stage:
				show_effect(p.x, p.y, Tags.Arcane, minor=True)
				tile = tiles[p.x][p.y]
				if not tile.is_wall(): continue
				spawn_func = CrystalGolem if stage_num == 1 and crystal else Golem
				make_floor(p.x, p.y)
				self.summon(self.make_golem(spawn_func), target=p, radius=0)
			stage_num += 1
			yield

		if self.get_stat('orbs') and caster.is_player_controlled:
			orb_allies = [u for u in level.units if Tags.Orb in u.tags and not are_hostile(caster, u)]
			act_cast = level.act_cast
			s = Stonewake()
			s.statholder = caster
			for u in orb_allies:
				s.caster = u
				s.owner = u
				for _ in act_cast(u, s, u.x, u.y, pay_costs=False, queue=False): pass

		if self.get_stat('supremacy'):
			los_walls = [t for t in level.iter_tiles() if level.can_see(t.x, t.y, caster.x, caster.y, light_walls=True) and t.is_wall()]
			for tile in los_walls:
				make_floor(tile.x, tile.y)
				self.summon(self.make_golem(), target=tile, radius=0)

class DreadLash(Spell):

	def on_init(self):
		self.name = "Dread Lash"
		self.level = 2
		self.tags = [Tags.Dark, Tags.Sorcery]
		self.damage_type = [Tags.Dark]

		self.max_charges = 13
		self.range = 6
		self.damage = 18
		self.duration = 3

		self.upgrades[('quick_cast', 'requires_los')] = ([1, -1], 3, "Dread Lord", "Dread Lash gains quickcast, and can be cast on targets outside your line of sight")
		self.upgrades['web'] = (1, 5, "Web of Fear", "Casting Dread Lash on yourself will instead cause it to hit every [feared] enemy in the level")
		self.upgrades['razor'] = (1, 3, "Razor Lash", "Dread Lash also deals [Physical] damage and inflicts [{duration}:duration] turns of [bleed]", [Tags.Metallic], [Tags.Physical], {'duration':3})
		self.upgrades['secret'] = (1, 4, "Dreadful Secret", "If the target is adjacent to you after being pulled, cast Seal Fate on them")


	def get_description(self):
		return ("Inflict [{damage}:damage] [Dark] damage and [{duration}:duration] turns of [fear] on the target unit\n"
				"Then, pull the target unit up to [{range}:range] tiles along a path toward you")

	def can_cast(self, x, y):
		if not self.get_stat('web'): return Spell.can_cast(self, x, y)
		if self.caster.level.get_unit_at(x, y) == self.caster: return True
		else: return Spell.can_cast(self, x, y)

	def get_impacted_tiles(self, x, y):
		if not self.get_stat('web'): return Spell.get_impacted_tiles(self, x, y)
		if self.caster.level.get_unit_at(x, y) == self.caster:
			return [u for u in self.caster.level.units if are_hostile(self.caster, u) and u.has_buff(FearBuff)]
		else: return Spell.get_impacted_tiles(self, x, y)

	def cast(self, x, y):

		caster = self.caster
		level = caster.level

		target_units = [level.get_unit_at(x, y)]

		if target_units[0] is None:
			level.show_path_effect(caster, Point(x, y), Tags.Dark)
			return

		damage = self.get_stat('damage')
		pull_distance = self.get_stat('range')
		duration = self.get_stat('duration')

		razor = self.get_stat('razor')
		secret = self.get_stat('secret')

		if secret: seal = caster.get_or_make_spell(SealFate)

		damage_types = self.get_stat('damage_type')

		show_effect = level.show_effect
		deal_damage = level.deal_damage
		can_move = level.can_move
		act_move = level.act_move

		if self.get_stat('web') and  target_units[0] == caster:
			target_units = [u for u in level.units if are_hostile(caster, u) and u.has_buff(FearBuff)]

		for target_unit in target_units:
			for dt in damage_types: deal_damage(target_unit.x, target_unit.y, damage, dt, self)
			if not target_unit.is_alive(): level.show_path_effect(caster, target_unit, Tags.Dark, minor=True); continue
			target_unit.apply_buff(FearBuff(), duration)
			if razor: target_unit.apply_buff(BleedBuff(), duration)
			path = get_pull_along_path(target_unit, caster, pull_distance)
			if not path: continue
			for i, p in enumerate(path):
				for q in reversed(path[i:]): show_effect(q.x, q.y, Tags.Dark, minor=True)
				yield
				if can_move(target_unit, p.x, p.y, teleport=True): act_move(target_unit, p.x, p.y, teleport=True)
				else: break
				yield

			if secret and level.unit_distance(caster, target_unit, diag=True) == 1:
				level.act_cast(caster, seal, target_unit.x, target_unit.y, pay_costs=False)

spell_tags = [
	Tags.Arcane,
	Tags.Blood,
	Tags.Chaos,
	Tags.Conjuration,
	Tags.Dark,
	Tags.Dragon,
	Tags.Enchantment,
	Tags.Eye,
	Tags.Fire,
	Tags.Holy,
	Tags.Ice,
	Tags.Lightning,
	Tags.Metallic,
	Tags.Nature,
	Tags.Orb,
	Tags.Ritual,
	Tags.Slime,
	Tags.Sorcery,
	Tags.Translocation,
	Tags.Word,
]

all_player_spell_constructors = [
	# Level 1 self.level = 1
	FireballSpell,
	LightningBoltSpell,
	MagicMissile,
	SummonWolfSpell,
	PoisonSting,
	DeathBolt,
	LifedrainSpell,
	Icicle,
	SummonBlade,
	DragonClaw,
	BloodBullet,

	# Level 2 self.level = 2
	TouchOfDeath,
	RainStormSpell,
	GoatOffering,
	Bonespear,
	ImmolateSpell,
	ScourgeSpell,
	MoonGlaive,
	MagnetizeSpell,
	MercurizeSpell,
	Slimeshot,
	Slimify,
	ToxinBurst,
	SummonHungryMaw,
	PyrostaticPulse,
	HolyBlast,
	FanOfFlames,
	SummonFloatingEye,
	PetrifySpell,
	MeltSpell,
	InvokeSavagerySpell,
	EyeOfBloodSpell,
	EyeOfFireSpell,
	EyeOfIceSpell,
	EyeOfLightningSpell,
	EyeOfRageSpell,
	RegenAuraSpell,
	HealingLight,
	BoilingBlood,
	Disperse,
	ChaosBarrage,
	AnnihilateSpell,
	ThunderStrike,
	Iceball,
	Freeze,
	UnderworldPortal,
	DragonBreath,
	ShadowHexSpell,
	SummonBoneKnights,
	DragonRideSpell,
	EarthenPassage,
	BouncingSlimeball,


	# Level 3 self.level = 3
	BlinkSpell,
	FlameGateSpell,
	SummonGiantBear,
	Darkness,
	PrisonOfThorns,
	Dominate,
	NightmareSpell,
	MysticVision,
	MysticPower,
	ChainLightningSpell,
	LightningHaloSpell,
	SealFate,
	Vampiricism,
	SummonEarthElemental,
	Ghostball,
	DevourMind,
	Ironize,
	BlindingLightSpell,
	ShrapnelBlast,
	SummonFrostfireHydra,
	DeathChill,
	SlimeformSpell,
	Blazerip,
	PyrostaticCurse,
	SilverSpearSpell,
	LightningSpire,
	Lumbriogenesis,
	DevourFlesh,
	Bloodshift,
	PsychicSeedling,
	WaveOfDread,
	HolyFlame,
	BestowImmortality,
	AmalgamateSlime,
	DispersionFieldSpell,
	ShieldSiphon,
	EarthquakeSpell,
	SummonSpiderQueen,
	StampedeFormSpell,
	IceVortex,
	DeathClock,
	StormWalk,
	ShatterSpell,
	DragonRoar,
	RotGaze,
	Torrent,
	DreadLash,

	# Level 4 self.level = 4
	LightningFormSpell,
	VoidBeamSpell,
	PetrificationAuraSpell,
	StormSpell,
	WatcherFormSpell,
	ImpGateSpell,
	FlameBurstSpell,
	SummonFireDrakeSpell,
	SummonStormDrakeSpell,
	SummonVoidDrakeSpell,
	SummonIceDrakeSpell,
	WheelOfDeath,
	VampiricGazeSpell,
	BoneBarrageSpell,
	DeathCleaveSpell,
	IgnitePoison,
	BlizzardSpell,
	StormBurst,
	IceWall,
	SearingSealSpell,
	PuritySpell,
	RestlessDead,
	EssenceFlux,
	CarnivalOfPain,
	MassCalcification,
	ArmageddonBladeSpell,
	BurningIdolSpell,
	SummonSeraphim,
	PainMirrorSpell,
	SummonFieryTormentor,
	DrainPulse,
	Permanence,
	ChoirOfAngels,
	Volcano,
	RuinousOffering,
	OrbOfNight,
	OrbOfUnraveling,
	ArcaneWardingSpell,
	SummonLeghead,


	# Level 5 self.level = 5
	Teleport,
	FlameStrikeSpell,
	DeathShock,
	SummonBlueLion,
	CantripCascade,
	FaeCourt,
	SoulTax,
	FlockOfEaglesSpell,
	HeavenlyIdol,
	SummonArchon,
	SummonIcePhoenix,
	IceWind,
	GoldSkullSummonSpell,
	HagSummon,
	FleshFiendSpell,
	TemporalTransfusion,
	BloodMeridian,
	OrbOfAssimilation,
	OrbOfAnima,
	Stonewake,


	# Level 6 self.level = 6
	ArcLightning,
	HeavensWrath,
	SummonGoldDrakeSpell,
	SummonKnights,
	TwilightGazeSpell,
	FaehauntGardenSpell,
	FurnaceOfSorcerySpell,
	DemonicRitual,
	PrismaticBeam,
	Sanction,
	Miasma,
	BlackHoleSpell,
	RitualOfFlyingDaggers,


	# Level 7 self.level = 7
	RainOfThunderbolts,
	MulticastSpell,
	SpikeballFactory,
	WyrmEggs,
	SoulWindSpell,
	WallOfFlame,
	DemonFormSpell,
	RitualOfTheOpeningEye,
	StarwhaleDream,


	# Level 8 self.level = 8
	SummonSlimeDrake,
	HordeOfHalfmen,
	SummonWizard,
	IonTentaclesSpell,


	# Level 9 self.level = 9
	MeteorShower,
	WizardReplica
]

def make_player_spells():
	all_player_spells = []

	for c in all_player_spell_constructors:
		s = c()
		all_player_spells.append(s)

	unit = Unit()
	for spell in all_player_spells:
		unit.add_spell(spell) # is this error checking? why are we putting the spells on a random unit?

	# Insist that all spells are spells (to catch mod bugs mostly)
	for spell in all_player_spells:
		if not isinstance(spell, Spell):
			print(spell.name)
			assert(isinstance(spell, Spell))

	# Insist that no spells have none descs, a common bug
	for spell in all_player_spells:
		if not spell.get_description():
			print(spell.name)
			assert(spell.get_description())

	# Insist that no spells have no tags
	for spell in all_player_spells:
		if not spell.level or not len(spell.tags):
			print(spell.name)
			assert(spell.level)
			assert(len(spell.tags))

	# Insist that the spell has consistent desc
	for spell in all_player_spells:
		if spell.description:
			print(spell.name)
			assert(spell.description == spell.get_description())

	# Insist that all extra tooltips exist
	for spell in all_player_spells:
		for tt_obj in spell.get_extra_examine_tooltips():
			if not tt_obj:
				print(spell)
				assert(tt_obj)

	# sort by total req levels
	all_player_spells.sort(key=lambda s: (s.level, s.name))

	return all_player_spells

def check_for_loose_spells():
	import inspect
	all_spell_classes = [
		obj for obj in globals().values()
		if inspect.isclass(obj)
		   and issubclass(obj, Spell)
		   and obj is not Spell
		   and obj.__module__ == __name__
	]

	for s in all_spell_classes:
		if s not in all_player_spell_constructors:
			spell = s()
			level = getattr(spell, "level", 0)
			if spell.level > 0: print(f"Level {level} spell {s.__name__} is created but not purchasable by the player")

	print(f"{len(all_spell_classes)} total spells")

def check_spell_upgrades():
	spells = make_player_spells()
	total = 0
	urgent = []
	for s in spells:
		deficiency = 4 - len(s.spell_upgrades)
		if deficiency > 0:
			upgrades = "upgrade" if deficiency==1 else "upgrades"
			print(f"{s.name} needs {deficiency} more {upgrades}")
			total += deficiency
			if deficiency > 1: urgent.append((s, deficiency))
	print(f"Altogether, at least {total} more upgrades required")
	for (s, deficiency) in urgent: print(f"{s.name} urgently needs {deficiency} more upgrades")

if __name__ == '__main__':
	check_for_loose_spells()
	check_spell_upgrades()
