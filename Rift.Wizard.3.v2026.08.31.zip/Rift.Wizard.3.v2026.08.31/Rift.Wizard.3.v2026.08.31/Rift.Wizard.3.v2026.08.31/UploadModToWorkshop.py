import struct, ctypes.util # PyInstaller wipes get_arch, restore it here for steamworks
if not hasattr(ctypes.util, "get_arch"): ctypes.util.get_arch = lambda: "x64" if struct.calcsize("P")*8==64 else "x86"

import os
import shutil
import sys
import tempfile
import time
import traceback
import webbrowser

import steamworks


RESULT_OK = 1
VISIBILITY_PRIVATE = 2
WORKSHOP_FILE_TYPE_COMMUNITY = 0
PREVIEW_MAX_BYTES = 1024 * 1024
PREVIEW_EXTENSIONS = ('.jpg', '.jpeg', '.png', '.gif')
WORKSHOP_ID_FILENAME = 'workshop_item_id.txt'


if getattr(sys, 'frozen', False):
	dname = os.path.dirname(sys.executable)
elif __file__:
	dname = os.path.dirname(os.path.abspath(__file__))
else:
	dname = os.getcwd()
os.chdir(dname)


def get_local_mod_roots():
	mods_root = os.path.abspath('mods')
	if not os.path.isdir(mods_root):
		raise Exception("Could not find a mods folder next to UploadModToWorkshop.py.")

	mod_roots = {}
	for name in sorted(os.listdir(mods_root)):
		root = os.path.join(mods_root, name)
		if not os.path.isdir(root):
			continue
		entry_path = os.path.join(root, name + '.py')
		if not os.path.exists(entry_path):
			continue
		mod_roots[name] = root

	return mod_roots


def read_preview_file(mod_root):
	for name in ('preview.png', 'preview.jpg', 'preview.jpeg', 'preview.gif'):
		value = os.path.abspath(os.path.join(mod_root, name))
		if not os.path.isfile(value):
			continue
		ext = os.path.splitext(value)[1].lower()
		if ext not in PREVIEW_EXTENSIONS:
			continue
		size = os.path.getsize(value)
		if size > PREVIEW_MAX_BYTES:
			raise Exception("Preview image %s must be under 1MB." % value)
		return value

	raise Exception("No preview image found in %s. Add preview.png, preview.jpg, preview.jpeg, or preview.gif to the mod folder." % mod_root)


def read_mod_root():
	mod_roots = get_local_mod_roots()
	if not mod_roots:
		raise Exception("No valid mod folders were found in the mods directory.")

	print("Available mod folders in mods:")
	for mod_name in mod_roots:
		print("- %s" % mod_name)

	mod_name = input("Mod folder name: ").strip()
	if mod_name in mod_roots:
		return {
			'root': mod_roots[mod_name],
			'mod_name': mod_name,
		}

	raise Exception("Mod folder not found. Put your mod in the mods directory and type the folder name exactly.")


def get_local_mod_root(mod_name):
	mod_roots = get_local_mod_roots()
	if mod_name in mod_roots:
		return {
			'root': mod_roots[mod_name],
			'mod_name': mod_name,
		}

	raise Exception("Mod folder not found. Put your mod in the mods directory and type the folder name exactly.")


def package_mod_root(mod_root):
	mod_name = os.path.basename(os.path.normpath(mod_root))
	temp_dir = tempfile.TemporaryDirectory(prefix='rw3_workshop_upload_')
	content_root = os.path.join(temp_dir.name, 'content')
	packaged_mod_root = os.path.join(content_root, mod_name)

	def ignore_files(folder, names):
		ignored = []
		if folder == mod_root and WORKSHOP_ID_FILENAME in names:
			ignored.append(WORKSHOP_ID_FILENAME)
		if '__pycache__' in names:
			ignored.append('__pycache__')
		return ignored

	shutil.copytree(mod_root, packaged_mod_root, ignore=ignore_files)
	return temp_dir, content_root


def get_saved_item_id_path(mod_root):
	return os.path.join(mod_root, WORKSHOP_ID_FILENAME)


def read_saved_item_id(mod_root):
	path = get_saved_item_id_path(mod_root)
	if not os.path.exists(path):
		return None

	with open(path, 'r', encoding='utf-8') as file:
		value = file.read().strip()

	if value.isdigit() and int(value) > 0:
		return int(value)

	print("Ignoring invalid Workshop item ID in %s" % path)
	return None


def write_saved_item_id(mod_root, published_file_id):
	path = get_saved_item_id_path(mod_root)
	with open(path, 'w', encoding='utf-8') as file:
		file.write(str(published_file_id) + '\n')
	print("Saved Workshop item ID to %s" % path)


def connect_steam():
	try:
		steam = steamworks.STEAMWORKS()
		steam.initialize()
		if not steam.app_id:
			steam.app_id = steam.Utils.GetAppID()
		if not steam.app_id:
			raise Exception("Steam did not report a valid app id.")
		return steam
	except Exception as exc:
		message = str(exc)
		if "Steam is not running" in message:
			raise Exception("Steam is not running. Start the Steam client, log in, and launch this tool again.")
		if "Not logged on" in message or "connection to Steam client could not be established" in message:
			raise Exception("Steam is not logged in or the Steam client connection failed. Log in to Steam with the Workshop-authoring account and try again.")
		if "steam_appid.txt missing" in message:
			raise Exception("steam_appid.txt is missing next to UploadModToWorkshop.py.")
		if "Missing library" in message:
			raise Exception("SteamworksPy native library is missing next to UploadModToWorkshop.py.")
		raise Exception("Failed to initialize Steam: %s" % message)


def make_create_handler(state):
	def on_item_created(*args, **kwargs):
		result = args[0]
		state['create_result'] = {
			'result': int(result.result),
			'publishedFileId': int(result.publishedFileId),
			'userNeedsToAcceptWorkshopLegalAgreement': bool(result.userNeedsToAcceptWorkshopLegalAgreement),
		}
	return on_item_created


def make_update_handler(state):
	def on_item_updated(*args, **kwargs):
		result = args[0].contents
		state['update_result'] = {
			'result': int(result.result),
			'userNeedsToAcceptWorkshopLegalAgreement': bool(result.userNeedsToAcceptWorkshopLegalAgreement),
		}
	return on_item_updated


def wait_for_result(steam, state, key, label):
	start = time.time()
	while state[key] is None:
		steam.run_callbacks()
		time.sleep(0.1)
		if time.time() - start > 300:
			raise Exception("%s timed out." % label)
	return state[key]


def ensure_result_ok(result, label):
	if result['result'] != RESULT_OK:
		raise Exception("%s failed with EResult %s" % (label, result['result']))


def get_workshop_item_page_url(published_file_id):
	return "https://steamcommunity.com/sharedfiles/filedetails/?id=%s" % published_file_id


def open_workshop_item_page(published_file_id):
	steam_url = "steam://url/CommunityFilePage/%s" % published_file_id
	web_url = get_workshop_item_page_url(published_file_id)
	try:
		if not webbrowser.open(steam_url):
			webbrowser.open(web_url)
	except Exception:
		pass
	print("Workshop item page: %s" % web_url)


def print_submission_notice():
	print("By submitting this item, you agree to the Steam Workshop terms of service:")
	print("https://steamcommunity.com/sharedfiles/workshoplegalagreement")
	print("")


def print_legal_agreement_notice(published_file_id):
	print("Steam requires the Workshop Legal Agreement for item %s." % published_file_id)
	print("Accept it here: https://steamcommunity.com/sharedfiles/workshoplegalagreement")
	print("Then review the item here: %s" % get_workshop_item_page_url(published_file_id))


def create_workshop_item(steam):
	state = {'create_result': None}
	steam.Workshop.CreateItem(steam.app_id, WORKSHOP_FILE_TYPE_COMMUNITY, callback=make_create_handler(state))
	result = wait_for_result(steam, state, 'create_result', 'CreateItem')
	ensure_result_ok(result, 'CreateItem')

	published_file_id = result['publishedFileId']
	print("Created Workshop item %s" % published_file_id)
	if result['userNeedsToAcceptWorkshopLegalAgreement']:
		print_legal_agreement_notice(published_file_id)
	return published_file_id


def format_progress_status(status):
	text = str(status)
	if '.' in text:
		text = text.split('.')[-1]
	return text


def wait_for_update_result(steam, state, update_handle):
	start = time.time()
	last_progress_line = None
	last_progress_time = 0

	while state['update_result'] is None:
		steam.run_callbacks()
		if state['update_result'] is not None:
			break
		now = time.time()
		if now - last_progress_time >= 1.0:
			progress = steam.Workshop.GetItemUpdateProgress(update_handle)
			status_text = format_progress_status(progress['status'])
			total = int(progress['total'])
			processed = int(progress['processed'])
			if total > 0:
				progress_line = "Upload progress: %s (%d%%, %d / %d bytes)" % (
					status_text,
					int(progress['progress'] * 100),
					processed,
					total,
				)
			else:
				progress_line = "Upload progress: %s" % status_text

			if progress_line != last_progress_line:
				print(progress_line)
				last_progress_line = progress_line
			last_progress_time = now

		time.sleep(0.1)
		if now - start > 300:
			raise Exception("SubmitItemUpdate timed out.")

	return state['update_result']


def submit_workshop_item_update(steam, published_file_id, content_root, preview_path, is_new_item, title=None, description="", visibility=VISIBILITY_PRIVATE, change_note=""):
	update_handle = steam.Workshop.StartItemUpdate(steam.app_id, published_file_id)
	if not update_handle:
		raise Exception("StartItemUpdate failed for item %s" % published_file_id)

	if is_new_item:
		if not steam.Workshop.SetItemTitle(update_handle, title):
			raise Exception("SetItemTitle failed")
		if not steam.Workshop.SetItemDescription(update_handle, description):
			raise Exception("SetItemDescription failed")
		if not steam.Workshop.SetItemVisibility(update_handle, visibility):
			raise Exception("SetItemVisibility failed")
		if not steam.Workshop.SetItemPreview(update_handle, preview_path):
			raise Exception("SetItemPreview failed. Steam expects an absolute local JPG, PNG, or GIF preview image, and your app must have Steam Cloud quota configured for Workshop previews.")
	if not steam.Workshop.SetItemContent(update_handle, content_root):
		raise Exception("SetItemContent failed")

	state = {'update_result': None}
	steam.Workshop.SubmitItemUpdate(update_handle, change_note, callback=make_update_handler(state))

	print("Uploading Workshop item %s..." % published_file_id)
	result = wait_for_update_result(steam, state, update_handle)
	ensure_result_ok(result, 'SubmitItemUpdate')

	if result['userNeedsToAcceptWorkshopLegalAgreement']:
		print_legal_agreement_notice(published_file_id)


def get_uploader_crash_log_path():
	return os.path.abspath('uploader_crash.txt')


def write_uploader_crash_log():
	path = get_uploader_crash_log_path()
	with open(path, 'w', encoding='utf-8') as file:
		file.write("Rift Wizard 3 Workshop uploader crash log\n\n")
		traceback.print_exc(file=file)
	return path


def main(mod=None):
	print("Rift Wizard 3 Workshop uploader")
	print("")

	if mod is None:
		mod = read_mod_root()
	saved_item_id = read_saved_item_id(mod['root'])
	is_new_item = not saved_item_id
	preview_path = read_preview_file(mod['root']) if is_new_item else None

	print("")
	print_submission_notice()

	steam = connect_steam()
	if saved_item_id:
		published_file_id = saved_item_id
		print("Updating Workshop item %s" % published_file_id)
	else:
		published_file_id = create_workshop_item(steam)
		write_saved_item_id(mod['root'], published_file_id)
		print("First upload defaults to private visibility. Edit the Workshop page afterward to change title, description, or visibility.")

	temp_dir, content_root = package_mod_root(mod['root'])
	try:
		submit_workshop_item_update(
			steam,
			published_file_id,
			content_root,
			preview_path,
			is_new_item,
			title=mod['mod_name'],
		)
	finally:
		temp_dir.cleanup()

	open_workshop_item_page(published_file_id)

	print("")
	print("Workshop upload complete.")
	print("Item ID: %s" % published_file_id)
	print("Item page: %s" % get_workshop_item_page_url(published_file_id))
	return published_file_id


def run_uploader_with_crash_log(mod=None):
	try:
		published_file_id = main(mod=mod)
		return {
			'ok': True,
			'published_file_id': published_file_id,
			'error': None,
			'crash_log_path': None,
		}
	except Exception:
		crash_log_path = write_uploader_crash_log()
		traceback.print_exc()
		print("")
		print("Uploader crashed. Crash log: %s" % crash_log_path)
		return {
			'ok': False,
			'published_file_id': None,
			'error': traceback.format_exc(),
			'crash_log_path': crash_log_path,
		}


if __name__ == '__main__':
	result = run_uploader_with_crash_log()
	if not result['ok']:
		raise SystemExit(1)
