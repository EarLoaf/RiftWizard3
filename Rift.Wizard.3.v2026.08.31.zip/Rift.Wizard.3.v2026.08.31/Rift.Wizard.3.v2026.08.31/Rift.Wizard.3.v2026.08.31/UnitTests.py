import os

from Game import *
from Level import *
from Monsters import GreenSlime
from Spells import *
from CommonContent import SimpleSummon
from FinalBosses import Mordred, final_bosses
from LevelGen import LevelGenerator
from Mutators import *


class TestBuff1(Buff):
	pass

class TestBuff2(Buff):
	pass

def show_progress(msg):
	print(msg.ljust(140), end='\r')

def finish_progress(msg):
	print(msg.ljust(140))

def test_buff_spells():
	level = Level(2, 2)

	test_spell = Spell()
	test_spell.name = "test spell"

	test_buff = TestBuff1()
	test_buff.spells = [test_spell]

	test_unit = Unit()
	test_unit.spells = [test_spell]


	level.add_obj(test_unit, 1, 1)
	test_unit.apply_buff(test_buff)
	assert(test_spell in test_unit.spells)

	# unit should still have spell since it had it before the buff
	test_unit.remove_buff(test_buff)
	assert(test_spell in test_unit.spells)

	level.remove_obj(test_unit)

	test_unit2 = Unit()
	level.add_obj(test_unit2, 1, 1)
	test_unit2.apply_buff(test_buff)
	test_unit2.remove_buff(test_buff)

	# This unit should have lost the buff spell since it did not have it to begin with
	assert(test_spell not in test_unit2.spells)

	test_buff2 = TestBuff2()
	test_buff2.spells = [test_spell]

	test_unit2.apply_buff(test_buff)
	test_unit2.apply_buff(test_buff2)

	assert(len(test_unit2.buffs) == 2)

	test_unit2.remove_buff(test_buff)
	assert(test_spell in test_unit2.spells)

	test_unit2.remove_buff(test_buff2)
	assert(test_spell not in test_unit2.spells)

def choose_test_target(spell, player, level):
	target = spell.get_ai_target()
	if isinstance(target, Unit):
		target = Point(target.x, target.y)
	if target and spell.can_cast(target.x, target.y):
		return target

	# Prefer the reserved summon pad center for empty-tile summon spells
	for target in [Point(3, 3), Point(4, 4), Point(5, 5)]:
		if spell.can_cast(target.x, target.y):
			return target

	if spell.can_target_self and spell.can_cast(player.x, player.y):
		return Point(player.x, player.y)

	targets = [Point(t.x, t.y) for t in level.iter_tiles() if spell.can_cast(t.x, t.y)]
	if not targets:
		raise AssertionError(f"{spell.name} had no valid smoke-test target")

	hostile_targets = []
	for target in targets:
		unit = level.get_unit_at(target.x, target.y)
		if unit and are_hostile(player, unit):
			hostile_targets.append(target)

	if hostile_targets:
		hostile_targets.sort(key=lambda p: distance(player, p))
		return hostile_targets[0]

	targets.sort(key=lambda p: distance(player, p))
	return targets[0]

def test_cast(spell, upg=False):
	level = Level(LEVEL_SIZE, LEVEL_SIZE)
	player = Unit()
	player.max_hp = 6000
	player.team = TEAM_PLAYER
	# The 'player' will use this each turn instead of spell
	player.add_spell(SimpleMeleeAttack(1))
	player.add_spell(spell)

	# For logging stuff
	level.player_unit = player

	# Add a spent flameburst for mystic memory or other 0 charge things
	fb = FlameBurstSpell()
	player.add_spell(fb)
	fb.cur_charges = 0

	level.add_obj(player, 1, 1)

	friend = Unit()
	friend.max_hp = 50
	friend.cur_hp = 25
	friend.tags = [Tags.Living]
	friend.team = TEAM_PLAYER
	level.add_obj(friend, 1, 2)

	friend2 = Unit()
	friend2.max_hp = 40
	friend2.cur_hp = 40
	friend2.tags = [Tags.Living, Tags.Nature]
	friend2.team = TEAM_PLAYER
	level.add_obj(friend2, 2, 1)

	friend3 = Unit()
	friend3.max_hp = 35
	friend3.cur_hp = 20
	friend3.tags = [Tags.Living, Tags.Arcane]
	friend3.team = TEAM_PLAYER
	level.add_obj(friend3, 3, 1)
	
	if upg:
		for upgrade in spell.spell_upgrades:
			player.apply_buff(upgrade)

	# Make a wall and a chasm for sblast and volcano and maybe other spells
	level.make_wall(1, 0)
	level.make_chasm(0, 1)

	# Seed cloud targets for cloud-dependent spells like Storm Walk
	level.add_obj(StormCloud(player), 7, 7)
	level.add_obj(BlizzardCloud(player), 8, 7)
	level.add_obj(RainCloud(player), 9, 7)

	# Reserve a clear summon area for large summons
	summon_pad = set((x, y) for x in range(2, 6) for y in range(2, 6))

	# Checker the board with high hp low damage enemies with each tag
	for tile in level.iter_tiles():
		if tile.x == tile.y == 0:
			continue

		if tile.unit:
			continue

		if (tile.x, tile.y) in summon_pad:
			continue

		# Leave empty space from indices 5 to 8
		if tile.x > 5:
			continue
		if tile.y > 5:
			continue

		if ((tile.x + tile.y) % 2 == 0):
			unit = Unit()
			unit.cur_hp = 39
			unit.max_hp	= 40
			unit.tags = [t for t in monster_tags]
			team_idx = ((tile.x + tile.y) % 4) // 2
			unit.team = [TEAM_PLAYER, TEAM_ENEMY][team_idx]

			# Always physical for now- make varied?
			unit.spells.append(SimpleMeleeAttack(1))
			level.add_obj(unit, tile.x, tile.y)

	spell.modify_test_level(level)

	target = choose_test_target(spell, player, level)
	level.act_cast(player, spell, target.x, target.y)
	channel_turns = 10
	if hasattr(spell, 'max_channel'):
		channel_turns = max(channel_turns, spell.max_channel + 2)
	for _ in range(channel_turns):
		level.advance(full_turn=True)


def test_each_player_spell():

	for upg in [False, True]:
		# To remake skills spells ect
		game = Game()
		spells = list(reversed(game.all_player_spells))
		for i, spell in enumerate(spells):
			show_progress("Testing spells %d/%d upgraded=%s: %s" % (i + 1, len(spells), upg, spell.name))
			try:
				test_cast(spell, upg)
			except Exception as exc:
				print()
				raise Exception(f"Spell smoke test failed for {spell.name} upgraded={upg}") from exc
	finish_progress("Tested all player spells")

class TestEquipmentPersistenceItem(Equipment):

	def on_init(self):
		self.name = "Test Equipment Persistence Item"
		self.resists[Tags.Fire] = 1
		self.owner_triggers[EventOnUnitAdded] = self.on_added

	def on_added(self, evt):
		self.owner.add_shields(1)

def test_stairs_with_buff():
	game = Game(generate_level=False)
	item = TestEquipmentPersistenceItem()
	game.p1.equip(item)
	assert(game.p1.resists[Tags.Fire] == 1)
	assert(game.p1.shields == 1)

	# Equipment effects should survive portal deployment and resubscribe on the new level.
	game.enter_portal()
	assert(game.deploying)
	assert(game.try_deploy(0, 0))

	assert(game.p1.resists[Tags.Fire] == 1)
	assert(game.p1.shields == 1)

	event_manager = game.cur_level.event_manager
	assert(len(event_manager._handlers[EventOnUnitAdded][game.p1]) == 1)


def make_smoke_enemy():
	unit = Unit()
	unit.max_hp = 250
	unit.cur_hp = 250
	unit.team = TEAM_ENEMY
	unit.tags = [Tags.Living]
	unit.spells.append(SimpleMeleeAttack(1))
	return unit

def test_battle_royale():
	# Add each monster to a level, perma berserk it, see what happens
	# Do it 3 times since theres lots of randomness
	for round_num in range(3):
		show_progress("Battle royale round %d/3" % (round_num + 1))
		try:
			game = Game(generate_level=False)

			game.p1.cur_hp = 100000000
			game.p1.max_hp = 100000000

			monsters = [s[0]() for s in spawn_options]
			i = 0
			for t in game.cur_level.iter_tiles():
				i += 1
				if not monsters:
					break
				if t.unit:
					continue
				cur_monster = monsters.pop()
				cur_monster.team = [TEAM_PLAYER, TEAM_ENEMY][i % 2]
				game.cur_level.add_obj(cur_monster, t.x, t.y)
				cur_monster.apply_buff(BerserkBuff())

			for i in range(2500):
				if game.is_awaiting_input():
					game.try_pass()
				game.advance()	
		except Exception as exc:
			print()
			raise Exception(f"Battle royale smoke test failed on round {round_num}") from exc
	finish_progress("Battle royale complete")

def test_each_player_equipment():
	base_game = Game(generate_level=False)

	for i, template in enumerate(base_game.all_player_items):
		show_progress("Testing equipment %d/%d: %s" % (i + 1, len(base_game.all_player_items), template.name))
		try:
			game = Game(generate_level=False)
			player = game.p1
			player.max_hp = 10000
			player.cur_hp = 10000
			player.spells = []

			fireball = FireballSpell()
			lightning = LightningBoltSpell()
			deathbolt = DeathBolt()
			wolf = SummonWolfSpell()
			eye = SummonFloatingEye()
			for spell in [fireball, lightning, deathbolt, wolf, eye]:
				player.add_spell(spell)

			item = template.clone()
			player.equip(item)

			game.enter_portal()
			assert(game.try_deploy(0, 0))

			level = game.cur_level

			ally = Unit()
			ally.max_hp = 50
			ally.cur_hp = 25
			ally.team = TEAM_PLAYER
			ally.tags = [Tags.Living]
			level.add_obj(ally, 1, 2)

			slime = GreenSlime()
			slime.team = TEAM_PLAYER
			level.add_obj(slime, 2, 1)

			for x, y in [(5, 5), (6, 5), (5, 6)]:
				level.add_obj(make_smoke_enemy(), x, y)

			for spell, x, y in [(wolf, 3, 1), (eye, 3, 2), (fireball, 5, 5), (lightning, 6, 5), (deathbolt, 5, 6)]:
				if spell.can_cast(x, y):
					level.act_cast(player, spell, x, y)
				for _ in range(3):
					game.advance()
		except Exception as exc:
			print()
			raise Exception(f"Equipment smoke test failed for {template.name}") from exc
	finish_progress("Tested all player equipment")

def test_rare_monsters():
	batch_size = 8
	i = 0
	total_batches = (len(rare_monsters) + batch_size - 1) // batch_size
	while i * batch_size < len(rare_monsters):
		batch = rare_monsters[i*batch_size:(i+1)*batch_size]
		show_progress("Testing rare monster batch %d/%d" % (i + 1, total_batches))
		try:
			p1 = Unit()

			dtypes = [Tags.Dark, Tags.Physical, Tags.Arcane, Tags.Fire, Tags.Ice, Tags.Lightning]
			for tag in dtypes:
				zap = SimpleRangedAttack(damage=25, range=16, damage_type=tag)
				zap.radius = 3
				zap.cool_down = len(dtypes)
				p1.spells.append(zap)
				zap.beam = True

			p1.max_hp = 100000
			p1.team = TEAM_PLAYER
			p1.buffs.append(TeleportyBuff(radius=15, chance=.1))

			difficulty = 2
			gen = LevelGenerator(difficulty)
			
			gen.num_monsters = 7
			gen.num_generators = 2
			gen.bosses = []

			for e in batch:
				gen.bosses.append(e[0]())

			level = gen.make_level()
			level.start_pos = gen.empty_spawn_points.pop()
			
			level.spawn_player(p1)

			for _ in range(80):
				level.advance(full_turn=True)
		except Exception as exc:
			names = ", ".join(e[0]().name for e in batch)
			print()
			raise Exception(f"Rare monster smoke test failed for batch {i}: {names}") from exc

		i += 1
	finish_progress("Tested all rare monster batches")


def test_predictable_fight():
	level = Level(5, 5)
	u1 = Unit()
	u1.max_hp = 10
	u1.spells = [SimpleRangedAttack(damage=5, range=5)]
	u1.team = TEAM_PLAYER

	u2 = Unit()
	u2.max_hp = 10
	u2.spells = [SimpleRangedAttack(damage=5, range=5)]
	u2.team = TEAM_ENEMY

	level.add_obj(u1, 0, 0)
	level.add_obj(u2, 3, 3)

	level.advance(full_turn=True)
	assert(u1.cur_hp == u2.cur_hp == 5)

def test_levelgen():
	p1 = Unit()
	for i in range(200):
		show_progress("Generating level %d/200" % (i + 1))
		difficulty = (i % 20) + 1
		level = LevelGenerator(difficulty=difficulty).make_level()
	finish_progress("Generated 200 levels")

def test_tag_income():
	tag_incomes = defaultdict(list)
	for i in range(100):
		for l in range(LAST_LEVEL):
			difficulty = l + 1
			level = LevelGenerator(difficulty=difficulty)
			tag_incomes[difficulty].append(level.num_component_tags)
	for lvl, incomes in tag_incomes.items():
		avg = sum(incomes) / len(incomes)
		mi = min(incomes)
		ma = max(incomes)
		print(f"Level {lvl} stats: avg: {avg}, min: {mi}, max: {ma}")

def test_seeded_levelgen():

	cases = [(10, .5234), (1, 3), (1, 5), (20, .123123), (25, .135599)]
	for i, (diff, seed) in enumerate(cases):

		show_progress("Comparing levelgen %d/%d diff=%s seed=%s" % (i + 1, len(cases), diff, seed))
		generator1 = LevelGenerator(difficulty=diff, seed=seed)
		l1 = generator1.make_level()

		generator2 = LevelGenerator(difficulty=diff, seed=seed)
		l2 = generator2.make_level()

		assert(len(l1.tiles) == len(l2.tiles))
		for i in range(len(l1.tiles)):
			assert(len(l1.tiles[i]) == len(l2.tiles[i]))
			for j in range(len(l1.tiles[i])):
				t1 = l1.tiles[i][j]
				t2 = l2.tiles[i][j]

				if t1.can_walk != t2.can_walk or t1.can_see != t2.can_see:
					print("Tile discrepency at %d, %d" % (i, j))
					print("Tile1: Walkable %d, Visible %d" % (t1.can_walk, t1.can_see))
					print("Tile2: Walkable %d, Visible %d" % (t2.can_walk, t2.can_see))
					assert(False)
				
				prop1 = t1.prop.name if t1.prop else None
				prop2 = t2.prop.name if t2.prop else None
				if prop1 != prop2:
					print("Prop discrepency at %d, %d" % (i, j))
					print("Map 1 has %s, Map 2 has %s" % (prop1, prop2))
					assert(False)

				unit1 = t1.unit.name if t1.unit else None
				unit2 = t2.unit.name if t2.unit else None
				if unit1 != unit2:
					print("Unit discrepency at %d, %d" % (i, j))
					print("Map 1 has %s, Map 2 has %s" % (unit1, unit2))
					assert(False)
	finish_progress("Compared seeded levelgen cases")

def test_trials():
	for i, trial in enumerate(all_trials):
		show_progress("Testing trial %d/%d: %s" % (i + 1, len(all_trials), trial.name))
		game = Game(save_enabled=True, mutators=trial.mutators, trial_name=trial.name)
		game.p1.is_player_controlled = False
		game.p1.add_spell(SimpleRangedAttack(damage=10, damage_type=Tags.Physical, range=5))
		for i in range(25): game.advance()
	finish_progress("Tested all trials")

def test_weekly_mods():
	for i, mod in enumerate(weekly_mods):
		show_progress("Testing weekly mod %d/%d: %s" % (i + 1, len(weekly_mods), mod.description))
		game = Game(mutators=[mod])
		game.p1.is_player_controlled = False
		game.p1.add_spell(SimpleRangedAttack(damage=10, damage_type=Tags.Physical, range=5))
		for i in range(25): game.advance()
	finish_progress("Tested all weekly mods")

def test_sprites():
	def get_test_unit_asset(unit):
		if unit.asset: return unit.asset

		name = unit.get_asset_name()

		if Tags.Undead in unit.tags and "skeletal" in name:
			if unit.stationary: name = "skeletal_stationary"
			elif unit.flying: name = 'skeletal_flying'
			else: name = "skeletal"

		if unit.is_lair and hasattr(unit, "spells"):
			summoned = unit.get_spell(SimpleSummon).spawn_func()
			if summoned.asset: return ["lair_combo"] + summoned.asset
			name = summoned.get_asset_name()
			if name: return ["lair_combo", 'char', name]
			return ['char', 'lair']

		return ['char', name]

	def sprite_asset_exists(asset):
		if not asset: return True

		if asset[0] == 'lair_combo': return sprite_asset_exists(asset[1:]) and sprite_asset_exists(['char', 'lair'])

		path = os.path.join('rl_data', *asset) + '.png'
		if os.path.exists(path): return True

		mod_path = os.path.join('mods', *asset) + '.png'
		return os.path.exists(mod_path)

	def tt_objs(obj):
		getter = getattr(obj, 'get_extra_examine_tooltips', None)
		if not getter: return []
		return [extra for extra in (getter() or []) if isinstance(extra, Unit)]

	def sprite_visit_key(obj):
		asset = get_test_unit_asset(obj)
		if isinstance(asset, list): asset = tuple(asset)

		return (
			type(obj).__name__,
			getattr(obj, 'name', None),
			asset,
			getattr(obj, 'asset_name', None),
			getattr(obj, 'radius', None),
			getattr(obj, 'stationary', None),
			getattr(obj, 'flying', None),
			getattr(obj, 'is_lair', None),
			tuple(sorted(t.name for t in getattr(obj, 'tags', []))),
			tuple(type(s).__name__ for s in getattr(obj, 'spells', [])),
			tuple(type(b).__name__ for b in getattr(obj, 'buffs', [])),
		)

	def check_sprite_asset(asset, source, missing):
		if sprite_asset_exists(asset): return
		missing.setdefault(tuple(asset), set()).add(source)

	def iter_test_sprite_roots():
		for factory, *_ in spawn_options:
			yield factory()

		for factory, *_ in rare_monsters:
			yield factory()

		for factory in final_bosses:
			yield factory()

		yield Mordred()

	def walk_sprite_graph(obj, source, missing, seen):
		if not isinstance(obj, Unit): return

		key = sprite_visit_key(obj)
		if key in seen: return
		seen.add(key)

		check_sprite_asset(get_test_unit_asset(obj), source, missing)

		for spell in obj.spells:
			if spell.caster is None: spell.caster = obj
			if spell.owner is None: spell.owner = obj
			unit_extra_getter = getattr(spell, 'get_unit_extra_examine_tooltips', None)
			if unit_extra_getter:
				for extra in unit_extra_getter() or []:
					walk_sprite_graph(extra, f"{source} spell {spell.name}", missing, seen)
			for extra in tt_objs(spell):
				walk_sprite_graph(extra, f"{source} spell {spell.name} extra", missing, seen)

		for buff in obj.buffs:
			if buff.owner is None: buff.owner = obj
			unit_extra_getter = getattr(buff, 'get_unit_extra_examine_tooltips', None)
			if unit_extra_getter:
				for extra in unit_extra_getter() or []:
					walk_sprite_graph(extra, f"{source} buff {buff.name}", missing, seen)
			for extra in tt_objs(buff):
				walk_sprite_graph(extra, f"{source} buff {buff.name} extra", missing, seen)

		for extra in obj.get_extra_examine_tooltips() or []:
			walk_sprite_graph(extra, f"{source} extra", missing, seen)

	missing = {}
	seen = set()

	for unit in iter_test_sprite_roots():
		walk_sprite_graph(unit, unit.name, missing, seen)

	if missing:
		lines = []
		for asset, sources in sorted(missing.items()):
			lines.append(f"Missing sprite asset for {list(asset)}")
			for source in sorted(sources):
				lines.append(source)
		assert False, "\n".join(lines)

	print("test_sprites passed")


def run_tests():

	test_buff_spells()
	test_stairs_with_buff()
	test_predictable_fight()
	test_seeded_levelgen()
	test_sprites()

	# broad smoke tests:
	test_battle_royale()
	test_rare_monsters()
	test_levelgen()
	test_tag_income()
	test_trials()
	test_weekly_mods()
	test_each_player_spell()
	test_each_player_equipment()

	print("run_tests passed")


if __name__ == "__main__":
	run_tests()
