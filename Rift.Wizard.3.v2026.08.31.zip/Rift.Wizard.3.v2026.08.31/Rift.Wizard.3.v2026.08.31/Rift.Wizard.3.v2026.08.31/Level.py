from collections import defaultdict, namedtuple, OrderedDict, deque
import math
import logging
import random
import time
import os
import heapq
from copy import copy
import tcod
from tcod import libtcodpy
import Localisation as loc
import text

logger = None

Point = namedtuple("Point", "x y")

TEAM_PLAYER = 0
TEAM_ENEMY = 1

LAST_LEVEL = 21

MAX_SPELLS = 10

RANGE_GLOBAL = 36

# Special value for on_apply
ABORT_BUFF_APPLY = 99

# Max advance time = 20 milliseconds
MAX_ADVANCE_TIME = .02

TILE_TYPE_FLOOR = 0
TILE_TYPE_WALL = 1
TILE_TYPE_CHASM = 2

EVENT_RECURSION_CAP = 64
DAMAGE_INSTANCE_CAP = 256
DEFERRED_CAST_CAP = 2048
EXTRA_TURNS_CAP = 2048

EFFECT_COLORS_PER_TILE = 3

# Keep effect swarms from dragging frames down
EFFECT_PRESSURE_MED = 150
EFFECT_PRESSURE_HIGH = 250

visual_mode = False
def set_visual_mode(val):
	global visual_mode
	visual_mode = val

class PriorityQueue:
	def __init__(self):
		self.elements = []
	
	def empty(self):
		return len(self.elements) == 0
	
	def put(self, item, priority):
		heapq.heappush(self.elements, (priority, item))
	
	def get(self):
		return heapq.heappop(self.elements)[1]


def distance(p1, p2, diag=False, euclidean=True):
	dx = p1.x - p2.x
	dy = p1.y - p2.y
	adx = dx if dx >= 0 else -dx
	ady = dy if dy >= 0 else -dy
	if diag: return adx if adx > ady else ady
	if euclidean: return math.sqrt(dx * dx + dy * dy)
	return adx + ady


LEVEL_SIZE = 18
points_in_ball_cache = {}
points_in_ring_at_center_cache = []
MAX_RING_RADIUS = int(math.ceil(math.sqrt(((LEVEL_SIZE - 1) * (LEVEL_SIZE - 1)) * 2)))


def get_points_in_ball_offsets(rounded_radius, diag):
	key = (rounded_radius, diag)
	cached = points_in_ball_cache.get(key)
	if cached is not None: return cached

	offsets = []
	origin = Point(0, 0)
	for dx in range(-rounded_radius, rounded_radius + 1):
		for dy in range(-rounded_radius, rounded_radius + 1):
			dist = distance(Point(dx, dy), origin, diag=diag)
			if dist <= rounded_radius:
				offsets.append((dx, dy, dist))

	points_in_ball_cache[key] = offsets
	return offsets


def build_points_in_ball_cache(max_radius):
	for rounded_radius in range(max_radius + 1):
		get_points_in_ball_offsets(rounded_radius, diag=False)
		get_points_in_ball_offsets(rounded_radius, diag=True)


def build_points_in_ring_at_center_cache(level_size):
	global points_in_ring_at_center_cache
	points_in_ring_at_center_cache = [[None for _ in range(level_size)] for _ in range(level_size)]

	for cx in range(level_size):
		for cy in range(level_size):
			rings = []
			for r in range(MAX_RING_RADIUS + 1):
				ring = []
				for dx, dy, dist in get_points_in_ball_offsets(r, diag=False):
					if dist <= r - 1: continue
					px = cx + dx
					py = cy + dy
					if 0 <= px < level_size and 0 <= py < level_size:
						ring.append(Point(px, py))
				rings.append(ring)
			points_in_ring_at_center_cache[cx][cy] = rings


def get_points_in_ring_at_center(x, y, r):
	if x < 0 or y < 0 or x >= LEVEL_SIZE or y >= LEVEL_SIZE: return []
	if r < 0 or r > MAX_RING_RADIUS: return []
	return points_in_ring_at_center_cache[x][y][r]


build_points_in_ball_cache(LEVEL_SIZE)
build_points_in_ring_at_center_cache(LEVEL_SIZE)

def are_friendly(unit1, unit2):
	return not are_hostile(unit1, unit2)

def are_hostile(unit1, unit2):
	if unit1 == unit2: return False
	if unit1.team != unit2.team: return True

	# Player cannot be berserked- and we can save a trip through the buff list by short circuiting out on the player
	# (The player is a very common arg for unit1 or unit2)
	if (not unit1.is_player_controlled and unit1.has_buff(BerserkBuff)) or (not unit2.is_player_controlled and unit2.has_buff(BerserkBuff)):
		return True

	return False

formatted_attrs = {'requires_los':'Requires LoS', 'hp_cost': 'HP Cost'}
def format_attr(attr):
	cached = formatted_attrs.get(attr, None)
	if cached is not None: return cached
	label = ' '.join(w.capitalize() for w in attr.replace('_', ' ').split())
	formatted_attrs[attr] = label
	return label

def dot_product(x1, y1, x2, y2):
	return x1 * x2 + y1 * y2

# Returns the minimum angle between the lines AB and AC
def get_min_angle(A_x, A_y, B_x, B_y, C_x, C_y):
	AB_x = B_x - A_x
	AB_y = B_y - A_y
	AC_x = C_x - A_x
	AC_y = C_y - A_y

	len_AB = math.sqrt(dot_product(AB_x, AB_y, AB_x, AB_y))
	len_AC = math.sqrt(dot_product(AC_x, AC_y, AC_x, AC_y))

	# return 0 if 2 of the points are the same
	if len_AB == 0 or len_AC == 0:
		return 0

	cos_theta = dot_product(AB_x, AB_y, AC_x, AC_y) / (len_AB * len_AC)
	cos_theta = min(1.0, cos_theta)
	cos_theta = max(-1.0, cos_theta)
	
	theta = math.acos(cos_theta)
	return theta;

EventOnSpellCast = namedtuple("EventOnSpellCast", "spell caster x y pay_costs")
EventOnRitualComplete = namedtuple("EventOnRitualComplete", "spell, caster, channel_buff")
EventOnDeath = namedtuple("EventOnDeath", "unit damage_event")
EventOnPropEnter = namedtuple("EventOnPropEnter", "unit prop")
EventOnPreDamaged = namedtuple("EventOnPreDamaged", "unit damage unresisted_damage damage_type source")
EventOnDamaged = namedtuple("EventOnDamaged", "unit damage damage_type source")
EventOnHealed = namedtuple("EventOnHealed", "unit heal source")
EventOnItemPickup = namedtuple("EventOnItemPickup", "item")
EventOnBuffAttemptApply = namedtuple("EventOnBuffAttemptApply", "buff duration unit")
EventOnBuffApply = namedtuple("EventOnBuffApply", "buff unit")
EventOnBuffRemove = namedtuple("EventOnBuffRemove", "buff unit")
EventOnMoved = namedtuple("EventOnMoved", "unit x y teleport old_x old_y")
EventOnUnitAdded = namedtuple("EventOnUnitAdded", "unit")
EventOnUnitPreAdded = namedtuple("EventOnUnitPreAdded", "unit")
EventOnPass = namedtuple("EventOnPass", "unit")
EventOnSpendHP = namedtuple("EventOnSpendHP", "unit hp")
EventOnShieldRemoved = namedtuple("EventOnShieldRemoved", "unit source")
EventOnLevelComplete = namedtuple("EventOnLevelComplete", "level")
EventOnReroll = namedtuple("EventOnReroll", "level")

CastContext = namedtuple("CastContext", "spell caster x y pay_costs cast_kwargs")


class EventHandler():
	# A system for dynamically registering and unregistering from global or entity scoped events
	# This is meant for flexible content like spells and buffs
	# Global game rules should not use dynamic subscriptions, they should be static in code.
	# We only need this because iterating over every buff on every character every time anything happened would be impractical

	def __init__(self):
		self._queue = []
		self._handlers = {}
		self.event_depth = 0

	def register_global_trigger(self, event_type, handler):
		assert (isinstance(event_type, type))
		evt_map = self._handlers.setdefault(event_type, {})
		handlers = evt_map.get(None)
		evt_map[None] = (handler,) if handlers is None else handlers + (handler,)

	def unregister_global_trigger(self, event_type, handler):
		assert (isinstance(event_type, type))
		evt_map = self._handlers.get(event_type)
		if evt_map is None or None not in evt_map: raise ValueError
		handlers = evt_map[None]
		idx = handlers.index(handler)
		if len(handlers) == 1: del evt_map[None]
		else: evt_map[None] = handlers[:idx] + handlers[idx + 1:]
		if not evt_map: del self._handlers[event_type]

	def register_entity_trigger(self, event_type, entity, handler):
		assert (isinstance(event_type, type))
		evt_map = self._handlers.setdefault(event_type, {})
		handlers = evt_map.get(entity)
		evt_map[entity] = (handler,) if handlers is None else handlers + (handler,)

	def unregister_entity_trigger(self, event_type, entity, handler):
		assert (isinstance(event_type, type))
		evt_map = self._handlers.get(event_type)
		if evt_map is None or entity not in evt_map: raise ValueError
		handlers = evt_map[entity]
		idx = handlers.index(handler)
		if len(handlers) == 1: del evt_map[entity]
		else: evt_map[entity] = handlers[:idx] + handlers[idx + 1:]
		if not evt_map: del self._handlers[event_type]

	def has_handlers(self, event_type, entity=None):
		evt_map = self._handlers.get(event_type)
		if not evt_map: return False
		if entity is not None and evt_map.get(entity): return True
		return bool(evt_map.get(None))

	def raise_event(self, event, entity=None):
		evt_map = self._handlers.get(type(event))
		if not evt_map: return
		if self.event_depth >= EVENT_RECURSION_CAP: return

		self.event_depth += 1

		if entity is not None:
			entity_handlers = evt_map.get(entity)
			if entity_handlers:
				for handler in entity_handlers: handler(event)

		global_handlers = evt_map.get(None)
		if global_handlers:
			for handler in global_handlers: handler(event)

		self.event_depth -= 1

def add_event_trigger(mapping, key, func): # add an event trigger on top on an already existing one instead of overriding it.
	existing = mapping.get(key)
	if existing is None: mapping[key] = func; return
	if isinstance(existing, list): existing.append(func); return
	def chained(*args, __old=existing, __new=func, **kwargs):
		__old(*args, **kwargs)
		__new(*args, **kwargs)
	mapping[key] = chained


def add_tooltip(base, new):
	existing = base.get_extra_examine_tooltips
	def wrapped(self, *args, __orig=existing, __new=new, **kwargs):
		if hasattr(__orig, "__self__") and __orig.__self__ is not None: extras = __orig(*args, **kwargs)
		else: extras = __orig(self, *args, **kwargs)
		extras = list(extras) if extras else []
		extras.append(__new)
		return extras
	base.get_extra_examine_tooltips = wrapped.__get__(base, type(base))

def add_tooltip_fn(base, new):
	existing = base.get_extra_examine_tooltips
	def wrapped(self, *args, __orig=existing, __new=new, **kwargs):
		extras = list(__orig(*args, **kwargs))
		tooltip = __new()
		if tooltip is not None:
			extras.append(tooltip)
		return extras
	base.get_extra_examine_tooltips = wrapped.__get__(base, type(base))

# Apply bonuses to a summoned unit
def apply_minion_bonuses(obj, unit):
	if not hasattr(obj, 'get_stat'): return
	if unit.minion_bonuses_applied: return

	unit.max_hp = obj.get_stat('minion_health', base=unit.max_hp)
	for s in unit.spells:
		if hasattr(s, 'damage'): s.damage = obj.get_stat('minion_damage', base=s.damage)
		if hasattr(s, 'heal'): s.heal = obj.get_stat('minion_damage', base=s.heal)
		if hasattr(s, 'range') and s.range >= 2: s.range = obj.get_stat('minion_range', base=s.range)

	# Make the unit temporary iff the obj has minion duration bonus or it is already temporary.  Give it all applicable bonuses if it does.
	if hasattr(obj, 'minion_duration'): unit.turns_to_death = obj.get_stat('minion_duration')
	elif unit.turns_to_death: unit.turns_to_death = obj.get_stat('minion_duration', unit.turns_to_death)

	unit.minion_bonuses_applied = True

# Return a unit with its minion bonuses
def make_minion(source, spawner):
	unit = spawner()
	apply_minion_bonuses(source, unit)
	return unit

class Bolt():
	# A sequencing tool for projectiles and projectile like phenomena
	def __init__(self, level, start, end, two_pass=True, find_clear=True):
		self.start = start
		self.end = end
		self.level = level
		self.two_pass = two_pass
		self.find_clear = find_clear

	def __iter__(self):
		path = self.level.get_points_in_line(self.start, self.end, two_pass=self.two_pass, find_clear=self.find_clear)
		if not path: path = self.level.get_points_in_line(self.start, self.end, two_pass=self.two_pass, find_clear=False)
		path = path[1:] # Skip first point
		for point in path:
			if self.find_clear and not self.level.tiles[point.x][point.y].can_see: break # give all the points up until you hit a wall if you can't punch through walls
			yield point

BurstConeParams = namedtuple("BurstConeParams", "target angle")
class Burst():
	# A sequencing tool for explosions and explosion like phenomena
	def __init__(self, level, origin, radius, burst_cone_params=None, expand_diagonals=False, ignore_walls=False):
		self.level = level
		self.origin = origin
		self.radius = radius
		self.burst_cone_params = burst_cone_params

		# Auto expand diagonals in cones, they dont work otherwise.
		self.expand_diagonals = expand_diagonals if not burst_cone_params else True
		self.ignore_walls = ignore_walls


	def is_in_burst(self, p):

		dist = distance(p, self.origin)
		if dist > self.radius:
			return False



		if isinstance(self.origin, Unit):
			# Take minimum of angle with each of the occupied points of the origin monster
			angle = min(get_min_angle(o.x, 
									  o.y, 
									  self.burst_cone_params.target.x, 
									  self.burst_cone_params.target.y, 
									  p.x, 
									  p.y) for o in self.origin.iter_occupied_points())

		else:
			angle = abs(get_min_angle(self.origin.x, 
								  self.origin.y, 
								  self.burst_cone_params.target.x, 
								  self.burst_cone_params.target.y, 
								  p.x, 
								  p.y)) 

		return angle <= self.burst_cone_params.angle

	def __iter__(self):
		if isinstance(self.origin, Unit): last_stage = set(self.origin.iter_occupied_points())
		else: last_stage = {self.origin}
		already_exploded = set(last_stage)
		if not self.burst_cone_params: yield last_stage

		step_limit = int(math.ceil(self.radius))
		for _ in range(step_limit):
			next_stage = set()
			for point in last_stage: next_stage.update(self.level.get_points_in_ball(point.x, point.y, 1.5, diag=True))
			next_stage.difference_update(already_exploded)
			next_stage = {p for p in next_stage if distance(p, self.origin) <= self.radius}
			if not self.ignore_walls: next_stage = {p for p in next_stage if self.level.tiles[p.x][p.y].can_see}
			if self.burst_cone_params is not None: next_stage = {p for p in next_stage if self.is_in_burst(p)}
			if not next_stage: break
			already_exploded.update(next_stage)
			yield next_stage
			last_stage = next_stage

def tween(start, end, t):
	return (1 - t) * start + t * end

class Color:
	def __init__(self, r=255, g=255, b=255):
		self.r = int(r)
		self.g = int(g)
		self.b = int(b)

	def __hash__(self):
		return hash((self.r, self.b, self.g))

	def __eq__(self, other):
		if not isinstance(other, Color): return False
		return self.r == other.r and self.g == other.g and self.b == other.b

	def __str__(self):
		return "<Color %d %d %d>" % (self.r, self.g, self.b)

	def to_tup(self):
		return (self.r, self.g, self.b)

def random_color(min=0, max=255):
	return Color(random.randint(min, max), random.randint(min, max), random.randint(min, max))

def tween_color(start, end, t):
	return Color(
			tween(start.r, end.r, t),
			tween(start.g, end.g, t),
			tween(start.b, end.b, t)
		)
COLOR_BLACK = Color(0, 0, 0)
COLOR_ARTIFACT = Color(252, 186, 3)
COLOR_CONSUMABLE = Color(31, 255, 75)
COLOR_MANA = Color(125, 125, 255)
COLOR_OMEGA = Color(255, 217, 102)

COLOR_DAMAGE = Color(215, 0, 0)
COLOR_CHARGES = Color(255, 128, 0)
COLOR_RANGE = Color(180, 100, 255)

COLOR_SHIELD = Color(77, 253, 252)

class Effect(object):
	def __init__(self, x, y, start_color, end_color, frames):
		self.x = x
		self.y = y
		self.start_color = start_color
		self.end_color = end_color
		self.color = start_color
		self.frames = frames
		self.frames_left = frames
		self.minor = False
		self.speed = 1.5

	def advance(self):
		t = (self.frames - self.frames_left) / float(self.frames)
		self.color = tween_color(self.start_color, self.end_color, t)
		self.frames_left = self.frames_left - 1

	def __reduce__(self):
		assert(False)


class Cloud():
	def __init__(self):
		self.is_player_controlled = False
		self.is_alive = True
		self.asset = None
		self.stats = list(stat_names)
		self.stats.append('strikechance')
		pass

	def advance(self):
		self.duration -= 1
		self.on_advance()
		if self.duration <= 0 and self.is_alive:
			self.kill()
		return True

	def kill(self):
		assert(self.is_alive)
		self.on_expire()
		self.level.remove_obj(self)
		self.is_alive = False

	def fmt_dict(self):
		d = {}
		for stat in self.stats:
			v = getattr(self, stat, None)
			if v is not None: d[stat] = v
		return d

	def can_be_replaced_by(self, new_cloud):
		return True

	def on_advance(self):
		pass

	def on_expire(self):
		pass

	def on_unit_enter(self, unit):
		pass

	def on_damage(self, dtype):
		pass

stat_names = [
			'range',
			'max_charges',
			'damage', 
			'radius',
			'duration',
			'minion_duration',
			'minion_damage',
			'minion_health',
			'minion_range',
			'heal',
			'num_targets',
			'shields',
			'max_channel',
			'num_summons',
			'hp_cost'
		]

class Spell(object):

	def __init__(self):
		# By default any of these attributes can be modified by shrines buffs ect.
		# Spells can delete or add values from this list in on_init.
		self.stats = list(stat_names)

		self.spell_upgrades = []
		self.upgrade_tooltip_specs = []

		self.name = "Unnamed spell"
		self.cool_down = 0
		self.hp_cost = 0
		self.requires_los = True
		self.tags = []
		self.damage_type = []
		self.damage_type_random = False
		self.added_by_buff = False

		self.asset = None
		self.flash_color = None

		self.prereqs = []
		self.level = 0
		self.description = ""
		self.caster = None
		self.owner = None
		self.statholder = None
		self.stat_modifiers_cache = {}
		self.stat_modifiers_owner = None
		self.stat_modifiers_version = -1

		self.melee = False

		self.show_tt = True
		self.tt_color = None
		self.extra_unit_tt_fns = []
		self.quick_cast = False

		self.cast_on_walls = False

		self.range = 5
		self.max_charges = 0
		self.can_target_self = False
		self.can_target_empty = True
		self.must_target_walkable = False
		self.must_target_empty = False

		# AI targest allies instead of enemies if true
		self.target_allies = False

		# AI targets random valid empty targets
		self.target_empty = False

		self.animate = True

		# attr, amount, max stacks, rarity
		self.upgrades = OrderedDict()
		self.on_init() # This must happen last or else defaults will be overwritten

		if self.range == 0: self.can_target_self = True

		# Record what stats actually exist on this spell
		self.stats = [s for s in self.stats if hasattr(self, s)]

		self.self_target = (self.range == 0)

		for attrs, val in reversed(self.upgrades.items()):
			name = None
			desc = None
			added_tags = []
			damage_type = []
			base_override = None
			if not isinstance(attrs, tuple): attrs = (attrs,)
			for attr in attrs:
				if attr not in self.stats:
					self.stats.append(attr) # append it here so it can be flipped on/off easily when purchasing/formatting the upgrade
			
			# Create the upgrade
			if isinstance(val, tuple):
				if not isinstance(val[0], list): amts = [val[0]]
				else: amts = val[0]
				level = val[1]
				if len(val) > 2: name = val[2]
				if len(val) > 3: desc = val[3]
				if len(val) > 4: added_tags = val[4] or []
				if len(val) > 5: damage_type = val[5]
				if len(val) > 6: base_override = val[6]
			else: amts = [val]; level = 1
			self.spell_upgrades.insert(0, SpellUpgrade(spell=self, attributes=attrs, amounts=amts, level=level, name=name, desc=desc, added_tags=added_tags, damage_type=damage_type, base_override=base_override))
		self.sort_spell_upgrades()
		self.cache_upgrade_tooltips()
		self.cur_charges = self.get_stat('max_charges')

	# For very complex upgrades
	def add_upgrade(self, upgrade):
		assert(isinstance(upgrade, Upgrade))
		upgrade.prereq = self
		if not upgrade.tags: upgrade.tags = list(self.tags)
		self.spell_upgrades.append(upgrade)
		self.sort_spell_upgrades()

	def sort_spell_upgrades(self):
		self.spell_upgrades.sort(key=lambda upg: (upg.level, upg.name.casefold())) # level first, then alphabetically

	def add_upgrade_tooltip(self, upgrade_name, *tooltip_fns):
		self.upgrade_tooltip_specs.append((upgrade_name, tooltip_fns))

	def cache_upgrade_tooltips(self):
		upgrade_name_counts = {}
		for upg in self.spell_upgrades:
			upgrade_name_counts[upg.name] = upgrade_name_counts.get(upg.name, 0) + 1

		tooltip_map = {}
		for upgrade_name, tooltip_fns in self.upgrade_tooltip_specs:
			assert(upgrade_name_counts.get(upgrade_name, 0) == 1), f"{upgrade_name} already exists"
			if upgrade_name not in tooltip_map:
				tooltip_map[upgrade_name] = []
			tooltip_map[upgrade_name].extend(tooltip_fns)

		for upg in self.spell_upgrades:
			upg.extra_examine_tooltip_fns = list(tooltip_map.pop(upg.name, []))

		assert(not tooltip_map)

	def get_upgrade_tooltips(self):
		tooltips = []
		for upg in self.spell_upgrades:
			tooltips.append(upg)
			tooltips.extend(upg.get_extra_examine_tooltips())
		return tooltips

	def sync_upgrade_tags(self):
		for upg in self.spell_upgrades:
			if not isinstance(upg, Upgrade): continue
			tags = list(self.tags) + list(getattr(upg, 'added_tags', []))
			seen = set()
			upg.tags = [t for t in tags if not (t in seen or seen.add(t))]

	def modify_test_level(self, level):
		pass

	# Override with objects that will appear in the tooltip when the mouse wheel is scrolled (Summons, buffs)
	def get_extra_examine_tooltips(self):
		return self.get_upgrade_tooltips()

	def get_unit_extra_examine_tooltips(self):
		extras = []
		for fn, use in self.extra_unit_tt_fns:
			extras.append(self.make_unit_tooltip(fn, use_source_bonuses=use))
		return extras

	def add_unit_tooltip(self, unit_constructor, use_source_bonuses=True):
		self.extra_unit_tt_fns.append((unit_constructor, use_source_bonuses))

	def make_unit_tooltip(self, unit_constructor, use_source_bonuses=True):
		u = unit_constructor()
		if use_source_bonuses:
			src = getattr(getattr(self, 'caster', None), 'source', None)
			if src: u.source = src; apply_minion_bonuses(src, u)
		return u

	def fmt_dict(self):
		return {s: self.get_stat(s) for s in self.stats}

	def iter_stats(self):
		for stat in self.stats:
			yield (stat, getattr(self, stat, 0), self.get_stat(stat))

	def get_color(self):
		return self.tags[0].color if self.tags else Color(255, 255, 255)

	def get_stat(self, attr, base=None):
		if self.statholder and self.statholder is not self.caster:
			master_spell = self.statholder.get_or_make_spell(type(self))
			if base is None: base = getattr(master_spell, attr, 0)
			return self.statholder.get_stat(base, master_spell, attr)
		statholder = self.statholder or self.caster
		if base is None: base = getattr(self, attr, 0)
		if not statholder or not statholder.buffs and not getattr(statholder, 'is_player_controlled', False): return base
		return statholder.get_stat(base, self, attr)

	def is_manual_cast(self):
		level = None
		if self.caster and self.caster.level: level = self.caster.level
		elif self.owner and self.owner.level: level = self.owner.level
		if not level: return False
		ctx = getattr(level, "current_cast_context", None)
		if not ctx or ctx.spell != self: return False
		return ctx.pay_costs

	def on_init(self):
		pass

	# Returns a list of tiles that can be targeted
	def get_targetable_tiles(self):

		if self.get_stat('range') == RANGE_GLOBAL:
			return [Point(t.x, t.y) for t in self.caster.level.iter_tiles() if self.can_cast(t.x, t.y)]

		candidates = self.caster.level.get_points_in_ball(self.caster.x, self.caster.y, self.get_stat('range'))
		if self.melee:
			candidates = self.caster.level.get_points_in_ball(self.caster.x, self.caster.y, 1.5, diag=True)

		return [p for p in candidates if self.can_cast(p.x, p.y)]

	# Returns a list of points that will be impacted if the spell is cast here
	def get_impacted_tiles(self, x, y):
		
		# If there is a radius, default to using it
		if hasattr(self, 'radius'): radius = self.get_stat('radius')
		else: radius = 0
		if radius: return self.caster.level.get_points_in_ball(x, y, radius)
		else: return [Point(x, y)]

	def cast(self, x, y):
		yield self.cast_instant(x, y)

	# Can override this instead of cast if you want to not put yield at the end
	def cast_instant(self, x, y):
		# Assert on unimplemented spells
		assert(False)

	# Return true if we shuold shade the tile red when alt is held
	def can_threaten(self, x, y):
		# By default do corner threat if have radius else just test if can cast
		if hasattr(self, 'radius') and not self.get_stat('radius')==0:
			return self.can_threaten_corner(x, y, self.get_stat('radius'))
		return self.can_cast(x, y)

	def can_threaten_corner(self, x, y, radius):
		if distance(Point(x, y), self.caster) > radius + self.range: return False
		if self.can_cast(x, y): return True
		nearby_points = self.caster.level.get_points_in_ball(x, y, radius)
		for p in nearby_points:
			if self.can_cast(p.x, p.y) and Point(x, y) in self.get_impacted_tiles(p.x, p.y): return True
		return False

	
	# By default, target a random targetable enemy unit
	def get_ai_target(self, check_harm=False):
		caster = self.caster
		caster_x = caster.x
		caster_y = caster.y
		caster_radius = caster.radius
		lvl = caster.level

		if self.self_target: return caster if self.can_cast(caster_x, caster_y) else None

		r = self.get_stat('range')
		if self.target_empty:
			candidates = list(lvl.get_points_in_ball(caster_x, caster_y, r)) # grab points in range
			lvl.random.shuffle(candidates) # shuffle em up
			return next((p for p in candidates if self.can_cast(p.x, p.y)), None) # call can_cast as few times as we need to

		scan_range = 1 + caster_radius if self.melee else r
		range_width = 2 * scan_range + 1
		use_tile_scan = range_width * range_width * 2 < len(lvl.units) # look at tiles if there are significantly fewer tiles that need to be checked than units

		check_harm = check_harm or bool(self.damage_type)
		good_units = []

		if use_tile_scan:
			seen = set()
			tiles = lvl.tiles
			width = lvl.width
			height = lvl.height

			for dx, dy, _ in get_points_in_ball_offsets(scan_range, self.melee):
				# faster point checking, dont use shortcuts on the hotpath since it creates a bunch of new Point objects we dont need
				x = caster_x + dx
				if x < 0 or x >= width: continue
				y = caster_y + dy
				if y < 0  or y >= height: continue

				u = tiles[x][y].unit
				if not u: continue
				if u.radius: # dont add multi-tile units to the good_units list more than once, other units can't show up twice anyway
					if u in seen: continue
					seen.add(u)
				if are_hostile(u, caster) == self.target_allies: continue
				if check_harm and not self.can_harm(u): continue
				good_units.append(u)
		else:
			for u in lvl.units: # look at units in the level rather than every tile if the range is large or the level has few units
				if abs(u.x - caster_x) > r + u.radius + caster_radius or abs(u.y - caster_y) > r + u.radius + caster_radius: continue # if target is horizontally or vertically further away than the range, skip
				if are_hostile(u, caster) == self.target_allies: continue # if the unit is hostile and the spell should target allies, or vice versa, skip
				if check_harm and not self.can_harm(u): continue  # if we can't hurt it, skip
				good_units.append(u)

		lvl.random.shuffle(good_units)
		for u in good_units:
			pts = list(u.iter_occupied_points()) if u.radius else [Point(u.x, u.y)]
			lvl.random.shuffle(pts)
			candidate = next((p for p in pts if self.can_cast(p.x, p.y)), None)
			if candidate: return candidate

		return None

	def get_corner_target(self, radius, requires_los=True, unit_filter=None):
		# Find targets possibly around corners
		# Returns the first randomly found target which will hit at least one enemy with a splash of the given radius
		caster = self.caster
		lvl = caster.level
		r = self.get_stat('range')

		if unit_filter is None: # default to trying to hurt enemies
			def unit_filter(u): return lvl.are_hostile(u, caster) and self.can_harm(u)

		target_units = [u for u in lvl.get_units_in_ball(caster, r + radius) if unit_filter(u)] # gather harmable enemies in est range
		if not target_units:  return None

		# heuristic to decide whether to look at all cast pts or look at the list of enemies
		num_targets = len(target_units)
		num_splash_tiles = 1 + (2 * radius * (radius + 1))
		num_total_tiles = min((1 + (2 * r * (r + 1))), lvl.height * lvl.width)

		if num_targets * num_splash_tiles < num_total_tiles: # if the number tiles checked would be smaller to look at enemies, then do that

			lvl.random.shuffle(target_units)
			for u in target_units:
				unit_pts = list(u.iter_occupied_points()) if u.radius else [Point(u.x, u.y)] # look at all the enemy points
				for p in unit_pts:
					possible_cast_pts = list(lvl.get_points_in_ball(p.x, p.y, radius)) # grab all the locations that could splash to a point occupied by the enemy
					lvl.random.shuffle(possible_cast_pts)
					for point in possible_cast_pts: # for each of the possible cast pts, check to see
						if not self.can_cast(point.x, point.y): continue # if you can cast there
						if not requires_los: return point
						impacted = set(self.get_impacted_tiles(point.x, point.y))
						if not any(tile in impacted for tile in unit_pts): continue # if casting there would hit the enemy
						return point

		else: # otherwise check all castable tiles
			cast_pts = [p for p in lvl.get_points_in_ball(caster.x, caster.y, r) if self.can_cast(p.x, p.y)] # look where we can cast
			if not cast_pts: return None
			lvl.random.shuffle(cast_pts)

			for p in cast_pts: # go through the cast points
				nearby = lvl.get_units_in_ball(p, radius) # look through units nearby
				impacted = None
				for u in nearby:
					if not unit_filter(u): continue
					if not requires_los: return p
					unit_pts = list(u.iter_occupied_points()) if u.radius else [Point(u.x, u.y)]
					if impacted is None: impacted = set(self.get_impacted_tiles(p.x, p.y))
					if not any(tile in impacted for tile in unit_pts):  continue # ignore them if casting there wouldn't hit them
					return p # if it doesn't do any of those, cast there

		return None # if no cast points have units near them, return none


	def can_pay_costs(self):
		
		if self.caster.is_stunned(): return False

		# Silence prevents casting of any non melee spells
		if self.caster.is_silenced() and not self.melee: return False

		if self.caster.cool_downs.get(self, 0) > 0: return False

		if self.max_charges:
			if self.cur_charges <= 0:
				return False

		if self.get_stat('hp_cost'):
			if self.get_stat('hp_cost') >= self.caster.cur_hp:
				return False

		return True

	def can_copy(self, x, y):
		old_req_los = self.requires_los
		old_range = self.range

		self.requires_los = False
		self.range = RANGE_GLOBAL

		retval = self.can_cast(x, y)

		self.range = old_range
		self.requires_los = old_req_los

		return retval

	def can_cast(self, x, y):
		caster = self.caster
		lvl = caster.level

		# coord not in the level, early out
		if x < 0 or x >= lvl.width or y < 0 or y >= lvl.height: return False

		# dx/dy once
		dx = abs(caster.x - x)
		dy = abs(caster.y - y)

		# self targeting
		if not self.can_target_self and dx == 0 and dy == 0: return False

		# walkable
		if self.must_target_walkable and not lvl.tiles[x][y].can_walk: return False

		# blind
		if caster.is_blind() and max(dx, dy) > 1 + caster.radius: return False

		#range
		r = self.get_stat('range') + (caster.radius if self.melee else 0)
		if self.melee:
			if max(dx, dy) > 1 + caster.radius: return False
		else:
			if dx > r or dy > r: return False
			if dx*dx + dy*dy > r*r: return False

		# empty v occupied
		if not self.can_target_empty or self.must_target_empty:
			u = lvl.tiles[x][y].unit
			if not self.can_target_empty and not u: return False
			if self.must_target_empty and u: return False

		#los
		if self.get_stat('requires_los'):
			if not lvl.can_see(caster.x, caster.y, x, y, light_walls=self.cast_on_walls):
				return False

		return True

	def pay_costs(self):
		if self.cool_down > 0: self.caster.cool_downs[self] = self.cool_down
		if self.max_charges: self.cur_charges -= 1
		hp_cost = self.get_stat('hp_cost')
		if hp_cost:
			self.caster.cur_hp -= hp_cost
			log_txt = (text.PAY_HP, {"unit": self.caster.name, "cost": hp_cost, "spell": self.name})
			self.caster.level.log(log_txt)
			self.caster.level.event_manager.raise_event(EventOnSpendHP(self.caster, hp_cost), self.caster)
			self.caster.level.show_effect(self.caster.x, self.caster.y, Tags.Blood, minor = hp_cost < 11)

	def get_description(self):
		return self.description

	def summon(self, unit, target=None, radius=5, team=None, sort_dist=True):
		if not unit.source: unit.source = self
		if not target: target = Point(self.caster.x, self.caster.y)
		return self.caster.level.summon(self.caster, unit, target, radius, team, sort_dist)

	def refund_charges(self, charges):
		self.cur_charges += charges
		self.cur_charges = min(self.cur_charges, self.get_stat('max_charges'))

	def drain_charges(self, charges=1):
		self.cur_charges = max(0, self.cur_charges - charges)
		self.do_ui_flash(tag=Tags.Arcane)

	def do_ui_flash(self, tag=None):
		if tag: self.flash_color = tag.color.to_tup()
		else: self.flash_color = (255, 255, 255)

	def can_harm(self, target_unit):
		if target_unit.cur_hp == 1 and target_unit.soulbound and not target_unit.shields: return False
		damage_type = getattr(self, 'damage_type', None)
		if not damage_type: return True
		damage_type = self.get_stat('damage_type')
		if isinstance(damage_type, list):
			for d in damage_type:
				if target_unit.resists[d] < 100:
					return True
		else:
			if target_unit.resists[damage_type] < 100:
				return True
		return False

	def get_asset(self):
		if self.asset: return self.asset
		return ['UI', 'spell skill icons', self.name.lower().replace(' ', '_')]


MoveAction = namedtuple("MoveAction", "x y")
CastAction = namedtuple("CastAction", "spell x y")
PassAction = namedtuple("PassAction", "")
StunnedAction = namedtuple("StunnedAction", "buff duration")

class AIPathingCache(object):

	def __init__(self):
		self.failures = set()

	def get_failure_key(self, pather, x, y, target):
		return x, y, pather.radius, bool(pather.flying), bool(pather.burrowing), target.x, target.y

	def is_unreachable(self, pather, x, y, target):
		if not self.failures: return False
		return self.get_failure_key(pather, x, y, target) in self.failures

	def add_failure(self, pather, x, y, target):
		self.failures.add(self.get_failure_key(pather, x, y, target))

	def propagate_failures(self, pather, x, y, unreachable_targets):
		for target in unreachable_targets:
			self.failures.add(self.get_failure_key(pather, x, y, target))

	def on_terrain_change(self):
		if self.failures: self.failures.clear()

class Component(object):  # these are consumables

	def __init__(self):
		self.name = "Unnamed Component"
		self.description = "Undescribed Component"
		self.tags = []
		self.asset = None
		self.overlay_asset = None
		self.on_init()
		self.is_rare = False

		if not self.overlay_asset:
			cls = type(self)
			pickup_override = cls.on_pickup is not Component.on_pickup
			craft_override = cls.on_craft is not Component.on_craft
			if pickup_override:
				self.overlay_asset = ['tiles', 'crafting', 'component_on_pickup']

			elif craft_override:
				self.overlay_asset = ['tiles', 'crafting', 'component_on_craft']
				self.is_rare = True

	def on_init(self):
		pass

	def on_pickup(self, player, level):
		pass

	def on_craft(self, player, equipment):
		pass

	def get_asset(self):
		if self.asset: return self.asset
		asset = ['tiles', 'crafting', self.name.lower().replace(' ', '_').replace("'", "")]
		return asset

	def get_unit(self):
		return None

	def get_unit_extra_examine_tooltips(self):
		unit = self.get_unit()
		if not unit: return []
		return [unit]

	def get_extra_examine_tooltips(self, game=None):
		extras = self.get_unit_extra_examine_tooltips()
		if not game: return extras
		if self in game.p1.components: return extras # already in inventory, prospective doesn't make sense
		extras.append(game.get_prospective_equipment([self]))
		return extras

STACK_NONE = 0
STACK_DURATION = 1
STACK_INTENSITY = 2
STACK_REPLACE = 3
STACK_TYPE_TRANSFORM = 4

BUFF_TYPE_PASSIVE = 0
BUFF_TYPE_BLESS = 1
BUFF_TYPE_CURSE = 2
BUFF_TYPE_ITEM = 3
BUFF_TYPE_NONE = -1

STACK_LABELS = {
	STACK_NONE: "Refresh",
	STACK_DURATION: "Duration",
	STACK_INTENSITY: "Intensity",
	STACK_REPLACE: "Replace",
	STACK_TYPE_TRANSFORM: "Duration",
}

BUFF_LABELS = {
	# BUFF_TYPE_PASSIVE: "Spell Upgrade",
	BUFF_TYPE_BLESS: "Buff",
	BUFF_TYPE_CURSE: "Debuff",
	# BUFF_TYPE_ITEM: "Equipment",
}

class Buff(object):

	def __init__(self):
		self.description = None
		self.owner_triggers = {}
		self.global_triggers = {}

		self.turns_left = 0
		self.color = None
		self.asset = None
		self.resists = defaultdict(lambda : 0)

		self.spells = []
		self.stack_type = STACK_NONE

		self.owner = None

		self.applied = False
		self.name = "Unnamed buff"
		self.shrink_text = 0

		# self.spell_bonuses[spell][attr]
		self.spell_bonuses = defaultdict(lambda : defaultdict(lambda: 0))
		self.global_bonuses = defaultdict(lambda: 0)
		self.tag_bonuses = defaultdict(lambda : defaultdict(lambda: 0))

		self.spell_bonuses_pct = defaultdict(lambda : defaultdict(lambda: 0))
		self.global_bonuses_pct = defaultdict(lambda: 0)
		self.tag_bonuses_pct = defaultdict(lambda : defaultdict(lambda: 0))


		self.buff_type = BUFF_TYPE_BLESS
		self.show_effect = True

		self.freeze_animation = False

		self.transform_asset = None
		self.stat_modifiers_cache = {}
		self.stat_modifiers_owner = None
		self.stat_modifiers_version = -1

		self.on_init()

		# Do not allow setting of turns_left in on_init, since usually its an accidental overload of the term
		assert(self.turns_left == 0)

		self.prereq = None

	def can_threaten(self, x, y):
		return False

	def on_init(self):
		pass

	def on_applied(self, owner):
		pass

	def on_unapplied(self):
		pass

	# Rarely... but sometimes needed
	def on_pre_advance(self):
		pass

	def on_advance(self):
		pass

	def get_description(self):
		return self.description

	def get_asset(self):
		return self.asset

	# Override to prevent the owner from advancing- ie for stun, or conditional stun
	def on_attempt_advance(self):
		return True

	# Override to prevent application in some circumstances- ie, not letting stun refresh on the player
	# def on_attempt_apply(self, owner):
	# 	return True

	def advance(self):
		
		self.on_advance()

		# Guard with if self.applied because advance might unapply (by for instance killing the owner)
		if self.applied:
			if self.turns_left > 0:
				self.turns_left -= 1
				if self.turns_left == 0:
					self.owner.remove_buff(self)

	def apply(self, owner):
		assert(not self.applied)
		self.owner = owner

		# record charges first since now some buff's on_applied will add tags and could alter max_charges
		prev_max_charges = {spell: spell.get_stat('max_charges') for spell in self.owner.spells}

		if self.on_applied(owner) == ABORT_BUFF_APPLY: return ABORT_BUFF_APPLY
		self.applied = True
		event_manager = self.owner.level.event_manager
		if self.owner.level: self.subscribe()

		# Accumulate resists
		for dtype, resist in self.resists.items(): self.owner.resists[dtype] += resist

		# Accumulate spell bonuses
		for attr, amt in self.global_bonuses.items(): owner.global_bonuses[attr] += amt

		for attr, amt in self.global_bonuses_pct.items(): owner.global_bonuses_pct[attr] += amt

		for spell_class, bonuses in self.spell_bonuses.items():
			for attr, amt in bonuses.items(): owner.spell_bonuses[spell_class][attr] += amt

		for spell_class, bonuses in self.spell_bonuses_pct.items():
			for attr, amt in bonuses.items(): owner.spell_bonuses_pct[spell_class][attr] += amt

		for tag, bonuses in self.tag_bonuses.items():
			for attr, amt in bonuses.items(): owner.tag_bonuses[tag][attr] += amt

		for tag, bonuses in self.tag_bonuses_pct.items():
			for attr, amt in bonuses.items(): owner.tag_bonuses_pct[tag][attr] += amt

		# Modify spells
		for spell in self.owner.spells: self.modify_spell(spell)

		# Add all new spells from this buff
		if self.spells:
			for spell in self.spells:
				if spell.name not in [s.name for s in self.owner.spells]:
					if isinstance(self, Equipment): self.owner.add_spell(spell)
					elif not owner.is_player_controlled: spell.added_by_buff = True; self.owner.add_spell(spell) # only give temp spells to npcs

		# Modify sprite on transforms
		if self.transform_asset and not self.owner.radius:
			assert(self.stack_type == STACK_TYPE_TRANSFORM)
			old_asset = self.owner.transform_asset
			if self.owner.transform_asset != self.transform_asset: self.owner.clear_anim('Transform_Anim')
			self.owner.prev_transform_asset = old_asset
			self.owner.transform_asset = self.transform_asset

		self.owner.invalidate_spell_stats()

		# Update spells whos max charges have changed
		for spell in self.owner.spells:
			if spell not in prev_max_charges: continue
			charge_diff = spell.get_stat('max_charges') - prev_max_charges[spell]
			spell.cur_charges += charge_diff

	def unapply(self):

		assert(self.applied)
		self.applied = False

		prev_max_charges = {spell: spell.get_stat('max_charges') for spell in self.owner.spells}

		self.on_unapplied()

		# TODO- put passive effect stuff aka resistances here

		for dtype, resist in self.resists.items():
			self.owner.resists[dtype] -= resist

		# Unaccumulate spell bonuses
		for attr, amt in self.global_bonuses.items():
			self.owner.global_bonuses[attr] -= amt

		# Unaccumulate spell bonuses
		for attr, amt in self.global_bonuses_pct.items():
			self.owner.global_bonuses_pct[attr] -= amt

		for spell_class, bonuses in self.spell_bonuses.items():
			for attr, amt in bonuses.items():
				self.owner.spell_bonuses[spell_class][attr] -= amt

		for spell_class, bonuses in self.spell_bonuses_pct.items():
			for attr, amt in bonuses.items():
				self.owner.spell_bonuses_pct[spell_class][attr] -= amt

		for tag, bonuses in self.tag_bonuses.items():
			for attr, amt in bonuses.items():
				self.owner.tag_bonuses[tag][attr] -= amt

		for tag, bonuses in self.tag_bonuses_pct.items():
			for attr, amt in bonuses.items():
				self.owner.tag_bonuses_pct[tag][attr] -= amt


		spells_from_other_buffs = [s.name for b in self.owner.buffs for s in b.spells if b != self]
		for spell in self.owner.spells:
			# Remove all spells granted only by this buff
			if spell.added_by_buff and spell.name not in spells_from_other_buffs: self.owner.remove_spell(spell)
			self.unmodify_spell(spell)

		# Modify sprite on transforms
		if self.transform_asset and not self.owner.radius:
			old_asset = self.owner.transform_asset
			next_transform = next((b for b in reversed(self.owner.buffs) if b.stack_type == STACK_TYPE_TRANSFORM and b.transform_asset), None)
			if next_transform:
				if self.owner.transform_asset != next_transform.transform_asset: self.owner.clear_anim('Transform_Anim')
				self.owner.transform_asset = next_transform.transform_asset
			else:
				self.owner.transform_asset = None
				self.owner.clear_anim('Transform_Anim')
			self.owner.prev_transform_asset = old_asset

		self.unsubscribe()
		self.owner.invalidate_spell_stats()

		# Update spells whos max charges have changed
		for spell in self.owner.spells:
			if spell not in prev_max_charges:
				continue

			charge_diff = spell.get_stat('max_charges') - prev_max_charges[spell]
			spell.cur_charges += charge_diff

	def on_add_spell(self, spell):
		self.modify_spell(spell)
		spell.do_ui_flash()

	def on_remove_spell(self, spell):
		self.unmodify_spell(spell)

	def subscribe(self):
		event_manager = self.owner.level.event_manager

		for event_type, trigger in self.owner_triggers.items():
			event_manager.register_entity_trigger(event_type, self.owner, trigger)
		for event_type, trigger in self.global_triggers.items():
			event_manager.register_global_trigger(event_type, trigger)

	def unsubscribe(self):
		event_manager = self.owner.level.event_manager

		for event_type, trigger in self.owner_triggers.items():
			try: event_manager.unregister_entity_trigger(event_type, self.owner, trigger)
			except ValueError: pass  # trigger already gone; nothing else to do

		for event_type, trigger in self.global_triggers.items():
			try: event_manager.unregister_global_trigger(event_type, trigger)
			except ValueError: pass

	# Called on each spell the owner has once
	def modify_spell(self, spell):
		pass

	def unmodify_spell(self, spell):
		pass

	# For examine
	def get_tooltip(self):
		return self.get_description()

	def get_tooltip_color(self):
		return self.color if self.color else Color(255, 255, 255)

	def get_stacking_label(self):
		if self.buff_type not in [BUFF_TYPE_BLESS, BUFF_TYPE_CURSE]: return None
		return STACK_LABELS.get(self.stack_type)

	def get_buff_type_label(self):
		return BUFF_LABELS.get(self.buff_type, None)

	def fmt_dict(self):
		return {} # to be overwritten

	def get_extra_examine_tooltips(self):
		return []

	def get_unit_extra_examine_tooltips(self):
		return []

	def summon(self, unit, target=None, radius=5, team=None, sort_dist=True):
		if unit.source is None: unit.source = self
		if not target: target = Point(self.owner.x, self.owner.y)
		return self.owner.level.summon(self.owner, unit, target, radius, team, sort_dist)



class Upgrade(Buff):

	def __init__(self, *args, **kwargs):
		self._init_args = args
		self._init_kwargs = kwargs
		Buff.__init__(self)
		self.level = 0
		self.tags = []
		self.added_tags = []
		self.new_attributes = {}
		self.description = ""
		self.prereq = None
		self.extra_examine_tooltip_fns = []
		self.on_init()
		self.keystone = False
		self.stack_type = STACK_INTENSITY
		self.max_stacks = 1
		self.buff_type = BUFF_TYPE_PASSIVE

	def get_extra_examine_tooltips(self):
		extras = []
		for tooltip_fn in self.extra_examine_tooltip_fns:
			tooltip = tooltip_fn()
			if tooltip is not None: extras.append(tooltip)
		return extras

	def clone_for_spell(self, master_spell, minion_spell):
		try:
			clone = type(self)(*self._init_args, **self._init_kwargs)
		except TypeError:
			return None

		if hasattr(clone, 'spell') and clone.spell == master_spell:
			clone.spell = minion_spell

		return clone

	def on_applied(self, owner): # for handling upgrades that add tags/attributes to their prerequisite spell
		if self.added_tags and isinstance(self.prereq, Spell):
			for tag in self.added_tags:
				self.spell_tag_update(type(self.prereq), tag, add=True)
		if self.new_attributes and self.prereq:
			spell = self.prereq
			for attribute, amount in self.new_attributes.items():
				setattr(spell, attribute, amount)
			owner.invalidate_spell_stats()

	def on_unapplied(self):
		if self.added_tags and isinstance(self.prereq, Spell):
			for tag in self.added_tags:
				self.spell_tag_update(type(self.prereq), tag, add=False)
		if self.new_attributes and self.prereq:
			spell = self.prereq
			for attribute in self.new_attributes:
				delattr(spell, attribute)
			self.owner.invalidate_spell_stats()

	def fmt_dict(self):
		d = {}
		for stat in stat_names:
			if hasattr(self, stat):
				d[stat] = self.get_stat(stat)
		return d

	def get_stat(self, attr, base=None):
		if base is None:
			base = getattr(self, attr, 0)
		if self.owner:
			return self.owner.get_stat(base, self, attr)
		else:
			return base

	def spell_tag_update(self, spell, tag, add=True):
		s = self.owner.get_spell(spell)
		if not s: return
		changed = False
		if add:
			if tag not in s.tags:
				s.tags.append(tag)
				changed = True
		else:
			if tag in s.tags:
				s.tags.remove(tag)
				changed = True
		s.sync_upgrade_tags()
		if changed: self.owner.invalidate_spell_stats()

	def spell_damage_type_update(self, spell, tag, add=True):
		s = self.owner.get_spell(spell)
		if not s: return
		changed = False
		if add:
			if tag not in s.damage_type:
				s.damage_type.append(tag)
				changed = True
		else:
			if tag in s.damage_type:
				s.damage_type.remove(tag)
				changed = True
		if changed: self.owner.invalidate_spell_stats()

	def get_asset(self):
		if self.asset: return self.asset
		return ['UI', 'spell skill icons', self.name.lower().replace(' ', '_')]

SLOT_TRINKET = 0
SLOT_HELMET = 1
SLOT_ARMOR = 2
SLOT_BOOTS = 3
SLOT_WEAPON = 4

SLOT_NAMES = [
	"trinket",
	"headwear",
	"armor",
	"footwear",
	"weapon"
]

class Equipment(Buff):

	def __init__(self, *args, **kwargs):

		# stored for clone use
		self._init_args = args
		self._init_kwargs = kwargs

		self.level = 0
		self.asset_name = None

		self.tags = []
		self.recipe = []
		self.crafting_input_fns = defaultdict(int)
		self.unique = True
		self.slot = SLOT_TRINKET

		Buff.__init__(self)
		
		self.buff_type = BUFF_TYPE_ITEM
		self.stack_type = STACK_INTENSITY  # Allow multiples of same item to stack
		self.set_stats()

		self.flash_color = None


	def set_stats(self):
		# call to refresh after constructors assign stat attributes outside the on_init
		self.stats = [s for s in stat_names if hasattr(self, s)]

	def __str__(self):
		return "Equipment: %s" % self.name

	def add_effect_tooltip(self, tooltip_fn):
		add_tooltip_fn(self, tooltip_fn)

	def add_spell_tooltip(self, spell_class):
		add_tooltip_fn(self, lambda: self.owner.get_or_make_spell(spell_class) if self.owner else spell_class())

	def get_asset(self):
		if self.asset: return self.asset
		asset = ['tiles', 'items', 'equipment', self.name.lower().replace(' ', '_').replace("'", '') if not self.asset_name else self.asset_name]
		return asset

	def get_extra_examine_tooltips(self):
		return []

	def get_stat(self, attr, base=None):
		if base is None: base = getattr(self, attr, 0)
		if self.owner: return self.owner.get_stat(base, self, attr)
		else: return base

	def fmt_dict(self):
		d = {}
		for stat in stat_names:
			if hasattr(self, stat):
				d[stat] = self.get_stat(stat)
		return d

	def on_pre_craft(self, player):
		pass

	def on_equip(self, unit):
		pass

	def on_unequip(self, unit):
		pass

	def clone(self):
		if self._init_args or self._init_kwargs: i = type(self)(*self._init_args, **self._init_kwargs)
		else: i = type(self)()
		i.tags = list(self.tags) # for tag grafting
		i.crafting_input_fns = self.crafting_input_fns.copy()
		return i

	def get_slot_name(self):
		return SLOT_NAMES[self.slot]

	def do_ui_flash(self, tag=None):
		if tag: self.flash_color = tag.color.to_tup()
		else: self.flash_color = (255, 255, 255)

class EquipmentList(object):

	def __init__(self, equipment):
		self.equipments = equipment

ABORT_CHANNEL = 99
class ChannelBuff(Buff):

	def __init__(self, spell, target, cast_after_channel=False, channel_check=None, on_stop=None, on_failure=None, on_ritual_completed=None):
		Buff.__init__(self)
		self.spell = spell
		self.origin_spell = getattr(spell, "__self__", None)
		self.spell_name = getattr(self.origin_spell, "name", None)
		self.name = "Channeling"
		self.spell_target = target
		self.turns = 0
		self.channel_turns = 0
		self.passed = True
		self.owner_triggers[EventOnPass] = self.on_pass
		self.owner_triggers[EventOnSpellCast] = self.on_cast
		self.stack_type = STACK_REPLACE

		self.buff_type = BUFF_TYPE_BLESS

		self.cast_after_channel = cast_after_channel
		self.channel_check = channel_check

		self.on_stop=on_stop
		self.on_failure = on_failure
		self.on_ritual_completed = on_ritual_completed

		self.asset = ['status', 'channeling']

	def get_description(self):
		return ("Channeling {spell}\nPass the turn to continue channeling\nManually casting a spell will end this channel", {"spell": self.spell_name})

	def on_applied(self, owner):
		self.channel_turns = 0
		self.max_channel = self.turns_left
		owner.channeling += 1

		buffs = [b for b in owner.buffs if isinstance(b, ChannelBuff)]
		for b in buffs:
			if b.spell != self.spell:
				owner.remove_buff(b)

	def on_unapplied(self):
		self.owner.channeling -= 1
		completed = self.max_channel > 0 and self.turns_left == 0
		if completed:
			if Tags.Ritual in self.origin_spell.tags: self.owner.level.event_manager.raise_event(EventOnRitualComplete(self.origin_spell, self.owner, self), self.owner)
			if self.on_ritual_completed: self.on_ritual_completed()
		if self.on_stop: self.on_stop()
		if self.on_failure and self.turns_left > 0: self.on_failure()

	def on_advance(self):
		self.channel_turns += 1
		if not self.passed: self.owner.remove_buff(self); return

		cast = False
		if not self.cast_after_channel:
			cast = True
			self.owner.level.queue_spell(self.spell(self.spell_target.x, self.spell_target.y, channel_cast=True))

		if self.cast_after_channel and self.channel_turns == self.max_channel:
			cast = True
			self.owner.level.queue_spell(self.spell(self.spell_target.x, self.spell_target.y, channel_cast=True))

		if cast and self.owner.is_player_controlled:
			self.owner.level.show_effect(0, 0, Tags.Sound_Effect, 'sorcery')

		self.passed = False

	def on_pass(self, evt):
		self.passed = True

	def on_cast(self, evt):
		if evt.pay_costs: self.owner.remove_buff(self)

class SpellUpgrade(Upgrade):

	def __init__(self, spell, attributes, amounts, level=1, added_tags=None, name=None, desc=None, damage_type=None, base_override=None):
		Upgrade.__init__(self)
		self.spell = type(spell)

		for attribute, amount in zip(attributes, amounts):
			if getattr(spell, attribute, 0) != 0: # if the upgrade is modifying an existing non-zero attribute, just have it act as a bonus
				self.spell_bonuses[type(spell)][attribute] = amount
			else: # if the upgrade is introducing a new attribute, we'll have it act as the base, so we store the value for application
				self.new_attributes[attribute] = amount
			setattr(self, attribute, amount) # sets the attribute in the upgrade, so we can use fmt_dict easily

		self.name = name if name else format_attr(attributes[0])
		if added_tags is None: added_tags = []
		self.added_tags = list(added_tags)
		self.tags = list(spell.tags) + list(added_tags)
		self.description = desc
		self.prereq = spell
		self.level = level
		self.damage_type = damage_type if damage_type else []
		self.base_override = base_override or {}
		for attr, val in self.base_override.items(): setattr(self, attr, val)

	def get_description(self):
		lines = []
		if self.description: lines.append((self.description, self.fmt_dict()))
		for t in self.added_tags: lines.append((text.TAG_ADD, {"tag_label": tag_label(t), "tag_key": tag_key(t)}))
		return lines

	def on_applied(self, owner): # when you get the spell upgrade
		spell = owner.get_spell(self.spell) # grab the spell
		self.applied_spell = spell
		for attribute, amount in self.new_attributes.items():
			if hasattr(spell, attribute):
				prev_amt = getattr(spell, attribute)
				amount += prev_amt
			setattr(spell, attribute, amount)
		if self.new_attributes:
			owner.invalidate_spell_stats()
		if self.added_tags:
			for tag in self.added_tags: self.spell_tag_update(type(spell), tag, add=True)
		if self.damage_type: # if the upgrade adds a damage type(s)
			for dtype in self.damage_type: self.spell_damage_type_update(type(spell), dtype, add=True)

	def on_unapplied(self):
		spell = self.applied_spell
		if self.added_tags:
			for tag in self.added_tags: self.spell_tag_update(type(spell), tag, add=False)
		if self.damage_type:
			for dtype in self.damage_type: self.spell_damage_type_update(type(spell), dtype, add=False)
		if self.new_attributes:
			base_spell = self.spell()
			for attribute, amount in self.new_attributes.items():
				remaining = getattr(spell, attribute) - amount
				if hasattr(base_spell, attribute) or remaining:
					setattr(spell, attribute, remaining)
				else:
					delattr(spell, attribute)

		if self.new_attributes:
			self.owner.invalidate_spell_stats()

class BlindBuff(Buff):

	def on_init(self):
		self.name = "Blind"
		self.stack_type	= STACK_REPLACE
		self.buff_type = BUFF_TYPE_CURSE
		self.asset = ['status', 'blind']
		self.description = "All spells reduced to melee range"

class NecrosisBuff(Buff):

	def __init__(self):
		Buff.__init__(self)
		self.name = "Necrosis"
		self.buff_type = BUFF_TYPE_CURSE
		self.stack_type = STACK_INTENSITY
		self.color = Tags.Dark.color
		self.asset = ['status', 'necrosis']
		self.description = "Each turn, lose 1 max HP"

	def on_applied(self, owner):
		if owner.resists[Tags.Dark] >= 100: return ABORT_BUFF_APPLY

	def on_advance(self):
		owner = self.owner
		if owner.resists[Tags.Dark] >= 100: owner.remove_buff(self); return
		owner.max_hp = max(owner.max_hp - 1, 1)
		owner.cur_hp = min(owner.max_hp, owner.cur_hp)

class BerserkBuff(Buff):

	def __init__(self):
		Buff.__init__(self)
		self.name = "Berserk"
		self.buff_type = BUFF_TYPE_CURSE
		self.stack_type	= STACK_NONE
		self.asset = ['status', 'berserk']
		self.color = Color(255, 0, 0)
		self.description = "Will attack and be attacked by both allies and enemies"

class Stun(Buff):

	def on_init(self):
		self.buff_type = BUFF_TYPE_CURSE
		self.stack_type	= STACK_NONE
		self.name = "Stunned"
		self.color = Color(220, 220, 220)
		self.asset = ['status', 'stun']
		self.description = "Cannot act"
		self.freeze_animation = True

	def on_attempt_advance(self):
		return False

	def on_attempt_apply(self, owner):
		if owner.gets_clarity and owner.has_buff(Stun): return False
		return True

	def on_unapplied(self):
		if self.owner.gets_clarity: self.owner.apply_buff(StunImmune(), 1)

	def on_applied(self, owner):
		if owner.has_buff(StunImmune): return ABORT_BUFF_APPLY

class Silence(Buff):

	def on_init(self):
		self.buff_type = BUFF_TYPE_CURSE
		self.stack_type = STACK_NONE
		self.name = "Silenced"
		self.asset = ['status', 'silence']
		self.description = "Cannot cast spells"
		self.color = Tags.Arcane.color

	def on_attempt_apply(self, owner):
		if owner.gets_clarity and owner.has_buff(Stun): return False
		return True

	def on_unapplied(self):
		if self.owner.gets_clarity: self.owner.apply_buff(StunImmune(), 1)

	def on_applied(self, owner):
		if owner.has_buff(StunImmune): return ABORT_BUFF_APPLY

# Its stun but you do a coward move each turn
class FearBuff(Stun):

	def __init__(self):
		Stun.__init__(self)
		self.name = "Feared"
		self.color = Tags.Dark.color
		self.asset = ['status', 'fear']
		self.freeze_animation = False
		self.description = "Cannot cast spells\nWill flee from enemies"

	def on_advance(self):

		# Dont move if you are also stunned frozen slept ect
		other_stuns = [b for b in self.owner.buffs if isinstance(b, Stun) and b != self]
		if other_stuns: return

		# Flee one square
		p = self.owner.get_flee_target()
		if p is not None and not self.owner.stationary:
			self.owner.level.act_move(self.owner, p.x, p.y, force_swap=True)

class StunImmune(Buff):

	def on_init(self):
		self.buff_type = BUFF_TYPE_BLESS
		self.stack_type = STACK_NONE
		self.name = "Clarity"
		self.asset = ['status', 'clarity']

	def get_tooltip(self):
		return "Cannot be [stunned], [frozen], [feared], [petrified], [silenced], or put to [sleep]"

	def on_applied(self, owner):
		for b in owner.buffs:
			if isinstance(b, Stun) or isinstance(b, Silence):
				owner.remove_buff(b)

class Soulbound(Buff):

	def __init__(self, guardian):
		Buff.__init__(self)
		self.name = "Soulbound"
		self.asset = ['status', 'soulbound']
		self.color = Tags.Dark.color
		self.description = "Cannot die until its guardian is killed"

		self.owner_triggers[EventOnPreDamaged] = self.on_self_damage_pre
		self.global_triggers[EventOnDeath] = self.on_death
		self.connected_unit = guardian

	def get_description(self):
		if self.owner: return ("Cannot die until {guardian} is killed", {'guardian':self.connected_unit.name})
		else: return self.description

	def on_applied(self, owner):
		self.owner.soulbound = True # for can_harm purposes when running get_ai_target
		self.owner.set_damage_floor(self, 1)

	def on_unapplied(self):
		self.owner.soulbound = False
		self.owner.remove_damage_floor(self)

	def on_advance(self):
		if not self.connected_unit.is_alive(): self.owner.remove_buff(self)

	def on_self_damage_pre(self, evt):
		# Do not protect if guardian is gone. This can happen if the guardian is corrupted away or silently removed
		if not self.connected_unit.is_alive(): self.owner.remove_buff(self)

	def on_death(self, evt):
		if evt.unit == self.connected_unit: self.owner.remove_buff(self)

class UnlockAchievementOnDeathBuff(Buff):

	def __init__(self, achievement_name):
		Buff.__init__(self)
		self.name = ""
		self.buff_type = BUFF_TYPE_NONE
		self.achievement_name = achievement_name
		self.owner_triggers[EventOnDeath] = self.on_death

	def on_death(self, evt):
		from SteamAdapter import unlock_achievement
		unlock_achievement(self.achievement_name)


class Unit(object):

	def __init__(self):
		self.face_left = False
		self.is_player_controlled = False

		self.name = "Unnamed"
		self.tags = []

		self.max_hp = 1
		self.cur_hp = 0
		self.shields = 0

		self.spells = []
		self.cool_downs = {}

		self.buffs = []
		self.soulbound = False
		self.damage_redirects = None
		self.damage_floors = None
		self.channeling = 0
		self.buff_lookup_cache = None
		self.visible_buffs_cache = None
		self.equipment = []
		self.components = []

		self.team = TEAM_ENEMY

		self.turns_to_death = None

		self.resists = defaultdict(lambda : 0)
		self.resists_applied = False

		self.spell_bonuses = defaultdict(lambda : defaultdict(lambda: 0))
		self.global_bonuses = defaultdict(lambda: 0)
		self.tag_bonuses = defaultdict(lambda : defaultdict(lambda: 0))
		
		self.spell_bonuses_pct = defaultdict(lambda : defaultdict(lambda: 0))
		self.global_bonuses_pct = defaultdict(lambda: 0)
		self.tag_bonuses_pct = defaultdict(lambda : defaultdict(lambda: 0))
		self.spell_stat_version = 0

		self.Anim = None
		self.Transform_Anim = None
		self.prev_transform_anim = None

		self.is_boss = False
		self.is_lair = False
		self.is_final_boss = False

		self.asset = None
		self.asset_name = None
		self.asset_variants = []
		self.transform_asset = None
		self.last_transform_asset = None
		self.prev_transform_asset = None
		self.transform_flicker_frames = 0
		self.transform_flicker_tick = 0

		self.killed = False

		self.debuff_immune = False

		self.is_coward = False

		# The spell or buff which summoned this unit
		self.source = None
		self.minion_bonuses_applied = False

		# Does this unit get clarity after being stunned
		self.gets_clarity = False

		# Track whether the unit has been spawned yet- useful for making mutators only apply onces
		self.ever_spawned = False

		# The unit this unit spawned from- for bestiary completion
		self.parent = None

		# Use radius so that unit.x and unit.y give the unit's center for 3x3 & 5x5 units
		self.radius = 0

		self.last_action = None

		self.stationary = False

		self.flying = False

		self.burrowing = False

		self.quick_move = False

		self.melee_spell = None # Autospell to cast when the player melees something.  Only used by elephant form but could bring back flaming sword or something.

		self.quick_cast_used = False

		self.shrink_text = 0

		self.extra_tt_fns = []

	def iter_occupied_points(self):
		for i in range(-self.radius, self.radius+1):
			for j in range(-self.radius, self.radius+1):
				yield Point(self.x + i, self.y + j)

	def get_asset_name(self):
		if self.asset_name: name = self.asset_name
		else: name = self.name.lower().replace(' ', '_')
		return name

	def get_asset(self):
		if self.asset: return self.asset
		return ['char', self.get_asset_name()]

	def start_transform_flicker(self, previous_unit):
		assert self.radius == previous_unit.radius
		self.last_transform_asset = previous_unit.get_asset()

	def clear_anim(self, attr, cleared=None):
		anim = getattr(self, attr)
		if not anim: return
		if cleared is not None and anim in cleared:
			setattr(self, attr, None)
			return
		anim.unregister()
		setattr(self, attr, None)
		if cleared is not None: cleared.add(anim)

	def clear_runtime_anims(self):
		cleared = set()
		self.clear_anim('Anim', cleared)
		self.clear_anim('Transform_Anim', cleared)
		self.clear_anim('prev_transform_anim', cleared)

	def invalidate_buff_caches(self):
		self.visible_buffs_cache = None
		self.buff_lookup_cache = None

	def invalidate_spell_stats(self):
		self.spell_stat_version += 1

	def adjust_spell_bonus(self, spell_class, attr, amt, pct=False):
		if pct: self.spell_bonuses_pct[spell_class][attr] += amt
		else: self.spell_bonuses[spell_class][attr] += amt
		self.invalidate_spell_stats()

	def adjust_global_bonus(self, attr, amt, pct=False):
		if pct: self.global_bonuses_pct[attr] += amt
		else: self.global_bonuses[attr] += amt
		self.invalidate_spell_stats()

	def adjust_tag_bonus(self, tag, attr, amt, pct=False):
		if pct: self.tag_bonuses_pct[tag][attr] += amt
		else: self.tag_bonuses[tag][attr] += amt
		self.invalidate_spell_stats()

	def get_buff_lookup(self):
		if self.buff_lookup_cache is not None: return self.buff_lookup_cache
		lookup = defaultdict(list)
		for buff in self.buffs:
			for cls in type(buff).mro(): # walk up the buffs inheritance chain (to preserve isinstance lookups) - mro returns a list of classes
				if cls == object: break # walked too far up the inheritance chain
				lookup[cls].append(buff)
				if cls == Buff: break
		self.buff_lookup_cache = lookup
		return lookup

	def get_visible_buffs(self):
		if self.visible_buffs_cache is not None: return self.visible_buffs_cache

		seen_types = set()
		visible_buffs = []
		for b in self.buffs:
			if b.buff_type == BUFF_TYPE_PASSIVE: continue
			if b.buff_type == BUFF_TYPE_ITEM: continue
			if type(b) in seen_types: continue
			if b.asset == None: continue
			seen_types.add(type(b))
			visible_buffs.append(b)

		self.visible_buffs_cache = visible_buffs
		return visible_buffs

	def grant_redirect(self, redirect_source, redirect_fn):
		redirect = (redirect_source, redirect_fn)
		if self.damage_redirects is None: self.damage_redirects = (redirect,)
		else: self.damage_redirects += (redirect,)

	def remove_redirect(self, redirect_source):
		if self.damage_redirects is None: return
		redirects = tuple(redirect for redirect in self.damage_redirects if redirect[0] is not redirect_source)
		self.damage_redirects = redirects if redirects else None

	def set_damage_floor(self, floor_source, floor):
		floors = () if self.damage_floors is None else tuple(entry for entry in self.damage_floors if entry[0] is not floor_source)
		self.damage_floors = tuple(sorted(floors + ((floor_source, floor),), key=lambda entry: entry[1]))

	def remove_damage_floor(self, floor_source):
		if self.damage_floors is None: return
		floors = tuple(entry for entry in self.damage_floors if entry[0] is not floor_source)
		self.damage_floors = floors if floors else None

	def get_allies(self, tag_req=None):
		if not getattr(self, 'level', None): return []
		if tag_req is None: tag_req = []
		if not isinstance(tag_req, list): tag_req = [tag_req]
		return [u for u in self.level.units
				if u.is_alive()
				and u is not self
				and not are_hostile(u, self)
				and all(t in u.tags for t in tag_req)]

	def get_hostiles(self, tag_req=None):
		if not getattr(self, 'level', None): return []
		if tag_req is None: tag_req = []
		return [u for u in self.level.units
				if u.is_alive()
				and are_hostile(u, self)
				and all(t in u.tags for t in tag_req)]

	def get_stat_modifiers(self, spell, attr):
		if spell.stat_modifiers_owner is not self or spell.stat_modifiers_version != self.spell_stat_version:
			spell.stat_modifiers_cache.clear()
			spell.stat_modifiers_owner = self
			spell.stat_modifiers_version = self.spell_stat_version

		cached = spell.stat_modifiers_cache.get(attr, None)
		if cached is not None: return cached

		bonus_total = self.spell_bonuses[type(spell)].get(attr, 0)
		pct_total = 100.0 + self.spell_bonuses_pct[type(spell)].get(attr, 0)

		for tag in spell.tags:
			bonus_total += self.tag_bonuses[tag].get(attr, 0)
			pct_total += self.tag_bonuses_pct[tag].get(attr, 0)

		bonus_total += self.global_bonuses.get(attr, 0)
		pct_total += self.global_bonuses_pct.get(attr, 0)

		cached = (bonus_total, pct_total)
		spell.stat_modifiers_cache[attr] = cached
		return cached

	def get_stat(self, base, spell, attr):
		# Range for self targeted or melee spells does not change
		if attr == 'range' and spell.range < 2: return spell.range
		if attr == 'damage_type': return spell.damage_type

		bonus_total, pct_total = self.get_stat_modifiers(spell, attr)

		isint = type(base) == int
		value = base * (pct_total / 100.0) + bonus_total
		if isint: value = int(math.ceil(value))

		# Cap things at 0- or at 1, in the case of range or duration, as those function poorly when zeroed	
		if attr in ['range', 'duration', 'max_channel']: value = max(value, 1)
		else: value = max(value, 0)
		return value

	def __reduce__(self):
		self.clear_runtime_anims()
		return object.__reduce__(self)

	def equip(self, item):
		self.equipment.append(item)
		self.apply_buff(item)

		# Instantly proc on unit added self triggers
		if EventOnUnitAdded in item.owner_triggers:
			evt = EventOnUnitAdded(self)
			item.owner_triggers[EventOnUnitAdded](evt)

		item.on_equip(self)
		self.invalidate_spell_stats()
		item.do_ui_flash()


	def unequip(self, item):
		self.equipment.remove(item)
		self.remove_buff(item)
		item.on_unequip(self)
		self.invalidate_spell_stats()

	def grant_equipment_copy_to_minion(self, recipient, equipment):
		e = equipment.clone()
		e.get_tooltip = (lambda _b=e: _b.name)
		e.buff_type = BUFF_TYPE_PASSIVE
		for c, a in e.crafting_input_fns.items():
			for i in range(a): c().on_craft(recipient, e)  # dupes on_craft effects
		recipient.equip(e)

	def add_component(self, component):
		for t in component.tags: self.component_tags[t] += 1
		self.components.append(component)
		self.components.sort(key=lambda x: (len(x.tags), x.name))

	def remove_component(self, component):
		for t in component.tags: self.component_tags[t] -=1
		self.components.remove(component)

	def get_spell_upgrades(self):
		return sorted((b for b in self.buffs if b.buff_type == BUFF_TYPE_PASSIVE and b.prereq != None),key=lambda d: d.name) # only spell upgrades have prereqs, that is to have learned the spell

	def get_equipment(self):
		equipment_list = sorted((e for e in self.equipment), key=lambda b: b.name)
		return equipment_list

	def has_equipment(self, equipment):
		return any(e.name == equipment.name for e in self.equipment)

	def has_all_upgrades(self, spell):
		return len(getattr(spell, 'spell_upgrades', [])) <= len([b for b in self.buffs if getattr(b, 'prereq', None) == spell])

	def get_mastery(self, tag):
		mastery = 0
		for spell in self.spells:
			if tag in spell.tags:
				mastery += spell.level
				mastery += sum(u.level for u in spell.spell_upgrades if u.applied)
		return mastery

	def try_enter(self, other):
		return False

	def pre_advance(self):
		self.quick_cast_used = False
		
		# Pre turn effects
		self.cool_downs = { spell : (cooldown - 1) for (spell, cooldown) in self.cool_downs.items() if cooldown > 1}

		if not self.buffs: return
		for b in list(self.buffs):
			if b.applied:
				b.on_pre_advance()

	def advance(self, orders=None):
	
		can_act = True
		for b in self.buffs:
			if not b.on_attempt_advance():
				can_act = False
				if self.is_player_controlled:
					stun_duration = 1 if not isinstance(self.last_action, StunnedAction) else self.last_action.duration + 1
					self.last_action = StunnedAction(b, stun_duration)
					self.level.requested_action = None
					log_txt = ("[Wizard:wizard] is {buff}", {"buff": b.name})
					self.level.log(log_txt)

		if can_act:
			# Take an action
			if not self.is_player_controlled:
				action = self.get_ai_action()
			else:
				action = self.level.requested_action
				self.level.requested_action = None
				self.last_action = action

			if action:
				logging.debug("%s will %s" % (self, action))

			if isinstance(action, MoveAction):
				if self.is_player_controlled: self.level.log("[Wizard:wizard] takes a step")
				self.level.act_move(self, action.x, action.y)
				if self.quick_move and not self.quick_cast_used:
					self.level.leap_effect(self.x, self.y, Tags.Physical.color, self)
					self.quick_cast_used = True
					return False
			elif isinstance(action, CastAction):
				self.level.act_cast(self, action.spell, action.x, action.y)
				if action.spell.get_stat('quick_cast') and not self.quick_cast_used:
					self.quick_cast_used = True
					return False
			elif isinstance(action, PassAction):
				if self.is_player_controlled:
					if self.has_buff(ChannelBuff):
						self.level.log(("[Wizard:wizard] channeled {spell}", {"spell":getattr(self.get_buff(ChannelBuff), "spell_name", "")}))
					else:
						self.level.log("[Wizard:wizard] stands still")
				self.level.event_manager.raise_event(EventOnPass(self), self)

		return True

	def advance_buffs(self):
		# don't advance buffs if it gets killed
		if self.killed: return

		# Advance buffs after the character.
		# This way poison burning ect can be cured before they kill you, and lightning form doesnt glow when you cant actually use it.
		# Copy the list before iteration since we advance could modify the list
		for buff in list(self.buffs):
			buff.advance()

		# Do this here so that buffs advance N turns on creatures meant to live N turns
		if self.turns_to_death is not None:
			self.turns_to_death -= 1
			if self.turns_to_death <= 0 and self.is_alive():
				self.kill()
				self.level.show_effect(self.x, self.y, Tags.Translocation)

	def is_blind(self):
		return self.has_buff(BlindBuff)

	def is_stunned(self):
		# Skip action if stunned, but advance buffs first.
		for b in self.buffs:
			if isinstance(b, Stun):
				return True
		return False

	def can_be_stunned(self):
		if not self.is_alive(): return False
		if self.debuff_immune: return False
		if self.has_buff(StunImmune): return False
		if self.is_stunned(): return False
		return True

	def is_silenced(self):
		# Cannot cast spells if silenced
		for b in self.buffs:
			if isinstance(b, Silence):
				return True
		return False

	def anim_is_frozen(self):
		for b in self.buffs:
			if b.freeze_animation:
				return True
		return False

	def can_harm(self, other): # for pathing purposes, decide if a unit can harm another
		for s in self.spells:
			if s.can_harm(other) and not s.target_allies: # if a spell can harm them, and it's not supposed to target allies, then they are good to path toward
				return True
		return False

	def get_ai_action(self):
		
		assert(not self.is_player_controlled)
		if not self.is_alive(): return None
		sx = self.x
		sy = self.y
		level = self.level
		origin = Point(sx, sy)

		# For now always channel if you can
		if self.has_buff(ChannelBuff):
			b = self.get_buff(ChannelBuff)
			if b.channel_check:
				if b.channel_check(b.spell_target): return PassAction() # if channel_check succeeds, keep channeling
				else: self.remove_buff(b) # If should not channel, stop channeling and keep going to decide on action
			else: return PassAction() # If no channel check exists, default to continue channeling

		for spell in self.spells:
			if not spell.can_pay_costs(): continue
			spell_target = spell.get_ai_target() # this gets overwritten in many cases, so changing the base version won't fix everything
			if not spell_target: continue
			target_unit = level.get_unit_at(spell_target.x, spell_target.y)
			if target_unit and not target_unit == self and not spell.can_harm(target_unit):  # double check since get_ai_target gets overwritten sometimes. some spells target the caster, with damage they are immune to
				continue

			if spell_target and not spell.can_cast(spell_target.x, spell_target.y): # error logging
				# Should not happen ever but sadly it does alot
				if target_unit:
					target_str = target_unit.name
					if target_unit == self: target_str = 'self'
				else: target_str = "empty tile"
				print("%s wants to cast %s on invalid target (%s)" % (self.name, spell.name, target_str))
				continue

			return CastAction(spell, spell_target.x, spell_target.y)

		# Stationary monsters pass if they cant cast
		if self.stationary: return PassAction()

		# Cowards move away from closest enemy, swapping if neccecary
		if self.is_coward:
			p = self.get_flee_target()
			if p: return MoveAction(p.x, p.y)
			return self.random_move()

		target = None
		player = level.player_unit
		attempted_targets = set()
		self_radius = self.radius
		unreachable_targets = None
		ai_pathing_cache = level.ai_pathing_cache
		target_pathing_checked = False

		# The player is always prioritized if possible. unless berserked, then they aren't thinking clearly enough to look for the player.
		if not self.has_buff(BerserkBuff) and player and player != self and are_hostile(self, player) and self.can_harm(player): target = player

		while True:
			if not target:
				for prefer_permanent_units in [True, False]:
					best_target = None
					best_dist = None

					for u in level.units:
						if u == self: continue
						if u in attempted_targets: continue
						if prefer_permanent_units and u.turns_to_death is not None: continue
						if not prefer_permanent_units and u.turns_to_death is None: continue
						if not are_hostile(self, u): continue

						radius_sum = self_radius + u.radius
						dx = abs(sx - u.x) - radius_sum
						dy = abs(sy - u.y) - radius_sum
						if dx < 0: dx = 0
						if dy < 0: dy = 0
						dist = dx if dx > dy else dy
						if best_dist is not None and dist >= best_dist: continue
						if not self.can_harm(u): continue
						if dist > 1:
							if not self_radius and not level.can_stand(u.x, u.y, self, check_unit=False):
								attempted_targets.add(u)
								continue
							if ai_pathing_cache.is_unreachable(self, sx, sy, u):
								attempted_targets.add(u)
								if unreachable_targets is None: unreachable_targets = []
								unreachable_targets.append(u)
								continue

						best_target = u
						best_dist = dist

					if best_target:
						target = best_target
						target_pathing_checked = True
						break

			if not target: break
			if level.are_adjacent(self, target): return PassAction()

			if not target_pathing_checked:
				if not self_radius and not level.can_stand(target.x, target.y, self, check_unit=False):
					attempted_targets.add(target)
					target = None
					continue

				if ai_pathing_cache.is_unreachable(self, sx, sy, target):
					attempted_targets.add(target)
					if unreachable_targets is None: unreachable_targets = []
					unreachable_targets.append(target)
					target = None
					continue

			path = level.find_path(origin, Point(target.x, target.y), self)
			if not path: return PassAction()

			try:
				if libtcodpy.path_size(path) > 0:
					x, y = libtcodpy.path_get(path, 0)
					if level.can_move(self, x, y):
						if unreachable_targets:
							ai_pathing_cache.propagate_failures(self, x, y, unreachable_targets)
						return MoveAction(x, y)

					attempted_targets.add(target)
					target = None
					continue

				ai_pathing_cache.add_failure(self, sx, sy, target)
			finally: libtcodpy.path_delete(path)

			attempted_targets.add(target)
			if unreachable_targets is None: unreachable_targets = []
			unreachable_targets.append(target)
			target = None

		action = self.random_move()
		if unreachable_targets and isinstance(action, MoveAction):
			ai_pathing_cache.propagate_failures(self, action.x, action.y, unreachable_targets)
		return action

	def random_move(self):
		possible_movement_targets = [p for p in self.level.get_adjacent_points(Point(self.x, self.y), check_unit=True, filter_walkable=False) if self.level.can_stand(p.x, p.y, self)]
		if not possible_movement_targets: return PassAction()
		p = self.level.random.choice(possible_movement_targets)
		return MoveAction(p.x, p.y)

	def is_fleeing(self):
		return self.is_coward or self.has_buff(FearBuff)

	def get_flee_target(self):
		# simplify this? just look at the player unit and check if any adj tiles are farther away from the player unit or not?

		# Try to find 
		enemies = [u for u in self.level.units if self.level.are_hostile(self, u)]
		if enemies:
			sx = self.x
			sy = self.y
			closest = min(enemies, key=lambda u: (sx - u.x) * (sx - u.x) + (sy - u.y) * (sy - u.y))

			def can_flee_to(p):
				
				# Must be able to walk on the tile
				if not self.level.can_stand(p.x, p.y, self, check_unit=False):
					return False

				# 3x3s cannot swap
				if self.radius > 0:
					if not self.level.can_stand(p.x, p.y, self, check_unit=True):
						return False

				unit = self.level.get_unit_at(p.x, p.y)

				# Dont block yourself (aka for 3x3s)
				if unit == self:
					unit = None

				if unit and are_hostile(self, unit):
					return False
				# Don't let cowards continually swap with each other- looks like no one is moving at all when that happens
				# TODO- also look at fear buff?
				if unit and unit.is_fleeing():
					return False
				# Don't flee through a player, its confusing
				if unit and unit.is_player_controlled:
					return False
				# Don't swap with stationary units
				if unit and unit.stationary:
					return False
				# Cannot swap with 3x3s
				if unit and unit.radius:
					return False
				# If there is a unit, *it* must be able to walk on the tile I am currently on
				if unit and not self.level.can_stand(self.x, self.y, unit, check_unit=False):
					return False
				return True

			best_flee_points = [p for p in self.level.get_adjacent_points(Point(self.x, self.y), filter_walkable=False) if can_flee_to(p)]

			if best_flee_points:
				closest_x = closest.x
				closest_y = closest.y
				best_dist_sq = -1
				best_points = []
				for p in best_flee_points:
					dist_sq = (p.x - closest_x) * (p.x - closest_x) + (p.y - closest_y) * (p.y - closest_y)
					if dist_sq > best_dist_sq:
						best_dist_sq = dist_sq
						best_points = [p]
					elif dist_sq == best_dist_sq:
						best_points.append(p)

				p = self.level.random.choice(best_points)
				return p

		# If there are no enemies, or if none of the flee points are movable, return None		
		return None

	def is_alive(self):
		return self.cur_hp > 0 and not self.killed

	def add_spell(self, spell, prepend=False):

		# Avoid having two duplicately named spells since they basically count as the same spell
		existing = [s for s in self.spells if s.name == spell.name]
		if existing: return

		for buff in self.buffs:
			if buff.applied:
				buff.on_add_spell(spell)

		spell.caster = self
		spell.owner = self
		spell.cur_charges = spell.get_stat('max_charges')

		spell.do_ui_flash()
		
		if not prepend: self.spells.append(spell)
		else: self.spells.insert(0, spell)

	def remove_spell(self, spell):
		# Remove spell by name, dont worry about pointer address
		self.spells = [s for s in self.spells if s.name != spell.name]
		
		for buff in self.buffs:
			if buff.applied:
				buff.on_remove_spell(spell)

	def apply_buff(self, buff, duration=0):
		assert(isinstance(buff, Buff))

		# If we call this method before adding the monster to the level just add the buff to the list and we will call this again later
		if not hasattr(self, 'level'): self.buffs.append(buff); self.invalidate_buff_caches(); return
		
		# Do not apply buffs to dead units
		if not self.is_alive(): return

		# if not buff.on_attempt_apply(self): return
		self.level.event_manager.raise_event(EventOnBuffAttemptApply(buff, duration, self), self)

		if buff.buff_type == BUFF_TYPE_CURSE and self.debuff_immune: return

		# Do not refresh stuns or silences on clarity havers
		# Otherwise they can get stunlocked by anything with 2 or more duration
		# Which defeats the purpose of clarity
		if self.gets_clarity and isinstance(buff, Stun) and self.is_stunned(): return
		if self.gets_clarity and isinstance(buff, Silence) and self.is_silenced(): return

		def same_buff(b1, b2): return b1.name == b2.name and type(b1) == type(b2)

		existing = [b for b in self.buffs if same_buff(b, buff)]
		if existing:
			if buff.stack_type == STACK_NONE:
				if existing[0].turns_left == 0: return  # if existing is permanent, don't overwrite
				if duration == 0: existing[0].turns_left = 0; return # apply a permanent over a temporary
				existing[0].turns_left = max(duration, existing[0].turns_left)
				return
			elif buff.stack_type == STACK_DURATION and (existing[0].turns_left == 0 or duration == 0): existing[0].turns_left = 0; return # permanent overrides temporary, and temporary shouldn't override permanent
			elif buff.stack_type in [STACK_TYPE_TRANSFORM, STACK_DURATION]: existing[0].turns_left += duration; return
			elif buff.stack_type == STACK_REPLACE: self.remove_buff(existing[0]) # And continue to add this one

		buff.turns_left = duration

		self.buffs.append(buff)
		self.invalidate_buff_caches()
		result = buff.apply(self)
		if result == ABORT_BUFF_APPLY:
			self.buffs.remove(buff)
			self.invalidate_buff_caches()
			return

		btype = buff.buff_type
		if buff.show_effect and btype in (BUFF_TYPE_BLESS, BUFF_TYPE_CURSE):
			if btype == BUFF_TYPE_BLESS: self.level.show_effect(self.x, self.y, Tags.Buff_Apply, buff.color)
			elif btype == BUFF_TYPE_CURSE: self.level.show_effect(self.x, self.y, Tags.Debuff_Apply, buff.color)
			if duration == 0: log_txt = (text.PERMANENT_BUFF_APPLIED, {"buff": buff.name, "unit": log_name(self), "color": log_color(self)})
			else: log_txt = (text.BUFF_APPLIED, {"buff": buff.name, "unit": log_name(self), "color": log_color(self), "amount": duration})
			self.level.log(log_txt)

		self.level.event_manager.raise_event(EventOnBuffApply(buff, self), self)

	def remove_buff(self, buff):
		if buff not in self.buffs: return
		if not buff.applied: return
		self.buffs.remove(buff)
		self.invalidate_buff_caches()
		buff.unapply()
		self.level.event_manager.raise_event(EventOnBuffRemove(buff, self), self)

	def remove_buffs(self, buff_class):
		to_remove = list(self.get_buff_lookup().get(buff_class, ()))
		for b in to_remove: self.remove_buff(b)

	def has_buff(self, buff_class):
		return bool(self.get_buff_lookup().get(buff_class))

	def get_buff(self, buff_class):
		candidates = self.get_buff_lookup().get(buff_class)
		if candidates: return candidates[0]
		else: return None

	def get_buff_stacks(self, buff_class):
		return len(self.get_buff_lookup().get(buff_class, ()))

	def pay_hp(self, hp_cost, activator_name):
		if not hp_cost: return False
		if hp_cost >= self.cur_hp: return False
		self.cur_hp -= hp_cost
		log_txt = (text.PAY_HP, {"unit": self.name, "cost": hp_cost, "spell": activator_name})
		self.level.log(log_txt)
		self.level.event_manager.raise_event(EventOnSpendHP(self, hp_cost), self)
		self.level.show_effect(self.x, self.y, Tags.Blood, minor=hp_cost < 11)
		return True

	def can_be_healed(self):
		return self.is_alive() and self.cur_hp < self.max_hp and self.resists[Tags.Heal] < 100

	def heal(self, amount, spell):
		if not self.is_alive(): return 0
		return self.level.deal_damage(self.x, self.y, -amount, Tags.Heal, spell)

	def deal_damage(self, amount, damage_type, spell):
		if not self.is_alive(): return 0
		return self.level.deal_damage(self.x, self.y, amount, damage_type, spell)

	def add_shields(self, shields, cap=True):
		previous_shields = self.shields
		self.shields += shields
		if cap: self.shields = min(self.shields, 20) # max 20 shields
		if self.shields > previous_shields: self.level.show_effect(self.x, self.y, Tags.Shield_Apply)

	def remove_shields(self, shields):
		if not self.shields: return
		self.level.show_effect(self.x, self.y, Tags.Shield_Expire)
		self.shields -= shields
		if self.shields < 0: self.shields = 0

	def refresh(self):
		
		# Remove all temporary buffs and debuffs
		temp_buffs = [b for b in self.buffs if b.buff_type in [BUFF_TYPE_CURSE, BUFF_TYPE_BLESS]]
		for d in temp_buffs: self.remove_buff(d)
		self.cur_hp = self.max_hp
		for s in self.spells: s.cur_charges = s.get_stat('max_charges')
		self.shields = 0
		self.killed = False

	def get_spell(self, spell_class):
		spells = [s for s in self.spells if isinstance(s, spell_class)]
		if not spells: return None
		if len(spells) == 1: return spells[0]

		desired_name = spell_class().name

		for s in spells:
			if s.name == desired_name:
				return s

		return spells[0]

	def get_highest_spell_level(self, tag):
		opts = [s.level for s in self.spells if tag in s.tags]
		if not opts: return 0
		else: return max(opts)

	# Get the spell if it exists in the units spell list, make it up if it doesnt
	def get_or_make_spell(self, spell_class):
		spell = self.get_spell(spell_class)
		if spell is not None: return spell

		spell = spell_class()
		spell.owner = self
		spell.caster = self
		if self.source and self.source.owner: spell.statholder = self.source.owner # let minions casting your spells use your upgrades
		return spell

	def set_default_resistances(self):
		if self.resists_applied: return
		if Tags.Demon in self.tags:
			self.resists.setdefault(Tags.Holy, -100)
			self.resists.setdefault(Tags.Dark, 100)

		if Tags.Metallic in self.tags:
			self.resists.setdefault(Tags.Fire, 50)
			self.resists.setdefault(Tags.Physical, 50)
			self.resists.setdefault(Tags.Ice, 75)
			if Tags.Living in self.tags: self.resists.setdefault(Tags.Lightning, -50) # living things encased in metal are more susceptible to lightning
			else: self.resists.setdefault(Tags.Lightning, 100)

		if Tags.Undead in self.tags:
			self.resists.setdefault(Tags.Holy, -100)
			self.resists.setdefault(Tags.Dark, 100)
			self.resists.setdefault(Tags.Ice, 50)

		if Tags.Glass in self.tags:
			self.resists.setdefault(Tags.Fire, 50)
			self.resists.setdefault(Tags.Physical, -100)
			self.resists.setdefault(Tags.Lightning, 100)
			self.resists.setdefault(Tags.Ice, 100)

		# Poison only works on living, nature, or demons.  Not so hot vs arcane, constructs, ect.
		if Tags.Living in self.tags:
			self.resists.setdefault(Tags.Poison, 0)
		if Tags.Nature in self.tags:
			self.resists.setdefault(Tags.Poison, 0)
		elif Tags.Demon in self.tags:
			self.resists.setdefault(Tags.Poison, 0)
		else:
			self.resists.setdefault(Tags.Poison, 100)

		# Creatures with radius should also uh 'resist' stuns
		if self.radius: self.gets_clarity = True
		self.resists_applied = True

	def kill(self, damage_event=None, trigger_death_event=True):
		# Sometimes you kill something twice, whatever.
		if self.killed: return

		if trigger_death_event:
			self.level.event_manager.raise_event(EventOnDeath(self, damage_event), self)
			if self.level.player_unit and self.level.player_unit != self:
				if are_hostile(self.level.player_unit, self):
					self.level.turn_summary.enemy_kill_counts[self.name] += 1
				else:
					self.level.turn_summary.ally_kill_counts[self.name] += 1

		if self.level.player_unit: self.level.player_unit.game.unlock_bestiary(self)
		self.killed = True
		self.level.remove_obj(self)
		self.cur_hp = 0

	def has_tags(self, tags:list):
		for t in tags:
			if t in self.tags:
				return True
		return False

	def get_extra_examine_tooltips(self):
		extras = []
		for fn in self.extra_tt_fns: extras.append(fn())
		for s in self.spells:
			if s.caster is None: s.caster = self
			if s.owner is None: s.owner = self
			spell_extras = s.get_unit_extra_examine_tooltips()
			if spell_extras: extras.extend(spell_extras)
		for b in self.buffs:
			if b.owner is None: b.owner = self
			buff_extras = b.get_unit_extra_examine_tooltips()
			if buff_extras: extras.extend(buff_extras)
		return extras

class PathingProbe(Unit):

	def __init__(self, flying=False, burrowing=False, radius=0):
		Unit.__init__(self)
		self.radius = radius
		self.flying = flying
		self.burrowing = burrowing

# cheap pathers so we don't have to spin up a whole unit every time
ground_path_probe = PathingProbe()
flying_path_probe = PathingProbe(flying=True)

TILE_FLOOR = 0
TILE_WALL = 1
TILE_CHASM = 2

class Tile(object):
	def __init__(self, can_walk=True, x=0, y=0, level=None):
		self.can_walk = can_walk
		self.can_see = True
		self.can_fly = True
		self.unit = None
		self.prop = None
		self.cloud = None
		self.name = "Tile"
		self.description = "Tile"
		self.x = x
		self.y = y
		self.is_chasm = False
		self.level = level
		self.sprites = None
		self.sprite_index = None
		self.tileset = 'stone'
		self.chasm_type = 'water'

	def __reduce__(self):
		self.sprites = None
		return object.__reduce__(self)

	def is_floor(self):
		return self.can_walk

	def is_wall(self):
		return not self.can_see

class Prop(object):

	def on_player_enter(self, player):
		pass

	def on_unit_enter(self, unit):
		pass

	def on_player_exit(self, player):
		pass

	def advance(self):
		pass

	def get_asset(self):
		return self.asset

	def get_confirm_text(self, item_name):
		return "Really?"

	def __reduce__(self):
		self.Sprite = None
		if hasattr(self, 'sprite_key'): self.sprite_key = None
		return object.__reduce__(self)

	def __getstate__(self):
		state = self.__dict__.copy()
		state.pop('Sprite', None)
		state.pop('sprite_key', None)
		return state

class Portal(Prop):
	def __init__(self, level_gen_params, reroll=False):
		self.name = "Rift"
		self.level_gen_params = level_gen_params
		self.description = level_gen_params.get_description()
		self.next_level = None
		self.locked = True
		self.reroll = reroll

		if level_gen_params.difficulty == LAST_LEVEL:
			self.asset = ['tiles', 'portal', 'dormant_portal_mordred']
		else:
			self.asset = ['tiles', 'portal', 'dormant_portal']

	def on_player_enter(self, player):
		if self.reroll: self.next_level = None
		if not self.locked: self.level.cur_portal = self

	def advance(self):
		if not self.locked: return
		if self.level.gen_params.difficulty == LAST_LEVEL:
			self.level.show_effect(self.x, self.y, Tags.Arcane)
			self.level.remove_prop(self)

		if all(u.team == TEAM_PLAYER for u in self.level.units): self.unlock()

	def unlock(self):
		if not self.locked: return
		self.locked = False
		self.level_gen_params.materialize_reward(self.level.player_unit)
		if self.level_gen_params.difficulty == LAST_LEVEL: self.asset = ['tiles', 'portal', 'active_portal_mordred']
		else: self.asset = ['tiles', 'portal', 'active_portal']

	def get_extra_examine_tooltips(self):
		if self.locked == True: return

		extras = []
		if not hasattr(self, 'level_gen_params'): return extras
		gen_params = self.level_gen_params
		seen = set() # no need to show dupes of monsters

		if gen_params.primary_spawn:
			unit = gen_params.primary_spawn()
			if unit.name not in seen:
				extras.append(copy(unit))
				seen.add(unit.name)

		if gen_params.secondary_spawn and gen_params.secondary_spawn != gen_params.primary_spawn:
			unit = gen_params.secondary_spawn()
			if unit.name not in seen:
				extras.append(copy(unit))
				seen.add(unit.name)

		if gen_params.bosses:
			for boss in gen_params.bosses:
				if boss.name not in seen:
					extras.append(copy(boss))
					seen.add(boss.name)

		if gen_params.components:
			for component in gen_params.components:
				if component.name not in seen:
					extras.append(component)
					seen.add(component.name)

		bonus_components = []
		if gen_params.shrine:
			def iter_shrines(value): # allow for multiple shrines (for things like vaults)
				if isinstance(value, (list, tuple, set)):
					for shrine in value: yield shrine
				else: yield value

			for shrine in iter_shrines(gen_params.shrine):
				if not shrine: continue
				if isinstance(shrine, ComponentPickup):  bonus_components.append(shrine.component)
				if isinstance(shrine, Shop):
					extras.append(shrine)
					for item in shrine.items:
						extras.append(item)
						if hasattr(item, "get_extra_examine_tooltips"):
							subextras = item.get_extra_examine_tooltips()
							if subextras: extras.extend(subextras)
				else: extras.append(shrine)

		if gen_params.components or bonus_components:
			all_components = gen_params.components + bonus_components
			prospects = self.level.player_unit.game.get_prospective_equipment(all_components)
			extras.insert(0, prospects)

		return extras

class MemoryOrb(Prop):
	def __init__(self):
		self.name = "Memory Orb"
		self.description = "Grants 1 SP"
		self.asset = ['tiles', 'items', 'animated', 'mana_orb']

	def on_player_enter(self, player):
		player.xp = player.xp + 1
		self.level.remove_prop(self)
		self.level.event_manager.raise_event(EventOnItemPickup(self), player)

class HeartDot(Prop):
	def __init__(self):
		self.name = "Ruby Heart"
		self.description = "Increase max HP by 25 and restore all health"
		self.asset = ['tiles', 'items', 'animated', 'ruby_heart']

	def on_player_enter(self, player):
		player.max_hp += 25
		player.cur_hp = player.max_hp
		self.level.remove_prop(self)
		self.level.event_manager.raise_event(EventOnItemPickup(self), player)

class ComponentPickup(Prop):
	def __init__(self, component):
		self.component = component
		self.name = component.name
		self.description = component.description
		self.asset = component.get_asset()

	def on_player_enter(self, player):
		player.add_component(self.component)
		self.level.remove_prop(self)
		self.level.log(("Wizard picked up {component}.", {"component": self.component.name}))
		self.component.on_pickup(player, self.level)
		self.level.event_manager.raise_event(EventOnItemPickup(self), player)

	def get_extra_examine_tooltips(self, game):
		return self.component.get_extra_examine_tooltips(game)

class Shop(Prop):

	def __init__(self):
		self.items = []
		self.name = "Shop"
		self.description = " "
		self.asset = ['tiles', 'items', 'animated', 'trinket']

	def get_description(self):
		return self.description

	def buy(self, shopper, item): # overwrite this for complex shrine effects
		self.on_buy(shopper, item)
		if isinstance(item, Equipment): shopper.equip(item)
		elif isinstance(item, Buff): shopper.apply_buff(item)
		elif isinstance(item, Spell): shopper.add_spell(item)
		else: assert(False)
		self.close()

	def close(self):
		self.level.cur_shop = None
		self.level.remove_prop(self)
		self.items = []

	def on_buy(self, shopper, item):
		pass

	def can_shop(self, shopper, item):
		if item is None: return True
		if item not in self.items: return False
		assert(isinstance(shopper, Unit))
		return True

	def on_player_enter(self, player):
		player.level.cur_shop = self

class Level(object):
	def __init__(self, w, h):
		self.width = w
		self.height = h

		self.size = self.width
		
		self.tiles = [[Tile(x=j, y=i, level=self) for i in range(h)] for j in range(w)]
		self.terrain_generation = 0
		self.effects = []
		effect_tile_count = w * h
		self.effect_color_generation = 0
		self.effect_color_generations = [-1] * effect_tile_count
		self.effect_color_counts = [0] * effect_tile_count
		self.effect_color_slots = [[None] * EFFECT_COLORS_PER_TILE for _ in range(effect_tile_count)]
		self.units = []
		self.props = []
		self.active_spells = []
		self.clouds = []

		self.cur_obj = None
		self.turns = self.iter_frame()

		self.cur_portal = None

		self.is_awaiting_input = False
		self.requested_action = None

		self.player_unit = None
		self.event_manager = EventHandler()

		self.cur_shop = None
		self.gen_params = None

		self.tcod_map = None

		self.frame_start_time = time.time()

		self.random = random.Random()
		self.level_id = random.randint(0, 100000)


		self.spell_counts = defaultdict(lambda: 0)

		self.damage_taken_sources = defaultdict(lambda: 0)
		self.damage_dealt_sources = defaultdict(lambda: 0)
		self.damage_instances = {}
		self.pending_casts = deque()
		self.processing_pending_casts = False
		self.cast_contexts = {}
		self.current_cast_context = None
		self.cast_chain_cap_hit = False

		self.turn_no = 0
		self.extra_turns_taken = defaultdict(int)

		self.fov = libtcodpy.FOV_PERMISSIVE_8
		self.combat_log = defaultdict(list)
		self.level_no = 0

		self.turn_summary = TurnSummary()

		self.map_dirty = True
		self.fov_cache = {}
		self.ai_pathing_cache = AIPathingCache()

	def __getstate__(self):
		state = self.__dict__.copy()
		state["effects"] = []
		state["active_spells"] = []
		state["cast_contexts"] = {}
		state["current_cast_context"] = None
		state["turns"] = None
		state["tcod_map"] = None
		state["fov_cache"] = {}
		state["ai_pathing_cache"] = AIPathingCache()
		state["turn_summary"] = TurnSummary()
		state["map_dirty"] = True
		state["event_manager"] = None
		return state

	def setup_level(self, level_num):
		self.level_no = level_num

		# Set realm numbers for any already unlocked portals.
		for p in self.props:
			if not isinstance(p, Portal):
				continue
			if p.level_gen_params.level:
				p.level_gen_params.level.setup_level(level_num+1)

	def log(self, entry):
		self.combat_log[max(1, self.turn_no)].append(resolve_text(entry))


	def can_move(self, unit, x, y, teleport=False, force_swap=False):
		if not teleport and max(abs(unit.x - x), abs(unit.y - y)) > 1: return False
		if not self.is_coord_in_bounds(x, y): return False
		if not self.can_stand(x, y, unit, check_unit=False): return False

		# Big units can only move to completely clear tiles- they have no chance of swapping units
		if unit.radius and not self.can_stand(x, y, unit, check_unit=True): return False

		# Blockers can be swapped unless they are large or stationary or cannot stand on the tile they are being swapped to
		blocker = self.tiles[x][y].unit
		
		# Big units should not block themselves of course
		if blocker == unit: blocker = None

		if blocker is not None:

			# big units cannot swap or be swapped
			if unit.radius > 0 or blocker.radius > 0: return False

			# Do not non flying units onto chasms
			if not self.can_stand(unit.x, unit.y, blocker, check_unit=False): return False

			# Do not force walkers onto chasms
			if not blocker.flying and not self.tiles[x][y].can_walk: return False

			# Check additional conditions if the swap is not forced, aka is from a move command not a spell:
			if not force_swap:

				# Only coward units and players can do non forced swap movement
				if not unit.is_fleeing() and not unit.is_player_controlled: return False

				# Enemies can only swap via spells
				if are_hostile(unit, blocker): return False

				# Nothing can swap the player except magic
				if blocker.is_player_controlled: return False

				# Nothing can swap stationary units except magic
				if blocker.stationary: return False

		return True

	def set_order_move(self, x, y):
		self.requested_action = MoveAction(x, y)
		self.is_awaiting_input = False

	def set_order_cast(self, spell, x, y):
		self.requested_action = CastAction(spell, x, y)
		self.is_awaiting_input = False

	def set_order_pass(self):
		self.requested_action = PassAction()
		self.is_awaiting_input = False

	def act_move(self, unit, x, y, teleport=False, leap=False, force_swap=False):
		# Do nothing if something tries to move a dead unit- a spell or buff for instance
		if not unit.is_alive(): return
		assert(isinstance(unit, Unit))
		if not leap: assert(self.can_move(unit, x, y, teleport=teleport, force_swap=force_swap))

		if unit.is_player_controlled:
			prop = self.tiles[unit.x][unit.y].prop
			if prop:
				prop.on_player_exit(unit)
				if prop is self.cur_portal: self.cur_portal = None

		# flip sprite if needed
		if x < unit.x: unit.face_left = True
		if x > unit.x: unit.face_left = False

		# allow swaps
		swapper = self.tiles[x][y].unit
		if swapper == unit: swapper = None

		oldx = unit.x
		oldy = unit.y

		# Clear previously occupied tiles
		for i in range(-unit.radius, unit.radius+1):
			for j in range(-unit.radius, unit.radius+1):
				self.tiles[unit.x+i][unit.y+j].unit = None

		unit.x = x
		unit.y = y

		# Poit occupied tiles to unit
		for i in range(-unit.radius, unit.radius+1):
			for j in range(-unit.radius, unit.radius+1):
				self.tiles[x+i][y+j].unit = unit

		# Execute burrow
		if unit.burrowing:
			for occ in unit.iter_occupied_points():
				if self.tiles[occ.x][occ.y].is_wall():
					self.make_floor(occ.x, occ.y)
					self.show_effect(occ.x, occ.y, Tags.Physical)

		# allow swaps
		if swapper:
			self.tiles[oldx][oldy].unit = swapper
			swapper.x = oldx
			swapper.y = oldy
			if self.event_manager.has_handlers(EventOnMoved, swapper):
				self.event_manager.raise_event(EventOnMoved(swapper, oldx, oldy, teleport=False, old_x=x, old_y=y), swapper)

			# Fix perma circle on swap
			if swapper.is_player_controlled:
				prop = self.tiles[swapper.x][swapper.y].prop
				if prop:
					prop.on_player_exit(swapper)
					if prop is self.cur_portal: self.cur_portal = None

		if self.event_manager.has_handlers(EventOnMoved, unit):
			self.event_manager.raise_event(EventOnMoved(unit, x, y, teleport=teleport, old_x=oldx, old_y=oldy), unit)

		prop = self.tiles[x][y].prop
		if prop:
			if unit.is_player_controlled: prop.on_player_enter(unit)
			prop.on_unit_enter(unit)

		cloud = self.tiles[x][y].cloud
		if cloud: cloud.on_unit_enter(unit)
		
	def act_cast(self, unit, spell, x, y, pay_costs=True, queue=True, **cast_kwargs):
		# Enqueue the cast request and make sure everything in the queue runs right away
		out = []
		self.pending_casts.append((unit, spell, x, y, pay_costs, queue, cast_kwargs, out))
		self.process_pending_casts()
		return out[0] if out else None

	def defer_cast(self, unit, spell, x, y, pay_costs=True, queue=True, **cast_kwargs):
		# Used by reaction triggers to schedule work after the current cast unwinds
		self.pending_casts.append((unit, spell, x, y, pay_costs, queue, cast_kwargs, None))
		if not self.processing_pending_casts: self.process_pending_casts()

	def process_pending_casts(self):
		# Drain the pending queue iteratively so spell reactions don't recurse
		if self.processing_pending_casts: return

		self.processing_pending_casts = True
		processed = 0

		try:
			while self.pending_casts:
				unit, spell, x, y, pay_costs, queue, cast_kwargs, out = self.pending_casts.popleft()
				result = self.execute_cast(unit, spell, x, y, pay_costs, queue, cast_kwargs)
				if out is not None: out.append(result)

				processed += 1
				if processed >= DEFERRED_CAST_CAP:
					if not self.cast_chain_cap_hit:
						self.log(text.SPELL_CAST_CAP_REACHED)
						from SteamAdapter import record_cast_chain_cap
						record_cast_chain_cap()
						self.cast_chain_cap_hit = True
					self.pending_casts.clear()
					break
		finally: self.processing_pending_casts = False

	def execute_cast(self, unit, spell, x, y, pay_costs=True, queue=True, cast_kwargs=None):
		assert(isinstance(unit, Unit)), "caster is not of type unit, is %s" % type(unit)
		if cast_kwargs is None: cast_kwargs = {}

		if unit.is_player_controlled: self.spell_counts[spell.name] += 1
		log_txt = (text.USE_SPELL, {"unit":log_name(unit), "color": log_color(unit), "spell": spell.name})
		self.log(log_txt)

		# flip sprite if needed
		if x < unit.x: unit.face_left = True
		if x > unit.x: unit.face_left = False

		if pay_costs:
			assert(spell.can_cast(x, y)), "%s trying to cast spell %s on untargetable tile %d, %d" % (unit.name, spell.name, x, y)
			assert(spell.can_pay_costs()), "%s trying to cast spell %s, but cannot pay costs" % (unit.name, spell.name)

		if pay_costs: spell.pay_costs()

		# If we want to queue the spell, queue it.  Else return the generator so the calling spell can iterate over it.
		context = CastContext(spell, unit, x, y, pay_costs, cast_kwargs)
		if queue:
			gen = spell.cast(x, y, **cast_kwargs)
			assert hasattr(gen, "__next__"), "%s.cast returned %s" % (type(spell).__name__, type(gen).__name__)
			self.queue_spell(gen)
			self.cast_contexts[gen] = context
			rval = None
		else:
			gen = spell.cast(x, y, **cast_kwargs)
			rval = self.run_with_cast_context(gen, context)

		self.event_manager.raise_event(EventOnSpellCast(spell, unit, x, y, pay_costs), unit)

		return rval

	def act_shop(self, unit, item):

		if item is None: self.cur_shop = None; return
		assert(isinstance(unit, Unit))
		assert(self.cur_shop)
		return self.cur_shop.buy(unit, item)

	def can_stand(self, x, y, unit, check_unit=True):
		assert(isinstance(unit, Unit))

		radius = unit.radius
		if not radius:
			if x < 0 or x >= self.width or y < 0 or y >= self.height: return False
			tile = self.tiles[x][y]
			if check_unit and tile.unit is not None and tile.unit != unit: return False
			if tile.is_chasm and not unit.flying: return False
			if not tile.can_see and not unit.burrowing and not tile.can_fly: return False
			return True

		# Use a weird loop format to avoid heap allocating range objects since can_stand is called *constantly*
		i = -radius
		chasms = 0

		while i <= radius:
			j = -radius
			while j <= radius:

				cur_x = x + i
				cur_y = y + j

				if not self.is_coord_in_bounds(cur_x, cur_y): return False
				tile = self.tiles[cur_x][cur_y]

				# if there's a different unit standing there then we can't
				if check_unit and tile.unit is not None and tile.unit != unit: return False

				# Only flyers can go over chasms
				if tile.is_chasm and not unit.flying: chasms += 1

				# Only burrowers can go through walls
				if not tile.can_see and not unit.burrowing and not tile.can_fly: return False

				j += 1
			i += 1

		total_sq_occupied = (1 + 2*radius) * (1 + 2*radius)
		if not unit.flying and chasms > total_sq_occupied / 2.0: return False
		return True

	def can_walk(self, x, y, check_unit=False):
		if not self.is_coord_in_bounds(x, y): return False
		tile = self.tiles[x][y]
		if check_unit and tile.unit is not None: return False
		return tile.can_walk

	def find_path(self, start, target, pather, pythonize=False, cosmetic=False, unit_penalty=4):
		
		# Early out if the pather is surrounded by units and walls
		# If the unit cannot move, we dont care how it should move
		# Do not do this for cosmetic paths- they can step over units, and are infrequently called anyway
		if not cosmetic and unit_penalty != 0:
			boxed_in = True
			for p in self.get_adjacent_points(start, filter_walkable=False):
				if self.can_stand(p.x, p.y, pather):
					boxed_in = False
					break

			if boxed_in: return None


		can_stand = self.can_stand
		tiles = self.tiles
		target_x = target.x
		target_y = target.y
		p_radius = pather.radius

		def path_func(xFrom, yFrom, xTo, yTo, userData):
			# If the previous point is basically 'arrived', we dont need to check further points.
			if p_radius and max(abs(xFrom - target_x), abs(yFrom - target_y)) <= p_radius + 1: return 0.5
			if not can_stand(xTo, yTo, pather, check_unit=False): return False

			# By default, all traversable tiles have cost 1.
			# But various things can penalize this like units in the way or props on the ground
			cost = 1.0

			for i in range(-p_radius, p_radius+1):
				for j in range(-p_radius, p_radius+1):
					tile = tiles[xTo+i][yTo+j]
					blocker_unit = tile.unit if tile.unit != pather else None
					if blocker_unit:
						if blocker_unit.stationary: cost += 12.5 * unit_penalty
						else: cost += unit_penalty
					elif tile.prop and unit_penalty != 0: # only care if there's a unit penalty, not for spells and such
						# player pathing avoids unlocked portals and shops unless that is the target
						if ((isinstance(tile.prop, Portal) and not tile.prop.locked) or isinstance(tile.prop, Shop)) and pythonize and not (xTo == target_x and yTo == target_y): return False
						# creatures have a slight preference to avoid props
						cost += 0.1
			return cost

		path = libtcodpy.path_new_using_function(self.width, self.height, path_func)
		libtcodpy.path_compute(path, start.x, start.y, target.x, target.y)
		if pythonize:
			ppath = []
			for i in range(libtcodpy.path_size(path)):
				x, y = libtcodpy.path_get(path, i)
				ppath.append(Point(x, y))
			libtcodpy.path_delete(path)
			return ppath
		return path

	# BFS to find a path to a standable tile, for units who lose flying while over a chasm.
	def find_shortest_path_to_nearest_valid_tile(self, x, y, unit):  # BFS for nearest valid landing tile
		start = Point(x, y)  # starting point
		parents = {start: None}  # map each visited point to its predecessor
		visited = {start}  # set of already-seen points
		queue = deque([start])  # FIFO queue of points to explore

		def build_path(end):  # reconstruct path from start to end using parents
			path = []  # list of points from start to end
			cur = end  # begin at the destination
			while cur:  # walk backward until None
				path.append(cur)  # add current point
				cur = parents[cur]  # move to predecessor
			path.reverse()  # reverse to get start -> end
			return path  # return the path

		while queue:  # while there are points to explore
			p = queue.popleft()  # take the oldest point (BFS order)
			if p != start and self.can_stand(p.x, p.y,  unit):  # if this is a valid landing tile
				return build_path(p)  # return the path to it
			for n in self.get_adjacent_points(p, filter_walkable=False):  # check all 8 neighbors (walls included)
				if n in visited: continue  # skip already-seen points

				if self.tiles[n.x][n.y].is_wall():  # if neighbor is a wall
					# Walls are terminals: only allow landing if burrowing
					if unit.burrowing and self.can_stand(n.x, n.y, unit):  # burrower can land on wall
						parents[n] = p  # record predecessor
						return build_path(n)  # return path ending at this wall
					continue  # never traverse through walls

				visited.add(n)  # mark neighbor as seen
				parents[n] = p  # record how we got there
				queue.append(n)  # push neighbor to be explored later

		return []  # no valid landing tile found

	def advance(self, full_turn=False):
		#self.advance_effects()
		self.frame_start_time = time.time()
		self.frame_units_moved = 0
		if not self.turns:
			self.turns = self.iter_frame()
		
		if not full_turn:
			next(self.turns)
		else:
			i = 0
			while not next(self.turns):
				# Limit to 5000 iterations
				i += 1
				assert(i < 5000)

	def advance_effects(self, advance=True):
		if self.effects:
			if advance:
				for effect in self.effects:
					effect.advance()

			# Cull expired effects
			self.effects = [fx for fx in self.effects if fx.frames_left > 0]
			advanced_effects = True

	def advance_spells(self):
		if not self.active_spells: return

		# gather all spells at beginning of queue with same code
		head_code = self.active_spells[0].gi_code
		to_advance = []
		for s in self.active_spells:
			if s.gi_code != head_code: break
			to_advance.append(s)

		stopped_spells = None
		for s in to_advance:
			prev_context = self.current_cast_context
			self.current_cast_context = self.cast_contexts.get(s)
			try: stopped = next(s, "Stopped")
			finally: self.current_cast_context = prev_context
			if stopped == "Stopped":
				if stopped_spells is None: stopped_spells = set()
				stopped_spells.add(s)
				self.cast_contexts.pop(s, None)

		if stopped_spells:
			self.active_spells[:len(to_advance)] = [s for s in to_advance if s not in stopped_spells]

	def can_advance_spells(self):
		return len(self.active_spells) > 0

	def get_next_unit(self):
		return 

	# extra turns for an ai unit
	def take_turn(self, unit):
		if not unit or not unit.is_alive() or unit.is_player_controlled: return
		if self.extra_turns_taken[self.turn_no] >= EXTRA_TURNS_CAP:
			if self.extra_turns_taken[self.turn_no] == EXTRA_TURNS_CAP: self.log("Extra turns per player turn limit of 2048 reached")
			if unit.team == TEAM_PLAYER: self.extra_turns_taken[self.turn_no] += 1
			return

		self.log(("{unit} takes an extra turn", {"unit": color_entity(log_name(unit), log_color(unit))}))
		if unit.team == TEAM_PLAYER: self.extra_turns_taken[self.turn_no] += 1
		unit.pre_advance()
		can_act = True
		for b in unit.buffs:
			if not b.on_attempt_advance():
				can_act = False
				break

		if can_act:
			finished_advance = False
			while not finished_advance:
				action = unit.get_ai_action()

				if isinstance(action, MoveAction):
					self.act_move(unit, action.x, action.y)
					if unit.quick_move and not unit.quick_cast_used:
						self.leap_effect(action.x, action.y, Tags.Physical.color, unit)
						unit.quick_cast_used = True
						yield
						continue
				elif isinstance(action, CastAction):
					cast_iter = self.act_cast(unit, action.spell, action.x, action.y, queue=False)
					if cast_iter:
						for _ in cast_iter:
							yield

					if action.spell.get_stat('quick_cast') and not unit.quick_cast_used:
						unit.quick_cast_used = True
						yield
						continue


				elif isinstance(action, PassAction):
					if self.event_manager.has_handlers(EventOnPass, unit):
						self.event_manager.raise_event(EventOnPass(unit), unit)

				finished_advance = True

		unit.advance_buffs()
		yield

	def iter_frame(self):

		while self.can_advance_spells():
			yield self.advance_spells()

		# An iterator representing the order of turns for all game objects
		while True:

			self.damage_instances.clear()
			self.cast_chain_cap_hit = False

			# Yield once per iteration if there are no units to prevent infinite loop
			if not self.units: yield

			self.turn_no += 1

			if any(u.team != TEAM_PLAYER for u in self.units):
				log_txt = ("Level {lvl}, Turn {turn} begins", {"lvl": self.level_no, "turn": self.turn_no})
				self.log(log_txt)

			# Cache unit list here to enforce summoning delay
			turn_units = list(self.units)
			for is_player_turn in [True, False]:
				clouds = [cloud for cloud in self.clouds if cloud.owner.is_player_controlled == is_player_turn]
				if clouds:
					for cloud in clouds:
						if cloud.is_alive:
							cloud.advance()
					while self.can_advance_spells():
						yield self.advance_spells()

				units = [unit for unit in turn_units if unit.is_player_controlled == is_player_turn]
				self.random.shuffle(units)

				for unit in units:
					if not unit.is_alive(): continue
					unit.pre_advance()

					finished_advance = False
					while not finished_advance:
						if unit.is_player_controlled and not unit.is_stunned() and not self.requested_action:
							self.is_awaiting_input = True
							yield
						
						# Yield for 1 frame if stunned to prevent jarring time skip
						if unit.is_player_controlled and unit.is_stunned(): yield

						# Clear turn summary as soon as player chooses an action, before it is executed
						# But group all things happening during stuns together
						if unit.is_player_controlled and not unit.is_stunned(): self.turn_summary.clear()

						finished_advance = unit.advance()

						#yield
						while self.can_advance_spells(): yield self.advance_spells()

					# Advance buffs after advancing spells
					unit.advance_buffs()

					while self.can_advance_spells(): yield self.advance_spells()

					self.frame_units_moved += 1
					
					# Yield if the current advance frame is above the advance time budget
					if time.time() - self.frame_start_time > MAX_ADVANCE_TIME: yield

			# Advance all props simultaneously
			for prop in list(self.props): prop.advance()

			# slowly clear any leftover units either from component pickups or other misc effects
			self.try_dismiss_units()

			# In the unlikely event that that created effects, advance them
			while self.can_advance_spells(): yield self.advance_spells()

			if self.player_unit: self.player_unit.game.record_turn_damage_achievement()

			if not visual_mode: yield True


	def get_unit_at(self, x, y):
		if x < 0 or x >= self.width or y < 0 or y >= self.height: return None
		return self.tiles[x][y].unit

	def get_connected_group_from_point(self, x, y, avoid_tags=[], required_tags=[], ignored_units=[], check_hostile=None, check_friendly=None, num_targets=-1):
		#Avoid Tags: If a unit has these tags, it will be ignored.
		#Required Tags: If a unit does not have these tags, it will be ignored.
		#Ignored Units: Add units you want to be ignored, e.g. the player.
		#Check Hostile: Only add units hostile to the given unit.
		unit = self.get_unit_at(x, y)
		if not unit: return []
		candidates = {unit}
		checked_units = set()
		unit_group = set()

		while candidates:
			unit = candidates.pop()
			if unit in checked_units: continue
			checked_units.add(unit)

			if unit in ignored_units: continue

			skip = False
			for tag in required_tags:
				if not tag in unit.tags:
					skip = True

			for tag in avoid_tags:
				if tag in unit.tags:
					skip = True

			if skip: continue
			if check_hostile and not are_hostile(check_hostile, unit): continue
			if check_friendly and are_hostile(check_friendly, unit): continue
			if num_targets > -1 and len(unit_group) >= num_targets: break

			unit_group.add(unit)
			for adjacent_unit in self.get_adjacent_units(unit):
				if adjacent_unit not in checked_units: candidates.add(adjacent_unit)

		return list(unit_group)

	def unit_distance(self, a, b, diag=False):  # specialized to measure for multi-tile units
		a_radius = a.radius if isinstance(a, Unit) else 0
		b_radius = b.radius if isinstance(b, Unit) else 0

		dx = abs(a.x - b.x) - a_radius - b_radius
		dy = abs(a.y - b.y) - a_radius - b_radius
		if dx < 0: dx = 0
		if dy < 0: dy = 0

		if diag: return dx if dx > dy else dy
		return math.sqrt(dx * dx + dy * dy)

	def are_adjacent(self, a, b): # fast adjacency for units/pts
		reach = 1 + getattr(a, 'radius', 0) + getattr(b, 'radius', 0)
		dx = abs(a.x - b.x)
		dy = abs(a.y - b.y)
		return dx <= reach and dy <= reach

	def get_units_by_distance(self, unit, friendly=False, enemy=False, require_los=False, max_results=None):
		filters = []
		if friendly: filters.append(are_friendly)
		if enemy: filters.append(are_hostile)
		if require_los: targets = self.get_units_in_los(unit)
		else: targets = self.units

		def passes_filters(u):
			if u is unit: return False
			return all(f(unit, u) for f in filters)

		targets = [u for u in targets if passes_filters(u)]
		if not targets: return []
		self.random.shuffle(targets)
		if max_results is not None:
			if max_results <= 0: return []
			return heapq.nsmallest(max_results, targets, key=lambda u: self.unit_distance(unit, u))
		return sorted(targets, key=lambda u: self.unit_distance(unit, u))

	def get_summon_point(self, x, y, radius_limit=5, sort_dist=True, flying=False, diag=False, burrowing=False,  unit=None):
		tiles = self.tiles
		if sort_dist and not diag:
			max_r = min(radius_limit, MAX_RING_RADIUS)
			for r in range(max_r + 1):
				for o in get_points_in_ring_at_center(x, y, r):
					if unit:
						if self.can_stand(o.x, o.y, unit): return o
						continue

					tile = tiles[o.x][o.y]
					valid = tile.can_walk or (flying and tile.can_fly) or (burrowing and not tile.can_see)
					if not valid: continue
					if tile.unit: continue
					return o
			return None

		options = list(self.get_points_in_ball(x, y, radius_limit, diag=diag))
		if sort_dist: options.sort(key=lambda p: distance(p, Point(x, y)))
		else: self.random.shuffle(options)

		for o in options:
			if unit:
				if self.can_stand(o.x, o.y, unit): return o
				continue

			tile = tiles[o.x][o.y]
			valid = tile.can_walk or (flying and tile.can_fly) or (burrowing and not tile.can_see)
			if not valid: continue
			if tile.unit: continue
			return o

		return None

	def get_random_stand_tile(self, unit):
		choice = None
		count = 0
		for t in self.iter_tiles():
			if not self.can_stand(t.x, t.y, unit): continue
			count += 1
			if count == 1 or self.random.randrange(count) == 0:
				choice = Point(t.x, t.y)
		return choice

	def get_farthest_stand_tile(self, unit, anchor, diag=True):
		choice = None
		best = -1
		ties = 0
		ax = anchor.x
		ay = anchor.y

		for t in self.iter_tiles():
			if not self.can_stand(t.x, t.y, unit): continue

			if diag:
				dist = max(abs(ax - t.x), abs(ay - t.y))
			else:
				dx = ax - t.x
				dy = ay - t.y
				dist = dx * dx + dy * dy

			if dist > best:
				best = dist
				choice = Point(t.x, t.y)
				ties = 1
				continue

			if dist == best:
				ties += 1
				if self.random.randrange(ties) == 0:
					choice = Point(t.x, t.y)

		return choice

	def iter_tiles(self):
		for i in range(len(self.tiles)):
			for j in range(len(self.tiles[i])):
				yield self.tiles[i][j]

	def is_point_in_bounds(self, point):
		return point.x >= 0 and point.x < self.width and point.y >= 0 and point.y < self.height

	def is_coord_in_bounds(self, x, y):
		return x >= 0 and x < self.width and y >= 0 and y < self.height


	def get_points_in_rect(self, xmin, ymin, xmax, ymax):
		xmin = max(xmin,0)
		xmax = min(xmax+1,self.width)
		ymin = max(ymin,0)
		ymax = min(ymax+1,self.height)
		
		for x in range(xmin, xmax):
			for y in range(ymin, ymax):
				yield Point(x, y)

	def get_adjacent_points(self, point, filter_walkable=True, check_unit=False, r=0):
		adjacent = (p for p in self.get_points_in_rect(point.x - (r+1), point.y - (r+1), point.x + (r+1), point.y + (r+1)) if p != point)
		if filter_walkable: return (p for p in adjacent if self.can_walk(p.x, p.y, check_unit=check_unit))
		else: return adjacent

	# quickly find adjacent units without a bunch of allocation
	def get_adjacent_units(self, unit):
		radius = unit.radius + 1
		max_x = self.width - 1
		max_y = self.height - 1

		xmin = unit.x - radius
		xmax = unit.x + radius
		ymin = unit.y - radius
		ymax = unit.y + radius

		if xmin < 0: xmin = 0
		if xmax > max_x: xmax = max_x
		if ymin < 0: ymin = 0
		if ymax > max_y: ymax = max_y

		tiles = self.tiles
		seen = {None}
		for x in range(xmin, xmax+1):
			column = tiles[x]
			seen.add(column[ymin].unit)
			seen.add(column[ymax].unit)

		left = tiles[xmin]
		right = tiles[xmax]
		for y in range(ymin + 1, ymax):
			seen.add(left[y].unit)
			seen.add(right[y].unit)

		seen.remove(None)
		seen.discard(unit)

		return list(seen)

	def get_tiles_in_ball(self, x, y, radius, diag=False):
		return [self.tiles[p.x][p.y] for p in self.get_points_in_ball(x, y, radius, diag=diag)]

	def get_points_in_ball(self, x, y, radius, diag=False):
		max_dx = max(x, self.width - 1 - x)
		max_dy = max(y, self.height - 1 - y)
		if diag: covers_level = radius >= max(max_dx, max_dy)
		else: covers_level = radius >= 0 and radius * radius >= max_dx * max_dx + max_dy * max_dy

		if covers_level: yield from self.get_points_in_rect(0, 0, self.width - 1, self.height - 1); return

		rounded_radius = int(math.ceil(radius))
		offsets = get_points_in_ball_offsets(rounded_radius, diag)
		for dx, dy, dist in offsets:
			if dist > radius: continue
			cur_x = x + dx
			cur_y = y + dy
			if 0 <= cur_x < self.width and 0 <= cur_y < self.height:
				yield Point(cur_x, cur_y)

	def adjust_beam(self, points):

		for i in range(1, len(points)-1):
			pre = points[i-1]
			cur = points[i]
			nex = points[i+1]

			# Do not adjust points along straight line segments
			if pre.x == nex.x or pre.y == nex.y:
				continue

			# Do not adjust points outside of the map.
			if not self.is_point_in_bounds(cur):
				continue

			# No blocker?  ok cool
			#if self.tiles[cur.x][cur.y].can_see:
			#	continue
			if self.can_see(points[0].x, points[0].y, cur.x, cur.y):
				continue

			opts = self.get_points_in_rect(cur.x-1, cur.y-1, cur.x+1, cur.y+1)
			better_opt = None
			for opt in opts:
				if opt == cur:
					continue
				if not self.tiles[opt.x][opt.y].can_see:
					continue
				if distance(opt, nex) <= 1.5 and distance(opt, pre) <= 1.5:
					better_opt = opt
					break
			if better_opt:
				points[i] = better_opt

	# Returns all points on the line going through dest perpendicular to origin
	def get_perpendicular_line(self, origin, dest, length=99):

		results = set([dest])
		
		if origin == dest:
			return results

		# reverse the slope
		dy = dest.x - origin.x
		dx = dest.y - origin.y

		longer_len = max(abs(dy), abs(dx))
		if longer_len:
			dx /= longer_len
			dy /= -longer_len
		# Default to a flat line if origin = dest
		else:
			dx = 1
			dy = 0

		line_start = Point(round(dest.x + length * dx), round(dest.y + length * dy))
		line_end = Point(round(dest.x - length * dx), round(dest.y - length * dy))
		return [p for p in self.get_points_in_line(line_start, line_end, two_pass=False) if self.is_point_in_bounds(p)]
		
	def show_beam(self, start, end, dtype, minor=True, inclusive=False):
		points = self.get_points_in_line(start, end)
		if not inclusive: points = points[1:-1]
		for p in points: self.show_effect(p.x, p.y, dtype, minor=minor)

	def get_points_in_line(self, start, end, two_pass=True, find_clear=False, no_diag=False, prng=None, inclusive=True):
		if prng is None: prng = self.random
		steep = abs(end.y - start.y) > abs(end.x - start.x)

		# Orient the line so that it is going left to right with slope between 1 and -1
		if steep:
			start = Point(start.y, start.x)
			end = Point(end.y, end.x)

		reverse = False
		if start.x > end.x:
			reverse = True

			swap_temp = end
			end = start
			start = swap_temp

		dx = end.x - start.x
		dy = abs(end.y - start.y)
		
		if not find_clear:
			starting_err_vals = [dx / 2.0]
		else:
			starting_err_vals = list(range(dx+1))
			starting_err_vals = sorted(starting_err_vals, key=lambda v: abs(v - (dx / 2.0)))

		for starting_err_val in starting_err_vals:
			err = starting_err_val

			ystep = 1 if start.y < end.y else -1
			y = start.y

			result = []
			if isinstance(start.x, float) or isinstance(end.x, float):
				assert(False)

			clear = True
			for x in range(start.x, end.x + 1):
				if not steep:
					next_point = Point(x, y)
				else:
					next_point = Point(y, x)

				result.append(next_point)


				err = err - dy
				if (not reverse and err < 0) or (reverse and err <= 0):
					y += ystep
					err += dx

			if find_clear and not clear:
				continue

			if two_pass:
				for i in range(2):
					self.adjust_beam(result)

			if find_clear:
				valid = True
				for p in result:
					if not self.is_point_in_bounds(p):
						valid = False
					elif not self.tiles[p.x][p.y].can_see:
						valid = False
				if not valid:
					continue

			if reverse:
				result.reverse()

			if no_diag:
				insertions = []
				for i in range(len(result)-1):
					p = result[i]
					q = result[i+1]
					if p.x != q.x and p.y != q.y:
						if prng.random() > .5: insertions.append((Point(p.x, q.y), i))
						else: insertions.append((Point(q.x, p.y), i))

				insert_num = 0
				for new_point, index in insertions:
					result.insert(insert_num + index, new_point)
					insert_num += 1

			if not inclusive:
				if len(result) <= 2: return []
				result = result[1:-1]
			return result

		# If we are looking for a clear path but none are clear return the default
		assert(find_clear)
		return []
		#return self.get_points_in_line(start, end, find_clear=False)

	def get_extended_path(self, origin, terminus, two_pass=True, find_clear=False, no_diag=False, inclusive=True):
		dx = terminus.x - origin.x
		dy = terminus.y - origin.y
		if dx == 0 and dy == 0: return [origin] if inclusive else []
		t_candidates = []

		# Compute t to the map boundary along the ray from origin -> terminus.
		if dx > 0: t_candidates.append((self.width - 1 - origin.x) / dx)
		elif dx < 0: t_candidates.append((0 - origin.x) / dx)

		if dy > 0: t_candidates.append((self.height - 1 - origin.y) / dy)
		elif dy < 0: t_candidates.append((0 - origin.y) / dy)

		if not t_candidates: return [origin] if inclusive else []

		t = min(t_candidates)
		far_x = int(round(origin.x + dx * t))
		far_y = int(round(origin.y + dy * t))

		# Clamp for safety (float rounding can push 1 tile out)
		far_x = max(0, min(self.width - 1, far_x))
		far_y = max(0, min(self.height - 1, far_y))

		far = Point(far_x, far_y)

		path = self.get_points_in_line(origin, far, two_pass=two_pass, find_clear=find_clear, no_diag=no_diag, inclusive=inclusive)

		# Defensive filter (should already be in-bounds)
		return [p for p in path if self.is_point_in_bounds(p)]

	def can_add_cloud(self, p):
		t = self.tiles[p.x][p.y]
		if t.cloud: return False
		if not (t.can_walk or t.can_fly): return False
		return True

	def add_obj(self, obj, x, y):
		obj.x = x
		obj.y = y
		obj.level = self

		if not hasattr(obj, 'level_id'): obj.level_id = self.level_id

		if isinstance(obj, Unit):
			if obj.max_hp <= 1: obj.max_hp = 1
			if not obj.cur_hp: obj.cur_hp = obj.max_hp

			for i in range(-obj.radius, obj.radius+1):
				for j in range(-obj.radius, obj.radius+1):
					cur_x = x + i
					cur_y = y + j

					if not self.tiles[cur_x][cur_y].unit is None:
						print("Cannot add %s at %s, already has %s" % (obj.name, str((x, y)), self.tiles[cur_x][cur_y].unit.name))
						assert(self.tiles[cur_x][cur_y].unit is None)

					if obj.burrowing:
						if self.tiles[cur_x][cur_y].is_wall(): self.make_floor(cur_x, cur_y)

					self.tiles[cur_x][cur_y].unit = obj

			self.event_manager.raise_event(EventOnUnitPreAdded(obj), obj)

			# Hack- allow improper adding in monsters.py
			for spell in obj.spells: spell.caster = spell.owner = obj

			obj.set_default_resistances()

			for buff in list(obj.buffs):
				if getattr(buff, 'applied', False) and getattr(buff, 'owner', None) is obj: continue

				# Apply unapplied buffs- these can come from Content on new units
				could_apply = buff.apply(obj) != ABORT_BUFF_APPLY

				# Remove buffs which cannot be applied (happens with stun + clarity potentially)
				if not could_apply: obj.buffs.remove(buff)

			# Monster buffs are all passives
			if not obj.is_player_controlled:
				for b in obj.buffs:
					if b.buff_type > 0:
						b.buff_type = BUFF_TYPE_PASSIVE

			obj.invalidate_buff_caches()

			self.units.append(obj)
			self.event_manager.raise_event(EventOnUnitAdded(obj), obj)

			obj.ever_spawned = True

		elif isinstance(obj, Cloud):

			# kill any existing clouds
			cur_cloud = self.tiles[x][y].cloud 
			if cur_cloud is not None:
				if cur_cloud.can_be_replaced_by(obj): cur_cloud.kill()
				else: return

			self.tiles[x][y].cloud = obj
			self.clouds.append(obj)

		elif isinstance(obj, Prop): self.add_prop(obj, x, y)

		else: assert(False) # Unknown obj type

	def remove_obj(self, obj):
		if isinstance(obj, Unit):

			# Unapply to unsubscribe
			for buff in list(obj.buffs):
				if buff.applied: buff.unapply()

			obj.clear_runtime_anims()

			radius = obj.radius if hasattr(obj, 'radius') else 0
			
			for i in range(-radius, radius+1):
				for j in range(-radius, radius+1):
					cur_x = obj.x + i
					cur_y = obj.y + j
					
					assert(self.tiles[cur_x][cur_y].unit == obj)
					self.tiles[cur_x][cur_y].unit = None

			assert(obj in self.units)
			self.units.remove(obj)

		if isinstance(obj, Cloud):
			assert(self.tiles[obj.x][obj.y].cloud == obj)
			self.tiles[obj.x][obj.y].cloud = None
			self.clouds.remove(obj)

		if isinstance(obj, Prop):
			self.remove_prop(obj)

		obj.removed = True

	def add_prop(self, prop, x, y):
		prop.x = x
		prop.y = y
		prop.level = self
		self.tiles[x][y].prop = prop
		self.props.append(prop)

	def add_portal(self, portal, x, y, locked=True, flash=True):
		self.add_prop(portal, x, y)
		if flash: self.show_effect(x, y, Tags.Translocation)
		if not locked: portal.unlock()
		return portal

	def remove_prop(self, prop):
		if prop in self.props: self.props.remove(prop) # occasionally gets mismatched, shouldn't happen but does
		else: print("remove_prop desync")
		tile = self.tiles[prop.x][prop.y]
		if tile.prop is prop: tile.prop = None
		elif tile.prop: print("remove_prop tile mismatch")

	def portal_mercy(self):
		if self.level_no == LAST_LEVEL: return
		if any(isinstance(prop, Portal) for prop in self.props): return
		tiles = [tile for tile in self.get_tiles_in_ball(self.player_unit.x, self.player_unit.y, 1.5)]
		for tile in tiles: self.make_floor(tile.x, tile.y)
		exit_loc = self.random.choice(tiles)
		self.add_portal(Portal(self.gen_params.make_child_generator()), exit_loc.x, exit_loc.y, locked=False)

	def prop_mercy(self):
		tiles = self.tiles
		for p in self.props:
			if not tiles[p.x][p.y].is_floor():
				self.make_floor(p.x, p.y)

	def spawn_player(self, player_unit):
		self.player_unit = player_unit
		self.add_obj(player_unit, self.start_pos.x, self.start_pos.y)
		prop = self.tiles[self.start_pos.x][self.start_pos.y].prop
		if prop: prop.on_player_enter(player_unit)

	def summon(self, owner, unit, target=None, radius=5, team=None, sort_dist=True):
		if not target: target = owner
			
		p = self.get_summon_point(target.x, target.y, radius_limit=radius, flying=unit.flying, sort_dist=sort_dist, unit=unit)
		if team is None: team = owner.team
		unit.team = team

		if p:
			self.add_obj(unit, p.x, p.y)
			self.show_effect(p.x, p.y, Tags.Conjuration)
			return unit
		else: return False

	def deal_redirected_damage(self, redirect_source, x, y, amount, damage_type, source, redirect_chain):
		if redirect_chain is None: redirect_chain = []
		redirect_chain.append(redirect_source)
		return self.deal_damage(x, y, amount, damage_type, source, redirect_chain=redirect_chain)

	def deal_damage(self, x, y, amount, damage_type, source, flash=True, redirect_chain=None):

		if amount == 0 and damage_type is Tags.Heal: return 0
		show_heal_effect = flash and amount < 0

		# Auto make effects if none were already made
		if flash and not show_heal_effect and self.reserve_effect(x, y, damage_type.color):
			effect = Effect(x, y, damage_type.color, Color(0, 0, 0), 12)
			if amount == 0: effect.minor = True
			self.apply_effect_pressure(effect)
			self.effects.append(effect)
		if amount == 0: return 0

		tile = self.tiles[x][y]
		cloud = tile.cloud
		if cloud and amount > 0: cloud.on_damage(damage_type)

		unit = tile.unit # just grab the unit directly, we already have the tile
		if not unit: return 0
		if not unit.is_alive(): return 0

		damage_redirects = unit.damage_redirects
		if damage_redirects:
			for redirect_source, redirect_fn in damage_redirects:
				if redirect_chain is not None and redirect_source in redirect_chain: continue
				result = redirect_fn(amount, damage_type, source, redirect_chain)
				if result is not None: return result

		if amount > 0:
			damage_instances = self.damage_instances
			damage_state = (unit, unit.cur_hp, unit.shields)
			damage_instance_count = damage_instances.get(damage_state, 0)
			if damage_instance_count >= DAMAGE_INSTANCE_CAP: return 0
			damage_instance_count += 1
			damage_instances[damage_state] = damage_instance_count
			if damage_instance_count == DAMAGE_INSTANCE_CAP:
				unit_str = color_entity(log_name(unit), log_color(unit))
				self.log((text.DMG_CAP, {"unit": unit_str}))

		# Track raw incoming damage before resist and shield processing
		orig_amount = amount

		# Factor in shields and resistances before raising the pre damage event
		resist = unit.resists.get(damage_type, 0)

		# Cap effective resists at 100- shenanigans ensue if we do not
		resist = min(resist, 100)
		multiplier = (100 - resist) / 100.0
		amount = int(math.ceil(amount * multiplier))

		if self.event_manager.has_handlers(EventOnPreDamaged, unit):
			pre_damage_event = EventOnPreDamaged(unit, orig_amount, amount, damage_type, source)
			self.event_manager.raise_event(pre_damage_event, unit)

		if amount > 0 and unit.shields > 0:
			unit_str = color_entity(log_name(unit), log_color(unit))
			source_str = source.name
			dtype_label = tag_label(damage_type)
			dtype_key = tag_key(damage_type)

			unit.shields = unit.shields - 1
			log_txt = (text.DMG_BLOCKED, {"unit": unit_str, "amount": amount, "dtype_label": dtype_label, "dtype_key": dtype_key, "source": source_str})
			self.log(log_txt)
			self.show_effect(unit.x, unit.y, Tags.Shield_Expire)
			evt = EventOnShieldRemoved(unit, source)
			self.event_manager.raise_event(evt, entity=unit)
			return 0

		# Cap damage to current hp and active damage floors, cap healing to missing hp
		if amount > 0:
			amount = min(amount, unit.cur_hp)
			damage_floors = unit.damage_floors
			if damage_floors:
				amount = min(amount, max(0, unit.cur_hp - damage_floors[-1][1]))
				if amount <= 0: return 0
		elif amount < 0: amount = max(amount, unit.cur_hp - unit.max_hp)

		if amount:
			unit_str = color_entity(log_name(unit), log_color(unit))
			source_str = source.name
			owner_str = color_entity(log_name(source.owner), log_color(source.owner)) if source.owner else source.name
			is_temp_buff = isinstance(source, Buff) and source.buff_type in (BUFF_TYPE_BLESS, BUFF_TYPE_CURSE)

			if amount > 0:
				dtype_label = tag_label(damage_type)
				dtype_key = tag_key(damage_type)

		if show_heal_effect and amount < 0 and self.reserve_effect(x, y, damage_type.color):
			effect = Effect(x, y, damage_type.color, Color(0, 0, 0), 12)
			self.apply_effect_pressure(effect)
			self.effects.append(effect)

		unit.cur_hp = unit.cur_hp - amount

		# Logging
		if amount > 0:
			if source.owner and not is_temp_buff: self.log((text.DMG_DEALS, {"owner": owner_str, "amount": amount, "dtype_label": dtype_label, "dtype_key": dtype_key, "unit": unit_str, "source": source_str}))
			else: self.log((text.DMG_TAKES, {"unit": unit_str, "amount": amount, "dtype_label": dtype_label, "dtype_key": dtype_key, "source": source_str}))
		elif amount < 0:
			if not is_temp_buff: self.log((text.HEAL_BY, {"owner": owner_str, "unit": unit_str, "amount": -amount, "source": source_str}))
			else: self.log((text.HEAL_FROM, {"unit": unit_str, "amount": -amount, "source": source_str}))

		# Processing
		if amount < 0:
			evt = EventOnHealed(unit, amount, source)
			self.event_manager.raise_event(evt, unit)

		elif amount > 0:
			# Record damage sources when a player unit exists (aka not in unittests)
			if self.player_unit:
				# Enemy
				if are_hostile(unit, self.player_unit):
					key = source_str
					if source.owner and source.owner.source and not (isinstance(source, Buff) and source.buff_type == BUFF_TYPE_CURSE):
						key = source.owner.name

					self.damage_dealt_sources[key] += amount
					self.turn_summary.damage_dealt[key] += amount
				# Ally/Self
				else:
					if isinstance(source, Buff) and source.buff_type == BUFF_TYPE_CURSE:
						key = source_str
					elif source.owner:
						key = source.owner.name
					else:
						key = source_str
					
					# Self
					if unit == self.player_unit:
						self.damage_taken_sources[key] += amount
						self.turn_summary.self_damage_taken[key] += amount
					# Ally
					else:
						self.turn_summary.ally_damage_taken[key] += amount
	

			damage_event = EventOnDamaged(unit, amount, damage_type, source)
			self.event_manager.raise_event(damage_event, unit)
		
			if (unit.cur_hp <= 0):
				unit.kill(damage_event = damage_event)
				if unit.killed:
					if source.owner: self.log((text.KILLED_BY_UNIT, {"unit": unit_str, "owner": owner_str, "source": source_str}))
					else: self.log((text.KILLED_BY_ENV, {"unit": unit_str, "source": source_str}))
				
		# set amount to 0 if there is no unit- ie, if an empty tile or dead unit was hit
		else:
			amount = 0

		if (unit.cur_hp > unit.max_hp):
			unit.cur_hp = unit.max_hp

		return amount

	def reserve_effect(self, x, y, color):
		effect_index = x * self.height + y
		if self.effect_color_generations[effect_index] != self.effect_color_generation:
			self.effect_color_generations[effect_index] = self.effect_color_generation
			self.effect_color_counts[effect_index] = 0
		count = self.effect_color_counts[effect_index]
		if count >= EFFECT_COLORS_PER_TILE: return False
		colors = self.effect_color_slots[effect_index]
		if count > 0 and color == colors[0]: return False
		if count > 1 and color == colors[1]: return False
		colors[count] = color
		self.effect_color_counts[effect_index] = count + 1
		return True

	def flash(self, x, y, color):
		if not self.reserve_effect(x, y, color): return
		effect = Effect(x, y, color, Color(0, 0, 0), 12)
		self.apply_effect_pressure(effect)
		self.effects.append(effect)

	def show_effect(self, x, y, effect_tag, fill_color=Color(0, 0, 0), minor=False, speed=1):
		if not self.reserve_effect(x, y, effect_tag.color): return
		effect = Effect(x, y, effect_tag.color, fill_color, 12)
		effect.minor = minor
		effect.speed = speed
		self.apply_effect_pressure(effect)
		self.effects.append(effect)

	def show_path_effect(self, start, finish, effect_tag, fill_color=Color(0, 0, 0), minor=False, straight=False, inclusive=True, pause_frames=0):
		path = self.find_path(start, finish, flying_path_probe, pythonize=True, cosmetic=True)
		if straight or not path: path = self.get_points_in_line(start, finish)
		if not inclusive: path = path[0:-1]

		def _iter():
			i = 0
			for p in path:
				if isinstance(effect_tag, list): i += 1; cur_tag = effect_tag[i % len(effect_tag)]
				else: cur_tag = effect_tag
				self.show_effect(p.x, p.y, cur_tag, fill_color, minor)
				for _ in range(pause_frames): yield  # one frame per pause

		gen = _iter()
		if pause_frames > 0: return gen  # caller: yield from level.show_path_effect(..., pause_frames=2)
		for _ in gen: pass  # immediate, current behavior

	def apply_effect_pressure(self, effect):
		# Shorten fade/speed when the queue is bloated
		count = len(self.effects)
		scale = None
		if count >= EFFECT_PRESSURE_HIGH:
			scale = 0.5
		elif count >= EFFECT_PRESSURE_MED:
			scale = 0.75
		if not scale:
			return
		new_frames = max(4, int(effect.frames * scale))
		if new_frames < effect.frames:
			effect.frames = new_frames
			effect.frames_left = min(effect.frames_left, new_frames)
		effect.speed = max(0.25, effect.speed * scale)

	def leap_effect(self, x, y, color, unit):
		if not self.reserve_effect(x, y, color): return
		effect = Effect(x, y, Tags.Leap.color, color, 12)
		effect.leap_unit = unit
		self.apply_effect_pressure(effect)
		self.effects.append(effect)

	def projectile_effect(self, x, y, proj_name, proj_origin, proj_dest, proj_color=None, proj_duration=7):
		if not proj_color: proj_color = Color(0, 0, 0)
		if not self.reserve_effect(x, y, proj_color): return
		effect = Effect(x, y, Tags.Arrow.color, proj_color, proj_duration)
		effect.proj_name = proj_name
		effect.proj_origin = proj_origin
		effect.proj_dest = proj_dest
		self.apply_effect_pressure(effect)
		self.effects.append(effect)

	def queue_spell(self, spell):
		assert(hasattr(spell, "__next__"))
		self.active_spells.append(spell)

	def run_with_cast_context(self, gen, context):
		while True:
			prev_context = self.current_cast_context
			self.current_cast_context = context
			try: value = next(gen)
			except StopIteration: return
			finally: self.current_cast_context = prev_context
			yield value

	def are_hostile(self, unit1, unit2):
		return are_hostile(unit1, unit2)

	def get_units_in_ball(self, center, radius, diag=False):
		cx, cy = center.x, center.y
		center = Point(cx, cy)
		hits = []
		for u in self.units:
			if abs(u.x - cx) > radius + u.radius or abs(u.y - cy) > radius + u.radius: continue # quick filter definitely too far away units
			if self.unit_distance(center, u, diag=diag) <= radius: hits.append(u)
		return hits

	def get_points_in_los(self, point):
		for i in range(0, len(self.tiles)):
			for j in range(0, len(self.tiles[i])):
				if self.can_see(point.x, point.y, i, j):
					yield Point(i, j)

	def has_enemy_units(self):
		return any(u.team != TEAM_PLAYER for u in self.units)

	def has_hostile_units(self):
		if not self.player_unit: return any(u.team != TEAM_PLAYER for u in self.units)
		return any(are_hostile(self.player_unit, u) for u in self.units)

	def dismiss_units_and_clouds(self):
		if not self.player_unit: return

		for cloud in list(self.clouds):
			if not cloud.is_alive: continue
			self.show_effect(cloud.x, cloud.y, Tags.Translocation, minor=True)
			cloud.kill()

		for unit in list(self.units):
			if unit.is_player_controlled: continue
			self.show_effect(unit.x, unit.y, Tags.Translocation)
			unit.kill(trigger_death_event=False)

	def try_dismiss_units(self):
		if not self.player_unit: return
		if not self.player_unit.game.level_cleared: return
		for unit in list(self.units):
			if unit.is_player_controlled: continue
			if unit.team == TEAM_PLAYER and self.random.random() >= .2: continue
			self.show_effect(unit.x, unit.y, Tags.Translocation)
			unit.kill(trigger_death_event=False)

	def make_wall(self, x, y):
		self.map_dirty = True
		tile = self.tiles[x][y]
		terrain_changed = not tile.is_wall()
		if tile.can_see: self.ai_pathing_cache.on_terrain_change()

		tile.can_walk = False
		tile.can_see = False
		tile.can_fly = False
		tile.is_chasm = False
		tile.name = "Wall"
		tile.description = "Solid rock"

		self.clear_tile_sprite(tile, terrain_changed)

		if self.tcod_map:
			self.tcod_map.transparent[tile.y, tile.x] = tile.can_see
			self.tcod_map.walkable[tile.y, tile.x] = tile.can_walk

	def make_floor(self, x, y):
		self.map_dirty = True
		tile = self.tiles[x][y]
		terrain_changed = not tile.is_floor()
		if not tile.can_walk: self.ai_pathing_cache.on_terrain_change()

		tile.can_walk = True
		tile.can_see = True
		tile.can_fly = True
		tile.is_chasm = False
		tile.name = "Floor"
		tile.description = "A rough rocky floor"

		self.clear_tile_sprite(tile, terrain_changed)

		if self.tcod_map:
			self.tcod_map.transparent[tile.y, tile.x] = tile.can_see
			self.tcod_map.walkable[tile.y, tile.x] = tile.can_walk

	def make_chasm(self, x, y):
		self.map_dirty = True
		tile = self.tiles[x][y]
		terrain_changed = not tile.is_chasm
		if not tile.is_chasm: self.ai_pathing_cache.on_terrain_change()

		tile.can_walk = False
		tile.can_see = True
		tile.can_fly = True
		tile.is_chasm = True
		tile.name = "The Abyss"
		tile.description = "Look closely and you might see the glimmer of distant worlds"

		self.clear_tile_sprite(tile, terrain_changed)

		if self.tcod_map:
			self.tcod_map.transparent[tile.y, tile.x] = tile.can_see
			self.tcod_map.walkable[tile.y, tile.x] = tile.can_walk

	def clear_tile_sprite(self, tile, terrain_changed):
		tile.sprites = None
		if terrain_changed: self.terrain_generation += 1

	def make_map(self):
		self.tcod_map = tcod.map.Map(len(self.tiles), len(self.tiles[0]))
		for tile in self.iter_tiles():
			self.tcod_map.transparent[tile.y, tile.x] = tile.can_see
			self.tcod_map.walkable[tile.y, tile.x] = tile.can_walk

	def get_fov_map(self, x, y, light_walls=False):
		if not hasattr(self, 'tcod_map') or not self.tcod_map: self.make_map()
		if self.map_dirty:
			self.fov_cache.clear()
			self.map_dirty = False
		key = (x, y, light_walls)
		cached = self.fov_cache.get(key)
		if cached is not None: return cached
		self.tcod_map.compute_fov(x, y, radius=40, light_walls=light_walls, algorithm=self.fov)
		fov = self.tcod_map.fov.copy()
		self.fov_cache[key] = fov
		return fov

	def can_see(self, x1, y1, x2, y2, light_walls=False):
		if not light_walls and (not self.tiles[x1][y1].can_see or not self.tiles[x2][y2].can_see): return False
		fov = self.get_fov_map(x1, y1, light_walls) # get the fov for p1
		if fov[y2, x2]: return True # can it see p2?
		fov = self.get_fov_map(x2, y2, light_walls) # permissive reflection
		return fov[y1, x1] # can p2 see p1?

	def can_see_unit(self, observer, u2):
		# check if you can see any portion of a unit from a given observation point
		for pt in u2.iter_occupied_points():
			if self.can_see(observer.x, observer.y, pt.x, pt.y):
				return True
		return False

	def get_units_in_los(self, origin, light_walls=False):
		origin_x = origin.x
		origin_y = origin.y
		get_fov_map = self.get_fov_map
		fov_origin = get_fov_map(origin_x, origin_y, light_walls)
		seen = set()
		missed = []

		for u in self.units:
			if not u.radius:
				if fov_origin[u.y, u.x]: seen.add(u)
				else: missed.append(u)
				continue

			for p in u.iter_occupied_points():
				if fov_origin[p.y, p.x]:
					seen.add(u)
					break
			else:
				missed.append(u)

		# Symmetry check for units not seen from the origin
		for u in missed:
			if not u.radius:
				if get_fov_map(u.x, u.y, light_walls)[origin_y, origin_x]: seen.add(u)
				continue

			for p in u.iter_occupied_points():
				if get_fov_map(p.x, p.y, light_walls)[origin_y, origin_x]:
					seen.add(u)
					break

		return list(seen)

	def set_tile_style(self, tile, tileset, chasm_type):
		tileset_changed = tile.tileset != tileset
		chasm_type_changed = tile.chasm_type != chasm_type
		if not tileset_changed and not chasm_type_changed: return

		terrain_changed = chasm_type_changed if tile.is_chasm else tileset_changed
		tile.tileset = tileset
		tile.chasm_type = chasm_type
		self.clear_tile_sprite(tile, terrain_changed)

	def set_tileset(self, tileset, chasm_type):
		for tile in self.iter_tiles():
			self.set_tile_style(tile, tileset, chasm_type)

	def set_group_tileset(self, points, tileset, chasm_type):
		for p in points:
			tile = self.tiles[p.x][p.y]
			self.set_tile_style(tile, tileset, chasm_type)


class TurnSummary():

	def __init__(self):
		self.ally_kill_counts = defaultdict(lambda: 0)
		self.enemy_kill_counts = defaultdict(lambda: 0)
		self.ally_damage_taken = defaultdict(lambda: 0)
		self.damage_dealt = defaultdict(lambda: 0)
		self.self_damage_taken = defaultdict(lambda: 0)

	def clear(self):
		self.ally_kill_counts.clear()
		self.enemy_kill_counts.clear()
		self.ally_damage_taken.clear()
		self.damage_dealt.clear()
		self.self_damage_taken.clear()

class NameLookupCollection():
	def __init__(self, elements):
		self.elements = elements
		self.lookup = {}
		for element in elements:
			assert(element.name not in self.lookup)
			self.lookup[element.name] = element

	def __getattr__(self, attr_name):
		if attr_name.startswith('__') and attr_name.endswith('__'):
			raise AttributeError(attr_name)
		if attr_name not in self.lookup:
			raise AttributeError(attr_name)
		return self.lookup[attr_name]

	def __iter__(self):
		return self.elements.__iter__()

	def add(self, element):
		assert (element.name not in self.lookup)
		self.elements.append(element)
		self.lookup[element.name] = element

class Tag():
	def __init__(self, name, color, asset=None):
		self.name = name
		self.color = color
		self.asset = asset

	def __hash__(self):
		return hash((self.name, self.color))

	def __eq__(self, other):
		if not isinstance(other, Tag): return False
		return self.color == other.color

Tags = NameLookupCollection([
	Tag("Physical", Color(230, 210, 210)),
	Tag("Fire", Color(229, 28, 35)),
	Tag("Lightning", Color(255, 238, 88)),
	Tag("Ice", Color(79, 195, 247)),
	Tag("Nature", Color(114, 213, 114)),
	Tag("Arcane", Color(240, 98, 146)),
	Tag("Dark", Color(156, 39, 176)),
	Tag("Holy", Color(246, 254, 141)),
	Tag("Sorcery", Color(233, 30, 99)),
	Tag("Conjuration", Color(243, 108, 96)),
	Tag("Enchantment",  Color(49, 164, 144)),
	Tag("Word", Color(255, 213, 79)),
	Tag("Orb", Color(248, 168, 183)),
	Tag("Dragon", Color(176, 18, 10)),
	Tag("Translocation", Color(186, 104, 200)),
	Tag("Undead", Color(97, 97, 97)),
	Tag("Elemental", Color(255, 235, 59)),
	Tag("Heal", Color(66, 189, 66)),
	Tag("Acid", Color(66, 189, 65)),
	Tag("Demon", Color(240, 70, 70)),
	Tag("Spider", Color(10, 126, 7)),
	Tag("Poison", Color(66, 189, 65)),
	Tag("Living", Color(174, 213, 129)),
	Tag("Construct", Color(188, 170, 164)),
	Tag("Metallic", Color(144, 156, 186)),
	Tag("Eye", Color(255, 255, 255)),
	Tag("Glass", Color(43, 175, 43)),
	Tag("Chaos", Color(255, 171, 77)),
	Tag("Blood", Color(134, 13, 7)),
	Tag("Tongue", Color(236, 94, 149)),
	Tag("Slime", Color(206, 220, 56)),
	Tag("Ritual", Color(20, 73, 154)),

	# Getting hacky here
	Tag("Shield", Color(77, 253, 252)),

	# Super hacky now
	Tag("Buff_Apply", Color(0, 0, 1)),
	Tag("Debuff_Apply", Color(0, 0, 2)),
	Tag("Shield_Apply", Color(0, 0, 3)),
	Tag("Shield_Expire", Color(0, 0, 4)),
	Tag("Sound_Effect", Color(0, 0, 5)),
	Tag("Leap", Color(0, 0, 6)),

	Tag("Arrow", Color(0, 0, 7)),	
	Tag("Petrification", Color(0, 0, 8)),
	Tag("Glassification", Color(0, 0, 9)),

	Tag("Immolate", Color(0, 0, 10)),
	Tag("Thunderstrike", Color(0, 0, 11)),
	Tag("ArmageddonBlade", Color(0, 0, 12)),
	Tag("Fang", Color(0, 0, 13)),
	Tag("GalvanicBlade", Color(0, 0, 14)),
	Tag("Music", Color(0, 0, 15)),
	Tag("Water", Color(0, 0, 16)),
	Tag("AssassinBlade", Color(0, 0, 17)),
	Tag("FlyingDagger", Color(0, 0, 18)),

	Tag("Consumable", Color(254, 254, 254)),
	Tag("Any", Color(200, 200, 200))
])

damage_tags = [
	Tags.Physical,
	Tags.Fire,
	Tags.Lightning,
	Tags.Dark,
	Tags.Poison,
	Tags.Holy,
	Tags.Arcane,
	Tags.Ice
]

attr_colors = {
	'damage': COLOR_DAMAGE,
	'range': COLOR_RANGE,
	'minion_health': Tags.Conjuration.color,
	'minion_damage': Tags.Conjuration.color,
	'minion_duration': Tags.Conjuration.color,
	'minion_range': COLOR_RANGE,
	'duration': Tags.Enchantment.color,
	'max_charges': COLOR_CHARGES,
	'radius': Tags.Sorcery.color,
	'num_summons': COLOR_CHARGES,
	'num_targets': COLOR_CHARGES,
	'shields': COLOR_SHIELD,
	'shot_cooldown': Color(255, 204, 153),
	'strikechance': Tags.Lightning.color,
	'cooldown': Color(255, 204, 153),
	'heal' : Tags.Heal.color,
	'max_channel' : Color(153, 51, 102),
	'quick_cast' : Color(255, 255, 255)
}

class Raw(str): pass
def tag_key(tag): return Raw(tag.name.lower()) # cast attribute to lowercase and make it an untranslateable string (for formatting purposes)
def tag_label(tag): return tag.name
def formatted_tag(tag): return (text.COLORED_TAG, {'tag_label':tag_label(tag), 'tag_key': tag_key(tag)})
def log_name(u): return u.name
def log_color(u): return Raw('wizard' if u.is_player_controlled else ('enemy' if (u.team == TEAM_ENEMY or u.has_buff(BerserkBuff)) else 'ally'))
def color_entity(name_key, color_raw): return ("[{name}:{color}]", {"name": name_key, "color": color_raw})

def attr_key(attr): return Raw(str(attr).lower()) # cast attribute to lowercase and make it an untranslateable string (for formatting purposes)
def attr_label(attr): return format_attr(attr) # strip out underscores

def resolve_text(value, fmt=None):

	def resolve_fmt(d):
		if not d: return {}
		out = {}
		for k, v in d.items():
			if isinstance(v, Raw): out[k] = v # not to be translated, for string formatters like attr/tag names
			elif isinstance(v, (list, tuple)): out[k] = resolve_text(v)
			elif isinstance(v, str): out[k] = loc.T(v)
			else: out[k] = v
		return out

	if isinstance(value, Raw): return str(value)
	if isinstance(value, tuple): # one message and its format (if it has one)
		msg, local_fmt = value
		merged = {**(fmt or {}), **local_fmt}  # local overrides
		return loc.T(msg, **resolve_fmt(merged))

	if isinstance(value, list): return "".join(resolve_text(v, fmt=fmt) for v in value)
	if isinstance(value, str): return loc.T(value, **resolve_fmt(fmt or {})) if fmt else loc.T(value)
	else: return str(value)
