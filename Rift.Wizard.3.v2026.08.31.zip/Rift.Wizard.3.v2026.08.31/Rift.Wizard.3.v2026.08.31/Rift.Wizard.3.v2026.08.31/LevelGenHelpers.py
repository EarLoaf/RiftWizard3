# Various methods for randomly modifying level tile
from Level import *

import logging
level_logger = logging.getLogger("Level")
level_logger.setLevel(logging.DEBUG)
level_logger.propagate = False

def expand_floor(levelgen):

	level = levelgen.level

	floor_tiles = [t for t in level.iter_tiles() if t.can_walk]
	blocked_tiles = [t for t in level.iter_tiles() if not t.can_walk]

	invert = len(floor_tiles) > len(blocked_tiles) 

	chasm = False
	if invert:
		chasm = levelgen.random.choice([True, False])


	chance = levelgen.random.choice([.05, .1, .2, .3])

	level_logger.debug("Floor Exp: %.1f" % chance)

	tiles = blocked_tiles if invert else floor_tiles
	for t in tiles:
		for p in level.get_points_in_ball(t.x, t.y, 1, diag=True):
			if levelgen.random.random() < chance:
				if invert:
					level.make_wall(p.x, p.y)
				else:
					if chasm:
						level.make_chasm(p.x, p.y)
					else:
						level.make_floor(p.x, p.y)

# Randomly convert some number of walls to chasms
def walls_to_chasms(levelgen):
	level = levelgen.level
	num_chasms = levelgen.random.randint(1, 20)
	level_logger.debug("Wallchasms: %d" % num_chasms)

	for i in range(num_chasms):
		choices = [t for t in level.iter_tiles() if not t.can_see]
		if not choices: break

		start_point = levelgen.random.choice(choices)
		choices = [start_point]
		for i in range(levelgen.random.randint(10, 50)):

			if not choices: break
			current = levelgen.random.choice(choices)
			choices.remove(current)
			level.make_chasm(current.x, current.y)

			for p in level.get_points_in_ball(current.x, current.y, 1):
				if not level.tiles[p.x][p.y].can_see:
					choices.append(p)

# Turns all tiles surrounded by floors into chasms
def chasmify(levelgen):
	level = levelgen.level
	level_logger.debug("Chasmify")
	# A tile can be a chasm if all adjacent tiles are pathable without this tile
	chasms = []
	for i in range(1, levelgen.level.size - 1):
		for j in range(1, levelgen.level.size - 1):
			neighbors = level.get_points_in_rect(i-1, j-1, i+1, j+1)
			if all(level.can_walk(p.x, p.y) for p in neighbors):
				chasms.append(Point(i, j))

	for p in chasms:
		level.make_chasm(p.x, p.y)

# Turns all tiles surrounded by visible tiles into walls
def wallify(levelgen):
	level = levelgen.level
	level_logger.debug("Wallify")
	# A tile can be a chasm if all adjacent tiles are pathable without this tile
	chasms = []
	for i in range(1, levelgen.level.size - 1):
		for j in range(1, levelgen.level.size - 1):
			neighbors = level.get_points_in_rect(i-1, j-1, i+1, j+1)
			if all(level.tiles[p.x][p.y].can_see for p in neighbors):
				chasms.append(Point(i, j))

	for p in chasms:
		level.make_wall(p.x, p.y)

def grid(levelgen, stagger=None, chance=None):
	level = levelgen.level

	if not stagger: stagger = levelgen.random.choice([2, 3, 4, 7])
	if not chance: chance = levelgen.random.random()

	floor_tiles = [t for t in level.iter_tiles() if t.can_walk]
	blocked_tiles = [t for t in level.iter_tiles() if not t.can_walk]

	invert = len(floor_tiles) > len(blocked_tiles) 

	chasm = False
	if invert: chasm = levelgen.random.choice([True, False])

	modestr = 'floor' if not invert else 'chasm' if chasm else 'wall'
	level_logger.debug("Grid: %d, %.2f, (%s)" % (stagger, chance, modestr))

	for i in range(levelgen.level.width):
		for j in range(levelgen.level.height):
			p = Point(i, j)
			if levelgen.random.random() > chance: continue
			if (i % stagger) == (j % stagger) == 0:
				if invert: level.make_wall(p.x, p.y)
				else:
					if chasm: level.make_chasm(p.x, p.y)
					else: level.make_floor(p.x, p.y)


def is_in_rect(i, j, border_size, level):
	if i < border_size: return False
	if level.width - i - 1 < border_size: return False
	if j < border_size: return False
	if level.height - j - 1 < border_size: return False
	return True

def is_in_circle(i, j, border_size, level):
	center = Point(level.width // 2 - .5, level.width // 2 - .5)
	radius = level.width // 2 - border_size
	return distance(Point(i, j), center) < radius

def is_in_diamond(i, j, border_size, level):
	halfsize = level.width // 2
	dist = abs(i - halfsize + .5) + abs(j - halfsize + .5)
	radius = halfsize - border_size + 4
	return dist < radius

def run_in_region(levelgen, mutator, margin=None):
	level = levelgen.level
	if margin is None:
		margin = levelgen.random.randint(2, 4)
	x0 = max(0, margin)
	y0 = max(0, margin)
	x1 = max(x0 + 1, levelgen.level.size - margin)
	y1 = max(y0 + 1, levelgen.level.size - margin)

	test_level = Level(levelgen.level.size, levelgen.level.size)
	for x in range(levelgen.level.size):
		for y in range(levelgen.level.size):
			tile = level.tiles[x][y]
			if tile.is_floor(): test_level.make_floor(x, y)
			elif tile.is_chasm: test_level.make_chasm(x, y)
			else: test_level.make_wall(x, y)

	original_level = levelgen.level
	levelgen.level = test_level
	try:
		mutator(levelgen)
	finally:
		levelgen.level = original_level

	for x in range(x0, x1):
		for y in range(y0, y1):
			new_tile = test_level.tiles[x][y]
			if new_tile.is_floor(): level.make_floor(x, y)
			elif new_tile.is_chasm: level.make_chasm(x, y)
			else: level.make_wall(x, y)

def border(levelgen, force_chasm=False, force_wall=False, size=None, force_rect=False):
	level = levelgen.level
	if size is None: size = levelgen.random.randint(1, 4)
	chasm = levelgen.random.choice([True, False, False, False])
	if force_chasm: chasm = True
	if force_wall: chasm = False
	test = levelgen.random.choice([is_in_rect, is_in_circle, is_in_diamond])
	if force_rect: test = is_in_rect
	level_logger.debug("Border: %d (%s, %s)" % (size, 'c' if chasm else 'w', test.__name__))

	for i in range(levelgen.level.width):
		for j in range(levelgen.level.height):
			do = not test(i, j, size, levelgen.level)
			if do:
				if not chasm: level.make_wall(i, j)
				else: level.make_chasm(i, j)


def white_noise(levelgen):
	level = levelgen.level
	chance = levelgen.random.choice([.05, .08, .1, .12, .25])

	floor_tiles = [t for t in level.iter_tiles() if t.can_walk]
	blocked_tiles = [t for t in level.iter_tiles() if not t.can_walk]

	if len(floor_tiles) > len(blocked_tiles):
		if levelgen.random.choice([True, False]): mode = 'chasm'
		else: mode = 'wall'
	else: mode = 'floor'

	level_logger.debug("White Noise: %.2f (%s)" % (chance, mode))

	for t in level.iter_tiles():
		if levelgen.random.random() < chance:
			if mode == 'wall': level.make_wall(t.x, t.y)
			elif mode == 'chasm': level.make_chasm(t.x, t.y)
			elif mode == 'floor': level.make_floor(t.x, t.y)
			else: assert(False)

def squares(levelgen):
	# TODO-
	# Borders not always walls

	level = levelgen.level
	max_size = levelgen.random.randint(3, 7)
	min_size = max_size // 2
	num = levelgen.random.randint(2, 6)
	floor_tiles = [t for t in level.iter_tiles() if t.can_walk]
	blocked_tiles = [t for t in level.iter_tiles() if not t.can_walk]

	if len(floor_tiles) > len(blocked_tiles):
		if levelgen.random.choice([True, False]): mode = 'chasm'
		else: mode = 'wall'
	else: mode = 'floor'

	level_logger.debug("Squares: s%d n%d (%s)" % (max_size, num, mode))

	border = True
	for i in range(num):

		x = levelgen.random.randint(0, levelgen.level.size - max_size)
		y = levelgen.random.randint(0, levelgen.level.size - max_size)
		w = levelgen.random.randint(min_size, max_size)
		h = levelgen.random.randint(min_size, max_size)
		for i in range(w):
			for j in range(h):
				cur_x = x + i
				cur_y = y + j
				if mode == 'wall': level.make_wall(cur_x, cur_y)
				elif mode == 'chasm': level.make_chasm(cur_x, cur_y)
				elif mode == 'floor': level.make_floor(cur_x, cur_y)
				else: assert(False)

		if border:
			for i in range(w):
				level.make_wall(x + i, y)
				level.make_wall(x + i, y + h - 1)
			for j in range(h):
				level.make_wall(x, y + j)
				level.make_wall(x + w - 1,  y + j)


def bisymmetry(levelgen):
	level = levelgen.level

	# Which axis does the symmetry come from
	axis = levelgen.random.choice(['x', 'y'])

	ideal_floors = levelgen.level.size*levelgen.level.size // 4

	mirror = levelgen.random.choice([True, False])

	level_logger.debug("Bisymmetry (%s, %s)" % (axis, 'mirror' if mirror else 'flip'))

	def get_src(i, j):
		if axis == 'y': return Point(i, j)
		elif axis == 'x': return Point(j, i)

	# Returns the tile we will be copying x, y to
	def get_tgt(x, y):
		if mirror: return Point(levelgen.level.size-x-1, levelgen.level.size-y-1)
		if axis == 'y': return Point(levelgen.level.size-x-1, y)
		if axis == 'x' and not mirror: return Point(x, levelgen.level.size-y-1)

	for i in range((levelgen.level.size // 2)):
		for j in range(levelgen.level.size):
			
			src_x, src_y = get_src(i, j)
			cur_tile = level.tiles[src_x][src_y]
			tgt_x, tgt_y = get_tgt(src_x, src_y)

			if cur_tile.is_wall(): level.make_wall(tgt_x, tgt_y)
			if cur_tile.is_floor(): level.make_floor(tgt_x, tgt_y)
			if cur_tile.is_chasm: level.make_chasm(tgt_x, tgt_y)

def lumps(levelgen, num_lumps=None, space_size=None):
	if num_lumps is None: num_lumps = levelgen.random.randint(1, 4)
	if space_size is None: space_size = levelgen.random.randint(8, 35)

	level = levelgen.level

	options = []
	max_existing = 110
	if len([t for t in level.iter_tiles() if not t.can_walk]) < max_existing:
		options.append('wall')
		options.append('chasm')
	if not options or len([t for t in level.iter_tiles() if t.is_floor()]) < max_existing:
		options.append('floor')

	mode = levelgen.random.choice(options)

	level_logger.debug("Lumps: %d %d (%s)" % (num_lumps, space_size, mode))

	for i in range(num_lumps):

		start_point = Point(levelgen.random.randint(0, levelgen.level.size-1), levelgen.random.randint(0, levelgen.level.size-1))
		candidates = [start_point]
		chosen = set()

		for j in range(space_size):
			cur_point = levelgen.random.choice(candidates)
			candidates.remove(cur_point)

			chosen.add(cur_point)

			for point in level.get_points_in_ball(cur_point.x, cur_point.y, 1):
				if point not in candidates and point not in chosen:
					candidates.append(point)

		for p in chosen:
			if mode == 'wall': level.make_wall(p.x, p.y)
			if mode == 'floor': level.make_floor(p.x, p.y)
			if mode == 'chasm': level.make_chasm(p.x, p.y)

def quads(levelgen):
	level = levelgen.level
	level_logger.debug("Quadrants")
	for i in range(levelgen.level.size // 2):
		for j in range(levelgen.level.size // 2):

			cur_tile = level.tiles[i][j]

			tgts = [
				Point(i, j + levelgen.level.size // 2),
				Point(i + levelgen.level.size // 2, j),
				Point(i + levelgen.level.size // 2, j + levelgen.level.size // 2)
			]
			for tgt_x, tgt_y in tgts:
				if cur_tile.is_wall():
					level.make_wall(tgt_x, tgt_y)
				if cur_tile.is_floor():		
					level.make_floor(tgt_x, tgt_y)
				if cur_tile.is_chasm:
					level.make_chasm(tgt_x, tgt_y)

def radialquads(levelgen):
	level = levelgen.level
	level_logger.debug("Radial Quadrants")
	for i in range(levelgen.level.size // 2):
		for j in range(levelgen.level.size // 2):

			cur_tile = level.tiles[i][j]

			tgts = [
				Point(i, levelgen.level.size - j - 1),
				Point(levelgen.level.size - i - 1, j),
				Point(levelgen.level.size - i - 1, levelgen.level.size - j - 1)
			]

			for tgt_x, tgt_y in tgts:
				if cur_tile.is_wall():
					level.make_wall(tgt_x, tgt_y)
				if cur_tile.is_floor():		
					level.make_floor(tgt_x, tgt_y)
				if cur_tile.is_chasm:
					level.make_chasm(tgt_x, tgt_y)

def paths(levelgen, num_points=None):
	level = levelgen.level
	if num_points is None: num_points = levelgen.random.choice([4, 6, 8, 10, 12, 14])
	all_points = [Point(i, j) for i in range(levelgen.level.size) for j in range(levelgen.level.size)]
	levelgen.random.shuffle(all_points)

	start_points = []
	for i in range(num_points): start_points.append(all_points.pop())

	options = []
	max_existing = 200
	if len([t for t in level.iter_tiles() if not t.can_walk]) < max_existing:
		options.append('wall')
		options.append('chasm')
	if not options or len([t for t in level.iter_tiles() if t.is_floor()]) < max_existing:
		options.append('floor')

	reconnect_chance = levelgen.random.choice([0, 0, .05, .1, .15, .2])
	mode = levelgen.random.choice(options)
	level_logger.debug("Paths: %d, %.2f, %s" % (num_points, reconnect_chance, mode))


	# Make start points a list and use PRNG to pick paths so that levelgen is reproducable
	levelgen.random.shuffle(start_points)
	end_points = [start_points.pop()]

	# for each start point, connect it to the graph
	while start_points:

		cur_start_point = levelgen.random.choice(start_points)
		start_points.remove(cur_start_point)

		possible_end_points = sorted(end_points, key=lambda p: distance(p, cur_start_point))[:4]
		cur_end_point = levelgen.random.choice(possible_end_points)

		end_points.append(cur_start_point)

		cur_point = cur_start_point
		while (cur_point != cur_end_point):
			
			if mode == 'floor':
				level.make_floor(cur_point.x, cur_point.y)
			if mode == 'wall':
				level.make_wall(cur_point.x, cur_point.y)
			if mode == 'chasm':
				level.make_chasm(cur_point.x, cur_point.y)

			trydir = levelgen.random.randint(0, 3)
			if trydir == 0 and cur_point.x < cur_end_point.x:
				cur_point = Point(cur_point.x + 1, cur_point.y)
			if trydir == 1 and  cur_point.x > cur_end_point.x:
				cur_point = Point(cur_point.x - 1, cur_point.y)
			if trydir == 2 and cur_point.y < cur_end_point.y:
				cur_point = Point(cur_point.x, cur_point.y + 1)
			if trydir == 3 and cur_point.y > cur_end_point.y:
				cur_point = Point(cur_point.x, cur_point.y - 1)

		# 20% of the time re-add it- this way there are more paths
		if levelgen.random.random() < reconnect_chance:
			start_points.append(cur_start_point)

def conway(levelgen):
	n = levelgen.random.choice([1, 3, 10])
	level_logger.debug("Game of life: %d" % n)
	level = levelgen.level
	def populated(x, y):
		return level.tiles[x][y].is_wall()

	def populate(x, y):
		level.make_wall(x, y)

	def depopulate(x, y):
		level.make_floor(x, y)

	for i in range(n):
		grid = {}

		for x in range(levelgen.level.size):
			for y in range(levelgen.level.size):
				num_adj = len(list(p for p in level.get_points_in_ball(x, y, 1, diag=True) if populated(p.x, p.y)))
				if populated(x, y):
					if num_adj <= 2:
						grid[x, y] = False
					elif num_adj >= 5:
						grid[x, y] = False
					else:
						grid[x, y] = True
				else:
					if num_adj >= 3:
						grid[x, y] = True
					else:
						grid[x, y] = False

		for (x, y), v in grid.items():
			if v:
				populate(x, y)
			else:
				depopulate(x, y)

def section(levelgen):
	level = levelgen.level
	method = levelgen.random.choice([level.make_wall, level.make_floor, level.make_chasm])
	max_start = max(5, levelgen.level.size - 4)
	start = levelgen.random.randint(4, max_start)
	axis = levelgen.random.choice(['x', 'y'])
	flip = levelgen.random.choice([True, False])

	level_logger.debug("Section: %s, %s, %s, %s" % (method, start, axis, flip))

	for i in range(levelgen.level.size):
		for j in range(levelgen.level.size):

			do = False
			to_check = i if axis == 'x' else j
			
			if flip:
				do = to_check < start
			else:
				do = to_check > start
			
			if do:
				method(i, j) 

def diagonal_cut(levelgen):
	level = levelgen.level
	thickness = levelgen.random.randint(1, 3)
	slope = levelgen.random.choice([-1, 1])
	offset = levelgen.random.randint(-4, 4)
	mode = levelgen.random.choice(['floor', 'chasm'])
	level_logger.debug("Diagonal: %d %d %s" % (thickness, offset, mode))

	for x in range(level.size):
		y = slope * x + offset
		for delta in range(-thickness, thickness + 1):
			target_y = y + delta
			if 0 <= target_y < level.size:
				if mode == 'floor': level.make_floor(x, target_y)
				else: level.make_chasm(x, target_y)

def crater_field(levelgen):
	level = levelgen.level
	num = levelgen.random.randint(1, 3)
	level_logger.debug("Craters: %d" % num)

	for _ in range(num):
		center = Point(levelgen.random.randint(3, level.size - 4), levelgen.random.randint(3, level.size - 4))
		radius = levelgen.random.randint(2, 5)
		for p in level.get_points_in_ball(center.x, center.y, radius, diag=True):
			if levelgen.random.random() < .6:
				level.make_chasm(p.x, p.y)

def pillar_noise(levelgen, density=None, blob=None):
	level = levelgen.level
	rng = levelgen.random
	if density is None: density = rng.choice([.03, .04, .05, .06])
	if blob is None: blob = rng.choice([1, 1, 2])
	level_logger.debug("Pillars: %.2f (%d)" % (density, blob))
	size = level.size
	for t in level.iter_tiles():
		if not t.can_see: continue
		if rng.random() > density: continue
		for dx in range(blob):
			for dy in range(blob):
				x = t.x + dx
				y = t.y + dy
				if x >= size or y >= size: continue
				level.make_wall(x, y)

def ribs(levelgen, spacing=None, thickness=None, gaps=None):
	level = levelgen.level
	rng = levelgen.random
	if spacing is None: spacing = rng.randint(4, 8)
	if thickness is None: thickness = rng.choice([1, 1, 2])
	if gaps is None: gaps = rng.choice([.2, .25, .3, .35])
	axis = rng.choice(['x', 'y'])
	level_logger.debug("Ribs: %s %d %d %.2f" % (axis, spacing, thickness, gaps))
	for i in range(level.width):
		for j in range(level.height):
			check = i if axis == 'x' else j
			if (check % spacing) >= thickness: continue
			if rng.random() < gaps: continue
			level.make_wall(i, j)

def ruins(levelgen, rooms=None, min_size=3, max_size=5, erosion=None):
	level = levelgen.level
	rng = levelgen.random
	if rooms is None: rooms = rng.randint(3, 6)
	if erosion is None: erosion = rng.choice([.25, .3, .35, .4])
	level_logger.debug("Ruins: %d %d-%d %.2f" % (rooms, min_size, max_size, erosion))
	for _ in range(rooms):
		w = rng.randint(min_size, max_size)
		h = rng.randint(min_size, max_size)
		x = rng.randint(0, max(level.size - w, 0))
		y = rng.randint(0, max(level.size - h, 0))
		for dx in range(w):
			for dy in range(h):
				if dx and dy and dx < w - 1 and dy < h - 1: continue
				if rng.random() < erosion: continue
				level.make_wall(x + dx, y + dy)

def stalagmites(levelgen, spikes=None, max_len=None):
	level = levelgen.level
	rng = levelgen.random
	if spikes is None: spikes = rng.randint(10, 16)
	if max_len is None: max_len = rng.choice([1, 2, 3])
	level_logger.debug("Stalagmites: %d %d" % (spikes, max_len))
	size = level.size
	directions = [Point(1, 0), Point(-1, 0), Point(0, 1), Point(0, -1)]
	for _ in range(spikes):
		start = None
		for _ in range(10):
			x = rng.randint(0, size - 1)
			y = rng.randint(0, size - 1)
			if level.tiles[x][y].is_chasm:
				start = Point(x, y)
				break
		if not start: continue
		direction = rng.choice(directions)
		length = rng.randint(1, max_len)
		for step in range(length):
			tx = start.x + direction.x * step
			ty = start.y + direction.y * step
			if tx < 0 or ty < 0 or tx >= size or ty >= size: break
			if not level.tiles[tx][ty].is_chasm: break
			level.make_wall(tx, ty)

def weave(levelgen, stripe=None, gap=None):
	level = levelgen.level
	rng = levelgen.random
	if stripe is None: stripe = rng.randint(3, 5)
	if gap is None: gap = rng.choice([.25, .3, .35])
	level_logger.debug("Weave: %d %.2f" % (stripe, gap))
	for i in range(level.width):
		for j in range(level.height):
			if ((i // stripe) + (j // stripe)) % 2: continue
			if rng.random() < gap: continue
			level.make_wall(i, j)

def macro_checkerboard_3x3(levelgen, chunk=None, flip_chance=None, floor_bias=None):
	level = levelgen.level
	rng = levelgen.random
	if chunk is None: chunk = 3
	if flip_chance is None: flip_chance = rng.choice([.12, .16, .2, .24])
	if floor_bias is None: floor_bias = rng.choice([.45, .5, .55])
	mode = rng.choice(['wall', 'chasm', 'mixed'])
	ox = rng.randint(0, 1)
	oy = rng.randint(0, 1)
	level_logger.debug("Checker3: c=%d flip=%.2f bias=%.2f (%s)" % (chunk, flip_chance, floor_bias, mode))

	size = level.size
	for x0 in range(0, size, chunk):
		for y0 in range(0, size, chunk):
			cx = x0 // chunk
			cy = y0 // chunk
			make_floor_chunk = ((cx + ox + cy + oy) % 2) == 0
			if rng.random() < flip_chance:
				make_floor_chunk = not make_floor_chunk
			if rng.random() < .18:
				make_floor_chunk = rng.random() < floor_bias

			cur_mode = mode
			if cur_mode == 'mixed':
				cur_mode = 'chasm' if rng.random() < .45 else 'wall'

			for dx in range(chunk):
				for dy in range(chunk):
					x = x0 + dx
					y = y0 + dy
					if x >= size or y >= size: continue
					if make_floor_chunk:
						level.make_floor(x, y)
					else:
						if cur_mode == 'wall': level.make_wall(x, y)
						else: level.make_chasm(x, y)

def voronoi_districts(levelgen, seeds=None):
	level = levelgen.level
	rng = levelgen.random
	size = level.size
	if seeds is None: seeds = rng.choice([4, 5, 6])
	level_logger.debug("Voronoi: seeds=%d" % seeds)

	points = []
	for _ in range(seeds):
		points.append(Point(rng.randint(1, size - 2), rng.randint(1, size - 2)))

	modes = []
	for i in range(seeds):
		if i < 2:
			modes.append('floor')
			continue
		roll = rng.random()
		if roll < .45: modes.append('floor')
		elif roll < .75: modes.append('wall')
		else: modes.append('chasm')

	jitters = [rng.random() * .6 for _ in range(seeds)]
	for x in range(size):
		for y in range(size):
			best = None
			best_dist = 10**9
			for i, p in enumerate(points):
				d = abs(x - p.x) + abs(y - p.y) + jitters[i]
				if d < best_dist:
					best_dist = d
					best = i
			mode = modes[best]
			if mode == 'floor': level.make_floor(x, y)
			elif mode == 'wall': level.make_wall(x, y)
			else: level.make_chasm(x, y)

def serpentine_river(levelgen, rivers=None, width=None, bridges=None):
	level = levelgen.level
	rng = levelgen.random
	size = level.size
	if rivers is None: rivers = rng.choice([1, 1, 2])
	if width is None: width = rng.choice([1, 2])
	if bridges is None: bridges = rng.choice([1, 2, 3])
	orientation = rng.choice(['h', 'v'])
	level_logger.debug("River: n=%d w=%d b=%d (%s)" % (rivers, width, bridges, orientation))
	river_points = []

	for _ in range(rivers):
		if orientation == 'h':
			y = rng.randint(2, size - 3)
			for x in range(size):
				river_points.append(Point(x, y))
				for w in range(-width, width + 1):
					ty = y + w
					if 0 <= ty < size:
						level.make_chasm(x, ty)
				if rng.random() < .6:
					y += rng.choice([-1, 0, 1])
					y = max(2, min(size - 3, y))
		else:
			x = rng.randint(2, size - 3)
			for y in range(size):
				river_points.append(Point(x, y))
				for w in range(-width, width + 1):
					tx = x + w
					if 0 <= tx < size:
						level.make_chasm(tx, y)
				if rng.random() < .6:
					x += rng.choice([-1, 0, 1])
					x = max(2, min(size - 3, x))

	if not river_points: return
	for _ in range(bridges):
		anchor = rng.choice(river_points)
		if orientation == 'h':
			bw = rng.choice([1, 1, 2])
			for dx in range(-bw, bw + 1):
				tx = anchor.x + dx
				if tx < 0 or tx >= size: continue
				for dy in range(-(width + 1), width + 2):
					ty = anchor.y + dy
					if 0 <= ty < size:
						level.make_floor(tx, ty)
		else:
			bw = rng.choice([1, 1, 2])
			for dy in range(-bw, bw + 1):
				ty = anchor.y + dy
				if ty < 0 or ty >= size: continue
				for dx in range(-(width + 1), width + 2):
					tx = anchor.x + dx
					if 0 <= tx < size:
						level.make_floor(tx, ty)

def spiral_carve(levelgen, ring_step=None, branch_chance=None):
	level = levelgen.level
	rng = levelgen.random
	size = level.size
	if ring_step is None: ring_step = rng.choice([2, 2, 3])
	if branch_chance is None: branch_chance = rng.choice([.08, .12, .16])
	level_logger.debug("Spiral: step=%d branch=%.2f" % (ring_step, branch_chance))

	left = 1
	right = size - 2
	top = 1
	bottom = size - 2
	while left <= right and top <= bottom:
		for x in range(left, right + 1):
			level.make_floor(x, top)
			if rng.random() < branch_chance and top + 1 < size - 1:
				level.make_floor(x, top + 1)
		for y in range(top, bottom + 1):
			level.make_floor(right, y)
			if rng.random() < branch_chance and right - 1 > 0:
				level.make_floor(right - 1, y)
		if top < bottom:
			for x in range(right, left - 1, -1):
				level.make_floor(x, bottom)
				if rng.random() < branch_chance and bottom - 1 > 0:
					level.make_floor(x, bottom - 1)
		if left < right:
			for y in range(bottom, top - 1, -1):
				level.make_floor(left, y)
				if rng.random() < branch_chance and left + 1 < size - 1:
					level.make_floor(left + 1, y)
		left += ring_step
		right -= ring_step
		top += ring_step
		bottom -= ring_step

def fortress_cells(levelgen, forts=None, min_size=None, max_size=None):
	level = levelgen.level
	rng = levelgen.random
	size = level.size
	if forts is None: forts = rng.choice([2, 3, 4])
	if min_size is None: min_size = 4
	if max_size is None: max_size = 7
	level_logger.debug("Fortress: n=%d %d-%d" % (forts, min_size, max_size))

	centers = []
	for _ in range(forts):
		w = rng.randint(min_size, max_size)
		h = rng.randint(min_size, max_size)
		x = rng.randint(1, max(1, size - w - 1))
		y = rng.randint(1, max(1, size - h - 1))
		for dx in range(w):
			for dy in range(h):
				tx = x + dx
				ty = y + dy
				if dx == 0 or dy == 0 or dx == w - 1 or dy == h - 1:
					level.make_wall(tx, ty)
				else:
					level.make_floor(tx, ty)
		centers.append(Point(x + w // 2, y + h // 2))

	for i in range(1, len(centers)):
		a = centers[i - 1]
		b = centers[i]
		for p in level.get_points_in_line(a, b, no_diag=True, prng=rng):
			level.make_floor(p.x, p.y)

def cavern_pockets(levelgen, pockets=None, size_min=None, size_max=None, links=None):
	level = levelgen.level
	rng = levelgen.random
	size = level.size
	if pockets is None: pockets = rng.choice([4, 5, 6, 7])
	if size_min is None: size_min = 2
	if size_max is None: size_max = 4
	if links is None: links = rng.choice([2, 3, 4])
	level_logger.debug("CavernPockets: n=%d r=%d-%d links=%d" % (pockets, size_min, size_max, links))

	centers = []
	for _ in range(pockets):
		cx = rng.randint(2, size - 3)
		cy = rng.randint(2, size - 3)
		rx = rng.randint(size_min, size_max)
		ry = rng.randint(size_min, size_max)
		centers.append(Point(cx, cy))
		for x in range(max(1, cx - rx - 1), min(size - 1, cx + rx + 2)):
			for y in range(max(1, cy - ry - 1), min(size - 1, cy + ry + 2)):
				norm = ((x - cx) ** 2) / float(max(1, rx * rx)) + ((y - cy) ** 2) / float(max(1, ry * ry))
				if norm > 1.25: continue
				if norm > 1.0 and rng.random() < .5: continue
				level.make_floor(x, y)
				if rng.random() < .14:
					for p in level.get_points_in_ball(x, y, 1, diag=False):
						if 0 < p.x < size - 1 and 0 < p.y < size - 1:
							level.make_floor(p.x, p.y)

	if not centers: return
	for _ in range(links):
		src = rng.choice(centers)
		targets = sorted(centers, key=lambda p: distance(src, p))
		if len(targets) < 2: break
		dst = rng.choice(targets[1:min(4, len(targets))])
		for p in level.get_points_in_line(src, dst, no_diag=True, prng=rng):
			level.make_floor(p.x, p.y)
			if rng.random() < .2:
				for q in level.get_points_in_ball(p.x, p.y, 1, diag=False):
					level.make_floor(q.x, q.y)

def fault_lines(levelgen, lines=None, steps=None, width=None):
	level = levelgen.level
	rng = levelgen.random
	size = level.size
	if lines is None: lines = rng.choice([2, 3, 4, 5])
	if steps is None: steps = rng.choice([8, 10, 12, 14])
	if width is None: width = rng.choice([1, 1, 2])
	mode = rng.choice(['chasm', 'chasm', 'floor'])
	level_logger.debug("Faults: n=%d steps=%d w=%d (%s)" % (lines, steps, width, mode))

	dirs = [Point(1, 0), Point(-1, 0), Point(0, 1), Point(0, -1)]
	for _ in range(lines):
		side = rng.choice(['l', 'r', 't', 'b'])
		if side == 'l': cur = Point(0, rng.randint(1, size - 2))
		if side == 'r': cur = Point(size - 1, rng.randint(1, size - 2))
		if side == 't': cur = Point(rng.randint(1, size - 2), 0)
		if side == 'b': cur = Point(rng.randint(1, size - 2), size - 1)
		direction = rng.choice(dirs)

		for _ in range(steps):
			for p in level.get_points_in_ball(cur.x, cur.y, width, diag=True):
				if mode == 'chasm': level.make_chasm(p.x, p.y)
				else: level.make_floor(p.x, p.y)
			if rng.random() < .45:
				direction = rng.choice(dirs)
			cur = Point(cur.x + direction.x, cur.y + direction.y)
			cur = Point(max(0, min(size - 1, cur.x)), max(0, min(size - 1, cur.y)))

def alcove_nibbler(levelgen, attempts=None, max_depth=None):
	level = levelgen.level
	rng = levelgen.random
	size = level.size
	if attempts is None: attempts = rng.choice([24, 30, 36])
	if max_depth is None: max_depth = rng.choice([1, 2, 2, 3])
	level_logger.debug("Alcoves: attempts=%d depth=%d" % (attempts, max_depth))

	dirs = [Point(1, 0), Point(-1, 0), Point(0, 1), Point(0, -1)]
	floors = [t for t in level.iter_tiles() if t.can_walk and 1 <= t.x < size - 1 and 1 <= t.y < size - 1]
	if not floors: return

	for _ in range(attempts):
		start = rng.choice(floors)
		d = rng.choice(dirs)
		wx = start.x + d.x
		wy = start.y + d.y
		if wx <= 0 or wy <= 0 or wx >= size - 1 or wy >= size - 1: continue
		if not level.tiles[wx][wy].is_wall(): continue
		depth = rng.randint(1, max_depth)
		for step in range(depth):
			tx = start.x + d.x * (step + 1)
			ty = start.y + d.y * (step + 1)
			if tx <= 0 or ty <= 0 or tx >= size - 1 or ty >= size - 1: break
			if not level.tiles[tx][ty].is_wall(): break
			level.make_floor(tx, ty)

def bridge_stitcher(levelgen, bridges=None):
	level = levelgen.level
	rng = levelgen.random
	size = level.size
	if bridges is None: bridges = rng.choice([4, 6, 8, 10, 12])
	level_logger.debug("BridgeStitch: %d" % bridges)

	candidates = []
	for x in range(1, size - 1):
		for y in range(1, size - 1):
			if not level.tiles[x][y].is_chasm: continue
			h = level.tiles[x - 1][y].can_walk and level.tiles[x + 1][y].can_walk
			v = level.tiles[x][y - 1].can_walk and level.tiles[x][y + 1].can_walk
			if h or v:
				candidates.append(Point(x, y))

	rng.shuffle(candidates)
	for p in candidates[:bridges]:
		level.make_floor(p.x, p.y)

	if bridges <= 2: return
	extra = bridges // 2
	for _ in range(extra):
		axis = rng.choice(['h', 'v'])
		if axis == 'h':
			x = rng.randint(1, size - 3)
			y = rng.randint(1, size - 2)
			if level.tiles[x][y].is_chasm and level.tiles[x + 1][y].is_chasm and level.tiles[x - 1][y].can_walk and level.tiles[x + 2][y].can_walk:
				level.make_floor(x, y)
				level.make_floor(x + 1, y)
		else:
			x = rng.randint(1, size - 2)
			y = rng.randint(1, size - 3)
			if level.tiles[x][y].is_chasm and level.tiles[x][y + 1].is_chasm and level.tiles[x][y - 1].can_walk and level.tiles[x][y + 2].can_walk:
				level.make_floor(x, y)
				level.make_floor(x, y + 1)

def choke_point_builder(levelgen, count=None, length=None):
	level = levelgen.level
	rng = levelgen.random
	size = level.size
	if count is None: count = rng.choice([1, 2, 3])
	if length is None: length = rng.choice([3, 5])
	level_logger.debug("Chokes: n=%d len=%d" % (count, length))

	floors = [t for t in level.iter_tiles() if t.can_walk and 2 <= t.x < size - 2 and 2 <= t.y < size - 2]
	if not floors: return

	for _ in range(count):
		center = None
		for _ in range(20):
			t = rng.choice(floors)
			open_tiles = len([p for p in level.get_points_in_ball(t.x, t.y, 2, diag=True) if level.tiles[p.x][p.y].can_walk])
			if open_tiles >= 12:
				center = t
				break
		if center is None: continue

		axis = rng.choice(['x', 'y'])
		half = length // 2
		gap = rng.randint(-1, 1)
		for d in range(-half, half + 1):
			if d == gap: continue
			x = center.x + d if axis == 'x' else center.x
			y = center.y if axis == 'x' else center.y + d
			if x <= 0 or y <= 0 or x >= size - 1 or y >= size - 1: continue
			level.make_wall(x, y)
		level.make_floor(center.x + gap if axis == 'x' else center.x, center.y if axis == 'x' else center.y + gap)

def symmetry_breaker(levelgen):
	level = levelgen.level
	rng = levelgen.random
	size = level.size
	half = size // 2
	quadrants = [
		(0, half, 0, half),
		(half, size, 0, half),
		(0, half, half, size),
		(half, size, half, size)
	]
	x0, x1, y0, y1 = rng.choice(quadrants)
	level_logger.debug("SymBreak: x=%d-%d y=%d-%d" % (x0, x1, y0, y1))

	test_level = Level(size, size)
	for x in range(size):
		for y in range(size):
			tile = level.tiles[x][y]
			if tile.is_floor(): test_level.make_floor(x, y)
			elif tile.is_chasm: test_level.make_chasm(x, y)
			else: test_level.make_wall(x, y)

	original_level = levelgen.level
	levelgen.level = test_level
	try:
		mutator = rng.choice([white_noise, noisy_pocket_carve, wall_clusters, pillar_noise, fault_lines])
		mutator(levelgen)
	finally:
		levelgen.level = original_level

	for x in range(x0, x1):
		for y in range(y0, y1):
			new_tile = test_level.tiles[x][y]
			if new_tile.is_floor(): level.make_floor(x, y)
			elif new_tile.is_chasm: level.make_chasm(x, y)
			else: level.make_wall(x, y)

def edge_bays(levelgen, bays=None, max_depth=None, max_width=None):
	level = levelgen.level
	rng = levelgen.random
	size = level.size
	if bays is None: bays = rng.choice([1, 2, 3])
	if max_depth is None: max_depth = rng.choice([4, 5, 6, 7])
	if max_width is None: max_width = rng.choice([2, 3, 4])
	mode = rng.choice(['chasm', 'chasm', 'floor'])
	level_logger.debug("EdgeBays: n=%d d=%d w=%d (%s)" % (bays, max_depth, max_width, mode))

	for _ in range(bays):
		side = rng.choice(['l', 'r', 't', 'b'])
		depth = rng.randint(3, max_depth)
		width = rng.randint(2, max_width)
		if side in ['l', 'r']:
			center = rng.randint(2, size - 3)
			for step in range(depth):
				span = max(1, width - (step // 2))
				x = step if side == 'l' else size - 1 - step
				for y in range(center - span, center + span + 1):
					if y < 0 or y >= size: continue
					if mode == 'chasm': level.make_chasm(x, y)
					else: level.make_floor(x, y)
		else:
			center = rng.randint(2, size - 3)
			for step in range(depth):
				span = max(1, width - (step // 2))
				y = step if side == 't' else size - 1 - step
				for x in range(center - span, center + span + 1):
					if x < 0 or x >= size: continue
					if mode == 'chasm': level.make_chasm(x, y)
					else: level.make_floor(x, y)

		if rng.random() < .35:
			for cap in range(rng.randint(2, 4)):
				if side == 'l': x = depth + cap
				elif side == 'r': x = size - 1 - depth - cap
				else: x = None
				if side == 't': y = depth + cap
				elif side == 'b': y = size - 1 - depth - cap
				else: y = None
				if x is not None:
					for yy in range(1, size - 1):
						if rng.random() < .08: level.make_wall(x, yy)
				if y is not None:
					for xx in range(1, size - 1):
						if rng.random() < .08: level.make_wall(xx, y)

def banded_walls(levelgen, spacing=None, axis=None, doors=None, thickness=None):
	level = levelgen.level
	rng = levelgen.random
	if spacing is None: spacing = rng.choice([2, 3, 4, 5, 6, 7])
	if axis is None: axis = rng.choice(['x', 'y'])
	if doors is None: doors = rng.choice([1, 2, 3])
	if thickness is None: thickness = rng.choice([1, 1, 2])
	level_logger.debug("Banded: %s %d doors=%d thick=%d" % (axis, spacing, doors, thickness))

	size = level.size
	for i in range(size):
		for j in range(size):
			band = i if axis == 'x' else j
			if (band % spacing) < thickness:
				level.make_wall(i, j)

	for line in range(0, size, spacing):
		for _ in range(doors):
			d = rng.randint(1, size - 2)
			for t in range(thickness):
				row = line + t
				if row < 0 or row >= size: continue
				x = row if axis == 'x' else d
				y = d if axis == 'x' else row
				level.make_floor(x, y)

def rooms_and_corridors(levelgen, rooms=None, min_size=3, max_size=5):
	level = levelgen.level
	rng = levelgen.random
	if rooms is None: rooms = rng.choice([3, 4, 5, 6])
	level_logger.debug("Rooms+Corridors: %d %d-%d" % (rooms, min_size, max_size))

	centers = []
	for _ in range(rooms):
		w = rng.randint(min_size, max_size)
		h = rng.randint(min_size, max_size)
		x = rng.randint(0, max(level.size - w, 0))
		y = rng.randint(0, max(level.size - h, 0))
		for dx in range(w):
			for dy in range(h):
				level.make_floor(x + dx, y + dy)
		centers.append(Point(x + w // 2, y + h // 2))

	for i in range(1, len(centers)):
		a = centers[i - 1]
		b = centers[i]
		if rng.random() < .5:
			for x in range(min(a.x, b.x), max(a.x, b.x) + 1): level.make_floor(x, a.y)
			for y in range(min(a.y, b.y), max(a.y, b.y) + 1): level.make_floor(b.x, y)
		else:
			for y in range(min(a.y, b.y), max(a.y, b.y) + 1): level.make_floor(a.x, y)
			for x in range(min(a.x, b.x), max(a.x, b.x) + 1): level.make_floor(x, b.y)

def random_walk_corridors(levelgen, steps=None, thickness=None):
	level = levelgen.level
	rng = levelgen.random
	if steps is None: steps = rng.choice([120, 150, 180])
	if thickness is None: thickness = rng.choice([1, 1, 2])
	level_logger.debug("WalkCorridor: %d thick=%d" % (steps, thickness))

	size = level.size
	x = rng.randint(1, size - 2)
	y = rng.randint(1, size - 2)
	dirs = [Point(1, 0), Point(-1, 0), Point(0, 1), Point(0, -1)]

	for _ in range(steps):
		for dx in range(-thickness + 1, thickness):
			for dy in range(-thickness + 1, thickness):
				tx = x + dx
				ty = y + dy
				if 0 < tx < size - 1 and 0 < ty < size - 1:
					level.make_floor(tx, ty)

		d = rng.choice(dirs)
		x = min(size - 2, max(1, x + d.x))
		y = min(size - 2, max(1, y + d.y))

def ring_and_spokes(levelgen, ring=None, spokes=None):
	level = levelgen.level
	rng = levelgen.random
	size = level.size
	if ring is None: ring = rng.choice([1, 2])
	if spokes is None: spokes = rng.choice([2, 3, 4])
	level_logger.debug("Ring+Spokes: ring=%d spokes=%d" % (ring, spokes))

	for i in range(ring, size - ring):
		level.make_floor(i, ring)
		level.make_floor(i, size - ring - 1)
		level.make_floor(ring, i)
		level.make_floor(size - ring - 1, i)

	for _ in range(spokes):
		if rng.random() < .5:
			x = rng.randint(ring + 1, size - ring - 2)
			for y in range(ring, size - ring): level.make_floor(x, y)
		else:
			y = rng.randint(ring + 1, size - ring - 2)
			for x in range(ring, size - ring): level.make_floor(x, y)

def wall_clusters(levelgen, clusters=None, sizes=None):
	level = levelgen.level
	rng = levelgen.random
	size = level.size
	if clusters is None: clusters = rng.choice([8, 10, 12])
	if sizes is None: sizes = [(2, 2), (3, 2), (3, 3)]
	level_logger.debug("WallClusters: %d" % clusters)

	for _ in range(clusters):
		w, h = rng.choice(sizes)
		x = rng.randint(1, max(1, size - w - 1))
		y = rng.randint(1, max(1, size - h - 1))
		for dx in range(w):
			for dy in range(h):
				level.make_wall(x + dx, y + dy)

def paths_floor(levelgen, num_points=None, reconnect_chance=None):
	level = levelgen.level
	if num_points is None: num_points = levelgen.random.choice([4, 6, 8, 10, 12, 14])
	if reconnect_chance is None: reconnect_chance = levelgen.random.choice([0, 0, .05, .1, .15, .2])
	all_points = [Point(i, j) for i in range(levelgen.level.size) for j in range(levelgen.level.size)]
	levelgen.random.shuffle(all_points)

	start_points = []
	for i in range(num_points): start_points.append(all_points.pop())

	level_logger.debug("PathsFloor: %d, %.2f" % (num_points, reconnect_chance))

	levelgen.random.shuffle(start_points)
	end_points = [start_points.pop()]

	while start_points:
		cur_start_point = levelgen.random.choice(start_points)
		start_points.remove(cur_start_point)

		possible_end_points = sorted(end_points, key=lambda p: distance(p, cur_start_point))[:4]
		cur_end_point = levelgen.random.choice(possible_end_points)

		end_points.append(cur_start_point)

		cur_point = cur_start_point
		while (cur_point != cur_end_point):
			level.make_floor(cur_point.x, cur_point.y)

			trydir = levelgen.random.randint(0, 3)
			if trydir == 0 and cur_point.x < cur_end_point.x:
				cur_point = Point(cur_point.x + 1, cur_point.y)
			if trydir == 1 and  cur_point.x > cur_end_point.x:
				cur_point = Point(cur_point.x - 1, cur_point.y)
			if trydir == 2 and cur_point.y < cur_end_point.y:
				cur_point = Point(cur_point.x, cur_point.y + 1)
			if trydir == 3 and cur_point.y > cur_end_point.y:
				cur_point = Point(cur_point.x, cur_point.y - 1)

		if levelgen.random.random() < reconnect_chance:
			start_points.append(cur_start_point)

def deep_wall_walk(levelgen, thickness=None, digs=None, steps=None, branch_chance=None):
	level = levelgen.level
	rng = levelgen.random
	if thickness is None: thickness = rng.choice([2, 3])
	if digs is None: digs = rng.choice([3, 4, 5])
	if steps is None: steps = rng.choice([8, 10, 12])
	if branch_chance is None: branch_chance = rng.choice([.2, .25, .3])
	level_logger.debug("DeepWalk: r=%d digs=%d steps=%d %.2f" % (thickness, digs, steps, branch_chance))

	deep = []
	for t in level.iter_tiles():
		if not t.is_wall(): continue
		if any(level.can_walk(p.x, p.y) for p in level.get_points_in_ball(t.x, t.y, thickness, diag=True)):
			continue
		deep.append(t)
	if not deep: return

	size = level.size
	dirs = [Point(1, 0), Point(-1, 0), Point(0, 1), Point(0, -1)]
	for _ in range(digs):
		start = rng.choice(deep)
		cur = Point(start.x, start.y)
		for _ in range(steps):
			if 0 < cur.x < size - 1 and 0 < cur.y < size - 1:
				level.make_floor(cur.x, cur.y)

			d = rng.choice(dirs)
			cur = Point(cur.x + d.x, cur.y + d.y)
			if cur.x < 1 or cur.y < 1 or cur.x >= size - 1 or cur.y >= size - 1:
				cur = Point(rng.randint(1, size - 2), rng.randint(1, size - 2))

			if rng.random() < branch_chance:
				b = rng.choice(dirs)
				bx = cur.x + b.x
				by = cur.y + b.y
				if 0 < bx < size - 1 and 0 < by < size - 1:
					level.make_floor(bx, by)

def speckled_wall_decay(levelgen, passes=None, chance=None, thickness=None):
	level = levelgen.level
	rng = levelgen.random
	if passes is None: passes = rng.choice([1, 2, 3])
	if chance is None: chance = rng.choice([.05, .08, .1])
	if thickness is None: thickness = rng.choice([2, 3])
	level_logger.debug("Speckle: p=%d r=%d c=%.2f" % (passes, thickness, chance))

	for _ in range(passes):
		for t in level.iter_tiles():
			if not t.is_wall(): continue
			if any(level.can_walk(p.x, p.y) for p in level.get_points_in_ball(t.x, t.y, thickness, diag=True)):
				continue
			if rng.random() < chance:
				level.make_floor(t.x, t.y)

def noisy_pocket_carve(levelgen, pockets=None, pocket_size=None, thickness=None, grow=None):
	level = levelgen.level
	rng = levelgen.random
	if pockets is None: pockets = rng.choice([2, 3, 4])
	if pocket_size is None: pocket_size = rng.choice([10, 12, 14])
	if thickness is None: thickness = rng.choice([2, 3])
	if grow is None: grow = rng.choice([.55, .6, .65])
	level_logger.debug("Pockets: n=%d size=%d r=%d g=%.2f" % (pockets, pocket_size, thickness, grow))

	deep = []
	for t in level.iter_tiles():
		if not t.is_wall(): continue
		if any(level.can_walk(p.x, p.y) for p in level.get_points_in_ball(t.x, t.y, thickness, diag=True)):
			continue
		deep.append(t)
	if not deep: return

	for _ in range(pockets):
		start = rng.choice(deep)
		chosen = set([Point(start.x, start.y)])
		frontier = [Point(start.x, start.y)]
		while frontier and len(chosen) < pocket_size:
			cur = rng.choice(frontier)
			frontier.remove(cur)
			level.make_floor(cur.x, cur.y)

			for p in level.get_points_in_ball(cur.x, cur.y, 1, diag=False):
				if p in chosen: continue
				if rng.random() < grow:
					chosen.add(p)
					frontier.append(p)

def edge_breach_erosion(levelgen, breaches=None, steps=None, wiggle=None):
	level = levelgen.level
	rng = levelgen.random
	if breaches is None: breaches = rng.choice([1, 2, 3])
	if steps is None: steps = rng.choice([6, 8, 10])
	if wiggle is None: wiggle = rng.choice([.2, .3, .4])
	level_logger.debug("EdgeBreach: n=%d steps=%d w=%.2f" % (breaches, steps, wiggle))

	size = level.size
	dirs = [Point(1, 0), Point(-1, 0), Point(0, 1), Point(0, -1)]
	for _ in range(breaches):
		side = rng.choice(['l', 'r', 't', 'b'])
		if side == 'l': cur = Point(0, rng.randint(1, size - 2)); direction = Point(1, 0)
		if side == 'r': cur = Point(size - 1, rng.randint(1, size - 2)); direction = Point(-1, 0)
		if side == 't': cur = Point(rng.randint(1, size - 2), 0); direction = Point(0, 1)
		if side == 'b': cur = Point(rng.randint(1, size - 2), size - 1); direction = Point(0, -1)

		for _ in range(steps):
			if 0 < cur.x < size - 1 and 0 < cur.y < size - 1:
				level.make_floor(cur.x, cur.y)
			if rng.random() < wiggle:
				direction = rng.choice(dirs)
			cur = Point(cur.x + direction.x, cur.y + direction.y)
			if cur.x < 0 or cur.y < 0 or cur.x >= size or cur.y >= size:
				break

def diagonal_wall_cuts(levelgen, min_block=None, cuts=None, max_passes=None):
	level = levelgen.level
	rng = levelgen.random
	if min_block is None: min_block = 5
	if cuts is None: cuts = rng.choice([2, 3, 4, 5])
	if max_passes is None: max_passes = rng.choice([2, 3])
	level_logger.debug("DiagWallCuts: %d cuts=%d passes=%d" % (min_block, cuts, max_passes))

	size = level.size
	radius = min_block // 2
	candidates = []
	for x in range(radius, size - radius):
		for y in range(radius, size - radius):
			if not level.tiles[x][y].is_wall(): continue
			ok = True
			for dx in range(-radius, radius + 1):
				for dy in range(-radius, radius + 1):
					if not level.tiles[x + dx][y + dy].is_wall():
						ok = False
						break
				if not ok: break
			if ok:
				candidates.append(Point(x, y))

	for _ in range(max_passes):
		if not candidates: return
		rng.shuffle(candidates)
		cuts = min(cuts, len(candidates))
		for i in range(cuts):
			center = candidates[i]
			slope = rng.choice([-1, 1])
			for direction in [-1, 1]:
				d = 0
				while True:
					x = center.x + d * direction
					y = center.y + (d * slope) * direction
					if x <= 0 or y <= 0 or x >= size - 1 or y >= size - 1:
						break
					if not level.tiles[x][y].is_wall():
						break
					level.make_floor(x, y)
					d += 1

		candidates = []
		for x in range(radius, size - radius):
			for y in range(radius, size - radius):
				if not level.tiles[x][y].is_wall(): continue
				ok = True
				for dx in range(-radius, radius + 1):
					for dy in range(-radius, radius + 1):
						if not level.tiles[x + dx][y + dy].is_wall():
							ok = False
							break
					if not ok: break
				if ok:
					candidates.append(Point(x, y))

seed_mutators = [
	paths,
	paths_floor,
	white_noise,
	lumps,
	squares,
	grid,
	pillar_noise,
	ribs,
	random_walk_corridors,
	spiral_carve,
	cavern_pockets,
	macro_checkerboard_3x3
]

mutator_table = [
	expand_floor,	
	walls_to_chasms,
	chasmify,
	white_noise,
	squares,
	lambda lg: run_in_region(lg, bisymmetry) if lg.random.random() < .5 else bisymmetry(lg),
	wallify,
	lambda lg: run_in_region(lg, grid) if lg.random.random() < .5 else grid(lg),
	lambda lg: run_in_region(lg, border) if lg.random.random() < .5 else border(lg),
	lambda lg: run_in_region(lg, quads) if lg.random.random() < .5 else quads(lg),
	paths,
	conway,
	lambda lg: run_in_region(lg, radialquads) if lg.random.random() < .5 else radialquads(lg),
	lumps,
	lambda lg: run_in_region(lg, section) if lg.random.random() < .5 else section(lg),
	diagonal_cut,
	crater_field,
	pillar_noise,
	banded_walls,
	rooms_and_corridors,
	random_walk_corridors,
	ring_and_spokes,
	wall_clusters,
	deep_wall_walk,
	speckled_wall_decay,
	noisy_pocket_carve,
	edge_breach_erosion,
	ribs,
	ruins,
	stalagmites,
	weave,
	macro_checkerboard_3x3,
	voronoi_districts,
	serpentine_river,
	spiral_carve,
	fortress_cells,
	cavern_pockets,
	fault_lines,
	alcove_nibbler,
	bridge_stitcher,
	choke_point_builder,
	symmetry_breaker,
	edge_bays
]
