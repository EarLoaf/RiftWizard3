import json
import math
import sys
from pathlib import Path

import pygame


SPRITE_SIZE = 60
DEFAULT_CELL_SIZE = 16
ATLAS_SIZES = (24, 64)
ATLAS_COLUMNS = 32
OUTPUT_DIR = Path("rl_data") / "UI" / "icon_atlas"
MANIFEST_NAME = "manifest.json"


def asset_to_key(asset):
	return "/".join(asset)


def get_asset_path(asset):
	path = Path("rl_data").joinpath(*asset).with_suffix(".png")
	if path.exists(): return path
	return None


def extract_icon_frame(image, sprite_size=SPRITE_SIZE, default_cell=DEFAULT_CELL_SIZE):
	iw, ih = image.get_width(), image.get_height()
	if iw == sprite_size and ih == sprite_size:
		return image.copy()
	if iw >= sprite_size and ih >= sprite_size and iw % sprite_size == 0 and ih % sprite_size == 0:
		return image.subsurface((0, 0, sprite_size, sprite_size)).copy()
	if iw >= default_cell and ih >= default_cell:
		return image.subsurface((0, 0, default_cell, default_cell)).copy()
	side = max(1, min(iw, ih))
	return image.subsurface((0, 0, side, side)).copy()


def add_asset(assets, asset):
	if not asset: return
	if not isinstance(asset, list): return
	if not asset or not isinstance(asset[0], str): return
	assets.setdefault(asset_to_key(asset), tuple(asset))


def add_object_asset(assets, obj):
	if not hasattr(obj, "get_asset"): return
	add_asset(assets, obj.get_asset())


def add_constructed_assets(assets, constructors, label, errors):
	for constructor in constructors:
		try:
			obj = constructor()
			add_object_asset(assets, obj)
		except Exception as exc:
			errors.append((label, getattr(constructor, "__name__", repr(constructor)), str(exc)))


def collect_assets():
	from Equipment import all_equipment
	from Spells import all_player_spell_constructors
	from Components import all_components, rare_components

	assets = {}
	errors = []

	add_constructed_assets(assets, all_player_spell_constructors, "spell", errors)
	add_constructed_assets(assets, all_equipment, "equipment", errors)
	add_constructed_assets(assets, all_components, "component", errors)
	add_constructed_assets(assets, rare_components, "rare component", errors)

	return assets, errors


def build_atlas(size, assets):
	keys = sorted(assets)
	if not keys: return None, {}, []

	cols = min(ATLAS_COLUMNS, max(1, len(keys)))
	rows = int(math.ceil(len(keys) / cols))
	atlas = pygame.Surface((cols * size, rows * size), pygame.SRCALPHA)
	entries = {}
	missing = []

	for index, key in enumerate(keys):
		asset = assets[key]
		path = get_asset_path(asset)
		if not path:
			missing.append(key)
			continue

		image = pygame.image.load(str(path))
		base = extract_icon_frame(image)
		icon = pygame.transform.smoothscale(base, (size, size))

		x = (index % cols) * size
		y = (index // cols) * size
		atlas.blit(icon, (x, y))
		entries[key] = [x, y, size, size]

	return atlas, entries, missing


def write_manifest(manifest):
	manifest_path = OUTPUT_DIR / MANIFEST_NAME
	with manifest_path.open("w", encoding="utf-8") as f:
		json.dump(manifest, f, indent=2, sort_keys=True)
	return manifest_path


def build_icon_atlas_data():
	assets, errors = collect_assets()

	manifest = {
		"version": 1,
		"sizes": {},
	}

	atlases = {}
	all_missing = set()
	for size in ATLAS_SIZES:
		atlas, entries, missing = build_atlas(size, assets)
		all_missing.update(missing)
		if atlas is None: continue

		filename = f"icon_atlas_{size}.png"
		manifest["sizes"][str(size)] = {
			"image": filename,
			"entries": entries,
		}
		atlases[str(size)] = atlas

	return manifest, atlases, all_missing, errors


def report_build_notes(manifest, all_missing, errors, action="Wrote"):
	for size in ATLAS_SIZES:
		if str(size) in manifest["sizes"]:
			entry_count = len(manifest["sizes"][str(size)]["entries"])
			print(f"{action} {entry_count} icons at {size}px")

	if all_missing:
		print("\nMissing assets:")
		for key in sorted(all_missing):
			print(f"  {key}")

	if errors:
		print("\nSkipped constructors:")
		for label, name, error in errors:
			print(f"  {label} {name}: {error}")


def build_icon_atlases():
	OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
	manifest, atlases, all_missing, errors = build_icon_atlas_data()

	for size, atlas in atlases.items():
		filename = manifest["sizes"][size]["image"]
		pygame.image.save(atlas, str(OUTPUT_DIR / filename))

	manifest_path = write_manifest(manifest)

	print(f"Wrote {manifest_path}")
	report_build_notes(manifest, all_missing, errors)


def surfaces_match(a, b):
	if a.get_size() != b.get_size(): return False
	return pygame.image.tostring(a, "RGBA") == pygame.image.tostring(b, "RGBA")


def check_icon_atlases():
	manifest, atlases, all_missing, errors = build_icon_atlas_data()
	manifest_path = OUTPUT_DIR / MANIFEST_NAME
	ok = True

	if not manifest_path.exists():
		print(f"Missing {manifest_path}")
		ok = False
	else:
		with manifest_path.open("r", encoding="utf-8") as f:
			current_manifest = json.load(f)
		if current_manifest != manifest:
			print(f"Stale {manifest_path}")
			ok = False

	for size, atlas in atlases.items():
		path = OUTPUT_DIR / manifest["sizes"][size]["image"]
		if not path.exists():
			print(f"Missing {path}")
			ok = False
			continue
		current_atlas = pygame.image.load(str(path))
		if not surfaces_match(current_atlas, atlas):
			print(f"Stale {path}")
			ok = False

	if not ok:
		print("\nIcon atlases are stale. Run AtlasBuilder.py and commit rl_data/UI/icon_atlas.")
		report_build_notes(manifest, all_missing, errors, action="Expected")
		return False

	print("Icon atlases are current")
	report_build_notes(manifest, all_missing, errors, action="Expected")
	return True


if __name__ == "__main__":
	pygame.init()
	try:
		if "--check" in sys.argv[1:]:
			if not check_icon_atlases(): sys.exit(1)
		else:
			build_icon_atlases()
	finally:
		pygame.quit()
