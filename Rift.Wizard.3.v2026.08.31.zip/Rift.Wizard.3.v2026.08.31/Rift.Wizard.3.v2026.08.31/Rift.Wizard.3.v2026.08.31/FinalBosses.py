import random
from contextlib import redirect_stderr

from Monsters import *
from CommonContent import *
from RareMonsters import *
from Spells import *


class WizardTeleport(Spell):

	def on_init(self):
		self.range = 0
		self.name = "Void Tango"
		self.cool_down = 7
		self.requires_los = False
		self.description = "Teleport to a random tile\nThe Wizard teleports to Mordred's old location"

	def cast(self, x, y):
		old_loc = Point(self.caster.x, self.caster.y)
		choices = [t for t in self.caster.level.iter_tiles() if t.can_walk and not t.unit]

		if choices:
			target = random.choice(choices)
			for p in self.caster.level.get_points_in_line(self.caster, target):
				self.caster.level.leap_effect(p.x, p.y, Color(216, 27, 96), self.caster)
				yield
			self.caster.level.act_move(self.caster, target.x, target.y, teleport=True)

		for p in self.caster.level.get_points_in_line(self.caster.level.player_unit, old_loc):
			self.caster.level.leap_effect(p.x, p.y, Color(2, 136, 209), self.caster.level.player_unit)
			yield

		if self.caster.level.can_move(self.caster.level.player_unit, old_loc.x, old_loc.y, teleport=True):
			self.caster.level.act_move(self.caster.level.player_unit, old_loc.x, old_loc.y, teleport=True)


class MordredCorruption(Spell):

	def on_init(self):
		self.name = "Planar Interposition"
		self.description = "Corrupt reality, mixing the current realm with another"
		self.cool_down = 7
		self.range = 0
		self.num_exits = 0
		self.forced_difficulty = None

	def cast(self, x, y):

		gen_params = self.caster.level.gen_params.make_child_generator(difficulty=self.forced_difficulty or self.caster.level.level_no)
		gen_params.num_exits = self.num_exits
		gen_params.num_monsters = 25
		new_level = gen_params.make_level()

		# For the new level, pick some swaths of it.
		# For each tile in that swath, transport the tile and its contents to the new level
		# For units, remove then add them to make event subscriptions work...?
		chance = random.random() * .5 + .1
		targets = []

		num_portals = len(list(t for t in self.caster.level.iter_tiles() if isinstance(t.prop, Portal)))

		for i in range(len(new_level.tiles)):
			for j in range(len(new_level.tiles)):
				if random.random() > chance:
					if isinstance(self.caster.level.tiles[i][j].prop, Portal):
						if num_portals <= 1: continue
						else: num_portals -= 1
					targets.append((i, j))
		random.shuffle(targets)

		for i, j in targets:

			old_unit = self.caster.level.get_unit_at(i, j)
			# Do not corrupt out the player, their summons, mordred, or the caster (who)
			if old_unit:
				# Do not destroy mordred or the wizard
				if old_unit.is_player_controlled or old_unit == self.caster: continue
				if are_hostile(old_unit, self.caster): continue

			if old_unit: old_unit.kill(trigger_death_event=False)

			new_tile = new_level.tiles[i][j]

			if new_tile.is_chasm: self.caster.level.make_chasm(i, j)
			elif new_tile.is_floor(): self.caster.level.make_floor(i, j)
			else: self.caster.level.make_wall(i, j)

			cur_tile = self.caster.level.tiles[i][j]
			self.caster.level.set_tile_style(cur_tile, new_tile.tileset, cur_tile.chasm_type)

			unit = new_tile.unit

			if unit: new_level.remove_obj(unit)
			if unit and self.caster.level.can_stand(i, j, unit): self.caster.level.add_obj(unit, i, j)

			prop = new_tile.prop
			if prop:
				old_prop = cur_tile.prop
				if old_prop: self.caster.level.remove_prop(old_prop)
				self.caster.level.add_prop(prop, i, j)

			# Remove props from chasms and walls
			if cur_tile.prop and not cur_tile.is_floor():
				self.caster.level.remove_prop(cur_tile.prop)

			self.caster.level.show_effect(i, j, Tags.Translocation)
			if random.random() < .25: yield
		yield


class ForcedRespawn(Buff):

	def __init__(self, spawner):
		Buff.__init__(self)
		self.spawner = spawner
		self.spawn_name = spawner().name
		self.name = "Mordred's Evolution"
		import SteamAdapter
		self.unlock_achievement = SteamAdapter.unlock_achievement

	def on_init(self):
		self.owner_triggers[EventOnDamaged] = self.on_damage

	def on_damage(self, evt):
		if self.owner.cur_hp > 0: return
		if self.owner.has_buff(Soulbound): return
		self.owner.kill(trigger_death_event=False)
		self.owner.level.queue_spell(self.respawn())

	def respawn(self):
		owner = self.owner
		level = owner.level

		new_unit = self.spawner()
		new_unit.team = owner.team
		spawned = False


		p = level.get_summon_point(owner.x, owner.y, radius_limit=30, unit=new_unit)
		if p:
			level.add_obj(new_unit, p.x, p.y)
			spawned = True

		if not p:
			p = Point(9, 9)
			new_unit.x, new_unit.y = p.x, p.y
			pts = [t for t in new_unit.iter_occupied_points()]
			for t in pts: level.make_floor(t.x, t.y)

			tries = 0 # Give up if they manage to fill every single tile
			while True:
				obstructions = set() # rebuild every loop so empty means "just scanned clear"
				for pt in pts:
					obstruction = level.get_unit_at(pt.x, pt.y)
					if obstruction: obstructions.add(obstruction)

				if not obstructions:
					if level.can_stand(p.x, p.y, new_unit):
						level.add_obj(new_unit, p.x, p.y) # final guard in case something moved in after a yield
						spawned = True
					break

				if tries >= 50: break # could not clear a 3x3/5x5 footprint, hidden victory option

				u = obstructions.pop()
				randomly_teleport(u, 12) # attempt to evict one blocker
				tries += 1
				yield # let the teleport resolve, then rescan the footprint

		if spawned: new_unit.apply_buff(StunImmune(), 3)
		else: self.unlock_achievement("DENIED_ASCENDANCE") # boxed out mordred, they were unable to spawn next form

		yield

	def get_tooltip(self):
		if not self.spawn_name: self.spawn_name = self.spawner().name
		return ("On reaching 0 HP, transform into {name}", {'name': self.spawn_name})

def Mordred():
	unit = Unit()
	unit.name = "Mordred"
	unit.asset_variants = [(['char', '3x3_mordred'], 1), (['char', '5x5_mordred'], 2)]
	unit.tags = [Tags.Dark, Tags.Living]
	unit.is_final_boss = True
	unit.is_boss = True

	unit.shields = 7
	unit.gets_clarity = True

	teleport = WizardTeleport()

	beam = SimpleRangedAttack(name="Mordred's Gaze", damage=27, damage_type=Tags.Arcane, range=30, beam=True, melt=True, cool_down=2)
	touch = SimpleMeleeAttack(damage=300, damage_type=Tags.Dark)
	touch.name = "Mordred's Touch"

	corruption = MordredCorruption()
	corruption.forced_difficulty = 17
	unit.spells.append(corruption)

	unit.spells.append(teleport)
	unit.spells.append(touch)
	unit.spells.append(beam)

	unit.buffs.append(ForcedRespawn(MordredUnbound))

	unit.max_hp = 697
	unit.resists[Tags.Dark] = 50
	unit.resists[Tags.Poison] = 0
	return unit

class DevastatingGaze(Spell):

	def on_init(self):
		self.name = "Devastating Gaze"
		self.damage = 45
		self.cool_down = 2
		self.range = 30
		self.requires_los = False
		self.damage_type = [Tags.Arcane, Tags.Dark]

	def get_description(self):
		return "Corrupts reality in a wide beam"

	def get_ai_target(self, check_harm=False):
		wizards = [u for u in self.owner.level.units if u.is_player_controlled]
		if not wizards: return Spell.get_ai_target(self)
		wizard = wizards[0]
		if not self.can_cast(wizard.x, wizard.y): return Spell.get_ai_target(self)
		if not self.can_harm(wizard): return Spell.get_ai_target(self)
		return wizard

	def cast(self, x, y):
		caster = self.caster
		level = caster.level

		dmg = self.get_stat('damage')
		dtypes = self.damage_type

		gen_params = level.gen_params.make_child_generator(random.randint(15, 19))
		gen_params.num_exits = 0
		gen_params.num_monsters = 30
		gen_params.bosses = [b for b in gen_params.bosses if b.radius == 0]

		self.new_level = gen_params.make_level(check_terrain=False)

		def hit_tile(pt):
			for dtype in dtypes: level.deal_damage(pt.x, pt.y, dmg, dtype, self)
			if level.tiles[pt.x][pt.y].is_wall(): level.make_floor(pt.x, pt.y)
			if random.random() < .5: corrupt(pt.x, pt.y,level, self.new_level)

		points_hit = set(caster.iter_occupied_points())

		for p in level.get_points_in_line(caster, Point(x, y)):
			for q in level.get_points_in_ball(p.x, p.y, 3):
				if q not in points_hit:
					hit_tile(q)
					points_hit.add(q)
		yield

class MordredShieldRegenBuff(Buff):

	def on_init(self):
		self.name = "Regenerating Shields"
		self.description = "Regenerate [7 SH:shields] each turn"
		self.color = Tags.Arcane.color

	def on_advance(self):
		self.owner.add_shields(7)

def MordredUnbound():
	unit = Unit()
	unit.tags = [Tags.Dark, Tags.Living]
	unit.name = "Mordred, Unbound"
	unit.asset_name = '3x3_mordred'
	unit.asset_variants = [(['char', '5x5_mordred'], 2)]
	unit.radius = 1
	unit.is_final_boss = True
	unit.is_boss = True

	unit.max_hp = 6970
	unit.shields = 77

	unit.resists[Tags.Dark] = 50
	unit.resists[Tags.Arcane] = 50

	unit.gets_clarity = True
	unit.burrowing = True
	unit.flying = True

	def caress(caster, target):
		if target.is_alive():
			if target.is_player_controlled: return
			else: target.team = caster.team

	touch = SimpleMeleeAttack(damage=300, damage_type=Tags.Dark, onhit=caress, onhit_description="If the target survives, they become Mordred's servant", drain=True)
	touch.name = "Mordred's Caress"

	teleport = MonsterTeleport()
	teleport.range = 30
	teleport.cool_down = 6
	teleport.requires_los = False

	unit.spells = [DevastatingGaze(), touch, teleport]

	unit.buffs = [MordredShieldRegenBuff(), ForcedRespawn(MordredAscendant)]

	return unit

class LifeVortex(Spell):

	def on_init(self):
		self.name = "Life Vortex"
		self.description = "Steal health from all creatures in line of sight"
		self.damage = 99
		self.cool_down = 3
		self.range = 0
		self.damage_type = Tags.Dark

	def can_cast(self, x, y):
		caster = self.caster
		if caster.cur_hp >= caster.max_hp: return False
		if not any(u != caster for u in caster.level.get_units_in_los(caster)): return False
		return Spell.can_cast(self, x, y)

	def get_impacted_tiles(self, x, y):
		return self.caster.level.get_tiles_in_los(self.caster)

	def can_threaten(self, x, y):
		return self.owner.level.can_see(self.owner.x, self.owner.y, x, y)

	def bolt(self, target, dmg):
		damage = target.deal_damage(dmg, self.damage_type, self)
		yield
		line = [p for p in self.caster.level.get_points_in_line(target, self.caster, find_clear=True)[1:-1]]
		for p in line:
			self.caster.level.show_effect(p.x, p.y, self.damage_type, minor=True)
			yield

		for i in range(3): yield

		for p in reversed(line):
			self.caster.level.show_effect(p.x, p.y, Tags.Blood, minor=True)
			yield

		if damage: self.caster.deal_damage(-damage, Tags.Heal, self)

	def cast_instant(self, x, y):
		total = 0
		dmg = self.get_stat('damage')
		caster = self.caster
		targets = [u for u in caster.level.get_units_in_los(caster)]
		for u in targets:
			if u == caster: continue
			self.owner.level.queue_spell(self.bolt(u, dmg))

class MordredCorruptionAura(Buff):

	def on_init(self):
		self.name = "Reality Corrosion"
		self.radius = 9

	def get_description(self):
		return ("Each turn, unoccupied tiles within {radius} tiles have a chance to be corrupted", {'radius': self.radius})

	def on_advance(self):
		owner = self.owner
		level = owner.level

		gen_params = level.gen_params.make_child_generator(random.randint(15, 19))
		gen_params.num_exits = 0
		gen_params.num_monsters = 30
		gen_params.bosses = [b for b in gen_params.bosses if b.radius == 0]

		self.new_level = gen_params.make_level(check_terrain=False)

		def hit_tile(pt):
			if level.tiles[pt.x][pt.y].is_wall(): level.make_floor(pt.x, pt.y)
			if random.random() < .33: corrupt(pt.x, pt.y,level, self.new_level)

		targets = level.get_tiles_in_ball(owner.x, owner.y, self.radius)
		random.shuffle(targets)

		for tile in targets:
			if not level.get_unit_at(tile.x, tile.y):
				hit_tile(tile)

def MordredAscendant():
	unit = Unit()
	unit.tags = [Tags.Dark, Tags.Living]
	unit.name = "Mordred, Ascendant"
	unit.asset_name = '5x5_mordred'
	unit.radius = 2
	unit.is_final_boss = True
	unit.is_boss = True

	unit.max_hp = 9999
	unit.shields = 99

	unit.gets_clarity = True
	unit.burrowing = True
	unit.flying = True

	beam = WideBeam(name= "Annihilation Beam", damage= 99, range=9, damage_type=Tags.Arcane, requires_los=False)


	unit.spells = [LifeVortex(), beam]

	for tag in damage_tags: unit.resists[tag] = 99

	unit.buffs = [PrismaticBuff(), MordredCorruptionAura()]

	return unit

# Corrupt the tile at x, y on cur_level using the same tile from new_level
def corrupt(x, y, cur_level, new_level):
	# Do not change tiles with units on them, too complex
	if cur_level.get_unit_at(x, y): return
	new_tile = new_level.tiles[x][y]

	if new_tile.is_chasm: cur_level.make_chasm(x, y)
	elif new_tile.is_floor(): cur_level.make_floor(x, y)
	else: cur_level.make_wall(x, y)
	
	cur_tile = cur_level.tiles[x][y]				
	cur_level.set_tile_style(cur_tile, new_tile.tileset, cur_tile.chasm_type)

	unit = new_tile.unit

	if unit and cur_level.can_stand(x, y, unit):
		new_level.remove_obj(unit)
		cur_level.add_obj(unit, x, y)

	prop = new_tile.prop
	if prop:
		old_prop = cur_tile.prop
		if old_prop: cur_level.remove_prop(old_prop)
		cur_level.add_prop(prop, x, y)

	# Remove props from chasms and walls
	if cur_tile.prop and not cur_tile.is_floor():
		cur_level.remove_prop(cur_tile.prop)

	cur_level.show_effect(x, y, Tags.Translocation)

class ChaosBite(Spell):

	def on_init(self):
		self.name = "Chaos Bite"
		self.damage_type = [Tags.Fire, Tags.Lightning, Tags.Physical]
		self.description = "Deals damage in an arc"
		self.range = 1.5
		self.melee = True
		self.can_target_self = False
		self.damage = 40

	def get_impacted_tiles(self, x, y):
		adj_points = [p for p in self.caster.level.get_points_in_ball(self.caster.x, self.caster.y, self.caster.radius + 1, diag=True) if distance(p, self.caster, diag=True) > self.caster.radius]
		aoe = sorted(adj_points, key=lambda p: distance(p, Point(x, y)))[:5]
		return aoe

	def cast(self, x, y):
		damage = self.get_stat('damage')
		deal_damage = self.caster.level.deal_damage
		for p in self.get_impacted_tiles(x, y):
			for dtype in self.damage_type: deal_damage(p.x, p.y, damage, dtype, self)
			for i in range(3): yield

class ChaosBreath(Spell):

	def on_init(self):
		self.name = "Chaos Breath"
		self.damage = 13
		self.range = 32
		self.cool_down = 5
		self.angle = math.pi / 12.0
		self.requires_los = False
		self.description = "Cone attack\nCorrupts space"
		self.damage_type = [Tags.Fire, Tags.Lightning, Tags.Physical]
		self.damage_type_random = True

	def aoe(self, x, y):
		target = Point(x, y)
		return Burst(self.caster.level, 
				     self.caster,
				     self.get_stat('range'), 
				     burst_cone_params=BurstConeParams(target, self.angle), 
				     ignore_walls=True)


	# Always cast if possible, in general direction of the wizard
	def get_ai_target(self):
		wizard = self.caster.level.player_unit
		# For unittests or other weird scenarios
		if not wizard: return Spell.get_ai_target(self)
		if not self.can_harm(wizard): return Spell.get_ai_target(self)
		if distance(wizard, self.caster) >= self.get_stat('range'):
			return [p for p in self.owner.level.get_points_in_line(self.caster, wizard) if distance(p, self.caster) < self.get_stat('range')][-1]
		else: return wizard

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		getu = level.get_unit_at
		deal_damage = level.deal_damage

		gen_params = level.gen_params.make_child_generator(random.randint(15, 19))
		gen_params.num_exits = 0
		gen_params.num_monsters = 50
		gen_params.bosses = [b for b in gen_params.bosses if b.radius == 0]
		new_level = gen_params.make_level(check_terrain=False)

		damage = self.get_stat('damage')
		dtypes = self.damage_type

		for stage in self.aoe(x, y):
			for point in stage:
				if level.tiles[point.x][point.y].unit == caster: continue
				unit = getu(point.x, point.y)
				dtype = random.choice(dtypes)
				if unit: deal_damage(point.x, point.y, damage, dtype, self)
				elif random.random() < .5:
					deal_damage(point.x, point.y, damage, dtype, self)
					corrupt(point.x, point.y, level, new_level)
			yield

class SnakeShedding(Buff):

	def on_init(self):
		self.description = "Each turn, summon 3 Snakes"
		self.color = Tags.Chaos.color
		self.snake_opts = [Snake, FireSnake, DeathSnake, GoldenSnake, TwoHeadedSnake]

	def advance(self):
		for i in range(3):
			unit = random.choice(self.snake_opts)()
			self.summon(unit, radius=7, sort_dist=False)

def Jormungandr():
	unit = Unit()
	unit.name = "Jormungandr"
	unit.max_hp = 9666
	unit.radius = 2
	unit.asset_name = 'beast_of_chaos'

	unit.spells = [WizardChaosWord(), ChaosBreath(), ChaosBite()]
	unit.buffs = [SnakeShedding(), AdaptiveArmorBuff(10)]

	unit.burrowing = True

	unit.tags = [Tags.Chaos, Tags.Lightning, Tags.Fire, Tags.Living]

	unit.resists[Tags.Fire] = 50
	unit.resists[Tags.Lightning] = 50
	unit.resists[Tags.Physical] = 50

	return unit

class FrogPopeDefense(Buff):

	def on_init(self):
		self.name = "Pope Armor"
		self.description = "Cannot lose more than 700 HP in one turn"
		self.damage_limit = 700

	def on_applied(self, owner):
		owner.set_damage_floor(self, owner.cur_hp - self.damage_limit)

	def on_unapplied(self):
		self.owner.remove_damage_floor(self)

	def on_advance(self):
		self.owner.set_damage_floor(self, self.owner.cur_hp - self.damage_limit)

class FrogPopeSoulTax(Spell):

	def on_init(self):
		self.name = "Blood Tax"
		self.description = "Steal 30% of the target's HP\nRedistribute it among Frog Pope's allies\nDoes not trigger on-damage effects"
		self.range = 99
		self.cool_down = 10

	def get_ai_target(self):
		wizards = [u for u in self.owner.level.units if u.is_player_controlled]
		if not wizards: return None
		wizard = wizards[0]
		if not self.can_cast(wizard.x, wizard.y): return None
		return wizard

	def cast(self, x, y):

		for p in self.owner.level.get_points_in_line(self.caster, Point(x, y))[1:-1]:
			self.owner.level.show_effect(p.x, p.y, Tags.Blood, minor=True)
			self.owner.level.show_effect(p.x, p.y, Tags.Holy, minor=True)
			yield

		target = self.owner.level.get_unit_at(x, y)

		stolen = (target.cur_hp * 3) // 10

		target.cur_hp -= stolen
		target.cur_hp = max(1, target.cur_hp)

		self.caster.level.show_effect(x, y, Tags.Blood)

		wounded = [u for u in self.owner.level.units if u.cur_hp < u.max_hp and not are_hostile(u, self.caster)]
		if not wounded: wounded = [self.caster]
		per_wounded = stolen // len(wounded)
		extra = stolen % len(wounded)

		random.shuffle(wounded)

		for u in wounded:
			heal = per_wounded
			if extra:
				extra -= 1
				heal += 1

			if heal <= 0: continue

			u.heal(heal, self)
			self.owner.level.show_path_effect(target, u, Tags.Blood, minor=True, inclusive=False)
			yield

def FrogPopeRandomFrog():
	f = random.choice([GiantToad, VoidToad, FlameToad, ToadPriest, ToadKnight, ToadNightmareSorcerer, WormWizard, SwampQueen])
	return f()

class FrogPopeHop(Spell):

	def on_init(self):
		self.name = "Hop"
		self.description = "Leap and damage adjacent enemies"
		self.damage = 35
		self.range = 10
		self.cool_down = 3

	def can_cast(self, x, y):
		return self.owner.level.can_stand(x, y, self.caster)

	def get_ai_target(self):
		options = [p for p in self.owner.level.get_points_in_ball(self.owner.x, self.owner.y, self.get_stat('range')) if self.owner.level.can_stand(p.x, p.y, self.caster)]
		if options: return random.choice(options)
		else: return None

	def cast(self, x, y):

		for p in self.owner.iter_occupied_points():
			self.owner.level.show_effect(p.x, p.y, Tags.Physical)

		yield

		self.owner.level.act_move(self.owner, x, y, teleport=True)

		yield

		for p in self.owner.level.get_points_in_ball(self.owner.x, self.owner.y, self.owner.radius+1, diag=True):
			if distance(p, self.owner, diag=True) > self.owner.radius:
				self.owner.level.deal_damage(p.x, p.y, self.get_stat('damage'), Tags.Physical, self)

		yield

class EdictOfWorms(Spell):

	def on_init(self):
		self.name = "Edict of Worms"
		self.damage = 100
		self.damage_type = Tags.Holy
		self.range = 0
		self.can_target_self = True
		self.cool_down = 12

	def get_description(self):
		return "Deals damage to all enemies\nIf they die, raise a Worm Shambler from their body"

	def get_ai_target(self):
		return self.owner

	def cast(self, x, y):
		c = self.caster
		lvl = c.level

		targets = [u for u in lvl.units if are_hostile(u, c)]
		dmg = self.get_stat('damage')
		dtype = self.damage_type
		for t in targets:
			lvl.show_path_effect(c, t, [Tags.Poison, Tags.Blood, Tags.Holy])
			t.deal_damage(dmg, dtype, self)
			for i in range(3): yield
			if not t.is_alive(): self.summon(WormShambler(t.max_hp), target=t)


def FrogPope():
	unit = Unit()
	unit.name = "Pope the Frog"
	unit.max_hp = 14000
	unit.radius = 2
	unit.asset_name = 'frog_prophet'

	unit.tags = [Tags.Living, Tags.Dark, Tags.Holy]

	frog_summon = SimpleSummon(FrogPopeRandomFrog, num_summons=7, radius=5, sort_dist=False, cool_down=6)
	frog_summon.name = "Swamp Horde"
	frog_summon.description = "Summon a gang of hideous friends from the swamp"

	tongue_attack = PullAttack(damage=37, range=7, color=Tags.Tongue.color)
	tongue_attack.name = "Tongue Lash"

	unit.spells = [frog_summon, FrogPopeSoulTax(), EdictOfWorms(), tongue_attack]

	unit.buffs = [FrogPopeDefense()]

	return unit


class BeatleVoidBeam(Spell):

	def on_init(self):
		self.name = "Insanity Beam"
		self.damage = 19
		self.range = 30
		self.requires_los = False
		self.description = "Corrupts reality in a wide beam"
		self.damage_type = Tags.Arcane
		self.cool_down = 3

	def cast(self, x, y):
		
		gen_params = self.caster.level.gen_params.make_child_generator(random.randint(15 , 19))		
		gen_params.num_exits = 0
		gen_params.num_monsters = 50

		gen_params.bosses = [b for b in gen_params.bosses if b.radius == 0] 

		self.new_level = gen_params.make_level(check_terrain=False)

		points_hit = set(self.owner.iter_occupied_points())
		to_hit = []
		for p in self.owner.level.get_points_in_line(self.caster, Point(x, y)):
			if p in points_hit: continue
			self.hit_tile(p)
			points_hit.add(p)
			i = 0
			for q in self.owner.level.get_points_in_ball(p.x, p.y, 3):
				i += 1
				if q not in points_hit:
					self.hit_tile(q)
					if i % 5 == 0: yield
					points_hit.add(q)

	def hit_tile(self, q):
		self.caster.level.deal_damage(q.x, q.y, self.get_stat('damage'), Tags.Arcane, self)
		if self.caster.level.tiles[q.x][q.y].is_wall(): self.caster.level.make_floor(q.x, q.y)
		if random.random() < .5: corrupt(q.x, q.y, self.caster.level, self.new_level)

class LayVoidEggs(Spell):

	def on_init(self):
		self.name = "Void Eggs"
		self.description = "Summon 6 void eggs\nIf allowed to hatch, they become horrible void creatures\nTeleport away after laying eggs"
		self.num_summons = 6
		self.cool_down = 7
		self.range = 8

	def get_ai_target(self):
		opts = [p for p in self.owner.level.get_points_in_ball(self.owner.x, self.owner.y, self.get_stat('range')) if self.can_cast(p.x, p.y)]
		if opts: return random.choice(opts)

	def cast(self, x, y):
		spawner = random.choice([VoidDrake, MindDevourer, StarSwimmer, MindMaggotQueen, VoidToad])
		ex = spawner()
		for i in range(self.get_stat('num_summons')):
			unit = Unit()
			unit.stationary = True
			unit.max_hp = 120
			unit.tags = [Tags.Arcane]
			unit.resists[Tags.Arcane] = 75

			unit.name = "%s Egg" % ex.name
			unit.asset_name = 'void_egg'

			unit.buffs.append(MatureInto(spawner, 14))
			unit = self.summon(unit, target=Point(x, y), radius=4, sort_dist=False)
			if unit: self.owner.level.show_beam(self.caster, unit, Tags.Arcane, minor=True, inclusive=False)
			yield

		randomly_teleport(self.caster, 99, flash=True, requires_los=False)

class BeatleShields(Spell):

	def on_init(self):
		self.name = "Shield Tide"
		self.description = "All allies gain 3 SH\nAll enemies lose 3 SH"
		self.cool_down = 3
		self.range = 0

	def cast(self, x, y):
		targets = list(self.owner.level.units)
		random.shuffle(targets)
		for t in targets:
			if are_hostile(self.caster, t): t.remove_shields(3)
			else: t.add_shields(3)
			if random.random() < .25: yield

class QueenReincarnation(ReincarnationBuff):
	def __init__(self):
		super().__init__(lives=10)
		self.name = "Repeating Insanity"

	def on_death(self, evt):
		owner = self.owner
		level = self.owner.level
		for u in level.get_units_in_los(owner):
			if are_friendly(self.owner, u): continue
			if u.is_player_controlled: continue
			if Tags.Living not in u.tags: continue
			level.show_path_effect(owner, u, Tags.Arcane)
			u.apply_buff(BerserkBuff(), 12)
		super().on_death(evt)

	def get_tooltip(self):
			return ("Berserk all [Living] enemies in line of sight for 12 turns\nThen reincarnate after being killed ({val} times)", {"val":self.lives})

def ApocalypseBeatle():
	unit = Unit()
	unit.name = "Insanity Queen"
	unit.max_hp = 919
	unit.radius = 2
	unit.asset_name = 'insanity_queen'
	unit.flying = True
	unit.tags = [Tags.Living, Tags.Arcane, Tags.Dark]
	unit.spells = [BeatleVoidBeam(), LayVoidEggs(), BeatleShields()]
	unit.buffs = [AdaptiveArmorBuff(25), QueenReincarnation()]
	return unit


class OphanDefense(Buff):

	def on_init(self):
		self.description = "Redirect all damage to allies"

	def on_applied(self, owner):
		def ophan_handler(amount, damage_type, source, redirect_chain):
			if amount <= 0: return None
			lvl = owner.level
			allies = owner.get_allies()
			if not allies: return None
			scapegoat = random.choice(allies)
			dealt = lvl.deal_redirected_damage(self, scapegoat.x, scapegoat.y, amount, damage_type, source, redirect_chain)
			if dealt: lvl.show_path_effect(owner, scapegoat, Tags.Holy, minor=True, inclusive=False)
			return dealt

		owner.grant_redirect(self, ophan_handler)

	def on_unapplied(self):
		self.owner.remove_redirect(self)

class SummonFallen(Spell):

	def on_init(self):
		self.name = "Summon Fallen Angels"
		self.description = "Summon 2 Fallen Angels"
		self.cool_down = 10
		self.range = 0

	def cast(self, x, y):
		for i in range(2):
			unit = FallenAngel()
			self.summon(unit, radius=6, sort_dist=False)
			yield

	def get_unit_extra_examine_tooltips(self):
		return [FallenAngel()]

class OphanBlast(Spell):

	def on_init(self):
		self.name = "Ophan Blast"
		self.description = "Corrupts reality around each enemy in line of sight"
		self.range = 0
		self.radius = 3
		self.cool_down = 3
		self.damage = 12
		self.damage_type = [Tags.Dark, Tags.Holy]

	def get_ai_target(self):
		return self.owner

	def can_threaten(self, x, y):
		return self.caster.level.can_see(self.caster.x, self.caster.y, x, y)

	def cast(self, x, y):
		gen_params = self.caster.level.gen_params.make_child_generator(random.randint(15 , 19))		
		gen_params.num_exits = 0
		gen_params.num_monsters = 50

		gen_params.bosses = [b for b in gen_params.bosses if b.radius == 0] 

		new_level = gen_params.make_level(check_terrain=False)
		damage = self.get_stat('damage')

		caster = self.caster
		level = caster.level
		tiles = level.tiles
		dealdmg = level.deal_damage
		targets = [u for u in level.get_units_in_los(caster) if are_hostile(caster, u)]
		for u in targets:
			level.show_beam(caster, u, Tags.Holy)
			for stage in Burst(level, u, self.radius, ignore_walls=True):
				for p in stage:
					if not level.is_point_in_bounds(p): continue
					if tiles[p.x][p.y].unit == caster: continue
					dealdmg(p.x, p.y, damage, Tags.Dark, self)
					dealdmg(p.x, p.y, damage, Tags.Holy, self)
					corrupt(p.x, p.y, level, new_level)
				yield

def Ophan():
	unit = Unit()
	unit.name = "Ophan"
	unit.shields = 7
	unit.max_hp = 7

	unit.tags = [Tags.Holy, Tags.Dark]

	unit.flying = True
	unit.stationary = True

	unit.radius = 2
	unit.asset_name = 'the_messenger'

	teleport = MonsterTeleport()
	teleport.range = 30
	teleport.cool_down = 3
	teleport.requires_los = False

	unit.resists[Tags.Holy] = 100
	unit.resists[Tags.Dark] = 100
	unit.resists[Tags.Poison] = 0

	unit.spells = [OphanBlast(), SummonFallen(), teleport]
	
	unit.buffs = [OphanDefense(), ReincarnationBuff(1), RegenShieldsBuff(1)]
	return unit

class SoulbinderBuff(Buff):

	def on_init(self):
		self.name = "Soulbinder"

	def get_description(self):
		if self.owner: return ("Each turn, a random ally becomes soulbound to {name}", {'name': self.owner.name})
		return "Each turn, a random ally becomes soulbound to Yaldabaoth"

	def get_target(self):
		candidates = self.owner.get_allies()
		candidates = [u for u in candidates if not u.has_buff(Soulbound)]
		if not candidates: return None
		return random.choice(candidates)

	def on_advance(self):
		u = self.get_target()
		if not u: return
		o = self.owner
		o.level.show_path_effect(o, u, Tags.Holy)
		buff = Soulbound(o)
		u.apply_buff(buff)

class HeavensBreath(BreathWeapon):

	def on_init(self):
		self.name = "Heaven's Breath"
		self.damage = 45
		self.damage_type = Tags.Holy
		self.requires_los = False
		self.ignore_walls = True

	def get_description(self):
		return "Cone attack\nInflicts 3 turns of [fear]\nHeals allies\nMelts walls"

	def per_square_effect(self, x, y, damage):
		caster = self.caster
		lvl = caster.level
		unit = lvl.get_unit_at(x, y)

		if not lvl.tiles[x][y].is_chasm: lvl.make_floor(x, y)

		if unit:
			if are_friendly(caster, unit): unit.heal(damage, self)
			else: unit.apply_buff(FearBuff(), 3); unit.deal_damage(damage, Tags.Holy, self)
		else: lvl.deal_damage(x, y, damage, Tags.Holy, self)

class CorruptionAura(Buff):

	def on_init(self):
		self.name = "Corruption Aura"
		self.radius = 7

	def get_description(self):
		return ("Each turn, unoccupied tiles within {radius} tiles have a chance to be corrupted", {'radius': self.radius})

	def on_advance(self):
		o = self.owner
		lvl = o.level
		for tile in lvl.get_tiles_in_ball(o.x, o.y, self.radius):
			if tile.unit: continue # no units
			if tile.prop: continue # no props
			if random.random() < 0.5: continue
			if tile.is_wall(): random.choice([lvl.make_floor, lvl.make_chasm])(tile.x, tile.y)
			elif tile.is_floor(): random.choice([lvl.make_wall, lvl.make_chasm])(tile.x, tile.y)
			elif tile.is_chasm: random.choice([lvl.make_floor, lvl.make_wall])(tile.x, tile.y)
			else: continue
			lvl.show_effect(tile.x, tile.y, Tags.Holy, minor=True)

def Yaldabaoth():
	unit = Unit()
	unit.name = "Yaldabaoth"
	unit.max_hp = 9000
	unit.tags = [Tags.Arcane, Tags.Chaos, Tags.Holy, Tags.Living]
	unit.flying = True
	unit.burrowing = True

	unit.resists[Tags.Fire] = 75
	unit.resists[Tags.Physical] = 75
	unit.resists[Tags.Lightning] = 75
	unit.resists[Tags.Arcane] = 75
	unit.resists[Tags.Holy] = 100
	unit.resists[Tags.Dark] = -50

	unit.radius = 2
	unit.asset_name = "yaldabaoth"

	archon_summon = SimpleSummon(ArchonPurifier, num_summons=7, cool_down=16, global_summon=True, path_effect=Tags.Holy, radius=0)
	archon_summon.name = "Summon Purifiers"
	breath = HeavensBreath()
	breath.range = 9 # on_init gets run before range/cool_down defaults are assigned
	breath.cool_down = 0
	unit.spells = [archon_summon, breath]

	soulbinder = SoulbinderBuff()
	corruptionaura = CorruptionAura()

	unit.buffs = [soulbinder, corruptionaura]
	return unit


def TheGardener():
	u = Unit()
	u.name = "The Gardener"
	u.max_hp = 42000
	u.tags = [Tags.Arcane, Tags.Nature, Tags.Living]

	u.resists[Tags.Fire] = -75
	u.resists[Tags.Physical] = 75
	u.resists[Tags.Arcane] = 100

	u.radius = 2

	def prune_hp(caster, target): target.max_hp = max(target.cur_hp, 1)
	prune = SimpleMeleeAttack(damage=99, onhit=prune_hp, onhit_description="Target's max HP is set equal to their current HP", drain=True)
	prune.name = "Prune"

	prison = PrisonOfThorns()
	prison.tags = []
	prison.max_charges = 0
	prison.cool_down = 3
	prison.range = 12

	u.spells = [prune, prison]

	queen_reinforcements = SummonReinforcements(ThornQueen, 12, 50, Tags.Arcane)
	tree_aura = GeneratorBuff(BrainTree, 0.75, global_summon=True, num_summons=3)
	regen = HealAuraBuff(100, 8, heal_self=True)

	u.buffs = [queen_reinforcements, tree_aura, regen]

	return u

class GaiasBlessingBuff(Buff):

	def on_init(self):
		self.name = "Gaia's Blessing"
		self.description = "Each turn, regenerate HP equal to the remaining duration and gain [3 SH:shields]"
		self.stack_type = STACK_DURATION
		self.color = Tags.Nature.color

	def on_advance(self):
		self.owner.heal(self.turns_left, self)
		self.owner.add_shields(3)


class GaiasVengeance(Buff):

	def on_init(self):
		self.name = "Gaia's Vengeance"
		self.description = "When an ally dies, allies gain Gaia's Blessing for 10 turns"
		self.color = Tags.Nature.color
		self.global_triggers[EventOnDeath] = self.on_death

	def on_death(self, evt):
		if are_hostile(self.owner, evt.unit): return
		targets = [u for u in self.owner.level.units if not are_hostile(u, self.owner)]
		if not targets: return
		for u in targets: u.apply_buff(GaiasBlessingBuff(), 10)

	def get_unit_extra_examine_tooltips(self):
		return [GaiasBlessingBuff()]

class GaiaStormSpell(Spell):

	def on_init(self):
		self.name = "Nature's Fury"
		self.description = "Summon Blizzards, Storm Clouds, and Rain Clouds around enemies"
		self.range = 0
		self.cool_down = 3
		self.radius = 2
		self.cloud_types = [RainCloud, BlizzardCloud, StormCloud]

	def get_ai_target(self):
		return self.caster

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		for u in caster.get_hostiles():
			cloud_type = random.choice(self.cloud_types)
			for stage in Burst(level, u, self.radius):
				for p in stage: self.caster.level.add_obj(cloud_type(caster), p.x, p.y)
				yield

def Gaia():
	u = Unit()
	u.radius = 2
	u.name = 'Gaia'
	u.asset_name = '5x5_gaia'
	u.tags = [Tags.Living, Tags.Nature]
	u.max_hp = 4000
	u.shields = 40
	u.burrowing = True

	u.resists[Tags.Poison] = 100
	u.resists[Tags.Physical] = 75
	u.resists[Tags.Fire] = 75
	u.resists[Tags.Lightning] = 75
	u.resists[Tags.Ice] = 75

	quake = WizardEarthquake()
	quake.radius = 12
	quake.damage = 50
	quake.cool_down = 3
	quake.damage_type = Tags.Physical

	u.spells = [quake, GaiaStormSpell()]
	u.buffs = [GaiasVengeance(), SummonReinforcements(EarthElemental, 40, 75, Tags.Nature)]

	return u

class Inversion(Spell):

	def on_init(self):
		self.name = "Inversion"
		self.description = "Unoccupied floors become chasms\nUnoccupied chasms become walls\nWalls become floors"
		self.range = 0
		self.cool_down = 3

	def get_ai_target(self):
		return self.caster

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		for tile in level.iter_tiles():
			if tile.unit or tile.prop: continue
			if tile.is_floor(): level.make_chasm(tile.x, tile.y)
			elif tile.is_chasm: level.make_wall(tile.x, tile.y)
			elif tile.is_wall(): level.make_floor(tile.x, tile.y)
			if random.random() < .2: level.show_beam(caster, tile, Tags.Dark); yield
		yield


class CrownOfContradictions(Buff):

	def on_init(self):
		self.name = "Crown of Contradictions"
		self.description = "Negative resistances are treated as positive when calculating incoming damage"

	def on_applied(self, owner):
		def resist_inversion_handler(amount, damage_type, source, redirect_chain):
			if amount <= 0: return None # ignore healing
			resist = owner.resists.get(damage_type, 0)
			if resist >= 0: return None # do nothing for positive resistance

			# temporarily flip the resist, then flip it back
			owner.resists[damage_type] = -resist
			try: return owner.level.deal_redirected_damage(self, owner.x, owner.y, amount, damage_type, source, redirect_chain)
			finally: owner.resists[damage_type] = resist

		owner.grant_redirect(self, resist_inversion_handler)

	def on_unapplied(self):
		self.owner.remove_redirect(self)

class DarkOfferingsBuff(Buff):

	def on_init(self):
		self.name = "Dark Offerings"
		self.description = "Heal for damage dealt by [Dark], [Demon], or [Undead] units"
		self.tag_check = [Tags.Demon, Tags.Undead, Tags.Dark]
		self.global_triggers[EventOnDamaged] = self.on_damaged

	def on_damaged(self, evt):
		if evt.damage < 1: return
		if not evt.source: return
		if not evt.source.owner: return
		tags = getattr(evt.source.owner, 'tags', None)
		if not tags: return
		if not any(tag in self.tag_check for tag in tags): return
		self.owner.heal(evt.damage, self)

class HellfireEruption(Spell):

	def on_init(self):
		self.name = "Hellfire Eruption"
		self.damage = 12
		self.radius = 2
		self.range = 0
		self.damage_type = [Tags.Dark, Tags.Fire]

	def get_description(self):
		return "Damages units in a burst around each chasm"

	def get_ai_target(self):
		if any(t for t in self.get_impacted_tiles(self.caster.x, self.caster.y) if t.unit and are_hostile(self.caster, t.unit) and self.can_harm(t.unit)):
			return self.caster
		return None

	def get_impacted_tiles(self, x, y):
		level = self.caster.level
		rad = self.get_stat('radius')
		to_hit = set()
		for tile in level.iter_tiles():
			if not tile.is_chasm: continue
			for t in level.get_tiles_in_ball(tile.x, tile.y, rad):
				to_hit.add(t)
		return list(to_hit)

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		dmg = self.get_stat('damage')
		to_hit = self.get_impacted_tiles(x, y)
		random.shuffle(to_hit)
		idx = 0
		for p in to_hit:
			idx = 0 if idx else 1
			level.deal_damage(p.x, p.y, dmg, self.damage_type[idx], self)
			if random.random() < .1: yield
		yield

def RandomHellspawn():
	f = random.choice([GoldenBull, Pan, FleshFiend, AshFiend, InsanityFiend, FieryTormentorMass, FloatingEyeMass, BloodKnight])
	return f()

def Bafflement():
	u = Unit()
	u.radius = 2
	u.name = "Bafflement, Demon King"
	u.asset_name = '5x5_demon_king'
	u.max_hp = 12345
	u.tags = [Tags.Demon, Tags.Dark, Tags.Fire]
	u.resists[Tags.Dark] = 100
	u.resists[Tags.Fire] = 75
	u.burrowing = True
	u.flying = True

	summon = SimpleSummon(RandomHellspawn, num_summons=5, radius=30, sort_dist=False, cool_down=5)
	summon.name = "Empty the Depths"
	summon.description = "Summon ferocious fiends from every plane of hell"
	summon.get_unit_extra_examine_tooltips = lambda: None

	u.spells = [summon, Inversion(), HellfireEruption()]
	u.buffs = [CrownOfContradictions(), DarkOfferingsBuff()]

	return u

class SnowQueensGazeSpell(Spell):

	def on_init(self):
		self.name = "Snow Queen's Gaze"
		self.range = 0
		self.damage = 10
		self.tt_color = Tags.Ice.color
		self.damage_type = [Tags.Ice]

	def get_impacted_tiles(self, x, y):
		for u in self.caster.level.units:
			if are_friendly(self.caster, u):
				if u == self.caster: continue
				yield u

	def get_ai_target(self):
		return self.caster

	def can_threaten(self, x, y):
		level = self.caster.level
		for unit in level.units:
			if unit == self.caster or level.are_hostile(self.caster, unit): continue
			if level.can_see(unit.x, unit.y, x, y): return True
		return False

	def get_description(self):
		return "A bolt of ice shoots forth from allies at a random enemy in their line of sight"

	def cast(self, x, y):
		bolts = []
		for unit in self.caster.level.units:
			if unit == self.caster or self.caster.level.are_hostile(self.caster, unit): continue
			possible_targets = [u for u in self.caster.level.units if self.caster.level.are_hostile(unit, u) and self.caster.level.can_see(unit.x, unit.y, u.x, u.y)]
			if possible_targets:
				target = random.choice(possible_targets)
				bolts.append(self.bolt(unit, target))

		while bolts:
			bolts = [b for b in bolts if next(b)]
			yield

	def bolt(self, source, target):
		for point in Bolt(self.caster.level, source, target):
			self.caster.level.show_effect(point.x, point.y, Tags.Ice)
			yield True
		target.deal_damage(self.get_stat('damage'), Tags.Ice, self)
		yield False

class SnowQueenBlizzardBeacon(Buff):

	def on_init(self):
		self.name = "Heart of the Blizzard"
		self.color = Tags.Ice.color

	def get_description(self):
		return "Each turn, summon [Blizzards:ice] over enemy units"

	def on_advance(self):
		add_obj = self.owner.level.add_obj
		for u in self.owner.get_hostiles():
			for p in u.iter_occupied_points():
				add_obj(BlizzardCloud(self.owner), p.x, p.y)

class SnowQueenUnseated(Buff):

	def on_init(self):
		self.name = "Unseated"
		self.color = Tags.Ice.color
		self.owner_triggers[EventOnDamaged] = self.on_damage

	def get_description(self):
		return "At 0 HP, transform into Snow Queen, Dethroned and summon Frost Saber"

	def on_damage(self, evt):
		if self.owner.cur_hp > 0: return
		if self.owner.has_buff(Soulbound): return
		reincarnation = self.owner.get_buff(ReincarnationBuff)
		if reincarnation and reincarnation.lives > 0: return # let reincarnations go off first

		owner = self.owner
		level = owner.level

		old_x = owner.x
		old_y = owner.y
		team = owner.team

		self.owner.kill(trigger_death_event=False)

		queen = SnowQueenDethroned()
		queen.team = team
		queen.start_transform_flicker(owner)
		level.add_obj(queen, old_x, old_y)

		pet = SnowQueensPet()
		summoned_pet = level.summon(queen, pet, queen, radius=18)
		if summoned_pet: level.show_path_effect(queen, pet, Tags.Ice, minor=True)

def SnowQueenEnthroned():
	u = Unit()
	u.radius = 2
	u.stationary = True
	u.name = "Snow Queen, Enthroned"
	u.asset_name = "snow_queen_1"
	u.asset_variants = [(['char', 'snow_queen_2'], u.radius)]
	u.max_hp = 8000
	u.shields = 100
	u.tags = [Tags.Ice]
	u.resists[Tags.Ice] = 100

	# summon knights
	# ice vamp gaze
	# blizzard beacon style passive

	summon_knights = SimpleSummon(StormKnight, 4, cool_down=3, global_summon=True, path_effect=Tags.Ice)
	summon_knights.name = "Knights of the Throne"

	u.spells = [summon_knights, SnowQueensGazeSpell()]
	u.buffs = [SnowQueenBlizzardBeacon(), SnowQueenUnseated()]
	return u

class SnowQueenDiamondAegis(Buff):

	def on_init(self):
		self.name = "Diamond Aegis"
		self.description = "Immune to debuffs while shielded"
		self.color = Tags.Ice.color
		self.owner_triggers[EventOnBuffAttemptApply] = self.on_buff_attempt
		self.owner_triggers[EventOnShieldRemoved] = self.on_shield_removed

	def update_immunity(self):
		self.owner.debuff_immune = self.owner.shields > 0

	def on_applied(self, owner):
		self.update_immunity()

	def on_advance(self):
		self.update_immunity()

	def on_buff_attempt(self, evt):
		self.update_immunity()

	def on_shield_removed(self, evt):
		self.update_immunity()

class PermafrostBuff(Buff):

	def on_init(self):
		self.name = "Permafrost"
		self.global_triggers[EventOnDamaged] = self.on_damaged

	def get_description(self):
		return ("When an enemy takes Ice damage, it has a 50% chance to be [frozen] for 1 turn")

	def on_damaged(self, evt):
		if evt.damage_type != Tags.Ice: return
		if not are_hostile(evt.unit, self.owner): return
		if random.random() > .5: return
		evt.unit.apply_buff(FrozenBuff(), 1)

def SnowQueenDethroned():
	u = Unit()
	u.radius = 2
	u.is_boss = True
	u.name = "Snow Queen, Dethroned"
	u.asset_name = 'snow_queen_2'
	u.max_hp = 8000
	u.shields = 1000
	u.tags = [Tags.Ice]
	u.resists[Tags.Ice] = 100

	u.spells = [SnowQueenIceLattice(), SnowQueenIceBeam()]
	u.buffs = [PermafrostBuff(), SnowQueenDiamondAegis()]
	return u

class SnowQueenIceBeam(Spell):

	def on_init(self):
		self.name = "Ice Beam"
		self.damage = 45
		self.damage_type = Tags.Ice
		self.range = 25
		self.beam_radius = 1.5
		self.requires_los = False
		self.can_target_empty = False

	def get_description(self):
		return ("Damages enemies in a wide beam\n"
				"Ignores walls\n"
				"Slain enemies become walls")

	def can_threaten(self, x, y):
		return True

	def get_impacted_tiles(self, x, y):
		level = self.caster.level
		points = []
		center_beam = level.get_points_in_line(self.caster, Point(x, y), find_clear=False)[1 + self.caster.radius:]
		for p in center_beam:
			for q in level.get_points_in_ball(p.x, p.y, self.beam_radius):
				if level.get_unit_at(q.x, q.y) == self.caster: continue
				if q not in points: points.append(q)
		return points

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		damage = self.get_stat('damage')
		dt = self.damage_type
		for p in self.get_impacted_tiles(x, y):
			unit = level.get_unit_at(p.x, p.y)
			if unit and are_hostile(caster, unit):
				wall_x = unit.x
				wall_y = unit.y
				level.deal_damage(p.x, p.y, damage, dt, self)
				if not unit.is_alive():
					level.make_wall(wall_x, wall_y)
					tile = level.tiles[wall_x][wall_y]
					level.set_tile_style(tile, 'turtle', tile.chasm_type)
			else: level.show_effect(p.x, p.y, dt)
		yield

class SnowQueenIceLattice(ShapedSpell):

	def __init__(self):
		snowflake = set()
		for i in range(18):
			snowflake.add((8, i))
			snowflake.add((9, i))
			snowflake.add((i, 8))
			snowflake.add((i, 9))
			snowflake.add((i, i))
			snowflake.add((i, 17 - i))

		def add_symmetric(x, y):
			snowflake.add((x, y))
			snowflake.add((17 - x, y))
			snowflake.add((x, 17 - y))
			snowflake.add((17 - x, 17 - y))
			snowflake.add((y, x))
			snowflake.add((17 - y, x))
			snowflake.add((y, 17 - x))
			snowflake.add((17 - y, 17 - x))

		for x, y in [(5, 1), (4, 2), (5, 2), (6, 3), (7, 4)]: add_symmetric(x, y)

		snowflake = sorted(snowflake)
		ShapedSpell.__init__(self, name="Ice Lattice", damage=30, damage_type=Tags.Ice, melt_walls=False, points=snowflake)
		self.cool_down = 3

	def get_description(self):
		return ("Damages enemies in a snowflake\n"
				"Shields allies\n"
				"Casts as often as possible")

	def cast(self, x, y):
		c = self.caster
		lvl = c.level
		damage = self.get_stat('damage')
		dt = self.damage_type
		for px, py in self.points:
			u = lvl.get_unit_at(px, py)
			if u and are_hostile(c, u): lvl.deal_damage(px, py, damage, dt, self)
			elif u: u.add_shields(1, cap=False)
			else: lvl.show_effect(px, py, dt)
		yield

def get_frost_saber_pounce_dest(cat, target):
	if cat.level.are_adjacent(cat, target): return Point(cat.x, cat.y)
	radius = cat.radius + target.radius + 1
	p = cat.level.get_summon_point(target.x, target.y, radius_limit=radius, unit=cat)
	if not p: return None
	for target_point in target.iter_occupied_points():
		if max(abs(p.x - target_point.x), abs(p.y - target_point.y)) <= cat.radius + 1:
			return p
	return None

class FrostSaberPounce(Spell):

	def on_init(self):
		self.name = "Pounce"
		self.damage = 32
		self.damage_type = Tags.Physical
		self.range = 5

	def get_description(self):
		return "Leap Attack"

	def can_cast(self, x, y):
		if not Spell.can_cast(self, x, y): return False
		target = self.caster.level.get_unit_at(x, y)
		if not target: return False
		if not are_hostile(self.caster, target): return False
		return get_frost_saber_pounce_dest(self.caster, target) is not None

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		target = level.get_unit_at(x, y)
		dest = get_frost_saber_pounce_dest(caster, target)

		if dest.x != caster.x or dest.y != caster.y:
			for point in level.get_points_in_line(caster, dest, find_clear=False):
				level.leap_effect(point.x, point.y, self.damage_type.color, caster)
				yield
			level.act_move(caster, dest.x, dest.y, teleport=True)

		level.deal_damage(x, y, self.get_stat('damage'), self.damage_type, self)
		yield

class FrostSaberGuardianBuff(Buff):

	def on_init(self):
		self.name = "Royal Guardian"
		self.color = Tags.Ice.color
		self.global_triggers[EventOnDeath] = self.on_death

	def get_description(self):
		return "When an ally dies, attempt to teleport near the killer and take an extra turn"

	def on_death(self, evt):
		if are_hostile(evt.unit, self.owner): return
		if evt.unit == self.owner: return
		if not (evt.damage_event and evt.damage_event.source and evt.damage_event.source.owner): return
		self.owner.level.queue_spell(self.do_teleport(self.owner, evt.damage_event.source.owner))

	def do_teleport(self, o, u):
		lvl = o.level
		cur_dist = distance(o, u)
		for p in o.iter_occupied_points(): lvl.show_effect(p.x, p.y, Tags.Translocation)
		yield

		pts = [p for p in lvl.get_points_in_ball(u.x, u.y, radius=6) if lvl.can_move(o, p.x, p.y, teleport=True)]
		if not pts: return
		best = min(pts, key=lambda pt: distance(pt, u))
		if distance(best, u) >= cur_dist: return
		yield lvl.act_move(o, best.x, best.y, teleport=True)
		for p in o.iter_occupied_points(): lvl.show_effect(p.x, p.y, Tags.Translocation)
		for _ in lvl.take_turn(o): yield

def SnowQueensPet():
	u = Unit()
	u.is_boss = True
	u.radius = 1
	u.name = "Frost Saber"
	u.asset_name = "queens_pet"
	u.tags = [Tags.Ice]
	u.max_hp = 4000
	u.resists[Tags.Ice] = 100
	u.burrowing = True
	u.spells = [FrostSaberPounce()]
	u.buffs = [DamageAuraBuff(damage=6, damage_type=Tags.Ice, radius=4, custom_name="Frost Aura"), FrostSaberGuardianBuff(), DeathBlessing(HasteBuff)]
	add_tooltip(u, HasteBuff())
	return u

class BodyElectricRecharged(Buff):

	def on_init(self):
		self.name = "Recharged"
		self.owner_triggers[EventOnDamaged] = self.on_damage

	def get_description(self):
		return "On reaching 0 HP, absorb allies and transform into The Sparking Soul\n\nThe Sparking Soul gains [1 SH:shields] for each absorbed ally"

	def on_damage(self, evt):
		if self.owner.cur_hp > 0: return
		if self.owner.has_buff(Soulbound): return
		reincarnation = self.owner.get_buff(ReincarnationBuff)
		if reincarnation and reincarnation.lives > 0: return # let reincarnations go off first

		owner = self.owner
		level = owner.level

		old_x = owner.x
		old_y = owner.y
		old_pos = Point(old_x, old_y)
		team = owner.team

		self.owner.kill(trigger_death_event=False)

		allies = [u for u in level.units if not are_hostile(owner, u) and u != owner]
		sh = len(allies)
		beam_paths = [level.get_points_in_line(u, old_pos) for u in allies]
		for u in allies: u.kill(trigger_death_event=False)

		u = TheSparkingSoul()
		u.team = team
		if sh: u.shields += sh
		u.start_transform_flicker(owner)
		level.add_obj(u, old_x, old_y)
		if beam_paths: level.queue_spell(self.do_beams(level, beam_paths))

	def do_beams(self, level, beam_paths):
		active_beams = [[path, 0] for path in beam_paths]
		show = level.show_effect
		while active_beams:
			for i in range(len(active_beams) - 1, -1, -1):
				path, index = active_beams[i]
				point = path[index]
				show(point.x, point.y, Tags.Lightning, minor=True)
				active_beams[i][1] += 1
				if active_beams[i][1] == len(path): active_beams.pop(i)
			yield

class SparkingSoul(Buff):
	def on_init(self):
		self.name = "Sparking Soul"
		self.color = Tags.Lightning.color
		self.description = "When targeted by an enemy spell, cast Chain Lightning on the caster"
		self.global_triggers[EventOnSpellCast] = self.on_cast

	def on_cast(self, evt):
		if not are_hostile(evt.caster, self.owner): return
		if self.owner.level.get_unit_at(evt.x, evt.y) != self.owner: return
		self.owner.level.act_cast(self.owner, self.owner.get_or_make_spell(MonsterChainLightning), evt.caster.x, evt.caster.y, pay_costs=False)

class ElectricEngirth(Spell):

	def on_init(self):
		self.name = "Electric Engirth"
		self.tt_color = Tags.Lightning.color
		self.description = "Teleport enemies in line of sight near the caster\nSummon Spark Spirits around them"
		self.range = 0
		self.cool_down = 3

	def get_ai_target(self):
		if any(u for u in self.caster.level.units if are_hostile(self.caster, u) and self.caster.level.can_see(self.caster.x, self.caster.y, u.x, u.y)):
			return self.caster
		return None

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		show_beam = level.show_beam
		target = Point(x, y)

		units = [u for u in level.get_units_in_los(target) if are_hostile(caster, u)]
		can_stand = level.can_stand
		act_move = level.act_move
		rings = points_in_ring_at_center_cache[x][y]
		max_ring = MAX_RING_RADIUS

		for u in units:
			dest = None
			for r in range(max_ring + 1):
				for p in rings[r]:
					if not can_stand(p.x, p.y, u): continue
					dest = p
					break
				if dest: break

			if not dest: continue
			if dest.x == u.x and dest.y == u.y: continue
			show_beam(u, dest, Tags.Translocation, minor=True, inclusive=True)
			act_move(u, dest.x, dest.y, teleport=True)
			yield

		get_adj = level.get_adjacent_points
		getu = level.get_unit_at
		for unit in units:
			for p in get_adj(unit, r=unit.radius):
				if not getu(p.x, p.y):
					self.summon(SparkSpirit(), target=p, radius=0)
			yield

	def get_unit_extra_examine_tooltips(self):
		return [SparkSpirit()]

class PerfectProcession(Spell):

	def on_init(self):
		self.name = "Perfect Procession"
		self.tt_color = Tags.Lightning.color
		self.range = 0
		self.description = "Allies take an extra turn"
		self.cool_down = 3

	def get_ai_target(self):
		if any(u for u in self.caster.level.units if not are_hostile(self.caster, u) and u != self.caster): return self.caster
		return None

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		units = [u for u in level.units if not are_hostile(caster, u) and u != caster]
		if not units: return
		take_turn = level.take_turn
		show_beam = level.show_beam
		for u in units:
			show_beam(caster, u, Tags.Lightning, minor=True, inclusive=False)
			for _ in take_turn(u): yield


def TheBodyElectric():
	u = Unit()
	u.radius = 2
	u.name = "The Body Electric"
	u.asset_name = '5x5_the_body_electric_1'
	u.asset_variants = [(['char', '5x5_the_body_electric_2'], u.radius)]
	u.max_hp = 24000
	u.tags = [Tags.Metallic, Tags.Lightning]

	chain = MonsterChainLightning()
	chain.range = 10

	u.spells = [ElectricEngirth(), PerfectProcession(), chain]
	u.buffs = [SparkingSoul(), BodyElectricRecharged()]
	return u

class Overcharging(Buff):

	def on_init(self):
		self.name = "Overcharging"
		self.color = Tags.Lightning.color
		self.description = "Each turn, doubles the damage of a random spell"

	def on_advance(self):
		opts = [s for s in self.owner.spells if s.damage]
		if not opts: return
		random.choice(opts).damage *= 2

def TheSparkingSoul():
	u = Unit()
	u.radius = 2
	u.name = "The Sparking Soul"
	u.asset_name = '5x5_the_body_electric_2'
	u.max_hp = 4000
	u.tags = [Tags.Metallic, Tags.Lightning]

	chain = MonsterChainLightning()
	chain.range = 10

	halo = LightningHaloSpell()
	halo.tags = []
	halo.cool_down = 2
	halo.max_charges = 0
	halo.expanding = 1
	halo.radius = 4
	def halo_desc(): return "Deal damage in an expanding ring each turn\nLasts {duration} turns"
	halo.get_description = halo_desc
	halo.tt_color = Tags.Lightning.color

	u.spells = [halo, chain]
	u.buffs = [SparkingSoul(), Overcharging()]
	u.is_boss = True
	return u

class AmaruDefenseBuff(Buff):

	def on_init(self):
		self.name = "Amaru Defense"
		self.description = "Immune to damage from [Sorcery] and [Enchantment] spells"

	def on_applied(self, owner):
		def amaru_handler(amount, damage_type, source, redirect_chain):
			if amount <= 0: return None
			if not isinstance(source, Spell): return None
			if not (Tags.Sorcery in source.tags or Tags.Enchantment in source.tags): return None
			return 0

		owner.grant_redirect(self, amaru_handler)

	def on_unapplied(self):
		self.owner.remove_redirect(self)

class SoulEaterBuff(Buff):

	def on_init(self):
		self.name = "Soul Eater"
		self.description = "Gain the max HP of slain units"
		self.global_triggers[EventOnDeath] = self.on_death

	def on_death(self, evt):
		if evt.unit == self.owner: return
		self.owner.level.show_beam(evt.unit, self.owner, Tags.Blood, minor=True)
		self.owner.max_hp += evt.unit.max_hp
		self.owner.heal(evt.unit.max_hp, self)

def Amaru():
	u = Unit()
	u.radius = 2
	u.name = "Amaru"
	u.asset_name = "5x5_twin_dragon"
	u.tags = [Tags.Living, Tags.Dragon, Tags.Fire, Tags.Ice]
	u.flying = True

	u.max_hp = 14000

	frost = IceBreath()
	frost.range = 11
	frost.damage = 41
	frost.cool_down = 1
	frost.quick_cast = True

	flame = FireBreath()
	flame.range = 11
	flame.damage = 41
	flame.cool_down = 1
	flame.quick_cast = True

	u.spells = [flame, frost]
	u.buffs = [SoulEaterBuff(), AmaruDefenseBuff()]

	u.resists[Tags.Fire] = 100
	u.resists[Tags.Ice] = 100
	u.resists[Tags.Physical] = 75

	return u

class SanguineTax(Buff):

	def on_init(self):
		self.name = "Sanguine Tax"
		self.color = Tags.Blood.color
		self.description = "When an enemy casts a spell, inflicts 10 turns of bleed"
		self.global_triggers[EventOnSpellCast] = self.on_cast

	def on_cast(self, evt):
		if not are_hostile(evt.caster, self.owner): return
		self.owner.level.show_beam(self.owner, evt.caster, Tags.Blood)
		evt.caster.apply_buff(BleedBuff(), 10)

class MaggotEmergence(Buff):

	def on_init(self):
		self.name = "Maggot Emergence"
		self.owner_triggers[EventOnDamaged] = self.on_damage

	def get_description(self):
		return "At 0 HP, transforms into Maweth\nThis unit's max HP is added to Maweth's"

	def on_damage(self, evt):
		if self.owner.cur_hp > 0: return
		if self.owner.has_buff(Soulbound): return
		reincarnation = self.owner.get_buff(ReincarnationBuff)
		if reincarnation and reincarnation.lives > 0: return # let reincarnations go off first

		owner = self.owner
		level = owner.level

		old_x = owner.x
		old_y = owner.y
		team = owner.team

		self.owner.kill(trigger_death_event=False)

		new_u = Maweth()
		new_u.max_hp += self.owner.max_hp
		new_u.team = team
		new_u.start_transform_flicker(owner)
		level.add_obj(new_u, old_x, old_y)

class BloodTapBuff(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)

	def on_init(self):
		self.buff_type = BUFF_TYPE_CURSE
		self.damage = self.spell.get_stat('damage')
		self.stack_type = STACK_INTENSITY
		self.name = "Blood Tap"
		self.color = Tags.Blood.color
		self.asset = ["status", "blood_tap"]
		self.caster = self.spell.caster

	def get_description(self):
		return ("Deal {dmg} [Dark] damage per turn\nCaster gains max HP equal to damage dealt", {"dmg": self.damage})

	def on_advance(self):
		if not self.caster.is_alive(): self.owner.remove_buff(self); return
		dmg = self.owner.deal_damage(self.damage, Tags.Dark, self.spell)
		if not dmg: return
		show_effect = self.owner.level.show_effect
		for p in self.owner.level.get_points_in_line(self.owner, self.caster, inclusive=False): show_effect(p.x, p.y, Tags.Blood, minor=True)
		self.caster.max_hp += dmg
		self.caster.heal(dmg, self.spell)

class BloodTapSpell(Spell):

	def on_init(self):
		self.name = "Blood Tap"
		self.range = 0
		self.max_channel = 3
		self.damage = 10
		self.duration = 10
		self.max_charges = 0
		self.cool_down = 3
		self.damage_type = Tags.Dark
		self.tt_color = Tags.Dark.color

	def get_description(self):
		return "Enemies in line of sight are afflicted with [Blood Tap:blood] for {duration} turns\nCan be channeled for {max_channel} turns"

	def get_ai_target(self):
		caster = self.caster
		can_see_unit = caster.level.can_see_unit
		return self.caster if any(u for u in caster.level.units if are_hostile(caster, u) and can_see_unit(caster, u)) else None

	def get_impacted_tiles(self, x, y):
		return [u for u in self.caster.level.get_units_in_los(self.caster) if are_hostile(self.caster, u)]

	def can_threaten(self, x, y):
		return self.owner.level.can_see(self.owner.x, self.owner.y, x, y)

	def bolt(self, caster, target, duration):
		if not target.is_alive(): return
		yield from caster.level.show_path_effect(caster, target, Tags.Blood, pause_frames=1)
		target.apply_buff(BloodTapBuff(self), duration)

	def any_targets(self, target):
		return self.get_ai_target()

	def cast(self, x, y, channel_cast=False):
		if not channel_cast and self.is_manual_cast():
			self.caster.apply_buff(ChannelBuff(self.cast, self.caster, channel_check=self.any_targets), self.get_stat('max_channel'))
			return
		caster = self.caster
		duration = self.get_stat('duration')
		queue = caster.level.queue_spell
		for u in caster.level.get_units_in_los(caster):
			if are_hostile(caster, u): queue(self.bolt(caster, u, duration))
		yield

def SanguineHierophant():
	u = Unit()
	u.radius = 2
	u.name = "Sanguine Hierophant"
	u.asset_name = '5x5_blood_cultist'
	u.asset_variants = [(['char', '5x5_maggot_lord'], u.radius)]
	u.max_hp = 4000
	u.tags = [Tags.Blood, Tags.Dark, Tags.Living]
	u.resists[Tags.Dark] = 100
	u.resists[Tags.Holy] = -100

	blood_tap = BloodTapSpell()

	u.spells = [SwarmSummon(MaggotLeech, effect_tag=Tags.Blood), blood_tap]
	u.buffs = [SanguineTax(), MaggotEmergence()]

	add_tooltip(u, BloodTapBuff(blood_tap))

	return u

class BloodReaping(Buff):

	def on_init(self):
		self.name = "Blood Reaping"
		self.description = "When a unit with bleed dies, takes an extra turn"
		self.color = Tags.Blood.color
		self.global_triggers[EventOnDeath] = self.on_death

	def on_death(self, evt):
		if not evt.unit.has_buff(BleedBuff): return
		if evt.unit == self.owner: return
		self.owner.level.queue_spell(self.do_turn())

	def do_turn(self):
		for _ in self.owner.level.take_turn(self.owner): yield

class MawethsBite(SimpleMeleeAttack):

	def __init__(self):
		SimpleMeleeAttack.__init__(self, damage=50, damage_type=[Tags.Physical, Tags.Dark], buff=BleedBuff, attacks=2, drain=True)
		self.name = "Devour"
		self.tt_color = Tags.Blood.color

	def cast_instant(self, x, y):
		caster = self.caster
		level = caster.level
		getu = level.get_unit_at
		damage = self.get_stat('damage')
		dtypes = self.get_stat('damage_type')

		for i in range(self.attacks):
			unit = getu(x, y)
			if not unit or not unit.is_alive():
				possible_targets = [t for t in level.get_adjacent_units(caster) if are_hostile(caster, t) and t.is_alive()]
				if possible_targets: unit = random.choice(possible_targets)
				else: return
			unit.apply_buff(self.buff(), self.buff_duration) # inflict bleed first so he can properly devour
			dealt = 0
			for dt in dtypes: dealt += unit.deal_damage(damage, dt, self)
			if dealt: caster.heal(dealt, self)


def Maweth():
	u = Unit()
	u.radius = 2
	u.name = "Maweth"
	u.asset_name = '5x5_maggot_lord'
	u.tags = [Tags.Blood, Tags.Dark, Tags.Living]

	u.max_hp = 4000

	u.spells = [MawethsBite()]
	u.buffs = [QuickmoveBuff(), BloodReaping(), HasteBuff(), AdaptiveArmorBuff(20)]
	u.burrowing = True
	return u

# rollable bosses
final_bosses = [Ophan, ApocalypseBeatle, Jormungandr, FrogPope, Yaldabaoth, TheGardener,
				Gaia, Bafflement, SnowQueenEnthroned, TheBodyElectric, Amaru, SanguineHierophant]

# for bestiary recording
all_bosses_and_forms = [
	Ophan,
	ApocalypseBeatle,
	Jormungandr,
	FrogPope,
	Yaldabaoth,
	TheGardener,
	Gaia,
	Bafflement,
	SnowQueenEnthroned,
	SnowQueenDethroned,
	SnowQueensPet,
	TheBodyElectric,
	TheSparkingSoul,
	SanguineHierophant,
	Maweth,
	Amaru,
	Mordred,
	MordredUnbound,
	MordredAscendant
]

level_20_boss_achievements = {
	"Ophan": "OPHAN",
	"Insanity Queen": "INSANITY_QUEEN",
	"Jormungandr": "JORMUNGANDR",
	"Pope the Frog": "POPE",
	"Yaldabaoth": "YALDABAOTH",
	"The Gardener": "GARDENER",
	"Gaia": "GAIA",
	"Bafflement, Demon King": "BAFFLEMENT",
	"Snow Queen, Enthroned": "SNOW_QUEEN",
	"The Body Electric": "BODY_ELECTRIC",
	"Amaru": "AMARU",
	"Sanguine Hierophant": "SANGUINE_HIEROPHANT",
}

def roll_final_boss(prng, game=None):
	if not game or not game.rolled_final_bosses or len(game.rolled_final_bosses) == len(final_bosses): opts = final_bosses
	else: opts = [u for u in final_bosses if u not in game.rolled_final_bosses]
	fn = prng.choice(opts)
	if game: game.rolled_final_bosses.add(fn)
	unit = fn()
	unit.is_boss = True
	return unit
