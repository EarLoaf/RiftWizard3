import importlib
import random

import LevelGen
from Level import Level, Point, Component, ComponentPickup, LAST_LEVEL
from Game import Portal

TILE_SYMBOLS = {
    '#': 'wall',
    '.': 'floor',
    '~': 'chasm',
    'P': 'portal',
    'O': 'orb',
}


class Vault(object):
    def __init__(self, vault_id, layout, tileset=None, chasm_type=None,
                 name=None, description=None, portal_asset=None, portal_locked=None, metadata=None):
        self.id = vault_id
        self.layout = layout
        self.tileset = tileset
        self.chasm_type = chasm_type
        self.metadata = metadata or {}

        self.name = name or vault_id
        self.description = description or "A mysterious vault."

        self.portal_asset = portal_asset
        self.portal_locked = portal_locked


vaults = {}
VAULT_TABLE = [
    # (vault_id, weight, min_level, max_level)
    ('goblin_vault', 1, 1, 7),
    ("spiders_lair", 1, 5, 11),
    ("slime_river", 1, 6, 12),
    ("lava_crossroads", 1, 7, 12),
    ("vault_of_souls", 1, 8, 13),
    ("ice_vault", 1, 7, 13),
    ("tempest_spire", 1, 9, 15),
    ("faery_prison", 1, 10, 16),
    ('sculptors_workshop', 1, 11, 17),
    ("vault_of_torment", 1, 12, 19),
    # add more handcrafted vaults here
]


def load_obj(path):
    module, attr = path.rsplit(".", 1)
    return getattr(importlib.import_module(module), attr)


def register_vault(vault):
    validate_vault(vault)
    if vault.id in vaults: raise ValueError("Duplicate vault id: %s" % vault.id)
    vaults[vault.id] = vault


def get_vault(vault_id): return vaults.get(vault_id)


def iter_vaults(): return vaults.values()


def roll_vault(rng, difficulty=None, table=None):
    rows = table or VAULT_TABLE
    if not rows: return None

    def can_roll(row):
        if difficulty is None: return True
        min_level = row[2] if len(row) > 2 else None
        max_level = row[3] if len(row) > 3 else None
        if min_level is not None and difficulty < min_level: return False
        if max_level is not None and difficulty > max_level: return False
        return True

    eligible = [row for row in rows if can_roll(row)]
    if not eligible: eligible = list(rows)

    source = rng or random.Random()
    ids = [row[0] for row in eligible]
    weights = [max(1, row[1]) for row in eligible]
    return vaults.get(source.choices(ids, weights=weights, k=1)[0])


def make_vault_params(game, difficulty, vault=None, table=None, rng=None):
    rng_obj = rng or getattr(game, "random", None) or random.Random()
    if isinstance(vault, Vault): spec = vault
    elif isinstance(vault, str):
        spec = get_vault(vault)
        if not spec: raise ValueError("Unknown vault id %s" % vault)
    else: spec = roll_vault(rng_obj, difficulty, table)
    if not spec: raise ValueError("No vault specification available")
    difficulty = min(difficulty + 1, LAST_LEVEL)
    return VaultParams(game, difficulty, spec, rng=rng_obj)


class VaultParams(object):
    def __init__(self, game, difficulty, vault, rng=None):
        self.game = game
        self.difficulty = difficulty
        self.vault = vault
        self.rng = rng or getattr(game, "random", None) or random.Random()

        self.primary_spawn = None
        self.secondary_spawn = None
        self.primary_elite = None
        self.secondary_elite = None
        self.components = []
        self.bosses = []
        self.num_xp = 0
        self.num_monsters = 0
        self.num_generators = 0
        self.shrine = None
        self.description = vault.description
        self.level_id = vault.metadata.get("level_id", hash(vault.id) & 0xFFFFFFFF)
        self.level = None
        self.is_vault = True

    def get_description(self):
        return self.description

    def make_child_generator(self, difficulty=None, forced_tag=None):
        if difficulty is None: difficulty = self.difficulty + 1
        return LevelGen.LevelGenerator(difficulty, self.game, forced_tag=forced_tag)

    def make_level(self):
        if self.level is not None: return self.level

        seed = self.rng.random()
        generator = LevelGen.LevelGenerator(self.difficulty, game=self.game, seed=seed)
        generator.level = Level(LevelGen.LEVEL_SIZE, LevelGen.LEVEL_SIZE)
        level = build_vault(generator, self.vault)

        self.components = list(generator.components)
        self.bosses = list(generator.bosses)
        self.num_xp = generator.num_xp
        self.num_monsters = generator.num_monsters
        self.num_generators = generator.num_generators

        level.gen_params = self
        self.level_id = getattr(generator, "level_id", self.level_id)
        level.gen_params.level_id = self.level_id
        self.shrine = generator.shrine
        self.level = level
        return level


class VaultPortal(Portal):
    def __init__(self, params, locked=True):
        self.params = params
        super(VaultPortal, self).__init__(params)

        vault = params.vault
        self.asset = ['tiles', 'portal', 'dormant_portal_vault']
        self.name = vault.name or vault.description or "Vault"
        self.description = vault.description or ""
        if vault.portal_asset: self.asset = vault.portal_asset
        if not locked or vault.portal_locked is False: self.unlock()

    def unlock(self):
        self.locked = False
        self.asset = ['tiles', 'portal', 'active_portal_vault']

    def get_extra_examine_tooltips(self):
        gen_params = self.params
        if hasattr(gen_params, "make_level") and getattr(gen_params, "level", None) is None:  gen_params.make_level()
        if self.locked: return []
        extras = super(VaultPortal, self).get_extra_examine_tooltips()
        return extras

def make_vault_portal(game, difficulty, vault=None, table=None, rng=None, locked=True):
    return VaultPortal(make_vault_params(game, difficulty, vault=vault, table=table, rng=rng), locked=locked)


def validate_vault(vault):
    if not vault.id: raise ValueError("vault id required")
    if not vault.layout: raise ValueError("%s: layout cannot be empty" % vault.id)
    width = len(vault.layout[0])
    level_limit = getattr(LevelGen, "LEVEL_SIZE", width)
    if width > level_limit or len(vault.layout) > level_limit: raise ValueError(
        "%s: layout exceeds LEVEL_SIZE" % vault.id)

    allowed = set(TILE_SYMBOLS.keys())
    for idx in range(10): allowed.add(str(idx))
    for key in ("props", "enemies", "shrines", "components"):
        for glyph in vault.metadata.get(key, {}): allowed.add(glyph)

    height = len(vault.layout)
    enemy_defs = vault.metadata.get("enemies", {})
    occupied_tiles = set()
    radius_cache = {}

    def normalize(value):
        if isinstance(value, dict): return {k: normalize(v) for k, v in value.items()}
        if isinstance(value, (list, tuple, set)):
            seq_type = type(value)
            return seq_type(normalize(v) for v in value)
        if isinstance(value, str) and "." in value:
            try: return load_obj(value)
            except (ImportError, AttributeError, ValueError):  return value
        return value

    def resolve_factory(defn):
        if isinstance(defn, dict):
            factory_path = defn.get("factory")
            if not factory_path: raise ValueError("Factory required in metadata entry")
            factory = load_obj(factory_path) if isinstance(factory_path, str) else factory_path
            kwargs = dict(defn.get("kwargs", {}))
            kwargs = {k: normalize(v) for k, v in kwargs.items()}
            return factory, kwargs
        if callable(defn): return defn, {}
        if isinstance(defn, str): return load_obj(defn), {}
        raise ValueError("Unsupported factory definition: %r" % (defn,))

    for y, row in enumerate(vault.layout):
        if len(row) != width: raise ValueError("%s: layout rows uneven" % vault.id)
        for x, char in enumerate(row):
            if char not in allowed: raise ValueError("%s: bad symbol '%s'" % (vault.id, char))

            if char in enemy_defs:
                if char not in radius_cache:
                    factory, kwargs = resolve_factory(enemy_defs[char])
                    sample_unit = factory(**kwargs)
                    radius_cache[char] = getattr(sample_unit, 'radius', 0) or 0
                radius = radius_cache[char]
                for dx in range(-radius, radius + 1):
                    for dy in range(-radius, radius + 1):
                        tile_x = x + dx
                        tile_y = y + dy
                        if tile_x < 0 or tile_y < 0 or tile_x >= width or tile_y >= height:
                            raise ValueError("%s: unit '%s' at %s with radius %d exceeds layout bounds" % (vault.id, char, (x, y), radius))
                        key = (tile_x, tile_y)
                        if key in occupied_tiles:  raise ValueError("%s: overlapping unit footprints at %s" % (vault.id, key))
                        occupied_tiles.add(key)


def build_vault(levelgen, vault):
    level = levelgen.level
    if vault.tileset or vault.chasm_type:
        first_tile = next(level.iter_tiles())
        level.set_tileset(vault.tileset or first_tile.tileset, vault.chasm_type or first_tile.chasm_type)

    prop_defs = vault.metadata.get("props", {})
    enemy_defs = vault.metadata.get("enemies", {})
    shrine_defs = vault.metadata.get("shrines", {})
    components_defs = vault.metadata.get("components", {})

    total_units = 0
    xp_count = 0
    start_point = None
    boss_units = []
    shrine_props = []
    component_props = []
    seen_names = set()

    def resolve_factory(defn):
        if isinstance(defn, dict):
            factory_path = defn.get("factory")
            if not factory_path: raise ValueError("Factory required in metadata entry")
            factory = load_obj(factory_path) if isinstance(factory_path, str) else factory_path
            def normalize(value):
                if isinstance(value, dict):
                    return {k: normalize(v) for k, v in value.items()}
                if isinstance(value, (list, tuple, set)):
                    seq_type = type(value)
                    return seq_type(normalize(v) for v in value)
                if isinstance(value, str) and "." in value:
                    try:
                        return load_obj(value)
                    except (ImportError, AttributeError, ValueError):
                        return value
                return value
            kwargs = dict(defn.get("kwargs", {}))
            kwargs = {k: normalize(v) for k, v in kwargs.items()}
            return factory, kwargs
        if callable(defn): return defn, {}
        if isinstance(defn, str): return load_obj(defn), {}
        raise ValueError("Unsupported factory definition: %r" % (defn,))

    def spawn_prop(defn, x, y):
        factory, kwargs = resolve_factory(defn)
        prop = factory(**kwargs)
        if isinstance(prop, Component): prop = ComponentPickup(prop)
        level.add_prop(prop, x, y)

    def spawn_unit(defn, x, y):
        factory, kwargs = resolve_factory(defn)
        unit = factory(**kwargs)
        level.add_obj(unit, x, y)
        if unit.name not in seen_names:
            boss_units.append(unit)
            seen_names.add(unit.name)
        return unit

    for y, row in enumerate(vault.layout):
        for x, char in enumerate(row):
            if char in prop_defs:
                level.make_floor(x, y)
                spawn_prop(prop_defs[char], x, y)
                continue

            if char in components_defs:
                level.make_floor(x, y)
                spawn_prop(components_defs[char], x, y)
                component_prop = level.tiles[x][y].prop
                if component_prop not in component_props: component_props.append(component_prop)
                continue

            if char in shrine_defs:
                level.make_floor(x, y)
                spawn_prop(shrine_defs[char], x, y)
                shrine_prop = level.tiles[x][y].prop
                if shrine_prop not in shrine_props: shrine_props.append(shrine_prop)
                continue

            if char in enemy_defs:
                level.make_floor(x, y)
                spawn_unit(enemy_defs[char], x, y)
                total_units += 1
                continue

            if char == 'O':
                level.make_floor(x, y)
                spawn_prop('Level.MemoryOrb', x, y)
                xp_count += 1
                continue

            if char == 'P':
                level.make_floor(x, y)
                level.add_portal(Portal(levelgen.make_child_generator()), x, y, flash=False)
                if start_point is None: start_point = Point(x, y)
                continue

            action = TILE_SYMBOLS.get(char)
            if action == 'wall': level.make_wall(x, y)
            elif action == 'floor': level.make_floor(x, y)
            elif action == 'chasm': level.make_chasm(x, y)

    level.start_pos = start_point or Point(0, 0)
    levelgen.empty_spawn_points = []
    levelgen.wall_spawn_points = []
    levelgen.primary_spawn = None
    levelgen.secondary_spawn = None
    levelgen.primary_elite = None
    levelgen.secondary_elite = None
    if component_props: levelgen.components = [c.component for c in component_props]
    else: levelgen.components = []
    levelgen.num_generators = 0
    if shrine_props: levelgen.shrine = tuple(shrine_props)
    else: levelgen.shrine = None
    levelgen.bosses = boss_units
    levelgen.num_monsters = total_units
    levelgen.num_xp = xp_count
    return level


# --------------------------------------------------------------------------- #

register_vault(Vault(
    vault_id='spiders_lair',
    tileset='fossil',
    chasm_type='swamp',
    name="Vault of Arachnea",
    description='Horrifying spider-kin lurk within.',
    layout=(
        'P..##0BO##OB0##..P',
        '.5..##......##..5.',
        '...##..#..#..##...',
        '#..##........##..#',
        '#..2#..####..#1..#',
        '.###..#....#..###.',
        '.#...#.3..3.#...#.',
        '.O..##.####.##..O.',
        '##.0#3......3#0.##',
        '##.0#3..S4..3#0.##',
        '.O..##......##..O.',
        '.#...#.3..3.#...#.',
        '.###..#....#..###.',
        '#..1#..####..#2..#',
        '#..##........##..#',
        '...##..#..#..##...',
        '.5..##......##..5.',
        'P..##0BO##OB0##..P',
    ),
    metadata={
        'shrines': {
            'S': 'LevelRewards.SpiderShrine',
        },
        'enemies': {
            '0': 'Monsters.GiantSpiderQueen',
            '1': 'Monsters.SteelSpiderQueen',
            '2': 'Monsters.PhaseSpiderQueen',
            '3': 'Monsters.Dryder',
            '4': 'RareMonsters.MotherOfSpiders',
            '5': 'RareMonsters.IdolOfPoison',
        },
        'components': {
            'B': 'Components.IronbarkPlate'
        },
    },
))

register_vault(Vault(
    vault_id='lava_crossroads',
    tileset='volcano',
    chasm_type='lava',
    name='Vault of Flame',
    description='A volcanic pit inhabited by ferocious dragons.',
    layout=(
        '2................2',
        '######~1..1~######',
        '2##~~~~1..1~~~~##2',
        '###~..~....~..~###',
        '1#~....~~~~....~#1',
        '##~..3..PP.....~##',
        '##~....~~~~....~##',
        '#..~~~..~~..~~~..#',
        'S.~~~~......~~~~..',
        '..~~~~......~~~~.S',
        '#..~~~..~~..~~~..#',
        '##~....~~~~....~##',
        '##~.....PP..3..~##',
        '2#~....~~~~....~#2',
        '###~..~....~..~###',
        '1##~~~~1..1~~~~##1',
        '######~1..1~######',
        '2................2',
    ),
    metadata={
        'shrines': {
            'S': 'LevelRewards.ShrineOfPerfection',
        },
        'enemies': {
            '0': 'Monsters.FireDrake',
            '1': {'factory': 'CommonContent.MonsterSpawner', 'kwargs': {'spawn_func': 'Monsters.FireDrake'}},
            '2': {'factory': 'CommonContent.MonsterSpawner', 'kwargs': {'spawn_func': 'Monsters.FireWyrm'}},
            '3': 'RareMonsters.Cindervein',
        },
    },
))

register_vault(Vault(
    vault_id='goblin_vault',
    tileset='jungle',
    chasm_type='water',
    name='Vault of Goblins',
    description='A fortified goblin warcamp.',
    layout=(
        '...~##P####P##~...',
        '.6.~..........~.6.',
        '...~###~##~###~...',
        '~~~~2222222222~~~~',
        '#..##~~~~~~~~##..#',
        '#..#..4.33.4..#..#',
        '#.O#..........#O.#',
        '#O.#..........#.O#',
        '#.O#..........#O.#',
        '#O.#..5....7..#.O#',
        '#.O#..........#O.#',
        '#O.#..........#.O#',
        '#..#3..4..4..3#..#',
        '#..#~~~~~~~~~~#..#',
        '~~~~2222222222~~~~',
        '...~###~##~###~...',
        '.6.~..........~.6.',
        '...~##P####P##~...',
    ),
    metadata={
        'enemies': {
            '1': 'Monsters.Goblin',
            '2': 'Monsters.Kobold',
            '3': 'Monsters.GoblinShaman',
            '4': 'Monsters.KoboldHedgeMage',
            '5': 'RareMonsters.GoblinCave',
            '6': 'RareMonsters.IdolOfSorcery',
            '7': 'RareMonsters.ChainedCyclops',
        },
    },
))

register_vault(Vault(
    vault_id='ice_vault',
    tileset='ice',
    chasm_type='water',
    name='Vault of Glaciers',
    description='Deadly sentries guard frozen hearts in the ruins of an ancient keep.',
    layout=(
        '..................',
        '.7.~~~6.~~.6~~~.7.',
        '...#####..#####...',
        '#~#P..6#..#6..P#~#',
        '#~#3H3.#..#.3H3#~#',
        '#~#.3..2..2..3.#~#',
        '#~#....#44#....#~#',
        '#~###.##..##.###~#',
        '#~~~~~~.22.~~~~~~#',
        '#~~1~~~~..~~~~1~~#',
        '#~~~~~~.22.~~~~~~#',
        '#~~.####..####.~~#',
        '#~..#4..33..4#..~#',
        '#~~.#..3HH3..#.~~#',
        '#~..#.~~~~~~.#..~#',
        '....#.6~22~6.#....',
        '.7..##########..7.',
        '..................',
    ),
    metadata={
        'enemies': {
            '1': 'RareMonsters.IceWizard',
            '2': 'Monsters.IceBelcher',
            '3': 'Monsters.ArmoredPolarBear',
            '4': 'Monsters.IceRift',
            '6': {'factory': 'CommonContent.MonsterSpawner', 'kwargs': {'spawn_func': 'Monsters.ArmoredPolarBear'}},
            '7': 'RareMonsters.IdolOfFrost',
        },
        'shrines': {
            'H': 'Level.HeartDot',
        },
    },
))

register_vault(Vault(
    vault_id='tempest_spire',
    tileset='stone',
    chasm_type='water',
    name='Vault of Tempests',
    description='An ancient spire ringed by ever watchful guardians.',
    layout=(
        '~~~~~~~~~~~~~~~~~~',
        '~4~~~~.3##3.~~~~~~',
        '~~~~~3W....W3~~~~~',
        '~~~##2..##..2##~~~',
        '~~3.#.#.##.#.#.3~~',
        '~~#W..121121..W#~~',
        '~~3..1#....#1..3~~',
        '~~#..2......2..#~~',
        '~3.####.##.####.3~',
        '~~W#P........P#W~~',
        '~3.####.##.####.3~',
        '~~#..2......2..#~~',
        '~~3..1#....#1..3~~',
        '~~#W..121121..W#~~',
        '~~3.#.#.##.#.#.3~~',
        '~~~##...##...##~~~',
        '~~~~~3W.##.W3~~~~~',
        '~~~~~~~~~~~~~~~~~~',
    ),
    metadata={
        'enemies': {
            '1': 'Monsters.StormDrake',
            '2': 'Monsters.Thunderbird',
            '3': 'RareMonsters.Watcher',
            '4': 'RareMonsters.Animikii',
        },
        'components': {
            'W': 'Components.WatcherStone'
        }
    },
))

register_vault(Vault(
    vault_id='vault_of_torment',
    tileset='volcano',
    chasm_type='lava',
    name='Vault of Torment',
    description='Demon forges and soul crucibles belch flame across a tangled lava tunnel.',
    layout=(
        '...~~~~~~~~~~~~...',
        '.4..............4.',
        '...#O~#~3P.~#.#...',
        '~P.~.1......3O~P.~',
        '~.##6####.62#.##.~',
        '~.B#.~#.~..~...~.~',
        '~.###.6##1.#6.##.~',
        '~..#..B3....2....~',
        '~.##1.#.....####.~',
        '~.~#.O~..5..O..2.~',
        '~.3~.#1.....####.~',
        '~..B..#..~..#.B..~',
        '~.#.#6#.2#..#1##.~',
        '~P~#.B#.~1.6#..~P~',
        '~..#O##1##2#B#~..~',
        '...#3~2.~P.O.3....',
        '.4......~.......4.',
        '...~~~~~~~~~~~~...',
    ),
    metadata={
        'enemies': {
            '1': 'Monsters.FleshFiend',
            '2': 'Monsters.FurnaceFiend',
            '3': 'Monsters.ImpCollector',
            '4': 'RareMonsters.CrucibleOfPain',
            '5': 'RareMonsters.InfernoKing',
            '6': {'factory': 'CommonContent.MonsterSpawner', 'kwargs': {'spawn_func': 'Monsters.FurnaceFiend'}},
        },
        'components': {
            'B': 'Components.DevilsBlood',
        },
    },
))

register_vault(Vault(
    vault_id='slime_river',
    tileset='cave',
    chasm_type='swamp',
    name="Vault of Slime",
    description='Twisted wizardry draws forth an ancient and alien mockery of life here',
        layout=(
        '7#######OO#######7',
        '#3..............3#',
        '#.###4#2##1#8###.#',
        '#.99#4####1#8#111#',
        '#.#9#4#...1#8#1~1#',
        '#.#9#4#.5.1#8#1~1#',
        '#.#9#4#...1#811~1#',
        '6.#9#4#1111111~~16',
        'Z1111111~~~~~~~11Z',
        'Z1~~~~~~~1111111.Z',
        '61~1111111...#4#.6',
        '#1~1#2#8#1.5.#4#.#',
        '#1~1#2#8#1...#4#.#',
        '#1~1#2#8####1#4#.#',
        '#111#2#8#S9#1#44.#',
        '#.###2#8##9#1###.#',
        '#3..............3#',
        '7#######OO#######7',
    ),
    metadata={
        'enemies': {
            '1': 'Monsters.GreenSlime',
            '2': 'Monsters.RedSlime',
            '3': 'Monsters.SlimeMage',
            '4': 'Monsters.IceSlime',
            '5': 'RareMonsters.IdolOfPoison',
            '6': {'factory': 'CommonContent.MonsterSpawner', 'kwargs': {'spawn_func': 'Monsters.GreenSlime'}},
            '7': {'factory': 'CommonContent.MonsterSpawner', 'kwargs': {'spawn_func': 'Monsters.SlimeMage'}},
            '8': 'Monsters.ElectricSlime',
            '9': 'Monsters.BloodSlime',  
        },
        'components': {
            'Z': 'Components.OozingOculite',  
        },
        'shrines': {
            'S': 'LevelRewards.slime_shelf',
        },
    },
))

register_vault(Vault(
    vault_id='vault_of_souls',
    tileset='fossil',
    name='Vault of Souls',
    description='A sepulchral gauntlet of horrors.',
    layout=(
        'P################P',
        '#....#O.44.O#....#',
        '#.1..#......#..1.#',
        '#................#',
        '#....#......#....#',
        '###.####.#####.###',
        '#..3.#......#.3..#',
        '#....#......#....#',
        '#.3.....0S.....3.#',
        '#....#......#....#',
        '#..3.#......#.3..#',
        '#....#......#....#',
        '###.####.#####.###',
        '#................#',
        '#..2..........2..#',
        '#....#......#....#',
        '#....#O.44.O#....#',
        'P################P',
    ),
    metadata={
        'shrines': {
            'S': 'LevelRewards.SoulShrine',
        },
        'enemies': {
            '0': 'RareMonsters.GiantSoulJar',
            '1': 'RareMonsters.IdolOfUndeath',
            '2': 'RareMonsters.SkullSentry',
            '3': 'Monsters.BoneKnight',
            '4': 'Monsters.Banshee',
        },
    },
))

register_vault(Vault(
    vault_id='faery_prison',
    tileset='flesh',
    chasm_type='lava',
    name='Vault of the Fettered Fae',
    description='A Great Faery is bound at the heart of a demonic court',
    layout=(
        '~~~~~~~~~~~~~~~~~~',
        '~P..............P~',
        '~..##...1....##..~',
        '~...##......##...~',
        '~....##~~~~##....~',
        '~.##....0....##..~',
        '~..##.##~##.##...~',
        '~...###H.H###....~',
        '~....0~.F.~0.....~',
        '~...###H.H###....~',
        '~..##.##~##..##..~',
        '~.##....0.....##.~',
        '~....##~~~~##....~',
        '~...##......##...~',
        '~..##........##..~',
        '~.##....1.....##.~',
        '~P..............P~',
        '~~~~~~~~~~~~~~~~~~',
    ),
    metadata={
        'enemies': {
            '0': 'Monsters.ArchFiend',
            '1': 'RareMonsters.IdolOfFiends',
            'F': 'RareMonsters.GreatFaeryGiant',
        },
        'components': {
            'H': 'Components.HeartFragment',
        },
    },
))

register_vault(Vault(
    vault_id='sculptors_workshop',
    tileset='stone',
    name='Vault of the Sculptor',
    description='An immortal sculptor labors to perfect his finest creations',
    layout=(
        '.....########.....',
        '.A..##########..B.',
        '...###......###...',
        '~~~###.F..E.###~~~',
        '~~~###......###~~~',
        '..................',
        '..................',
        '......##..##......',
        '......#P..X#......',
        '......#~..S#......',
        '......##..##......',
        '..................',
        '..................',
        '~~~###......###~~~',
        '~~~###.D..C.###~~~',
        '...###......###...',
        '.A..##########..B.',
        '.....########.....',
    ),
    metadata={
        'shrines': {
            'X': 'LevelRewards.IdolChest',
        },
        'enemies': {
            'A': 'RareMonsters.IdolOfLife',
            'B': 'RareMonsters.IdolOfPoison',
            'C': 'RareMonsters.CrucibleOfPain',
            'D': 'RareMonsters.IdolOfRebirth',
            'E': 'RareMonsters.IdolOfFiends',
            'F': 'RareMonsters.IdolOfPiety',
            'S': 'RareMonsters.Sculptor',
        },
    },
))
