import os, json, functools

BASE = os.path.join("rl_data", "loc")
LANG = "en"
ENGLISH = "en"

missing_strings = set() # {(lang, key)}

AUTO_ADD_MISSING = False # set to True if you want to auto insert missing/untranslated strings into text_{lang}.json
PLACEHOLDER_VALUE = "" # placeholder so translator can spot untranslated items

LANG_DISPLAY_NAME = {
    "en": "English",
    # "es": "Español",
    # "de": "Deutsch",
    # "ja": "日本語",
    # "ko": "한국어",
    # "zh": "简体中文",
}

@functools.lru_cache(maxsize=8)
def load(lang):
	path = os.path.join(BASE, f"text_{lang}.json")
	if not os.path.exists(path): return {}
	with open(path, "r", encoding="utf-8") as f: return json.load(f)

def set_locale(lang):
	global LANG
	LANG = lang

def get_locale():
	return LANG

def available_locales():
	codes = []
	for fn in os.listdir(BASE):
		if fn.startswith("text_") and fn.endswith(".json"):
			codes.append(fn[len("text_"):-len(".json")])
	return sorted(set(codes))

def lang_path(lang):
	return os.path.join(BASE, f"text_{lang}.json")

def write_json(path, data, sort_keys=False):
	os.makedirs(os.path.dirname(path), exist_ok=True)
	tmp = f"{path}.tmp"
	with open(tmp, "w", encoding="utf-8") as f:
		json.dump(data, f, ensure_ascii=False, indent=2, sort_keys=sort_keys)
	os.replace(tmp, path)

def log_missing(lang, key, value):
	# create or updated text_{lang}.json with a placeholder if a key is new to it
	path = lang_path(lang)
	data = load(lang).copy()
	if key in data: return
	data[key] = value
	write_json(path, data)
	load.cache_clear() # so T() can see the updated file

def T(string, **fmt):
	if LANG==ENGLISH: s = string
	else:
		s = load(LANG).get(string)
		if s is None or s == "": # if the key isn't in the json (None) or the translation is empty ("")
			s = string # fallback to english
			if AUTO_ADD_MISSING: # if logging, then add untranslated strings to the json
				sig = (LANG, string)
				if sig not in missing_strings:
					missing_strings.add(sig)
					try: log_missing(LANG, string, PLACEHOLDER_VALUE)
					except Exception: pass
	return s.format(**fmt) if fmt else s

def reorder_missing_first(path):
	if not os.path.exists(path): return
	with open(path, "r", encoding="utf-8") as f: data = json.load(f)

	# force keys to str so the checker knows what's being sorted
	missing = {str(k): v for k, v in data.items() if v in (None, "")}
	done    = {str(k): v for k, v in data.items() if v not in (None, "")}

	ordered = {}
	for k in sorted(missing.keys(), key=lambda s: s.casefold()): ordered[k] = missing[k]
	for k in sorted(done.keys(),    key=lambda s: s.casefold()): ordered[k] = done[k]

	tmp = path + ".tmp"
	with open(tmp, "w", encoding="utf-8") as f:
		json.dump(ordered, f, ensure_ascii=False, indent=2)
	os.replace(tmp, path)

def clear_untranslated(path):
	if not os.path.exists(path): return
	with open(path, "r", encoding="utf-8") as f: data=json.load(f)
	done = {str(k): v for k, v in data.items() if v not in (None, "")}
	tmp = path + ".tmp"
	with open(tmp, "w", encoding="utf-8") as f:
		json.dump(done, f, ensure_ascii=False, indent=2)
	os.replace(tmp, path)


if __name__ == "__main__": # run this to reorder the languages to have missing entries on top
	for code in available_locales():
		if code == ENGLISH: continue
		# reorder_missing_first(lang_path(code))
		clear_untranslated(lang_path(code)) # enable this and comment out reorder if you want to clear missing entries