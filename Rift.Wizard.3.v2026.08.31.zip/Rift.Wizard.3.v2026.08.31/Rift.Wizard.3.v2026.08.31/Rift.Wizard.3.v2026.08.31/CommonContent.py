from Level import *

def get_spawn_min_max(difficulty):

	spawn_levels = [
		(1, 1), # 1
		(1, 2), # 2
		(1, 3), # 3
		(2, 3), # 4
		(2, 4), # 5
		(2, 4), # 6
		(3, 4), # 7
		(3, 5), # 8
		(4, 5), # 9
		(4, 6), # 10
		(5, 6), # 11
		(5, 7), # 12
		(6, 6), # 13
		(6, 7), # 14
		(7, 7), # 15
		(7, 8), # 16
		(8, 8), # 17
		(8, 9), # 18
		(8, 9), # 19
		(9, 9), # 20
	]


	# This formula is weird and appears to do very strange things but im not going to change it now because balance is good
	index = max(0, min(difficulty - 1, len(spawn_levels) - 1))

	min_level, max_level = spawn_levels[index]
	return min_level, max_level

class SimpleMeleeAttack(Spell):

	def __init__(self, damage=1, buff=None, buff_duration=0, damage_type=Tags.Physical, onhit=None, onhit_description=None, attacks=1, trample=False, drain=False):
		Spell.__init__(self)
		self.name = "Melee Attack"
		self.range = 1.5
		self.melee = True
		self.damage = damage
		self.damage_type = damage_type if isinstance(damage_type, list) else [damage_type]
		self.buff = buff
		self.buff_duration = buff_duration
		self.buff_name = buff().name.lower() if buff else None
		self.onhit = onhit
		self.onhit_description = onhit_description
		self.attacks = attacks
		self.trample = trample
		self.drain = drain

	def cast_instant(self, x, y):
		caster = self.caster
		for i in range(self.attacks):
			unit = caster.level.get_unit_at(x, y)

			if self.attacks > 1 and not unit:
				possible_targets = [t for t in caster.level.get_adjacent_units(caster) if are_hostile(caster, t)]
				if not possible_targets: return
				unit = random.choice(possible_targets)
				x = unit.x; y = unit.y

			# Deal the damage
			dealt = 0
			dtypes = self.damage_type if isinstance(self.damage_type, list) else [self.damage_type] # sometimes gets overwritten after init
			for dtype in dtypes: dealt += caster.level.deal_damage(x, y, self.get_stat('damage'), dtype, self)
			if self.drain and dealt: caster.deal_damage(-dealt, Tags.Heal, self)
			if not unit: continue
			if unit.is_alive() and self.buff: unit.apply_buff(self.buff(), self.buff_duration)
				
			if self.trample and not unit.radius:
				trample_points = [p for p in caster.level.get_adjacent_points(Point(x, y ), check_unit=True, filter_walkable=True)] + [None]
				p = random.choice(trample_points)
				if p and caster.level.can_move(unit, p.x, p.y): caster.level.act_move(unit, p.x, p.y)
				if caster.level.can_move(caster, x, y, force_swap=True): caster.level.act_move(caster, x, y, force_swap=True)
					
			if self.onhit: self.onhit(caster, unit)

	def get_description(self):
		if self.description: return self.description
		desc = []
		if self.buff:
			if self.buff_duration == 1: desc.append(("Apply {buff} for 1 turn", {'buff':self.buff_name}))
			elif self.buff_duration == 0: desc.append(("Apply permanent {buff}", {'buff':self.buff_name}))
			else: desc.append(("Apply {buff} for {duration} turns", {'buff': self.buff_name, 'duration': self.buff_duration}))
		if self.attacks > 1: desc.append(("Attacks {attacks} times", {'attacks': self.attacks}))
		if self.trample: desc.append("Trample attack")
		if self.drain: desc.append("Heals for damage dealt")
		if self.onhit and self.onhit_description: desc.append(self.onhit_description)

		out = []
		for i, line in enumerate(desc):
			if i: out.append("\n")
			out.append(line)
		return out


class SimpleRangedAttack(Spell):

	def __init__(self, name=None, damage=1, damage_type=Tags.Physical, range=3, beam=False, onhit=None, onhit_description=None, radius=0,
				 melt=False,
				 max_channel=0, cool_down=0, proj_name=None, effect=None, buff=None, buff_duration=0,
				 cast_after_channel=False,
				 drain=False, attacks=1):
		Spell.__init__(self)

		self.name = name

		# Auto name bolt, ball if only one damage type.  Multiple damage types is harder.
		if not self.name:
			if isinstance(damage_type, Tag):
				if radius: self.name = "%s Ball" % damage_type.name
				elif beam: self.name = "%s Beam" % damage_type.name
				else: self.name = "%s Bolt" % damage_type.name

		if not proj_name:
			if damage_type == Tags.Lightning: proj_name = 'lightning_bolt'
			if damage_type == Tags.Fire: proj_name = 'fire_bolt'
			if damage_type == Tags.Ice: proj_name = 'ice_bolt'
			if damage_type == Tags.Arcane: proj_name = 'arcane_bolt'
			if damage_type == Tags.Physical: proj_name = 'physical_bolt'

		if not self.name: self.name = "Ranged Attack"

		self.damage = damage
		self.damage_type = damage_type
		self.range = range
		self.attacks = attacks
		self.beam = beam
		self.onhit = onhit
		self.onhit_description = onhit_description
		self.radius = radius
		if self.radius == 0: self.can_target_empty = False  # faster calc for units that don't need to look at every tile. messes up can_threaten
		self.melt = melt
		if self.melt: self.requires_los = False  # if we burn through walls, we don't need los

		self.max_channel = max_channel
		self.cool_down = cool_down

		self.proj_name = proj_name
		self.effect = effect

		self.buff = buff
		self.buff_name = buff().name.lower() if buff else None
		self.buff_duration = buff_duration

		self.cast_after_channel = cast_after_channel

		self.drain = drain
		self.suicide = False
		self.damage_type_random = True

	def get_description(self):
		desc = []
		if self.description: desc.append(self.description)
		if self.beam: desc.append("Beam attack")
		if self.melt: desc.append("Melts walls")
		elif not self.requires_los: desc.append("Ignores walls")
		if self.cast_after_channel: desc.append(("Cast time: {turns} turns", {'turns': self.max_channel}))
		elif self.max_channel: desc.append(("Can be channeled for {turns} turns", {'turns': self.max_channel}))
		if self.buff:
			if self.buff_duration == 1: desc.append(("Apply {buff} for 1 turn", {'buff':self.buff_name}))
			else: desc.append(("Apply {buff} for {duration} turns", {'buff': self.buff_name, 'duration': self.buff_duration}))
		if self.onhit_description: desc.append(self.onhit_description)
		if self.drain: desc.append("Heals for damage dealt")
		if self.suicide: desc.append("Kills the caster")
		if self.attacks > 1: desc.append(("Shoots {attacks} times", {'attacks': self.attacks}))

		out = []
		for i, line in enumerate(desc):
			if i: out.append("\n")
			out.append(line)
		return out

	def can_continue_channel(self, target):
		if isinstance(target, Unit):
			if not target.is_alive(): return False
			if self.caster.level.get_unit_at(target.x, target.y) != target: return False
			if self.caster.level.are_hostile(self.caster, target) == self.target_allies: return False
		return self.can_cast(target.x, target.y)

	def cast(self, x, y, channel_cast=False):
		for i in range(self.attacks):
			if self.suicide: self.caster.kill()
			if self.max_channel and not channel_cast and self.is_manual_cast():
				unit_target = self.caster.level.get_unit_at(x, y)
				target = unit_target if unit_target else Point(x, y)
				buff = ChannelBuff(self.cast, target, cast_after_channel=self.cast_after_channel, channel_check=self.can_continue_channel)
				self.caster.apply_buff(buff, self.max_channel)
				return

			start = Point(self.caster.x, self.caster.y)
			target = Point(x, y)

			for point in Bolt(self.caster.level, start, target, find_clear=not self.melt):
				if not self.beam:
					dtype = self.effect or self.damage_type
					if isinstance(dtype, list): dtype = random.choice(dtype)
					if self.proj_name: self.caster.level.projectile_effect(point.x, point.y, proj_name=self.proj_name, proj_origin=self.caster, proj_dest=target, proj_duration=4)
					else: self.caster.level.deal_damage(point.x, point.y, 0, dtype, self)
					yield
				else: self.hit(point.x, point.y)
				if self.melt and self.caster.level.tiles[point.x][point.y].is_wall(): self.caster.level.make_floor(point.x, point.y)

			if not self.beam: self.hit(x, y)

		stagenum = 0
		for stage in Burst(self.caster.level, target, self.get_stat('radius'), ignore_walls=not self.get_stat('requires_los')):
			stagenum += 1
			# Skip the first point, its already been damaged
			if stagenum == 1: continue
			for point in stage: self.hit(point.x, point.y)
			for i in range(self.radius): yield

	def get_impacted_tiles(self, x, y):
		tiles = set()
		tiles.add(Point(x, y))
		target = Point(x, y)
		if self.beam:
			for p in Bolt(self.caster.level, self.caster, target, find_clear=not self.melt): tiles.add(p)
		if self.get_stat('radius'):
			for stage in Burst(self.caster.level, target, self.get_stat('radius'), ignore_walls=not self.get_stat('requires_los')):
				for point in stage: tiles.add(point)
		return tiles

	def get_ai_target(self):
		radius = self.get_stat('radius')
		return self.get_corner_target(radius) if radius else Spell.get_ai_target(self)

	def can_cast(self, x, y):
		radius = self.get_stat('radius')
		caster = self.caster
		lvl = caster.level
		allow_empty = radius > 0

		if x < 0 or x >= lvl.width or y < 0 or y >= lvl.height: return False

		dx = abs(caster.x - x)
		dy = abs(caster.y - y)

		if not self.can_target_self and dx == 0 and dy == 0: return False
		if self.must_target_walkable and not lvl.tiles[x][y].can_walk: return False
		if caster.is_blind() and max(dx, dy) > 1 + caster.radius: return False

		r = self.get_stat('range') + (caster.radius if self.melee else 0)
		if self.melee:
			if max(dx, dy) > 1 + caster.radius: return False
		else:
			if dx > r or dy > r: return False
			if dx * dx + dy * dy > r * r: return False

		if not allow_empty or self.must_target_empty:
			u = lvl.tiles[x][y].unit
			if not allow_empty and not u: return False
			if self.must_target_empty and u: return False

		if self.get_stat('requires_los') and not lvl.can_see(caster.x, caster.y, x, y, light_walls=self.cast_on_walls): return False
		return True

	def can_threaten(self, x, y):
		radius = self.get_stat('radius')
		if radius: return self.can_threaten_corner(x, y, radius)
		caster = self.caster
		lvl = caster.level
		dx = abs(x - caster.x)
		dy = abs(y - caster.y)
		r = self.get_stat('range') + self.owner.radius
		if dx * dx + dy * dy > r * r: return False
		if self.get_stat('requires_los') and not lvl.can_see(caster.x, caster.y, x, y, light_walls=self.cast_on_walls): return False
		return True

	def hit(self, x, y):
		unit = self.caster.level.get_unit_at(x, y)
		dtype = self.damage_type
		if isinstance(dtype, list): dtype = random.choice(dtype)
		dealt = self.caster.level.deal_damage(x, y, self.get_stat('damage'), dtype, self)
		if unit and self.onhit: self.onhit(self.caster, unit)
		if unit and self.buff: unit.apply_buff(self.buff(), self.buff_duration)
		if dealt and self.drain: self.caster.deal_damage(-dealt, Tags.Heal, self)

class WideBeam(Spell):

	def __init__(self, name="Wide Beam", damage=5, beam_radius=1.5, range=9, damage_type=None, requires_los=True):
		super().__init__()
		self.name = name
		self.damage = damage
		self.beam_radius = beam_radius
		self.beam_width = int(beam_radius * 2)
		self.range = range
		self.damage_type = damage_type
		self.requires_los = requires_los

	def get_description(self):
		desc =["Deals damage in a wide beam"]
		if not self.requires_los: desc.append(['\nMelts walls'])
		return desc

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		dmg = self.get_stat('damage')

		if self.requires_los: center_beam = level.get_points_in_line(caster, Point(x, y), find_clear=True)[1+caster.radius:]
		else: center_beam = level.get_points_in_line(caster, Point(x, y), find_clear=False)[1+caster.radius:]
		outer_beam = []

		for p in center_beam:
			for q in level.get_points_in_ball(p.x, p.y, self.beam_radius): # grab the points around the centerbeam
				if level.get_unit_at(q.x, q.y) == caster: continue # dont let caster hurt themselves
				if (q not in center_beam) and (q not in outer_beam): outer_beam.append(q) # don't include already captured pts

		wide_beam = center_beam + outer_beam

		for p in wide_beam:
			level.deal_damage(p.x, p.y, dmg, self.damage_type, self)
			if not self.requires_los and not level.tiles[p.x][p.y].can_see: level.make_floor(p.x, p.y)

		yield

class SimpleCurse(Spell):

	def __init__(self, buff, buff_duration, effect=None):
		self.buff = buff
		self.buff_name = buff().name.lower()
		self.duration = buff_duration
		self.stackable = buff().stack_type == STACK_INTENSITY
		self.effect = effect
		Spell.__init__(self)
		if buff().buff_type == BUFF_TYPE_BLESS: self.target_allies = True
		self.description = ("Apply {buff} for {duration} turns", {'buff': self.buff_name, 'duration': buff_duration})
		
	def can_threaten(self, x, y):
		if self.target_allies: return False
		return Spell.can_cast(self, x, y)

	def can_cast(self, x, y):
		unit = self.caster.level.get_unit_at(x, y)
		if not unit: return False
		if not self.stackable and unit.has_buff(self.buff): return False
		return Spell.can_cast(self, x, y)

	def cast_instant(self, x, y):
		unit = self.caster.level.get_unit_at(x, y)
		if unit:
			buff = self.buff()
			buff.caster = self.caster
			unit.apply_buff(buff, self.duration)
			if self.effect:
				for p in self.caster.level.get_points_in_line(self.caster, Point(x, y)):
					self.caster.level.show_effect(p.x, p.y, self.effect)

class SimpleSummon(Spell):

	def __init__(self, spawn_func, num_summons=1, cool_down=0, duration=0, max_channel=0, global_summon=False, path_effect=None, sort_dist=False, radius=3, suicide=False, custom_plural=None):
		Spell.__init__(self)
		
		self.duration = duration
		self.example_monster = spawn_func()

		self.num_summons = num_summons
		self.global_summon = global_summon
		self.cool_down = cool_down

		# How close to an enemy the ai needs to get the target
		self.ai_cast_radius = 2
		if self.range == 0: self.can_target_self = True

		self.sort_dist = sort_dist

		self.path_effect = path_effect

		self.radius = radius
		self.spawn_func = spawn_func
		self.max_channel = max_channel

		self.suicide = suicide

		self.custom_plural = custom_plural

		self.calc_text()

	def calc_text(self):
		spawn_name = self.spawn_func().name
		self.name = "Summon %s" % spawn_name
		if self.num_summons > 1:
			if self.custom_plural: self.name = "Summon %s" % self.custom_plural
			else: self.name += 's'
		if self.duration: spawn_name = "temporary " + spawn_name
		if self.num_summons == 1: desc = [("Summon a {unit}", {'unit': spawn_name})]
		elif self.custom_plural: desc = [("Summon {count} {plural}", {'count': self.num_summons, 'plural': self.custom_plural})]
		else: desc = [("Summon {count} {unit}s", {'count': self.num_summons, 'unit': spawn_name})]
		if self.global_summon:
			if self.num_summons > 1: desc.extend([" at random locations"])
			else: desc.extend([" at a random location"])
		if self.max_channel: desc.extend(["\n", ("Can be channeled for {turns} turns", {'turns': self.max_channel})])
		if self.suicide: desc.extend(["\n", "Kills the caster"])
		self.description = desc[0] if len(desc) == 1 else desc
		
	def on_init(self):
		self.range = 0

	def get_ai_target(self):
		# Do not cast if there are no enemies
		if not any(are_hostile(self.caster, u) for u in self.caster.level.units): return None
		if self.range == 0: return Point(self.caster.x, self.caster.y)
		else: return self.get_corner_target(self.ai_cast_radius)

	def cast(self, x, y, channel_cast=False):
		if self.max_channel and not channel_cast and self.is_manual_cast(): self.caster.apply_buff(ChannelBuff(self.cast, Point(x, y)), self.max_channel); return
		if self.suicide: self.caster.kill()

		for i in range(self.num_summons):
			unit = self.get_unit()
			if self.global_summon:
				targets = [t for t in self.caster.level.iter_tiles() if self.caster.level.can_stand(t.x, t.y, unit)]
				if targets: target = random.choice(targets); x = target.x; y = target.y
				else: return # abort summon if there are no valid targets for global summoning

			summoned_unit = self.summon(unit, Point(x, y), sort_dist=self.sort_dist, radius=self.radius)
			if not summoned_unit: return # abort if self.summon returns None
			if self.path_effect: self.owner.level.show_path_effect(self.owner, summoned_unit, self.path_effect, minor=True)
			yield

	def can_threaten(self, x, y):
		return False

	def get_unit(self):
		u = self.spawn_func()
		if self.duration: u.turns_to_death = self.duration
		src = getattr(getattr(self, 'caster', None), 'source', None)
		if src: u.source = src; apply_minion_bonuses(src, u)
		return u

	def get_unit_extra_examine_tooltips(self):
		return [self.get_unit()]

class PullAttack(Spell):

	def __init__(self, damage=0, damage_type=Tags.Physical, range=3, pull_squares=1, color=None):
		Spell.__init__(self)
		self.damage = damage
		self.damage_type = damage_type
		self.range = range
		self.pull_squares = pull_squares
		self.name = "Pull Attack"
		self.color = color or Color(255, 255, 255)

	def get_description(self):
		return "Pull the target {tiles} tile{s} toward the caster", {'tiles': self.pull_squares, 's':'s' if self.pull_squares > 1 else ''}

	def cast_instant(self, x, y):

		path = self.caster.level.get_points_in_line(self.caster, Point(x, y))
		for p in path[1:-1]: self.caster.level.flash(p.x, p.y, self.color)
		target_unit = self.caster.level.get_unit_at(x, y)

		if target_unit:
			pull(target_unit, self.caster, self.pull_squares)
			target_unit.deal_damage(self.get_stat('damage'), self.damage_type, self)
			self.on_hit(target_unit)

	def on_hit(self, unit):
		pass

def pull(target, source, squares, find_clear=True):
	path = target.level.get_points_in_line(target, source, find_clear=find_clear, two_pass=find_clear)[1:-1][:squares]
	for p in path:
		if target.level.can_move(target, p.x, p.y, teleport=True): target.level.act_move(target, p.x, p.y, teleport=True)
		else: return False
	return True


# Return a movement path for pulling target toward source.
# The path excludes target's current tile and includes the chosen destination tile.
# search_distance is how far to look for the best reachable standable tile
# if the caller will move the whole returned path, pass the max pull distance
# if the caller moves only one space, pass enough search distance to ignore any terrain
# Chooses the reachable standable tile within search_distance that is closest to source, even if source cannot be stood on by target.
def get_pull_along_path(target, source, search_distance):
	if search_distance <= 0: return []

	level = target.level
	start = Point(target.x, target.y)
	start_dist = level.unit_distance(start, source, diag=True)
	best_key = (start_dist, 0)
	best_path = []

	frontier = deque([(start, [])])
	seen = {start}

	while frontier:
		point, path = frontier.popleft()

		if path:
			key = (level.unit_distance(point, source, diag=True), len(path))
			if key < best_key:
				best_key = key
				best_path = path

		if len(path) >= search_distance: continue

		for p in level.get_adjacent_points(point, filter_walkable=False):
			if p in seen: continue
			if not level.can_stand(p.x, p.y, target): continue
			seen.add(p)
			frontier.append((p, path + [p]))

	return best_path

# Push the target a certain number of square away from the source
# Return False if the target cannot be pushed to the location
def push(target, source, squares):
	if squares <= 0: return True
	dir_x = target.x - source.x
	dir_y = target.y - source.y
	if dir_x == dir_y == 0: return False
	dest_x = target.x + dir_x * (squares + 1)
	dest_y = target.y + dir_y * (squares + 1)
	return pull(target, Point(dest_x, dest_y), squares, find_clear=False)
	
class HealAlly(Spell):

	def __init__(self, heal, range, tag=None, can_target_self=True):
		Spell.__init__(self)
		self.name = "Heal Ally"
		self.heal = heal
		self.range = range
		self.tag = tag
		self.target_allies = True
		self.can_target_self = can_target_self

	def get_description(self):
		if self.range == 0: desc = ("Heals caster for {heal} HP", {'heal': self.heal})
		elif self.tag: desc = ("Heals allied {tag} unit for {heal} HP", {'tag': formatted_tag(self.tag), 'heal': self.heal})
		elif self.can_target_self: desc = ("Heals caster or ally for {heal} HP", {'heal': self.heal})
		else: desc = ("Heals an ally for {heal} HP", {'heal': self.heal})
		return desc

	def can_harm(self, target_unit):
		return target_unit.can_be_healed()

	def get_ai_target(self):
		units_in_range = self.caster.level.get_units_in_ball(Point(self.caster.x, self.caster.y), self.range)
		good_targets = [u for u in units_in_range if are_friendly(self.caster, u) and u.can_be_healed()]
		good_targets = [u for u in good_targets if self.can_cast(u.x, u.y)]

		if self.tag: good_targets = [u for u in good_targets if self.tag in u.tags]

		if good_targets:
			target = random.choice(good_targets)
			return Point(target.x, target.y)
		else: return None

	def can_threaten(self, x, y):
		return False

	def cast_instant(self, x, y):
		unit = self.caster.level.get_unit_at(x, y)
		if unit: unit.deal_damage(-self.heal, Tags.Heal, self)

class StormCloud(Cloud):

	def __init__(self, owner, damage=10, duration=5):
		Cloud.__init__(self)
		self.owner = owner
		self.particle_dmg = None # for particle storm upgrade
		self.duration = duration
		self.damage = damage
		self.color = Color(100, 100, 100)
		self.strikechance = 50
		self.name = "Storm Cloud"
		self.source = None
		self.asset = ['tiles', 'clouds', 'thunder_cloud']


	def get_description(self):
		return ("Each turn, {strikechance}% chance to deal [{damage}:damage] [Lightning] damage to any unit standing inside\n"
				"Expires in {duration} turns")

	def on_advance(self):
		if random.random() <= (self.strikechance / 100):
			self.level.deal_damage(self.x, self.y, self.damage, Tags.Lightning, self.source or self)
		if self.particle_dmg: # for particle storm upgrade
			self.level.deal_damage(self.x, self.y, self.particle_dmg, Tags.Arcane, self.source or self)


class BlizzardCloud(Cloud):

	def __init__(self, owner, damage=5, duration=5):
		Cloud.__init__(self)
		self.owner = owner
		self.duration = duration
		self.damage = damage
		self.color = Color(100, 100, 100)
		self.name = "Blizzard"
		self.asset = ['tiles', 'clouds', 'ice_cloud']
		self.source = None
		self.spellcast = None
		self.status_on_damage = [] # accepts tuples of (buff_cls, duration)

	def get_description(self):
		return ("Each turn, deal [{damage}:damage] [Ice] damage to any unit standing inside\n"
				"50% chance units standing inside are [frozen] for 1 turn\n"
				"Disappears on taking [Fire] damage\n"
				"Expires in {duration} turns")

	def on_advance(self):
		dealt = self.level.deal_damage(self.x, self.y, self.damage, Tags.Ice, self.source or self)

		if self.spellcast and random.random() < 0.25:
			if self.source:
				spell = self.source.caster.get_or_make_spell(self.spellcast)
				self.source.caster.level.act_cast(self.source.owner, spell, self.x, self.y, pay_costs=False)
			else:
				spell = self.spellcast()
				self.source.caster.level.act_cast(self.source.owner, spell, self.x, self.y, pay_costs=False)

		unit = self.level.get_unit_at(self.x, self.y)
		if unit:
			if random.random() > .5:
				unit.apply_buff(FrozenBuff(), 1)
			if dealt and self.status_on_damage:
				for buff_cls, duration in self.status_on_damage:
					unit.apply_buff(buff_cls(), duration)

	def on_damage(self, dtype):
		if dtype == Tags.Fire: self.kill()

class SoakedBuff(Buff):

	def on_init(self):
		self.name = "Soaked"
		self.resists[Tags.Ice] = -50
		self.resists[Tags.Lightning] = -50
		self.resists[Tags.Fire] = 50
		self.stack_type = STACK_DURATION
		self.buff_type = BUFF_TYPE_CURSE
		self.asset = ['status', 'soaked']

class RainCloud(Cloud):

	def __init__(self, owner, spell=None, duration=5):
		Cloud.__init__(self)
		self.asset= ['tiles', 'clouds', 'rainstorm_cloud']
		self.name = "Rain Cloud"
		self.owner = owner
		self.duration = duration
		self.spell = spell

	def get_description(self):
		return ("Each turn, apply soaked for 2 turns to any unit standing inside\n"
				"Disappears on taking [Fire] damage\n"
				"Expires in {duration} turns")
		
	def on_advance(self):
		unit = self.level.get_unit_at(self.x, self.y)
		if not unit: return
		unit.apply_buff(SoakedBuff(), 2)
		if not self.spell: return
		if self.spell.get_stat('healing') and not are_hostile(self.spell.caster, unit): unit.heal(10, self.spell)
		if self.spell.get_stat('poison'): unit.deal_damage(self.spell.get_stat('damage'), Tags.Poison, self.spell)

	def on_damage(self, dtype):
		if dtype == Tags.Fire: self.kill()


class CloudGeneratorBuff(Buff):

	def __init__(self, cloud_func, radius, chance):
		Buff.__init__(self)
		self.cloud_func = cloud_func
		self.radius = radius
		self.chance = chance

	def get_description(self):
		return "Each turn, {chance}% chance to spawn a {cloud_type} on each empty or enemy-occupied tile within {radius} tiles"

	def fmt_dict(self):
		return {"chance": self.chance, "cloud_type": self.cloud_func(None).name, "radius": self.radius}

	def on_advance(self):
		for point in self.owner.level.get_points_in_ball(self.owner.x, self.owner.y, self.radius):
			unit = self.owner.level.get_unit_at(point.x, point.y)
			if unit and not are_hostile(unit, self.owner): continue
			if not self.owner.level.tiles[point.x][point.y].can_see: continue
			if random.random() < (self.chance / 100): self.owner.level.add_obj(self.cloud_func(owner=self.owner), point.x, point.y)

class SpiderWeb(Cloud):

	def __init__(self):
		Cloud.__init__(self)
		self.name = "Spider Web"
		self.color = Color(210, 210, 210)
		self.description = ("Any non-[Spider] unit entering the web is immobilized for 1 turn\n"
							"This destroys the web\n"
							"[Fire] damage destroys webs")
		self.duration = 12
		self.asset = ['tiles', 'clouds', 'web']

	def on_unit_enter(self, unit):
		if Tags.Spider not in unit.tags:
			unit.apply_buff(ImmobilizeBuff(), 2)
			self.kill()

	def on_damage(self, dtype):
		if dtype == Tags.Fire: self.kill()

class PetrifyBuff(Stun):

	def __init__(self):
		Stun.__init__(self)
		self.name = "Petrified"
		self.color = Tags.Construct.color
		self.resists[Tags.Physical] = 75
		self.resists[Tags.Fire] = 75
		self.resists[Tags.Ice] = 100
		self.resists[Tags.Lightning] = 100
		self.asset = ['status', 'petrified']
		self.stack_type = STACK_NONE

		self.description = "Cannot act"


class GlassPetrifyBuff(PetrifyBuff):

	def __init__(self):
		PetrifyBuff.__init__(self)
		self.resists[Tags.Physical] = -100
		self.name = "Glassed"
		self.asset = ['status', 'glassed']
		self.color = Tags.Glass.color

	def on_applied(self, owner):
		if Tags.Glass in owner.tags: return ABORT_BUFF_APPLY
		return PetrifyBuff.on_applied(self, owner)

class ResistBuff(Buff):

	def __init__(self, dtype, res=50):
		self.dtype = dtype
		self.res = res
		Buff.__init__(self)

	def on_init(self):
		self.stack_type = STACK_INTENSITY
		if self.res < 0: self.buff_type = BUFF_TYPE_CURSE
		keyword =  "Vulnerability" if self.res < 0 else "Immunity" if self.res >= 100 else "Protection"
		self.name = f"{self.dtype.name} {keyword}"
		self.resists[self.dtype] = self.res
		self.color = self.dtype.color


class ResistIce(Buff):

	def on_init(self):
		self.name = "Ice Protection"
		self.resists[Tags.Ice] = 50
		self.color = Tags.Ice.color
		self.asset = ['status', 'resist_ice']

class ResistFire(Buff):

	def on_init(self):
		self.name = "Fire Protection"
		self.resists[Tags.Fire] = 50
		self.color = Tags.Fire.color
		self.asset = ['status', 'resist_fire']

class ResistLightning(Buff):

	def on_init(self):
		self.name = "Lightning Protection"
		self.resists[Tags.Lightning] = 50
		self.color = Tags.Lightning.color
		self.asset = ['status', 'resist_lightning']

class ResistHoly(Buff):

	def on_init(self):
		self.name = "Holy Protection"
		self.resists[Tags.Holy] = 50
		self.color = Tags.Holy.color
		self.asset = ['status', 'resist_holy']

class ResistDark(Buff):

	def on_init(self):
		self.name = "Dark Protection"
		self.resists[Tags.Dark] = 50
		self.color = Tags.Dark.color
		self.asset = ['status', 'resist_dark']


class Stoneskin(Buff):

	def on_init(self):
		self.name = "Stoneskin"
		self.resists[Tags.Physical] = 50
		self.color = Tags.Physical.color
		self.asset = ['status', 'stoneskin']

# Raised when frozen is ended by damage
EventOnUnfrozen = namedtuple("EventOnUnfrozen", "unit dtype buff")
class FrozenBuff(Stun):

	def __init__(self):
		Stun.__init__(self)
		self.shatter_chance = 0
		self.name = "Frozen"
		self.color = Tags.Ice.color
		self.turns_frozen = 0

		self.owner_triggers[EventOnDamaged] = self.on_damage
		self.break_dtype = None
		self.description = "Cannot act\nEnds on taking [Fire] or [Physical] damage"
		self.asset = ['status', 'frozen']

	def on_advance(self):
		if self.owner.resists[Tags.Ice] >= 100: self.owner.remove_buff(self); return
		self.turns_frozen += 1

	def on_applied(self, owner):
		if owner.resists[Tags.Ice] >= 100: return ABORT_BUFF_APPLY
		return Stun.on_applied(self, owner)

	def on_damage(self, evt):
		if evt.damage_type == Tags.Fire or evt.damage_type == Tags.Physical:
			self.break_dtype = evt.damage_type
			self.owner.remove_buff(self)

	def on_unapplied(self):
		self.owner.level.event_manager.raise_event(EventOnUnfrozen(self.owner, self.break_dtype, self), self.owner)
		Stun.on_unapplied(self)

# Raised when sleep is ended
EventOnAwakened = namedtuple("EventOnAwakened", "unit buff")
class SleepBuff(Stun):

	def __init__(self):
		Stun.__init__(self)
		self.name = "Sleep"
		self.wake_damage_event = None
		self.owner_triggers[EventOnDamaged] = self.on_damage
		self.description = "Cannot act\nEnds on taking any damage that is not [Arcane] or [Dark]"
		self.asset = ['status', 'sleep']

	def on_damage(self, evt):
		if evt.damage_type == Tags.Arcane or evt.damage_type == Tags.Dark: return
		self.wake_damage_event = evt
		self.owner.remove_buff(self)

	def on_unapplied(self):
		self.owner.level.event_manager.raise_event(EventOnAwakened(self.owner, self), self.owner)
		Stun.on_unapplied(self)

class TrollRegenBuff(Buff):

	def on_init(self):
		self.name = "Troll Regeneration"

	def on_applied(self, owner):
		self.recently_burned = False
		self.owner_triggers[EventOnDamaged] = self.on_damage_taken

	def on_damage_taken(self, damage_event):
		if damage_event.damage_type == Tags.Fire: self.recently_burned = True

	def on_advance(self):
		if not self.recently_burned:
			if self.owner.cur_hp != self.owner.max_hp:
				self.owner.deal_damage(-5, Tags.Heal, self)
		self.recently_burned = False

	def get_tooltip(self):
		return "Regenerate 5 HP each turn\nDisabled on taking [Fire] damage"

class DamageAuraBuff(Buff):

	def __init__(self, damage, damage_type, radius, custom_name=None, friendly_fire=False, melt_walls=False):
		
		self.damage = damage
		self.damage_type = damage_type
		self.radius = radius
		self.friendly_fire = friendly_fire
		self.source = None

		Buff.__init__(self)

		if custom_name: self.name = custom_name
		elif isinstance(self.damage_type, Tag): self.name = "%s Aura" % self.damage_type.name
		else: self.name = "Damage Aura"

		if not isinstance(self.damage_type, list): self.color = self.damage_type.color

		# Not used in base class, used in inherited classes
		self.damage_dealt = 0
		self.melt_walls = melt_walls
		
	def on_hit(self, unit): pass
	def on_damage(self, unit): pass
	def on_kill(self, unit): pass

	def on_advance(self):
		for p in self.owner.level.get_points_in_ball(self.owner.x, self.owner.y, self.radius):
			unit = self.owner.level.get_unit_at(p.x, p.y)
			if isinstance(self.damage_type, list) and self.damage_type: damage_type = random.choice(self.damage_type)
			else: damage_type = self.damage_type

			if unit:
				if unit == self.owner: continue
				if not self.friendly_fire and not self.owner.level.are_hostile(self.owner, unit): continue
				dealt = unit.deal_damage(self.damage, damage_type, self.source or self)
				self.on_hit(unit) # proc regardless of dealing damage
				if dealt:
					self.damage_dealt += dealt
					self.on_damage(unit) # proc only if damage is dealt
					if not unit.is_alive(): self.on_kill(unit) # proc if it killed the unit with its damage

			else:
				if not self.owner.level.tiles[p.x][p.y].can_see: continue
				if random.random() < .5: continue
				self.owner.level.show_effect(p.x, p.y, damage_type, minor=True)

	def can_threaten(self, x, y):
		return distance(self.owner, Point(x, y)) <= self.radius

	def get_tooltip(self):
		damage_type_str = ' or '.join(t.name for t in self.damage_type) if isinstance(self.damage_type, list) else self.damage_type.name
		unit_type_str = 'units' if self.friendly_fire else 'enemies'
		return ("Each turn, deal {damage} {damage_type} damage to {unit_type} within {radius} tiles", {"damage": self.damage, "damage_type": damage_type_str, "unit_type": unit_type_str, "radius": self.radius})

class HealAuraBuff(Buff):

	def __init__(self, heal, radius, whole_map=False, can_heal_player=True, heal_self=False):
		Buff.__init__(self)
		self.name = "Healing Aura"
		self.color = Tags.Heal.color
		self.heal = heal
		self.radius = radius
		self.whole_map = whole_map
		self.can_heal_player = can_heal_player
		self.heal_self = heal_self

	def on_advance(self):
		if self.whole_map:
			units = list(self.owner.level.units)
		else:
			units = list(self.owner.level.get_units_in_ball(Point(self.owner.x, self.owner.y), self.radius))

		for unit in units:
			if unit.is_player_controlled and not self.can_heal_player:
				continue

			if unit == self.owner and not self.heal_self:
				continue

			if self.owner.level.are_hostile(self.owner, unit):
				continue

			if unit.cur_hp == unit.max_hp:
				continue

			unit.deal_damage(-self.heal, Tags.Heal, self)

	def get_tooltip(self):
		if not self.whole_map: return ("Heal allies within {radius} tiles for {heal} each turn", {'radius': self.radius, 'heal': self.heal})
		else: return ("Heal allies for {heal} each turn", {'heal': self.heal})

class LeapAttack(Spell):

	def __init__(self, damage, range, damage_type=Tags.Physical, is_leap=True, charge_bonus=0, is_ghost=False, buff=None, buff_duration=0):
		Spell.__init__(self)
		self.damage = damage
		self.damage_type = damage_type
		self.range = range
		self.is_leap = is_leap and not is_ghost
		self.charge_bonus = charge_bonus
		self.is_ghost = is_ghost
		self.name = "Pounce" if self.is_leap else "Charge"
		self.requires_los = not self.is_ghost
		self.buff = buff
		self.buff_duration = buff_duration
		self.buff_name = buff().name if buff else None

	def get_leap_dest(self, x, y):
		caster = self.caster
		level = caster.level
		requires_los = self.get_stat('requires_los')

		target_unit = level.get_unit_at(x, y)
		if not target_unit: return None # can't jump if there's no unit there
		if level.are_adjacent(caster, target_unit): return Point(caster.x, caster.y) # don't need to leap if we're already adjacent
		target_center = Point(x, y)
		target_points = set()
		for p in target_unit.iter_occupied_points(): # Be willing to leap next to large monsters
			for q in level.get_adjacent_points(p, check_unit=True, filter_walkable=not caster.flying):
				if q != target_center: target_points.add(q)

		target_points = list(target_points)
		random.shuffle(target_points)

		for point in target_points:
			if not self.caster.level.can_move(self.caster, point.x, point.y, teleport=True): continue
			if not self.is_ghost:
				if self.is_leap:
					if requires_los and not level.can_see(point.x, point.y, caster.x, caster.y): continue
				else:
					full_path = level.get_points_in_line(caster, point, find_clear=requires_los)
					if not full_path or full_path[-1] != point: continue
					if not all(level.can_stand(p.x, p.y, caster) for p in full_path[1:-1]): continue
			return point
		return None		

	def get_description(self):
		desc = []
		if self.is_leap: desc.append("Leap attack")
		elif self.is_ghost: desc.append("Teleport attack")
		else: desc.append("Charge attack")
		if self.charge_bonus: desc.append(("{charge_bonus} extra damage per tile traveled", {'charge_bonus': self.charge_bonus}))
		if self.buff:
			if self.buff_duration: desc.append(("Inflict {buff} for {duration} turn{s}", {'buff': self.buff_name, 'duration': self.buff_duration, 's': 's' if self.buff_duration > 1 else ''}))
			else: desc.append(("Inflict {buff}", {'buff': self.buff_name}))
		out = []
		for i, line in enumerate(desc):
			if i: out.append("\n")
			out.append(line)
		return out

	def can_cast(self, x, y):
		return Spell.can_cast(self, x, y) and (self.get_leap_dest(x, y) is not None)
			
	def cast(self, x, y):
		leap_dest = self.get_leap_dest(x, y)
		if not leap_dest: return

		caster = self.caster
		level = caster.level
		requires_los = self.get_stat('requires_los') # sometimes remove los req outside of init
		unit = level.get_unit_at(x, y)

		charge_bonus = 0
		if leap_dest.x != caster.x or leap_dest.y != caster.y: # don't bother with this if they're already next to their target
			path = level.get_points_in_line(caster, leap_dest, find_clear=requires_los)
			for point in path: level.leap_effect(point.x, point.y, self.damage_type.color, caster)
			level.act_move(caster, leap_dest.x, leap_dest.y, teleport=True)
			charge_bonus = self.charge_bonus * (len(path) - 2)

		level.deal_damage(x, y, self.get_stat('damage') + charge_bonus, self.damage_type, self)
		if self.buff and unit and unit.is_alive(): unit.apply_buff(self.buff(), self.buff_duration)
		yield

	def can_threaten(self, x, y):
		caster = self.caster
		level = caster.level
		target = Point(x, y)
		if distance(caster, target) > self.get_stat('range'): return False
		return level.can_see(caster.x, caster.y, x, y) if self.get_stat('requires_los') else True

class GlobalAttrBonus(Buff):

	def __init__(self, attr, bonus):
		Buff.__init__(self)
		self.attr = attr
		self.bonus = bonus
		self.global_bonuses[attr] = bonus
		self.buff_type = BUFF_TYPE_BLESS

class TagAttrBonus(Buff):
	def __init__(self, tag, attr, bonus, custom_name=None, pct=False):
		Buff.__init__(self)
		self.attr = attr
		self.bonus = bonus
		self.tag = tag
		if pct: self.tag_bonuses_pct[tag][attr] = bonus
		else: self.tag_bonuses[tag][attr] = bonus
		self.stack_type = STACK_INTENSITY
		self.name = custom_name or f"{tag.name} {attr_label(attr)} Bonus"
		self.color = tag.color

class MonsterTeleport(Spell):

	def on_init(self):
		self.name = "Teleport"
		self.description = "Teleport to a random tile"
		self.range = 10
		self.can_target_self = True
		self.cool_down = 4
		self.requires_los = False

	def get_ai_target(self):
		return self.caster

	def can_threaten(self, x, y):
		return False

	def cast_instant(self, x, y):
		randomly_teleport(self.caster, self.range, flash=True, requires_los=self.requires_los)

class MonsterLeap(Spell):

	def on_init(self):
		self.name = "Leap"
		self.description = "Leap to target tile"
		self.range = 6
		self.requires_los = True
		self.cool_down = 5

	def get_ai_target(self):
		choices = [t for t in self.caster.level.get_tiles_in_ball(self.caster.x, self.caster.y, self.get_stat('range')) if self.caster.level.can_stand(t.x, t.y, self.caster)]
		choices = [t for t in choices if distance(self.caster, t) >= 2] # Do not leap one square
		choices = [t for t in choices if self.can_cast(t.x, t.y)]
		if not choices: return None
		return random.choice(choices)

	def can_threaten(self, x, y):
		return False

	def cast(self, x, y):
		if not self.caster.level.can_stand(x, y, self.caster): return
		path = self.caster.level.get_points_in_line(Point(self.caster.x, self.caster.y), Point(x, y), find_clear=True)
		for point in path:
			self.caster.level.leap_effect(point.x, point.y, Tags.Physical.color, self.caster)
			yield
		self.caster.level.act_move(self.caster, x, y, teleport=True)

def get_random_teleport_destination(unit, radius, requires_los=False):
	blink_targets = [p for p in unit.level.get_points_in_ball(unit.x, unit.y, radius) if unit.level.can_move(unit, p.x, p.y, teleport=True) and (p.x, p.y != unit.x, unit.y)]
	if not blink_targets: return None
	if requires_los: blink_targets = [p for p in blink_targets if unit.level.can_see(unit.x, unit.y, p.x, p.y)]
	if not blink_targets: return None
	target = random.choice(blink_targets)
	return target

def randomly_teleport(unit, radius, flash=True, requires_los=False):
		blink_targets = [p for p in unit.level.get_points_in_ball(unit.x, unit.y, radius) if unit.level.can_move(unit, p.x, p.y, teleport=True)]
		if not blink_targets: return
		if requires_los: blink_targets = [p for p in blink_targets if unit.level.can_see(unit.x, unit.y, p.x, p.y)]
		if not blink_targets: return
		target = random.choice(blink_targets)
		if flash: unit.level.flash(unit.x, unit.y, Tags.Translocation.color)
		unit.level.act_move(unit, target.x, target.y, teleport=True)
		if flash: unit.level.flash(unit.x, unit.y, Tags.Translocation.color)

def drain_max_hp(unit, hp):
	unit.max_hp -= hp
	unit.max_hp = max(1, unit.max_hp)
	unit.cur_hp = min(unit.cur_hp, unit.max_hp)

class RegenBuff(Buff):

	def __init__(self, heal):
		Buff.__init__(self)
		self.heal = heal
		self.stack_type = STACK_INTENSITY
		self.name = "Regeneration"
		self.buff_type = BUFF_TYPE_BLESS
		self.asset = ['status', 'heal']

	def get_description(self):
		return "Heals {heal} HP each turn", {"heal": self.heal}

	def on_advance(self):
		if self.owner.cur_hp < self.owner.max_hp:
			self.owner.deal_damage(-self.heal, Tags.Heal, self)


class ShieldRegenBuff(Buff):

	def __init__(self, shield_max, shield_freq=1):
		Buff.__init__(self)
		self.name = "Shield Regeneration"
		self.shield_max = shield_max
		self.shield_freq = shield_freq
		self.turns = 0
		self.buff_type = BUFF_TYPE_BLESS

	def on_advance(self):
		if self.owner.shields >= self.shield_max:
			self.turns = 0
		else:
			self.turns += 1
			if self.turns == self.shield_freq:
				self.owner.add_shields(1)
				self.turns = 0

	def get_tooltip(self):
		return "Gain 1 [SH:shields] every {freq} turns up to a max of {max}", {'freq': self.shield_freq, 'max': self.shield_max}


class RegenShieldsBuff(Buff):

	def __init__(self, sh=2, cap=True):
		Buff.__init__(self)
		self.sh = sh
		self.cap = cap

	def on_init(self):
		self.name = "Regenerating Shields"
		self.color = Tags.Arcane.color

	def get_description(self):
		return ("Gain [{sh} SH:shields] each turn", {'sh': self.sh})

	def on_advance(self):
		self.owner.add_shields(self.sh, self.cap)


class ReincarnationBuff(Buff):

	def __init__(self, lives=1):
		self.lives = lives
		self.old_pos = None
		self.cached_turns_to_death = None
		self.cached_shields = 0
		self.cached_max_hp = 0
		Buff.__init__(self)

	def on_init(self):
		self.owner_triggers[EventOnDeath] = self.on_death
		self.name = "Reincarnation"
		self.buff_type = BUFF_TYPE_PASSIVE
		self.stack_type = STACK_NONE
		self.asset = ['status', 'reincarnation']

	def on_applied(self, owner):
		self.cached_shields = owner.shields
		self.cached_max_hp = owner.max_hp
		self.cached_turns_to_death = owner.turns_to_death
		if owner.turns_to_death is None: return
		if not isinstance(owner.source, (Spell, Equipment)): return
		turns = owner.source.get_stat('minion_duration')
		self.cached_turns_to_death = turns


	def get_description(self):
		suffix = "" if self.lives == 1 else "s"
		return ("Reincarnates when killed ({lives} time{suffix})", {'lives':self.lives, 'suffix':suffix})

	def on_death(self, evt):
		if self.lives <= 0: return
		self.lives -= 1
		self.old_pos = Point(self.owner.x, self.owner.y)
		to_remove = [b for b in list(self.owner.buffs) if  b is not self and b.buff_type not in (BUFF_TYPE_PASSIVE, BUFF_TYPE_ITEM)]
		for b in to_remove: self.owner.remove_buff(b)
		self.owner.level.queue_spell(self.respawn())

	def respawn(self):
		respawn_points = [p for p in self.owner.level.iter_tiles() if self.owner.level.can_stand(p.x, p.y, self.owner)]
		if not respawn_points:return
		self.owner.shields = self.cached_shields
		self.owner.max_hp = max(self.owner.max_hp, self.cached_max_hp)
		dest = random.choice(respawn_points)
		self.owner.cur_hp = self.owner.max_hp
		self.owner.turns_to_death = self.cached_turns_to_death
		self.owner.killed = False
		self.owner.level.add_obj(self.owner, dest.x, dest.y)
		self.owner.level.leap_effect(self.old_pos.x, self.old_pos.y, Tags.Holy.color, self.owner)
		yield
		for p in self.owner.level.get_points_in_line(self.old_pos, dest)[1:-1]: self.owner.level.show_effect(p.x, p.y, Tags.Holy, minor=True)
		yield
		self.owner.level.leap_effect(dest.x, dest.y, Tags.Holy.color, self.owner)
		if self.lives <= 0: self.owner.remove_buff(self)
		self.owner.apply_buff(Stun(), 1)
		yield

class ShieldSightSpell(Spell):

	def __init__(self, cool_down, shields):
		Spell.__init__(self)
		self.shields = shields
		self.stats.append('shields')
		self.name = "Shield Allies"
		self.cool_down = cool_down
		self.buff_type = BUFF_TYPE_BLESS

	def get_description(self):
		return "Grant allies in line of sight [1 SH:shields], up to a max of [{shields}:shields]"

	def on_init(self):
		self.range = 0

	def cast_instant(self, x, y):
		units = [u for u in self.caster.level.get_units_in_los(Point(x, y)) if not self.caster.level.are_hostile(u, self.caster)]
		for unit in units:
			if unit.shields < self.shields:
				unit.add_shields(1)

class ImmobilizeBuff(Buff):

	def on_init(self):
		self.stack_type = STACK_DURATION
		self.name = "Immobilized"
		self.description = "Cannot walk"
		self.asset = ["status", "immobile"]
		self.buff_type = BUFF_TYPE_CURSE
		self.prev_state = False

	def on_applied(self, owner):
		owner.stationary += 1

	def on_unapplied(self):
		self.owner.stationary -= 1

class BleedBuff(Buff):

	def on_init(self):
		self.stack_type = STACK_INTENSITY
		self.damage = 3
		self.color = Tags.Blood.color
		self.name = "Bleed"
		self.buff_type = BUFF_TYPE_CURSE
		self.asset = ["status", "bleed"]
		self.description = "Take [Physical] damage each turn"

	def get_description(self):
		return ("Take {damage} [Physical] damage each turn", {"damage":self.damage})

	def on_applied(self, owner):
		if owner.resists[Tags.Physical] >= 100: return ABORT_BUFF_APPLY

	def on_advance(self):
		o = self.owner
		if o.resists[Tags.Physical] >= 100: o.remove_buff(self); return
		o.deal_damage(self.damage, Tags.Physical, self)
		o.level.show_effect(o.x, o.y, Tags.Blood, minor=True)


class Poison(Buff):

	def on_init(self):
		self.stack_type = STACK_NONE
		self.damage = 1
		self.color = Tags.Poison.color
		self.name = "Poison"
		self.buff_type = BUFF_TYPE_CURSE
		self.asset = ['status', 'poison']
		self.description = "Take 1 [Poison] damage each turn\nCannot heal"
		self.resists[Tags.Heal] = 100

	def on_applied(self, owner):
		if owner.resists[Tags.Poison] >= 100: return ABORT_BUFF_APPLY

	def on_advance(self):
		if self.owner.resists[Tags.Poison] >= 100: self.owner.remove_buff(self); return
		self.owner.deal_damage(self.damage, Tags.Poison, self)

class LichSealSoulSpell(Spell):

	def on_init(self):
		self.name = "Soul Jar"
		self.description = "Summon a Soul Jar\nThe caster cannot die while the Soul Jar lives"
		self.range = 0
		self.cool_down = 20

	def can_cast(self, x, y):
		return not self.caster.has_buff(Soulbound) and Spell.can_cast(self, x, y)

	def cast_instant(self, x, y):

		phylactery = Unit()
		phylactery.name = 'Soul Jar'
		phylactery.max_hp = 6
		phylactery.stationary = True
		phylactery.tags = [Tags.Construct, Tags.Dark]

		if self.summon(phylactery, Point(x, y)): self.caster.apply_buff(Soulbound(phylactery))

class BloodrageBuff(Buff):
	
	def __init__(self, bonus):
		self.bonus = bonus
		Buff.__init__(self)

	def on_init(self):
		self.name = 'Bloodrage'
		self.color = Tags.Demon.color
		self.asset = ['status', 'bloodlust']
		self.global_bonuses['damage'] = self.bonus
		self.stack_type	= STACK_INTENSITY	

def bloodrage(amount=2):
	def onhit(caster, target):
		caster.apply_buff(BloodrageBuff(amount), 10)
	return onhit

def ProjectileUnit():

	unit = Unit()
	unit.max_hp = 8

	unit.resists[Tags.Physical] = 100
	unit.resists[Tags.Dark] = 100
	unit.resists[Tags.Holy] = 100
	unit.resists[Tags.Fire] = 100
	unit.resists[Tags.Lightning] = 100
	unit.resists[Tags.Arcane] = 100
	unit.resists[Tags.Ice] = 100

	unit.flying = True

	return unit

class Thorns(Buff):

	def __init__(self, damage, dtype=Tags.Physical):
		self.damage = damage
		self.dtype = dtype
		Buff.__init__(self)
		self.name = "Thorns"
		self.description = ("Deal {damage} {dtype} damage to melee attackers", {'damage': self.damage, 'dtype': formatted_tag(self.dtype)})
		self.color = dtype.color

	def on_init(self):
		self.global_triggers[EventOnSpellCast] = self.on_spell
		self.stack_type = STACK_INTENSITY

	def on_spell(self, evt):
		if self.owner.level.get_unit_at(evt.x, evt.y) != self.owner: return
		if not (isinstance(evt.spell, LeapAttack) or isinstance(evt.spell, PullAttack) or evt.spell.melee): return # Distance is implied to be 1 if its a leap or a melee
		if not are_hostile(self.owner, evt.caster): return # prevent thorns on positive melee interactions i.e. vampiricism/siege golem building
		self.owner.level.queue_spell(self.do_thorns(evt.caster))

	def do_thorns(self, unit):
		if not are_hostile(self.owner, unit): return
		unit.deal_damage(self.damage, self.dtype, self)
		yield

class CurseRetaliation(Buff):

	def __init__(self, name=None, buff=None, buff_dur=None, color_tag=None, melee=False):
		Buff.__init__(self)
		self.name = name
		self.color = color_tag.color
		self.buff = buff
		self.buff_dur = buff_dur
		self.buff_name = buff().name
		self.melee = melee
		self.global_triggers[EventOnSpellCast] = self.on_spell
		self.stack_type = STACK_INTENSITY

	def get_description(self):
		target = 'enemy melee attackers' if self.melee else 'enemy attackers'
		if self.buff_dur == 1: return ("Inflict {buff} on {target} for 1 turn", {'buff': self.buff_name, 'target': target})
		if self.buff_dur > 1: return ("Inflict {buff} on {target} for {duration} turns", {'buff': self.buff_name, 'target': target, 'duration': self.buff_dur})
		return ("Inflict {buff} on {target}", {'buff': self.buff_name, 'target': target})

	def on_spell(self, evt):
		if self.owner.level.get_unit_at(evt.x, evt.y) != self.owner: return
		if self.melee and not ((isinstance(evt.spell, LeapAttack) or isinstance(evt.spell, PullAttack) or evt.spell.melee)): return # Distance is implied to be 1 if its a leap or a melee
		if not are_hostile(self.owner, evt.caster): return
		evt.caster.apply_buff(self.buff(), self.buff_dur)

class DeathCurseRetaliation(Buff):

	def __init__(self, name=None, buff=None, buff_dur=0, color_tag=None):
		Buff.__init__(self)
		self.name = name
		self.color = color_tag.color
		self.buff = buff
		self.buff_dur = buff_dur
		self.buff_name = buff().name
		self.owner_triggers[EventOnDeath] = self.on_death
		self.stack_type = STACK_INTENSITY

	def get_description(self):
		target = 'killer'
		if self.buff_dur == 1: return ("Inflict {buff} on {target} for 1 turn", {'buff': self.buff_name, 'target': target})
		if self.buff_dur > 1: return ("Inflict {buff} on {target} for {duration} turns", {'buff': self.buff_name, 'target': target, 'duration': self.buff_dur})
		return ("Inflict {buff} on {target}", {'buff': self.buff_name, 'target': target})

	def on_death(self, evt):
		if not evt.damage_event: return
		if not evt.damage_event.source: return
		if not evt.damage_event.source.owner: return
		evt.damage_event.source.owner.apply_buff(self.buff(), self.buff_dur)

class DeathBlessing(Buff):

	def __init__(self, buff, buff_dur=0):
		self.buff = buff
		self.buff_dur = buff_dur
		self.buff_name = buff().name
		Buff.__init__(self)

	def on_init(self):
		self.name = "Death Blessing"
		self.buff_type = BUFF_TYPE_PASSIVE
		self.owner_triggers[EventOnDeath] = self.on_death

	def get_description(self):
		if self.buff_dur == 1: return ("On death, grant {buff} to allies for 1 turn", {'buff': self.buff_name})
		if self.buff_dur > 1: return ("On death, grant {buff} to allies for {duration} turns", {'buff': self.buff_name, 'duration': self.buff_dur})
		return ("On death, grant {buff} to allies", {'buff': self.buff_name})

	def on_death(self, evt):
		for ally in self.owner.get_allies():
			ally.apply_buff(self.buff(), self.buff_dur)

class RetaliationBuff(Buff):

	def __init__(self, damage, dtype):
		self.damage = damage
		self.dtype = dtype
		Buff.__init__(self)
		self.name = "%s Retaliation" % dtype.name
		self.description = ("On taking damage from an enemy, deal {damage} {dtype} damage to that enemy", {'damage': self.damage, 'dtype': formatted_tag(self.dtype)})

	def on_init(self):
		self.owner_triggers[EventOnDamaged] = self.on_damage

	def on_damage(self, evt):
		if not evt.source or not evt.source.owner: return
		if not are_hostile(evt.source.owner, self.owner): return
		if not self.owner.is_alive(): return
		self.owner.level.queue_spell(self.do_damage(evt.source.owner))

	def do_damage(self, unit):
		if not unit.is_alive(): return
		self.owner.level.show_path_effect(self.owner, unit, self.dtype, minor=True)
		unit.deal_damage(self.damage, self.dtype, self)
		yield


class ChanceToBecome(Buff):

	def __init__(self, spawner, chance, name=None):
		self.spawner = spawner
		self.chance = chance
		if name is None: self.spawn_name = self.spawner().name
		else: self.spawn_name = name
		Buff.__init__(self)

	def get_description(self):
		return ("Each turn, {val}% chance to become a {name}", {'val':int(self.chance*100), 'name':self.spawn_name})

	def on_advance(self):
		if random.random() > self.chance: return
		self.owner.kill(trigger_death_event=False)
		self.owner.level.summon(self.owner, self.get_unit())

	def get_unit(self):
		u = self.spawner()
		src = getattr(getattr(self, 'owner', None), 'source', None)
		if src: u.source = src; apply_minion_bonuses(src, u)
		return u

	def get_unit_extra_examine_tooltips(self):
		return [self.get_unit()]

class MatureInto(Buff):

	def __init__(self, spawner, duration):
		Buff.__init__(self)
		self.spawner = spawner
		self.spawn_name = None
		self.mature_duration = duration

	def on_advance(self):
		self.mature_duration -= 1
		if self.mature_duration <= 0:
			self.owner.kill(trigger_death_event=False)
			new_unit = self.spawner()
			new_unit.team = self.owner.team
			new_unit.source = self.owner.source
			if new_unit.source: apply_minion_bonuses(self.owner.source, new_unit)
			p = self.owner.level.get_summon_point(self.owner.x, self.owner.y, radius_limit=8, flying=new_unit.flying)
			if p: self.owner.level.add_obj(new_unit, p.x, p.y)


	def get_tooltip(self):
		if not self.spawn_name: self.spawn_name = self.spawner().name
		return ("Will become a {spawn_name} in {val} turns", {'spawn_name':self.spawn_name, 'val':self.mature_duration})

	def get_unit(self):
		u = self.spawner()
		src = getattr(getattr(self, 'owner', None), 'source', None)
		if src: u.source = src; apply_minion_bonuses(src, u)
		return u

	def get_unit_extra_examine_tooltips(self):
		return [self.get_unit()]

class SpawnOnDeath(Buff):

	def __init__(self, spawners, num_spawns):
		Buff.__init__(self)
		self.num_spawns = num_spawns
		self.set_spawners(spawners)
		self.name = "Summon On Death"
		self.stack_type = STACK_INTENSITY
		self.buff_type = BUFF_TYPE_PASSIVE
		self.owner_triggers[EventOnDeath] = self.on_death
		self.apply_bonuses = True

	def set_spawners(self, spawners):
		self.spawners = spawners
		self.spawn_specs = self.normalize()

	def normalize(self):
		if isinstance(self.spawners, (list, tuple)):
			if isinstance(self.num_spawns, (list, tuple)):
				return list(zip(self.spawners, self.num_spawns)) # if you have lists of uneven length, it will truncate
			return [(s, self.num_spawns) for s in self.spawners] # if you put in just one number, assume you want the same number of everything
		return [(self.spawners, self.num_spawns)]

	def get_unit(self, spawner):
		u = spawner()
		src = getattr(getattr(self, 'owner', None), 'source', None)
		if src and self.apply_bonuses: u.source = src; apply_minion_bonuses(src, u)
		return u

	def get_unit_extra_examine_tooltips(self):
		extras = []
		seen = set()
		for spawner, _count in self.spawn_specs:
			if spawner in seen: continue
			seen.add(spawner)
			extras.append(self.get_unit(spawner))
		return extras

	def get_tooltip(self):
		parts = ["On death, summon "]
		for i, (spawner, count) in enumerate(self.spawn_specs):
			if i > 0: parts.append(" and " if i == len(self.spawn_specs) - 1 else ", ")
			name = spawner().name
			if count == 1: parts.append(("a {name}", {"name": name}))
			else: parts.append(("{count} {name}s", {"count": count, "name": name}))
		return parts

	def on_death(self, evt):
		self.owner.level.queue_spell(self.spawn())

	def spawn(self):
		for spawner, count in self.spawn_specs:
			for _ in range(count):
				unit = spawner()
				if self.owner.source and self.apply_bonuses:
					unit.source = self.owner.source
					apply_minion_bonuses(self.owner.source, unit)
				unit.parent = self.owner
				self.summon(unit)
				yield

class SpawnOnHeal(Buff):

	def __init__(self, spawn_fn):
		Buff.__init__(self)
		self.spawn_fn = spawn_fn
		self.spawner_name = spawn_fn().name
		self.owner_triggers[EventOnHealed] = self.on_heal

	def get_description(self):
		return ("Summon a {unit} nearby when this creature is healed", {'unit': self.spawner_name})

	def on_heal(self, evt):
		self.summon(self.spawn_fn())

	def get_unit(self):
		return self.spawn_fn()

	def get_unit_extra_examine_tooltips(self):
		return[self.get_unit()]

class RespawnAs(Buff):

	def __init__(self, spawner, name=None):
		Buff.__init__(self)
		self.spawner = spawner
		self.spawn_name = name
		if not self.spawn_name: self.spawn_name = self.spawner().name
		self.name = "Respawn As %s" % self.spawn_name

	def on_init(self):
		self.owner_triggers[EventOnDamaged] = self.on_damage

	def on_damage(self, evt):

		if self.owner.cur_hp <= 0:
			if self.owner.has_buff(Soulbound): return
			# Supress death events- this creature isn't really dying, its respawning
			self.owner.kill(trigger_death_event=False)
			self.owner.level.queue_spell(self.respawn())

	def respawn(self):
		new_unit = self.owner.level.summon(self.owner, self.get_unit())
		if new_unit:
			new_unit.parent = self.owner
			new_unit.refresh()
		yield

	def get_unit(self):
		u = self.spawner()
		src = getattr(getattr(self, 'owner', None), 'source', None)
		if src: u.source = src; apply_minion_bonuses(src, u)
		return u

	def get_unit_extra_examine_tooltips(self):
		return [self.get_unit()]

	def get_tooltip(self):
		return ("On reaching 0 hp, transforms into a {name}", {'name': self.spawn_name})

class SplittingBuff(Buff):
	# A buff that makes a creature split into smaller versions of itself when killed

	def __init__(self, spawner, children=2):
		Buff.__init__(self)
		self.spawner = spawner
		self.owner_triggers[EventOnDeath] = self.on_death
		self.children = children
		self.child_example = spawner()
		self.name = "Splitting"

	def on_death(self, evt):
		self.owner.level.queue_spell(self.split())

	def split(self):
		for i in range(self.children):
			unit = self.spawner()
			if unit.max_hp == 0: return
			self.summon(unit)
			yield
			
	def get_tooltip(self):
		return ("On death, splits into {val} smaller versions of itself", {'val':self.children})

class SimpleBurst(Spell):

	def __init__(self, damage, radius, damage_type=Tags.Physical, cool_down=0, ignore_walls=False, onhit=None, extra_desc=None):
		Spell.__init__(self)
		self.damage = damage
		self.damage_type = damage_type
		dt_name = damage_type[0].name if isinstance(damage_type, list) else damage_type.name
		self.name = "%s Burst" % dt_name
		self.cool_down = cool_down
		self.radius = radius
		self.friendly_fire = True
		self.ignore_walls = ignore_walls
		self.onhit = onhit
		self.extra_desc = extra_desc

	def on_init(self):
		self.range = 0
		
	def get_ai_target(self):
		for p in self.get_impacted_tiles(self.caster.x, self.caster.y):
			u = self.caster.level.get_unit_at(p.x, p.y)
			if u and are_hostile(u, self.caster):
				return self.caster

		return None

	def get_description(self):
		desc = "Deal damage in a burst around the caster"
		if self.ignore_walls:
			desc += "\nIgnores walls"
		if self.extra_desc:
			desc += self.extra_desc
		return desc

	def get_impacted_tiles(self, x, y):
		for stage in Burst(self.caster.level, Point(x, y), self.get_stat('radius'), ignore_walls=self.ignore_walls or not self.get_stat('requires_los')):
			for p in stage:
				yield p

	def can_threaten(self, x, y):
		if distance(self.caster, Point(x, y)) > self.radius: return False
		# Potential optimization- only make the aoe once per frame
		return Point(x, y) in list(self.get_impacted_tiles(self.caster.x, self.caster.y))

	def cast_instant(self, x, y):
		caster = self.caster
		level = caster.level

		damage = self.get_stat('damage')
		dtype = self.damage_type if isinstance(self.damage_type, list) else [self.damage_type] # allow for dual types

		caster_tiles = set(caster.iter_occupied_points())
		for p in self.get_impacted_tiles(x, y):
			if p in caster_tiles: continue # slower but x,y direct match didn't work for 3x3s
			for dt in dtype:
				level.deal_damage(p.x, p.y, damage, dt, self)
				if self.onhit:
					unit = level.get_unit_at(p.x, p.y)
					if unit: self.onhit(caster, unit)


def spawn_webs(unit):

	adj = unit.level.get_points_in_ball(unit.x, unit.y, 1.5)
	candidates = [p for p in adj if unit.level.get_unit_at(p.x, p.y) is None and unit.level.tiles[p.x][p.y].can_see and not isinstance(unit.level.tiles[p.x][p.y].cloud, SpiderWeb)]

	if candidates:
		p = random.choice(candidates)
		web = SpiderWeb()
		web.owner = unit
		unit.level.add_obj(web, p.x, p.y)

def Skeleton(hp=0, stationary=False, flying=False, name=None):
	u = Unit()
	u.name = "Skeleton"
	u.asset_name = "skeletal"
	if name is not None: u.name = f"Skeletal {name}"
	u.stationary = stationary
	u.flying = flying
	if stationary: u.asset_name = 'skeletal_stationary'
	elif flying: u.asset_name = 'skeletal_flying'
	u.max_hp = hp
	u.spells.append(SimpleMeleeAttack(5))
	u.tags.append(Tags.Undead)
	return u

def raise_skeleton(owner, unit, source=None):
	if Tags.Living not in unit.tags: return
	skeleton = Skeleton(hp=unit.max_hp, stationary=unit.stationary, flying=unit.flying, name=unit.name)
	skeleton.team = owner.team
	skeleton.source = source
	p = unit.level.get_summon_point(unit.x, unit.y, flying=unit.flying)
	if p: owner.level.summon(owner=owner, unit=skeleton, target=p); return skeleton
	else: return None

class DeathExplosion(Buff):

	def __init__(self, damage, radius, damage_type, custom_name=None, custom_color=None):
		Buff.__init__(self)
		self.damage = damage
		self.damage_type = damage_type if isinstance(damage_type, list) else [damage_type]
		self.radius = radius
		self.name = custom_name or "Death Explosion"
		self.color = custom_color

	def get_description(self):
		dtypes = [f"[{tag_label(tag)}:{tag_key(tag)}]" for tag in self.damage_type]
		dtype_str = " and ".join(dtypes)
		return ("On death, deal {damage} {dtype_str} damage to units within {radius} tiles", {'damage':self.damage, 'dtype_str':dtype_str, 'radius':self.radius})

	def on_applied(self, owner):
		self.owner_triggers[EventOnDeath] = self.on_death

	def on_death(self, death_event):
		self.owner.level.queue_spell(self.explode(self.owner.level, self.owner.x, self.owner.y))

	def explode(self, level, x, y):
		for stage in Burst(self.owner.level, self.owner, self.radius):
			for point in stage:
				for dtype in self.damage_type:
					self.owner.level.deal_damage(point.x, point.y, self.damage, dtype, self)
			yield

class Generator2Buff(Buff):

	def __init__(self, spawner):
		self.spawner = spawner
		self.example_monster = self.spawner()
		Buff.__init__(self)

	def on_init(self):
		self.min_turns = 7
		self.max_turns = 10
		self.turns = random.randint(self.min_turns, self.max_turns)

	def on_advance(self):
		# Dont spawn while stunned
		if self.owner.is_stunned():
			return
		self.turns -= 1
		if self.turns == 0:
			unit = self.spawner()
			if self.owner.source:
				unit.source = self.owner.source
				apply_minion_bonuses(self.owner.source, unit)
			
			self.summon(unit)
			self.turns = random.randint(self.min_turns, self.max_turns)

	def get_tooltip(self):
		return ("Spawn a {monster} every {min_turns} to {max_turns} turns\nNext spawn: {turns} turns",
				{'monster': self.example_monster.name, 'min_turns': self.min_turns, 'max_turns': self.max_turns, 'turns': self.turns})

def MonsterSpawner(spawn_func):
	unit = Unit()
	example_monster = spawn_func()

	unit.name = "%s Spawner" % example_monster.name
	unit.max_hp = 40

	unit.asset = ["lair_combo"] + example_monster.get_asset()

	summon = SimpleSummon(spawn_func, cool_down=random.randint(6, 9), sort_dist=True)
	unit.spells.append(summon)
	unit.cool_downs[summon] = min(summon.cool_down, random.randint(6, 9))
	unit.stationary = True
	unit.is_lair = True

	return unit

class WizardNightmare(Spell):

	def __init__(self, damage_type=None):
		Spell.__init__(self) # have this first so the new damage_type = [] in spell init doesn't override it
		if not damage_type:
			damage_type = [Tags.Dark, Tags.Arcane]
		self.damage_type = damage_type


	def on_init(self):
		self.name = "Nightmare Aura"
		self.cool_down = 16
		self.duration = 8
		self.radius = 7
		self.range = 0
		dtype_str = self.damage_type.name if isinstance(self.damage_type, str) else ' or '.join([t.name for t in self.damage_type])
		self.description = ("Each turn, deal 2 {dtype} damage to all enemies within {radius} tiles\nLasts {duration} turns",
							{'dtype': dtype_str, 'radius': self.radius, 'duration': self.duration})

	def get_ai_target(self):
		for u in self.caster.level.get_units_in_ball(self.caster, radius=self.radius):
			if are_hostile(u, self.caster):
				return self.caster
		return None


	def cast_instant(self, x, y):
		buff = DamageAuraBuff(damage=2, damage_type=self.damage_type, radius=self.get_stat('radius'))
		buff.name = buff.name or "Nightmare Aura"
		self.caster.apply_buff(buff, self.get_stat('duration'))

class WizardSelfBuff(Spell):

	def __init__(self, buff, duration, cool_down=0):
		self.buff = buff
		self.duration = duration
		Spell.__init__(self)
		self.cool_down = cool_down
		self.description = ("Apply {buff} for {duration} turns", {'buff': self.buff().name, 'duration': duration})
		
	def on_init(self):
		self.range = 0
		self.name = self.buff().name

	def get_ai_target(self):
		if not self.caster.has_buff(self.buff):
			return self.caster
		return None

	def cast_instant(self, x, y):
		self.caster.apply_buff(self.buff(), self.get_stat('duration'))

class WizardHealAura(Spell):

	def __init__(self, heal=2, duration=8, cool_down=16, radius=7):
		Spell.__init__(self)
		self.heal = heal
		self.duration = duration
		self.cool_down = 16
		self.radius = radius
		self.description = ("Heal allies within [{radius}:radius] tiles for [{heal} HP:heal] each turn\nLasts [{duration} turns:duration]",
							{'radius': self.radius, 'heal': self.heal, 'duration': self.duration})
		

	def get_ai_target(self):
		for u in self.caster.level.get_units_in_ball(self.caster, radius=self.radius):
			if not are_hostile(u, self.caster) and u.cur_hp < u.max_hp:
				return self.caster
		return None

	def on_init(self):
		self.name = "Heal Aura"
		self.range = 0

	def cast_instant(self, x, y):
		self.caster.apply_buff(HealAuraBuff(heal=self.get_stat('heal'), radius=self.get_stat('radius')), self.get_stat('duration'))

class WizardBloodlust(Spell):

	def on_init(self):
		self.name = "Bloodlust"
		self.bonus = 3
		self.radius = 5
		self.range = 0
		self.duration = 5
		self.cool_down = 10
		self.damage_type = Tags.Fire

	def get_description(self):
		return ("All allies within {radius} tiles gain +{bonus} damage for {duration} turns",
				{'radius': self.radius, 'bonus': self.bonus, 'duration': self.duration})

	def cast_instant(self, x, y):
		for p in self.caster.level.get_points_in_ball(self.caster.x, self.caster.y, self.radius):
			unit = self.caster.level.get_unit_at(p.x, p.y)
			if unit and not are_hostile(unit, self.caster):
				bloodlust = BloodrageBuff(self.bonus)
				unit.apply_buff(bloodlust, self.duration)

class GlassReflection(Buff):

	def on_init(self):
		self.name = "Sorcery Mirror"
		self.global_triggers[EventOnSpellCast] = self.on_spell_cast

	def on_spell_cast(self, evt):
		if evt.x == self.owner.x and evt.y == self.owner.y and Tags.Sorcery in evt.spell.tags:
			self.owner.level.queue_spell(self.reflect(evt))

	def reflect(self, evt):
		spell = type(evt.spell)()
		spell.cur_charges = 1
		spell.caster = self.owner
		spell.owner = self.owner
		spell.statholder = evt.caster

		if spell.can_cast(evt.caster.x, evt.caster.y):
			self.owner.level.defer_cast(self.owner, spell, evt.caster.x, evt.caster.y)

		yield

	def get_tooltip(self):
		return "When a [Sorcery] spell targets this unit, cast a copy targeting the original caster"

class ShieldAllySpell(Spell):

	def __init__(self, shields=1, range=5, cool_down=0):
		self.shields = shields
		Spell.__init__(self)
		self.range = range
		self.cool_down = cool_down

	def on_init(self):
		self.name = "Shield Ally"
		self.description = ("Grant an ally {shields} shields up to a max of {max}", {'shields': self.shields, 'max': self.shields})
		self.target_allies = True

	def cast_instant(self, x, y):
		unit = self.caster.level.get_unit_at(x, y)
		if unit and unit.shields < self.shields:
			unit.add_shields(self.shields - unit.shields)

	def can_cast(self, x, y):
		unit = self.caster.level.get_unit_at(x, y)
		if unit and unit.shields < self.shields:
			return Spell.can_cast(self, x, y)
		else:
			return False

class WizardBlizzard(Spell):

	def on_init(self):
		self.name = "Blizzard"
		self.radius = 4
		self.cool_down = 10
		self.range = 8
		self.damage_type = Tags.Ice

	def get_description(self):
		return "Create Blizzards around the target"

	def get_ai_target(self):
		return self.get_corner_target(self.radius)

	def cast(self, x, y):
		for stage in Burst(self.caster.level, Point(x, y), self.get_stat('radius'), ignore_walls=not self.get_stat('requires_los')):
			for p in stage:
				cloud = BlizzardCloud(self.caster)
				self.caster.level.add_obj(cloud, p.x, p.y)
			yield

class WizardQuakeport(Spell):

	def on_init(self):
		self.name = "Quakeport"
		self.description = "Teleport to the target and create a local earthquake"
		self.range = 12
		self.cool_down = 19
		self.can_target_self = True

	def get_ai_target(self):
		return self.caster

	def cast(self, x, y):
		randomly_teleport(self.caster, radius=self.range)
		yield

		points = list(self.caster.level.get_points_in_ball(self.caster.x, self.caster.y, 4))
		random.shuffle(points)

		def is_important_floor(p):
			# Not a floor = certainly not an IMPORTANT floor
			if not self.caster.level.tiles[p.x][p.y].can_walk:
				return False
			# If floor, and all adjacent tiles are floor, unimportant
			return all(self.caster.level.tiles[q.x][q.y].can_walk for q in self.caster.level.get_adjacent_points(p, filter_walkable=False))

		for p in points:
			# Dont mess with floors, as this could make the level unpathable, and we dont want this spell to do that.
			if is_important_floor(p):
				continue

			unit = self.caster.level.get_unit_at(p.x, p.y)
			prop = self.caster.level.tiles[p.x][p.y].prop
			if random.random() < .65:
				self.caster.level.deal_damage(p.x, p.y, self.get_stat('damage'), Tags.Physical, self)
				if random.random() < .7:
					self.caster.level.make_floor(p.x, p.y)
				elif not unit and not prop:
					if random.random() < .5:
						self.caster.level.make_wall(p.x, p.y)
					else:
						self.caster.level.make_chasm(p.x, p.y)
			if random.random() < .25:
				yield

class RetributiveEffect(Buff):

	def __init__(self, name="Retribution", effect=None):
		Buff.__init__(self)
		self.stack_type = STACK_INTENSITY
		self.name = name
		if effect: self.retribution = effect
		self.owner_triggers[EventOnDamaged] = self.retribution

	def retribution(self, evt):
		pass

class TeleportyBuff(Buff):

	def __init__(self, radius=4, chance=.25, flash = None, hop=False):
		Buff.__init__(self)
		self.flash = flash
		self.radius = radius
		self.chance = chance
		self.hop = hop
		self.buff_type = BUFF_TYPE_PASSIVE
		self.name = "Passive Teleportation"

	def on_advance(self):
		if random.random() > self.chance: return
		if self.owner.is_stunned(): return
		if self.owner.has_buff(ChannelBuff): return # Dont interupt channels, its dumb
		old = Point(self.owner.x, self.owner.y)
		randomly_teleport(self.owner, self.radius, requires_los=self.hop)
		for p in self.owner.level.get_points_in_line(old, self.owner)[:-1]: self.owner.level.show_effect(p.x, p.y, Tags.Translocation, minor=True)

	def get_tooltip(self):
		moveword = "hop" if self.hop else "blink"
		return ("Each turn, {chance}% chance to {move} to a random tile up to {radius} tiles away",
				{'chance': int(self.chance * 100), 'move': moveword, 'radius': self.radius})

	def get_tooltip_color(self):
		return Tags.Translocation.color

class TouchedBySorcery(Buff):

	def __init__(self, element):
		self.element = element
		Buff.__init__(self)

	def on_init(self):
		self.resists[self.element] = 100
		self.name = "Touched by %s" % self.element.name
		self.color = self.element.color
		spell = SimpleRangedAttack(damage=5, range=7, damage_type=self.element)
		spell.name = "Sorcery"
		self.spells = [spell]
		self.asset = ['status', '%s_eye' % self.element.name.lower()]

class Acidified(Buff):

	def on_init(self):
		self.name = "Acidified"
		self.resists[Tags.Poison] = -100
		self.buff_type = BUFF_TYPE_CURSE
		self.asset = ['status', 'amplified_poison']
		self.color = Tags.Poison.color

class Electrified(Buff):

	def on_init(self):
		self.name = "Electrified"
		self.resists[Tags.Lightning] = -10
		self.buff_type = BUFF_TYPE_CURSE
		self.stack_type	= STACK_INTENSITY
		self.asset = ['status', 'amplified_lightning']
		self.color = Tags.Lightning.color

def drain_spell_charges(caster, target):
	possible_spells = [s for s in target.spells if s.cur_charges > 0]
	if possible_spells:
		spell = random.choice(possible_spells)
		spell.drain_charges(1)

def drain_all_spell_charges(caster, target):
	possible_spells = [s for s in target.spells if s.cur_charges > 0]
	if possible_spells:
		spell = random.choice(possible_spells)
		spell.drain_charges(spell.cur_charges)
	

def grant_minion_spell(spell_class, unit, master, cool_down=1, pre_insert=True, replace=None):
	spell = spell_class()

	if not master: master = unit # allow granting of spells before a master is created/assigned (for Tooltip purposes)

	spell.statholder = master
	spell.caster = unit
	spell.owner = unit

	master_spell = master.get_or_make_spell(spell_class)
	if getattr(master_spell, 'damage_type', None): # so upgrades which change the spell's damage type can register for AI targeting
		if isinstance(master_spell.damage_type, list): spell.damage_type = master_spell.damage_type.copy()
		else: spell.damage_type = master_spell.damage_type

	pending_upgrades = []
	for upg in master.buffs:
		if not isinstance(upg, Upgrade): continue
		if upg.prereq != master_spell: continue
		if isinstance(upg, SpellUpgrade): continue
		clone = upg.clone_for_spell(master_spell, spell)
		if not clone: continue
		clone.prereq = spell
		pending_upgrades.append(clone)

	spell.tags = master_spell.tags.copy() # to inherit upgrade added tag bonuses

	# Erase charges and add cooldown 
	spell.max_charges = 0
	spell.cur_charges = 0
	spell.cool_down = cool_down

	if pre_insert: unit.spells.insert(0, spell)
	elif replace: unit.spells[unit.spells.index(replace)] = spell
	else: unit.spells.append(spell)

	for upg in pending_upgrades: unit.apply_buff(upg)

	# Return spell so further modifications can be made (range twiddling ect)
	return spell

def mod_resist(u, tag, val):
	u.resists[tag] += val

def set_resist(u, tag, val):
	if u.resists[tag] > val: return
	u.resists[tag] = val

def add_tag(u, tag):
	if tag not in u.tags: u.tags.append(tag)

class AdaptiveArmorResistBuff(Buff):

	def __init__(self, tag, resist):
		Buff.__init__(self)
		self.buff_type = BUFF_TYPE_BLESS
		self.stack_type = STACK_INTENSITY
		self.name = "%s Armor" % tag.name
		self.color = tag.color
		self.resists[tag] = resist


class AdaptiveArmorBuff(Buff):

	def __init__(self, resist):
		self.res_amt = resist
		Buff.__init__(self)

	def on_init(self):
		self.name = "Adaptive Armor"
		self.description = ("When this unit takes damage, it gains {resist}% resistance to that damage type for 1 turn", {'resist': self.res_amt})
		self.owner_triggers[EventOnDamaged] = self.on_damage

	def on_damage(self, evt):
		if evt.damage <= 0: return
		self.owner.apply_buff(AdaptiveArmorResistBuff(evt.damage_type, self.res_amt), 1)


class SharedPainBuff(Buff):

	def on_init(self):
		self.name = "Shared Pain"
		self.asset = ['status', 'shared_pain']
		self.color = Tags.Blood.color
		self.description = "Damage dealt to this unit is also dealt to other units with this debuff"
		self.owner_triggers[EventOnDamaged] = self.on_damaged
		self.buff_type = BUFF_TYPE_CURSE

	def on_damaged(self, evt):
		if not evt.source: return
		if type(evt.source) is type(self): return
		targets = [u for u in self.owner.level.units if u.is_alive() and u.get_buff(SharedPainBuff) and u is not self.owner]
		for t in targets: self.owner.level.queue_spell(self.do_redeal(t, evt.damage, evt.damage_type))

	def do_redeal(self, target, damage, dtype):
		if not target.is_alive(): return
		self.owner.level.show_beam(self.owner, target, dtype)
		target.deal_damage(damage, dtype, self)
		yield

class SummonReinforcements(Buff):

	def __init__(self, spawn_fn, num_sum, health_pct, effect_tag=Tags.Translocation):
		Buff.__init__(self)
		self.spawner = spawn_fn
		self.summon_name = spawn_fn().name
		self.num_sum = num_sum
		self.health_pct = health_pct
		self.effect_tag = effect_tag
		self.triggered = False

	def on_init(self):
		self.name = "Reinforcements"
		self.owner_triggers[EventOnDamaged] = self.on_damaged

	def get_description(self):
		return ("Summon {num_sum} {summon_name} when HP falls below {health_pct}%",
				{"num_sum": self.num_sum, "summon_name":self.summon_name, "health_pct":self.health_pct})

	def on_damaged(self, evt):
		if self.triggered: return
		o = self.owner
		if o.cur_hp > (o.max_hp * (self.health_pct/100)): return # don't call them in yet
		if not o.is_alive(): return # reinforcements couldn't make it in time
		o.level.queue_spell(self.do_summon())
		self.triggered = True

	def get_unit(self):
		u = self.spawner()
		src = getattr(getattr(self, 'owner', None), 'source', None)
		if src: u.source = src; apply_minion_bonuses(src, u)
		return u

	def get_unit_extra_examine_tooltips(self):
		return [self.get_unit()]

	def do_summon(self):
		for _ in range(self.num_sum):
			summoned = self.summon(self.get_unit(), radius=15, sort_dist=False) # they can be far away, they're rushing in to help
			if summoned: yield from self.owner.level.show_path_effect(self.owner, summoned, self.effect_tag, pause_frames=1)
