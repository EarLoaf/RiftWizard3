import os, sys, re, json

os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
os.environ['SDL_VIDEO_MINIMIZE_ON_FOCUS_LOSS'] = "0"
os.environ['SDL_VIDEO_WINDOW_POS'] = "0,0"
os.environ['SDL_RENDER_SCALE_QUALITY'] = "linear"

# Make all the relative file accesses work
cheats_enabled = False
can_enable_cheats = False
if getattr(sys, 'frozen', False):
	dname = os.path.dirname(sys.executable)
	can_enable_cheats = 'cheatmode' in sys.argv
elif __file__:
	dname = os.path.dirname(os.path.abspath(__file__))
	can_enable_cheats = True
os.chdir(dname)

import pygame
import pygame.locals
from pygame._sdl2.video import Window
import numpy as np
from Game import *
from Spells import spell_tags
from collections import defaultdict, OrderedDict
from copy import copy

from Vaults import VaultPortal
from LevelGen import all_biomes
import gc
import time

import dill as pickle

import text

import ModHandler
import SteamAdapter
from Mutators import *


main_view = None


idle_frame = 0
idle_subframe = 0

cloud_frame_clock = 0

STATUS_ICON_SIZE = 20
SPRITE_SIZE = 60
PORTAL_ICON_SIZE = 60
OG_SPRITE_SIZE = 16
FONT_SIZE = 24
FONT_PAD = 2

FONT_DIR = os.path.join('rl_data', 'fonts')

FONT_MAP = {
	'default': "SpecialElite-Regular.ttf"
}

FONT_SIZE_MAP = {
	'default' : 24
}

TEXT_OFFSET = SPRITE_SIZE * 1.1
ROW_GAP = 4
FRAME_PERIOD = 12

ANIM_ATTACK = 0
ANIM_IDLE = 1

SUB_FRAMES = [
	6,
	6,
]

HIT_FLASH_SUBFRAMES = 2
HIT_FLASH_ALPHA = 200
DEATH_FLASH_SUBFRAMES = 7
DEATH_FLASH_ALPHA = 240

FLASH_NONE = 0
FLASH_HIT = 1
FLASH_DEATH = 2

HIT_FLASH_ASSET = ['UI', 'square_white_target']
DEATH_FLASH_ASSET = ['UI', 'square_invalid_target']

STATUS_SUBFRAMES = 6

SPELL_FLASH_FRAMES = 12
EQUIPMENT_FLASH_FRAMES = 6
SPELL_SPEED_FLASH_FRAMES = 12
SPELL_SPEED_NAMES = ("Normal", "Fast", "Turbo", "Xturbo")

CRAFT_ANIM_FRAME_HOLD = 6

SOUND_COOLDOWN_MAX = 2

CHAR_HEART = 'HP'#chr(3)
CHAR_SHIELD = 'SH' #chr(4)
CHAR_CLARITY = 'CL'

HP_BAR_ASSETS = {
	0: ['ui', 'hp_60'],
	1: ['ui', 'hp_180'],
	2: ['ui', 'hp_300'],
}

SUPPORTED_SOUND_EXTS = ('.mp3',  '.ogg', '.wav')

BORDER_COLOR = (100, 100, 100)

COLOR_CLARITY = (2, 136, 209)
COLOR_WHITE = (255, 255, 255)

HIGHLIGHT_COLOR = (90, 90, 90)
UNAVAILABLE_COLOR = (120, 120, 120)

STATE_LEVEL = 0
STATE_CHAR_SHEET = 1
STATE_SHOP = 2
STATE_TITLE = 3
STATE_OPTIONS = 4
STATE_MESSAGE = 5
STATE_CONFIRM = 6
STATE_REMINISCE = 7
STATE_REBIND = 8
STATE_COMBAT_LOG = 9
STATE_PICK_MODE = 10
STATE_PICK_TRIAL = 11
STATE_SETUP_CUSTOM = 12
STATE_PICK_MUTATOR_PARAMS = 13
STATE_ENTER_MUTATOR_VALUE = 14
STATE_SELECT_LANGUAGE = 15
STATE_SAVE_PREFS = 16
STATE_MODS = 17
STATE_HOW_TO_PLAY = 18

SHOP_TYPE_SPELLS = 0
SHOP_TYPE_CRAFTING = 1
SHOP_TYPE_SPELL_UPGRADES = 2
SHOP_TYPE_SHOP = 3
SHOP_TYPE_BESTIARY = 4
SHOP_TYPE_COMPONENT_SELECTION = 5
SHOP_TYPE_WARDROBE = 6

CHAR_SHEET_SELECT_TYPE_SPELLS = 0
CHAR_SHEET_SELECT_TYPE_EQUIPMENT = 1

MAX_PATH_DELAY = 1

# Default vals, should get overriden later
RENDER_WIDTH = 1920
RENDER_HEIGHT = 1080
LEVEL_SIZE = 18

SIZE_LARGE = 3

SIZE = SIZE_LARGE

def set_size(new_size):
	global SIZE
	global RENDER_WIDTH
	global RENDER_HEIGHT
	global LEVEL_SIZE

	if new_size == SIZE_LARGE:
		RENDER_WIDTH = 1920
		RENDER_HEIGHT = 1080
		LEVEL_SIZE = 18
		set_level_size(18)
		SIZE = SIZE_LARGE

if SIZE:
	set_size(SIZE)

SPELL_FAIL_LOCKOUT_FRAMES = 12


def apply_option_defaults(options):
	if 'sound_volume' not in options:
		options['sound_volume'] = 100
	if 'music_volume' not in options:
		options['music_volume'] = 100
	if 'spell_speed' not in options:
		options['spell_speed'] = 0
	if 'window_mode' not in options:
		options['window_mode'] = WINDOW_MODE_FULLSCREEN
	if 'windowed_size' not in options:
		options['windowed_size'] = None
	if 'autosave_progress' not in options:
		options['autosave_progress'] = True
	if 'save_screenshots' not in options:
		options['save_screenshots'] = True
	if 'save_prev_runs' not in options:
		options['save_prev_runs'] = False
	if 'enabled_mods' not in options:
		options['enabled_mods'] = []
	if 'selected_outfit' not in options:
		options['selected_outfit'] = 'player'
	if 'last_custom_mutators' not in options:
		options['last_custom_mutators'] = []


def load_saved_options():
	try:
		with open('options2.dat', 'rb') as options_file:
			options = pickle.load(options_file)
	except:
		options = {}

	apply_option_defaults(options)
	return options

COLOR_VICTORY = Tags.Ice.color.to_tup()

# How many squares per frame are flipped from one level to the next during deploy/undeploy
DEPLOY_SPEED = 4

# Attempt to fix high DPI for windows
try:
	import ctypes
	errorCode = ctypes.windll.shcore.SetProcessDpiAwareness(2)
except:
	pass

# Hack to fix highlight bug
class SpellCharacterWrapper(object):
	def __init__(self, spell):
		self.spell = spell

	def __eq__(self, other):
		if not isinstance(other, SpellCharacterWrapper):
			return False
		return self.spell == other.spell

	def __hash__(self):
		return hash(self.spell)

	def get_extra_examine_tooltips(self):
		return self.spell.get_extra_examine_tooltips()

class TooltipExamineTarget(object):

	def __init__(self, desc):
		self.description = desc

	def get_description(self):
		return self.description or ""

class ShopFilterTarget(object):

	def __init__(self, action, category, value=None, name=None, description=None):
		self.action = action
		self.category = category
		self.value = value
		self.name = name
		self.description = description

	def __eq__(self, other):
		if not isinstance(other, ShopFilterTarget): return False
		return self.action == other.action and self.category == other.category and self.value == other.value

	def __hash__(self):
		return hash((self.action, self.category, self.value))

	def get_description(self):
		return self.description or ""


LEARN_SPELL_TARGET = TooltipExamineTarget("Learn a new spell")
CRAFTING_TARGET = TooltipExamineTarget("Craft Equipment")
CHAR_SHEET_TARGET = TooltipExamineTarget("Learn new spells and abilities")
INSTRUCTIONS_TARGET = TooltipExamineTarget("Learn how to play")
OPTIONS_TARGET = TooltipExamineTarget("Adjust options")
REROLL_PORTALS_TARGET = TooltipExamineTarget("Reroll the destinations of all rifts\nOnce per level")
COMBAT_LOG_TARGET = TooltipExamineTarget("Open the combat log")

SEARCH_INPUT_TARGET = "SEARCH_INPUT_TARGET"

SHOP_FILTER_TAGS = "tags"
SHOP_FILTER_ATTR = "attr"
SHOP_FILTER_BONUS = "bonus"
SHOP_FILTER_GAIN_TAGS = "gain_tags"
SHOP_FILTER_GAIN_ATTR = "gain_attr"
SHOP_FILTER_RECIPE_TAGS = "recipe_tags"
SHOP_FILTER_GLOBAL = "global"
SHOP_FILTER_CATEGORY = "category"
SHOP_FILTER_TOGGLE = "toggle"
SHOP_FILTER_CLEAR = "clear"
SHOP_FILTER_CAN_AFFORD = "can_afford"
SHOP_FILTER_UNUSED = "unused"
SHOP_FILTER_UNVICTORIED = "unvictoried"

shop_filter_category_names = {
	SHOP_FILTER_TAGS: "Tags",
	SHOP_FILTER_ATTR: "Attributes",
	SHOP_FILTER_BONUS: "Bonuses",
	SHOP_FILTER_GAIN_TAGS: "Gain Tags",
	SHOP_FILTER_GAIN_ATTR: "Gain Attributes",
	SHOP_FILTER_RECIPE_TAGS: "Recipe",
}
shop_filter_categories_by_type = {
	SHOP_TYPE_SPELLS: (SHOP_FILTER_TAGS, SHOP_FILTER_ATTR),
	SHOP_TYPE_CRAFTING: (SHOP_FILTER_TAGS, SHOP_FILTER_ATTR),
}
shop_filter_hidden_categories_by_type = {
	SHOP_TYPE_SPELLS: (SHOP_FILTER_GAIN_TAGS, SHOP_FILTER_GAIN_ATTR),
	SHOP_TYPE_CRAFTING: (SHOP_FILTER_RECIPE_TAGS, SHOP_FILTER_BONUS),
}
shop_filter_modifier_categories = (SHOP_FILTER_GAIN_TAGS, SHOP_FILTER_GAIN_ATTR, SHOP_FILTER_RECIPE_TAGS, SHOP_FILTER_BONUS)

shop_filter_spell_attrs = (
	'damage',
	'duration',
	'hp_cost',
	'max_channel',
	'max_charges',
	'num_targets',
	'radius',
	'range',
)
shop_filter_minion_attrs = (
	'minion_damage',
	'minion_duration',
	'minion_health',
	'minion_range',
	'num_summons',
)
shop_filter_attrs = shop_filter_spell_attrs + shop_filter_minion_attrs

shop_global_filter_names = {
	SHOP_FILTER_CAN_AFFORD: "Can Afford",
	SHOP_FILTER_UNUSED: "Never Purchased",
	SHOP_FILTER_UNVICTORIED: "Never Victory",
}
shop_global_filter_descriptions = {
	SHOP_FILTER_CAN_AFFORD: "Only show options that you can afford to purchase",
	SHOP_FILTER_UNUSED: "Only show options that you have never purchased",
	SHOP_FILTER_UNVICTORIED: "Only show options that you have never achieved victory with",
}

DEPLOY_TARGET = TooltipExamineTarget(text.deploy_text)

TOOLTIP_PREV = 0
TOOLTIP_NEXT = 1
TOOLTIP_EXIT = 2
TOOLTIP_UPGRADE = 3

HOW_TO_PLAY_PREV = "how_to_play_prev"
HOW_TO_PLAY_NEXT = "how_to_play_next"

COMBAT_LOG_PREV_TARGET = "combat_log_prev"
COMBAT_LOG_NEXT_TARGET = "combat_log_next"

UI_TOP = 0
UI_LEFT = 1
UI_RIGHT = 2
UI_BOTTOM = 3
UI_UPPER_LEFT = 4
UI_UPPER_RIGHT = 5
UI_LOWER_LEFT = 6
UI_LOWER_RIGHT = 7
UI_FIRST = 0
UI_LAST = UI_LOWER_RIGHT

TITLE_SELECTION_LOAD = 0
TITLE_SELECTION_ABANDON = 1
TITLE_SELECTION_NEW = 2
TITLE_SELECTION_OPTIONS = 3
TITLE_SELECTION_HELP = 4
TITLE_SELECTION_BESTIARY = 5
TITLE_SELECTION_DISCORD = 6
TITLE_SELECTION_MODS = 7
TITLE_SELECTION_CREDITS = 8
TITLE_SELECTION_EXIT = 9
TITLE_SELECTION_MAX = TITLE_SELECTION_EXIT

MOD_MENU_BROWSE = 0
MOD_MENU_UPLOAD = 1
MOD_MENU_BACK = 2
MOD_MENU_RESET = 3
MOD_MENU_RESTART = 4
MOD_MENU_UPLOAD_CANCEL = 5

OPTION_HELP = 0
OPTION_SOUND_VOLUME = 1
OPTION_MUSIC_VOLUME = 2
OPTION_SPELL_SPEED = 3
OPTION_CONTROLS = 4
OPTION_RETURN = 5
OPTION_EXIT = 6
OPTION_LANGUAGE_SELECT = 7
OPTION_WINDOW_MODE = 8
OPTION_SAVE_PREFERENCES = 9
OPTION_WARDROBE = 10

SAVE_PREF_AUTOSAVE = 0
SAVE_PREF_SCREENSHOTS = 1
SAVE_PREF_SAVE_RUNS = 2
SAVE_PREF_BACK = 3

WINDOW_MODE_WINDOWED = 'windowed'
WINDOW_MODE_BORDERLESS = 'borderless'
WINDOW_MODE_FULLSCREEN = 'fullscreen'
WINDOW_MODE_CHOICES = [WINDOW_MODE_WINDOWED, WINDOW_MODE_BORDERLESS, WINDOW_MODE_FULLSCREEN]
MIN_WINDOW_SCALE = 0.5
DEFAULT_WINDOW_SCALE = .75
MAX_WINDOW_SCALE = 3.0
WINDOW_MARGIN_PX = (0, 0)
SDL_WINDOW_MAXIMIZED = 0x00000080

GAME_MODE_NORMAL = 0
GAME_MODE_TRIALS = 1
GAME_MODE_WEEKLY = 2
GAME_MODE_RANDOM = 3
GAME_MODE_CUSTOM = 4
GAME_MODE_MAX = GAME_MODE_CUSTOM

COLOR_XP = (229, 191, 0)

tooltip_colors = {}
for tag in Tags: tooltip_colors[tag.name.lower()] = tag.color
tooltip_colors.update(attr_colors)
tooltip_colors['default'] = Color(255, 255, 255)

tooltip_colors['petrify'] = Tags.Construct.color
tooltip_colors['petrified'] = tooltip_colors['petrify']
tooltip_colors['petrifies'] = tooltip_colors['petrify']

tooltip_colors['frozen'] = Tags.Ice.color
tooltip_colors['freezes'] = Tags.Ice.color
tooltip_colors['freeze'] = Tags.Ice.color

tooltip_colors['stunned'] = Tags.Physical.color
tooltip_colors['stun'] = tooltip_colors['stunned']
tooltip_colors['stuns'] = tooltip_colors['stunned']

tooltip_colors['berserk'] = COLOR_DAMAGE
tooltip_colors['berserked'] = COLOR_DAMAGE
tooltip_colors['berserks'] = COLOR_DAMAGE

tooltip_colors['poisoned'] = Tags.Poison.color
tooltip_colors['poisons'] = Tags.Poison.color

tooltip_colors['blind'] = Tags.Holy.color
tooltip_colors['blinded'] = tooltip_colors['blind']
tooltip_colors['blinds'] = tooltip_colors['blind']

tooltip_colors['glassify'] = Tags.Glass.color
tooltip_colors['glassified'] = Tags.Glass.color
tooltip_colors['glassed'] = Tags.Glass.color

tooltip_colors['sleep'] = Tags.Arcane.color
tooltip_colors['sleeps'] = Tags.Arcane.color

tooltip_colors['silence'] = Tags.Arcane.color
tooltip_colors['silenced'] = Tags.Arcane.color
tooltip_colors['silences'] = Tags.Arcane.color

tooltip_colors['necrosis'] = Tags.Dark.color

tooltip_colors['fear'] = Tags.Dark.color
tooltip_colors['fears'] = Tags.Dark.color
tooltip_colors['feared'] = Tags.Dark.color

tooltip_colors['blind'] = Tags.Eye.color
tooltip_colors['blinds'] = Tags.Eye.color
tooltip_colors['blinded'] = Tags.Eye.color

tooltip_colors['bleed'] = Tags.Blood.color
tooltip_colors['bleeds'] = Tags.Blood.color
tooltip_colors['bleeding'] = Tags.Blood.color

tooltip_colors['hemorrhage'] = Tags.Blood.color

tooltip_colors['poisoned'] = Tags.Poison.color
tooltip_colors['poisons'] = Tags.Poison.color

tooltip_colors['quick_cast'] = Color(255, 255, 255)
tooltip_colors['requires_los'] = Tags.Translocation.color
tooltip_colors['wizard'] = Color(2, 136, 209)
tooltip_colors['enemy'] = tooltip_colors['damage']
tooltip_colors['ally'] = Tags.Conjuration.color
tooltip_colors['hp_cost'] = Tags.Blood.color
tooltip_colors['max_channel'] = Color(153, 51, 102)
tt_attrs = [
	'num_targets',
	'damage',
	'duration',
	'radius',

	'shields',
	'shot_cooldown',
	'strikechance',
	'cooldown',
	'max_channel',

	'num_summons',
	'minion_health',
	'minion_damage',
	'minion_duration',
	'minion_range',
]

REPEAT_INTERVAL = .05
REPEAT_DELAY = .2

MUSIC_OVER_EVENT = pygame.USEREVENT + 1

# import logging
# mem_log = logging.getLogger("memory")
# mem_log.setLevel(logging.DEBUG)
# mem_log.propagate = False
# mem_log.addHandler(logging.FileHandler('mem_log.txt', mode='w'))

Channel = namedtuple('Channel', 'name channel base_volume')

image_cache = {}
projectile_image_cache = {}
scaled_icon_cache = {}
icon_atlas_surfaces = {}
icon_atlas_manifest = None
recolored_icon_cache = {}
flash_texture_cache = {}
inline_asset_icon_cache = {}
missing_asset_fallbacks = set()
ICON_ATLAS_DIR = os.path.join('rl_data', 'UI', 'icon_atlas')
ICON_ATLAS_MANIFEST = os.path.join(ICON_ATLAS_DIR, 'manifest.json')

TEXT_SIZE_CACHE_LIMIT = 32768
TEXT_RENDER_CACHE_LIMIT = 8192

size_cache = OrderedDict()
render_cache = OrderedDict()

def get_lru_value(cache, key):
	if key not in cache: return None
	cache.move_to_end(key)
	return cache[key]

def set_lru_value(cache, key, value, limit):
	cache[key] = value
	cache.move_to_end(key)
	if len(cache) > limit: cache.popitem(last=False)
	return value

def load_unit_preview_image(asset):
	# The preview cache retains only the currently examined unit
	cached = image_cache.get(tuple(asset))
	if cached is not None: return cached
	if asset[0] != 'lair_combo': return pygame.image.load(resolve_image_path(asset)).convert_alpha()

	monster_image = load_unit_preview_image(asset[1:])
	lair_image = load_unit_preview_image(['char', 'lair'])
	image = pygame.Surface(lair_image.get_size(), pygame.SRCALPHA).convert_alpha()
	image.blit(monster_image, (
		(image.get_width() - monster_image.get_width()) // 2,
		(image.get_height() - monster_image.get_height()) // 2,
	))
	image.blit(lair_image, (0, 0))
	return image

def get_image(asset):
	# the point is you don't want to repeatedly load stuff, so you put it in an image cache
	assert(asset)
	assert(isinstance(asset, list))
	assert(isinstance(asset[0], str))

	key = tuple(asset)
	if key in image_cache: return image_cache[key]

	# experimenting with putting monster pic over lair
	if asset[0] == 'lair_combo':
		monster_asset = asset[1:]  # e.g., ['char', 'goblin']
		monster_img = get_image(monster_asset)
		lair_img = get_image(['char', 'lair'])

		# Safety check
		if monster_img is None or lair_img is None:
			image_cache[key] = lair_img or pygame.Surface((32, 32), pygame.SRCALPHA)  # Fallback
			return image_cache[key]

		combo = pygame.Surface(lair_img.get_size(), pygame.SRCALPHA)
		mx = (combo.get_width() - monster_img.get_width()) // 2
		my = (combo.get_height() - monster_img.get_height()) // 2
		combo.blit(monster_img, (mx, my))
		combo.blit(lair_img, (0, 0))
		image_cache[key] = combo
		return combo

	# First check
	path = resolve_image_path(asset)
	if path in image_cache:image_cache[key] = image_cache[path]; return image_cache[key]
	try:
		if os.path.getsize(path) == 0: image_cache[key] = None; image_cache[path] = None; return None
		i = pygame.image.load(path).convert_alpha()
		image_cache[key] = i
		image_cache[path] = i
		return i
	except:
		traceback.print_exc()
		print("Error loading image %s" % path)
		image_cache[key] = None
		image_cache[path] = None
		return None


def slice_image_strip(sheet, frame_w, frame_h):
	cols = sheet.get_width() // frame_w
	frames = []
	for i in range(cols):
		f = pygame.Surface((frame_w, frame_h), pygame.SRCALPHA).convert_alpha()
		f.blit(sheet, (0, 0), (i * frame_w, 0, frame_w, frame_h))
		frames.append(f)
	return frames

CORNERS_MAP = {
    None: (),
    'top_left_corner': ('top_left_corner',),
    'top_right_corner': ('top_right_corner',),
    'bottom_left_corner':('bottom_left_corner',),
    'bottom_right_corner': ('bottom_right_corner',),
    'top': ('top_left_corner','top_right_corner'),
    'bottom': ('bottom_left_corner','bottom_right_corner'),
    'left': ('top_left_corner','bottom_left_corner'),
    'right': ('top_right_corner','bottom_right_corner'),
    'square': ('top_left_corner','top_right_corner','bottom_left_corner','bottom_right_corner'),
}

TOKEN_RE = re.compile(r"""
	\[
		(?P<m_name>[^\]:]+)
		(?::(?P<m_tag>[^\]]+))?
	\]
	(?P<m_punc>[.,:;!?]+(?=\s|$))?
	|
	(?P<word>[\w%'/\-]+(?:[.,:;!?]+(?=\s|$))?)
	|
	(?P<punc>[.,:;!?()]+)
	|
	(?P<space>\s+)
	|
	(?P<other>.)
""", re.VERBOSE)

def fit_text_to_width(font, s, max_w):
	t = resolve_text(s)
	if max_w <= 0:
		return ""
	if cached_size(font, t) <= max_w:
		return t
	ell = "..."
	if not t:
		return Raw(ell)

	# Find the longest prefix that still fits once ellipsis is appended.
	lo = 0
	hi = len(t)
	while lo < hi:
		mid = (lo + hi + 1) // 2
		if font.size(t[:mid] + ell)[0] <= max_w:
			lo = mid
		else:
			hi = mid - 1

	return Raw(t[:lo] + ell) if lo else Raw(ell)

def pick_font_path(lang):
	path = (FONT_MAP.get(lang)
			or FONT_MAP.get(lang.split('-', 1)[0])
			or FONT_MAP['default'])
	return os.path.join(FONT_DIR, path)

def pick_font_size(lang):
	return (FONT_SIZE_MAP.get(lang)
		or FONT_SIZE_MAP.get(lang.split('-', 1)[0])
		or FONT_SIZE_MAP['default'])

def make_font(lang, px_size):
	return pygame.font.Font(pick_font_path(lang), px_size)

def cache_key_font(font):
	return (id(font), font.get_height())

def cached_size(font, text, cache_ok=True):
	if not cache_ok: return font.size(text)[0]
	k = (cache_key_font(font), text)
	w = get_lru_value(size_cache, k)
	if w is None:
		w = font.size(text)[0]
		set_lru_value(size_cache, k, w, TEXT_SIZE_CACHE_LIMIT)
	return w

def cached_render(font, color, text, cache_ok=True):
	if not cache_ok: return font.render(text, True, color)
	k = (cache_key_font(font), color, text)
	surf = get_lru_value(render_cache, k)
	if surf is None:
		surf = font.render(text, True, color)
		set_lru_value(render_cache, k, surf, TEXT_RENDER_CACHE_LIMIT)
	return surf

def has_markup(s):
	return '[' in s and ']' in s

def get_asset_key(obj):
	if isinstance(obj, (Spell, Upgrade, Unit, Component, Equipment, Prop, Buff)): return obj.get_asset()
	elif isinstance(obj, Tag): return None
	print(f"Can't get asset for {obj}, {type(obj)} is unsupported.")
	return None

def get_icon_atlas_manifest():
	global icon_atlas_manifest
	if icon_atlas_manifest is not None: return icon_atlas_manifest
	if not os.path.exists(ICON_ATLAS_MANIFEST):
		icon_atlas_manifest = {}
		return icon_atlas_manifest
	try:
		with open(ICON_ATLAS_MANIFEST, 'r', encoding='utf-8') as f:
			icon_atlas_manifest = json.load(f)
	except:
		traceback.print_exc()
		icon_atlas_manifest = {}
	return icon_atlas_manifest

def get_atlas_icon(asset, target_px):
	size_data = get_icon_atlas_manifest().get('sizes', {}).get(str(target_px))
	if not size_data: return None

	rect = size_data.get('entries', {}).get('/'.join(asset))
	if not rect: return None

	atlas_key = str(target_px)
	atlas = icon_atlas_surfaces.get(atlas_key)
	if atlas is False: return None
	if atlas is None:
		image_name = size_data.get('image')
		if not image_name: return None
		path = os.path.join(ICON_ATLAS_DIR, image_name)
		if not os.path.exists(path):
			icon_atlas_surfaces[atlas_key] = False
			return None
		try:
			atlas = pygame.image.load(path).convert_alpha()
			icon_atlas_surfaces[atlas_key] = atlas
		except:
			traceback.print_exc()
			icon_atlas_surfaces[atlas_key] = False
			return None

	return atlas.subsurface(rect)

def has_image(asset):
	path = os.path.join('rl_data', *asset) + '.png'
	if os.path.exists(path): return True
	return bool(ModHandler.find_asset(asset))

def resolve_image_path(asset):
	path = os.path.join('rl_data', *asset) + '.png' # look in main files first
	if os.path.exists(path): return path
	mod_path = ModHandler.find_asset(asset)
	if mod_path: return mod_path # look in mod files

	missing_key = tuple(asset)
	if missing_key not in missing_asset_fallbacks:
		missing_asset_fallbacks.add(missing_key)
		print(f"Missing asset for {'/'.join(asset)}")

	path = os.path.join('rl_data', 'tiles', 'crafting', 'default') + '.png' # grab the fallback
	if os.path.exists(path): return path
	raise Exception(f'Cannot find asset for {asset}')

def get_projectile_image(proj_name):
	if isinstance(proj_name, list):
		cache_key = tuple(proj_name)
		if cache_key in projectile_image_cache: return projectile_image_cache[cache_key]
		image = get_image(proj_name)
		projectile_image_cache[cache_key] = image
		return image

	assert(isinstance(proj_name, str))

	if proj_name in projectile_image_cache: return projectile_image_cache[proj_name]

	candidate_assets = [['effects', 'proj', proj_name]]
	path_parts = [part for part in os.path.normpath(proj_name.replace('\\', os.sep).replace('/', os.sep)).split(os.sep) if part]

	if len(path_parts) > 1:
		candidate_assets.append(path_parts)

		if 'mods' in path_parts:
			mods_index = path_parts.index('mods')
			if mods_index + 2 < len(path_parts):
				candidate_assets.append(path_parts[mods_index + 1:])

	for asset in candidate_assets:
		if has_image(asset):
			image = get_image(asset)
			projectile_image_cache[proj_name] = image
			return image

	image = get_image(['effects', 'proj', proj_name])
	projectile_image_cache[proj_name] = image
	return image

def get_char_frame_size(surface, radius):
	if surface.get_width() % SPRITE_SIZE != 0: return OG_SPRITE_SIZE * (1 + radius * 2)
	return SPRITE_SIZE * (1 + radius * 2)

def get_glow_mask(surface, mode='fill', radius=0):
	frame_size = get_char_frame_size(surface, radius)

	# only alpha matters for the new art: transparent is empty, anything painted is part of the body
	alpha = pygame.surfarray.pixels_alpha(surface)[:frame_size, :frame_size]
	occupied = alpha != 0
	del alpha

	glow_mask = np.zeros((frame_size+2, frame_size+2), dtype=bool)

	if mode == 'fill':
		glow_mask[:frame_size, :frame_size] = occupied
	elif mode == 'edge':
		# edge masks need a 1-pixel border around the frame so edge pixels can expand outward
		body_mask = np.zeros_like(glow_mask)
		body_mask[1:frame_size+1, 1:frame_size+1] = occupied
		neighbors = np.zeros_like(glow_mask)

		# shift the body mask in the 4 cardinal directions, then keep only the rim
		neighbors[:-1, :] |= body_mask[1:, :]
		neighbors[1:, :] |= body_mask[:-1, :]
		neighbors[:, :-1] |= body_mask[:, 1:]
		neighbors[:, 1:] |= body_mask[:, :-1]
		glow_mask = neighbors & ~body_mask
	else: assert False, f"Unknown glow mode {mode}"

	mask_surface = pygame.Surface((frame_size+2, frame_size+2), flags=pygame.SRCALPHA)
	mask_alpha = glow_mask.astype(np.uint8) * 255

	# write the mask into both alpha and rgb so later tinting can just multiply a copied white mask
	alpha_view = pygame.surfarray.pixels_alpha(mask_surface)
	alpha_view[:, :] = mask_alpha

	rgb_view = pygame.surfarray.pixels3d(mask_surface)
	rgb_view[:, :, 0] = mask_alpha
	rgb_view[:, :, 1] = mask_alpha
	rgb_view[:, :, 2] = mask_alpha

	del rgb_view
	del alpha_view

	return mask_surface

def tint_glow_mask(mask_surface, color):
	# copy the cached white mask and tint it for this specific request
	glow_frame = mask_surface.copy()
	glow_frame.fill((*color.to_tup(), 255), special_flags=pygame.BLEND_RGBA_MULT)
	return glow_frame

def get_flash_texture(asset, frame_size):
	key = (tuple(asset), frame_size)
	if key in flash_texture_cache: return flash_texture_cache[key]

	tile = get_image(asset)
	size = frame_size + 2
	texture = pygame.Surface((size, size), pygame.SRCALPHA).convert_alpha()
	for x in range(0, size, SPRITE_SIZE):
		for y in range(0, size, SPRITE_SIZE):
			texture.blit(tile, (x, y))

	flash_texture_cache[key] = texture
	return texture

def load_flash_textures():
	for frame_size in (SPRITE_SIZE, SPRITE_SIZE * 3, SPRITE_SIZE * 5):
		get_flash_texture(HIT_FLASH_ASSET, frame_size)
		get_flash_texture(DEATH_FLASH_ASSET, frame_size)


class LookSpell(Spell):

	def on_init(self):
		self.range = 99
		self.requires_los = False
		self.show_tt = False
		self.quick_cast = True
		self.name = "look"

	def can_cast(self, x, y):
		return False

	def cast_instant(self, x, y):
		pass

	def can_pay_costs(self):
		return True

	def pay_costs(self):
		pass

	def get_tab_targets(self):
		return [tile.unit or tile.prop for tile in self.caster.level.iter_tiles() if (tile.prop or tile.unit) and (tile.unit != self.caster)]

class WalkSpell(Spell):

	def on_init(self):
		self.range = 99
		self.requires_los = False
		self.show_tt = False
		self.name = "walk"

	def can_cast(self, x, y):
		return not self.caster.level.has_hostile_units()

	def can_pay_costs(self):
		return True

	def pay_costs(self):
		pass

	def get_tab_targets(self):
		props = [tile.prop for tile in self.caster.level.iter_tiles() if tile.prop]
		portals = [p for p in props if isinstance(p, Portal)]
		others = [p for p in props if not isinstance(p, Portal)]
		others.sort(key = lambda p: distance(p, self.caster))

		return others + portals

	def cast_instant(self, x, y):
		main_view.path = self.caster.level.find_path(self.caster, Point(x, y), self.caster, pythonize=True)

COLOR_LAIR_PRIMARY = (255, 0, 0, 255)
COLOR_LAIR_SECONDARY = (0, 255, 0, 255)

class SpriteSheet(object):

	def __init__(self, param, radius=0):
		assert(param)
		assert(isinstance(param, list))

		self.param = param
		self.radius = radius
		self.image = get_image(param)

		# missing asset will tell you the missing asset path
		if not self.image: raise Exception(f"Missing sprite asset {self.param}")

		frame_size = get_char_frame_size(self.image, self.radius)
		self.frame_size = frame_size

		self.anim_frames = {k: [] for k in [ANIM_ATTACK, ANIM_IDLE]}
		self.anim_frames_flipped = {k: [] for k in [ANIM_ATTACK, ANIM_IDLE]}
		self.anim_lengths = {}

		# Validate divisibility
		if (self.image.get_width() % frame_size != 0) or (self.image.get_height() % frame_size != 0):
			print(f"Warning: Asset {self.param} has size {self.image.get_width()}x{self.image.get_height()} not divisible by frame_size {frame_size}")
			assert False

		columns = self.image.get_width() // frame_size # max number of frames in a given animation, whichever is the longest
		rows = self.image.get_height() // frame_size

		row_for_attack = max(0, rows - 2)
		row_for_idle = max(0, rows - 1)

		attack_rect = pygame.Rect(0, row_for_attack * frame_size, frame_size, frame_size)
		attack_frame = self.image.subsurface(attack_rect)
		self.anim_frames[ANIM_ATTACK].append(attack_frame)
		self.anim_frames_flipped[ANIM_ATTACK].append(pygame.transform.flip(attack_frame, True, False))
		self.anim_lengths[ANIM_ATTACK] = 1

		subimage_y = row_for_idle * frame_size
		for col in range(columns):
			rect = pygame.Rect(frame_size * col, subimage_y, frame_size, frame_size)
			subimage = self.image.subsurface(rect)
			self.anim_frames[ANIM_IDLE].append(subimage)
			self.anim_frames_flipped[ANIM_IDLE].append(pygame.transform.flip(subimage, True, False))
		self.anim_lengths[ANIM_IDLE] = columns

		# Fallback if attack or idle is missing
		for anim in [ANIM_ATTACK, ANIM_IDLE]:
			if not self.anim_frames[anim]:
				borrow = ANIM_IDLE if anim == ANIM_ATTACK else ANIM_ATTACK
				if self.anim_frames[borrow]:
					fallback = self.anim_frames[borrow][0]
				else:
					fallback = pygame.Surface((frame_size, frame_size), pygame.SRCALPHA)
					pygame.draw.circle(fallback, (255, 0, 0, 255), (frame_size // 2, frame_size // 2), frame_size // 4)
					print(f"NOTE: {self.param} missing anim {anim}; using placeholder.")
				self.anim_frames[anim] = [fallback]
				self.anim_frames_flipped[anim] = [pygame.transform.flip(fallback, True, False)]
				self.anim_lengths[anim] = 1

		self.glow_cache = {}
		self.glow_mask_cache = {}
		self.textured_flash_cache = {}

	def get_glow_mask_surface(self, anim, frame, flipped, mode='fill'):
		frame_dict = self.anim_frames if not flipped else self.anim_frames_flipped

		# Default to idle frame 1 if requested frame does not exist
		if anim not in frame_dict or len(frame_dict[anim]) <= frame:
			frame_surface = self.anim_frames[ANIM_IDLE][0]
			mask_key = (ANIM_IDLE, 0, False, mode)
		else:
			frame_surface = frame_dict[anim][frame]
			mask_key = (anim, frame, flipped, mode)

		if mask_key not in self.glow_mask_cache:
			self.glow_mask_cache[mask_key] = get_glow_mask(frame_surface, mode, radius=self.radius)

		return self.glow_mask_cache[mask_key]

	def get_glow_frame(self, anim, frame, color, flipped, mode='fill'):
		key = (anim, frame, color, flipped, mode)
		if key in self.glow_cache: return self.glow_cache[key]

		glow_frame = tint_glow_mask(self.get_glow_mask_surface(anim, frame, flipped, mode), color)
		self.glow_cache[key] = glow_frame
		return glow_frame

	def get_textured_flash_frame(self, anim, frame, flipped, asset, alpha, mode='fill'):
		key = (tuple(asset), anim, frame, flipped, alpha, mode)
		if key in self.textured_flash_cache: return self.textured_flash_cache[key]

		flash_frame = get_flash_texture(asset, self.frame_size).copy()
		flash_frame.blit(self.get_glow_mask_surface(anim, frame, flipped, mode), (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
		if alpha < 255: flash_frame.set_alpha(alpha)
		self.textured_flash_cache[key] = flash_frame
		return flash_frame

	def get_hit_flash_frame(self, anim, frame, flipped, alpha=HIT_FLASH_ALPHA, mode='fill'):
		return self.get_textured_flash_frame(anim, frame, flipped, HIT_FLASH_ASSET, alpha, mode)

	def get_death_flash_frame(self, anim, frame, flipped, alpha=DEATH_FLASH_ALPHA, mode='fill'):
		return self.get_textured_flash_frame(anim, frame, flipped, DEATH_FLASH_ASSET, alpha, mode)

	def __reduce__(self):
		return (SpriteSheet, (self.param, self.radius))

class LeapEffect(object):

	def __init__(self, x, y, unit, color, duration=7):
		colors = [tween_color(color, Color(0, 0, 0), i / duration) for i in range(duration)]

		anim = unit.Transform_Anim or unit.Anim
		if anim:
			self.sprites = [anim.sheet.get_glow_frame(ANIM_ATTACK, 0, color, flipped=unit.face_left, mode='edge') for color in colors]
			self.finished = False
		else:
			self.sprites = None
			self.finished = True
		self.frame = 0
		self.duration = duration
		self.x = x
		self.y = y
		self.pixel_x = (x - unit.radius) * SPRITE_SIZE
		self.pixel_y = (y - unit.radius) * SPRITE_SIZE

	def draw(self, display):
		if self.sprites: display.blit(self.sprites[self.frame], (self.pixel_x, self.pixel_y))
		self.frame += 1
		if self.frame >= self.duration: self.finished = True

class ProjectileEffect(object):

	def __init__(self, x, y, sprites):
		self.sprites = sprites
		self.frame = 0
		self.duration = len(sprites)
		self.finished = False
		self.x = x
		self.y = y

	def draw(self, display):
		display.blit(self.sprites[self.frame], (self.x * SPRITE_SIZE, self.y * SPRITE_SIZE))
		self.frame += 1
		if self.frame >= self.duration:
			self.finished = True

class UnitSprite(object):

	def __init__(self, unit, sprite_sheet, view):
		self.anim = ANIM_IDLE
		self.anim_frame = 0
		self.anim_subframe = 0
		self.unit = unit
		self.event_manager = None

		# Register for events if the unit is on a level otherwise do not
		if hasattr(unit, "level"):
			self.event_manager = unit.level.event_manager
			self.event_manager.register_entity_trigger(EventOnSpellCast, unit, self.on_attack)
			self.event_manager.register_entity_trigger(EventOnDamaged, unit, self.on_damaged)
			self.event_manager.register_entity_trigger(EventOnShieldRemoved, self.unit, self.on_unshielded)
			self.event_manager.register_entity_trigger(EventOnDeath, unit, self.on_death)
			self.event_manager.register_entity_trigger(EventOnItemPickup, unit, self.on_item)

		self.sheet = sprite_sheet

		self.flash_sub_frame = 0
		self.flash_type = FLASH_NONE

		self.finished = False

	def unregister(self):
		if not self.event_manager: return
		event_manager = self.event_manager
		self.event_manager = None
		event_manager.unregister_entity_trigger(EventOnSpellCast, self.unit, self.on_attack)
		event_manager.unregister_entity_trigger(EventOnDamaged, self.unit, self.on_damaged)
		event_manager.unregister_entity_trigger(EventOnShieldRemoved, self.unit, self.on_unshielded)
		event_manager.unregister_entity_trigger(EventOnDeath, self.unit, self.on_death)
		event_manager.unregister_entity_trigger(EventOnItemPickup, self.unit, self.on_item)

	def advance(self):
		self.anim_subframe += 1

		if self.anim_subframe >= SUB_FRAMES[self.anim]:
			self.anim_subframe = 0
			self.anim_frame += 1
			if self.anim_frame >= self.sheet.anim_lengths[self.anim]:
				# For now always go back to idle.  So idle loops, and other anims return to idle.
				self.anim = ANIM_IDLE
				self.anim_frame = 0


		# Synchronize idle anims
		if self.anim == ANIM_IDLE:
			self.anim_frame = idle_frame  % self.sheet.anim_lengths[self.anim]
			# Prevent flashing of placeholders
			if self.anim_frame >= self.sheet.anim_lengths[self.anim]: self.anim_frame = 0
			# freeze stunned creature
			if self.unit.anim_is_frozen(): self.anim_frame = 0

		# Channelers always in attack, and always ready to snap out of it
		if self.unit.channeling: # flag check faster than buff sweep
			self.anim = ANIM_ATTACK
			self.anim_frame = 0
			self.anim_subframe = SUB_FRAMES[ANIM_ATTACK] - 2

	def on_unshielded(self, evt):
		if self.unit.is_player_controlled: main_view.play_sound("shield_break")

	def on_attack(self, evt):

		if not evt.spell.animate: return

		# Do not try to play attack anim if it does not exist
		if not self.sheet.anim_lengths.get(ANIM_ATTACK, None): return

		self.anim = ANIM_ATTACK
		self.anim_frame = 0
		self.anim_subframe = 0

		if type(evt.spell) not in [SimpleMeleeAttack]:
			if self.unit.is_player_controlled:
				if Tags.Conjuration in evt.spell.tags:
					main_view.play_sound("summon")
				elif Tags.Translocation in evt.spell.tags:
					main_view.play_sound("teleport")
				elif Tags.Word in evt.spell.tags:
					main_view.play_sound("word")
				elif Tags.Sorcery in evt.spell.tags:
					main_view.play_sound("sorcery")
				elif Tags.Enchantment in evt.spell.tags:
					main_view.play_sound("enchant")

			else:
				main_view.play_sound("enemy")


	def on_damaged(self, evt):
		if evt.damage < 1 or not self.unit.is_alive(): return

		self.flash_type = FLASH_HIT
		self.flash_sub_frame = 0

		# sound
		if self.unit.is_player_controlled:
			main_view.play_sound("hit_player")
			main_view.cur_hp_flash = 8
		else:
			main_view.play_sound("hit_enemy")

	def on_death(self, evt):
		# On death, copy self into the effect layer and mark it as a death flash
		if evt.damage_event:
			s = copy(self)
			s.x = self.unit.x
			s.y = self.unit.y
			s.flash_type = FLASH_DEATH
			s.flash_sub_frame = 0
			s.finished = False

			if self.unit.is_player_controlled or self.unit.is_final_boss:
				main_view.effects = [e for e in main_view.effects if not ((e.x == self.unit.x) and (e.y == self.unit.y))]
			main_view.queue_effect(s, death_effect=True)

		if self.unit.is_player_controlled:
			main_view.play_music('lose_theme')
			main_view.play_sound("death_player")

		else:
			if self.unit.radius: main_view.play_sound("death_boss")
			else: main_view.play_sound("death_enemy")

	def on_item(self, evt):
		main_view.play_sound("item_pickup")

	def draw(self, surface, no_pos=False):
		self.advance()

		if not no_pos:
			x = SPRITE_SIZE * (self.unit.x-self.unit.radius)
			y = SPRITE_SIZE * (self.unit.y-self.unit.radius)
		elif no_pos:

			width = SPRITE_SIZE * (1 + 2 * self.unit.radius)  # Calculate total width based on radius
			x = (surface.get_width() - width) // 2
			y = (surface.get_height() - width) // 2

		if not self.unit.killed:
			frame_dict = self.sheet.anim_frames_flipped if self.unit.face_left else self.sheet.anim_frames

			frame = frame_dict[self.anim]
			if self.anim_frame >= len(frame):
				assert False, "Trying to render frame %d of anim %d on %s, impossible" % (self.anim_frame, self.anim, self.unit.name)
			to_draw = frame[self.anim_frame]
			surface.blit(to_draw, (x, y))

		if self.flash_type == FLASH_HIT and self.flash_sub_frame < HIT_FLASH_SUBFRAMES:
			flash_image = self.sheet.get_hit_flash_frame(self.anim, self.anim_frame, self.unit.face_left)
			surface.blit(flash_image, (x, y))
		elif self.flash_type == FLASH_DEATH and self.flash_sub_frame < DEATH_FLASH_SUBFRAMES:
			flash_image = self.sheet.get_death_flash_frame(self.anim, self.anim_frame, self.unit.face_left)
			surface.blit(flash_image, (x, y))

		if self.flash_type != FLASH_NONE:
			flash_frames = DEATH_FLASH_SUBFRAMES if self.flash_type == FLASH_DEATH else HIT_FLASH_SUBFRAMES
			self.flash_sub_frame += 1
			if self.flash_sub_frame >= flash_frames:
				self.finished = self.flash_type == FLASH_DEATH
				self.flash_type = FLASH_NONE
				self.flash_sub_frame = 0


class SimpleSprite(object):

	def __init__(self, x, y, image, speed=1, loop=False, sync=False):
		if isinstance(image, (list, tuple)):
			self.frames = list(image)
			self.image = None
		else:
			self.image = image
			self.frames = None
		self.speed = speed
		self.x = x
		self.y = y
		self.loop = loop
		self.pixel_x = SPRITE_SIZE * self.x
		self.pixel_y = SPRITE_SIZE * self.y

		self.finished = False
		self.frame = 0
		self.subframe = 0
		self.sync = sync

	def draw(self, surface):
		blit_args = self.prepare_blit()
		if blit_args:
			surface.blit(*blit_args)

	def prepare_blit(self):
		# Return ready-to-blit tuple so callers can batch renders
		self.advance()
		if self.finished: return None

		if self.frames: return (self.frames[self.frame], (self.pixel_x, self.pixel_y))
		else:
			sourcerect = (SPRITE_SIZE * self.frame, 0, SPRITE_SIZE, SPRITE_SIZE)
			return (self.image, (self.pixel_x, self.pixel_y), sourcerect)

	def advance(self):
		if self.sync:
			if idle_subframe == 0:
				self.frame += 1

		else:
			self.subframe += 1

			if self.subframe >= self.speed: # allows for fractional effect obj speeds.
				self.subframe = self.subframe - self.speed
				self.frame += 1

		total_frames = len(self.frames) if self.frames else (self.image.get_width() // SPRITE_SIZE)
		if self.frame >= total_frames:
			if not self.loop: self.finished = True
			else:
				self.frame = 0
				self.subframe = 0


class EffectRect(object):

	def __init__(self, x, y, color, frames):
		self.color = color
		self.total_frames = frames
		self.finished = False
		self.frame = 0

		self.x = x
		self.y = y

	def draw(self, surface):
		x = SPRITE_SIZE * self.x
		y = SPRITE_SIZE * self.y
		rect = (x, y, SPRITE_SIZE, SPRITE_SIZE)
		t = (self.total_frames - self.frame) / float(self.total_frames)
		color = tween_color(self.color, Color(0, 0, 0), t)
		pygame.draw.rect(surface, color.to_tup(), rect)
		self.advance()

	def advance(self):
		self.frame += 1
		if self.frame == self.total_frames:
			self.finished = True


NUMPAD_KEYS = {
	pygame.K_KP0, pygame.K_KP1, pygame.K_KP2, pygame.K_KP3, pygame.K_KP4,
	pygame.K_KP5, pygame.K_KP6, pygame.K_KP7, pygame.K_KP8, pygame.K_KP9
}

def format_key_name(keycode):
	if keycode is None: return "Unbound"
	name = pygame.key.name(keycode).upper()
	if keycode in NUMPAD_KEYS: return f"NUM {name}"
	return name


from itertools import count

_key_bind_ids = count()

# Movement / Actions
KEY_BIND_UP = next(_key_bind_ids)
KEY_BIND_DOWN = next(_key_bind_ids)
KEY_BIND_LEFT = next(_key_bind_ids)
KEY_BIND_RIGHT = next(_key_bind_ids)
KEY_BIND_UP_RIGHT = next(_key_bind_ids)
KEY_BIND_UP_LEFT = next(_key_bind_ids)
KEY_BIND_DOWN_RIGHT = next(_key_bind_ids)
KEY_BIND_DOWN_LEFT = next(_key_bind_ids)
KEY_BIND_AUTOPICKUP = next(_key_bind_ids)
KEY_BIND_RESELECT_SPELL = next(_key_bind_ids)
KEY_BIND_SPELL_1 = next(_key_bind_ids)
KEY_BIND_SPELL_2 = next(_key_bind_ids)
KEY_BIND_SPELL_3 = next(_key_bind_ids)
KEY_BIND_SPELL_4 = next(_key_bind_ids)
KEY_BIND_SPELL_5 = next(_key_bind_ids)
KEY_BIND_SPELL_6 = next(_key_bind_ids)
KEY_BIND_SPELL_7 = next(_key_bind_ids)
KEY_BIND_SPELL_8 = next(_key_bind_ids)
KEY_BIND_SPELL_9 = next(_key_bind_ids)
KEY_BIND_SPELL_10 = next(_key_bind_ids)
KEY_BIND_MODIFIER = next(_key_bind_ids)
KEY_BIND_CONFIRM = next(_key_bind_ids)
KEY_BIND_ABORT = next(_key_bind_ids)
KEY_BIND_PASS = next(_key_bind_ids)
KEY_BIND_FF = next(_key_bind_ids)
KEY_BIND_REROLL = next(_key_bind_ids)
KEY_BIND_SPELL_SPEED_DOWN = next(_key_bind_ids)
KEY_BIND_SPELL_SPEED_UP = next(_key_bind_ids)

# Level Info
KEY_BIND_TAB = next(_key_bind_ids)
KEY_BIND_VIEW = next(_key_bind_ids)
KEY_BIND_WALK = next(_key_bind_ids)
KEY_BIND_INTERACT = next(_key_bind_ids)
KEY_BIND_THREAT = next(_key_bind_ids)
KEY_BIND_THREATENERS = next(_key_bind_ids)
KEY_BIND_LOS = next(_key_bind_ids)
KEY_BIND_HIGHLIGHT_ALLIES = next(_key_bind_ids)
KEY_BIND_HIGHLIGHT_ENEMIES = next(_key_bind_ids)
KEY_BIND_HIGHLIGHT_OBJECTS = next(_key_bind_ids)

# Menus
KEY_BIND_CHAR = next(_key_bind_ids)
KEY_BIND_SPELLS = next(_key_bind_ids)
KEY_BIND_CRAFTING = next(_key_bind_ids)
KEY_BIND_HELP = next(_key_bind_ids)
KEY_BIND_MESSAGE_LOG = next(_key_bind_ids)
KEY_BIND_PREV_EXAMINE_TARGET = next(_key_bind_ids)
KEY_BIND_NEXT_EXAMINE_TARGET = next(_key_bind_ids)

# Shop Actions
KEY_BIND_QUERY = next(_key_bind_ids)
KEY_BIND_CAN_AFFORD = next(_key_bind_ids)
KEY_BIND_ANY = next(_key_bind_ids)
KEY_BIND_FIRE = next(_key_bind_ids)
KEY_BIND_ICE = next(_key_bind_ids)
KEY_BIND_LIGHTNING = next(_key_bind_ids)
KEY_BIND_NATURE = next(_key_bind_ids)
KEY_BIND_ARCANE = next(_key_bind_ids)
KEY_BIND_DARK = next(_key_bind_ids)
KEY_BIND_HOLY = next(_key_bind_ids)
KEY_BIND_METALLIC = next(_key_bind_ids)
KEY_BIND_BLOOD = next(_key_bind_ids)
KEY_BIND_SORCERY = next(_key_bind_ids)
KEY_BIND_ENCHANTMENT = next(_key_bind_ids)
KEY_BIND_CONJURATION = next(_key_bind_ids)
KEY_BIND_EYE = next(_key_bind_ids)
KEY_BIND_DRAGON = next(_key_bind_ids)
KEY_BIND_ORB = next(_key_bind_ids)
KEY_BIND_CHAOS = next(_key_bind_ids)
KEY_BIND_SLIME = next(_key_bind_ids)
KEY_BIND_WORD = next(_key_bind_ids)
KEY_BIND_TRANSLOCATION = next(_key_bind_ids)
KEY_BIND_RITUAL = next(_key_bind_ids)
KEY_BIND_FILTER_ATTR_MAX_CHARGES = next(_key_bind_ids)
KEY_BIND_FILTER_ATTR_RANGE = next(_key_bind_ids)
KEY_BIND_FILTER_ATTR_RADIUS = next(_key_bind_ids)
KEY_BIND_FILTER_ATTR_DAMAGE = next(_key_bind_ids)
KEY_BIND_FILTER_ATTR_DURATION = next(_key_bind_ids)
KEY_BIND_FILTER_ATTR_NUM_TARGETS = next(_key_bind_ids)
KEY_BIND_FILTER_ATTR_MAX_CHANNEL = next(_key_bind_ids)
KEY_BIND_FILTER_ATTR_HP_COST = next(_key_bind_ids)
KEY_BIND_FILTER_ATTR_MINION_DURATION = next(_key_bind_ids)
KEY_BIND_FILTER_ATTR_MINION_DAMAGE = next(_key_bind_ids)
KEY_BIND_FILTER_ATTR_MINION_HEALTH = next(_key_bind_ids)
KEY_BIND_FILTER_ATTR_MINION_RANGE = next(_key_bind_ids)
KEY_BIND_FILTER_ATTR_NUM_SUMMONS = next(_key_bind_ids)

KEY_BIND_MAX = KEY_BIND_FILTER_ATTR_NUM_SUMMONS
KEY_BIND_OPTION_ACCEPT = next(_key_bind_ids)
KEY_BIND_OPTION_ABORT = next(_key_bind_ids)
KEY_BIND_OPTION_RESET = next(_key_bind_ids)

del _key_bind_ids
	#keybind,  keybind  name, defaults, associated tag
KEY_BIND_DEFS = [
	# Movement / Actions
	(KEY_BIND_UP, "up", [pygame.K_UP, pygame.K_KP8], None),
	(KEY_BIND_DOWN, "down", [pygame.K_DOWN, pygame.K_KP2], None),
	(KEY_BIND_LEFT, "left", [pygame.K_LEFT, pygame.K_KP4], None),
	(KEY_BIND_RIGHT, "right", [pygame.K_RIGHT, pygame.K_KP6], None),
	(KEY_BIND_UP_RIGHT, "up-right", [pygame.K_KP9, None], None),
	(KEY_BIND_UP_LEFT, "up-left", [pygame.K_KP7, None], None),
	(KEY_BIND_DOWN_RIGHT, "down-right", [pygame.K_KP3, None], None),
	(KEY_BIND_DOWN_LEFT, "down-left", [pygame.K_KP1, None], None),
	(KEY_BIND_AUTOPICKUP, "Autopickup", [pygame.K_a, None], None),
	(KEY_BIND_RESELECT_SPELL, "Reselect Last Spell", [pygame.K_q, None], None),
	(KEY_BIND_SPELL_1, "Spell 1", [pygame.K_1, None], None),
	(KEY_BIND_SPELL_2, "Spell 2", [pygame.K_2, None], None),
	(KEY_BIND_SPELL_3, "Spell 3", [pygame.K_3, None], None),
	(KEY_BIND_SPELL_4, "Spell 4", [pygame.K_4, None], None),
	(KEY_BIND_SPELL_5, "Spell 5", [pygame.K_5, None], None),
	(KEY_BIND_SPELL_6, "Spell 6", [pygame.K_6, None], None),
	(KEY_BIND_SPELL_7, "Spell 7", [pygame.K_7, None], None),
	(KEY_BIND_SPELL_8, "Spell 8", [pygame.K_8, None], None),
	(KEY_BIND_SPELL_9, "Spell 9", [pygame.K_9, None], None),
	(KEY_BIND_SPELL_10, "Spell 10", [pygame.K_0, None], None),
	(KEY_BIND_MODIFIER, "Modifier Key", [pygame.K_LSHIFT, pygame.K_RSHIFT], None),
	(KEY_BIND_CONFIRM, "confirm/cast", [pygame.K_RETURN, pygame.K_KP_ENTER], None),
	(KEY_BIND_ABORT, "abort/cast", [pygame.K_ESCAPE, None], None),
	(KEY_BIND_PASS, "pass/channel", [pygame.K_SPACE, pygame.K_KP5], None),
	(KEY_BIND_FF, "Fast Forward", [pygame.K_BACKSPACE, None], None),
	(KEY_BIND_REROLL, "Reroll Rifts", [pygame.K_r, None], None),
	(KEY_BIND_SPELL_SPEED_DOWN, "Decrease Anim Speed", [pygame.K_LEFTBRACKET, None], None),
	(KEY_BIND_SPELL_SPEED_UP, "Increase Anim Speed", [pygame.K_RIGHTBRACKET, None], None),

	# Level Info
	(KEY_BIND_TAB, "Next Target", [pygame.K_TAB, None], None),
	(KEY_BIND_VIEW, "Look", [pygame.K_v, None], None),
	(KEY_BIND_WALK, "Walk", [pygame.K_w, None], None),
	(KEY_BIND_INTERACT, "Interact", [pygame.K_PERIOD, None], None),
	(KEY_BIND_THREAT, "Show Threat Zone", [pygame.K_t, None], None),
	(KEY_BIND_THREATENERS, "Show Threatening Enemies", [pygame.K_y, None], None),
	(KEY_BIND_LOS, "Show Line of Sight", [pygame.K_l, None], None),
	(KEY_BIND_HIGHLIGHT_ALLIES, "Highlight Allies", [pygame.K_u, None], None),
	(KEY_BIND_HIGHLIGHT_ENEMIES, "Highlight Enemies", [pygame.K_i, None], None),
	(KEY_BIND_HIGHLIGHT_OBJECTS, "Highlight Objects", [pygame.K_o, None], None),

	# Menus
	(KEY_BIND_CHAR, "Character Sheet", [pygame.K_c, None], None),
	(KEY_BIND_SPELLS, "Spells", [pygame.K_s, None], None),
	(KEY_BIND_CRAFTING, "Crafting", [pygame.K_e, None], None),
	(KEY_BIND_HELP, "Help", [pygame.K_h, pygame.K_SLASH], None),
	(KEY_BIND_MESSAGE_LOG, "Message Log", [pygame.K_m, None], None),
	(KEY_BIND_PREV_EXAMINE_TARGET, "Next tooltip", [pygame.K_PAGEUP, None], None),
	(KEY_BIND_NEXT_EXAMINE_TARGET, "Prev tooltip", [pygame.K_PAGEDOWN, None], None),

	# Shop Actions:
	(KEY_BIND_QUERY, "Input Text", [pygame.K_q, None], None),
	(KEY_BIND_CAN_AFFORD, "Can Afford", [pygame.K_BACKQUOTE, None], None),
	(KEY_BIND_ANY, "Any", [pygame.K_ASTERISK, None], Tags.Any),
	(KEY_BIND_ARCANE, "Arcane", [pygame.K_a, None], Tags.Arcane),
	(KEY_BIND_BLOOD, "Blood", [pygame.K_b, None], Tags.Blood),
	(KEY_BIND_CHAOS, "Chaos", [pygame.K_k, None], Tags.Chaos),
	(KEY_BIND_CONJURATION, "Conjuration", [pygame.K_c, None], Tags.Conjuration),
	(KEY_BIND_DARK, "Dark", [pygame.K_d, None], Tags.Dark),
	(KEY_BIND_DRAGON, "Dragon", [pygame.K_r, None], Tags.Dragon),
	(KEY_BIND_ENCHANTMENT, "Enchantment", [pygame.K_e, None], Tags.Enchantment),
	(KEY_BIND_EYE, "Eye", [pygame.K_y, None], Tags.Eye),
	(KEY_BIND_FIRE, "Fire", [pygame.K_f, None], Tags.Fire),
	(KEY_BIND_HOLY, "Holy", [pygame.K_h, None], Tags.Holy),
	(KEY_BIND_ICE, "Ice", [pygame.K_i, None], Tags.Ice),
	(KEY_BIND_LIGHTNING, "Lightning", [pygame.K_l, None], Tags.Lightning),
	(KEY_BIND_METALLIC, "Metallic", [pygame.K_m, None], Tags.Metallic),
	(KEY_BIND_NATURE, "Nature", [pygame.K_n, None], Tags.Nature),
	(KEY_BIND_ORB, "Orb", [pygame.K_o, None], Tags.Orb),
	(KEY_BIND_RITUAL, "Ritual", [pygame.K_u, None], Tags.Ritual),
	(KEY_BIND_SLIME, "Slime", [pygame.K_z, None], Tags.Slime),
	(KEY_BIND_SORCERY, "Sorcery", [pygame.K_s, None], Tags.Sorcery),
	(KEY_BIND_TRANSLOCATION, "Translocation", [pygame.K_t, None], Tags.Translocation),
	(KEY_BIND_WORD, "Word", [pygame.K_w, None], Tags.Word),
	(KEY_BIND_FILTER_ATTR_DAMAGE, "Damage", [pygame.K_d, None], None),
	(KEY_BIND_FILTER_ATTR_DURATION, "Duration", [pygame.K_u, None], None),
	(KEY_BIND_FILTER_ATTR_HP_COST, "HP Cost", [pygame.K_h, None], None),
	(KEY_BIND_FILTER_ATTR_MAX_CHANNEL, "Max Channel", [pygame.K_x, None], None),
	(KEY_BIND_FILTER_ATTR_MAX_CHARGES, "Max Charges", [pygame.K_m, None], None),
	(KEY_BIND_FILTER_ATTR_NUM_TARGETS, "Num Targets", [pygame.K_t, None], None),
	(KEY_BIND_FILTER_ATTR_RADIUS, "Radius", [pygame.K_a, None], None),
	(KEY_BIND_FILTER_ATTR_RANGE, "Range", [pygame.K_r, None], None),
	(KEY_BIND_FILTER_ATTR_MINION_DAMAGE, "Minion Damage", [pygame.K_g, None], None),
	(KEY_BIND_FILTER_ATTR_MINION_DURATION, "Minion Duration", [pygame.K_i, None], None),
	(KEY_BIND_FILTER_ATTR_MINION_HEALTH, "Minion Health", [pygame.K_e, None], None),
	(KEY_BIND_FILTER_ATTR_MINION_RANGE, "Minion Range", [pygame.K_o, None], None),
	(KEY_BIND_FILTER_ATTR_NUM_SUMMONS, "Num Summons", [pygame.K_n, None], None),
]

default_key_binds = {bind_id: defaults for bind_id, _, defaults, _ in KEY_BIND_DEFS}
key_bind_display_order = [bind_id for bind_id, _, _, _ in KEY_BIND_DEFS]
key_names = {bind_id: label for bind_id, label, _, _ in KEY_BIND_DEFS}
key_bind_save_names = {
	bind_id: name[len("KEY_BIND_"):].lower()
	for name, bind_id in globals().items()
	if name.startswith("KEY_BIND_") and name != "KEY_BIND_MAX" and isinstance(bind_id, int) and bind_id <= KEY_BIND_MAX
}
key_bind_ids_by_save_name = {name: bind_id for bind_id, name in key_bind_save_names.items()}
binds_to_filters = {bind_id: tag for bind_id, _, _, tag in KEY_BIND_DEFS if tag}
filters_to_binds = {tag: bind_id for bind_id, tag in binds_to_filters.items()}
shop_attr_filter_binds = dict(zip(shop_filter_attrs, (
	KEY_BIND_FILTER_ATTR_DAMAGE,
	KEY_BIND_FILTER_ATTR_DURATION,
	KEY_BIND_FILTER_ATTR_HP_COST,
	KEY_BIND_FILTER_ATTR_MAX_CHANNEL,
	KEY_BIND_FILTER_ATTR_MAX_CHARGES,
	KEY_BIND_FILTER_ATTR_NUM_TARGETS,
	KEY_BIND_FILTER_ATTR_RADIUS,
	KEY_BIND_FILTER_ATTR_RANGE,
	KEY_BIND_FILTER_ATTR_MINION_DAMAGE,
	KEY_BIND_FILTER_ATTR_MINION_DURATION,
	KEY_BIND_FILTER_ATTR_MINION_HEALTH,
	KEY_BIND_FILTER_ATTR_MINION_RANGE,
	KEY_BIND_FILTER_ATTR_NUM_SUMMONS,
)))
binds_to_shop_attrs = {bind_id: attr for attr, bind_id in shop_attr_filter_binds.items()}
shop_global_filter_binds = {
	SHOP_FILTER_CAN_AFFORD: KEY_BIND_CAN_AFFORD,
}
shop_tag_bind_ids = set(binds_to_filters.keys())
shop_attr_bind_ids = set(shop_attr_filter_binds.values())
shop_exclusive_action_bind_ids = {KEY_BIND_QUERY, KEY_BIND_CAN_AFFORD}
shop_value_blocking_bind_ids = shop_exclusive_action_bind_ids | {KEY_BIND_MODIFIER, KEY_BIND_DOWN, KEY_BIND_UP, KEY_BIND_LEFT, KEY_BIND_RIGHT, KEY_BIND_TAB, KEY_BIND_CONFIRM, KEY_BIND_ABORT}
shop_rebind_ids = shop_tag_bind_ids | shop_attr_bind_ids | shop_exclusive_action_bind_ids

def build_filter_key_cache(key_bindings, bind_targets):
	target_map = {}
	for bind_id, target in bind_targets.items():
		for keycode in key_bindings.get(bind_id, ()):
			if keycode is None: continue
			target_map.setdefault(keycode, []).append(target)
	return target_map

def build_tag_filter_key_cache(key_bindings):
	target_map = build_filter_key_cache(key_bindings, binds_to_filters)
	for tag in spell_tags:
		letter = ModHandler.tag_filter_letters.get(tag.name)
		if letter: target_map.setdefault(ord(letter), []).append(tag)
	return target_map

class PyGameView(object):

	def __init__(self):
		self.game = None
		self.options = load_saved_options()

		self.rebinding = False
		self.key_binds = self.merge_saved_key_binds(self.options.get('key_binds', {}))
		self.options['key_binds'] = self.serialize_key_binds(self.key_binds)
		self.filter_tag_keys = build_tag_filter_key_cache(self.key_binds)
		self.filter_attr_keys = build_filter_key_cache(self.key_binds, binds_to_shop_attrs)

		pygame.mixer.pre_init(buffer=1024)
		pygame.init()
		pygame.display.init()

		pygame.display.set_caption("Rift Wizard 3")

		self.window_mode = self.options.get('window_mode', WINDOW_MODE_FULLSCREEN)
		if self.window_mode not in WINDOW_MODE_CHOICES:
			self.window_mode = WINDOW_MODE_FULLSCREEN
			self.options['window_mode'] = self.window_mode

		if 'windowed' in sys.argv:
			self.window_mode = WINDOW_MODE_WINDOWED
			self.options['window_mode'] = self.window_mode

		self.window_minimized = False
		self.init_display()
		load_flash_textures()

		self.clock = pygame.time.Clock()

		#pygame.mixer.init()
		self.can_play_sound = False
		self.current_music = None
		self.music_queued_name = None
		if not 'nosound' in sys.argv:
			try:
				pygame.mixer.set_num_channels(8)
				self.hit_sound_channel = pygame.mixer.Channel(0)
				self.hit_player_sound_channel = pygame.mixer.Channel(1)
				self.death_sound_channel = pygame.mixer.Channel(2)
				self.cast_sound_channel = pygame.mixer.Channel(3)
				self.step_sound_channel = pygame.mixer.Channel(4)
				self.misc_sound_channel = pygame.mixer.Channel(5)
				self.ui_sound_channel = pygame.mixer.Channel(6)
				self.victory_sound_channel = pygame.mixer.Channel(7)

				pygame.mixer.set_reserved(8)

				self.base_volumes = {
					self.hit_sound_channel : .5,
					self.hit_player_sound_channel: .6,
					self.death_sound_channel: .75,
					self.cast_sound_channel: .65,
					self.step_sound_channel: .15,
					self.misc_sound_channel: .75,
					self.ui_sound_channel: .25,
					self.victory_sound_channel: .8
				}

				sound = True #'sound' in sys.argv

				if not sound:
					pygame.mixer.music.stop()
					channels = [self.hit_sound_channel, self.hit_player_sound_channel, self.death_sound_channel, self.cast_sound_channel, self.step_sound_channel, self.victory_sound_channel]
					for channel in channels: channel.set_volume(0)

				self.can_play_sound = True

				self.adjust_volume(0, "sound")

			except: pass

		# Get language from options (default to English)
		first_run = ("lang" not in self.options) # before setting to default, to be acted on later, sending first time users directly to lang menu
		lang = self.options.get("lang", "en")
		loc.set_locale(lang)
		self.how_to_play_font_cache = {}
		pygame.font.init()
		self.reapply_font(persist=False) # don't save default, since we'll check if it exists in options to determine if we should direct them to select a langauge

		self.frameno = 0

		self.load_chasm_sprites()
		self.load_wall_sprites()
		self.load_floor_sprites()

		self.effects = []

		self.load_effect_images()
		self.projectile_effect_frames = {}

		self.sprite_sheets = {}
		self.cur_spell = None
		self.cur_spell_target = None
		self.targetable_tiles = None

		self._examine_target = None
		self._examine_index = 0
		self._examine_extras = []

		self.deploy_target = None

		self.state = None
		self.return_to_title()

		if first_run: self.open_language_menu(STATE_TITLE)

		self.char_sheet_column = CHAR_SHEET_SELECT_TYPE_SPELLS  # 0 = spells, 1 = equipment
		self.char_sheet_row_index = 0


		self.shop_type = SHOP_TYPE_SPELLS
		self.shop_upgrade_spell = None # The spell to be upgraded
		self.shop_craft_equipment = None # the equipment to be crafted
		self.cur_equipment_flash = {} # dict of tuples of keyed by Equipment (Color, Remaining Flash Time) when a equipment should flash effect
		self.cur_spell_flash = {} # dict of tuples of keyed by Spell (Color, Remaining Flash Time) when a spell should flash effect
		self.cur_hp_flash = None # Remaining Flash Time when player takes damage, for HP display flash effect
		self.spell_speed_flash_frames = 0
		self.shop_craft_component_ingredients = [] # the components that have been selected to be used in crafting
		self.shop_craft_remaining_tags = [] # the tags yet to be supplied by components for the crafting of the equipment
		self.shop_selection_index = 0
		self.shop_page = 0
		self.max_shop_objects = (RENDER_HEIGHT - 4 * self.linesize - 2 * self.border_margin) // self.linesize
		self.shop_rows_per_page = self.max_shop_objects
		self.shop_options_cache = None
		self.shop_filter_option_cache = {}
		self.shop_craft_blueprint_cache = {}

		self.shop_filter_category = SHOP_FILTER_TAGS
		self.shop_tag_filter = set()
		self.shop_attr_filter = set()
		self.shop_bonus_filter = set()
		self.shop_gain_tag_filter = set()
		self.shop_gain_attr_filter = set()
		self.shop_recipe_tag_filter = set()

		self.filter_unused = False
		self.filter_unvictoried = False
		self.filter_can_afford = False

		self.path = []

		self.effect_queue = []
		self.effect_queue_tile_counts = {}
		self.sound_effects = {}

		self.ui_all= None
		self.load_ui_panels()

		self.unit_examine_icon_surface = pygame.Surface((SPRITE_SIZE, SPRITE_SIZE), pygame.SRCALPHA)

		self.examine_icon_size = 64
		self.examine_icon_x = self.examine_display.get_width() - self.border_margin - self.examine_icon_size
		self.examine_icon_y = self.border_margin


		self.char_panel_examine_lines = {}

		self.second_step = False

		self.path_delay = 0

		self.option_selection = OPTION_SOUND_VOLUME
		self.options_menu_x = None

		self.message = None
		self.how_to_play_return_state = STATE_TITLE
		self.how_to_play_return_examine_target = None
		self.how_to_play_return_examine_index = 0
		self.how_to_play_page = None


		self.gameover_frames = 0
		self.gameover_tiles = None
		self.gameover_level_display = None
		self.level_stats_cache = None
		self.level_stats_cache_key = None
		self.post_victory_defer_frames = 0

		self.deploy_anim_frames = 0

		self.title_frames = slice_image_strip(get_image(['title_animated']), 1920, 1080)

		self.victory_image = get_image(['victory_text'])
		self.victory_frames = slice_image_strip(get_image(['victory_animated']), 240, 500)
		self.defeat_image = get_image(['defeat_text'])
		self.defeat_frames = slice_image_strip(get_image(['defeat_animated']), 240, 460)
		self.gameover_anim_frame = 0
		self.draw_combat_log_button = False

		self.victory_wait_frames = 0
		self.victory_delay_frames = 3

		self.shop_scroll_frame = 0

		self.ui_rects = []
		self.mouse_pos = (0, 0)

		self.char_panel_menu_actions = {
			CHAR_SHEET_TARGET: self.open_char_sheet,
			LEARN_SPELL_TARGET: lambda: self.open_shop(SHOP_TYPE_SPELLS),
			CRAFTING_TARGET: lambda: self.open_shop(SHOP_TYPE_CRAFTING),
			INSTRUCTIONS_TARGET: self.show_help,
			OPTIONS_TARGET: self.open_options,
			REROLL_PORTALS_TARGET: lambda: self.game.try_reroll_rifts(),
			COMBAT_LOG_TARGET: lambda: self.open_combat_log(from_death=True),
		}

		self.title_can_continue = can_continue_game()
		self.mods_menu_status = ""
		self.mods_menu_upload_selecting = False
		self.mods_menu_upload_options = []
		self.mods_menu_catalog = []
		self.mods_menu_catalog_by_name = {}
		self.mods_menu_disabled_names = []
		self.mods_menu_enabled_on_boot = None
		self.mods_menu_enabled_on_open = []
		self.mods_menu_disabled_on_open = []
		self.mods_menu_group = 'disabled'
		self.mods_menu_action_target = MOD_MENU_BROWSE
		self.mods_menu_disabled_page = 0
		self.mods_menu_enabled_page = 0

		self.threat_zone = None
		self.last_threat_highlight = None
		self.threatening_enemies_cache_key = None
		self.threatening_enemy_points = []

		icon = get_image(['UI', 'icon'])
		pygame.display.set_icon(icon)

		self.repeat_keys = {}

		# Targeting overlay assets
		fill_a = 110
		impacted_a = int(fill_a * 2)
		targeted_a = int(fill_a * 1.5)

		self.tile_targetable_image = get_image(['UI', 'square_valid']).copy()
		self.tile_targetable_image.set_alpha(fill_a)

		self.tile_impacted_image = get_image(['UI', 'square_impacted']).copy()
		self.tile_impacted_image.set_alpha(impacted_a)

		# Animated targeting
		targeted_strip = get_image(['UI', 'square_targeted']).copy()
		self.tile_targeted_frames = slice_image_strip(targeted_strip, SPRITE_SIZE, SPRITE_SIZE)
		for f in self.tile_targeted_frames: f.set_alpha(targeted_a)

		self.tile_invalid_target_image = get_image(['UI', 'square_invalid_target']).copy()
		self.tile_invalid_target_image.set_alpha(fill_a)

		self.tile_invalid_target_in_range_image = get_image(['UI', 'square_invalid_target']).copy()
		self.tile_invalid_target_in_range_image.set_alpha(fill_a)

		self.hostile_los_image = get_image(['UI', 'square_invalid_target']).copy()
		self.hostile_los_image.set_alpha(fill_a)

		self.tile_visible_image = get_image(['UI', 'square_valid']).copy()
		self.tile_visible_image.set_alpha(fill_a)

		self.component_overlay_cache = {}
		self.crafting_tag_images = {}
		self.craft_animation_frames = []
		craft_anim_image = get_image(['UI', 'crafting ui', 'craft_animation'])
		if craft_anim_image:
			frame_h = craft_anim_image.get_height() or SPRITE_SIZE
			frame_w = frame_h
			if frame_w:
				num_frames = max(1, craft_anim_image.get_width() // frame_w)
				self.craft_animation_frames = slice_image_strip(craft_anim_image, frame_w, frame_h)
		self.craft_animation_playing = False
		self.craft_animation_timer = 0
		self.craft_animation_pending_equipment = None
		self.craft_animation_frame_hold = CRAFT_ANIM_FRAME_HOLD

		# Load targeting tile masking
		self.prebake_targeting()
		self.preload_boot_assets()

		self.reminisce_folder = None
		self.reminisce_index = 0

		self.abort_to_spell_shop = False
		self.abort_to_crafting_shop = False


		self.examine_icon_subframe = 0
		self.examine_icon_frame = 0

		self.cast_fail_frames = 0

		self.combat_log_offset = 0
		self.combat_log_turn = 0
		self.combat_log_level = 0
		self.combat_log_cache = {}
		self.combat_log_lines = []
		self.combat_log_match_lines = []
		self.combat_log_query = ""
		self.combat_log_query_prev = ""
		self.combat_log_query_focused = False
		self.combat_log_max_turn_value = 1

		# Mutator parameter selection state (for custom run UI)
		self.pending_mutator_class = None  # class being configured
		self.pending_param = None # selected param to be configured with a value
		self.pending_value_buffer = ''  # raw string input for number entry
		self.custom_mutators = []  # finalized list of configured mutator instances
		self.custom_mutator_args = [] # store the list of configured mutator args for display
		self.custom_mutator_page = 0
		self.mutator_param_entries = []
		self.mutator_param_page = 0
		self.mutator_param_query = ""
		self.mutator_param_search_focused = False

		self.confirm_text = None
		self.confirm_yes = None
		self.confirm_no = None

		self.next_messages = []
		self.fast_forward = False

		self.search_cache = {}
		self.bestiary_search_cache = {}
		self.unit_preview_key = None
		self.unit_preview_frames = []
		self.search_query = ""
		self.search_focused = False
		self.build_search_cache()

		self.max_keybinds_per_page = self.max_shop_objects - 1

		self.bg_test = get_image(['tiles', 'bg_test'])

		self.sound_cooldowns = {}

		self.track_queue = None
		self.last_battle_track = None
		if self.can_play_sound: pygame.mixer.music.set_endevent(MUSIC_OVER_EVENT)

	def music_is_busy(self):
		if not self.can_play_sound: return False
		return pygame.mixer.music.get_busy()

	def get_min_window_size(self):
		return (int(RENDER_WIDTH * MIN_WINDOW_SCALE), int(RENDER_HEIGHT * MIN_WINDOW_SCALE))

	def get_default_window_size(self):
		_, _, desktop_w, desktop_h = self.display_usable_bounds
		scale = min(desktop_w / RENDER_WIDTH, desktop_h / RENDER_HEIGHT) * DEFAULT_WINDOW_SCALE
		scale = max(MIN_WINDOW_SCALE, min(scale, MAX_WINDOW_SCALE))
		return (int(RENDER_WIDTH * scale), int(RENDER_HEIGHT * scale))

	def get_windowed_size(self):
		saved_size = self.options['windowed_size']
		if saved_size: return self.normalized_window_size(saved_size)
		return self.get_default_window_size()

	def init_scaled_window(self):
		import ctypes

		sdl_path = os.path.abspath(os.path.join(os.path.dirname(pygame.__file__), "SDL2.dll"))
		self.sdl = ctypes.CDLL(sdl_path)
		self.sdl.SDL_GetWindowFromID.argtypes = [ctypes.c_uint32]
		self.sdl.SDL_GetWindowFromID.restype = ctypes.c_void_p
		self.sdl.SDL_GetRenderer.argtypes = [ctypes.c_void_p]
		self.sdl.SDL_GetRenderer.restype = ctypes.c_void_p
		self.sdl.SDL_GetWindowFlags.argtypes = [ctypes.c_void_p]
		self.sdl.SDL_GetWindowFlags.restype = ctypes.c_uint32
		self.sdl.SDL_GetDisplayBounds.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_int)]
		self.sdl.SDL_GetDisplayBounds.restype = ctypes.c_int
		self.sdl.SDL_GetDisplayUsableBounds.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_int)]
		self.sdl.SDL_GetDisplayUsableBounds.restype = ctypes.c_int
		self.sdl.SDL_SetWindowMinimumSize.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int]
		self.sdl.SDL_SetWindowMinimumSize.restype = None
		self.sdl.SDL_RenderSetIntegerScale.argtypes = [ctypes.c_void_p, ctypes.c_int]
		self.sdl.SDL_RenderSetIntegerScale.restype = ctypes.c_int
		self.sdl.SDL_RenderSetLogicalSize.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int]
		self.sdl.SDL_RenderSetLogicalSize.restype = ctypes.c_int

		self.sdl_window = self.sdl.SDL_GetWindowFromID(self.display_window.id)
		if not self.sdl_window: raise pygame.error("failed to get scaled window")
		self.sdl_bounds_rect = (ctypes.c_int * 4)()
		min_w, min_h = self.get_min_window_size()
		self.sdl.SDL_SetWindowMinimumSize(self.sdl_window, min_w, min_h)
		self.refresh_scaled_renderer()

	def refresh_scaled_renderer(self):
		if self.window_minimized: return
		sdl_renderer = self.sdl.SDL_GetRenderer(self.sdl_window)
		if not sdl_renderer: raise pygame.error("failed to get scaled renderer")
		if self.sdl.SDL_RenderSetIntegerScale(sdl_renderer, False) != 0: raise pygame.error("failed to set fractional renderer scale")
		if self.sdl.SDL_RenderSetLogicalSize(sdl_renderer, RENDER_WIDTH, RENDER_HEIGHT) != 0: raise pygame.error("failed to set logical renderer size")

	def get_display_bounds(self, display_index, usable):
		get_bounds = self.sdl.SDL_GetDisplayUsableBounds if usable else self.sdl.SDL_GetDisplayBounds
		result = get_bounds(display_index, self.sdl_bounds_rect)
		if result != 0: raise pygame.error("failed to get bounds for display %d" % display_index)
		return tuple(self.sdl_bounds_rect)

	def update_display(self, display_index):
		self.display_bounds = self.get_display_bounds(display_index, usable=False)
		self.display_usable_bounds = self.get_display_bounds(display_index, usable=True)

	def is_window_maximized(self):
		return bool(self.sdl.SDL_GetWindowFlags(self.sdl_window) & SDL_WINDOW_MAXIMIZED)

	def init_display(self):
		display_res = (RENDER_WIDTH, RENDER_HEIGHT)
		flags = pygame.RESIZABLE | pygame.SCALED

		self.screen = pygame.display.set_mode(display_res, flags)
		self.display_window = Window.from_display_module()
		self.init_scaled_window()
		self.apply_window_mode()

		level_length_px = LEVEL_SIZE * SPRITE_SIZE
		self.h_margin = max((RENDER_WIDTH - level_length_px) // 2, 0)
		self.v_margin = max((RENDER_HEIGHT - level_length_px) // 2, 0)
		self.border_margin = 12

		level_rect = pygame.Rect(self.h_margin, self.v_margin, SPRITE_SIZE * LEVEL_SIZE, SPRITE_SIZE * LEVEL_SIZE)
		self.level_display = self.screen.subsurface(level_rect)
		self.terrain_surface = pygame.Surface(self.level_display.get_size()).convert()
		self.terrain_level = None
		self.terrain_generation = -1

		side_width = max(self.h_margin, 1)
		character_rect = pygame.Rect(0, 0, side_width, RENDER_HEIGHT)
		examine_rect = pygame.Rect(RENDER_WIDTH - side_width, 0, side_width, RENDER_HEIGHT)
		self.character_display = self.screen.subsurface(character_rect)
		self.examine_display = self.screen.subsurface(examine_rect)

		center_width = max(RENDER_WIDTH - 2 * self.h_margin, SPRITE_SIZE)
		self.middle_menu_display = pygame.Surface((center_width, RENDER_HEIGHT), pygame.SRCALPHA)
		self.middle_menu_width = self.middle_menu_display.get_width()
		self.middle_menu_height = self.middle_menu_display.get_height()

	def apply_window_mode(self):
		self.update_display(self.display_window.display_index)

		if self.window_mode == WINDOW_MODE_FULLSCREEN:
			self.display_window.set_fullscreen(desktop=True)
			return

		self.display_window.set_windowed()
		self.display_window.restore()
		self.display_window.borderless = self.window_mode == WINDOW_MODE_BORDERLESS
		self.display_window.resizable = self.window_mode == WINDOW_MODE_WINDOWED

		if self.window_mode == WINDOW_MODE_BORDERLESS:
			display_x, display_y, display_w, display_h = self.display_bounds
			self.display_window.position = (display_x, display_y)
			self.display_window.size = (display_w, display_h)
		else:
			usable_x, usable_y, usable_w, usable_h = self.display_usable_bounds
			window_w, window_h = self.get_windowed_size()
			self.display_window.size = (window_w, window_h)
			window_x = usable_x + max((usable_w - window_w) // 2, 0)
			window_y = usable_y + max((usable_h - window_h) // 2, 0)
			self.display_window.position = (window_x, window_y)

	def resize_window(self, evt):
		if self.window_mode != WINDOW_MODE_WINDOWED: return
		if self.is_window_maximized(): return
		self.options['windowed_size'] = self.normalized_window_size(evt.size)

	def normalized_window_size(self, requested_size):
		_, _, desktop_w, desktop_h = self.display_usable_bounds
		min_w, min_h = self.get_min_window_size()

		max_w = max(min(desktop_w - WINDOW_MARGIN_PX[0], int(RENDER_WIDTH * MAX_WINDOW_SCALE)), min_w)
		max_h = max(min(desktop_h - WINDOW_MARGIN_PX[1], int(RENDER_HEIGHT * MAX_WINDOW_SCALE)), min_h)

		width = max(min(requested_size[0], max_w), min_w)
		height = max(min(requested_size[1], max_h), min_h)

		return (width, height)

	def get_layout(self):
		# Works even if window resizes—uses actual screen size
		W, H = self.screen.get_size()
		left = pygame.Rect(0, 0, self.h_margin, H)
		center_w = W - 2 * self.h_margin
		center = pygame.Rect(self.h_margin, 0, center_w, H)
		right = pygame.Rect(self.h_margin + center_w, 0, self.h_margin, H)
		return left, center, right

	def open_language_menu(self, return_state):
		self.language_return_state = return_state
		self.langs_cache = [code for code in (loc.available_locales() or ["en"]) if code in loc.LANG_DISPLAY_NAME] or ['en']
		cur = loc.get_locale()
		self.examine_target = cur if cur in self.langs_cache else self.langs_cache[0]
		self.state = STATE_SELECT_LANGUAGE

	def draw_language_menu(self):
		self.ui_rects.clear()
		langs = self.langs_cache or loc.available_locales() or ["en"]

		# build rows: (code, text, width)
		rows = []
		for code in langs:
			label = loc.LANG_DISPLAY_NAME.get(code, code)
			width = self.font.size(label)[0]
			rows.append((code, label, width))

		title = "LANGUAGE"
		title_w = self.font.size(title)[0]
		rect_w = max([title_w] + [w for _, _, w in rows])
		cur_x = self.screen.get_width() // 2 - rect_w // 2
		cur_y = self.screen.get_height() // 2 - self.linesize * (len(rows) // 2) - self.linesize * 2

		# title
		self.draw_string(title, self.screen, cur_x + (rect_w - title_w) // 2, cur_y, (255, 255, 255))
		cur_y += self.linesize * 2

		# language rows
		for code, text, row_w in rows:
			self.draw_string(text, self.screen, cur_x, cur_y, (255, 255, 255), mouse_content=code, content_width=row_w)
			cur_y += self.linesize

	def process_language_menu_input(self):
		# keyboard
		for evt in [e for e in self.events if e.type == pygame.KEYDOWN]:
			if evt.key in self.key_binds[KEY_BIND_UP]:
				if self.langs_cache:
					i = self.langs_cache.index(self.examine_target) if self.examine_target in self.langs_cache else 0
					i = (i - 1) % len(self.langs_cache)
					self.examine_target = self.langs_cache[i]
				self.play_sound("menu_confirm")

			if evt.key in self.key_binds[KEY_BIND_DOWN]:
				if self.langs_cache:
					i = self.langs_cache.index(self.examine_target) if self.examine_target in self.langs_cache else -1
					i = (i + 1) % len(self.langs_cache)
					self.examine_target = self.langs_cache[i]
				self.play_sound("menu_confirm")

			if evt.key in self.key_binds[KEY_BIND_CONFIRM]:
				if self.langs_cache:
					code = self.examine_target if self.examine_target in self.langs_cache else self.langs_cache[0]
					self.update_language(code)  # set_locale + reapply_font(persist=True)
					self.load_ui_panels()  # refresh any cached labels
				self.state = self.language_return_state
				return

			if evt.key in self.key_binds[KEY_BIND_ABORT]:
				self.state = self.language_return_state
				self.play_sound("menu_confirm")
				return

		# mouse
		m = self.get_mouse_pos()
		for evt in [e for e in self.events if e.type == pygame.MOUSEBUTTONDOWN]:
			if evt.button == pygame.BUTTON_LEFT:
				for r, o in self.ui_rects:
					if r.collidepoint(m):
						if o in self.langs_cache:
							self.play_sound("menu_confirm")
							self.update_language(o)
							self.load_ui_panels()
							self.state = self.language_return_state
							return

			if evt.button == pygame.BUTTON_RIGHT:
				self.play_sound("menu_confirm")
				self.state = self.language_return_state
				return

		# hover moves highlight (like other menus)
		dx, dy = self.get_mouse_rel()
		if dx or dy:
			for r, o in self.ui_rects:
				if r.collidepoint(m):
					if o in self.langs_cache and self.examine_target != o:
						self.play_sound("menu_confirm")
						self.examine_target = o
					break

	def update_language(self, lang_code):
		loc.set_locale(lang_code)
		self.options["lang"] = lang_code
		self.reapply_font(persist=True)
		size_cache.clear()
		render_cache.clear()
		if hasattr(self, 'text_blit_y_cache'): self.text_blit_y_cache.clear()
		self.how_to_play_font_cache.clear()
		self.build_search_cache()
		self.bestiary_search_cache.clear()

	def reapply_font(self, persist=False):
		lang = loc.get_locale()
		self.font_px = pick_font_size(lang)

		def load_font(px):
			try:
				path = pick_font_path(lang)
				return pygame.font.Font(path, px)
			except Exception:
				return pygame.font.Font(os.path.join(FONT_DIR, FONT_MAP["default"]), px)

		self.font_loader = load_font
		self.font = load_font(self.font_px)
		self.options_menu_x = None

		# recompute metrics
		self.linesize = self.font.get_linesize() + FONT_PAD
		self.char_width = self.font.size("W")[0]
		self.set_character_panel_columns()
		self.recap_number_col_width = self.font.size("99999")[0] + 4
		self.recap_number_col_x = self.h_margin - self.recap_number_col_width - self.font_px

		self.font_variant_cache = {0: (self.font, self.linesize)}
		if not hasattr(self, 'max_shrink_level'): self.max_shrink_level = 4

		# persist in options
		if persist:
			try:
				with open('options2.dat', 'wb') as f:
					pickle.dump(self.options, f)
			except Exception:
				pass

	def get_font_variant(self, shrink_level):
		if shrink_level is None: shrink_level = 0
		level = max(0, min(self.max_shrink_level, int(shrink_level)))
		cached = self.font_variant_cache.get(level)
		if cached: return cached
		px = max(self.font_px - 2 * level, 8)
		font = self.font_loader(px)
		linesize = font.get_linesize() + FONT_PAD
		self.font_variant_cache[level] = (font, linesize)
		return font, linesize

	def set_character_panel_columns(self):
		self.spell_hotkey_col_w = max(self.font.size(s)[0] for s in ("99", "S9", "C9")) + 6
		self.spell_charges_col_w = self.spell_hotkey_col_w

		self.spell_icon_px = min(FONT_SIZE, self.linesize)

		self.spell_hotkey_x = self.border_margin
		self.spell_icon_x = self.spell_hotkey_x + self.spell_hotkey_col_w
		self.spell_name_x = self.spell_icon_x + FONT_SIZE + 6
		self.spell_charges_x = self.character_display.get_width() - self.border_margin

		self.spell_name_max_w = max(0, (self.spell_charges_x - self.spell_charges_col_w - self.spell_name_x - 2))

	def draw_screen(self):
		# Do not try to draw the screen when the game is minimized
		if self.window_minimized: return
		pygame.display.flip()

	def get_surface_pos(self, surf):
		if surf == self.middle_menu_display: return (self.h_margin, 0)
		elif surf == self.examine_display: return (self.screen.get_width() - self.h_margin, 0)
		else: return (0, 0)

	def load_ui_panels(self):
		self.ui_all = pygame.image.load(os.path.join("rl_data", "UI", "ui_all.png")).convert_alpha()
		# cut it up rather than use the full image, we don't need to blit all millions of pixels per frame, just the actual border
		ui_width, ui_height = self.ui_all.get_size()
		edge_width = 8
		separator_width = 10
		inner_height = ui_height - 2 * edge_width
		ui_frame_rects = [
			pygame.Rect(0, 0, ui_width, edge_width),
			pygame.Rect(0, ui_height - edge_width, ui_width, edge_width),
			pygame.Rect(0, edge_width, edge_width, inner_height),
			pygame.Rect(self.h_margin - separator_width // 2, edge_width, separator_width, inner_height),
			pygame.Rect(ui_width - self.h_margin - separator_width // 2, edge_width, separator_width, inner_height),
			pygame.Rect(ui_width - edge_width, edge_width, edge_width, inner_height),
		]
		self.ui_frame_blits = [(self.ui_all, rect.topleft, rect) for rect in ui_frame_rects]

	def get_audio_path(self, subdir, name):
		base_path = os.path.join('rl_data', subdir)
		if os.path.splitext(name)[1]: candidates = [os.path.join(base_path, name)]
		else: candidates = [os.path.join(base_path, name + ext) for ext in SUPPORTED_SOUND_EXTS]

		for candidate in candidates:
			if os.path.exists(candidate):
				return candidate

		return None

	def preload_sound_effects(self):
		if not self.can_play_sound: return
		sound_dir = os.path.join('rl_data', 'soundFX')
		if not os.path.isdir(sound_dir): return

		sound_names = set()
		for filename in os.listdir(sound_dir):
			sound_name, ext = os.path.splitext(filename)
			if ext.lower() not in SUPPORTED_SOUND_EXTS: continue
			sound_names.add(sound_name)

		for sound_name in sorted(sound_names):
			if sound_name in self.sound_effects: continue
			filename = self.get_audio_path("soundFX", sound_name)
			if not filename: continue
			self.sound_effects[sound_name] = pygame.mixer.Sound(filename)

	def play_sound(self, sound_name):
		if not self.can_play_sound: return
		if sound_name in self.sound_cooldowns: return
		self.sound_cooldowns[sound_name] = SOUND_COOLDOWN_MAX


		if sound_name not in self.sound_effects:
			filename = self.get_audio_path("soundFX", sound_name)
			if not filename: return
			self.sound_effects[sound_name] = pygame.mixer.Sound(filename)

		sound = self.sound_effects[sound_name]

		if 'victory' in sound_name:
			self.victory_sound_channel.play(sound)
			return
		if 'hit_player' in sound_name:
			self.hit_player_sound_channel.play(sound)
		elif 'hit' in sound_name:
			self.hit_sound_channel.play(sound)
		elif 'step' in sound_name:
			self.step_sound_channel.play(sound)
		elif 'death' in sound_name:
			self.death_sound_channel.play(sound)
		elif 'sorcery_enemy' in sound_name:
			self.cast_sound_channel.play(sound)
		elif 'menu' in sound_name:
			self.ui_sound_channel.play(sound)
		else:
			self.misc_sound_channel.play(sound)

	def cancel_queued_music(self):
		if self.music_queued_name and self.music_queued_name.startswith('battle_'):
			battle_num = int(self.music_queued_name.rsplit('_', 1)[1])
			if self.track_queue is None: self.track_queue = []
			if battle_num != self.last_battle_track and battle_num not in self.track_queue: self.track_queue.append(battle_num)
		self.music_queued_name = None

	def queue_battle_music(self):
		battle_num = self.get_next_battle_track()
		track_name = 'battle_%d' % battle_num
		music_path = self.get_audio_path('music', track_name)
		if not music_path: return
		pygame.mixer.music.queue(music_path)
		pygame.mixer.music.set_volume(self.options['music_volume'] / 125)
		self.music_queued_name = track_name

	def promote_queued_music(self):
		if not self.music_queued_name: return False
		track_name = self.music_queued_name
		self.music_queued_name = None
		self.current_music = track_name
		self.last_battle_track = int(track_name.rsplit('_', 1)[1])
		self.queue_battle_music()
		return True

	def play_music(self, track_name, fade_ms=0):
		if not self.can_play_sound: return
		if track_name == self.current_music and self.music_is_busy(): return
		music_path = self.get_audio_path('music', track_name)
		if not music_path: return
		pygame.mixer.music.set_endevent()
		self.cancel_queued_music()
		pygame.mixer.music.load(music_path)
		pygame.mixer.music.set_volume(self.options['music_volume'] / 125)
		self.current_music = track_name
		if track_name.startswith('battle_'): self.last_battle_track = int(track_name.rsplit('_', 1)[1])
		pygame.mixer.music.set_endevent(MUSIC_OVER_EVENT)
		pygame.mixer.music.play()
		if track_name.startswith('battle_'): self.queue_battle_music()

	def on_music_end(self):
		if not self.can_play_sound: return

		# If we are in a level play another level song
		if self.game and not self.game.gameover:
			# If we are at the penultimate fight restart the bigboss song
			if self.game.level_num == LAST_LEVEL - 1:
				self.play_music('big_boss_theme')

			# If we are at the mordred fight restart the mordred song
			elif self.game.level_num == LAST_LEVEL:
				self.play_music("boss_theme")

			elif self.game.cur_level.gen_params.is_vault:
				self.play_music('vault_theme')

			elif self.current_music == 'title_theme' or self.current_music == 'vault_theme' or not self.music_is_busy():
				self.play_battle_music()

		# Otherwise restart the title music
		else: self.play_music("title_theme")

	def on_music_stream_end(self):
		if self.promote_queued_music(): return
		self.on_music_end()

	def deploy(self, p):

		self.terrain_level = None
		if self.game.try_deploy(self.deploy_target.x, self.deploy_target.y):

			self.deploy_anim_frames = 0
			if self.options.get('save_screenshots', False): self.make_level_screenshot(finished=False)

			self.game.p1.clear_runtime_anims()
			self.effects = []

			if self.game.level_num < LAST_LEVEL: self.play_sound("start_level")
			else: self.play_sound("start_final_level")
			self.on_music_end()

			self.deploy_target = None

			SteamAdapter.set_presence_game(self.game)

		else: self.play_sound("menu_abort")


	def on_level_finish(self):
		# Clear examine target to show summary
		self.examine_target = None
		self.level_stats_cache = None
		self.level_stats_cache_key = None
		self.post_victory_defer_frames = max(self.post_victory_defer_frames, 1)
		level_num = self.game.level_num
		self.queue_post_victory_task(lambda game=self.game, ln=level_num: game.write_pending_level_stats(ln))
		self.queue_post_victory_task(lambda game=self.game, ln=level_num: game.write_pending_combat_logs(ln))
		if not (self.game.gameover or self.game.victory) and getattr(self.game, 'autosave_enabled', True): self.queue_post_victory_task(lambda game=self.game: game.save_game())
		self.play_sound("victory_level")

	def queue_post_victory_task(self, task):
		if not self.game: return
		self.game.post_victory_tasks.append(task)

	# don't need to run this, gc happens when we get to the next level anyhow.
	def level_end_gc(self):
		c0, c1, c2 = gc.get_count()
		t0, t1, t2 = gc.get_threshold()
		gc.collect(0)
		if c1 >= t1: gc.collect(1)
		if c2 >= t2: gc.collect(2)

	def process_post_victory_tasks(self):
		if not self.game: return
		if self.post_victory_defer_frames > 0:
			self.post_victory_defer_frames -= 1
			return
		if not self.game.post_victory_tasks: return
		task = self.game.post_victory_tasks.pop(0)
		task()

	def choose_spell(self, spell, target=None):
		if spell.show_tt:
			self.examine_target = spell

		if self.deploy_target:
			self.play_sound("menu_abort")
			return

		if not spell.can_pay_costs():
			self.play_sound("menu_abort")
			self.cast_fail_frames = SPELL_FAIL_LOCKOUT_FRAMES
			return

		prev_spell = self.cur_spell
		self.cur_spell = spell

		def can_tab_target(t):
			unit = self.game.cur_level.get_unit_at(t.x, t.y)
			if unit is None: return False
			return are_hostile(self.game.p1, unit)

		self.play_sound("menu_confirm")
		self.targetable_tiles = spell.get_targetable_tiles()
		if hasattr(spell, 'get_tab_targets'): self.tab_targets = spell.get_tab_targets()
		else:
			self.tab_targets = [t for t in self.targetable_tiles if can_tab_target(t)]
			self.tab_targets.sort(key=lambda t: distance(t, self.game.p1))

		self.tab_targets = [Point(t.x, t.y) if not isinstance(t, Point) else t for t in self.tab_targets]

		if target is not None: self.cur_spell_target = Point(target.x, target.y)
		elif not prev_spell: self.cur_spell_target = Point(self.game.p1.x, self.game.p1.y)

	def reselect_last_spell(self):
		last_cast = self.game.last_manual_cast
		if not last_cast or last_cast.spell not in self.game.p1.spells:
			self.play_sound("menu_abort")
			return
		self.choose_spell(last_cast.spell, Point(last_cast.x, last_cast.y))

	def abort_cur_spell(self):
		self.cur_spell = None
		self.play_sound("menu_abort")
		self.examine_target = None

	def cast_cur_spell(self):
		success = self.game.try_cast(self.cur_spell, self.cur_spell_target.x, self.cur_spell_target.y)
		if not success: self.play_sound('menu_abort')
		self.cur_spell = None
		unit = self.game.cur_level.get_unit_at(self.cur_spell_target.x, self.cur_spell_target.y)
		if unit: self.cur_spell_target = unit
		self.examine_target = None

	def cycle_tab_targets(self):

		target = self.deploy_target or self.cur_spell_target
		if not self.tab_targets: return

		if target in self.tab_targets:
			index = self.tab_targets.index(target)
			new_index = (index + 1) % len(self.tab_targets)
		else:
			new_index = 0

		target = self.tab_targets[new_index]

		if self.deploy_target:
			self.deploy_target = target
		if self.cur_spell_target:
			self.cur_spell_target = target

		self.try_examine_tile(target)

	def make_opaque_tile(self, image):
		opaque = pygame.Surface(image.get_size()).convert()
		opaque.fill((0, 0, 0))
		opaque.blit(image, (0, 0))
		return opaque

	def load_chasm_sprites(self):
		self.chasm_sprites = {}

		overlay_path = os.path.join("rl_data", "tiles", "chasm", "chasm_black_transparency.png")
		overlay = None
		if os.path.exists(overlay_path): overlay = pygame.image.load(overlay_path).convert_alpha()

		for c in ["water", "lava", "swamp"]:
			path = os.path.join("rl_data", "tiles", "chasm", f"chasm_{c}.png")
			if os.path.exists(path):
				image = pygame.image.load(path).convert_alpha()
				if overlay:
					occupied_img = image.copy()
					occupied_img.blit(overlay, (0, 0))
					occupied_img = self.make_opaque_tile(occupied_img)

				image = self.make_opaque_tile(image)
				if not overlay: occupied_img = image
				self.chasm_sprites[c] = (image, occupied_img)

	def load_wall_sprites(self):
		self.wall_tiles = {}
		filenames = ['wall']
		for i in range(100): filenames += ['wall_%d' % i]
		for biome in all_biomes:
			self.wall_tiles[biome.tileset] = []
			paths = [os.path.join("rl_data", "tiles", "tilesets", "%s" % biome.tileset, "%s wall" % biome.tileset, f + '.png') for f in filenames]
			for p in paths:
				if os.path.exists(p):
					image = pygame.image.load(p).convert_alpha()
					self.wall_tiles[biome.tileset].append(self.make_opaque_tile(image))

	def load_floor_sprites(self):
		self.floor_tiles = {}
		filenames = ['floor']
		for i in range(10):
			filenames += ['floor_%d' % i]

		for biome in all_biomes:
			self.floor_tiles[biome.tileset] = []
			paths = [os.path.join("rl_data", "tiles", "tilesets", "%s" % biome.tileset, "%s floor" % biome.tileset, f + '.png') for f in filenames]
			for p in paths:
				if os.path.exists(p):
					image = pygame.image.load(p).convert_alpha()
					self.floor_tiles[biome.tileset].append(self.make_opaque_tile(image))

	def get_display_level(self):
		return self.game.next_level or self.game.cur_level

	def get_sprite_sheet(self, asset, radius=0):
		key = (tuple(asset), radius)

		if key not in self.sprite_sheets:
			self.sprite_sheets[key] = SpriteSheet(asset, radius)

		return self.sprite_sheets[key]

	def get_anim(self, unit, forced_asset=None):
		if not forced_asset:
			asset = get_asset_key(unit)
			for variant_asset, variant_radius in unit.asset_variants: # do lookup/cache on first draw to allow for smooth transitions rather than mid-turn lookups
				self.get_sprite_sheet(variant_asset, radius=variant_radius)
		elif forced_asset: asset = forced_asset
		sprite = self.get_sprite_sheet(asset, radius=unit.radius)
		return UnitSprite(unit, sprite, view=self)

	def load_effect_images(self):
		self.effect_images = {}
		self.effect_frames = {}
		self.minor_effect_images = {}
		self.minor_effect_frames = {}
		for tag in Tags:
			asset = ['effects', tag.name.lower()]
			if tag.asset: asset = tag.asset

			# Minor asset is always the major asset but with _0 apended to the filename (before the extension)
			minor_asset = asset[0:-1] + [asset[-1] + '_0']

			if has_image(asset):
				image = get_image(asset)
				if image:
					self.effect_images[tag.color.to_tup()] = image
					self.effect_frames[tag.color.to_tup()] = slice_image_strip(image, SPRITE_SIZE, SPRITE_SIZE)

			if has_image(minor_asset):
				minor_image = get_image(minor_asset)
				if minor_image:
					self.minor_effect_images[tag.color.to_tup()] = minor_image
					self.minor_effect_frames[tag.color.to_tup()] = slice_image_strip(minor_image, SPRITE_SIZE, SPRITE_SIZE)

	def preload_boot_assets(self):
		self.preload_sound_effects()

		projectile_dir = os.path.join('rl_data', 'effects', 'proj')
		if not os.path.isdir(projectile_dir): return
		for filename in os.listdir(projectile_dir): get_projectile_image(os.path.splitext(filename)[0])

	def get_projectile_effect_frames(self, effect):
		flip_x = effect.proj_origin.x > effect.proj_dest.x
		flip_y = effect.proj_origin.y < effect.proj_dest.y
		rotate = abs(effect.proj_origin.y - effect.proj_dest.y) > abs(effect.proj_origin.x - effect.proj_dest.x)

		proj_key = tuple(effect.proj_name) if isinstance(effect.proj_name, list) else effect.proj_name
		color_key = effect.end_color.to_tup()
		cache_key = (proj_key, color_key, effect.frames, flip_x, flip_y, rotate)
		if cache_key in self.projectile_effect_frames: return self.projectile_effect_frames[cache_key]

		sprite = get_projectile_image(effect.proj_name)
		if effect.end_color != Color(0, 0, 0):
			sprite = sprite.copy()
			sprite.fill(color_key, special_flags=pygame.BLEND_RGBA_MIN)

		if rotate:
			sprite = pygame.transform.rotate(sprite, 90)
		sprite = pygame.transform.flip(sprite, flip_x, flip_y)

		frames = []
		for i in range(effect.frames):
			frame = sprite.copy()
			fade_color = tween_color(Color(255, 255, 255), Color(0, 0, 0), i / effect.frames)
			frame.fill(fade_color.to_tup(), special_flags=pygame.BLEND_RGB_MIN)
			frames.append(frame)

		self.projectile_effect_frames[cache_key] = frames
		return frames

	def get_filled_effect_image(self, effect_color, fill_color):
		key = (effect_color, fill_color)
		if key not in self.effect_images:
			image = self.effect_images[effect_color].copy()
			image.fill(fill_color, special_flags=pygame.BLEND_RGBA_MIN)
			self.effect_images[key] = image
			self.effect_frames[key] = slice_image_strip(image, SPRITE_SIZE, SPRITE_SIZE)
			return image
		else:
			return self.effect_images[key]

	def get_effect_frame_list(self, effect):
		color_key = effect.color.to_tup()
		if color_key not in self.effect_images: return None

		if effect.end_color and effect.end_color != Color(0, 0, 0):
			fill_key = effect.end_color.to_tup()
			self.get_filled_effect_image(color_key, fill_key)
			return self.effect_frames.get((color_key, fill_key))

		if effect.minor and color_key in self.minor_effect_frames:
			return self.minor_effect_frames[color_key]

		return self.effect_frames.get(color_key)

	def queue_effect(self, new_effect, death_effect=False):
		# Limit queued effects on the same tile
		effect_point = (new_effect.x, new_effect.y)
		if death_effect: self.effect_queue.append((new_effect, True)); return True
		existing_count = self.effect_queue_tile_counts.get(effect_point, 0)
		if existing_count >= 3: return False
		self.effect_queue.append((new_effect, False))
		self.effect_queue_tile_counts[effect_point] = existing_count + 1
		return True

	def advance_queued_effects(self):
		if not self.effect_queue: return

		effect_tiles = set((e.x, e.y) for e in self.effects)
		next_queue = []
		next_tile_counts = {}
		for effect, death_effect in self.effect_queue:
			effect_point = (effect.x, effect.y)
			if death_effect or effect_point not in effect_tiles:
				self.effects.append(effect)
				effect_tiles.add((effect.x, effect.y))
			else:
				next_queue.append((effect, False))
				next_tile_counts[effect_point] = next_tile_counts.get(effect_point, 0) + 1
		self.effect_queue = next_queue
		self.effect_queue_tile_counts = next_tile_counts

	def get_effect(self, effect, color=None):
		# Go from level effect to PygameView effects
		if effect.color == Tags.Sound_Effect.color:
			# So bad but so good
			assert(isinstance(effect.end_color, str))
			self.play_sound(effect.end_color)
			return None
		elif effect.color == Tags.Leap.color:
			return LeapEffect(effect.x, effect.y, effect.leap_unit, effect.end_color, effect.frames)
		elif effect.color == Tags.Arrow.color:
			frames = self.get_projectile_effect_frames(effect)
			return ProjectileEffect(effect.x, effect.y, frames)
		elif effect.color.to_tup() in self.effect_images:
			frames = self.get_effect_frame_list(effect)
			if frames: return SimpleSprite(effect.x, effect.y, frames, speed=effect.speed)
		print("No effect found for %s" % effect.color)
		return EffectRect(effect.x, effect.y, effect.color, effect.frames)

	def get_mouse_rel(self):
		return self.mouse_dx, self.mouse_dy

	def get_mouse_pos(self):
		return pygame.mouse.get_pos()

	def get_mouse_level_point(self):
		# Get the integer coordinates of the mouse on the battlefield if it is on the battlefield
		x, y = self.get_mouse_pos()

		x -= self.h_margin
		y -= self.v_margin

		x //= SPRITE_SIZE
		y //= SPRITE_SIZE

		if x < 0 or y < 0: return None
		if x >= LEVEL_SIZE or y >= LEVEL_SIZE: return None
		return Point(x, y)

	def try_move(self, movedir):
		result = self.game.try_move(*movedir)
		if result:
			self.play_sound("step_player")
			self.second_step = 1 - self.second_step
		elif self.game.p1.stationary: self.cast_fail_frames = SPELL_FAIL_LOCKOUT_FRAMES
		return result

	def try_examine_tile(self, point):
		if point is None: return
		if not self.get_display_level().is_point_in_bounds(point): return

		tile = self.get_display_level().tiles[point.x][point.y]
		self.examine_target = (tile.unit if tile.unit != self.game.p1 else None) or tile.cloud or tile.prop

	def is_animating_deploy(self):
		return self.deploy_anim_frames not in (0, self.get_max_deploy_frames())

	def can_execute_inputs(self):
		return self.cast_fail_frames <= 0 and self.game.is_awaiting_input() and not self.is_animating_deploy()

	def is_bestiary_shop(self):
		return self.state == STATE_SHOP and self.shop_type == SHOP_TYPE_BESTIARY

	def is_list_only_shop(self):
		return self.state == STATE_SHOP and self.shop_type in [SHOP_TYPE_BESTIARY, SHOP_TYPE_WARDROBE]

	# Use private _examine_target and _examine_index to present a virtual view of self.examine_target which rotates btw related tooltips
	@property
	def examine_target(self):
		if self._examine_index: return self._examine_extras[self._examine_index - 1]
		else: return self._examine_target

	@examine_target.setter
	def examine_target(self, e):
		if e == self._examine_target: return
		self._examine_target = e
		self._examine_index = 0
		if self.is_list_only_shop(): self._examine_extras = []
		else: self._examine_extras = self.get_extra_examine_targets()

	def get_extra_examine_targets(self):
		# Components
		if self.game and isinstance(self._examine_target, (Component, ComponentPickup)):
			comp = self._examine_target.component if isinstance(self._examine_target, ComponentPickup) else self._examine_target
			extras = comp.get_extra_examine_tooltips(self.game) or []
			if isinstance(extras, EquipmentList): extras = [extras]
			expanded = []
			for e in extras:
				if isinstance(e, Unit): e.set_default_resistances()
				expanded.append(e) # the equipment list page
				if isinstance(e, EquipmentList): expanded.extend(e.equipments) # each equipment you can make with it
			return expanded

		getter = getattr(self._examine_target, "get_extra_examine_tooltips", None)
		if getter:
			extras = getter() or []
			if extras:
				for e in extras:
					if isinstance(e, Unit) and self.game:
						e.set_default_resistances()
				return extras

		elif isinstance(self._examine_target, Shop):
			tooltips = []
			for i in self._examine_target.items:
				tooltips.append(i)
				extras = i.get_extra_examine_tooltips() or []
				for t in extras: tooltips.append(t)
			return tooltips
		return []

	def move_examine_target(self, movedir):
		num_extra_targets = len(self._examine_extras)
		if not num_extra_targets: return
		self._examine_index += movedir
		self._examine_index = max(0, self._examine_index)
		self._examine_index = min(num_extra_targets, self._examine_index)

	def process_examine_panel_input(self):
		for evt in self.events:
			if evt.type == pygame.KEYDOWN:
				if evt.key in self.key_binds[KEY_BIND_NEXT_EXAMINE_TARGET]:
					self.move_examine_target(1)
				elif evt.key in self.key_binds[KEY_BIND_PREV_EXAMINE_TARGET]:
					self.move_examine_target(-1)
			elif evt.type == pygame.MOUSEWHEEL:
				if evt.y > 0:
					self.move_examine_target(-1)
				elif evt.y < 0:
					self.move_examine_target(1)

	def adjust_spell_speed(self, amount):
		self.options['spell_speed'] = (self.options['spell_speed'] + amount) % len(SPELL_SPEED_NAMES)
		self.spell_speed_flash_frames = SPELL_SPEED_FLASH_FRAMES
		self.save_options()

	def process_level_input(self):

		if self.cast_fail_frames:
			self.cast_fail_frames -= 1

		# During gameover tiling, ignore inputs until the blackout/tiling finishes
		if self.game and self.game.gameover and (self.gameover_frames < 9 or self.gameover_tiles):
			return

		if any(evt.type == pygame.KEYDOWN for evt in self.events) and self.gameover_frames > 8 and not self.gameover_tiles:
			for evt in self.events:
				if evt.type == pygame.KEYDOWN and evt.key in self.key_binds[KEY_BIND_MESSAGE_LOG]:
					self.open_combat_log(from_death=True)
					return
			self.enter_reminisce()
			return

		level_point = self.get_mouse_level_point()
		movedir = None
		keys = pygame.key.get_pressed()
		modifier_held = any(key and keys[key] for key in self.key_binds[KEY_BIND_MODIFIER])

		if self.can_execute_inputs() and self.path:
			if not self.path_delay:
				next_point = self.path[0]
				movedir = Point(next_point.x - self.game.p1.x, next_point.y - self.game.p1.y)
				if self.try_move(movedir): self.path = self.path[1:]
				else: self.game.try_pass()
				self.path_delay = MAX_PATH_DELAY
			else: self.path_delay -= 1

		# Disable ff after 1 round
		if self.can_execute_inputs() and self.fast_forward: self.fast_forward = False

		for evt in self.events:
			if not evt.type == pygame.KEYDOWN: continue

			if evt.key in self.key_binds[KEY_BIND_SPELL_SPEED_DOWN]:
				self.adjust_spell_speed(-1)
				continue
			if evt.key in self.key_binds[KEY_BIND_SPELL_SPEED_UP]:
				self.adjust_spell_speed(1)
				continue

			# Cancel path on key down
			# do this here instead of by checking pressed keys to deal with pygame alt tab bug
			self.path = []

			if evt.key in self.key_binds[KEY_BIND_FF]:
				self.fast_forward = True
				self.game.try_pass()

			if self.can_execute_inputs():
				if evt.key in self.key_binds[KEY_BIND_UP]:
					movedir = Point(0, -1)
				if evt.key in self.key_binds[KEY_BIND_DOWN]:
					movedir = Point(0, 1)
				if evt.key in self.key_binds[KEY_BIND_LEFT]:
					movedir = Point(-1, 0)
				if evt.key in self.key_binds[KEY_BIND_RIGHT]:
					movedir = Point(1, 0)
				if evt.key in self.key_binds[KEY_BIND_DOWN_RIGHT]:
					movedir = Point(1, 1)
				if evt.key in self.key_binds[KEY_BIND_DOWN_LEFT]:
					movedir = Point(-1, 1)
				if evt.key in self.key_binds[KEY_BIND_UP_LEFT]:
					movedir = Point(-1, -1)
				if evt.key in self.key_binds[KEY_BIND_UP_RIGHT]:
					movedir = Point(1, -1)

				if evt.key in self.key_binds[KEY_BIND_CONFIRM]:
					if self.cur_spell:
						self.cast_cur_spell()
					elif self.game.deploying:
						self.deploy(level_point)

				if evt.key in self.key_binds[KEY_BIND_PASS]:
					if not self.cur_spell:
						self.game.try_pass()

				if evt.key in self.key_binds[KEY_BIND_RESELECT_SPELL] and not self.game.deploying:
					self.reselect_last_spell()

				for bind in range(KEY_BIND_SPELL_1, KEY_BIND_SPELL_10+1):
					if evt.key in self.key_binds[bind] and not self.game.deploying:
						index = bind - KEY_BIND_SPELL_1
						if modifier_held and index < 3:
							self.interact_wishlist_slot(index)
							break
						if len(self.game.p1.spells) > index: self.choose_spell(self.game.p1.spells[index])

				no_hostiles = None
				if evt.key in self.key_binds[KEY_BIND_WALK] or evt.key in self.key_binds[KEY_BIND_AUTOPICKUP]:
					no_hostiles = not self.game.cur_level.has_hostile_units()

				if evt.key in self.key_binds[KEY_BIND_WALK]:
					if no_hostiles:
						spell = WalkSpell()
						spell.caster = self.game.p1
						self.choose_spell(spell)

				if evt.key in self.key_binds[KEY_BIND_VIEW]:
					spell = LookSpell()
					spell.caster = self.game.p1
					self.choose_spell(spell)

				if evt.key in self.key_binds[KEY_BIND_CHAR]:
					self.open_char_sheet()

				if evt.key in self.key_binds[KEY_BIND_SPELLS]:
					self.open_shop(SHOP_TYPE_SPELLS)

				if evt.key in self.key_binds[KEY_BIND_CRAFTING]:
					self.open_shop(SHOP_TYPE_CRAFTING)

				if evt.key in self.key_binds[KEY_BIND_TAB] and (self.cur_spell or self.deploy_target):
					self.cycle_tab_targets()

				if evt.key in self.key_binds[KEY_BIND_HELP]:
					self.show_help()

				if evt.key in self.key_binds[KEY_BIND_AUTOPICKUP] and no_hostiles:
					self.autopickup()

				if evt.key in self.key_binds[KEY_BIND_INTERACT] and self.game.cur_level.tiles[self.game.p1.x][self.game.p1.y].prop:
					self.game.cur_level.tiles[self.game.p1.x][self.game.p1.y].prop.on_player_enter(self.game.p1)

					if self.game.cur_level.cur_shop:
						self.open_shop(SHOP_TYPE_SHOP)

					if self.game.cur_level.cur_portal and not self.game.deploying:
						self.game.enter_portal()

				if evt.key in self.key_binds[KEY_BIND_ABORT]:
					if self.cur_spell:
						self.abort_cur_spell()
					elif self.game.deploying:
						self.deploy_target = None
						self.examine_target = None
						self.game.try_abort_deploy()
						self.play_sound("menu_abort")
					else:
						self.open_options()

				if evt.key in self.key_binds[KEY_BIND_MESSAGE_LOG]:
					self.open_combat_log()

				if evt.key in self.key_binds[KEY_BIND_REROLL]:
					self.game.try_reroll_rifts()

			global cheats_enabled
			if can_enable_cheats and evt.key == pygame.K_z and keys[pygame.K_LSHIFT] and keys[pygame.K_LCTRL]:
				cheats_enabled = not cheats_enabled

			if cheats_enabled:
				if evt.key == pygame.K_t and level_point:
					if self.game.cur_level.can_move(self.game.p1, level_point.x, level_point.y, teleport=True):
						self.game.cur_level.act_move(self.game.p1, level_point.x, level_point.y, teleport=True)

				if evt.key == pygame.K_x: self.game.p1.xp += 10
				if evt.key == pygame.K_y: self.game.p1.xp = 0

				if evt.key == pygame.K_h: self.game.p1.max_hp += 250; self.game.p1.cur_hp =self.game.p1.max_hp

				# Press j to jill everything.
				if evt.key == pygame.K_j:
					for unit in list(self.game.cur_level.units):
						if unit != self.game.p1:
							unit.kill()

				if evt.key == pygame.K_g: self.game.p1.kill()

				if evt.key == pygame.K_r:
					for spell in self.game.p1.spells: spell.cur_charges = spell.get_stat('max_charges')

				if evt.key == pygame.K_s:
					self.game.save_game('./cheat_save')

				if evt.key == pygame.K_l:
					self.game = continue_game('cheat_save')
					self.clear_shop_filter_cache()
					self.build_search_cache()

				if evt.key == pygame.K_c and keys[pygame.K_LSHIFT]:
					x = self.game.cur_level.tiles[9999][9999]

				if evt.key == pygame.K_h:
					self.game.p1.cur_hp = self.game.p1.max_hp

				if evt.key == pygame.K_d:
					gates = [tile.prop for tile in self.game.cur_level.iter_tiles() if isinstance(tile.prop, Portal)]
					for gate in gates:
						gate.level_gen_params = LevelGenerator(self.game.level_num + 1, self.game)
						if not gate.locked: gate.level_gen_params.materialize_reward(self.game.p1)
						gate.description = gate.level_gen_params.get_description()
						gate.next_level = None
						self.game.cur_level.flash(gate.x, gate.y, Tags.Arcane.color)

				if evt.key == pygame.K_f:
					self.examine_target = self.get_display_level().gen_params

				# if evt.key == pygame.K_v:
				# 	to_blit = self.screen
				# 	scale = 1
				# 	w = to_blit.get_width() * scale
				# 	h = to_blit.get_height() * scale
				# 	surf = pygame.transform.scale(to_blit, (w, h))
				#
				# 	for i in range(100):
				# 		path = "screencap\\ss_%d.png" % i
				# 		if not os.path.exists(path):
				# 			pygame.image.save(surf, path)
				# 			break

				if evt.key == pygame.K_EQUALS:
					self.game.level_num += 1

				if evt.key == pygame.K_MINUS:
					self.game.level_num -= 1

				# Press n to spawn 1 of each nonster, since m opens the message log
				if evt.key == pygame.K_n:
					for monster, cost, _ in spawn_options:
						unit = monster()
						p = self.game.cur_level.get_summon_point(0, 0, radius_limit=40)
						if p: self.game.cur_level.add_obj(unit, p.x, p.y)

				if evt.key == pygame.K_k and level_point: # convert
					u = self.game.cur_level.get_unit_at(level_point.x, level_point.y)
					if u: u.team = TEAM_PLAYER

				if evt.key == pygame.K_b and level_point:
					unit = None
					unit_fn = self.search_query or ""
					if unit_fn:
						try: result = eval(unit_fn, globals(), {})
						except Exception: result = None
						if callable(result) and '(' not in unit_fn:
							try: result = result()
							except Exception: result = None
						if isinstance(result, Unit): unit = result
					if unit:
						p = self.game.cur_level.get_summon_point(level_point.x, level_point.y, unit=unit)
						if p: self.game.cur_level.add_obj(unit, p.x, p.y)

				if evt.key == pygame.K_F4 and self.game.p1.is_alive(): # character reset
					level = self.game.cur_level
					old = self.game.p1
					spawn = Point(old.x, old.y)

					old.kill(trigger_death_event=False)

					wizard = self.game.make_player_character()
					self.game.p1 = wizard
					level.player_unit = wizard  # keep level state consistent
					level.add_obj(wizard, spawn.x, spawn.y)

					level.requested_action = None
					level.is_awaiting_input = False
					level.turns = level.iter_frame()
					try:
						while not level.is_awaiting_input: next(level.turns)
					except StopIteration: pass

					self.examine_target = wizard
					self.cur_spell = None
					self.cur_spell_target = None

				if evt.key == pygame.K_p:
					import pdb
					pdb.set_trace()

				if evt.key == pygame.K_o and level_point:
					self.game.cur_level.add_obj(MemoryOrb(), level_point.x, level_point.y)

				if evt.key == pygame.K_F1 and level_point:
					self.game.cur_level.add_prop(megachest(), level_point.x, level_point.y)

				if evt.key == pygame.K_F2: # get one of every component
					for c in all_components: self.game.p1.add_component(c())
					for c in rare_components: self.game.p1.add_component(c())

				if evt.key == pygame.K_F3 and level_point:
					forced = None
					query = (self.search_query or '').strip()
					if query:
						try: forced = eval(query, globals(), {})
						except Exception: forced = None

					reward = roll_level_reward(self.game.cur_level.level_no, player=self.game.p1, forced=forced)
					print(f"Rolled a {reward.name}.")
					self.game.cur_level.add_prop(reward, level_point.x, level_point.y)

				if evt.key == pygame.K_BACKQUOTE and level_point:
					query = (self.search_query or '').strip()
					c = obj = None
					if query:
						try: c = eval(query, globals(), {})
						except Exception: c = None
						else: c = c()
					if isinstance(c, Component): obj = ComponentPickup(c)
					if obj: self.game.cur_level.add_prop(obj, level_point.x, level_point.y)


		if movedir:
			repeats = 1
			if keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT]:
				repeats = 4
			if self.cur_spell:
				for _ in range(repeats):
					new_spell_target = Point(self.cur_spell_target.x + movedir.x, self.cur_spell_target.y + movedir.y)
					if self.game.cur_level.is_point_in_bounds(new_spell_target):
						self.cur_spell_target = new_spell_target
						self.try_examine_tile(new_spell_target)
			elif self.game.deploying and self.deploy_target:
				for _ in range(repeats):
					new_point = Point(self.deploy_target.x + movedir.x, self.deploy_target.y + movedir.y)
					if self.game.next_level.is_point_in_bounds(new_point):
						self.deploy_target = new_point
						self.try_examine_tile(new_point)
			else:
				self.try_move(movedir)
				self.cur_spell_target = None


		mouse_dx, mouse_dy = self.get_mouse_rel()
		if mouse_dx or mouse_dy:
			if level_point:
				if self.cur_spell:
					self.cur_spell_target = level_point
				if self.game.deploying:
					self.deploy_target = level_point

				self.try_examine_tile(level_point)

		for click in self.events:
			if click.type != pygame.MOUSEBUTTONDOWN:
				continue

			# Cancel click to move on subsequent clicks
			self.path = []

			if self.gameover_frames > 8 and not self.gameover_tiles:
				# allow clicking the character panel to open the combat log before reminiscing
				mx, my = self.get_mouse_pos()
				if mx < self.h_margin:
					self.process_click_character(click.button, mx, my)
					if self.state == STATE_COMBAT_LOG: return
				self.enter_reminisce()
				return

			mx, my = self.get_mouse_pos()
			if mx < self.h_margin:
				self.process_click_character(click.button, mx, my)

			if click.button == pygame.BUTTON_LEFT and self.can_execute_inputs():
				if self.cur_spell and click.button == pygame.BUTTON_LEFT and level_point:
					self.cur_spell_target = level_point
					self.cast_cur_spell()
				elif self.game.deploying and level_point:
					self.deploy_target = level_point
					self.deploy(self.deploy_target)
				elif level_point and distance(level_point, self.game.p1) == 0:
					self.game.try_pass()
				elif level_point and all(u.team == TEAM_PLAYER for u in self.game.cur_level.units):
					self.path = self.game.cur_level.find_path(self.game.p1, level_point, self.game.p1, pythonize=True, cosmetic=True)
				elif level_point and distance(level_point, self.game.p1, diag=True) >= 1:
					path = self.game.cur_level.find_path(self.game.p1, level_point, self.game.p1, pythonize=True, cosmetic=True)
					if path:
						movedir = Point(path[0].x - self.game.p1.x, path[0].y - self.game.p1.y)
						self.try_move(movedir)

			if click.button == pygame.BUTTON_RIGHT:
				if self.cur_spell:
					self.abort_cur_spell()
				if self.game.deploying:
					self.deploy_target = None
					self.examine_target = None
					self.game.try_abort_deploy()
					self.play_sound("menu_abort")

			# Only process one mouse evt per frame
			#break

	def autopickup(self):
		if self.cur_spell: self.cur_spell = None

		props = [tile.prop for tile in self.game.cur_level.iter_tiles() if tile.prop]
		pickups = [p for p in props if isinstance(p, MemoryOrb) or isinstance(p, ComponentPickup) or isinstance(p, HeartDot)]  #  or isinstance(p, SpellScroll)]
		destinations = [p for p in pickups if self.game.cur_level.find_path(self.game.p1, p, self.game.p1, pythonize=True)]


		full_path = []
		prev_dest = self.game.p1
		while destinations:
			destinations.sort(key=lambda d: distance(prev_dest, d), reverse=True)
			d = destinations.pop()
			path = self.game.cur_level.find_path(prev_dest, d, self.game.p1, pythonize=True)
			if path:
				full_path += path
				prev_dest = d

		self.path = full_path

	def draw_char_sheet(self, show_available_upgrades=True):
		self.middle_menu_display.fill((0, 0, 0))

		player = self.game.p1
		applied_upgrades_by_spell = {}
		for buff in player.buffs:
			if isinstance(buff, Upgrade) and buff.prereq:
				applied_upgrades_by_spell.setdefault(buff.prereq, []).append(buff)

		spell_rows = []
		spell_body_rows = 1
		for spell in player.spells:
			applied_upgrades = applied_upgrades_by_spell.get(spell, [])
			unapplied = max(0, len(spell.spell_upgrades) - len(applied_upgrades))
			available_upgrade_row = None
			if show_available_upgrades:
				remaining_slots = max(0, 2 - len(applied_upgrades))
				if remaining_slots and unapplied:
					keyword = "Upgrade" if remaining_slots == 1 else "Upgrades"
					available_upgrade_row = ('{amt} {keyword} Available', {"amt": remaining_slots, 'keyword':keyword})

			spell_rows.append((spell, applied_upgrades, available_upgrade_row))
			spell_body_rows += 1 + len(applied_upgrades)
			if available_upgrade_row: spell_body_rows += 1

		equipment_body_rows = 1 + len(player.equipment)
		required_rows = 3 + max(spell_body_rows, equipment_body_rows)
		line_limit = self.middle_menu_display.get_height() - self.border_margin
		shrink_level = 0
		for level in range(self.max_shrink_level + 1):
			_, linesize = self.get_font_variant(level)
			shrink_level = level
			if required_rows * linesize <= line_limit: break

		font, linesize = self.get_font_variant(shrink_level)
		font_kwargs = {"font": font, "linesize_override": linesize}
		upgrade_indent = 18

		# Spells
		spell_x_offset = self.border_margin + 18
		cur_x = spell_x_offset
		cur_y = linesize
		self.draw_string("Spells", self.middle_menu_display, cur_x, cur_y, **font_kwargs)

		cur_y += linesize
		cur_y += linesize

		col_width = self.middle_menu_width // 2 - 2*self.border_margin
		upgrade_col_width = col_width - upgrade_indent

		#Spells
		for spell, applied_upgrades, available_upgrade_row in spell_rows:

			self.draw_string(spell.name, self.middle_menu_display, cur_x, cur_y, mouse_content=spell, content_width=col_width, **font_kwargs)
			cur_y += linesize

			# Spell Upgrades
			for upgrade in applied_upgrades:
				fmt = upgrade.name
				color = (255, 255, 255)
				self.draw_string(fmt, self.middle_menu_display, cur_x + upgrade_indent, cur_y, mouse_content=upgrade, content_width=upgrade_col_width, color=color, **font_kwargs)
				cur_y += linesize

			if available_upgrade_row:
				self.draw_string(available_upgrade_row, self.middle_menu_display, cur_x + upgrade_indent, cur_y, content_width=upgrade_col_width, **font_kwargs)
				cur_y += linesize

		learn_color = (170, 170, 170) if self.game.player_spell_limit_reached() else (255, 255, 255)
		self.draw_string(("Learn a Spell ({char})", {"char": self.get_keybind_letters(KEY_BIND_SPELLS)}), self.middle_menu_display, cur_x, cur_y, learn_color, mouse_content=LEARN_SPELL_TARGET, content_width=col_width, **font_kwargs)


		#EQUIPMENT
		equipment_x_offset = self.middle_menu_width // 2 + self.border_margin
		cur_x = equipment_x_offset
		cur_y = linesize
		self.draw_string("Equipment", self.middle_menu_display, cur_x, cur_y, **font_kwargs)
		cur_y += 2 * linesize
		for e in player.equipment:
			self.draw_string(e.name, self.middle_menu_display, cur_x, cur_y, mouse_content=e, content_width=col_width, **font_kwargs)
			cur_y += linesize

		self.draw_string(("Craft Equipment ({char})", {"char": self.get_keybind_letters(KEY_BIND_CRAFTING)}), self.middle_menu_display, cur_x, cur_y, mouse_content=CRAFTING_TARGET, content_width=col_width, **font_kwargs)
		self.screen.blit(self.middle_menu_display, (self.h_margin, 0))

	def flatten_recipe(self, recipe):
		flat = []
		for tag, amount in recipe: flat.extend([tag] * amount)
		return flat

	def clear_component_selection(self):
		self.shop_craft_component_ingredients.clear()
		self.shop_craft_remaining_tags = []
		self.cancel_craft_animation()

	def clear_shop_filters(self):
		self.shop_tag_filter.clear()
		self.shop_attr_filter.clear()
		self.shop_bonus_filter.clear()
		self.shop_gain_tag_filter.clear()
		self.shop_gain_attr_filter.clear()
		self.shop_recipe_tag_filter.clear()
		self.shop_filter_category = SHOP_FILTER_TAGS
		self.filter_unvictoried = False
		self.filter_unused = False
		self.filter_can_afford = False

	def invalidate_shop_options(self):
		self.shop_options_cache = None

	def clear_shop_filter_cache(self):
		self.shop_filter_option_cache.clear()
		self.shop_craft_blueprint_cache.clear()
		self.invalidate_shop_options()

	def get_shop_options_cache_key(self):
		tag_filter_key = tuple(sorted(t.name for t in self.shop_tag_filter))
		attr_filter_key = tuple(sorted(self.shop_attr_filter))
		bonus_filter_key = tuple(sorted(self.shop_bonus_filter))
		gain_tag_filter_key = tuple(sorted(t.name for t in self.shop_gain_tag_filter))
		gain_attr_filter_key = tuple(sorted(self.shop_gain_attr_filter))
		recipe_tag_filter_key = tuple(sorted(t.name for t in self.shop_recipe_tag_filter))
		shop_target = None
		if self.shop_type == SHOP_TYPE_SPELL_UPGRADES: shop_target = self.shop_upgrade_spell
		if self.shop_type == SHOP_TYPE_COMPONENT_SELECTION: shop_target = self.shop_craft_equipment
		return (self.shop_type, self.search_query, tag_filter_key, attr_filter_key, bonus_filter_key, gain_tag_filter_key, gain_attr_filter_key, recipe_tag_filter_key, self.filter_unused, self.filter_unvictoried, self.filter_can_afford, shop_target)

	def leave_shop_context(self):
		if self.state != STATE_SHOP: return
		self.set_search_focus(False, clear=True)
		if self.shop_type == SHOP_TYPE_COMPONENT_SELECTION: self.clear_component_selection()
		self.abort_to_spell_shop = False
		self.abort_to_crafting_shop = False
		if self.game and self.game.cur_level.cur_shop: self.game.try_shop(None)

	def open_shop(self, shop_type, spell=None, equipment=None):
		self.cancel_craft_animation()
		if shop_type != SHOP_TYPE_SHOP: self.leave_shop_context()
		self.prev_state = self.state

		self.search_query = ""
		self.search_focused = False

		self.play_sound("menu_confirm")

		self.shop_open_examine_target = self.examine_target

		self.shop_type = shop_type
		if spell: self.shop_upgrade_spell = spell
		categories = self.get_shop_filter_categories()
		if categories and self.shop_filter_category not in categories: self.shop_filter_category = categories[0]

		if equipment:
			self.shop_craft_equipment = equipment # tell the game, what's being crafted
			self.shop_craft_component_ingredients = [] # reset the ingredients being used
			self.shop_craft_remaining_tags = self.flatten_recipe(equipment.recipe) # make a copy of the list of tags required to make the equipment

		if shop_type == SHOP_TYPE_SPELLS: self.build_spell_shop_filter_cache()
		elif shop_type == SHOP_TYPE_CRAFTING: self.build_craft_shop_filter_cache()
		self.invalidate_shop_options()

		self.state = STATE_SHOP
		self.shop_page = 0
		self.shop_rows_per_page = self.max_shop_objects

		shoptions = self.get_shop_options()
		if shoptions: self.examine_target = shoptions[0]

		self.deconstruction_component_cache = {}

	def open_abandon_prompt(self):
		self.state = STATE_CONFIRM
		self.confirm_text = "Really abandon the current run?"
		self.confirm_yes = self.confirm_abandon
		self.confirm_no = self.abort_abandon
		self.examine_target = True

	def confirm_abandon(self):
		SteamAdapter.record_loss()
		abort_game()
		self.play_sound("menu_confirm")
		self.return_to_title()

	def abort_abandon(self):
		self.play_sound("menu_confirm")
		self.return_to_title()

	def open_buy_prompt(self, item):
		self.cancel_craft_animation()
		if isinstance(item, Spell) or isinstance(item, Upgrade): self.play_sound('learn_spell')
		else: self.play_sound("menu_confirm")
		self.state = STATE_CONFIRM
		self.confirm_yes = self.confirm_buy
		self.confirm_no = self.abort_buy

		self.chosen_purchase = item
		i = item.name

		if self.shop_type == SHOP_TYPE_SHOP:
			cur_shop = self.get_display_level().cur_shop
			if cur_shop: self.confirm_text = cur_shop.get_confirm_text(i)
			else: self.confirm_text = ("Buy {item}?", {"item": i})
		elif isinstance(item, Equipment): self.confirm_text = ("Craft {item}?", {"item": i})
		else: self.confirm_text = ("Learn {spell} for {amount} SP?" , {"spell": i, "amount": self.game.get_upgrade_cost(self.chosen_purchase)})

		# Default to yes (?)
		self.examine_target = True

	def confirm_buy(self):
		self.game.shop_craft_component_ingredients = self.shop_craft_component_ingredients.copy()
		purchase = self.chosen_purchase
		shop = self.game.cur_level.cur_shop if self.shop_type == SHOP_TYPE_SHOP else None
		success = self.game.try_shop(self.chosen_purchase)
		assert(success) # Shouldnt get into the screen if we cannot buy
		if isinstance(purchase, Equipment): self.pay_components()
		self.refresh_search_cache_after_purchase(purchase, shop)
		self.invalidate_shop_options()
		self.abort_to_spell_shop = False
		self.abort_to_crafting_shop = False
		self.close_shop()

	def pay_components(self):
		if self.shop_craft_component_ingredients: # make the player pay for the crafting with the ingredients
			for c in self.shop_craft_component_ingredients: self.game.p1.remove_component(c)
		self.shop_craft_component_ingredients.clear() # reset the list of offered components

	def reset_components(self):
		self.shop_craft_component_ingredients.clear()
		self.shop_craft_remaining_tags = self.flatten_recipe(self.chosen_purchase.recipe) if hasattr(self.chosen_purchase, 'recipe') else []
		self.cancel_craft_animation()

	def abort_buy(self):
		self.state = STATE_SHOP
		self.reset_components()
		self.chosen_purchase = None
		self.play_sound("menu_abort")

	def draw_confirm(self):
		self.middle_menu_display.fill((0, 0, 0))
		self.examine_display.fill((0, 0, 0))

		# Draw Purchase Art in Background
		if self.game and self.shop_type in [SHOP_TYPE_SPELLS, SHOP_TYPE_COMPONENT_SELECTION]:
			to_draw = self.chosen_purchase if self.shop_type == SHOP_TYPE_SPELLS else self.shop_craft_equipment
			asset = get_asset_key(to_draw)
			image = get_image(asset)
			if image:
				big_shop = pygame.transform.scale(image, (self.middle_menu_width, self.middle_menu_display.get_height()))
				big_shop.fill((255, 255, 255, 30), special_flags=pygame.BLEND_RGBA_MULT)
				self.middle_menu_display.blit(big_shop, (0, 0))

		cur_y = self.middle_menu_display.get_height() // 2 - 3*self.linesize
		cur_x = (self.middle_menu_width - self.font.size(resolve_text(self.confirm_text))[0]) // 2
		self.draw_string(self.confirm_text, self.middle_menu_display, cur_x, cur_y)

		cur_y += 2*self.linesize
		cur_x = (self.middle_menu_width) // 4
		self.draw_string("Yes", self.middle_menu_display, cur_x, cur_y, mouse_content=True)

		cur_x = (self.middle_menu_width) * 3 // 4 - self.font.size("No")[0]
		self.draw_string("No", self.middle_menu_display, cur_x, cur_y, mouse_content=False)

		self.screen.blit(self.middle_menu_display, (self.h_margin, 0))

	def process_confirm_input(self):

		mx, my = self.get_mouse_pos()
		for evt in self.events:
			if evt.type == pygame.KEYDOWN:
				if evt.key in self.key_binds[KEY_BIND_ABORT]:
					self.confirm_no()
					return
				if evt.key in self.key_binds[KEY_BIND_CONFIRM]:
					if self.examine_target == True: self.confirm_yes(); return
					elif self.examine_target == False: self.confirm_no(); return

				if evt.key in self.key_binds[KEY_BIND_LEFT] or evt.key in self.key_binds[KEY_BIND_RIGHT]:
					if self.examine_target in [True, False]: self.examine_target = not self.examine_target
					else:
						if evt.key in self.key_binds[KEY_BIND_LEFT]: self.examine_target = True
						else: self.examine_target = False

			elif evt.type == pygame.MOUSEBUTTONDOWN:

				if evt.button == pygame.BUTTON_LEFT:
					for r, c in self.ui_rects:
						if r.collidepoint((mx, my)):
							if c == True: self.confirm_yes(); return
							elif c == False: self.confirm_no(); return
				if evt.button == pygame.BUTTON_RIGHT: self.confirm_no(); return

	def get_key_bind_page_count(self): return max(1, math.ceil(len(key_bind_display_order) / self.max_keybinds_per_page))

	def open_key_rebind(self):
		self.state = STATE_REBIND
		self.key_bind_page = 0
		self.examine_target = [key_bind_display_order[0], 0]
		self.rebinding = False
		self.new_key_binds = dict(self.key_binds)

	def get_keybind_letters(self, bind_key):
		primary, secondary = self.key_binds.get(bind_key, (None, None))
		if primary is not None: return format_key_name(primary)
		elif secondary is not None: return format_key_name(secondary)
		else: return ""

	def get_keybind_display_text(self, bind_id, keycode):
		key_name = format_key_name(keycode)
		return key_name

	def serialize_key_binds(self, key_binds):
		return {key_bind_save_names[bind_id]: tuple(keys) for bind_id, keys in key_binds.items() if bind_id in key_bind_save_names}

	def merge_saved_key_binds(self, saved):
		merged = dict(default_key_binds)
		if not isinstance(saved, dict): return merged

		for saved_id, entry in saved.items():
			if not isinstance(saved_id, str): continue
			bind_id = key_bind_ids_by_save_name.get(saved_id)
			if bind_id not in default_key_binds: continue
			defaults = default_key_binds[bind_id]
			if not isinstance(entry, (list, tuple)): continue
			if len(entry) != len(defaults): continue
			merged[bind_id] = tuple(entry)
		return merged

	def get_keybind_conflict_ids(self, bind_id):
		if bind_id in shop_tag_bind_ids: return shop_tag_bind_ids | shop_value_blocking_bind_ids
		if bind_id in shop_attr_bind_ids: return shop_attr_bind_ids | shop_value_blocking_bind_ids
		if bind_id in shop_value_blocking_bind_ids: return (set(default_key_binds.keys()) - shop_rebind_ids) | shop_tag_bind_ids | shop_attr_bind_ids | shop_exclusive_action_bind_ids
		return set(default_key_binds.keys()) - shop_rebind_ids

	def draw_key_rebind(self):
		cur_y = 0

		binds_per_page = self.max_keybinds_per_page
		start_idx = self.key_bind_page * binds_per_page
		end_idx = start_idx + binds_per_page

		w = self.screen.get_width()
		col_gap = w * .2
		key_col_width = 240
		table_w = col_gap * 2 + key_col_width
		col_x = (w - table_w) // 2
		col_xs = [col_x, col_x + col_gap, col_x + col_gap * 2]


		self.draw_string("FUNCTION", self.screen, col_xs[0], cur_y)
		self.draw_string("MAIN KEY", self.screen, col_xs[1], cur_y)
		self.draw_string("SECONDARY KEY", self.screen, col_xs[2], cur_y)

		cur_y += self.linesize * 2

		for bind in key_bind_display_order[start_idx:end_idx]:
			cur_x = col_xs[0]
			key_name = resolve_text(key_names[bind])
			self.draw_string(f"{key_name}:", self.screen, cur_x, cur_y, pre_resolved=True)

			key1, key2 = self.new_key_binds[bind]

			index = 0
			for k in [key1, key2]:
				cur_x = col_xs[index + 1]
				fmt = self.get_keybind_display_text(bind, k)
				content = [bind, index] if not self.rebinding else None
				cur_color = (0, 255, 0) if (self.rebinding and self.examine_target == [bind, index]) else (255, 255, 255)
				self.draw_string(fmt, self.screen, cur_x, cur_y, color=cur_color, mouse_content=content, content_width=key_col_width)
				index += 1

			cur_y += self.linesize

		cur_y += self.linesize*1


		self.draw_string("Reset to Default", self.screen, col_xs[0], cur_y, mouse_content=KEY_BIND_OPTION_RESET if not self.rebinding else None)
		self.draw_string("Done", self.screen, col_xs[2], cur_y, mouse_content=KEY_BIND_OPTION_ACCEPT if not self.rebinding else None)

		total_pages = self.get_key_bind_page_count()
		cur_page = self.key_bind_page

		if total_pages > 1:
			can_prev = cur_page > 0
			can_next = cur_page < total_pages - 1

			prev_text = "<<<<"
			next_text = ">>>>"
			label_fmt = ("Page {cur}/{total}", {"cur": cur_page + 1, "total": total_pages})
			label_text = resolve_text(label_fmt)

			cur_y += self.linesize * 2

			# prev
			cur_color = (255, 255, 255) if can_prev else HIGHLIGHT_COLOR
			self.draw_string(prev_text, self.screen, col_xs[0], cur_y,cur_color, mouse_content=(TOOLTIP_PREV if can_prev else None), pre_resolved=True)

			# page label
			self.draw_string(label_text, self.screen, col_xs[1], cur_y, pre_resolved=True)

			# next
			cur_color = (255, 255, 255) if can_next else HIGHLIGHT_COLOR
			self.draw_string(next_text, self.screen, col_xs[2], cur_y, cur_color, mouse_content=(TOOLTIP_NEXT if can_next else None), pre_resolved=True)

	def key_bind_page_adjust(self, delta):
		total = self.get_key_bind_page_count()
		new_page = max(0, min(total - 1, self.key_bind_page + delta))
		if new_page == self.key_bind_page: return False
		self.key_bind_page = new_page
		return True

	def get_keybind_rows_on_page(self):
		remaining = len(key_bind_display_order) - self.key_bind_page * self.max_keybinds_per_page
		return max(0, min(self.max_keybinds_per_page, remaining))

	def get_page_target(self, row, col):
		rows = self.get_keybind_rows_on_page()
		if rows == 0: return KEY_BIND_OPTION_RESET if col == 0 else KEY_BIND_OPTION_ACCEPT
		row = max(0, min(row, rows-1))
		start = self.key_bind_page * self.max_keybinds_per_page
		bind_id = key_bind_display_order[start + row]
		return [bind_id, min(col, 1)]

	def process_key_rebind(self):
		# If there already is a selection- keys set the selection
		if self.rebinding:
			for evt in self.events:
				if evt.type != pygame.KEYDOWN: continue
				if evt.key in self.key_binds[KEY_BIND_ABORT]: self.rebinding = False; continue
				if not isinstance(self.examine_target, list): self.rebinding = False; continue

				bind_id, slot = self.examine_target
				key = evt.key if not (evt.key == pygame.K_BACKSPACE and slot == 1) else None
				if key is not None:
					conflict_ids = self.get_keybind_conflict_ids(bind_id)
					for other_id, (k1, k2) in self.new_key_binds.items():
						if other_id == bind_id: continue
						if other_id not in conflict_ids: continue
						if k1 == key: self.new_key_binds[other_id] = (k2, None)
						elif k2 == key: self.new_key_binds[other_id] = (k1, None)

				primary, secondary = self.new_key_binds[bind_id]
				if slot == 0: primary = key
				else: secondary = key
				self.new_key_binds[bind_id] = (primary, secondary)
				self.rebinding = False
			return

		# If nothing is selected- enter sets selection, escape leaves the screen, clicks set selection, right click leaves
		else:
			for evt in self.events:
				if evt.type == pygame.KEYDOWN:
					contents = [c for (r, c) in self.ui_rects]
					if not contents: continue
					if self.examine_target not in contents: self.examine_target = contents[0]
					cur_index = contents.index(self.examine_target)

					rows_on_page = max(0, (len(contents) - 2) // 2)  # real bind rows this page

					if isinstance(self.examine_target, list):
						row, col = divmod(cur_index, 2)
					elif self.examine_target == KEY_BIND_OPTION_RESET:
						row, col = max(0, rows_on_page - 1), 0
					elif self.examine_target == KEY_BIND_OPTION_ACCEPT:
						row, col = max(0, rows_on_page - 1), 1
					else:
						row, col = max(0, rows_on_page - 1), 0

					def clamp_row(r):
						if rows_on_page == 0: return 0
						return max(0, min(r, rows_on_page - 1))

					if evt.key in self.key_binds[KEY_BIND_UP]:
						if isinstance(self.examine_target, list):
							if row == 0:
								self.examine_target = KEY_BIND_OPTION_RESET if col == 0 else KEY_BIND_OPTION_ACCEPT
								self.play_sound("menu_confirm")
							else:
								target_row = clamp_row(row - 1)
								target_idx = min(len(contents) - 3, target_row * 2 + col)
								self.examine_target = contents[target_idx]
								self.play_sound("menu_confirm")
						else:
							self.examine_target = self.get_page_target(rows_on_page - 1, col)
							self.play_sound("menu_confirm")
						continue

					if evt.key in self.key_binds[KEY_BIND_DOWN]:
						if isinstance(self.examine_target, list):
							if row < rows_on_page - 1:
								target_idx = min(len(contents) - 3, (row + 1) * 2 + col)
								self.examine_target = contents[target_idx]
								self.play_sound("menu_confirm")
							else:
								self.examine_target = KEY_BIND_OPTION_RESET if col == 0 else KEY_BIND_OPTION_ACCEPT
								self.play_sound("menu_confirm")
						else:
							# wrap to top of current page
							self.examine_target = self.get_page_target(0, col)
							self.play_sound("menu_confirm")
						continue

					if evt.key in self.key_binds[KEY_BIND_LEFT]:
						if isinstance(self.examine_target, list):
							if self.examine_target[1] == 1:
								self.examine_target[1] = 0
								self.play_sound("menu_confirm")
							elif self.key_bind_page > 0 and self.key_bind_page_adjust(-1):
								self.examine_target = self.get_page_target(row, 1)  # bottom/right of previous page
								self.play_sound("menu_confirm")
							else:
								self.play_sound("menu_abort")
						elif self.examine_target == KEY_BIND_OPTION_ACCEPT:
							self.examine_target = KEY_BIND_OPTION_RESET
							self.play_sound("menu_confirm")
						elif self.examine_target == KEY_BIND_OPTION_RESET:
							if self.key_bind_page > 0 and self.key_bind_page_adjust(-1):
								self.examine_target = KEY_BIND_OPTION_ACCEPT
								self.play_sound("menu_confirm")
							else:
								self.play_sound("menu_abort")
						else:
							self.play_sound("menu_abort")
						continue

					if evt.key in self.key_binds[KEY_BIND_RIGHT]:
						if isinstance(self.examine_target, list):
							if self.examine_target[1] == 0:
								self.examine_target[1] = 1
								self.play_sound("menu_confirm")
							elif self.key_bind_page < self.get_key_bind_page_count() - 1 and self.key_bind_page_adjust(1):
								rows_new = self.get_keybind_rows_on_page()
								self.examine_target = self.get_page_target(rows_new - 1, 0)  # last real row on next page
								self.play_sound("menu_confirm")
							else:
								self.play_sound("menu_abort")
						elif self.examine_target == KEY_BIND_OPTION_RESET:
							self.examine_target = KEY_BIND_OPTION_ACCEPT
							self.play_sound("menu_confirm")
						elif self.examine_target == KEY_BIND_OPTION_ACCEPT:
							if self.key_bind_page < self.get_key_bind_page_count() - 1 and self.key_bind_page_adjust(1):
								self.examine_target = KEY_BIND_OPTION_RESET
								self.play_sound("menu_confirm")
							else:
								self.play_sound("menu_abort")
						else:
							self.play_sound("menu_abort")
						continue

					if evt.key in self.key_binds[KEY_BIND_CONFIRM]:
						self.key_bind_select_option(self.examine_target)
					if evt.key in self.key_binds[KEY_BIND_ABORT]:
						self.key_bind_select_option(KEY_BIND_OPTION_ACCEPT)

				if evt.type == pygame.MOUSEBUTTONDOWN:
					if evt.button == pygame.BUTTON_LEFT: self.key_bind_select_option(self.examine_target)
					if evt.button == pygame.BUTTON_RIGHT: self.key_bind_select_option(KEY_BIND_OPTION_ABORT)

	def key_bind_select_option(self, option):
		if isinstance(option, list):
			self.rebinding = True
			# And the examine target is already set
		elif option == KEY_BIND_OPTION_ABORT:
			self.play_sound("menu_abort")
			self.open_options()
		elif option == KEY_BIND_OPTION_ACCEPT:
			self.play_sound("menu_confirm")
			self.key_binds = dict(self.new_key_binds)
			self.filter_tag_keys = build_tag_filter_key_cache(self.key_binds)
			self.filter_attr_keys = build_filter_key_cache(self.key_binds, binds_to_shop_attrs)
			self.save_options()
			self.open_options()
		elif option == KEY_BIND_OPTION_RESET:
			self.play_sound("menu_confirm")
			self.new_key_binds = dict(default_key_binds)
		elif option == TOOLTIP_NEXT: self.key_bind_page_adjust(1); return
		elif option == TOOLTIP_PREV: self.key_bind_page_adjust(-1); return

	def enter_reminisce(self):
		self.state = STATE_REMINISCE
		self.reminisce_folder = os.path.join('saves', str(self.game.run_number))
		self.reminisce_imgs = [os.path.join(self.reminisce_folder, f) for f in os.listdir(self.reminisce_folder) if f.endswith('.png')]

		def sort_key(fn):
			prefix = 'level_'
			postfix1 = '_begin.png'
			postfix2 = '_finish.png'

			fn = fn.split('/')[-1]
			fn = fn.split('\\')[-1]

			modifier = (1 if postfix2 in fn else 0)
			fn = fn.replace(prefix, '')
			fn = fn.replace(postfix1, '')
			fn = fn.replace(postfix2, '')

			try:
				level = int(fn)
			except:
				level = -1

			index = level * 2 + modifier
			return index

		self.reminisce_imgs = sorted(self.reminisce_imgs, key=sort_key)

		self.game = None
		self.cur_spell = None
		self.cur_spell_target = None
		self.targetable_tiles = None
		self.reminisce_index = 0

	def draw_reminisce(self):

		img_fn = self.reminisce_imgs[self.reminisce_index]

		image = pygame.image.load(img_fn)
		self.screen.blit(image, (0, 0))

	def get_max_reminisce_index(self):
		return len(self.reminisce_imgs) - 1

	def process_reminisce_input(self):

		# Left and right add or subtract
		for evt in self.events:
			if evt.type == pygame.KEYDOWN:
				if evt.key in [pygame.K_LEFT, pygame.K_DOWN, pygame.K_KP2, pygame.K_KP4]:
					self.reminisce_index -= 1
					if self.reminisce_index < 0:
						self.reminisce_index = 0
				if evt.key in [pygame.K_RIGHT, pygame.K_UP, pygame.K_KP6, pygame.K_KP8]:
					self.reminisce_index += 1
					if self.reminisce_index > self.get_max_reminisce_index():
						self.reminisce_index = self.get_max_reminisce_index()
				if evt.key in [pygame.K_SPACE, pygame.K_RETURN, pygame.K_KP_ENTER]:
					self.reminisce_index += 1
					if self.reminisce_index > self.get_max_reminisce_index():
						self.return_to_title()
				if evt.key in [pygame.K_ESCAPE]:
					self.return_to_title()

			if evt.type == pygame.MOUSEBUTTONDOWN:
				if evt.button == pygame.BUTTON_LEFT:
					self.reminisce_index += 1
					if self.reminisce_index > self.get_max_reminisce_index():
						self.return_to_title()
				if evt.button == pygame.BUTTON_RIGHT:
					self.reminisce_index -= 1
					if self.reminisce_index < 0:
						self.reminisce_index = 0

	def adjust_char_sheet_selection(self, diff, column):
		assert diff in (-1, 1)
		self.play_sound("menu_confirm")
		spells = self.game.p1.spells
		equipment = self.game.p1.equipment
		is_spell_col = column == CHAR_SHEET_SELECT_TYPE_SPELLS
		items = spells if is_spell_col else equipment
		sentinel = LEARN_SPELL_TARGET if is_spell_col else CRAFTING_TARGET

		if not items:
			self.examine_target = sentinel
			self.char_sheet_row_index = 0
			return

		if self.examine_target in items: idx = items.index(self.examine_target)
		elif self.examine_target == sentinel: idx = len(items)
		else: idx = self.char_sheet_row_index

		idx = (idx + diff) % (len(items) + 1)

		if idx == len(items): self.examine_target = sentinel
		else: self.examine_target = items[idx]

		self.char_sheet_column = column
		self.char_sheet_row_index = idx

	def toggle_char_sheet_column(self, diff):
		self.play_sound("menu_confirm")

		columns = (CHAR_SHEET_SELECT_TYPE_SPELLS, CHAR_SHEET_SELECT_TYPE_EQUIPMENT)
		cur = columns.index(self.char_sheet_column)
		self.char_sheet_column = columns[(cur + diff) % len(columns)]

		spells = self.game.p1.spells
		equipment = self.game.p1.equipment
		is_spells = self.char_sheet_column == CHAR_SHEET_SELECT_TYPE_SPELLS
		items = spells if is_spells else equipment
		sentinel = LEARN_SPELL_TARGET if is_spells else CRAFTING_TARGET
		idx = self.char_sheet_row_index

		if not items:
			self.examine_target = sentinel
			self.char_sheet_row_index = 0
			return

		idx = max(0, min(idx, len(items)))  # clamp to range

		if idx == len(items): self.examine_target = sentinel
		else: self.examine_target = items[idx]

	def adjust_list_pos(self, amt):
		t = self.examine_target
		lists = []
		if isinstance(t, Spell): lists = [self.game.p1.spells]
		elif isinstance(t, Equipment): lists = [self.game.p1.equipment, self.game.p1.buffs] # got to change position in buffs also thats where order determines how they go off
		swap_target = None
		for l in lists:
			if t not in l: return
			cur_index = l.index(t)
			if not swap_target: # first pass, spells or equipment lists
				new_index = cur_index + amt
				if new_index < 0: return 		# abort
				if new_index >= len(l): return  # conditions
				swap_target = l[new_index]
			else:
				if swap_target not in l: return # if equipment somehow isn't in the buff list, abort
				new_index = l.index(swap_target) # second pass, locate the swapped target in p1 buff list to be swapped
			l[cur_index], l[new_index] = l[new_index], l[cur_index] # swap them in their respective list
		if isinstance(t, Equipment): self.game.p1.invalidate_buff_caches() # changing order matters sometimes

	def process_char_sheet_input(self):

		keys = pygame.key.get_pressed()
		modifier_held = any(key and keys[key] for key in self.key_binds[KEY_BIND_MODIFIER])
		for evt in self.events:
			if evt.type != pygame.KEYDOWN: continue

			if evt.key in self.key_binds[KEY_BIND_DOWN]:
				if modifier_held: self.adjust_list_pos(+1) # combine these, just identify the list based off the an is_instance of the examine target type.
				else: self.adjust_char_sheet_selection(+1, self.char_sheet_column)

			elif evt.key in self.key_binds[KEY_BIND_UP]:
				if modifier_held: self.adjust_list_pos(-1)
				else: self.adjust_char_sheet_selection(-1, self.char_sheet_column)

			elif evt.key in self.key_binds[KEY_BIND_RIGHT]: self.toggle_char_sheet_column(+1)
			elif evt.key in self.key_binds[KEY_BIND_LEFT]: self.toggle_char_sheet_column(-1)

			if evt.key in self.key_binds[KEY_BIND_ABORT]:
				self.play_sound("menu_confirm")
				self.state = STATE_LEVEL

			if evt.key in self.key_binds[KEY_BIND_CONFIRM]:
				if self.examine_target == CRAFTING_TARGET: self.open_shop(SHOP_TYPE_CRAFTING)
				elif self.examine_target == LEARN_SPELL_TARGET: self.open_shop(SHOP_TYPE_SPELLS)
				elif self.examine_target in self.game.p1.spells: self.open_shop(SHOP_TYPE_SPELL_UPGRADES, self.examine_target)
				elif hasattr(self.examine_target, "prereq") and self.examine_target.prereq in self.game.p1.spells:
					self.open_shop(SHOP_TYPE_SPELL_UPGRADES, self.examine_target.prereq)

			if evt.key in self.key_binds[KEY_BIND_SPELLS]: self.open_shop(SHOP_TYPE_SPELLS)
			elif evt.key in self.key_binds[KEY_BIND_CRAFTING]: self.open_shop(SHOP_TYPE_CRAFTING)

			for bind in range(KEY_BIND_SPELL_1, KEY_BIND_SPELL_10):
				if evt.key in self.key_binds[bind]:
					index = bind - KEY_BIND_SPELL_1
					if len(self.game.p1.spells) > index: self.examine_target = self.game.p1.spells[index]

		mx, my = self.get_mouse_pos()
		for evt in self.events:
			if evt.type !=pygame.MOUSEBUTTONDOWN: continue
			if evt.button == pygame.BUTTON_LEFT:
				target = self.get_ui_target(mx, my)
				if target is None: continue
				else: self.examine_target = target
				if self.try_char_panel_menu_interaction(target): continue
				if isinstance(target, Spell): self.open_shop(SHOP_TYPE_SPELL_UPGRADES, target)
				elif isinstance(target, SpellCharacterWrapper): self.open_spell_upgrade_menu(target.spell)
				elif isinstance(target, Upgrade) and self.examine_target is not None: self.open_shop(SHOP_TYPE_SPELL_UPGRADES, target.prereq)

			if evt.button == pygame.BUTTON_RIGHT:
				self.state = STATE_LEVEL
				self.play_sound("menu_abort")

	def spell_has_filter_attr(self, spell, attr):
		if attr in spell.__dict__ and spell.__dict__[attr]: return True
		return False

	def get_options_by_name(self, options):
		by_name = {}
		for option in options:
			if option.name not in by_name:
				by_name[option.name] = option
		return by_name

	def get_catalog_with_owned_overlay(self, catalog, owned_options=()):
		owned = self.get_options_by_name(owned_options)
		if not owned: return tuple(catalog)
		return tuple(owned.get(option.name, option) for option in catalog)

	def get_shop_craft_blueprint(self, item):
		return self.shop_craft_blueprint_cache.get(item, item)

	def is_valid_shop_option(self, opt):
		if self.filter_unused and SteamAdapter.has_been_purchased(opt.name): return False
		if self.filter_unvictoried and SteamAdapter.has_been_victoried(opt.name): return False
		if self.filter_can_afford:
			if isinstance(opt, Equipment):
				if not self.game.can_craft_equipment(self.get_shop_craft_blueprint(opt)):
					return False

		if self.search_query and not self.match_query(opt, self.search_query): return False

		return True

	def has_dynamic_shop_filters(self):
		return self.filter_unused or self.filter_unvictoried or self.filter_can_afford or bool(self.search_query)

	def get_active_shop_filter_values(self):
		active = []
		for category in self.get_all_shop_filter_categories():
			active_values = self.get_shop_filter_set(category)
			if active_values is None: continue
			for value in active_values:
				active.append((category, value))
		return active

	def get_prefiltered_shop_options(self):
		filter_cache = self.shop_filter_option_cache[self.shop_type]
		active_sets = []

		for category, value in self.get_active_shop_filter_values():
			active_sets.append(filter_cache[category].get(value, set()))

		if not active_sets: return filter_cache['base']

		active_sets.sort(key=len)
		return tuple(opt for opt in filter_cache['base'] if all(opt.name in option_set for option_set in active_sets))

	def get_shop_options(self):
		cacheable = self.shop_type in [SHOP_TYPE_SPELLS, SHOP_TYPE_CRAFTING, SHOP_TYPE_COMPONENT_SELECTION, SHOP_TYPE_SPELL_UPGRADES]
		if cacheable:
			cache_key = self.get_shop_options_cache_key()
			if self.shop_options_cache and self.shop_options_cache[0] == cache_key: return self.shop_options_cache[1]

		if self.shop_type in [SHOP_TYPE_SPELLS, SHOP_TYPE_CRAFTING]:
			options = self.get_prefiltered_shop_options()
			if self.has_dynamic_shop_filters():
				options = tuple(opt for opt in options if self.is_valid_shop_option(opt))
		elif self.shop_type == SHOP_TYPE_COMPONENT_SELECTION: options = [c for c in self.game.p1.components] #  # return the player's components to be spent crafting if they match the equipment to be crafted
		elif self.shop_type == SHOP_TYPE_SPELL_UPGRADES: options = [u for u in self.shop_upgrade_spell.spell_upgrades]
		elif self.shop_type == SHOP_TYPE_SHOP and self.game.cur_level.cur_shop: options = self.game.cur_level.cur_shop.items
		elif self.shop_type == SHOP_TYPE_BESTIARY:
			if not self.search_query.strip(): options = all_monsters
			else: options = [m for m in all_monsters if self.match_bestiary_query(m, self.search_query)]
		elif self.shop_type == SHOP_TYPE_WARDROBE:
			options = wardrobe_outfits
		else: options = []
		if cacheable: self.shop_options_cache = (cache_key, options)
		return options

	def get_icon(self, item):
		image = get_image(get_asset_key(item))
		if not image: return None
		return self.extract_icon_frame(image, SPRITE_SIZE, 16)

	def extract_icon_frame(self, image, sprite_size=SPRITE_SIZE, default_cell=16):
		iw, ih = image.get_width(), image.get_height()
		if iw == sprite_size and ih == sprite_size:
			return image
		if iw >= sprite_size and ih >= sprite_size and iw % sprite_size == 0 and ih % sprite_size == 0:
			return image.subsurface((0, 0, sprite_size, sprite_size))
		if iw >= default_cell and ih >= default_cell:
			return image.subsurface((0, 0, default_cell, default_cell))
		side = max(1, min(iw, ih))
		return image.subsurface((0, 0, side, side))

	def get_deconstruction_components(self, equipment):
		cache = self.deconstruction_component_cache
		if equipment in cache: return cache[equipment]
		entries = equipment.crafting_input_fns
		if not entries: cache[equipment] = []; return cache[equipment]
		components = []
		for component, val in entries.items():
			for i in range(max(0, val)):
				components.append(component())
		cache[equipment] = components
		return components

	def draw_search_bar(self, panel, x, y, query, focused):
		search_label = resolve_text("Search:")
		label_w = cached_size(self.font, search_label)
		self.draw_string(search_label, panel, x, y, pre_resolved=True)

		inner_h = self.font.get_height()
		box_x = x + label_w
		search_bar_img = get_image(['ui', 'search_bar'])
		bar_w, bar_h = search_bar_img.get_size()
		box_center_y = y - 2 + inner_h / 2
		box_rect = pygame.Rect(box_x, int(box_center_y - bar_h / 2), bar_w, bar_h)
		panel.blit(search_bar_img, box_rect.topleft)
		if focused:
			focus_key = ('ui', 'search_bar', 'focus_overlay', bar_w, bar_h)
			focus_overlay = image_cache.get(focus_key)
			if focus_overlay is None:
				focus_overlay = pygame.Surface((bar_w, bar_h), pygame.SRCALPHA)
				focus_overlay.fill((255, 255, 255, 40))
				image_cache[focus_key] = focus_overlay
			panel.blit(focus_overlay, box_rect.topleft)
		self.make_content_rect(panel, box_rect, SEARCH_INPUT_TARGET)

		caret = "_" if focused and (pygame.time.get_ticks() // 500) % 2 == 0 else ""
		caret_y = box_rect.y + (box_rect.height - inner_h) // 2
		text_pad = 12
		text_x = box_rect.x + text_pad
		if query:
			val = query
			color = (255, 255, 255)
			self.draw_string(val + caret, panel, text_x, caret_y, color,  content_width=box_rect.width - 2*text_pad, pre_resolved=True, cache_ok=False)
		elif focused:
			val = ""
			color = (255, 255, 255)
			self.draw_string(val + caret, panel, text_x, caret_y, color, content_width=box_rect.width - 2*text_pad, pre_resolved=True)
		else:
			val = resolve_text(("({key}) or click to type", {"key": self.get_keybind_letters(KEY_BIND_QUERY)}))
			color = (150, 150, 150)
			self.draw_string(val, panel, text_x, caret_y, color, content_width=box_rect.width - 2*text_pad, pre_resolved=True)

	def draw_shop_search_bar(self, panel, x, y):
		self.draw_search_bar(panel, x, y, self.search_query, self.search_focused)

	def draw_shop_wizard(self, panel, filter_end_x, y):
		asset_name = 'wizard_crafting' if self.shop_type == SHOP_TYPE_CRAFTING else 'wizard_spellbook'
		image = get_image(['ui', asset_name])
		frame_size = image.get_height()
		frame_count = image.get_width() // frame_size
		frame = (cloud_frame_clock // SUB_FRAMES[ANIM_IDLE]) % frame_count
		x = filter_end_x + (panel.get_width() - filter_end_x - frame_size) // 2
		source_rect = pygame.Rect(frame * frame_size, 0, frame_size, frame_size)
		panel.blit(image, (x, y), source_rect)

	def draw_shop_page_controls(self, panel, x, y):
		max_shop_pages = self.get_max_shop_pages()
		if max_shop_pages <= 1: return

		can_prev = self.shop_page > 0
		can_next = self.shop_page < max_shop_pages - 1

		prev_text = "<<<<"
		next_text = ">>>>"
		label_fmt = ("Page {cur}/{total}", {"cur": self.shop_page + 1, "total": max_shop_pages})
		label_text = resolve_text(label_fmt)  # localize here to acquire width from resulting txt

		pad_w = cached_size(self.font, "   ")
		prev_w = cached_size(self.font, prev_text)
		label_w = cached_size(self.font, label_text)

		cur_color = (255, 255, 255) if can_prev else HIGHLIGHT_COLOR
		self.draw_string(prev_text, panel, x, y,cur_color, mouse_content=TOOLTIP_PREV, pre_resolved=True)
		x += prev_w + pad_w

		self.draw_string(label_text, panel, x, y, pre_resolved=True)
		x += label_w + pad_w

		cur_color = (255, 255, 255) if can_next else HIGHLIGHT_COLOR
		self.draw_string(next_text, panel, x, y, cur_color, mouse_content=TOOLTIP_NEXT, pre_resolved=True)

	def get_shop_filter_categories(self, shop_type=None):
		if shop_type is None: shop_type = self.shop_type
		return shop_filter_categories_by_type.get(shop_type, ())

	def get_all_shop_filter_categories(self, shop_type=None):
		if shop_type is None: shop_type = self.shop_type
		return self.get_shop_filter_categories(shop_type) + shop_filter_hidden_categories_by_type.get(shop_type, ())

	def add_equipment_bonus_attrs(self, item, attrs):
		attrs.update(attr for attr, val in item.global_bonuses.items() if val)
		attrs.update(attr for attr, val in item.global_bonuses_pct.items() if val)
		for bonuses in item.tag_bonuses.values():
			attrs.update(attr for attr, val in bonuses.items() if val)
		for bonuses in item.tag_bonuses_pct.values():
			attrs.update(attr for attr, val in bonuses.items() if val)
		for bonuses in item.spell_bonuses.values():
			attrs.update(attr for attr, val in bonuses.items() if val)
		for bonuses in item.spell_bonuses_pct.values():
			attrs.update(attr for attr, val in bonuses.items() if val)

	def add_spell_gain_filter_values(self, spell, tags, attrs):
		for upgrade in spell.spell_upgrades:
			if upgrade.applied: continue
			tags.update(upgrade.added_tags)
			attrs.update(attr for attr, val in upgrade.new_attributes.items() if attr in shop_filter_attrs and val)

	def refresh_search_cache_after_purchase(self, purchase, shop):
		if isinstance(shop, ShrineOfKnowledge):
			for spell in self.game.p1.spells: self.refresh_search_cache_option(spell)
		elif self.shop_type == SHOP_TYPE_SHOP and isinstance(purchase, Spell):
			self.refresh_search_cache_option(purchase)
		elif isinstance(purchase, Upgrade):
			self.refresh_search_cache_option(purchase.prereq)
		elif isinstance(purchase, Equipment):
			owned = self.get_options_by_name(self.game.p1.equipment).get(purchase.name)
			self.refresh_search_cache_option(owned if owned else purchase)

	def rebuild_shop_filter_option_cache(self, shop_type, options):
		categories = self.get_all_shop_filter_categories(shop_type)
		filter_options = {category: defaultdict(set) for category in categories}
		self.shop_filter_option_cache[shop_type] = {
			'base': options,
			**filter_options,
		}
		filter_cache = self.shop_filter_option_cache[shop_type]
		for option in options:
			tags = set(option.tags)
			tags.discard(Tags.Any)
			memberships = {SHOP_FILTER_TAGS: tags}
			if shop_type == SHOP_TYPE_SPELLS:
				gain_tags = set()
				gain_attrs = set()
				self.add_spell_gain_filter_values(option, gain_tags, gain_attrs)
				memberships[SHOP_FILTER_ATTR] = [attr for attr in shop_filter_attrs if self.spell_has_filter_attr(option, attr)]
				memberships[SHOP_FILTER_GAIN_TAGS] = gain_tags
				memberships[SHOP_FILTER_GAIN_ATTR] = gain_attrs
			elif shop_type == SHOP_TYPE_CRAFTING:
				bonus_attrs = set()
				recipe_tags = set(self.flatten_recipe(option.recipe))
				recipe_tags.discard(Tags.Any)
				self.add_equipment_bonus_attrs(option, bonus_attrs)
				memberships[SHOP_FILTER_ATTR] = [attr for attr in option.stats if attr in shop_filter_attrs]
				memberships[SHOP_FILTER_RECIPE_TAGS] = recipe_tags
				memberships[SHOP_FILTER_BONUS] = [attr for attr in bonus_attrs if attr in shop_filter_attrs]

			for category, values in memberships.items():
				for value in values:
					filter_cache[category].setdefault(value, set()).add(option.name)

	def build_spell_shop_filter_cache(self):
		if self.game: spells = self.get_catalog_with_owned_overlay(self.game.all_player_spells, self.game.p1.spells)
		else: spells = tuple(spell() for spell in all_player_spell_constructors)
		self.rebuild_shop_filter_option_cache(SHOP_TYPE_SPELLS, spells)

	def build_craft_shop_filter_cache(self):
		items = self.game.all_player_items if self.game else make_all_items()
		blueprint_items = tuple(item for item in items if item.recipe)
		owned_equipment = self.game.p1.equipment if self.game else ()
		craft_items = self.get_catalog_with_owned_overlay(blueprint_items, owned_equipment)
		self.shop_craft_blueprint_cache = {display: blueprint for display, blueprint in zip(craft_items, blueprint_items)}
		self.rebuild_shop_filter_option_cache(SHOP_TYPE_CRAFTING, craft_items)

	def get_shop_filter_values(self, category):
		if category in [SHOP_FILTER_TAGS, SHOP_FILTER_GAIN_TAGS, SHOP_FILTER_RECIPE_TAGS]: return tuple(spell_tags)
		if category in [SHOP_FILTER_ATTR, SHOP_FILTER_BONUS, SHOP_FILTER_GAIN_ATTR]: return shop_filter_attrs
		return ()

	def get_shop_filter_value_groups(self, category):
		if category in [SHOP_FILTER_ATTR, SHOP_FILTER_BONUS, SHOP_FILTER_GAIN_ATTR]:
			return (shop_filter_spell_attrs, shop_filter_minion_attrs)
		return (self.get_shop_filter_values(category),)

	def get_shop_filter_value_label(self, category, value):
		if category in [SHOP_FILTER_TAGS, SHOP_FILTER_GAIN_TAGS, SHOP_FILTER_RECIPE_TAGS]: return value.name
		return attr_label(value)

	def get_shop_filter_value_color(self, category, value):
		if category in [SHOP_FILTER_TAGS, SHOP_FILTER_GAIN_TAGS, SHOP_FILTER_RECIPE_TAGS]: return value.color.to_tup()
		if category in [SHOP_FILTER_ATTR, SHOP_FILTER_BONUS, SHOP_FILTER_GAIN_ATTR] and value in tooltip_colors: return tooltip_colors[value].to_tup()
		return (255, 255, 255)

	def get_attr_filter_key(self, attr):
		bind = shop_attr_filter_binds.get(attr)
		if bind is None: return ""
		glyph = self.get_keybind_letters(bind)
		if glyph: return glyph[0].upper()

		primary, secondary = default_key_binds[bind]
		for default in (primary, secondary):
			if default: return pygame.key.name(default)[0].upper()
		return ""

	def get_shop_filter_value_key(self, category, value):
		if category in [SHOP_FILTER_TAGS, SHOP_FILTER_GAIN_TAGS, SHOP_FILTER_RECIPE_TAGS]:
			key = self.get_filter_key(value)
			if key == '?': return ""
			return key
		if category in [SHOP_FILTER_ATTR, SHOP_FILTER_BONUS, SHOP_FILTER_GAIN_ATTR]: return self.get_attr_filter_key(value)
		return ""

	def get_shop_filter_set(self, category):
		if category == SHOP_FILTER_TAGS: return self.shop_tag_filter
		if category == SHOP_FILTER_ATTR: return self.shop_attr_filter
		if category == SHOP_FILTER_BONUS: return self.shop_bonus_filter
		if category == SHOP_FILTER_GAIN_TAGS: return self.shop_gain_tag_filter
		if category == SHOP_FILTER_GAIN_ATTR: return self.shop_gain_attr_filter
		if category == SHOP_FILTER_RECIPE_TAGS: return self.shop_recipe_tag_filter
		return None

	def is_shop_filter_value_active(self, category, value):
		active_values = self.get_shop_filter_set(category)
		return active_values is not None and value in active_values

	def is_shop_filter_value_highlighted(self, category, value):
		if self.is_shop_filter_value_active(category, value): return True
		modifier_category = self.get_shop_filter_modifier_category(category)
		return modifier_category is not None and self.is_shop_filter_value_active(modifier_category, value)

	def add_shop_filter_hotkey_description(self, desc, hotkey):
		if not hotkey: return desc
		return "{desc}\nHotkey:  {hotkey}".format(desc=desc, hotkey=hotkey)

	def get_shop_filter_category_hotkey_description(self, category):
		return self.get_keybind_letters(KEY_BIND_TAB)

	def get_shop_filter_value_base_hotkey_description(self, category, value):
		if category in [SHOP_FILTER_TAGS, SHOP_FILTER_GAIN_TAGS, SHOP_FILTER_RECIPE_TAGS]:
			bind = filters_to_binds.get(value)
			if bind is not None: return self.get_keybind_letters(bind)
			letter = ModHandler.tag_filter_letters.get(value.name)
			return letter.upper() if letter else ""
		if category in [SHOP_FILTER_ATTR, SHOP_FILTER_BONUS, SHOP_FILTER_GAIN_ATTR]:
			bind = shop_attr_filter_binds.get(value)
			if bind is not None: return self.get_keybind_letters(bind)
		return ""

	def get_shop_filter_value_hotkey_description(self, category, value):
		hotkey = self.get_shop_filter_value_base_hotkey_description(category, value)
		if category not in shop_filter_modifier_categories: return hotkey
		modifier_key = self.get_keybind_letters(KEY_BIND_MODIFIER)
		if not modifier_key or not hotkey: return ""
		return "{modifier_key} + {hotkey}".format(modifier_key=modifier_key, hotkey=hotkey)

	def get_shop_global_filter_hotkey_description(self, filter_id):
		bind = shop_global_filter_binds.get(filter_id)
		if bind is None: return ""
		return self.get_keybind_letters(bind)

	def get_shop_filter_category_description(self, category):
		if category == SHOP_FILTER_TAGS: desc = "Filter tags"
		elif category == SHOP_FILTER_ATTR: desc = "Filter attributes"
		elif category == SHOP_FILTER_BONUS: desc = "Filter attribute bonuses"
		else: desc = "Show filters"
		hotkey = self.get_shop_filter_category_hotkey_description(category)
		if hotkey: desc = "{desc}\nNext category:  {hotkey}".format(desc=desc, hotkey=hotkey)
		return desc

	def get_shop_filter_category_target(self, category):
		name = shop_filter_category_names[category]
		desc = self.get_shop_filter_category_description(category)
		return ShopFilterTarget(SHOP_FILTER_CATEGORY, category, name=name, description=desc)

	def get_shop_filter_modifier_category(self, category):
		if self.shop_type == SHOP_TYPE_SPELLS:
			if category == SHOP_FILTER_TAGS: return SHOP_FILTER_GAIN_TAGS
			if category == SHOP_FILTER_ATTR: return SHOP_FILTER_GAIN_ATTR
		if self.shop_type == SHOP_TYPE_CRAFTING:
			if category == SHOP_FILTER_TAGS: return SHOP_FILTER_RECIPE_TAGS
			if category == SHOP_FILTER_ATTR: return SHOP_FILTER_BONUS
		return None

	def get_shop_filter_value_base_description(self, category, value):
		label = self.get_shop_filter_value_label(category, value)
		if category == SHOP_FILTER_TAGS: desc = "Results with {label} tag".format(label=label)
		elif category == SHOP_FILTER_ATTR: desc = "Results with {label}".format(label=label)
		elif category == SHOP_FILTER_BONUS: desc = "Results boost {label}".format(label=label)
		elif category == SHOP_FILTER_GAIN_TAGS: desc = "Results can gain {label} tag".format(label=label)
		elif category == SHOP_FILTER_GAIN_ATTR: desc = "Results can gain {label}".format(label=label)
		elif category == SHOP_FILTER_RECIPE_TAGS: desc = "Results require {label}".format(label=label)
		else: desc = "Toggle this filter"
		return desc

	def get_shop_filter_value_description(self, category, value):
		desc = self.get_shop_filter_value_base_description(category, value)
		desc = self.add_shop_filter_hotkey_description(desc, self.get_shop_filter_value_hotkey_description(category, value))
		modifier_category = self.get_shop_filter_modifier_category(category)
		if modifier_category:
			modifier_desc = self.get_shop_filter_value_base_description(modifier_category, value)
			modifier_desc = self.add_shop_filter_hotkey_description(modifier_desc, self.get_shop_filter_value_hotkey_description(modifier_category, value))
			desc = "{desc}\n\n{modifier_desc}".format(desc=desc, modifier_desc=modifier_desc)
		if category == SHOP_FILTER_TAGS:
			mastery_line = ("\n\n[{tag_label} Mastery:{tag_key}]: [{mastery}:{tag_key}]", {"tag_label": tag_label(value), "tag_key":tag_key(value), "mastery": self.game.p1.get_mastery(value)})
			desc = [desc, mastery_line]
		return desc

	def get_shop_global_filter_description(self, filter_id):
		desc = shop_global_filter_descriptions[filter_id]
		return self.add_shop_filter_hotkey_description(desc, self.get_shop_global_filter_hotkey_description(filter_id))

	def get_shop_filter_value_target(self, category, value):
		label = self.get_shop_filter_value_label(category, value)
		name = "{cat}: {label}".format(cat=shop_filter_category_names[category], label=label)
		desc = self.get_shop_filter_value_description(category, value)
		return ShopFilterTarget(SHOP_FILTER_TOGGLE, category, value, name=name, description=desc)

	def get_shop_global_filter_target(self, filter_id):
		name = shop_global_filter_names[filter_id]
		desc = self.get_shop_global_filter_description(filter_id)
		return ShopFilterTarget(SHOP_FILTER_TOGGLE, SHOP_FILTER_GLOBAL, filter_id, name=name, description=desc)

	def is_shop_global_filter_active(self, filter_id):
		if filter_id == SHOP_FILTER_CAN_AFFORD: return self.filter_can_afford
		if filter_id == SHOP_FILTER_UNUSED: return self.filter_unused
		if filter_id == SHOP_FILTER_UNVICTORIED: return self.filter_unvictoried
		return False

	def get_shop_filter_clear_target(self, category, value):
		label = self.get_shop_filter_value_label(category, value)
		name = "{cat}: {label}".format(cat=shop_filter_category_names[category], label=label)
		desc = "Remove this filter"
		return ShopFilterTarget(SHOP_FILTER_CLEAR, category, value, name=name, description=desc)

	def get_active_shop_filter_chips(self):
		chips = []
		for category in self.get_all_shop_filter_categories():
			active_values = self.get_shop_filter_set(category)
			if active_values is None: continue
			for value in self.get_shop_filter_values(category):
				if value not in active_values: continue
				chips.append((category, value))
		return chips

	def draw_shop_active_filters(self, panel, x, y):
		chips = self.get_active_shop_filter_chips()
		if not chips: return y

		for category, value in chips:
			label = "{cat}: {label}".format(cat=shop_filter_category_names[category], label=self.get_shop_filter_value_label(category, value))
			target = self.get_shop_filter_clear_target(category, value)
			color = self.get_shop_filter_value_color(category, value)
			self.draw_string(label, panel, x, y, color, mouse_content=target, pre_resolved=True)
			y += self.linesize
		return y

	def draw_shop_global_filter(self, panel, x, y, filter_id):
		color = (255, 255, 255) if self.is_shop_global_filter_active(filter_id) else (150, 150, 150)
		target = self.get_shop_global_filter_target(filter_id)
		self.draw_string(shop_global_filter_names[filter_id], panel, x, y, color, mouse_content=target)
		return y + self.linesize

	def draw_shop_filter_title(self, panel, x, y):
		self.draw_string("Filters:", panel, x, y)
		return y + self.linesize

	def draw_shop_filter_categories(self, panel, x, y, width):
		categories = self.get_shop_filter_categories()
		if not categories: return y, x

		cur_x = x
		max_x = x + width
		pad = cached_size(self.font, "  ")
		for category in categories:
			label = resolve_text(shop_filter_category_names[category])
			active = category == self.shop_filter_category
			color = (255, 255, 255) if active else (150, 150, 150)
			label_w = cached_size(self.font, label)
			if cur_x != x and cur_x + label_w > max_x:
				cur_x = x
				y += self.linesize
			target = self.get_shop_filter_category_target(category)
			self.draw_string(label, panel, cur_x, y, color, mouse_content=target, pre_resolved=True)
			cur_x += label_w + pad
		return y + self.linesize, cur_x - pad

	def draw_shop_filter_values(self, panel, x, y):
		category = self.shop_filter_category

		for group_index, values in enumerate(self.get_shop_filter_value_groups(category)):
			if group_index and values: y += self.linesize
			for value in values:
				active = self.is_shop_filter_value_highlighted(category, value)
				value_color = self.get_shop_filter_value_color(category, value)
				base_color = value_color if active else (150, 150, 150)
				label = self.get_shop_filter_value_label(category, value)
				target = self.get_shop_filter_value_target(category, value)
				fmt_txt = value.name if category == SHOP_FILTER_TAGS else "default"
				if category in [SHOP_FILTER_ATTR, SHOP_FILTER_BONUS]: fmt_txt = attr_key(value)
				self.draw_with_hotkey(label, fmt_txt, panel, x, y, base_color, value_color, mouse_content=target, hot_key=self.get_shop_filter_value_key(category, value))
				y += self.linesize
		return y

	def draw_left_list_shop(self, title, shoptions, row_fn, draw_search=False):
		self.shop_rects = []
		self.shop_rows_per_page = max(1, self.max_shop_objects - 2)
		self.character_display.fill((0, 0, 0))
		self.middle_menu_display.fill((0, 0, 0))
		self.ui_rects = [(r, c) for r, c in self.ui_rects if r.left >= self.h_margin]

		panel = self.character_display
		name_x = self.border_margin
		cur_y = self.linesize
		content_width = panel.get_width() - 2 * self.border_margin

		self.draw_string(title, panel, name_x, cur_y, content_width=content_width)

		if draw_search:
			search_y = cur_y + self.linesize * 2
			self.draw_shop_search_bar(panel, name_x, search_y)
			cur_y = search_y + self.linesize * 2

		else: cur_y += self.linesize * 2

		if not shoptions: self.draw_string("No Results", panel, name_x, cur_y, content_width=content_width)

		rows_per_page = self.get_shop_rows_per_page()
		start_index = self.shop_page * rows_per_page
		end_index = start_index + rows_per_page

		for opt in shoptions[start_index:end_index]:
			fmt, cur_color = row_fn(opt)
			self.draw_string(fmt, panel, name_x, cur_y, cur_color, mouse_content=opt, content_width=content_width)
			cur_y += self.linesize

		cur_y = self.linesize * (self.max_shop_objects+4)
		self.draw_shop_page_controls(panel, name_x, cur_y)

	def get_unit_preview_frames(self, unit):
		asset = get_asset_key(unit)
		key = (tuple(asset), unit.radius)
		if key == self.unit_preview_key: return self.unit_preview_frames

		image = load_unit_preview_image(asset)
		frame_size = get_char_frame_size(image, unit.radius)
		columns = image.get_width() // frame_size
		row_for_idle = max(0, image.get_height() // frame_size - 1)
		frames = [
			image.subsurface((column * frame_size, row_for_idle * frame_size, frame_size, frame_size))
			for column in range(columns)
		]

		self.unit_preview_key = key
		self.unit_preview_frames = frames
		return frames

	def draw_bestiary_preview(self, monster):
		panel = self.middle_menu_display
		if not monster: return
		if not SteamAdapter.has_slain(monster.name): return
		frames = self.get_unit_preview_frames(monster)
		frame = (cloud_frame_clock // SUB_FRAMES[ANIM_IDLE]) % len(frames)
		subimage = frames[frame]
		preview_size = subimage.get_width() * 2
		scaled = pygame.transform.scale(subimage, (preview_size, preview_size))
		preview_x = panel.get_width() // 2 - preview_size // 2
		preview_y = panel.get_height() // 2 - preview_size // 2
		panel.blit(scaled, (preview_x, preview_y))
		self.draw_string(monster.name, panel, 0, preview_y + preview_size + self.linesize, center=True,  content_width=panel.get_width())

	def draw_bestiary_shop(self):
		shoptions = self.get_shop_options()

		def bestiary_row(opt):
			if SteamAdapter.has_slain(opt.name): return opt.name, (255, 255, 255)
			return "?????????????????????", UNAVAILABLE_COLOR

		title = ("Bestiary: {cur} of {total}", {"cur": SteamAdapter.get_num_slain(), "total": len(all_monsters)})
		self.draw_left_list_shop(title, shoptions, bestiary_row, draw_search=True)
		self.draw_bestiary_preview(self.examine_target if self.examine_target in shoptions else None)

		self.screen.blit(self.middle_menu_display, (self.h_margin, 0))

	def draw_shop(self):

		# Spells: show spells show filters
		# Spell Upgrades: show upgrades for spell
		# Crafting: show equipment, filters, recipe
		# Component Selection: show components and recipe boxes to be filled.
		# Bestiary: show all monsters (cannot purchase)

		if self.shop_type == SHOP_TYPE_BESTIARY: self.draw_bestiary_shop(); return
		if self.shop_type == SHOP_TYPE_WARDROBE: self.draw_wardrobe_shop(); return

		self.shop_rects = []
		self.middle_menu_display.fill((0, 0, 0))

		# Draw Shrine Background
		if self.shop_type == SHOP_TYPE_SHOP:
			cur_shop = self.get_display_level().cur_shop
			if cur_shop: self.draw_scaled_icon(cur_shop, self.middle_menu_display, 0, 0, size=self.middle_menu_width, recolor=(255, 255, 255, 90))

		# Draw Spell Background
		if self.shop_type == SHOP_TYPE_SPELL_UPGRADES:
			image = get_image(get_asset_key(self.shop_upgrade_spell))
			if image:
				big_shop = pygame.transform.scale(image, (self.middle_menu_width, self.middle_menu_display.get_height()))
				big_shop.fill((255, 255, 255, 30), special_flags=pygame.BLEND_RGBA_MULT)
				self.middle_menu_display.blit(big_shop, (0, 0))

		name_x = SPRITE_SIZE // 2
		spell_column_width = SPRITE_SIZE * 7

		level_x = SPRITE_SIZE * 7

		tag_x = SPRITE_SIZE * 8

		search_x = SPRITE_SIZE * 11

		shoptions = self.get_shop_options()

		cur_x = name_x
		cur_y = self.linesize
		row_icon_px = min(FONT_SIZE, self.linesize)
		desc_lines = 0

		if self.shop_type == SHOP_TYPE_SPELLS:
			self.draw_string("Learn Spell:", self.middle_menu_display, name_x, cur_y)
			self.draw_string("SP", self.middle_menu_display, level_x, cur_y, COLOR_XP)
			self.draw_string("Tags", self.middle_menu_display, tag_x, cur_y)

		if self.shop_type == SHOP_TYPE_CRAFTING:
			self.draw_string("Craft Equipment:", self.middle_menu_display, name_x, cur_y)
			self.draw_string("Recipe", self.middle_menu_display, tag_x, cur_y)

		if self.shop_type == SHOP_TYPE_COMPONENT_SELECTION:
			self.draw_string(("Select Components For: {e}", {"e": self.shop_craft_equipment.name}), self.middle_menu_display, name_x, cur_y)
		if self.shop_type == SHOP_TYPE_SPELL_UPGRADES:
			spell_name = resolve_text(self.shop_upgrade_spell.name)
			self.draw_string(("Upgrade {s}:", {"s":spell_name}), self.middle_menu_display, name_x, cur_y)
		if self.shop_type == SHOP_TYPE_SHOP:
			self.draw_string(self.get_display_level().cur_shop.name, self.middle_menu_display, 0, cur_y, content_width=self.middle_menu_width, center=True)
			cur_y += 2 * self.linesize
			desc_lines = self.draw_wrapped_string(self.get_display_level().cur_shop.description, self.middle_menu_display, self.border_margin, cur_y, width=self.middle_menu_width - 2 * self.border_margin, center=True, indent=False)
			cur_y += self.linesize * desc_lines
		self.shop_rows_per_page = max(1, self.max_shop_objects - (desc_lines + 2)) if self.shop_type == SHOP_TYPE_SHOP else self.max_shop_objects


		cur_y += self.linesize * 2

		if not shoptions: self.draw_string("No Results", self.middle_menu_display, cur_x, cur_y, content_width=self.middle_menu_width)


		rows_per_page = self.get_shop_rows_per_page()
		start_index = self.shop_page * rows_per_page
		end_index = start_index + rows_per_page

		for opt in shoptions[start_index:end_index]:

			cur_x = name_x
			craft_opt = self.get_shop_craft_blueprint(opt) if self.shop_type == SHOP_TYPE_CRAFTING else opt
			if self.shop_type in [SHOP_TYPE_SPELLS, SHOP_TYPE_CRAFTING, SHOP_TYPE_COMPONENT_SELECTION, SHOP_TYPE_SHOP]:
				y_icon = cur_y + (self.linesize - row_icon_px) // 2
				self.draw_scaled_icon(opt, self.middle_menu_display, cur_x, y_icon, size=row_icon_px)
				cur_x += SPRITE_SIZE // 2

			fmt = opt.name
			cur_color = (255, 255, 255)
			can_click = True

			if self.shop_type in [SHOP_TYPE_SPELLS, SHOP_TYPE_SPELL_UPGRADES]:
				cost = self.game.get_upgrade_cost(opt)
				if self.game.has_upgrade(opt): cur_color = (0, 255, 0)
				elif self.game.can_buy_upgrade(opt): cur_color = (255, 255, 255)
				else: cur_color = UNAVAILABLE_COLOR

			if self.shop_type == SHOP_TYPE_SHOP:
				if not self.game.cur_level.cur_shop.can_shop(self.game.p1, opt): cur_color = UNAVAILABLE_COLOR

			if self.shop_type == SHOP_TYPE_CRAFTING:
				if self.game.can_craft_equipment(craft_opt): cur_color = (255, 255, 255)
				elif self.game.p1.has_equipment(opt): cur_color = (0, 255, 0)
				else: cur_color = UNAVAILABLE_COLOR

			if self.shop_type == SHOP_TYPE_COMPONENT_SELECTION:
				if opt in self.shop_craft_component_ingredients: cur_color = (0, 255, 0)
				elif not any(tag in self.shop_craft_remaining_tags for tag in opt.tags) and not Tags.Any in self.shop_craft_remaining_tags:
					cur_color = UNAVAILABLE_COLOR
					can_click = False
				elif opt.is_rare: cur_color = (170, 244, 243) # on pickup halo color
				else: cur_color = (255, 255, 255)

			if self.shop_type == SHOP_TYPE_SHOP:
				width = self.middle_menu_width - cur_x - self.border_margin
				self.draw_string(fmt, self.middle_menu_display, cur_x, cur_y, cur_color, mouse_content=opt, content_width=width)
			else:
				if can_click: self.draw_string(fmt, self.middle_menu_display, cur_x, cur_y, cur_color, mouse_content=opt, content_width=spell_column_width)
				else: self.draw_string(fmt, self.middle_menu_display, cur_x, cur_y, cur_color, content_width=spell_column_width)

				if hasattr(opt, 'level') and isinstance(opt.level, int) and opt.level > 0:
					self.draw_string(str(cost), self.middle_menu_display, level_x, cur_y, cur_color, pre_resolved=True)


			# Draw the letters for the Tags next to their spell or item to be bought/crafted
			if self.shop_type in [SHOP_TYPE_SPELLS, SHOP_TYPE_COMPONENT_SELECTION]:
				tx = tag_x
				for tag in opt.tags:
					hotkey = self.get_filter_key(tag)
					self.draw_string(hotkey, self.middle_menu_display, tx, cur_y, tag.color.to_tup())
					tx += self.font.size(tag.name[0])[0]

			# draw the crafting recipe
			elif self.shop_type == SHOP_TYPE_CRAFTING:
				tx = tag_x
				missing_tags = self.game.get_missing_crafting_requirements(craft_opt)
				is_owned = (cur_color == (0, 255, 0))
				for t in self.flatten_recipe(craft_opt.recipe):
					string = self.get_filter_key(t)
					if is_owned: c = cur_color
					else:
						c = t.color.to_tup()
						if t in missing_tags:
							missing_tags.remove(t)
							c = cur_color
					self.draw_string(string, self.middle_menu_display, tx, cur_y, c)
					tx += self.font.size(string)[0]

			elif self.shop_type == SHOP_TYPE_SHOP and isinstance(self.game.cur_level.cur_shop, ReformationShop) and isinstance(opt, Equipment):
				tx = tag_x
				icon_y = cur_y + (self.linesize - row_icon_px) // 2
				for component in self.get_deconstruction_components(opt):
					icon_rect = pygame.Rect(tx, icon_y, row_icon_px, row_icon_px)
					self.make_content_rect(self.middle_menu_display, icon_rect, component)
					self.draw_scaled_icon(component, self.middle_menu_display, icon_rect.x, icon_rect.y, size=row_icon_px)
					tx += row_icon_px + 2

			cur_y += self.linesize

		if self.shop_type in [SHOP_TYPE_CRAFTING, SHOP_TYPE_SPELLS]:
			# Draw filters
			cur_x = search_x
			cur_y = self.linesize

			self.draw_shop_search_bar(self.middle_menu_display, search_x, cur_y)
			wizard_y = cur_y + self.linesize * 2

			tag_width = self.middle_menu_width - cur_x - self.border_margin

			cur_y += 2*self.linesize
			cur_y = self.draw_shop_filter_title(self.middle_menu_display, cur_x, cur_y)
			cur_y, filter_end_x = self.draw_shop_filter_categories(self.middle_menu_display, cur_x, cur_y, tag_width)
			self.draw_shop_wizard(self.middle_menu_display, filter_end_x, wizard_y)
			cur_y += self.linesize
			cur_y = self.draw_shop_filter_values(self.middle_menu_display, cur_x, cur_y)

			cur_y += self.linesize

			if self.shop_type == SHOP_TYPE_CRAFTING:
				cur_y += self.linesize
				cur_y = self.draw_shop_global_filter(self.middle_menu_display, cur_x, cur_y, SHOP_FILTER_CAN_AFFORD)

			cur_y += self.linesize
			cur_y = self.draw_shop_global_filter(self.middle_menu_display, cur_x, cur_y, SHOP_FILTER_UNUSED)

			cur_y = self.draw_shop_global_filter(self.middle_menu_display, cur_x, cur_y, SHOP_FILTER_UNVICTORIED)

			if self.get_active_shop_filter_chips():
				cur_y += 2*self.linesize
				cur_y = self.draw_shop_active_filters(self.middle_menu_display, cur_x, cur_y)

		if self.shop_type == SHOP_TYPE_COMPONENT_SELECTION:
			self.update_craft_animation()

			# Draw Required Components
			w = self.middle_menu_width
			box_size = SPRITE_SIZE
			box_margin = box_size // 2

			panel_center_x = w - (w // 4)
			cur_y = self.linesize

			equipment = self.shop_craft_equipment
			if not equipment: return

			total = sum(amount for _, amount in equipment.recipe)
			filled = total - len(self.shop_craft_remaining_tags)
			progress_ratio = min(1.0, (filled + total) / (total + total))

			# draw the item icon above the tag boxes at natural size
			icon_size = box_size
			icon_x = panel_center_x - icon_size // 2
			icon_y = cur_y
			icon_rect = pygame.Rect(icon_x, icon_y, icon_size, icon_size)
			self.make_content_rect(self.middle_menu_display, icon_rect, equipment, enable_highlight=True)
			self.draw_scaled_icon(equipment, self.middle_menu_display, icon_x, icon_y, size=icon_size, alpha=progress_ratio)

			cur_y += icon_size + box_margin

			tag_slots = []

			cur_x = panel_center_x - box_size // 2

			# Draw the different tag boxes/requirements
			for tag, amount in self.shop_craft_equipment.recipe:
				for i in range(amount):
					color = tag.color.to_tup()
					tag_image = self.get_crafting_tag_image(tag)
					box_rect = pygame.Rect(cur_x, cur_y, box_size, box_size)
					if tag_image:
						tag_w, tag_h = tag_image.get_width(), tag_image.get_height()
						dest_x = cur_x + (box_size - tag_w) // 2
						dest_y = cur_y + (box_size - tag_h) // 2
						self.middle_menu_display.blit(tag_image, (dest_x, dest_y))
					else:
						pygame.draw.rect(self.middle_menu_display, color, box_rect, 2)

					tag_letter = self.get_filter_key(tag)
					letter_width, letter_height = self.font.size(tag_letter)
					letter_x = cur_x + (box_size - letter_width) // 2
					letter_y = cur_y + (box_size - letter_height) // 2
					self.draw_string(tag_letter, self.middle_menu_display, letter_x, letter_y, color)

					tag_slots.append((tag, box_rect))

					cur_y += box_size + box_margin

			# fill the required tag boxes with the icons for the components which fulfill them
			component_tag_usage = defaultdict(set)  # component -> set of tag indexes used

			for tag, box_rect in tag_slots:
				placed = False
				for component in self.shop_craft_component_ingredients:
					# loop through each tag on the component
					for tag_index, t in enumerate(component.tags):
						if tag_index in component_tag_usage[component]:
							continue  # this tag on this component has already been used

						# Match logic
						if tag == Tags.Any or tag == t:
							# draw the component in this box
							self.make_content_rect(self.middle_menu_display, box_rect, component)

							icon = self.get_icon(component)
							if icon: self.middle_menu_display.blit(icon, box_rect.topleft)

							component_tag_usage[component].add(tag_index)
							placed = True
							break  # move to next tag box

					if placed: break

			if self.craft_animation_playing and self.craft_animation_frames:
				hold = max(1, self.craft_animation_frame_hold)
				frame_count = len(self.craft_animation_frames)
				frame_index = min(frame_count - 1, self.craft_animation_timer // hold)
				anim_frame = self.craft_animation_frames[frame_index]
				for _, box_rect in tag_slots:
					anim_x = box_rect.centerx - anim_frame.get_width() // 2
					anim_y = box_rect.centery - anim_frame.get_height() // 2
					self.middle_menu_display.blit(anim_frame, (anim_x, anim_y))

		cur_x = name_x
		cur_y = self.linesize * (self.max_shop_objects+4)
		self.draw_shop_page_controls(self.middle_menu_display, cur_x, cur_y)

		self.screen.blit(self.middle_menu_display, (self.h_margin, 0))

	def get_filter_key(self, filter_obj):
		bind = filters_to_binds.get(filter_obj)
		if bind:
			glyph = self.get_keybind_letters(bind)
			if glyph: return glyph[0].upper()

			primary, secondary = default_key_binds.get(bind, (None, None))

			for default in (primary, secondary):
				if default: return pygame.key.name(default)[0].upper()

		if isinstance(filter_obj, Tag):
			letter = ModHandler.tag_filter_letters.get(filter_obj.name)
			if letter: return letter.upper()

		return '?'

	def draw_with_hotkey(self, text, fmt_txt, surface, x, y, base_color, hot_color, mouse_content=None, content_width=None, center=False, font=None, hot_key=None):
		def draw_plain(): self.draw_string(text, surface, x, y, base_color, mouse_content=mouse_content, content_width=content_width, center=center, font=font)
		if base_color == hot_color: draw_plain(); return # the filter is active, draw the whole thing with the tag's color
		string = resolve_text(text) # translate so we know what letters it has now
		search = string.lower()
		if hot_key is None: hot_key = self.get_filter_key(mouse_content) # find out what letter we may be highlighting
		if not hot_key: draw_plain(); return # invalid mouse content somehow snuck in
		hot_idx = search.find(hot_key.lower()) # find() grabs the first instance
		if hot_idx < 0: draw_plain(); return # no hotkey in word
		resolved = f"{string[:hot_idx]}[{string[hot_idx]}:{fmt_txt}]{string[hot_idx+1:]}" # replace the hotkey with the hotkey + format text
		self.draw_string(resolved, surface, x, y, base_color, mouse_content=mouse_content, content_width=content_width, center=center, font=font, pre_resolved=True)

	def try_wishlist_interaction(self, equipment):
		if equipment not in self.game.p1.wishlist_equipment: return False
		if self.game.can_craft_equipment(equipment):
			self.open_shop(SHOP_TYPE_COMPONENT_SELECTION, equipment=equipment)
			self.play_sound('menu_confirm')
		else:
			self.game.clear_wishlist(equipment)
			self.play_sound('menu_abort')
		return True

	def try_clear_wishlist_interaction(self, equipment):
		if equipment not in self.game.p1.wishlist_equipment: return False
		self.game.clear_wishlist(equipment)
		self.play_sound('menu_abort')
		return True

	def try_char_panel_menu_interaction(self, target):
		action = self.char_panel_menu_actions.get(target)
		if action:
			action()
			return True
		if isinstance(target, Equipment): return self.try_wishlist_interaction(target)
		return False

	def interact_wishlist_slot(self, index):
		wishlist = self.game.p1.wishlist_equipment
		if len(wishlist) <= index:
			self.play_sound('menu_abort')
			return
		self.try_wishlist_interaction(wishlist[index])

	def try_wishlist_hotkey(self, evt):
		for index, bind in enumerate(range(KEY_BIND_SPELL_1, KEY_BIND_SPELL_3 + 1)):
			if evt.key not in self.key_binds[bind]: continue
			self.interact_wishlist_slot(index)
			return True
		return False

	def try_buy_shop_selection(self, prompt=True):

		if self.shop_type == SHOP_TYPE_BESTIARY: return
		to_buy = self._examine_target # Try to buy the examine target
		if self.shop_type == SHOP_TYPE_WARDROBE:
			if to_buy in wardrobe_outfits: self.apply_wardrobe_outfit(to_buy)
			return

		# code for different shop types here to intercept before normal equipment and spell purchasing behavior.
		if self.shop_type == SHOP_TYPE_SHOP:
			if not to_buy: return
			success = self.game.can_shop(to_buy)
			if not success: self.play_sound("menu_abort"); return
			cur_shop = self.game.cur_level.cur_shop
			stage = getattr(cur_shop, 'stage', 0)
			max_stage = getattr(cur_shop, 'stages', 0)
			if stage < max_stage: cur_shop.progress_stage(to_buy); self.reset_shop_page(); return
			self.open_buy_prompt(to_buy)
			if not prompt: self.confirm_buy()
			return

		# If its an owned spell, open upgrades shop for that spell
		if to_buy in self.game.p1.spells:
			self.open_spell_upgrade_menu(to_buy, return_to_spell_shop=True)
			return

		if isinstance(to_buy, Equipment):
			craft_item = self.get_shop_craft_blueprint(to_buy) if self.shop_type == SHOP_TYPE_CRAFTING else to_buy
			if not self.game.can_craft_equipment(craft_item):
				self.game.set_wishlist_equipment(craft_item)
				self.play_sound('menu_confirm') # bespoke sound here, aspirational
				return
			self.play_sound("menu_confirm") # replace with crafting specific sound?
			self.open_shop(SHOP_TYPE_COMPONENT_SELECTION, equipment=craft_item)
			self.abort_to_crafting_shop = True
			return

		if isinstance(to_buy, Component):
			if to_buy in self.shop_craft_component_ingredients:
				self.shop_craft_component_ingredients.remove(to_buy)
				self.recalculate_required_components()
				self.cancel_craft_animation()
				return

			if not self.is_valid_component(to_buy): return

			self.play_sound("place_item")
			self.shop_craft_component_ingredients.append(to_buy)
			for tag in to_buy.tags: # for each of the component tags
				if tag in self.shop_craft_remaining_tags: self.shop_craft_remaining_tags.remove(tag) # if it's part of the req, remove it from the requirement
				elif Tags.Any in self.shop_craft_remaining_tags: self.shop_craft_remaining_tags.remove(Tags.Any)

			# if you supplied the requisite tags, then confirm if you want to buy the equipment in question
			if len(self.shop_craft_remaining_tags) == 0: self.start_craft_animation()
			else: self.cancel_craft_animation()
			return

		if not to_buy: return
		success = self.game.can_shop(to_buy)
		if not success: self.play_sound("menu_abort"); return

		self.open_buy_prompt(to_buy)
		if not prompt: self.confirm_buy()

	def is_valid_component(self, component):
		if Tags.Any in self.shop_craft_remaining_tags: return True
		for t in component.tags:
			if t in self.shop_craft_remaining_tags: return True
		return False

	def recalculate_required_components(self):
		self.shop_craft_remaining_tags = self.flatten_recipe(self.shop_craft_equipment.recipe) # find out what tags are required to create the item
		for c in self.shop_craft_component_ingredients: # for each of the current set of components being used
			for t in c.tags: # for each of their tags
				if t in self.shop_craft_remaining_tags: # if that tag's in the recipe
					self.shop_craft_remaining_tags.remove(t) # remove it from the list of the required tags
				elif Tags.Any in self.shop_craft_remaining_tags:
					self.shop_craft_remaining_tags.remove(Tags.Any)

	def start_craft_animation(self):
		target = self.shop_craft_equipment
		if not target: return
		if not self.craft_animation_frames:
			self.open_buy_prompt(target)
			return
		self.play_sound("craft_item")
		self.craft_animation_playing = True
		self.craft_animation_timer = 0
		self.craft_animation_pending_equipment = target

	def cancel_craft_animation(self):
		self.craft_animation_playing = False
		self.craft_animation_timer = 0
		self.craft_animation_pending_equipment = None

	def update_craft_animation(self):
		if not self.craft_animation_playing: return
		if not self.craft_animation_frames:
			target = self.craft_animation_pending_equipment
			self.cancel_craft_animation()
			if target: self.open_buy_prompt(target)
			return
		self.craft_animation_timer += 1
		hold = max(1, self.craft_animation_frame_hold)
		if self.craft_animation_timer >= len(self.craft_animation_frames) * hold:
			target = self.craft_animation_pending_equipment
			self.cancel_craft_animation()
			if target: self.open_buy_prompt(target)

	def set_shop_filter_category(self, category):
		if category not in self.get_shop_filter_categories(): return False
		if self.shop_filter_category == category: return True
		self.shop_filter_category = category
		self.play_sound("menu_confirm")
		return True

	def cycle_shop_filter_category(self):
		categories = self.get_shop_filter_categories()
		if not categories: return False
		if self.shop_filter_category not in categories:
			return self.set_shop_filter_category(categories[0])
		index = categories.index(self.shop_filter_category)
		return self.set_shop_filter_category(categories[(index + 1) % len(categories)])

	def toggle_shop_scoped_filter(self, category, value):
		self.play_sound("menu_confirm")
		active_values = self.get_shop_filter_set(category)
		if active_values is None: return
		if value in active_values: active_values.remove(value)
		else: active_values.add(value)
		self.reset_shop_page()

	def clear_shop_scoped_filter(self, category, value):
		self.play_sound("menu_confirm")
		active_values = self.get_shop_filter_set(category)
		if active_values is None: return
		if value in active_values: active_values.remove(value)
		self.reset_shop_page()

	def handle_shop_filter_target(self, target, modifier_held=False):
		if target.action == SHOP_FILTER_CATEGORY: return self.set_shop_filter_category(target.category)
		if target.action == SHOP_FILTER_TOGGLE and target.category == SHOP_FILTER_GLOBAL: return self.toggle_shop_global_filter(target.value)
		if target.action == SHOP_FILTER_TOGGLE:
			category = self.get_shop_filter_hotkey_category(target.category, modifier_held)
			self.toggle_shop_scoped_filter(category, target.value)
			return True
		if target.action == SHOP_FILTER_CLEAR: self.clear_shop_scoped_filter(target.category, target.value); return True
		return False

	def get_shop_filter_hotkey_category(self, category, modifier_held):
		if modifier_held:
			modifier_category = self.get_shop_filter_modifier_category(category)
			if modifier_category: return modifier_category
		return category

	def try_shop_filter_value_hotkey(self, evt, modifier_held=False):
		category = self.shop_filter_category
		if category not in self.get_shop_filter_categories(): return False
		filter_category = self.get_shop_filter_hotkey_category(category, modifier_held)

		key_targets = None
		if category == SHOP_FILTER_TAGS: key_targets = self.filter_tag_keys
		elif category == SHOP_FILTER_ATTR: key_targets = self.filter_attr_keys
		if key_targets is None: return False

		values = set(self.get_shop_filter_values(filter_category))
		for value in key_targets.get(evt.key, ()):
			if value not in values: continue
			self.toggle_shop_scoped_filter(filter_category, value)
			return True
		return False

	def toggle_shop_filter(self, filter_obj):
		if isinstance(filter_obj, Tag):
			self.toggle_shop_scoped_filter(SHOP_FILTER_TAGS, filter_obj)
			return
		if isinstance(filter_obj, str): self.toggle_shop_global_filter(filter_obj)

	def toggle_shop_global_filter(self, filter_id):
		self.play_sound("menu_confirm")
		if filter_id == SHOP_FILTER_CAN_AFFORD: self.filter_can_afford = not self.filter_can_afford
		elif filter_id == SHOP_FILTER_UNUSED: self.filter_unused = not self.filter_unused
		elif filter_id == SHOP_FILTER_UNVICTORIED: self.filter_unvictoried = not self.filter_unvictoried
		else: return False
		self.reset_shop_page()
		return True

	def reset_shop_page(self):
		self.shop_page = 0
		self.shop_selection_index = 0

		old_target = self._examine_target
		new_shoptions = self.get_shop_options()
		self.examine_target = None
		if new_shoptions:
			if self.shop_type == SHOP_TYPE_COMPONENT_SELECTION:
				self.examine_target = new_shoptions[0]
				page_end = min(len(new_shoptions), self.max_shop_objects)
				idx = self.selectable_component_index_in_range(new_shoptions, 0, page_end)
				if idx is not None: self.examine_target = new_shoptions[idx]
			elif old_target in new_shoptions:
				self.examine_target = old_target
			else:
				self.examine_target = new_shoptions[0]

	def is_component_option_selectable(self, component):
		return component in self.shop_craft_component_ingredients or self.is_valid_component(component)

	def selectable_component_index_in_range(self, shoptions, start, end):
		for idx in range(start, end):
			if self.is_component_option_selectable(shoptions[idx]):
				return idx
		return None

	def find_selectable_component_index(self, shoptions, start_idx, step, start_bound, end_bound):
		if start_bound >= end_bound: return None
		if start_bound <= start_idx < end_bound and self.is_component_option_selectable(shoptions[start_idx]): return start_idx
		if step == 0: step = 1
		idx = start_idx
		while True:
			idx += step
			if idx < start_bound or idx >= end_bound: break
			if self.is_component_option_selectable(shoptions[idx]): return idx
		return self.selectable_component_index_in_range(shoptions, start_bound, end_bound)

	def get_shop_rows_per_page(self):
		return max(1, self.shop_rows_per_page)

	def get_max_shop_pages(self):
		return math.ceil(len(self.get_shop_options()) / self.get_shop_rows_per_page())

	def shop_selection_adjust(self, inc):
		# Bump examine target up by inc, roll over if it goes over the shop page
		shoptions = self.get_shop_options()
		if not shoptions: return
		self.play_sound("menu_confirm")
		rows_per_page = self.get_shop_rows_per_page()

		if self._examine_target in shoptions:
			shop_selection_index = shoptions.index(self._examine_target)

		else:
			shop_selection_index = rows_per_page * self.shop_page
			inc = 0

		page_start = self.shop_page * rows_per_page
		page_end = min(len(shoptions), page_start + rows_per_page)
		if page_end <= page_start: page_end = len(shoptions)

		shop_selection_index += inc

		page_span = page_end - page_start
		if page_span <= 0:
			page_start = 0
			page_end = len(shoptions)
			page_span = max(1, page_end - page_start)

		if shop_selection_index < page_start or shop_selection_index >= page_end:
			offset = (shop_selection_index - page_start) % page_span
			shop_selection_index = page_start + offset

		if self.shop_type == SHOP_TYPE_COMPONENT_SELECTION:
			step = 0
			if inc > 0: step = 1
			elif inc < 0: step = -1
			target_index = self.find_selectable_component_index(shoptions, shop_selection_index, step, page_start, page_end)
			if target_index is None: return
			shop_selection_index = target_index

		self.examine_target = shoptions[shop_selection_index]

	def shop_page_adjust(self, inc):
		max_shop_pages = self.get_max_shop_pages()
		if max_shop_pages < 1: return
		if max_shop_pages > 1: self.play_sound("menu_confirm")
		else: self.play_sound("menu_abort")

		old_options = self.get_shop_options()
		old_index = old_options.index(self._examine_target) if self._examine_target in old_options else None
		old_page = self.shop_page
		rows_per_page = self.get_shop_rows_per_page()

		self.shop_page = (self.shop_page + inc) % max_shop_pages
		page_start = self.shop_page * rows_per_page
		page_end = min(len(old_options), page_start + rows_per_page)
		if page_end <= page_start: page_end = len(old_options)

		offset = old_index - old_page * rows_per_page if old_index is not None else 0
		target_index = page_start + offset
		if target_index < page_start: target_index = page_start
		elif target_index >= page_end: target_index = page_end - 1

		shoptions = self.get_shop_options()
		if not shoptions: return
		target_index = max(page_start, min(len(shoptions) - 1, target_index))

		if self.shop_type == SHOP_TYPE_COMPONENT_SELECTION:
			page_end = min(len(shoptions), page_start + rows_per_page)
			idx = self.selectable_component_index_in_range(shoptions, page_start, page_end)
			if idx is None: idx = target_index
			self.examine_target = shoptions[idx]
		else:
			self.examine_target = shoptions[target_index]

	def close_shop(self):

		if self.shop_type == SHOP_TYPE_WARDROBE:
			self.state = STATE_OPTIONS
			self.examine_target = OPTION_WARDROBE
			return

		if not self.game: self.return_to_title(); return

		if self.shop_type == SHOP_TYPE_COMPONENT_SELECTION: self.clear_component_selection()

		if self.abort_to_spell_shop:
			self.play_sound("menu_abort")
			self.abort_to_spell_shop = False
			self.open_shop(SHOP_TYPE_SPELLS)
			return

		if self.abort_to_crafting_shop:
			self.play_sound("menu_abort")
			self.abort_to_crafting_shop = False
			self.open_shop(SHOP_TYPE_CRAFTING)
			return

		if self.shop_type == SHOP_TYPE_SHOP:
			cur_shop = self.game.cur_level.cur_shop
			if (self.state == STATE_SHOP and cur_shop and getattr(cur_shop, "stage", 1) > 1): # if you're in a shop with stages and not on the first stage and trying to leave
				cur_shop.regress_stage(self.game.p1) # go to the shop's previous stage
				self.reset_shop_page() # refresh the shoptions and reset the examine focus
				self.play_sound("menu_abort")
				return

		self.game.try_shop(None)
		self.clear_shop_filters() # clear filters if we're backing out to the level or the character sheet

		if self.shop_type == SHOP_TYPE_SHOP or self.prev_state == STATE_LEVEL:
			self.play_sound("menu_confirm")
			self.state = STATE_LEVEL

		elif self.shop_type != SHOP_TYPE_SHOP:
			self.open_char_sheet()
			self.examine_target = self.shop_open_examine_target


	def open_char_sheet(self):
		self.leave_shop_context()
		self.play_sound("menu_confirm")
		self.state = STATE_CHAR_SHEET
		if self.examine_target not in self.game.p1.spells + self.game.p1.equipment + [CRAFTING_TARGET, LEARN_SPELL_TARGET]:
			self.examine_target = LEARN_SPELL_TARGET

	def set_search_focus(self, focused, clear=False):
		if clear: self.search_query = ""
		if focused == self.search_focused: return
		self.search_focused = focused
		if focused: pygame.key.start_text_input()
		else: pygame.key.stop_text_input()

	def open_spell_upgrade_menu(self, spell, return_to_spell_shop=False):
		if spell not in self.game.p1.spells: return
		self.play_sound("menu_confirm")
		self.open_shop(SHOP_TYPE_SPELL_UPGRADES, spell=spell)
		self.abort_to_spell_shop = return_to_spell_shop

	def process_shop_input(self):
		keys = pygame.key.get_pressed()

		if self.search_focused:
			for evt in self.events:
				if evt.type == pygame.TEXTINPUT:
					self.search_query += evt.text
					self.reset_shop_page()

		modifier_held = any(key and keys[key] for key in self.key_binds[KEY_BIND_MODIFIER])
		list_only_shop = self.is_list_only_shop()
		wishlist_hotkeys_enabled = modifier_held and not list_only_shop

		for evt in self.events:
			if evt.type == pygame.MOUSEWHEEL:
				if self.examine_target is None:
					if evt.y > 0: self.shop_page_adjust(-1)
					elif evt.y < 0: self.shop_page_adjust(1)
					self.examine_target = None
				continue

			if evt.type != pygame.KEYDOWN: continue

			if self.search_focused:
				if evt.key in self.key_binds[KEY_BIND_CONFIRM]: self.set_search_focus(False)
				elif evt.key in self.key_binds[KEY_BIND_ABORT]: self.set_search_focus(False, clear=True)
				elif evt.key == pygame.K_BACKSPACE:
					self.search_query = self.search_query[:-1]
					if evt.key not in self.repeat_keys:
						self.repeat_keys[evt.key] = time.time() + REPEAT_DELAY
				continue

			if wishlist_hotkeys_enabled and self.try_wishlist_hotkey(evt): continue
			if evt.key in self.key_binds[KEY_BIND_QUERY] and self.shop_type != SHOP_TYPE_WARDROBE: self.set_search_focus(True); continue
			if not list_only_shop and evt.key in self.key_binds[KEY_BIND_CAN_AFFORD]: self.toggle_shop_global_filter(SHOP_FILTER_CAN_AFFORD); continue
			if not list_only_shop and evt.key in self.key_binds[KEY_BIND_TAB] and self.cycle_shop_filter_category(): continue
			if evt.key in self.key_binds[KEY_BIND_DOWN]: self.shop_selection_adjust(1); continue
			if evt.key in self.key_binds[KEY_BIND_UP]: self.shop_selection_adjust(-1); continue
			if evt.key in self.key_binds[KEY_BIND_LEFT]: self.shop_page_adjust(-1); continue
			if evt.key in self.key_binds[KEY_BIND_RIGHT]: self.shop_page_adjust(1); continue

			if not list_only_shop and self.try_shop_filter_value_hotkey(evt, modifier_held): continue

			if evt.key in self.key_binds[KEY_BIND_CONFIRM]: self.try_buy_shop_selection(prompt=True); break
			if evt.key in self.key_binds[KEY_BIND_ABORT]: self.close_shop()

			# Screenshot cheat
			if cheats_enabled and evt.key == pygame.K_v:
					to_blit = self.screen
					scale = 1
					w = to_blit.get_width() * scale
					h = to_blit.get_height() * scale
					surf = pygame.transform.scale(to_blit, (w, h))

					for i in range(100):
						path = "screencap\\ss_%d.png" % i
						if not os.path.exists(path):
							pygame.image.save(surf, path)
							break

		mouse_pos = self.get_mouse_pos()

		for click in self.events:
			if click.type != pygame.MOUSEBUTTONDOWN: continue
			if click.button == pygame.BUTTON_LEFT:

				mx, my = mouse_pos
				target = self.get_ui_target(mx, my)
				if target is None: continue

				if mx < self.h_margin and not list_only_shop: # if the mouse is over the char panel
					if self.try_char_panel_menu_interaction(target): continue
					elif self.shop_type == SHOP_TYPE_SPELLS and isinstance(target, SpellCharacterWrapper):
						self.open_spell_upgrade_menu(target.spell, return_to_spell_shop=True)
					continue

				if target == SEARCH_INPUT_TARGET: self.set_search_focus(True); continue
				else: self.set_search_focus(False)

				if target == TOOLTIP_NEXT: self.shop_page_adjust(1)
				elif target == TOOLTIP_PREV: self.shop_page_adjust(-1)
				elif target == TOOLTIP_EXIT: self.close_shop()
				elif isinstance(target, ShopFilterTarget): self.handle_shop_filter_target(target, modifier_held)
				else: self.try_buy_shop_selection(prompt=True)

			elif click.button == pygame.BUTTON_RIGHT:
				mx, my = mouse_pos
				target = self.get_ui_target(mx, my)
				if mx < self.h_margin and not list_only_shop and self.try_clear_wishlist_interaction(target): continue
				if self.search_focused: self.set_search_focus(False, clear=True); break
				self.close_shop()
				self.play_sound("menu_abort")

	def get_tile_sprite(self, tile, occupied=False):
		x = tile.x
		y = tile.y
		tileset = tile.tileset
		if tile.is_floor():
			tile_index = hash((2*x, y)) % len(self.floor_tiles[tileset])
			return self.floor_tiles[tileset][tile_index]
		if tile.is_wall():
			if tile.sprite_index is None or tile.sprite_index >= len(self.wall_tiles[tileset]):
				tile.sprite_index = random.randint(0, len(self.wall_tiles[tileset])-1)
			return self.wall_tiles[tileset][tile.sprite_index]
		if tile.is_chasm:
			base, occupied_sprite = self.chasm_sprites[tile.chasm_type]
			if occupied: return occupied_sprite
			return base

	def get_tile_image(self, tile, occupied=False):
		if tile.sprites is None: tile.sprites = [None, None]
		index = 1 if occupied else 0
		image = tile.sprites[index]
		if image is None:
			image = self.get_tile_sprite(tile, occupied=occupied)
			tile.sprites[index] = image
		return image

	def get_tile_blit(self, tile):
		image = self.get_tile_image(tile, occupied=bool(tile.unit))
		return image, (tile.x * SPRITE_SIZE, tile.y * SPRITE_SIZE)

	def draw_cached_terrain(self, level):
		if self.terrain_level is not level or self.terrain_generation != level.terrain_generation:
			tile_blits = []
			append_tile_blit = tile_blits.append
			for col in level.tiles:
				for tile in col:
					image = self.get_tile_image(tile)
					append_tile_blit((image, (tile.x * SPRITE_SIZE, tile.y * SPRITE_SIZE)))
			self.terrain_surface.blits(tile_blits, doreturn=False)
			self.terrain_level = level
			self.terrain_generation = level.terrain_generation

		self.level_display.blit(self.terrain_surface, (0, 0))

	def draw_unit(self, u):
		x = u.x * SPRITE_SIZE
		y = u.y * SPRITE_SIZE

		FLICKER_FRAMES = 18
		FLICKER_INTERVAL = 2

		has_transform_state = u.transform_asset or u.last_transform_asset or u.transform_flicker_frames

		if not has_transform_state:
			if not u.Anim: u.Anim = self.get_anim(u)
			anim = u.Anim
		else:
			target_asset = u.transform_asset
			if target_asset != u.last_transform_asset:
				prior_asset = u.prev_transform_asset if u.prev_transform_asset is not None else u.last_transform_asset
				u.prev_transform_asset = prior_asset
				u.clear_anim('Transform_Anim')
				u.clear_anim('prev_transform_anim')
				u.last_transform_asset = target_asset
				u.transform_flicker_frames = FLICKER_FRAMES if (u.prev_transform_asset is not None or target_asset is not None) else 0
				u.transform_flicker_tick = 0

			use_target = bool(target_asset)
			if u.transform_flicker_frames:
				use_target = (u.transform_flicker_tick // FLICKER_INTERVAL) % 2 == 1
				u.transform_flicker_tick += 1
				u.transform_flicker_frames -= 1
				if u.transform_flicker_frames == 0: use_target = bool(target_asset)

			asset_to_draw = target_asset if use_target else u.prev_transform_asset
			if asset_to_draw:
				if asset_to_draw == target_asset:
					if not u.Transform_Anim: u.Transform_Anim = self.get_anim(u, forced_asset=asset_to_draw)
					anim = u.Transform_Anim
				else:
					if u.prev_transform_asset != asset_to_draw: u.clear_anim('prev_transform_anim')
					if not u.prev_transform_anim:
						u.prev_transform_anim = self.get_anim(u, forced_asset=asset_to_draw)
						u.prev_transform_asset = asset_to_draw
					anim = u.prev_transform_anim
			else:
				if not u.Anim: u.Anim = self.get_anim(u)
				anim = u.Anim

		anim.draw(self.level_display)

		# Friendlyness icon # Set Manually to 3 while it doesn't have a proper size Icon
		if not u.is_player_controlled and not are_hostile(u, self.game.p1):
			scaled_key = ('friendly', 'status', 'scaled', STATUS_ICON_SIZE // 2)
			friendly_icon = image_cache.get(scaled_key)
			if friendly_icon is None:
				base_icon = get_image(['friendly'])
				scaled_px = max(1, STATUS_ICON_SIZE // 2)
				friendly_icon = pygame.transform.smoothscale(base_icon, (scaled_px, scaled_px)).convert_alpha()
				image_cache[scaled_key] = friendly_icon

			unit_origin_x = x - (SPRITE_SIZE * u.radius)
			unit_origin_y = y - (SPRITE_SIZE * u.radius)
			unit_span = SPRITE_SIZE * (1 + u.radius * 2)
			icon_margin = 5

			dest = ( unit_origin_x + unit_span - friendly_icon.get_width() - icon_margin, unit_origin_y + icon_margin)
			self.level_display.blit(friendly_icon, dest)

		# Lifebar / hp bar
		if u.cur_hp != u.max_hp:
			hp_percent = u.cur_hp / float(u.max_hp)
			full_bar = get_image(HP_BAR_ASSETS[u.radius])
			max_bar = full_bar.get_width()
			bar_h = full_bar.get_height()
			bar_pixels = max(1, min(max_bar, int(max_bar * hp_percent)))

			margin = (max_bar - bar_pixels) // 2
			lifebar_x = x - (SPRITE_SIZE * u.radius) + 1
			lifebar_y = y + SPRITE_SIZE + (SPRITE_SIZE * u.radius) - bar_h + 2
			max_y = self.level_display.get_height() - bar_h - 8 # stop from being cut off by ui-frame
			lifebar_y = min(lifebar_y, max_y)

			area = pygame.Rect(margin, 0, bar_pixels, bar_h)
			self.level_display.blit(full_bar, (lifebar_x + margin, lifebar_y), area)

		# Draw Buffs
		status_effects = u.get_visible_buffs()
		if not status_effects: return
		cycle_slots = len(status_effects) + 1
		slot = cloud_frame_clock // (STATUS_SUBFRAMES * 4) % cycle_slots
		if slot == len(status_effects): return
		b = status_effects[slot]

		unit_origin_x = x - (SPRITE_SIZE * u.radius)
		unit_origin_y = y - (SPRITE_SIZE * u.radius)
		unit_span = SPRITE_SIZE * (1 + u.radius * 2)
		buff_icon_offset = 5
		buff_x = unit_origin_x + unit_span - STATUS_ICON_SIZE - buff_icon_offset
		buff_y = unit_origin_y + unit_span - STATUS_ICON_SIZE - buff_icon_offset

		if not b.asset:
			color = b.color if b.color else Color(255, 255, 255)
			pygame.draw.rect(self.level_display, color.to_tup(), (buff_x, buff_y, 3, 3))
		else:
			image = get_image(b.asset)
			if image.get_size() == (STATUS_ICON_SIZE, STATUS_ICON_SIZE): self.level_display.blit(image, (buff_x, buff_y))
			else:
				num_frames = max(1, image.get_width() // STATUS_ICON_SIZE)
				frame_num = cloud_frame_clock // STATUS_SUBFRAMES % num_frames
				source_rect = (STATUS_ICON_SIZE * frame_num, 0, STATUS_ICON_SIZE, STATUS_ICON_SIZE)
				self.level_display.blit(image, (buff_x, buff_y), source_rect)


	def draw_cloud(self, cloud, secondary=False):
		if not cloud.asset: return
		image = get_image(cloud.asset)
		num_frames = image.get_width() // SPRITE_SIZE
		cur_frame = (cloud_frame_clock // SUB_FRAMES[ANIM_IDLE]) % num_frames
		subarea = (SPRITE_SIZE * cur_frame, 0, SPRITE_SIZE, SPRITE_SIZE)
		x = cloud.x * SPRITE_SIZE
		y = cloud.y * SPRITE_SIZE
		self.level_display.blit(image, (x, y), subarea)

	def get_component_overlay_frames(self, component):
		overlay_asset = getattr(component, 'overlay_asset', None)
		if not overlay_asset: return None

		base_asset = get_asset_key(component)
		key = (tuple(base_asset), tuple(overlay_asset))
		if key in self.component_overlay_cache: return self.component_overlay_cache[key]

		base_image = get_image(base_asset)
		overlay_image = get_image(overlay_asset)
		if base_image is None or overlay_image is None:
			self.component_overlay_cache[key] = None
			return None

		overlay_frames = slice_image_strip(overlay_image, SPRITE_SIZE, SPRITE_SIZE)
		frames = []
		for ov in overlay_frames:
			frame = ov.copy()  # overlay as background
			bx = (SPRITE_SIZE - base_image.get_width()) // 2
			by = (SPRITE_SIZE - base_image.get_height()) // 2
			frame.blit(base_image, (bx, by))  # component on top
			frames.append(frame)

		self.component_overlay_cache[key] = frames
		return frames

	def get_crafting_tag_image(self, tag):
		key = tag_key(tag)
		if key in self.crafting_tag_images: return self.crafting_tag_images[key]
		image = get_image(['UI', 'crafting ui', f'box_{key}'])
		if image is None: image = get_image(['UI', 'crafting ui', 'box_any'])
		self.crafting_tag_images[key] = image
		return image

	def draw_prop(self, p, surface=None):

		if isinstance(p, ComponentPickup):
			component = p.component
			frames = self.get_component_overlay_frames(component)
			asset_key = get_asset_key(component)
			image = frames if frames else get_image(asset_key)
			sprite_key = (tuple(asset_key), tuple(getattr(component, 'overlay_asset', []) or ()))
		else:
			image = get_image(get_asset_key(p))
			sprite_key = image

		if image is None: return

		cur_key = getattr(p, 'sprite_key', None)
		if isinstance(sprite_key, tuple): needs_new = cur_key != sprite_key
		else: needs_new = cur_key is not sprite_key
		if not hasattr(p, 'Sprite') or not p.Sprite or needs_new:
			p.sprite_key = sprite_key
			if isinstance(image, list):
				overlay_speed = SUB_FRAMES[ANIM_IDLE]
				p.Sprite = SimpleSprite(p.x, p.y, image, speed=overlay_speed, loop=True, sync=False)
			else:
				sync = False
				if isinstance(p, Portal): speed = 3
				else: sync = True; speed = 12
				p.Sprite = SimpleSprite(p.x, p.y, image, speed=speed, loop=True, sync=sync)

		p.Sprite.draw(surface or self.level_display)

	def draw_effect(self, e, batch=None):
		# SimpleSprite path appends to a shared batch list
		if hasattr(e, 'prepare_blit'):
			blit_args = e.prepare_blit()
			if not blit_args: return
			if batch is not None: batch.append(blit_args)
			else: self.level_display.blit(*blit_args)
		else:
			if batch: self.level_display.blits(batch); batch.clear()
			e.draw(self.level_display)

	def draw_border(self, points, color, hidden=None):
		points = set(points)
		for p in points:
			if hidden:
				if p in hidden: continue
			pixel_coords = Point(SPRITE_SIZE*p.x, SPRITE_SIZE*p.y)

			# Left border
			if (p.x - 1, p.y) not in points:
				rect = (p.x * SPRITE_SIZE, p.y * SPRITE_SIZE, 1, SPRITE_SIZE)
				pygame.draw.rect(self.level_display, color, rect)

			# Right Border
			if (p.x + 1, p.y) not in points:
				rect = (p.x * SPRITE_SIZE + (SPRITE_SIZE - 1), p.y * SPRITE_SIZE, 1, SPRITE_SIZE)
				pygame.draw.rect(self.level_display, color, rect)

			# Top Border
			if (p.x, p.y - 1) not in points:
				rect = (p.x * SPRITE_SIZE, p.y * SPRITE_SIZE, SPRITE_SIZE, 1)
				pygame.draw.rect(self.level_display, color, rect)

			# Bottom Border
			if (p.x, p.y + 1) not in points:
				rect = (p.x * SPRITE_SIZE, p.y * SPRITE_SIZE + (SPRITE_SIZE - 1), SPRITE_SIZE, 1)
				pygame.draw.rect(self.level_display, color, rect)

			# LR corner
			if (p.x+1, p.y+1) not in points:
				coord = (p.x * SPRITE_SIZE + (SPRITE_SIZE-1), p.y*SPRITE_SIZE + (SPRITE_SIZE-1))
				self.level_display.set_at(coord, color)

			# UR corner
			if (p.x+1, p.y-1) not in points:
				coord = (p.x * SPRITE_SIZE + (SPRITE_SIZE-1), p.y*SPRITE_SIZE)
				self.level_display.set_at(coord, color)

			# LL corner
			if (p.x-1, p.y+1) not in points:
				coord = (p.x * SPRITE_SIZE, p.y*SPRITE_SIZE + (SPRITE_SIZE-1))
				self.level_display.set_at(coord, color)

			# UL corner
			if (p.x-1, p.y-1) not in points:
				coord = (p.x * SPRITE_SIZE, p.y*SPRITE_SIZE)
				self.level_display.set_at(coord, color)

	def mask_name_for(self, pts, tx, ty):
		# adjacency
		n = (tx, ty - 1) in pts
		e = (tx + 1, ty) in pts
		s = (tx, ty + 1) in pts
		w = (tx - 1, ty) in pts

		# completely isolated: all 4 sides open
		if not (n or e or s or w):
			return 'square'

		# sides
		if not (n or e or w):
			return 'top'
		if not (s or e or w):
			return 'bottom'
		if not (w or n or s):
			return 'left'
		if not (e or n or s):
			return 'right'

		# corners
		nw = (tx - 1, ty - 1) in pts
		ne = (tx + 1, ty - 1) in pts
		sw = (tx - 1, ty + 1) in pts
		se = (tx + 1, ty + 1) in pts

		if not (n or w or nw):
			return 'top_left_corner'
		if not (n or e or ne):
			return 'top_right_corner'
		if not (s or w or sw):
			return 'bottom_left_corner'
		if not (s or e or se):
			return 'bottom_right_corner'

		return None

	def draw_targeting(self):
		S = SPRITE_SIZE

		blit = self.level_display.blit
		blits = self.level_display.blits  # for batching
		pre_green = self.pre_green
		pre_red = self.pre_red
		pre_blue = self.pre_blue
		pre_green_keep = self.pre_green_keep
		tile_green = self.tile_targetable_image
		tile_red_inrng = self.tile_invalid_target_in_range_image
		tile_blue_flat = self.tile_impacted_image

		mask_name_for = self.mask_name_for
		corners_of = lambda n: CORNERS_MAP.get(n, ())

		cx, cy = self.cur_spell_target.x, self.cur_spell_target.y
		can_cast = self.cur_spell.can_cast(cx, cy)
		show_tt = self.cur_spell.show_tt

		impacted = set()
		targetable = set()
		invalid = set()

		# Build impacted / center
		if can_cast:
			targetable.add((cx, cy))
			impacted.add((cx, cy))
			for p in self.cur_spell.get_impacted_tiles(cx, cy):
				impacted.add((p.x, p.y))
		else:
			invalid.add((cx, cy))

		# Skip green/red when show_tt is False
		if show_tt:
			for p in self.targetable_tiles:
				targetable.add((p.x, p.y))

			# in-range but invalid
			if self.cur_spell.melee:
				aoe = self.game.cur_level.get_points_in_ball(self.game.p1.x, self.game.p1.y, 1, diag=True)
			else:
				aoe = self.game.cur_level.get_points_in_ball(
					self.game.p1.x, self.game.p1.y, self.cur_spell.get_stat('range')
				)

			requires_los = self.cur_spell.get_stat('requires_los')
			for p in aoe:
				pt = (p.x, p.y)
				if pt in impacted or pt in targetable:
					continue
				if p.x == self.game.p1.x and p.y == self.game.p1.y and not self.cur_spell.can_target_self:
					continue
				if requires_los and not self.game.cur_level.can_see(self.game.p1.x, self.game.p1.y, p.x, p.y):
					continue
				invalid.add(pt)

		# Names for blue are always needed
		blue_name_by = {(tx, ty): mask_name_for(impacted, tx, ty) for (tx, ty) in impacted}

		# Batch blits for green/red
		if show_tt:
			# GREEN for targetable-only
			green_pts = (targetable - impacted)
			green_name_by = {(tx, ty): mask_name_for(targetable, tx, ty) for (tx, ty) in targetable}
			# bucket: name -> list[(surface, pos)]
			buckets = {}
			for (tx, ty) in green_pts:
				gname = green_name_by[(tx, ty)]
				img = pre_green[gname] if gname else tile_green
				buckets.setdefault(img, []).append((img, (tx * S, ty * S)))
			# one blits call per unique image
			for img, pairs in buckets.items():
				blits(pairs)

			# RED for invalid-only
			red_pts = (invalid - impacted)
			if red_pts:
				# compute names for just these points
				red_name_by = {pt: mask_name_for(invalid, pt[0], pt[1]) for pt in red_pts}
				buckets = {}
				for (tx, ty) in red_pts:
					rname = red_name_by[(tx, ty)]
					img = pre_red[rname] if rname else tile_red_inrng
					buckets.setdefault(img, []).append((img, (tx * S, ty * S)))
				for img, pairs in buckets.items():
					blits(pairs)

		# BLUE for impacted + matching green corner fill
		if show_tt:
			# we need green corner sets only if show_tt (green exists)
			green_name_by = locals().get('green_name_by', {})
			green_corners_by = {pt: set(corners_of(name)) for pt, name in green_name_by.items()}
		else:
			green_corners_by = {}

		for (tx, ty) in impacted:
			pos = (tx * S, ty * S)
			bname = blue_name_by[(tx, ty)]

			if show_tt and (tx, ty) in targetable:
				green_corners = green_corners_by.get((tx, ty), ())
				for corner in corners_of(bname):
					if corner not in green_corners:
						blit(pre_green_keep[corner], pos)

			if bname:
				blit(pre_blue[bname], pos)
			else:
				blit(tile_blue_flat, pos)

		# Center frame on top
		if can_cast and self.tile_targeted_frames:
			f = (cloud_frame_clock // 3) % len(self.tile_targeted_frames)
			blit(self.tile_targeted_frames[f], (cx * S, cy * S))
		elif not can_cast:
			blit(self.tile_invalid_target_image, (cx * S, cy * S))

	def prebake_targeting(self):
		S = SPRITE_SIZE
		names = ['square', 'top', 'bottom', 'left', 'right','top_left_corner', 'top_right_corner', 'bottom_left_corner', 'bottom_right_corner']
		base = ['UI', 'target masks']

		def make_stencils(src):
			m = pygame.mask.from_surface(src)  # opaque mask art
			cut = pygame.Surface(src.get_size(), pygame.SRCALPHA)
			m.to_surface(cut, setcolor=(255, 255, 255, 0), unsetcolor=(255, 255, 255, 255))
			keep = pygame.Surface(src.get_size(), pygame.SRCALPHA)
			m.to_surface(keep, setcolor=(255, 255, 255, 255), unsetcolor=(255, 255, 255, 0))
			return cut, keep

		# load mask art + stencils
		mask_imgs = {n: get_image(base + [n]).convert_alpha() for n in names}
		stencils = {n: make_stencils(mask_imgs[n]) for n in names}  # (cut, keep)

		green = self.tile_targetable_image
		red = self.tile_invalid_target_in_range_image
		blue = self.tile_impacted_image

		self.pre_green = {}
		self.pre_red = {}
		self.pre_blue = {}
		self.pre_green_keep = {}

		def bake_variant(base_tile, cut):
			out = base_tile.copy()
			out.blit(cut, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
			return out

		for name in names:
			cut, keep = stencils[name]
			self.pre_green[name] = bake_variant(green, cut)
			self.pre_red[name] = bake_variant(red, cut)
			self.pre_blue[name] = bake_variant(blue, cut)

			gc = pygame.Surface((S, S), pygame.SRCALPHA)
			gc.blit(green, (0, 0))
			gc.blit(keep, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
			self.pre_green_keep[name] = gc

	def add_threat(self,level,x,y):
		if x >= 0 and x < LEVEL_SIZE and y >= 0 and y < LEVEL_SIZE:
			t = level.tiles[x][y]
			if t.can_walk or t.can_fly:
				self.threat_zone.add((x,y))

	def draw_threat_borders(self):
		self.draw_border([Point(t[0], t[1]) for t in self.threat_zone], (255, 0, 0))

	def draw_threat(self):
		level = self.get_display_level()
		# Narrow to one unit maybe
		highlighted_unit = None
		mouse_point = self.get_mouse_level_point()

		if isinstance(self.examine_target, Unit) and hasattr(self.examine_target, 'x') and hasattr(self.examine_target, 'y'):
			highlighted_unit = self.examine_target

		if highlighted_unit and highlighted_unit.is_player_controlled:
			highlighted_unit = None

		if not self.threat_zone or highlighted_unit != self.last_threat_highlight:
			self.last_threat_highlight = highlighted_unit
			self.threat_zone = set()

			units = []
			possible_spells = []
			possible_buffs = []
			if not highlighted_unit:
				for u in level.units:
					if are_hostile(self.game.p1, u):
						self.threat_zone.add((u.x, u.y))
						possible_spells += u.spells
						possible_buffs += u.buffs
						units.append(u)
			else:
				units.append(highlighted_unit)
				possible_spells += highlighted_unit.spells
				possible_buffs += highlighted_unit.buffs
				self.threat_zone.add((highlighted_unit.x, highlighted_unit.y))

			spells = []
			for s in possible_spells: spells.append(s) # had weird special case for melee, but can_threaten handles melee just fine.
			spells.sort(key = lambda s: s.range, reverse = True)

			buffs = []
			for b in possible_buffs:
				# kind of bizarre but Buff.can_threaten always returns false
				# so we just have to detect those buffs with the default method
				if not b.can_threaten.__func__ == Buff.can_threaten:
					buffs.append(b)

			for t in level.iter_tiles():
				# Dont bother with walls
				if not t.can_walk and not t.can_fly: continue
				if t in self.threat_zone: continue
				for s in spells:
					if s.can_threaten(t.x, t.y):
						self.threat_zone.add((t.x, t.y))
						break
				for b in buffs:
					if b.can_threaten(t.x, t.y):
						self.threat_zone.add((t.x, t.y))
						break

		blit_area = (0, 0, SPRITE_SIZE, SPRITE_SIZE)
		to_blit = []
		image = self.hostile_los_image
		for t in self.threat_zone: to_blit.append((image, (SPRITE_SIZE * t[0], SPRITE_SIZE * t[1]), blit_area))
		self.level_display.blits(to_blit)

	def draw_threatening_enemies(self):
		level = self.get_display_level()
		p = self.deploy_target or (self.cur_spell_target if self.cur_spell else self.get_mouse_level_point() or Point(self.game.p1.x, self.game.p1.y))
		blit_area = (0, 0, SPRITE_SIZE, SPRITE_SIZE)
		image = self.hostile_los_image
		cache_key = (level.level_id, p.x, p.y)

		if cache_key != self.threatening_enemies_cache_key:
			self.threatening_enemy_points = []
			for u in level.units:
				if not are_hostile(self.game.p1, u): continue
				if not any(s.can_threaten(p.x, p.y) for s in u.spells) and not any(b.can_threaten(p.x, p.y) for b in u.buffs): continue
				for q in u.iter_occupied_points():
					self.threatening_enemy_points.append((q.x, q.y))
			self.threatening_enemies_cache_key = cache_key

		to_blit = [(image, (SPRITE_SIZE * x, SPRITE_SIZE * y), blit_area) for x, y in self.threatening_enemy_points]
		self.level_display.blits(to_blit)
		if self.tile_targeted_frames:
			frame = (cloud_frame_clock // 3) % len(self.tile_targeted_frames)
			self.level_display.blit(self.tile_targeted_frames[frame], (p.x * SPRITE_SIZE, p.y * SPRITE_SIZE))

	def draw_los_borders(self):
		self.draw_border(self.los_tiles, (255, 255, 255))

	def draw_los(self):
		global idle_frame
		blit_area = (0, 0, SPRITE_SIZE, SPRITE_SIZE)
		image = self.tile_visible_image
		level = self.get_display_level()
		p = self.deploy_target or (self.cur_spell_target if self.cur_spell else self.get_mouse_level_point() or Point(self.game.p1.x, self.game.p1.y))
		los_tiles = []
		for x in range(LEVEL_SIZE):
			for y in range(LEVEL_SIZE):
				if level.can_see(p.x, p.y, x, y):
					draw_point = (SPRITE_SIZE * x, SPRITE_SIZE * y)
					self.level_display.blit(image, draw_point, blit_area)
					los_tiles.append(Point(x, y))
		self.los_tiles = los_tiles

	def highlight_units(self, allied=True):
		blit_area = (0, 0, SPRITE_SIZE, SPRITE_SIZE)
		level = self.get_display_level()
		image = self.tile_visible_image if allied else self.hostile_los_image
		eval = are_friendly if allied else are_hostile
		for x in range(LEVEL_SIZE):
			for y in range(LEVEL_SIZE):
				u = level.get_unit_at(x, y)
				if u and eval(u, self.game.p1):
					draw_point = (SPRITE_SIZE * x, SPRITE_SIZE * y)
					self.level_display.blit(image, draw_point, blit_area)

	def highlight_objects(self):
		blit_area = (0, 0, SPRITE_SIZE, SPRITE_SIZE)
		level = self.get_display_level()
		image = self.tile_impacted_image
		for x in range(LEVEL_SIZE):
			for y in range(LEVEL_SIZE):
				p = level.tiles[x][y].prop
				if not p: continue
				self.level_display.blit(image, (SPRITE_SIZE * x, SPRITE_SIZE * y), blit_area)
				self.draw_prop(p)

	def highlight_examine_override(self, mode):
		level_point = self.cur_spell_target if self.cur_spell else self.get_mouse_level_point()
		if not level_point: return
		level = self.get_display_level()
		if not level.is_point_in_bounds(level_point): return
		tile = level.tiles[level_point.x][level_point.y]
		target = None

		if mode == 'threat':
			unit = tile.unit
			if unit: target = unit

		elif mode == 'enemies':
			unit = tile.unit
			if unit and are_hostile(unit, self.game.p1): target = unit

		elif mode == "allies":
			unit = tile.unit
			if unit and are_friendly(unit, self.game.p1): target = unit

		elif mode == "objects":
			target = tile.prop

		if target is not None: self.examine_target = target
		else: self.try_examine_tile(level_point)

	def get_max_deploy_frames(self):
		# Number of frames needed to show animation = maximum taxicab distance btw player and a corner
		return max(
			distance(self.game.p1, Point(0, 0), euclidean=False),
			distance(self.game.p1, Point(0, LEVEL_SIZE-1), euclidean=False),
			distance(self.game.p1, Point(LEVEL_SIZE-1, 0), euclidean=False),
			distance(self.game.p1, Point(LEVEL_SIZE-1, LEVEL_SIZE-1), euclidean=False)) // DEPLOY_SPEED + 1

	def draw_ui_frame(self):
		if not self.ui_frame_blits: return
		self.screen.blits(self.ui_frame_blits, doreturn=False)

	def draw_level(self):
		if self.gameover_frames >= 8: return
		level = self.get_display_level()

		#Transform and drain the levels effects
		to_remove = []
		for effect in level.effects:
			if not hasattr(effect, 'graphic'):
				graphic = self.get_effect(effect)
				if not graphic: to_remove.append(effect); continue

				graphic.level_effect = effect
				# Queue buff effects, instantly play other effects

				# Damage effects can replace damage effects
				# Buff effects queue after everything
				# Damage effects queue after buff effects

				queued_colors = [
					Tags.Buff_Apply.color,
					Tags.Debuff_Apply.color,
					Tags.Shield_Apply.color,
					Tags.Shield_Expire.color,
				]
				if hasattr(effect, 'color') and effect.color in queued_colors:
					if not self.queue_effect(graphic): to_remove.append(effect); continue
				else: self.effects.append(graphic)
				effect.graphic = graphic

		# Remove effects with no active graphic
		if to_remove:
			remove_ids = {}
			for effect in to_remove:
				effect_id = id(effect)
				remove_ids[effect_id] = remove_ids.get(effect_id, 0) + 1
			next_level_effects = []
			for effect in level.effects:
				effect_id = id(effect)
				if remove_ids.get(effect_id, 0): remove_ids[effect_id] -= 1; continue
				next_level_effects.append(effect)
			level.effects = next_level_effects

		level.effect_color_generation += 1

		# Draw the board
		self.advance_queued_effects()

		# effect_tiles = {(e.x, e.y) for e in self.effects}

		if hasattr(self.examine_target, 'level') and hasattr(self.examine_target, 'x') and hasattr(self.examine_target, 'y'):
			if isinstance(self.examine_target, Unit) and self.examine_target.cur_hp > 0:
				for b in self.examine_target.buffs:
					if hasattr(b, 'connected_unit'):
						u = b.connected_unit
						if u and u.is_alive(): self.blit_overlay(self.hostile_los_image, u.x, u.y)

				if self.examine_target.has_buff(ChannelBuff):
					b = self.examine_target.get_buff(ChannelBuff)
					for t in getattr(b.spell, "__self__", None).get_impacted_tiles(b.spell_target.x, b.spell_target.y):
						self.blit_overlay(self.tile_impacted_image, t.x, t.y)

		if isinstance(self.examine_target, Buff) and isinstance(getattr(self.examine_target, 'connected_targets', None), list) :
			for p in self.examine_target.connected_targets: # draw the overlay on the connected points
				if isinstance(p, Unit) and not p.is_alive(): continue # don't draw connected if it's to a dead unit
				self.blit_overlay(self.hostile_los_image, p.x, p.y)

		if self.game.next_level:
			self.deploy_anim_frames += 1
			self.deploy_anim_frames = min(self.deploy_anim_frames, self.get_max_deploy_frames())
		elif self.game.prev_next_level and self.deploy_anim_frames > 0:
			self.deploy_anim_frames -= 1
			if self.deploy_anim_frames == 0: self.game.prev_next_level = None

		get_tile_blit = self.get_tile_blit
		get_tile_image = self.get_tile_image
		draw_unit = self.draw_unit
		draw_prop = self.draw_prop
		draw_cloud = self.draw_cloud
		level_blits = self.level_display.blits

		def append_level_drawables(drawables, level, pred=None, occupied_chasm_blits=None):
			append_drawable = drawables.append
			append_occupied_chasm_blit = occupied_chasm_blits.append if occupied_chasm_blits is not None else None
			tiles = level.tiles

			for prop in level.props:
				if pred is not None and not pred(prop.x, prop.y): continue
				if tiles[prop.x][prop.y].unit: continue
				append_drawable((prop.x, prop.y, 0, draw_prop, prop))

			for unit in level.units:
				if pred is not None and not pred(unit.x, unit.y): continue

				if append_occupied_chasm_blit:
					if unit.radius:
						for x in range(unit.x - unit.radius, unit.x + unit.radius + 1):
							for y in range(unit.y - unit.radius, unit.y + unit.radius + 1):
								tile = tiles[x][y]
								if tile.is_chasm:
									append_occupied_chasm_blit((get_tile_image(tile, occupied=True), (x * SPRITE_SIZE, y * SPRITE_SIZE)))
					else:
						tile = tiles[unit.x][unit.y]
						if tile.is_chasm:
							append_occupied_chasm_blit((get_tile_image(tile, occupied=True), (unit.x * SPRITE_SIZE, unit.y * SPRITE_SIZE)))

				append_drawable((unit.x, unit.y, 0, draw_unit, unit))

			for cloud in level.clouds:
				if pred is not None and not pred(cloud.x, cloud.y): continue
				append_drawable((cloud.x, cloud.y, 1, draw_cloud, cloud))

		def draw_level_drawables(drawables):
			drawables.sort(key=lambda drawable: (drawable[0], drawable[1], drawable[2]))
			for _, _, _, draw_fn, drawable in drawables: draw_fn(drawable)

		if not self.deploy_anim_frames:
			level = self.game.cur_level
			self.draw_cached_terrain(level)

			drawables = []
			occupied_chasm_blits = []
			append_level_drawables(drawables, level, occupied_chasm_blits=occupied_chasm_blits)
			if occupied_chasm_blits: level_blits(occupied_chasm_blits, doreturn=False)
			draw_level_drawables(drawables)

		else: # split off extra work for deploy / transition frames
			cur_level = self.game.cur_level
			next_level = self.game.next_level or self.game.prev_next_level
			p1x = self.game.p1.x
			p1y = self.game.p1.y
			cur_radius = DEPLOY_SPEED * self.deploy_anim_frames

			def get_level(i, j):
				if abs(i-p1x) + abs(j-p1y) > cur_radius: return cur_level
				else: return next_level

			def in_next_level(x, y):
				return abs(x -p1x) + abs(y - p1y) <= cur_radius

			tile_blits = []
			append_tile_blit = tile_blits.append

			for i in range(0, LEVEL_SIZE):
				for j in range(0, LEVEL_SIZE):
					level = get_level(i, j)
					if len(level.tiles) <= i: continue
					if len(level.tiles[i]) <= j: continue
					tile = level.tiles[i][j]
					append_tile_blit(get_tile_blit(tile))

			level_blits(tile_blits, doreturn=False)

			drawables = []
			append_level_drawables(drawables, cur_level, lambda x, y: not in_next_level(x, y))
			append_level_drawables(drawables, next_level, in_next_level)
			draw_level_drawables(drawables)

		if self.examine_target and hasattr(self.examine_target, 'x') and not self.cur_spell:
			if isinstance(self.examine_target, Unit):
				img = self.hostile_los_image if are_hostile(self.examine_target, self.game.p1) else self.tile_visible_image
				for p in self.examine_target.iter_occupied_points(): self.blit_overlay(img, p.x, p.y)
			else: self.blit_overlay(self.tile_impacted_image, self.examine_target.x, self.examine_target.y)

		if self.effects:
			batched_effects = [] # Batch sprite effects to collapse multiple blits
			active_effects = []
			finished_ids = None

			for effect in self.effects:
				self.draw_effect(effect, batched_effects)
				if not effect.finished:
					active_effects.append(effect)
					continue
				if not hasattr(effect, 'level_effect'): continue

				if finished_ids is None: finished_ids = {}
				effect_id = id(effect.level_effect)
				finished_ids[effect_id] = finished_ids.get(effect_id, 0) + 1

			if batched_effects: self.level_display.blits(batched_effects)
			self.effects = active_effects

			if finished_ids:
				for effect_level in (self.game.cur_level, self.game.next_level):
					if not effect_level: continue

					remaining_level_effects = []
					for level_effect in effect_level.effects:
						effect_id = id(level_effect)
						remove_count = finished_ids.get(effect_id, 0)
						if not remove_count:
							remaining_level_effects.append(level_effect)
							continue

						if remove_count == 1: del finished_ids[effect_id]
						else: finished_ids[effect_id] = remove_count - 1

					effect_level.effects = remaining_level_effects
					if not finished_ids: break


		# Draw deploy
		if self.game.deploying and self.deploy_target:
			image = get_image(["UI", "deploy_ok_animated"]) if level.can_stand(self.deploy_target.x, self.deploy_target.y, self.game.p1) else get_image(["UI", "deploy_no_animated"])
			deploy_frames = image.get_width() // SPRITE_SIZE
			deploy_frame = (cloud_frame_clock // 3) % deploy_frames
			self.level_display.blit(image, (self.deploy_target.x * SPRITE_SIZE, self.deploy_target.y * SPRITE_SIZE), (deploy_frame * SPRITE_SIZE, 0, SPRITE_SIZE, SPRITE_SIZE))

		# Draw LOS / Targeting over everything else
		keys = pygame.key.get_pressed()
		if any(k and keys[k] for k in self.key_binds[KEY_BIND_LOS]):
			self.draw_los()
		elif any(k and keys[k] for k in self.key_binds[KEY_BIND_THREAT]) and self.game.is_awaiting_input():
			self.draw_threat()
			self.highlight_examine_override("threat")
		elif any(k and keys[k] for k in self.key_binds[KEY_BIND_THREATENERS]) and self.game.is_awaiting_input():
			self.draw_threatening_enemies()
		elif any(k and keys[k] for k in self.key_binds[KEY_BIND_HIGHLIGHT_ALLIES]) and self.game.is_awaiting_input():
			self.highlight_units()
			self.highlight_examine_override("allies")
		elif any(k and keys[k] for k in self.key_binds[KEY_BIND_HIGHLIGHT_ENEMIES]) and self.game.is_awaiting_input():
			self.highlight_units(allied=False)
			self.highlight_examine_override("enemies")
		elif any(k and keys[k] for k in self.key_binds[KEY_BIND_HIGHLIGHT_OBJECTS]) and self.game.is_awaiting_input():
			self.highlight_objects()
			self.highlight_examine_override("objects")
		elif self.cur_spell:
			self.draw_targeting()


	def blit_overlay(self, overlay, x, y):
		if overlay: self.level_display.blit(overlay, (x * SPRITE_SIZE, y * SPRITE_SIZE))

	def make_content_rect(self, surface, rel_rect, mouse_content, enable_highlight=True):
		surf_pos = self.get_surface_pos(surface)

		abs_rect = pygame.Rect(rel_rect.x + surf_pos[0], rel_rect.y + surf_pos[1], rel_rect.width, rel_rect.height)

		self.ui_rects.append((abs_rect, mouse_content))

		# If the mouse moved, and is over this text, set this mouse content as examine target
		dx, dy = self.get_mouse_rel()
		if (dx or dy) and abs_rect.collidepoint(self.mouse_pos):
			self.examine_target = mouse_content

		# If, for whatever reason, this content is the parent examine target, draw the highlight rect
		if self._examine_target == mouse_content:
			should_highlight = True
			if not enable_highlight:
				if not abs_rect.collidepoint(self.mouse_pos):
					should_highlight = False
			if should_highlight:
				pygame.draw.rect(surface, HIGHLIGHT_COLOR, rel_rect)

	def tokenize(self, txt):
		for m in TOKEN_RE.finditer(txt):
			if m.group('m_name') is not None: yield ('markup', m.group('m_name'), m.group('m_tag'), m.group('m_punc'))  # tag may be None
			else:
				k = m.lastgroup
				if k == 'word': yield ('word', m.group())
				elif k == 'punc': yield ('punc', m.group())
				elif k == 'space': yield ('space', m.group())
				else: yield ('other', m.group())

	def get_inline_asset_icon(self, alias, target_px):
		alias = alias.lower()
		asset = ["status", "32x32", alias]
		cache_key = (alias, target_px)
		if cache_key in inline_asset_icon_cache: return inline_asset_icon_cache[cache_key]

		if not has_image(asset):
			inline_asset_icon_cache[cache_key] = None
			return None

		image = get_image(asset)
		if not image:
			inline_asset_icon_cache[cache_key] = None
			return None

		if image.get_size() == (target_px, target_px): icon = image
		else: icon = pygame.transform.smoothscale(image, (target_px, target_px)).convert_alpha()
		inline_asset_icon_cache[cache_key] = icon
		return icon

	def colorize_tokens(self, tokens, base_color, font, tooltip_colors, linesize=None, cache_ok=True):
		out = []
		target_px = max(1, min(linesize or self.linesize, font.get_height()))
		for kind, *vals in tokens:
			if kind == 'markup':
				name, tag = vals[0], vals[1]
				punc = vals[2] if len(vals) > 2 else None
				name_key = name.lower()
				if name_key == "asseticon":
					icon = self.get_inline_asset_icon(tag, target_px) if tag else None
					if icon:
						out.append(("", base_color, False, icon.get_width(), icon))
						if punc:
							surf = cached_render(font, base_color, punc, cache_ok=cache_ok)
							out.append((punc, base_color, False, surf.get_width(), surf))
						continue

					draw_full = "[asseticon:%s]" % tag if tag else "[asseticon]"
					draw_full += punc or ''
					surf = cached_render(font, base_color, draw_full, cache_ok=cache_ok)
					out.append((draw_full, base_color, False, surf.get_width(), surf))
					continue

				draw = name.replace('_', ' ')
				key = tag.lower() if tag is not None else name_key
				col = (tooltip_colors.get(key) or tooltip_colors.get('default')).to_tup()
				draw_full = draw + (punc or '')
				surf = cached_render(font, col, draw_full, cache_ok=cache_ok)
				out.append((draw_full, col, False, surf.get_width(), surf))
			elif kind == 'space':
				s = vals[0]
				w = cached_size(font, s, cache_ok=cache_ok)
				out.append((s, base_color, True, w, None))
			else:
				s = vals[0]
				surf = cached_render(font, base_color, s, cache_ok=cache_ok)
				out.append((s, base_color, False, surf.get_width(), surf))
		return out

	def build_search_cache(self):
		self.search_cache.clear()
		if self.game:
			for s in self.game.all_player_spells: self.refresh_search_cache_option(s)
			for e in self.game.all_player_items: self.refresh_search_cache_option(e)
			return len(self.search_cache)
		else:
			for s in all_player_spell_constructors:
				spell = s()
				self.refresh_search_cache_option(spell)

			for e in all_equipment:
				equipment = e()
				self.refresh_search_cache_option(equipment)

	def refresh_search_cache_option(self, opt):
		self.search_cache[opt] = tuple(self.get_searchable_text(opt))

	def parse_search_query(self, q):
		if not q: return False, "", False
		final_exact = q[-1].isspace()
		raw = q.strip()
		if not raw: return False, "", False
		if raw.startswith("\\"): return True, raw[1:].strip(), final_exact
		return False, raw, final_exact

	def split_search_tokens(self, s):
		if not s: return []
		tokens = []
		buf = []
		n = len(s)
		for i, ch in enumerate(s):
			if ch.isalnum():
				buf.append(ch.casefold())
				continue
			if ch == "'" and buf:
				if i + 1 < n and s[i + 1].isalnum():
					buf.append("'")
					continue
			if buf:
				token = ''.join(buf)
				if not token.isdigit(): tokens.append(token)
				buf = []
		if buf:
			token = ''.join(buf)
			if not token.isdigit(): tokens.append(token)
		return tokens

	def get_search_tokens_from_text(self, s, fmt=None):
		if not s: return []
		terms = []
		t = resolve_text(s, fmt)
		for kind, *vals in self.tokenize(t):
			if kind == 'markup':
				name = vals[0]
				if name: terms.extend(self.split_search_tokens(name))
			elif kind == 'word':
				terms.extend(self.split_search_tokens(vals[0]))
		return terms

	def token_match(self, token, term, exact):
		if token is None: return False
		if exact: return token == term
		return token.startswith(term)

	def tokens_have_term(self, tokens, term, exact):
		for token in tokens:
			if self.token_match(token, term, exact): return True
		return False

	def tokens_have_terms(self, tokens, terms, final_exact):
		last = len(terms) - 1
		for i, term in enumerate(terms):
			if not self.tokens_have_term(tokens, term, i < last or final_exact): return False
		return True

	def tokens_have_phrase(self, tokens, terms, final_exact):
		if not terms: return True
		plen = len(terms)
		max_i = len(tokens) - plen
		for i in range(max_i + 1):
			if not self.token_match(tokens[i], terms[0], plen > 1 or final_exact): continue
			for j in range(1, plen):
				exact = j < plen - 1 or final_exact
				if not self.token_match(tokens[i + j], terms[j], exact): break
			else:
				return True
		return False

	def match_search_tokens(self, tokens, q):
		phrase_mode, raw, final_exact = self.parse_search_query(q)
		terms = self.split_search_tokens(raw)
		if phrase_mode: return self.tokens_have_phrase(tokens, terms, final_exact)
		return self.tokens_have_terms(tokens, terms, final_exact)

	def match_query(self, opt, q):
		if not q: return True

		tokens = self.search_cache.get(opt)
		if tokens is None:
			tokens = tuple(self.get_searchable_text(opt))
			self.search_cache[opt] = tokens

		return self.match_search_tokens(tokens, q)

	def match_bestiary_query(self, monster, q):
		if not q: return True
		if not SteamAdapter.has_slain(monster.name): return False

		tokens = self.bestiary_search_cache.get(monster.name)
		if tokens is None:
			tokens = tuple(self.get_bestiary_searchable_text(monster))
			self.bestiary_search_cache[monster.name] = tokens

		return self.match_search_tokens(tokens, q)

	def get_bestiary_searchable_text(self, monster):
		parts = []
		extend = parts.extend

		def add_text(s, fmt=None):
			if not s: return
			terms = self.get_search_tokens_from_text(s, fmt)
			if not terms: return
			if parts and parts[-1] is not None: parts.append(None)
			extend(terms)

		add_text(monster.name)
		for t in monster.tags: add_text(t.name)

		return parts

	# get searchable text for spells and equipment
	def get_searchable_text(self, o):
		parts = []
		extend = parts.extend

		def add_text(s, fmt=None):
			if not s: return
			terms = self.get_search_tokens_from_text(s, fmt)
			if not terms: return
			if parts and parts[-1] is not None: parts.append(None)
			extend(terms)

		if isinstance(o, Spell):
			add_text(o.name)
			add_text(o.get_description(), fmt=o.fmt_dict())
			for t in o.tags: add_text(t.name)
			for dt in o.damage_type: add_text(dt.name)
			for s in o.stats: add_text(attr_label(s))
			if o.melee: add_text(text.SPELL_MELEE_RANGE)
			if o.quick_cast: add_text(text.SPELL_QUICK_CAST)
			if o.get_stat('cool_down') > 0 or o.cool_down > 0: add_text(text.SPELL_COOLDOWN_LABEL)
			if not o.requires_los: add_text(text.SPELL_IGNORES_LOS)

			for upg in o.spell_upgrades:
				add_text(upg.name)
				add_text(upg.get_description(), fmt=upg.fmt_dict())
				for t in getattr(upg, 'added_tags', []): add_text(t.name)
				for attr, val in getattr(upg, 'new_attributes', {}).items():
					add_text(attr_label(attr))
					if attr in tt_attrs or attr == 'hp_cost':
						prereq_name = upg.prereq.name if getattr(upg, 'prereq', None) else ""
						fmt = (text.GAIN_VAL_COLORED, {"name": prereq_name, "val": val, "attr_label": format_attr(attr), "attr_key": attr_key(attr)})
						add_text(fmt)
				for attr, val in upg.global_bonuses_pct.items():
					if val >= 0: fmt = (text.ALL_GAIN_PCT, {"val": int(val), "attr_label": format_attr(attr), "attr_key": attr_key(attr)})
					else: fmt = (text.ALL_LOSE_PCT, {"val": int(val), "attr_label": format_attr(attr), "attr_key": attr_key(attr)})
					add_text(fmt)
				for attr, val in upg.global_bonuses.items():
					if val >= 0: fmt = (text.ALL_GAIN_VAL, {"val": int(val), "attr_label": format_attr(attr), "attr_key": attr_key(attr)})
					else: fmt = (text.ALL_LOSE_VAL, {"val": int(val), "attr_label": format_attr(attr), "attr_key": attr_key(attr)})
					add_text(fmt)
				for tag, bonus_map in upg.tag_bonuses_pct.items():
					for attr, val in bonus_map.items():
						fmt = (text.TAG_PCT_BONUS, {"tag_label": tag_label(tag), "tag_key": tag_key(tag), "val": int(val), "attr_label": attr_label(attr), "attr_key": attr_key(attr)})
						add_text(fmt)
				for tag, bonus_map in upg.tag_bonuses.items():
					for attr, val in bonus_map.items():
						fmt = (text.TAG_VAL_BONUS, {"tag_label": tag_label(tag), "tag_key": tag_key(tag), "val": int(val), "attr_label": attr_label(attr), "attr_key": attr_key(attr)})
						add_text(fmt)
				for spell, bonuses in upg.spell_bonuses_pct.items():
					for attr, val in bonuses.items():
						if attr in tooltip_colors: fmt = (text.GAIN_PCT_COLORED, {"name": spell().name, "val": val, "attr_label": format_attr(attr), "attr_key": attr_key(attr)})
						else: fmt = (text.GAIN_PCT_PLAIN, {"name": spell().name, "val": val, "attr_label": format_attr(attr)})
						add_text(fmt)
				for spell, bonuses in upg.spell_bonuses.items():
					for attr, val in bonuses.items():
						if attr in tooltip_colors: fmt = (text.GAIN_VAL_COLORED, {"name": spell().name, "val": val, "attr_label": format_attr(attr), "attr_key": attr_key(attr)})
						else: fmt = (text.GAIN_VAL_PLAIN, {"name": spell().name, "val": val, "attr_label": format_attr(attr)})
						add_text(fmt)
				for dtype in upg.resists:
					if upg.resists[dtype]:
						add_text(dtype.name)
						add_text('resist')
						add_text((text.RESIST_VAL, {"val": upg.resists[dtype], "tag_label": tag_label(dtype)}))

		elif isinstance(o, Equipment):
			add_text(o.name)
			add_text(o.get_description(), fmt=o.fmt_dict())
			add_text(o.get_slot_name())
			for t in o.tags: add_text(t.name)
			for tag in self.flatten_recipe(o.recipe): add_text(tag.name)
			for s in o.stats: add_text(attr_label(s))
			for attr in o.global_bonuses: add_text(attr_label(attr))
			for attr in o.global_bonuses_pct: add_text(attr_label(attr))

			for attr, val in o.global_bonuses_pct.items():
				if val >= 0: fmt = (text.ALL_GAIN_PCT, {"val": int(val), "attr_label": format_attr(attr), "attr_key": attr_key(attr)})
				else: fmt = (text.ALL_LOSE_PCT, {"val": int(val), "attr_label": format_attr(attr), "attr_key": attr_key(attr)})
				add_text(fmt)

			for attr, val in o.global_bonuses.items():
				if val >= 0: fmt = (text.ALL_GAIN_VAL, {"val": int(val), "attr_label": format_attr(attr), "attr_key": attr_key(attr)})
				else: fmt = (text.ALL_LOSE_VAL, {"val": int(val), "attr_label": format_attr(attr), "attr_key": attr_key(attr)})
				add_text(fmt)

			for tag, bonus_map in o.tag_bonuses_pct.items():
				for attr, val in bonus_map.items():
					fmt = (text.TAG_PCT_BONUS, {"tag_label": tag_label(tag), "tag_key": tag_key(tag), "val": int(val), "attr_label": attr_label(attr), "attr_key": attr_key(attr)})
					add_text(fmt)

			for tag, bonus_map in o.tag_bonuses.items():
				for attr, val in bonus_map.items():
					fmt = (text.TAG_VAL_BONUS, {"tag_label": tag_label(tag), "tag_key": tag_key(tag), "val": int(val), "attr_label": attr_label(attr), "attr_key": attr_key(attr)})
					add_text(fmt)

			for spell, bonuses in o.spell_bonuses_pct.items():
				for attr, val in bonuses.items():
					if attr in tooltip_colors: fmt = (text.GAIN_PCT_COLORED, {"name": spell().name, "val": val, "attr_label": format_attr(attr), "attr_key": attr_key(attr)})
					else: fmt = (text.GAIN_PCT_PLAIN, {"name": spell().name, "val": val, "attr_label": format_attr(attr)})
					add_text(fmt)

			for spell, bonuses in o.spell_bonuses.items():
				for attr, val in bonuses.items():
					if attr in tooltip_colors: fmt = (text.GAIN_VAL_COLORED, {"name": spell().name, "val": val, "attr_label": format_attr(attr), "attr_key": attr_key(attr)})
					else: fmt = (text.GAIN_VAL_PLAIN, {"name": spell().name, "val": val, "attr_label": format_attr(attr)})
					add_text(fmt)

			for dtype in o.resists:
				if o.resists[dtype]:
					add_text(dtype.name)
					add_text('resist')
					add_text((text.RESIST_VAL, {"val": o.resists[dtype], "tag_label": tag_label(dtype)}))

		return parts

	def get_font_metrics(self, font):
		if not hasattr(self, 'font_metrics_cache'): self.font_metrics_cache = {}
		cached = self.font_metrics_cache.get(font)
		if cached: return cached
		sample = "AgjpqyWMÅÄÖ水你"
		surf = font.render(sample, True, (0, 0, 0))
		rect = surf.get_bounding_rect()
		ink_top = rect.y
		ink_height = rect.height if rect.height > 0 else font.get_height()
		self.font_metrics_cache[font] = (ink_top, ink_height)
		return ink_top, ink_height

	def get_text_blit_y_offset(self, font, linesize):
		if not hasattr(self, 'text_blit_y_cache'): self.text_blit_y_cache = {}
		key = (cache_key_font(font), linesize)
		cached = self.text_blit_y_cache.get(key)
		if cached is not None: return cached
		ascent = font.get_ascent()
		descent = font.get_descent()  # negative in pygame
		total = ascent - descent
		pad = max(0, (linesize - total) // 2)
		offset = pad + FONT_PAD
		self.text_blit_y_cache[key] = offset
		return offset

	def draw_string(self, string, surface, x, y, color=(255, 255, 255), mouse_content=None, content_width=None, center=False, char_panel=False, font=None, fmt=None, cache_ok=True, pre_resolved=False, linesize_override=None):

		if not font: font = self.font

		linesize = linesize_override if linesize_override is not None else self.linesize
		blit_y = y + self.get_text_blit_y_offset(font, linesize)

		text = string if pre_resolved else resolve_text(string, fmt)

		use_fast = isinstance(text, str) and not has_markup(text) # checks if there are any components that are trying to be their own color via []
		if use_fast:
			line_w = cached_size(font, text, cache_ok=cache_ok)
			width = content_width if content_width else line_w
			if center:
				x = x + (width - line_w) // 2
				width = line_w

			if mouse_content is not None:
				rel_rect = pygame.Rect(x, y, width, linesize)
				self.make_content_rect(surface, rel_rect, mouse_content, enable_highlight=(not char_panel))
			surf = cached_render(font, color, text, cache_ok=cache_ok)
			surface.blit(surf, (x, blit_y))
			return 1

		tokens = self.colorize_tokens(self.tokenize(text), color, font, tooltip_colors, linesize, cache_ok=cache_ok)
		total_w = sum(w for _, _, _, w, _ in tokens)
		width = content_width if content_width else total_w
		if center: x = x + (width - total_w) // 2

		if mouse_content is not None:
			rel_rect = pygame.Rect(x, y, width, linesize)
			self.make_content_rect(surface, rel_rect, mouse_content, enable_highlight=(not char_panel))

		cx = x
		for draw_text, col, is_space, w, surf in tokens:
			if not is_space:
				if surf is None: surf = font.render(draw_text, True, col)
				surface.blit(surf, (cx, blit_y))
			cx += w
		return 1

	def draw_wrapped_string(self, string, surface, x, y, width, color=(255, 255, 255), center=False, indent=True, extra_space=False, fmt=None, pre_resolved=False, font=None, linesize_override=None, bottom_y=None, cache_ok=True):
		font = font or self.font
		linesize = linesize_override if linesize_override is not None else self.linesize
		num_lines = 0
		text = string if pre_resolved else resolve_text(string, fmt)
		space_px = cached_size(font, ' ', cache_ok=cache_ok)
		blit_y_offset = self.get_text_blit_y_offset(font, linesize)

		def flush_draw_line(chunks, base_x, base_y):
			if not chunks: return
			total_px = sum(px for _, _, _, px, _ in chunks)
			start_x = base_x
			if center and total_px < width: start_x = base_x + (width - total_px) // 2
			cx = start_x
			for draw, col, is_space, px, surf in chunks:
				if not is_space:
					blit_y = base_y + blit_y_offset
					if surf is None: surf = font.render(draw, True, col)
					surface.blit(surf, (cx, blit_y))
				cx += px

		if bottom_y is not None:
			prepared_lines = []
			for paragraph in text.split('\n'):
				if paragraph == '':
					prepared_lines.append(None)
					num_lines += 1
					if extra_space:
						prepared_lines.append(None)
						num_lines += 1
					continue

				colored = self.colorize_tokens(self.tokenize(paragraph), color, font, tooltip_colors, linesize, cache_ok=cache_ok)
				cur_x = x
				line_chunks = []
				first_line = True

				for draw, col, is_space, px, surf in colored:
					if not line_chunks and is_space:
						continue
					avail = x + width - cur_x
					if px > avail and line_chunks:
						prepared_lines.append((x + (space_px if (not first_line and indent) else 0), line_chunks))
						num_lines += 1
						first_line = False
						line_chunks = []
						cur_x = x + (space_px if indent else 0)
						if is_space: continue
					line_chunks.append((draw, col, is_space, px, surf))
					cur_x += px

				if line_chunks:
					prepared_lines.append((x + (space_px if (not first_line and indent) else 0), line_chunks))
					num_lines += 1

				if extra_space:
					prepared_lines.append(None)
					num_lines += 1

			cur_y = bottom_y - linesize * (num_lines - 1)
			for line in prepared_lines:
				if line is not None:
					base_x, chunks = line
					flush_draw_line(chunks, base_x, cur_y)
				cur_y += linesize
			return num_lines

		cur_y = y
		# Process each \n-separated paragraph line
		for paragraph in text.split('\n'):
			if paragraph == '':
				num_lines += 1
				cur_y += linesize
				if extra_space:
					num_lines += 1
					cur_y += linesize
				continue

			# NEW: tokenize + colorize once for the paragraph
			colored = self.colorize_tokens(self.tokenize(paragraph), color, font, tooltip_colors, linesize, cache_ok=cache_ok)

			cur_x = x
			line_chunks = []  # list of prepared chunks for this visual line
			first_line = True

			for draw, col, is_space, px, surf in colored:
				if not line_chunks and is_space:
					continue
				avail = x + width - cur_x
				if px > avail and line_chunks:
					flush_draw_line(line_chunks, x + (space_px if (not first_line and indent) else 0), cur_y)
					num_lines += 1
					cur_y += linesize
					first_line = False
					line_chunks = []
					cur_x = x + (space_px if indent else 0)
					if is_space:
						continue
				line_chunks.append((draw, col, is_space, px, surf))
				cur_x += px

			if line_chunks:
				flush_draw_line(line_chunks, x + (space_px if (not first_line and indent) else 0), cur_y)
				num_lines += 1
				cur_y += linesize

			if extra_space:
				num_lines += 1
				cur_y += linesize

		return num_lines

	def get_ui_target(self, x, y):
		for r, c in self.ui_rects:
			if r.collidepoint((x, y)): return c
		return None

	def process_click_character(self, button, x, y):

		target = self.get_ui_target(x, y)
		if target is None: return
		if button == pygame.BUTTON_RIGHT:
			if isinstance(target, Equipment) and self.try_clear_wishlist_interaction(target): return
			elif isinstance(target, SpellCharacterWrapper) and not self.cur_spell:
				self.open_shop(SHOP_TYPE_SPELL_UPGRADES, target.spell)
				return
		if button != pygame.BUTTON_LEFT: return

		if self.try_char_panel_menu_interaction(target): return
		elif isinstance(target, SpellCharacterWrapper):
			self.choose_spell(target.spell)


	def draw_fail_overlay_on_center(self, alpha=140):
		w, h = self.middle_menu_display.get_size()
		self.draw_fail_overlay(
			self.screen,
			rect=(self.h_margin, 0, w, h),
			thickness=6,
			color=(255, 60, 60),
			alpha=alpha
		)

	def draw_fail_overlay(self, surface, rect=None, thickness=6, color=(255, 60, 60), alpha=140):
		if rect is None:
			x, y, w, h = 0, 0, surface.get_width(), surface.get_height()
		else:
			x, y, w, h = rect
		overlay = pygame.Surface((w, h), pygame.SRCALPHA)
		pygame.draw.rect(overlay, (*color, alpha), (0, 0, w, thickness))  # top
		pygame.draw.rect(overlay, (*color, alpha), (0, h - thickness, w, thickness))  # bottom
		pygame.draw.rect(overlay, (*color, alpha), (0, 0, thickness, h))  # left
		pygame.draw.rect(overlay, (*color, alpha), (w - thickness, 0, thickness, h))  # right
		surface.blit(overlay, (x, y))

	def draw_scaled_icon(self, obj, surface, x, y, size=None, default_cell=16, recolor=None, alpha=None):
		target_px = size or FONT_SIZE
		alpha_val = None if alpha is None else (int(alpha * 255) if alpha <= 1 else int(alpha))
		if alpha_val is not None: alpha_val = max(0, min(255, alpha_val))

		asset = get_asset_key(obj)
		if not asset: return

		# cache key should include a stable asset id and the target size
		cache_key = (tuple(asset) if isinstance(asset, list) else str(asset), target_px, recolor, alpha_val)
		icon = scaled_icon_cache.get(cache_key)
		if icon is None:
			if recolor is None and alpha_val is None:
				icon = get_atlas_icon(asset, target_px)
			if icon is None:
				image = get_image(asset)
				if not image: return
				base = self.extract_icon_frame(image, SPRITE_SIZE, default_cell)
				icon = pygame.transform.smoothscale(base, (target_px, target_px)).convert_alpha()
				if recolor: icon.fill(recolor, special_flags=pygame.BLEND_RGBA_MULT)
				if alpha_val is not None: icon.set_alpha(alpha_val)
			scaled_icon_cache[cache_key] = icon

		surface.blit(icon, (x, y))

	def get_examine_text_width(self, cur_y, has_icon=True):
		full_width = self.examine_display.get_width() - 2 * self.border_margin
		if has_icon and cur_y < self.examine_icon_y + self.examine_icon_size:
			return self.examine_icon_x - self.border_margin
		return full_width

	def get_white_flash_icon(self, icon_surface):
		# fast white overlay: copy scaled icon and max-fill RGB, keep alpha intact
		overlay = icon_surface.copy()
		overlay.fill((255, 255, 255), special_flags=pygame.BLEND_RGB_MAX)
		return overlay

	def get_flash_overlay(self, asset, target_px, default_cell=16, recolor=None, alpha=None):
		alpha_val = None if alpha is None else (int(alpha * 255) if alpha <= 1 else int(alpha))
		if alpha_val is not None: alpha_val = max(0, min(255, alpha_val))
		cache_key = (tuple(asset) if isinstance(asset, list) else str(asset), target_px, recolor, alpha_val)
		overlay = recolored_icon_cache.get(cache_key)
		if overlay is not None: return overlay

		image = get_image(asset)
		if not image: return None
		base = self.extract_icon_frame(image, SPRITE_SIZE, default_cell)
		icon = pygame.transform.smoothscale(base, (target_px, target_px)).convert_alpha()
		if alpha_val is not None: icon.set_alpha(alpha_val)
		overlay = self.get_white_flash_icon(icon)
		if recolor: overlay.fill(recolor, special_flags=pygame.BLEND_RGBA_MULT)
		recolored_icon_cache[cache_key] = overlay
		return overlay

	def format_chronomancer_time(self, time_left_ds):
		minutes = time_left_ds // 600
		seconds = (time_left_ds // 10) % 60
		deciseconds = time_left_ds % 10
		return f"{minutes:02d}:{seconds:02d}.{deciseconds}"

	def draw_character(self):
		self.character_display.fill((0, 0, 0))
		self.char_panel_examine_lines = {}

		game = self.game
		player = game.p1
		panel = self.character_display
		margin = self.border_margin

		# shrink_text applies a per-panel font variant without touching the global font
		shrink_level = getattr(player, 'shrink_text', 0)
		font, linesize = self.get_font_variant(shrink_level)
		font_kwargs = {"font": font, "linesize_override": linesize}
		spell_icon_px = min(FONT_SIZE, linesize)
		bottom_lines = []
		draw_mutators = game.mutators and game.trial_name
		if draw_mutators: bottom_lines.append("mutators")
		if cheats_enabled: bottom_lines.append("cheats")
		draw_combat_log_button = self.draw_combat_log_button or game.gameover or game.victory
		if draw_combat_log_button: bottom_lines.append('combat_log'); self.draw_combat_log_button = True
		draw_reroll =  getattr(self.game, 'rift_rerolls', 0) and not draw_combat_log_button
		if draw_reroll: bottom_lines.append("reroll")
		bottom_lines.extend(["menu", "howto", "char"])
		line_limit = panel.get_height() - margin - len(bottom_lines) * linesize
		x_limit = panel.get_width() - margin
		max_used_x = margin

		cur_x = margin
		cur_y = margin

		low_hp = player.cur_hp <= 25
		hpcolor = (255, 0, 0) if low_hp else (255, 255, 255)
		# Apply HP flash effect when player takes damage - single flash
		if self.cur_hp_flash:
			hpcolor = (255, 255, 255) if low_hp else (255, 0, 0)
			self.cur_hp_flash -= 1
			if self.cur_hp_flash <= 0: self.cur_hp_flash = None
		hp = (text.UNIT_HP, {"color": attr_key('damage'), "cur": player.cur_hp, "max": player.max_hp})
		self.draw_string(hp, panel, cur_x, cur_y, color=hpcolor, **font_kwargs) # to make hp red always, need to fix draw_string height placement to draw over, or use draw_wrapped, or amend draw_string to allow for different colored words inside

		status_right_x = self.spell_charges_x

		if 'chronomancer_time_left_ds' in game.__dict__:
			time_left_ds = game.chronomancer_time_left_ds
			timer_text = self.format_chronomancer_time(time_left_ds)
			timer_color = (255, 255, 255)
			if time_left_ds <= 150: timer_color = (255, 0, 0)
			elif time_left_ds <= 600: timer_color = (255, 255, 0)
			timer_w = font.size(timer_text)[0]
			timer_x = self.spell_charges_x - timer_w
			self.draw_string(timer_text, panel, timer_x, cur_y, color=timer_color, pre_resolved=True, cache_ok=False, **font_kwargs)
			timer_slot_w = cached_size(font, "88:88.8")
			status_right_x = self.spell_charges_x - timer_slot_w - margin

		if self.spell_speed_flash_frames:
			speed_name = SPELL_SPEED_NAMES[self.options['spell_speed']]
			speed_w = font.size(speed_name)[0]
			self.draw_string(speed_name, panel, status_right_x - speed_w, cur_y, color=COLOR_XP, pre_resolved=True, **font_kwargs)
			self.spell_speed_flash_frames -= 1

		cur_y += linesize

		if player.shields:
			self.draw_string((text.UNIT_SH, {"color": Raw("shield"), "num":player.shields}), panel, cur_x, cur_y, **font_kwargs)
			cur_y += linesize

		self.draw_string(("SP {num}", {"num":player.xp}), panel, cur_x, cur_y, color=COLOR_XP, **font_kwargs)
		cur_y += linesize

		turn_display = self.game.cur_level.turn_no + (0.5 if player.quick_cast_used else 0)
		self.draw_string(("Realm {r}, Turn {t}", {"r": game.level_num, "t": turn_display}), panel, cur_x, cur_y, cache_ok=False, **font_kwargs)
		cur_y += 2 * linesize
		self.draw_string(("Spells ({char})", {"char": self.get_keybind_letters(KEY_BIND_SPELLS)}), panel, cur_x, cur_y, mouse_content=LEARN_SPELL_TARGET, **font_kwargs)

		cur_y += linesize

		# decay spell flash frames
		if self.cur_spell_flash:
			new_flash = {}
			for s, (c, f) in self.cur_spell_flash.items():
				f -= 1
				if f > 0: new_flash[s] = (c, f)
			self.cur_spell_flash = new_flash

		# Spells
		for idx, spell in enumerate(player.spells, start=1):
			# hotkey text from index
			d = idx % 10
			m = 'S' if idx > 10 else '' # spell input modifier S short for shift
			hotkey = Raw(f"{m}{d}") # no need to translate this

			# color
			if spell == self.cur_spell: color = (0, 255, 0)
			elif spell.can_pay_costs(): color = (255, 255, 255)
			else: color = UNAVAILABLE_COLOR

			# Check if this spell should have a flash overlay
			if spell.flash_color is not None:
				self.cur_spell_flash[spell] = (spell.flash_color, SPELL_FLASH_FRAMES)
				spell.flash_color = None

			flash_data = self.cur_spell_flash.get(spell) if self.cur_spell_flash else None
			flash_color = flash_data[0] if flash_data else None
			is_flash = flash_data is not None
			text_color = flash_color if is_flash and flash_color else color

			# ---- single, full-width hover/click rect for the whole row ----
			row_left = self.spell_hotkey_x
			row_right = self.spell_charges_x  # inner right edge anchor
			row_rect = pygame.Rect(row_left, cur_y, row_right - row_left, linesize)
			self.make_content_rect(panel, row_rect, SpellCharacterWrapper(spell), enable_highlight=True)

			# ---- hotkey  ----
			self.draw_string(hotkey, panel, self.spell_hotkey_x, cur_y, color=text_color, char_panel=True, **font_kwargs)

			# ---- icon (centered vertically) ----
			y_icon = cur_y + (linesize - spell_icon_px) // 2
			self.draw_scaled_icon(spell, panel, self.spell_icon_x, y_icon, size=spell_icon_px)

			if is_flash: # draw an overlay icon if we are flashing
				overlay = self.get_flash_overlay(get_asset_key(spell), spell_icon_px, default_cell=16, recolor=flash_color)
				if overlay: panel.blit(overlay, (self.spell_icon_x, y_icon))

			# ---- cd or charges (flush-right) ----
			rem_cd = spell.caster.cool_downs.get(spell, 0)
			if rem_cd: fmt = Raw('(' + str(rem_cd) + ')') # will be greyed out, and telling the player how many turns until they can cast
			elif not spell.max_charges: fmt = str(0) # lock to 0 if max_charges should be zero
			else: fmt = str(spell.cur_charges)
			cw = font.size(fmt)[0]
			self.draw_string(fmt, panel, self.spell_charges_x - cw, cur_y, color=text_color, char_panel=True, pre_resolved=True, **font_kwargs)

			# ---- name (bounded so it never hits charges; no mouse_content here) ----
			name_str = fit_text_to_width(font, spell.name, self.spell_name_max_w) # hands back a translated string of Raw type.
			self.draw_string(name_str, panel, self.spell_name_x, cur_y, color=text_color, char_panel=True, pre_resolved=True, **font_kwargs)

			cur_y += linesize

		surf_pos = self.get_surface_pos(self.character_display)

		cur_y += linesize
		self.draw_string(("Equipment ({char})", {"char": self.get_keybind_letters(KEY_BIND_CRAFTING)}), panel, cur_x, cur_y, mouse_content=CRAFTING_TARGET, **font_kwargs)
		cur_y += linesize
		if player.equipment:

			# decay equipment flash frames
			if self.cur_equipment_flash:
				new_flash = {}
				for s, (c, f) in self.cur_equipment_flash.items():
					f -= 1
					if f > 0: new_flash[s] = (c, f)
				self.cur_equipment_flash = new_flash

			for item in player.equipment:

				abs_rect = pygame.Rect(cur_x + surf_pos[0], cur_y + surf_pos[1], FONT_SIZE, FONT_SIZE)
				self.make_content_rect(panel, abs_rect, item)
				self.draw_scaled_icon(item, panel, cur_x, cur_y)

				# Check if this equipment should have a flash overlay, if it does, put it in the dictionary, and then clear the trigger
				if item.flash_color is not None:
					self.cur_equipment_flash[item] = (item.flash_color, EQUIPMENT_FLASH_FRAMES)
					item.flash_color = None

				flash_data = self.cur_equipment_flash.get(item) if self.cur_equipment_flash else None
				flash_color = flash_data[0] if flash_data else None
				is_flash = flash_data is not None

				if is_flash: # draw an overlay icon if we are flashing
					overlay = self.get_flash_overlay(get_asset_key(item), FONT_SIZE, default_cell=16, recolor=flash_color)
					if overlay: panel.blit(overlay, (cur_x, cur_y))

				cur_x += FONT_SIZE+2
				if cur_x > panel.get_width() - margin - FONT_SIZE:
					cur_x = margin
					cur_y += FONT_SIZE

			cur_y += linesize
			cur_x = margin

		if player.components:
			cur_y += linesize
			self.draw_string("Components", panel, cur_x, cur_y, color=(255, 255, 255), **font_kwargs)
			cur_y += linesize

			for item in player.components:
				abs_rect = pygame.Rect(cur_x + surf_pos[0], cur_y + surf_pos[1], FONT_SIZE, FONT_SIZE)
				self.make_content_rect(panel, abs_rect, item)
				self.draw_scaled_icon(item, panel, cur_x, cur_y)
				cur_x += FONT_SIZE+2
				if cur_x > panel.get_width() - margin - FONT_SIZE:
					cur_x = margin
					cur_y += FONT_SIZE

			cur_y += linesize
			cur_x = margin

			# Show a list of how many of each tag you have
			for tag, num in player.component_tags.items():
				if num > 0:
					tag_letter = self.get_filter_key(tag)
					txt = f"{tag_letter}:{num}"
					self.draw_string(txt, panel, cur_x, cur_y, color=tag.color.to_tup(), pre_resolved=True, **font_kwargs)
					text_width = font.size(txt)[0]
					cur_x += text_width + 8

					if cur_x > panel.get_width() - self.border_margin - text_width:
						cur_x = self.border_margin
						cur_y += linesize

			cur_x = self.border_margin
			cur_y += linesize

			####

		wishlist = player.wishlist_equipment
		if wishlist:
			cur_y += linesize
			self.draw_string("Desired", panel, cur_x, cur_y, **font_kwargs)
			cur_y += linesize

			for e in wishlist:
				# Draw clickable icon
				icon_x = cur_x
				icon_y = cur_y
				surf_pos = self.get_surface_pos(panel)
				row_right = self.spell_charges_x
				click_w = row_right - icon_x
				click_rect = pygame.Rect(icon_x + surf_pos[0], icon_y + surf_pos[1], click_w, linesize)
				self.make_content_rect(panel, click_rect, e, enable_highlight=True)

				self.draw_scaled_icon(e, self.character_display, icon_x, icon_y)

				missing_tags = self.game.get_missing_crafting_requirements(e)
				recipe_tags = self.flatten_recipe(e.recipe)
				recipe_width = sum(font.size(self.get_filter_key(t) or t.name[0])[0] for t in recipe_tags)
				recipe_start = self.spell_charges_x - recipe_width

				name_x = icon_x + FONT_SIZE + 4
				name_w = max(0, recipe_start - name_x - 4) # squish the name between the recipe and the icon
				display_name = fit_text_to_width(font, e.name, name_w)
				self.draw_string(display_name, panel, name_x, cur_y, **font_kwargs)

				tx = recipe_start
				for t in recipe_tags:
					string = self.get_filter_key(t)
					c = t.color.to_tup()
					if t in missing_tags:
						missing_tags.remove(t)
						c = UNAVAILABLE_COLOR
					self.draw_string(string, panel, tx, icon_y, color=c, pre_resolved=True, **font_kwargs)
					tx += font.size(string)[0]

				cur_y += linesize

		if any(player.resists.get(t, 0) for t in Tags):
			cur_y += linesize
			self.draw_string("Resistances", panel, cur_x, cur_y, color=(255, 255, 255), **font_kwargs)
			cur_y += linesize

			resist_tags = [t for t in Tags if player.resists.get(t)]
			resist_tags.sort(key=lambda t: (-1 if player.resists[t] >= 0 else 1, -abs(player.resists[t])))

			drew_resist_group = False
			for negative in [False, True]:
				group_drawn = False
				for tag in resist_tags:
					if (player.resists[tag] < 0) != negative: continue
					if not group_drawn and drew_resist_group: cur_y += linesize # gap pos / neg resists
					fmt = (text.RESIST_VAL, {"val": player.resists[tag], "tag_label": tag_label(tag)})
					self.draw_string(fmt, panel, cur_x, cur_y, color=tag.color.to_tup(), **font_kwargs)
					cur_y += linesize
					group_drawn = True
				if group_drawn: drew_resist_group = True

		# Status Effects
		status_effects = [b for b in player.buffs if b.buff_type in [BUFF_TYPE_BLESS, BUFF_TYPE_CURSE]]
		counts = {}
		for effect in status_effects:
			if effect.name not in counts: counts[effect.name] = (effect, 0, 0, None)
			_, stacks, duration, color = counts[effect.name]
			stacks += 1
			duration = max(duration, effect.turns_left)
			counts[effect.name] = (effect, stacks, duration, effect.get_tooltip_color().to_tup())

		if status_effects:
			cur_y += linesize
			self.draw_string("Status Effects", panel, cur_x, cur_y, color=(255, 255, 255), **font_kwargs)
			cur_y += linesize
			for buff_name, (buff, stacks, duration, color) in counts.items():
				fmt = resolve_text(buff_name)
				if stacks > 1: fmt += ' x%d' % stacks
				if duration: fmt += ' (%d)' % duration
				max_used_x = max(max_used_x, cur_x + cached_size(font, fmt))
				self.draw_string(fmt, panel, cur_x, cur_y, color=color, mouse_content=buff, pre_resolved=True, **font_kwargs)
				cur_y += linesize

		stunbuff = player.get_buff(Stun)
		if stunbuff:
			cur_y += linesize
			color = (255, 0, 0) if self.cast_fail_frames else stunbuff.color.to_tup()
			self.draw_string((text.STATUS_LINE, {"status":stunbuff.name.upper()}), panel, cur_x, cur_y, color=color, **font_kwargs)
			cur_y += linesize

		content_bottom = cur_y
		cur_x = self.border_margin
		cur_y = line_limit

		if draw_mutators:
			message = game.trial_name
			for mutator in game.mutators: message += "\n" + resolve_text(mutator.get_description(), fmt=mutator.fmt_dict())
			CHALLENGES_TARGET = TooltipExamineTarget(message)
			self.draw_string(game.trial_name, panel, cur_x, cur_y, mouse_content=CHALLENGES_TARGET, pre_resolved=True, **font_kwargs)
			cur_y += linesize

		if cheats_enabled:
			self.draw_string("Cheats Enabled", panel, cur_x, cur_y, color=(255, 0, 0), **font_kwargs)
			cur_y += linesize

		if draw_reroll: # blocks a crash that came from trying to load a crashed save
			rolls = game.rift_rerolls
			roll_fmt = Raw(f'({rolls})') if rolls > 1 else Raw('')
			fmt = ("Reroll Rifts ({key}) {extra_rerolls}", {"key": self.get_keybind_letters(KEY_BIND_REROLL), "extra_rerolls": roll_fmt})
			self.draw_string(fmt, panel, cur_x, cur_y, mouse_content=REROLL_PORTALS_TARGET, **font_kwargs)
			cur_y += linesize

		if draw_combat_log_button:
			label = ("View Combat Log ({key})", {"key": self.get_keybind_letters(KEY_BIND_MESSAGE_LOG)})
			self.draw_string(label, panel, cur_x, cur_y, mouse_content=COMBAT_LOG_TARGET, **font_kwargs)
			cur_y += linesize

		self.draw_string(("Menu ({key})", {"key": self.get_keybind_letters(KEY_BIND_ABORT)}), panel, cur_x, cur_y, mouse_content=OPTIONS_TARGET, **font_kwargs)
		cur_y += linesize

		self.draw_string(("How to Play ({key})", {"key": self.get_keybind_letters(KEY_BIND_HELP)}), panel, cur_x, cur_y, mouse_content=INSTRUCTIONS_TARGET, **font_kwargs)
		cur_y += linesize

		color = (255, 255, 255)
		self.draw_string(("Character Sheet ({key})", {"key": self.get_keybind_letters(KEY_BIND_CHAR)}), panel, cur_x, cur_y, color=color, mouse_content=CHAR_SHEET_TARGET, **font_kwargs)
		cur_y += linesize

		# overflow nudges shrink_text upward once per frame
		max_used = content_bottom
		if (max_used + linesize > line_limit or max_used_x + FONT_SIZE > x_limit) and shrink_level < self.max_shrink_level:
			player.shrink_text = min(self.max_shrink_level, shrink_level + 1)
		elif shrink_level > 0 and max_used + 8 * linesize <= line_limit and max_used_x + 3 * FONT_SIZE <= x_limit:
			player.shrink_text = max(0, shrink_level - 1)

	def draw_examine(self):

		if (self.game and getattr(self.examine_target, "level", None) == self.game.cur_level) and self.game.deploying:
			self.examine_target = None

		if self.state == STATE_LEVEL and not self.game.is_awaiting_input() and not (self.game.gameover or self.game.victory):
			self.examine_target = None

		self.examine_display.fill((0, 0, 0))

		if self.examine_target:
			if isinstance(self.examine_target, Spell):
				self.draw_examine_spell()
			elif isinstance(self.examine_target, SpellCharacterWrapper):
				old = self.examine_target
				self.examine_target = self.examine_target.spell
				self.draw_examine_spell()
				self.examine_target = old
			elif isinstance(self.examine_target, Unit):
				self.draw_examine_unit()
			elif isinstance(self.examine_target, Buff):
				self.draw_examine_upgrade()
			elif isinstance(self.examine_target, Component) or isinstance(self.examine_target, ComponentPickup):
				self.draw_examine_component()
			elif isinstance(self.examine_target, EquipmentList):
				self.draw_examine_equipment_list()
			elif isinstance(self.examine_target, VaultPortal):
				self.draw_examine_vault_portal()
			elif isinstance(self.examine_target, Portal):
				self.draw_examine_portal()
			elif isinstance(self.examine_target, Shop):
				self.draw_examine_shop()
			elif isinstance(self.examine_target, WardrobeOutfit):
				pass
			else:
				self.draw_examine_misc()
		elif self.game:
			if self.game.deploying:
				self.draw_examine_misc(DEPLOY_TARGET)
			elif self.game.level_cleared:
				self.draw_level_stats()
			elif self.game.cur_level.turn_no > 0:
				self.draw_turn_stats()

		if self.game and (self.game.gameover or self.game.victory):
			self.draw_level_stats()

		if self._examine_extras:
			x = self.border_margin
			y = self.examine_display.get_height() - 3 * self.border_margin
			prv = self._examine_index+1
			nxt = len(self._examine_extras)+1
			fmt = ("<<<< PGUP {prv}/{nxt} PGDN >>>>", {"prv": prv, "nxt": nxt})

			self.draw_string(fmt, self.examine_display, x, y, (255, 255, 255), center=True, content_width=self.examine_display.get_width())

	def draw_turn_stats(self):
		cur_x = self.border_margin
		cur_y = self.border_margin
		linesize = self.linesize
		turn_summary = self.game.cur_level.turn_summary
		name_col_w = (self.recap_number_col_x - cur_x - 4)

		def draw_stat_line(name, value):
			left = fit_text_to_width(self.font, name, name_col_w)
			self.draw_string(left, self.examine_display, cur_x, cur_y, pre_resolved=True)
			dmg_str = str(value)
			right_pad = self.recap_number_col_width - self.font.size(dmg_str)[0]
			self.draw_string(dmg_str, self.examine_display, self.recap_number_col_x + right_pad, cur_y, pre_resolved=True)

		last_action = self.game.p1.last_action
		if last_action is not None:
			action_type = type(last_action)
			if action_type == MoveAction:
				action_str = "You moved"
			elif action_type == CastAction:
				action_str = ("You cast {spell}", {"spell": last_action.spell.name})
			elif self.game.p1.get_buff(ChannelBuff):
				b = self.game.p1.get_buff(ChannelBuff)
				spell_name = getattr(b, "spell_name", None) or b.spell.__name__
				action_str = ("You channeled {spell}", {"spell": spell_name})
			elif action_type == PassAction:
				action_str = "You waited"
			elif action_type == StunnedAction:
				action_str = ("You were {status} for {dur} turns",{"status": last_action.buff.name, "dur": last_action.duration})
			else: action_str = ""

			self.draw_wrapped_string(action_str, self.examine_display, cur_x, cur_y, width=self.examine_display.get_width() - (self.border_margin*2))
			cur_y += 2*linesize

		if turn_summary.damage_dealt:
			total_dmg = sum(turn_summary.damage_dealt.values())
			draw_stat_line("Damage Dealt:", total_dmg)
			cur_y += linesize

			for src, dmg in sorted(turn_summary.damage_dealt.items(), key=lambda t: -t[1]):
				draw_stat_line(src, dmg)
				cur_y += linesize

			cur_y += linesize

		if turn_summary.self_damage_taken:
			total_dmg = sum(turn_summary.self_damage_taken.values())
			draw_stat_line("Damage Taken:", total_dmg)
			cur_y += linesize
			for src, dmg in turn_summary.self_damage_taken.items():
				draw_stat_line(src, dmg)
				cur_y += linesize

			cur_y += linesize

		if turn_summary.ally_damage_taken:
			total_dmg = sum(turn_summary.ally_damage_taken.values())
			draw_stat_line("Ally Damage Taken:", total_dmg)
			cur_y += linesize
			for src, dmg in turn_summary.ally_damage_taken.items():
				draw_stat_line(src, dmg)
				cur_y += linesize

			cur_y += linesize

		if turn_summary.enemy_kill_counts:
			total_kills = sum(turn_summary.enemy_kill_counts.values())
			draw_stat_line("Enemies Slain:", total_kills)
			cur_y += linesize
			for name, kills in turn_summary.enemy_kill_counts.items():
				draw_stat_line(name, kills)
				cur_y += linesize
			cur_y += linesize

		if turn_summary.ally_kill_counts:
			total_kills = sum(turn_summary.ally_kill_counts.values())
			draw_stat_line("Allies Lost:", total_kills)
			cur_y += linesize
			for name, kills in turn_summary.ally_kill_counts.items():
				draw_stat_line(name, kills)
				cur_y += linesize
			cur_y += linesize

	def draw_examine_upgrade(self): # handles spellupgrades and equipment
		has_icon = getattr(self.examine_target, 'buff_type', None) == BUFF_TYPE_ITEM
		if has_icon:
			self.draw_scaled_icon(self.examine_target, self.examine_display, self.examine_icon_x, self.examine_icon_y, size=self.examine_icon_size)

		upgrade = self.examine_target
		border_margin = self.border_margin
		cur_x = border_margin
		cur_y = border_margin
		shrink_level = upgrade.shrink_text
		font, linesize = self.get_font_variant(shrink_level)
		font_kwargs = {"font": font, "linesize_override": linesize}
		line_limit = self.examine_display.get_height() - border_margin

		def wrap(text, extra_space=False, fmt=None):
			width = self.get_examine_text_width(cur_y, has_icon)
			return self.draw_wrapped_string(text, self.examine_display, cur_x, cur_y, width=width, indent=False, extra_space=extra_space, fmt=fmt, **font_kwargs)

		lines = wrap(upgrade.name)
		cur_y += linesize * lines
		buff_type = upgrade.get_buff_type_label()
		if buff_type: lines = wrap(("{label}", {'label':buff_type})); cur_y += linesize * lines
		cur_y += linesize

		# Draw equipment tags
		if isinstance(upgrade, Equipment) and upgrade.tags:
			for tag in upgrade.tags:
				self.draw_string(tag.name, self.examine_display, cur_x, cur_y, tag.color.to_tup(), **font_kwargs)
				cur_y += linesize
			cur_y += linesize

		if getattr(self.examine_target, 'level', None):
			fmt = (text.SPELL_LEVEL, {"level": upgrade.level})
			self.draw_string(fmt, self.examine_display, cur_x, cur_y, **font_kwargs)
			cur_y += linesize

		cur_y += linesize

		# Autogen boring part of description
		for tag, bonuses in upgrade.tag_bonuses_pct.items():
			for attr, val in bonuses.items():
				fmt = (text.TAG_PCT_BONUS, {"tag_label":tag_label(tag), "tag_key":tag_key(tag), "val":int(val), "attr_label":attr_label(attr), "attr_key":attr_key(attr)})
				lines = wrap(fmt)
				cur_y += (lines+1) * linesize

		for tag, bonuses in upgrade.tag_bonuses.items():
			for attr, val in bonuses.items():
				fmt = (text.TAG_VAL_BONUS, {"tag_label":tag_label(tag), "tag_key":tag_key(tag), "val":int(val), "attr_label":attr_label(attr), "attr_key":attr_key(attr)})
				lines = wrap(fmt)
				cur_y += (lines+1) * linesize

		for spell, bonuses in upgrade.spell_bonuses_pct.items():
			spell_ex = spell()
			useful_bonuses = [(attr, val) for (attr, val) in bonuses.items() if attr in spell_ex.stats]
			if not useful_bonuses: continue

			for attr, val in useful_bonuses:
				if attr in tooltip_colors: fmt = (text.GAIN_PCT_COLORED, {"name": spell_ex.name, "val": val, "attr_label": format_attr(attr), "attr_key": attr_key(attr)})
				else: fmt = (text.GAIN_PCT_PLAIN, {"name": spell_ex.name, "val": val, "attr_label": format_attr(attr)})
				lines = wrap(fmt)
				cur_y += (lines+1) * linesize

		for spell, bonuses in upgrade.spell_bonuses.items():
			spell_ex = spell()
			useful_bonuses = [(attr, val) for (attr, val) in bonuses.items() if attr in spell_ex.stats]
			if not useful_bonuses: continue

			for attr, val in useful_bonuses:
				if attr in tooltip_colors: fmt = (text.GAIN_VAL_COLORED, {"name": spell_ex.name, "val": val, "attr_label": format_attr(attr), "attr_key": attr_key(attr)})
				else: fmt = (text.GAIN_VAL_PLAIN, {"name": spell_ex.name, "val": val, "attr_label": format_attr(attr)})
				lines = wrap(fmt)
				cur_y += (lines+1) * linesize

		if hasattr(upgrade, 'new_attributes') and hasattr(upgrade, 'prereq'):
			spell = upgrade.prereq.name
			for attr, val in upgrade.new_attributes.items():
				if attr in tt_attrs or attr == 'hp_cost': fmt = (text.GAIN_VAL_COLORED, {"name": spell, "val": val, "attr_label": format_attr(attr), "attr_key": attr_key(attr)})
				else: continue
				lines = wrap(fmt)
				cur_y += (lines+1) * linesize

		for attr, val in upgrade.global_bonuses_pct.items():
			if val >= 0: fmt = (text.ALL_GAIN_PCT, {"val": int(val), "attr_label": format_attr(attr), "attr_key":attr_key(attr)})
			else: fmt = (text.ALL_LOSE_PCT, {"val": int(val), "attr_label": format_attr(attr), "attr_key":attr_key(attr)})
			lines = wrap(fmt)
			cur_y += (lines+1) * linesize

		for attr, val in upgrade.global_bonuses.items():
			if val >= 0: fmt = (text.ALL_GAIN_VAL, {"val": int(val), "attr_label": format_attr(attr), "attr_key": attr_key(attr)})
			else: fmt = (text.ALL_LOSE_VAL, {"val": int(val), "attr_label": format_attr(attr), "attr_key": attr_key(attr)})
			lines = wrap(fmt)
			cur_y += (lines+1) * linesize

		has_resists = False

		for tag in upgrade.resists:
			fmt = (text.RESIST_VAL, {"val": upgrade.resists[tag], "tag_label": tag_label(tag)})
			self.draw_string(fmt, self.examine_display, cur_x, cur_y, tag.color.to_tup(), **font_kwargs)
			has_resists = True
			cur_y += linesize

		if has_resists: cur_y += linesize

		desc = upgrade.get_description()
		if not desc: desc = upgrade.get_tooltip()

		if desc:
			lines = wrap(desc, extra_space=True, fmt=upgrade.fmt_dict())
			cur_y += lines * linesize

		if isinstance(upgrade, Equipment):
			header_y = cur_y
			cur_y += linesize
			had_attrs = False

			for attr in tt_attrs:
				if not hasattr(upgrade, attr): continue
				had_attrs = True
				fmt = (text.STATLINE, {"value": upgrade.get_stat(attr), "attr_label": attr_label(attr)})
				self.draw_string(fmt, self.examine_display, cur_x, cur_y, attr_colors[attr].to_tup(), **font_kwargs)
				cur_y += linesize

			if had_attrs: self.draw_string("Attributes:", self.examine_display, cur_x, header_y, **font_kwargs)

		stacking = upgrade.get_stacking_label()
		if stacking:
			cur_y += 2 * linesize
			lines = wrap(("Stack Type: {label}", {'label':stacking}))
			cur_y += lines * linesize

		if cur_y > line_limit and shrink_level < self.max_shrink_level:
			upgrade.shrink_text = min(self.max_shrink_level, shrink_level + 1)

	def draw_examine_misc(self, target=None):
		border_margin = self.border_margin
		cur_x = border_margin
		cur_y = border_margin

		if not target: target = self.examine_target

		if hasattr(target, "name"):
			lines = self.draw_wrapped_string(target.name, self.examine_display, cur_x, cur_y, width=23*16)
			cur_y += (lines + 1) * self.linesize
		if hasattr(target, 'get_asset'):
			self.draw_scaled_icon(target, self.examine_display, self.examine_icon_x, self.examine_icon_y, size=self.examine_icon_size)
			cur_y += self.examine_icon_size
		if hasattr(target, "get_description"):
			if hasattr(target, "fmt_dict"): fmt = target.fmt_dict()
			else: fmt = {}
			self.draw_wrapped_string(target.get_description(), self.examine_display, cur_x, cur_y, self.examine_display.get_width() - 2*self.border_margin, extra_space=True, fmt=fmt)
		elif hasattr(target, "description"):
			self.draw_wrapped_string(target.description, self.examine_display, cur_x, cur_y, self.examine_display.get_width() - 2*self.border_margin, extra_space=True)

	def draw_examine_component(self):
		border_margin = self.border_margin
		cur_x = border_margin
		cur_y = border_margin
		target = self.examine_target
		if isinstance(target, ComponentPickup): target = target.component
		self.draw_scaled_icon(target, self.examine_display, self.examine_icon_x, self.examine_icon_y, size=self.examine_icon_size)

		if hasattr(target, "name"):
			lines = self.draw_wrapped_string(target.name, self.examine_display, cur_x, cur_y, width=23 * 16)
			cur_y += (lines + 1) * self.linesize

		if hasattr(target, 'tags'):
			for tag in target.tags:
				self.draw_string(tag.name, self.examine_display, cur_x, cur_y, (tag.color.r, tag.color.g, tag.color.b))
				cur_y += self.linesize
			cur_y += self.linesize

		if hasattr(target, "get_description"):
			self.draw_wrapped_string(target.get_description(), self.examine_display, cur_x, cur_y, self.examine_display.get_width() - 2 * border_margin, indent=False, extra_space=True)
		elif hasattr(target, "description"):
			self.draw_wrapped_string(target.description, self.examine_display, cur_x, cur_y, self.examine_display.get_width() - 2 * border_margin, indent=False, extra_space=True)

	def draw_examine_equipment_list(self):
		border_margin = self.border_margin
		cur_x = border_margin
		cur_y = border_margin
		panel = self.examine_display

		prospective_equipment = list(self.examine_target.equipments)

		target_shrink = getattr(self.examine_target, 'shrink_text', 0)
		line_limit = panel.get_height() - border_margin

		while True:
			font, linesize = self.get_font_variant(target_shrink)
			est_y = border_margin
			est_y += linesize
			if prospective_equipment: est_y += linesize * 2
			else: est_y += linesize
			est_y += len(prospective_equipment) * linesize
			if est_y <= line_limit or target_shrink >= self.max_shrink_level: break
			target_shrink += 1

		self.examine_target.shrink_text = target_shrink
		font, linesize = self.get_font_variant(target_shrink)
		font_kwargs = {"font": font, "linesize_override": linesize}

		self.draw_string("Prospective Equipment", panel, cur_x, cur_y, **font_kwargs)
		cur_y += linesize

		if prospective_equipment:
			txt = ("({count})", {"count": len(prospective_equipment)})
			self.draw_string(txt, panel, cur_x, cur_y, **font_kwargs)
			cur_y += linesize * 2
		else: self.draw_string("None", panel, cur_x, cur_y, **font_kwargs)

		for i in prospective_equipment:
			self.draw_scaled_icon(i, panel, cur_x, cur_y) # draw equipment icon
			cur_x += SPRITE_SIZE // 2
			self.draw_string(i.name, panel, cur_x, cur_y, **font_kwargs) # draw equipment name
			cur_x = border_margin
			cur_y += linesize

	def draw_examine_spell(self):

		self.draw_scaled_icon(self.examine_target, self.examine_display, self.examine_icon_x, self.examine_icon_y, size=self.examine_icon_size)

		border_margin = self.border_margin
		cur_x = border_margin
		cur_y = border_margin
		linesize = self.linesize
		spell = self.examine_target

		def wrap(text, extra_space=False, fmt=None):
			width = self.get_examine_text_width(cur_y, True)
			return self.draw_wrapped_string(text, self.examine_display, cur_x, cur_y, width, indent=False, extra_space=extra_space, fmt=fmt)

		lines = wrap(spell.name)
		cur_y += linesize * lines
		cur_y += linesize

		for tag in spell.tags:
			self.draw_string(tag.name, self.examine_display, cur_x, cur_y, tag.color.to_tup())
			cur_y += linesize

		cur_y += linesize

		if spell.level:
			lvl = (text.SPELL_LEVEL, {"level": spell.level})
			self.draw_string(lvl, self.examine_display, cur_x, cur_y)
			cur_y += linesize

		if spell.melee:
			self.draw_string(text.SPELL_MELEE_RANGE, self.examine_display, cur_x, cur_y)
			cur_y += linesize
		elif spell.range:
			fmt = (text.SPELL_RANGE, {"range": spell.get_stat('range'), "los":"" if spell.get_stat('requires_los') else text.SPELL_IGNORES_LOS})
			self.draw_string(fmt, self.examine_display, cur_x, cur_y)
			cur_y += linesize

		if spell.get_stat('quick_cast'):
			self.draw_string(text.SPELL_QUICK_CAST, self.examine_display, cur_x, cur_y)
			cur_y += linesize

		if spell.max_charges:
			fmt = (text.SPELL_CHARGES, {"cur": spell.cur_charges, "max":spell.get_stat('max_charges')})
			self.draw_string(fmt, self.examine_display, cur_x, cur_y)
			cur_y += linesize

		if spell.get_stat('hp_cost'):
			fmt = (text.SPELL_HP_COST, {"cost": spell.get_stat('hp_cost')})
			self.draw_string(fmt, self.examine_display, cur_x, cur_y)
			cur_y += linesize

		if spell.get_stat('cool_down') > 0 or spell.cool_down > 0:
			cd = spell.get_stat('cool_down')
			rem_cd = spell.caster.cool_downs.get(spell, 0) if spell.caster else 0
			rem_cd_fmt = Raw('(' + str(rem_cd) + ')') if rem_cd else ""
			fmt = (text.COOLDOWN, {"value": cd, "remaining": rem_cd_fmt})
			self.draw_string(fmt, self.examine_display, cur_x, cur_y)
			cur_y += linesize

		cur_y += linesize

		lines = wrap(spell.get_description(), extra_space=True, fmt=spell.fmt_dict())
		cur_y += linesize * lines

		self.draw_string("Attributes:", self.examine_display, cur_x, cur_y)
		cur_y += linesize
		had_attrs = False
		for attr in tt_attrs:
			if not getattr(self.examine_target, attr, None): continue # don't display 0 attributes
			had_attrs = True
			fmt = (text.STATLINE, {"value": self.examine_target.get_stat(attr), "attr_label": attr_label(attr)})
			self.draw_string(fmt, self.examine_display, cur_x, cur_y, attr_colors[attr].to_tup())
			cur_y += linesize

		if not had_attrs:
			self.draw_string("None", self.examine_display, cur_x, cur_y)
			cur_y += linesize
		cur_y += linesize

		if spell.spell_upgrades:
			self.draw_string("Upgrades:", self.examine_display, cur_x, cur_y)
			cur_y += linesize

			for upg in spell.spell_upgrades:
				cur_color = (0, 255, 0) if self.game.has_upgrade(upg) else (255, 255, 255)
				fmt = (" {level} - {name}", {"level":upg.level, "name":upg.name})
				self.draw_string(fmt, self.examine_display, cur_x, cur_y, color=cur_color)
				cur_y += linesize


	def draw_examine_vault_portal(self):

		portal = self.examine_target
		if isinstance(portal, VaultPortal):
			gen_params = portal.level_gen_params
			if getattr(gen_params, "level", None) is None:
				gen_params.make_level()

		self.draw_examine_portal()

	def draw_examine_portal(self):

		border_margin = self.border_margin
		cur_x = border_margin
		cur_y = border_margin

		tag_x = self.examine_display.get_width() - border_margin

		linesize = self.linesize

		gen_params = self.examine_target.level_gen_params

		portal = self.examine_target

		self.draw_string(getattr(portal, "name", "Rift"), self.examine_display, cur_x, cur_y)
		cur_y += linesize

		if portal.locked:
			cur_y += linesize

			width = self.examine_display.get_width() - 2 * border_margin
			lines = self.draw_wrapped_string("(Defeat all enemies and destroy all spawners to unlock)", self.examine_display, cur_x, cur_y, width)
			cur_y += (lines + 2) * linesize

			if isinstance(portal, VaultPortal):
				lines = self.draw_wrapped_string(portal.description, self.examine_display, cur_x, cur_y, width)
				cur_y += lines * linesize

			return

		cur_y += linesize

		drawn_names = set()
		units = []

		COLOR_POP = (255, 255, 255)
		COLOR_BOSS = (253, 143, 77)
		COLOR_ENC = (255, 0, 0)

		if gen_params.primary_spawn:
			unit = gen_params.primary_spawn()
			units.append((unit, COLOR_POP))
			drawn_names.add(unit.name)

		if gen_params.secondary_spawn and gen_params.secondary_spawn != gen_params.primary_spawn:
			unit = gen_params.secondary_spawn()
			units.append((unit, COLOR_POP))
			drawn_names.add(unit.name)

		for b in sorted(gen_params.bosses, key=lambda b: (b.is_boss, b.radius)):
			if b.name in drawn_names: continue
			units.append((b, COLOR_BOSS if not b.is_boss else COLOR_ENC))
			drawn_names.add(b.name)

		for unit, color in units:

			sprite_sheet = self.get_sprite_sheet(get_asset_key(unit), radius=unit.radius)
			frame = (cloud_frame_clock // FRAME_PERIOD) % (len(sprite_sheet.anim_frames[ANIM_IDLE]))

			sprite = sprite_sheet.anim_frames[ANIM_IDLE][frame]
			scaled_sprite = pygame.transform.smoothscale(sprite, (PORTAL_ICON_SIZE, PORTAL_ICON_SIZE))
			self.examine_display.blit(scaled_sprite, (cur_x, cur_y))

			name = unit.name if len(unit.name) <= 20 else unit.name[:18] + '..'
			text_x = cur_x + TEXT_OFFSET
			text_y = cur_y + max(0, (PORTAL_ICON_SIZE - linesize) // 2)
			self.draw_string(name, self.examine_display, text_x, text_y, color)
			cur_y += PORTAL_ICON_SIZE + ROW_GAP

		cur_y += linesize

		width = self.examine_display.get_width() - 2 * border_margin

		for component in gen_params.components:
			image = get_image(get_asset_key(component))
			name_y = cur_y + (image.get_height() - self.font.get_height()) // 2
			self.examine_display.blit(image, (cur_x, cur_y))
			self.draw_string(component.name, self.examine_display, cur_x + TEXT_OFFSET, name_y)
			tag_letters, tag_measure_letters = '', ''
			for tag in component.tags:
				tag_letter = self.get_filter_key(tag)
				tag_measure_letters += f"{tag_letter}"
				tag_letters += f"[{tag_letter}:{tag_key(tag)}]"
			cw = self.font.size(tag_measure_letters)[0]
			self.draw_string(tag_letters, self.examine_display, tag_x - cw, name_y, pre_resolved=True)
			cur_y += SPRITE_SIZE

		if gen_params.shrine:
			if isinstance(gen_params.shrine, ComponentPickup): cur_y -= linesize # align with regular components if only one reward and it's a component

			def iter_shrines(value):
				if isinstance(value, (list, tuple, set)):
					for shrine in value: yield shrine
				else: yield value

			for shrine in iter_shrines(gen_params.shrine):
				if not shrine: continue
				cur_y += linesize
				image = get_image(get_asset_key(shrine))
				name_y = cur_y + (image.get_height() - self.font.get_height()) // 2

				self.examine_display.blit(image, (cur_x, cur_y))

				is_component = isinstance(shrine, ComponentPickup)
				name_color = (170, 244, 243) if is_component else (255, 255, 255) # all reward components are rare/oncraft
				self.draw_string(shrine.name, self.examine_display, TEXT_OFFSET + border_margin, name_y, color=name_color, content_width=width)

				if is_component:
					tag_letters, tag_measure_letters = '', ''
					for tag in shrine.component.tags:
						tag_letter = self.get_filter_key(tag)
						tag_measure_letters += f"{tag_letter}"
						tag_letters += f"[{tag_letter}:{tag_key(tag)}]"
					cw = self.font.size(tag_measure_letters)[0]
					self.draw_string(tag_letters, self.examine_display, tag_x - cw, name_y, pre_resolved=True)

				cur_y += linesize * 2

				if isinstance(shrine, Shop):
					name_x = cur_x + TEXT_OFFSET
					icon_x = name_x - SPRITE_SIZE // 2
					if shrine.items: cur_y += int(linesize // 2)
					for item in shrine.items:
						self.draw_string(item.name, self.examine_display, name_x, cur_y)
						self.draw_scaled_icon(item, self.examine_display, icon_x, cur_y)
						cur_y += linesize

	def draw_examine_shop(self):
		cur_x = self.border_margin
		cur_y = self.border_margin

		self.draw_string(self.examine_target.name, self.examine_display, cur_x, cur_y)
		cur_y += self.linesize

		image = get_image(get_asset_key(self.examine_target))

		if image.get_width() % SPRITE_SIZE != 0: size = OG_SPRITE_SIZE
		else: size = SPRITE_SIZE

		frame = (cloud_frame_clock // FRAME_PERIOD) % (image.get_width() // size)
		sourcerect = (size * frame, 0, size, size)
		subimage = image.subsurface(sourcerect)
		scaledimage = pygame.transform.scale(subimage, (64, 64))

		self.examine_display.blit(scaledimage, (self.examine_display.get_width() - self.border_margin - 64, 0))

		if not self.examine_target.items: # for shrines
			cur_y += self.linesize * 2
			desc_len = self.draw_wrapped_string(self.examine_target.get_description(), self.examine_display, cur_x, cur_y,
												width=self.examine_display.get_width() - cur_x - self.border_margin)
			cur_y += self.linesize * desc_len

		for item in self.examine_target.items:
			cur_y += self.linesize
			self.draw_string(item.name, self.examine_display, cur_x + SPRITE_SIZE // 2, cur_y)
			self.draw_scaled_icon(item, self.examine_display, cur_x, cur_y)



	def draw_examine_unit(self):

		# If a game is running, do not display dead monsters or the player
		if self.game:
			if self.examine_target.killed: return
			if self.examine_target == self.game.p1: return

		if self.is_bestiary_shop():
			if not SteamAdapter.has_slain(self.examine_target.name): return

		border_margin = self.border_margin
		cur_x = border_margin
		cur_y = border_margin
		indent = border_margin
		unit = self.examine_target
		panel = self.examine_display
		# shrink_text keeps this panel legible without touching global font state
		shrink_level = getattr(unit, 'shrink_text', 0)
		font, linesize = self.get_font_variant(shrink_level)
		font_kwargs = {"font": font, "linesize_override": linesize}
		line_limit = panel.get_height() - border_margin

		# Determine the unit's native frame size: 60 * (1 + 2*radius)
		radius = getattr(unit, 'radius', 0) or 0
		native_size = SPRITE_SIZE * (1 + 2 * radius)

		# Ensure staging surface fits the full native frame (avoid cropping)
		# Recreate only if the size changed to avoid realloc each frame.
		if not hasattr(self, 'unit_examine_icon_surface') or self.unit_examine_icon_surface.get_width() != native_size:
			self.unit_examine_icon_surface = pygame.Surface((native_size, native_size), pygame.SRCALPHA).convert_alpha()

		# Clear with full transparency
		self.unit_examine_icon_surface.fill((0, 0, 0, 0))

		if unit.Anim:
			unit.Anim.draw(self.unit_examine_icon_surface, True)
		else:
			frames = self.get_unit_preview_frames(unit)
			frame = (cloud_frame_clock // SUB_FRAMES[ANIM_IDLE]) % len(frames)
			subimage = frames[frame]
			if unit.face_left: subimage = pygame.transform.flip(subimage, True, False)
			self.unit_examine_icon_surface.blit(subimage, (0, 0))

		# Scale the full native frame into the panel box
		scale_factor = radius + 1
		base = self.examine_icon_size
		dst_w = dst_h = base * scale_factor

		scaled = pygame.transform.smoothscale(self.unit_examine_icon_surface, (dst_w, dst_h))

		right_edge = self.examine_icon_x + self.examine_icon_size
		dest_x = right_edge - dst_w  # right-aligned
		dest_y = self.examine_icon_y  # top-aligned
		self.examine_display.blit(scaled, (dest_x, dest_y))


		lines = self.draw_wrapped_string(unit.name, panel, cur_x, cur_y, width=17*16, **font_kwargs) # what is the magic # width doing here?
		cur_y += (lines+1) * linesize

		if unit.team == TEAM_PLAYER:
			self.draw_string("Friendly", panel, cur_x, cur_y, color=Tags.Conjuration.color.to_tup(), **font_kwargs)
			cur_y += linesize

		if unit.turns_to_death:
			self.draw_string(("{num} turns left", {"num": unit.turns_to_death}), panel, cur_x, cur_y, **font_kwargs)
			cur_y += linesize

		if unit.cur_hp > 0:
			hp = (text.UNIT_HP, {"color": attr_key('damage'), "cur": unit.cur_hp, "max": unit.max_hp})
			self.draw_string(hp, panel, cur_x, cur_y, **font_kwargs)
		else:
			self.draw_string(("{num} HP",{"num":unit.max_hp}), panel, cur_x, cur_y, color=attr_colors['minion_health'].to_tup(), **font_kwargs) # for unit summon previews

		cur_y += linesize

		if unit.shields:
			self.draw_string((text.UNIT_SH, {"color": Raw("shield"), "num": unit.shields}), panel, cur_x, cur_y, **font_kwargs)
			cur_y += linesize

		cur_y += linesize
		for tag in unit.tags:
			self.draw_string(tag.name, panel, cur_x, cur_y, color=(tag.color.r, tag.color.g, tag.color.b), **font_kwargs)
			cur_y += linesize

		cur_y += linesize
		if unit.spells:
			self.draw_string("Spells:", panel, cur_x, cur_y, **font_kwargs)
			cur_y += linesize
		for spell in unit.spells:
			if getattr(spell, 'tt_color', None): cur_color= spell.tt_color.to_tup()
			elif hasattr(spell, 'damage_type') and isinstance(spell.damage_type, Tag): cur_color = spell.damage_type.color.to_tup()
			else: cur_color = (255, 255, 255)

			self.draw_string(spell.name, panel, cur_x, cur_y, color=cur_color, **font_kwargs)
			cur_y += linesize

			if spell.get_stat('quick_cast'):
				self.draw_string(text.SPELL_QUICK_CAST, panel, cur_x, cur_y, **font_kwargs)
				cur_y += linesize

			if hasattr(spell, 'damage'):
				dmg = spell.get_stat('damage')
				dt = getattr(spell, 'damage_type', None)

				if isinstance(dt, Tag):
					fmt = (text.DMG_VAL_TYPED_ONE, {"val": dmg, "type": (text.COLORED_TAG, {"tag_label": tag_label(dt), "tag_key": tag_key(dt)})})

				elif isinstance(dt, list) and dt:
					joiner_key = text.OR if getattr(spell, 'damage_type_random', False) else text.AND
					parts = []
					for i, t in enumerate(dt):
						if i: parts.append((joiner_key, {}))  # localized "and"/"or"
						parts.append((text.COLORED_TAG, {"tag_label": tag_label(t), "tag_key": tag_key(t)}))
					fmt = (text.DMG_VAL_TYPED_LIST, {"val": dmg, "types": parts})

				else: fmt = (text.DMG_VAL_ONLY, {"val": dmg})

				lines = self.draw_wrapped_string(fmt, panel, cur_x, cur_y, panel.get_width() - 2 * border_margin, color=COLOR_DAMAGE.to_tup(), **font_kwargs)
				cur_y += lines * linesize

			if spell.range > 1.5:
				fmt = (text.STATLINE, {"value": spell.get_stat('range'), "attr_label": attr_label('range')})
				self.draw_string(fmt, panel, cur_x, cur_y, color=COLOR_RANGE.to_tup(), **font_kwargs)
				cur_y += linesize
			if hasattr(spell, 'radius') and spell.get_stat('radius') > 0:
				fmt = (text.STATLINE, {"value": spell.get_stat('radius'), "attr_label": attr_label('radius')})
				self.draw_string(fmt, panel, cur_x, cur_y, color=attr_colors['radius'].to_tup(), **font_kwargs)
				cur_y += linesize
			if hasattr(spell, 'hp_cost') and spell.get_stat('hp_cost') > 0:
				fmt = (text.STATLINE, {"value": spell.get_stat('hp_cost'), "attr_label": attr_label('hp_cost')})
				self.draw_string(fmt, panel, cur_x, cur_y, color=Tags.Blood.color.to_tup(), **font_kwargs)
				cur_y += linesize
			if spell.get_stat('cool_down') > 0 or spell.cool_down > 0:
				if spell.statholder and spell.statholder != spell.owner: cd = spell.cool_down # for spells granted by the wizard where the wizard is the statholder
				else: cd = spell.get_stat('cool_down') # for spells the creature has innately

				rem_cd = spell.caster.cool_downs.get(spell, 0) if spell.caster else 0
				rem_cd_fmt = Raw('(' + str(rem_cd) + ')') if rem_cd else ""
				fmt = (text.COOLDOWN, {"value": cd, "remaining": rem_cd_fmt})
				self.draw_string(fmt, panel, cur_x, cur_y, **font_kwargs)
				cur_y += linesize

			# Prioritize spell.description so it can be overriden
			grantor = spell.statholder if spell.statholder and spell.statholder is not unit else None
			if grantor:
				desc_str = ("Granted by {name}", {'name': getattr(grantor, 'name', None) or "Unknown"})
				self.draw_string(desc_str, panel, cur_x + indent, cur_y, **font_kwargs)
				cur_y += linesize
			else:
				desc = spell.description or spell.get_description()
				if desc:
					lines = self.draw_wrapped_string(desc, panel, cur_x + indent, cur_y, panel.get_width() - 3 * indent, fmt=spell.fmt_dict(), **font_kwargs)
					cur_y += lines*linesize
			cur_y += linesize

		if unit.flying:
			self.draw_string("Flying", panel, cur_x, cur_y, **font_kwargs)
			cur_y += linesize

		if unit.stationary:
			self.draw_string("Immobile", panel, cur_x, cur_y, **font_kwargs)
			cur_y += linesize

		if unit.burrowing:
			self.draw_string("Burrowing", panel, cur_x, cur_y, **font_kwargs)
			cur_y += linesize

		if unit.flying or unit.stationary or unit.burrowing: cur_y += linesize

		resist_tags = [t for t in Tags if t in unit.resists and unit.resists[t] != 0]
		resist_tags.sort(key = lambda t: -unit.resists[t])

		drew_resist_group = False
		for negative in [False, True]:
			has_resists = False
			for tag in resist_tags:
				if not ((unit.resists[tag] < 0) == negative): continue
				if not has_resists and drew_resist_group: cur_y += linesize  # gap pos / neg resists
				self.draw_string((text.RESIST_VAL, {"val": unit.resists[tag], "tag_label": tag.name}), panel, cur_x, cur_y, color=tag.color.to_tup(), **font_kwargs)
				has_resists = True
				cur_y += linesize
			if has_resists: drew_resist_group = True

		# Unit Passives
		if hasattr(self.examine_target, 'level'): passives = [b for b in self.examine_target.buffs if b.buff_type == BUFF_TYPE_PASSIVE]
		else: passives = self.examine_target.buffs

		width = panel.get_width() - 2 * border_margin # calc buff line position once
		for buff in passives:
			buff_desc = buff.get_tooltip() or buff.name # prefer desc, but fallback to name
			if not buff_desc: continue # nothing to display
			cur_y += linesize
			c = buff.get_tooltip_color()
			buff_color = (c.r, c.g, c.b)
			fmt = buff.fmt_dict() # defaults to {} in base class
			lines = self.draw_wrapped_string(buff_desc, panel, cur_x, cur_y, width, buff_color, fmt=fmt, **font_kwargs)
			cur_y += linesize * lines

		if hasattr(unit, 'level'): status_effects = [b for b in unit.buffs if b.buff_type in [BUFF_TYPE_BLESS, BUFF_TYPE_CURSE]]
		else: status_effects = []

		counts = {}
		for effect in status_effects:
			if effect.name not in counts: counts[effect.name] = (effect, 0, 0, None)
			_, stacks, duration, color = counts[effect.name]
			stacks += 1
			duration = max(duration, effect.turns_left)
			counts[effect.name] = (effect, stacks, duration, effect.get_tooltip_color().to_tup())

		if status_effects:
			cur_y += linesize
			self.draw_string("Status Effects", panel, cur_x, cur_y, color=(255, 255, 255), **font_kwargs)
			cur_y += linesize
			for buff_name, (buff, stacks, duration, color) in counts.items():
				fmt = resolve_text(buff_name)
				if stacks > 1: fmt += ' x%d' % stacks
				if duration: fmt += ' (%d)' % duration
				self.draw_string(fmt, panel, cur_x, cur_y, color=color, mouse_content=buff, pre_resolved=True, **font_kwargs)
				cur_y += linesize

		# overflow check slowly increases shrink_text so the panel settles
		if cur_y > line_limit and shrink_level < self.max_shrink_level:
			unit.shrink_text = min(self.max_shrink_level, shrink_level + 1)

	def get_title_menu_entries(self):
		entries = []
		if self.title_can_continue: entries.extend([TITLE_SELECTION_LOAD, TITLE_SELECTION_ABANDON])
		else: entries.append(TITLE_SELECTION_NEW)

		entries.extend([
			TITLE_SELECTION_OPTIONS,
			TITLE_SELECTION_HELP,
			TITLE_SELECTION_BESTIARY,
			TITLE_SELECTION_DISCORD,
			TITLE_SELECTION_MODS,
			TITLE_SELECTION_CREDITS,
			TITLE_SELECTION_EXIT,
		])
		return entries

	def draw_title(self):

		screen_width = self.screen.get_width()
		screen_height = self.screen.get_height()

		cur_x = screen_width // 2 - SPRITE_SIZE * 2
		cur_y = screen_height // 2 + SPRITE_SIZE * 3

		cur_frame = (cloud_frame_clock // SUB_FRAMES[ANIM_IDLE]) % 4
		self.screen.blit(self.title_frames[cur_frame], (0, 0))

		entries = self.get_title_menu_entries()
		labels = {
			TITLE_SELECTION_LOAD: "CONTINUE RUN",
			TITLE_SELECTION_ABANDON: "ABANDON RUN",
			TITLE_SELECTION_NEW: "NEW GAME",
			TITLE_SELECTION_OPTIONS: "OPTIONS",
			TITLE_SELECTION_HELP: "HOW TO PLAY",
			TITLE_SELECTION_BESTIARY: "BESTIARY",
			TITLE_SELECTION_DISCORD: "DISCORD",
			TITLE_SELECTION_MODS: "MODS",
			TITLE_SELECTION_CREDITS: "CREDITS",
			TITLE_SELECTION_EXIT: "QUIT",
		}
		rect_w = max(self.font.size(text)[0] for text in labels.values())
		cur_x = screen_width // 2 - rect_w // 2

		for option in entries:
			text = labels[option]
			line_w = self.font.size(text)[0]
			self.draw_string(text, self.screen, cur_x, cur_y, (255, 255, 255), mouse_content=option, content_width=line_w)
			cur_y += self.linesize + 2

	def process_title_input(self):
		entries = self.get_title_menu_entries()
		if entries and self.examine_target not in entries and self.examine_target is not None:
			self.examine_target = entries[0]

		selection = None
		m_loc = self.get_mouse_pos()

		for evt in self.events:
			if evt.type == pygame.KEYDOWN:

				if evt.key in self.key_binds[KEY_BIND_CONFIRM]:
					self.play_sound('menu_confirm')
					selection = self.examine_target
					continue

				if entries and evt.key in self.key_binds[KEY_BIND_UP]:
					if self.examine_target not in entries: self.examine_target = entries[0]
					else:
						idx = entries.index(self.examine_target)
						self.examine_target = entries[(idx - 1) % len(entries)]
					self.play_sound('menu_confirm')
					continue

				if entries and evt.key in self.key_binds[KEY_BIND_DOWN]:
					if self.examine_target not in entries: self.examine_target = entries[0]
					else:
						idx = entries.index(self.examine_target)
						self.examine_target = entries[(idx + 1) % len(entries)]
					self.play_sound('menu_confirm')
					continue

			if evt.type == pygame.MOUSEBUTTONDOWN and evt.button == pygame.BUTTON_LEFT:
				for rect, option in self.ui_rects:
					if rect.collidepoint(m_loc):
						self.play_sound('menu_confirm')
						self.examine_target = option
						selection = option
						break

		dx, dy = self.get_mouse_rel()
		if abs(dx) + abs(dy) > 1:
			hovered = None
			for rect, option in self.ui_rects:
				if rect.collidepoint(m_loc):
					hovered = option
					break

			if hovered is not None:
				if self.examine_target != hovered: self.play_sound("menu_confirm")
				self.examine_target = hovered
			else: self.examine_target = None

		if selection == TITLE_SELECTION_NEW:
			self.state = STATE_PICK_MODE
			self.examine_target = 0
		elif selection == TITLE_SELECTION_ABANDON:
			self.open_abandon_prompt()
		elif selection == TITLE_SELECTION_OPTIONS:
			self.open_options()
		elif selection == TITLE_SELECTION_LOAD:
			if can_continue_game():
				self.load_game()
		elif selection == TITLE_SELECTION_HELP:
			self.show_help()
		elif selection == TITLE_SELECTION_DISCORD:
			import webbrowser
			webbrowser.open("https://discord.gg/NngFZ7B")
		elif selection == TITLE_SELECTION_MODS:
			self.open_mods()
		elif selection == TITLE_SELECTION_CREDITS:
			self.show_credits()
		elif selection == TITLE_SELECTION_EXIT:
			self.running = False
		elif selection == TITLE_SELECTION_BESTIARY:
			SteamAdapter.check_bestiary_ach()
			self.open_shop(SHOP_TYPE_BESTIARY)

	def refresh_mod_menu(self):
		previous_enabled = list(self.options['enabled_mods'])
		self.mods_menu_catalog = ModHandler.discover_mods()
		self.mods_menu_catalog_by_name = {mod['mod_name']: mod for mod in self.mods_menu_catalog}

		enabled_mods = []
		seen_mod_names = set()
		for mod_name in previous_enabled:
			if mod_name in seen_mod_names: continue
			enabled_mods.append(mod_name)
			seen_mod_names.add(mod_name)

		self.options['enabled_mods'] = enabled_mods
		self.mods_menu_disabled_names = [mod['mod_name'] for mod in self.mods_menu_catalog if mod['mod_name'] not in seen_mod_names]
		self.mods_menu_disabled_page = min(self.mods_menu_disabled_page, self.get_mod_menu_page_count('disabled') - 1)
		self.mods_menu_enabled_page = min(self.mods_menu_enabled_page, self.get_mod_menu_page_count('enabled') - 1)
		return previous_enabled != enabled_mods

	def get_mod_menu_actions(self):
		actions = [MOD_MENU_BROWSE, MOD_MENU_UPLOAD]
		if self.is_mod_menu_dirty():
			actions.extend([MOD_MENU_RESET, MOD_MENU_RESTART])
		else:
			actions.append(MOD_MENU_BACK)
		return actions

	def is_mod_menu_dirty(self):
		if self.mods_menu_enabled_on_boot is None:
			return False
		return self.options['enabled_mods'] != self.mods_menu_enabled_on_boot

	def get_mod_menu_positions(self, enabled_names, disabled_names):
		positions = {}
		for i, mod_name in enumerate(disabled_names):
			positions[mod_name] = ('disabled', i)
		for i, mod_name in enumerate(enabled_names):
			positions[mod_name] = ('enabled', i)
		return positions

	def reset_mod_menu_to_boot(self):
		if self.mods_menu_enabled_on_boot is None:
			return
		self.options['enabled_mods'] = list(self.mods_menu_enabled_on_boot)
		self.save_options()
		self.refresh_mod_menu()
		self.mods_menu_status = ""
		self.set_mod_menu_focus('actions', MOD_MENU_BACK)

	def restart_modded_game(self):
		self.play_sound('menu_confirm')
		self.save_options()
		if getattr(sys, 'frozen', False): args = [sys.executable] + sys.argv[1:]
		else: args = [sys.executable] + sys.argv
		os.execv(args[0], args)

	def get_active_mod_menu_group(self):
		if self.mods_menu_upload_selecting:
			return 'upload'
		target_group = self.get_mod_menu_target_group(self.examine_target)
		if target_group:
			return target_group
		return self.mods_menu_group

	def get_mod_menu_target_group(self, target):
		if self.mods_menu_upload_selecting:
			return 'upload'
		if target in self.options['enabled_mods']:
			return 'enabled'
		if target in self.mods_menu_disabled_names:
			return 'disabled'
		if target in self.get_mod_menu_actions():
			return 'actions'
		return None

	def get_mod_menu_rows_per_page(self):
		top_y = self.linesize * 4
		bottom_y = self.screen.get_height() - self.linesize * 10
		available = bottom_y - top_y
		return max(1, available // self.linesize)

	def get_mod_menu_page_count(self, group):
		if group not in ('disabled', 'enabled'):
			return 1
		entries = self.mods_menu_disabled_names if group == 'disabled' else self.options['enabled_mods']
		rows = self.get_mod_menu_rows_per_page()
		return max(1, math.ceil(len(entries) / rows))

	def get_mod_menu_page_bounds(self, group):
		rows = self.get_mod_menu_rows_per_page()
		total_pages = self.get_mod_menu_page_count(group)
		if group == 'disabled':
			self.mods_menu_disabled_page = max(0, min(total_pages - 1, self.mods_menu_disabled_page))
			page = self.mods_menu_disabled_page
			entries = self.mods_menu_disabled_names
		else:
			self.mods_menu_enabled_page = max(0, min(total_pages - 1, self.mods_menu_enabled_page))
			page = self.mods_menu_enabled_page
			entries = self.options['enabled_mods']
		start_idx = page * rows
		end_idx = min(start_idx + rows, len(entries))
		return rows, total_pages, start_idx, end_idx

	def adjust_mod_menu_page(self, group, delta):
		if group == 'disabled':
			total_pages = self.get_mod_menu_page_count('disabled')
			new_page = max(0, min(total_pages - 1, self.mods_menu_disabled_page + delta))
			if new_page == self.mods_menu_disabled_page: return False
			self.mods_menu_disabled_page = new_page
			return True
		if group == 'enabled':
			total_pages = self.get_mod_menu_page_count('enabled')
			new_page = max(0, min(total_pages - 1, self.mods_menu_enabled_page + delta))
			if new_page == self.mods_menu_enabled_page: return False
			self.mods_menu_enabled_page = new_page
			return True
		return False

	def get_mod_menu_group_entries(self, group):
		if group == 'upload':
			return list(self.mods_menu_upload_options) + [MOD_MENU_UPLOAD_CANCEL]
		if group == 'disabled':
			rows, total_pages, start_idx, end_idx = self.get_mod_menu_page_bounds('disabled')
			return self.mods_menu_disabled_names[start_idx:end_idx]
		if group == 'enabled':
			rows, total_pages, start_idx, end_idx = self.get_mod_menu_page_bounds('enabled')
			return self.options['enabled_mods'][start_idx:end_idx]
		if group == 'actions':
			return self.get_mod_menu_actions()
		return []

	def get_default_mod_menu_target(self):
		if self.mods_menu_upload_selecting:
			entries = self.get_mod_menu_group_entries('upload')
			return entries[0] if entries else MOD_MENU_UPLOAD_CANCEL
		if self.mods_menu_disabled_names:
			return self.mods_menu_disabled_names[0]
		if self.options['enabled_mods']:
			return self.options['enabled_mods'][0]
		return MOD_MENU_BROWSE

	def set_mod_menu_focus(self, group, target=None):
		self.mods_menu_group = group
		if group == 'actions':
			actions = self.get_mod_menu_actions()
			if target in actions:
				self.mods_menu_action_target = target
			elif self.mods_menu_action_target not in actions:
				self.mods_menu_action_target = actions[0]
			self.examine_target = self.mods_menu_action_target
			return
		if group == 'disabled':
			if target and target in self.mods_menu_disabled_names:
				rows = self.get_mod_menu_rows_per_page()
				self.mods_menu_disabled_page = self.mods_menu_disabled_names.index(target) // rows
				self.examine_target = target
				return
			entries = self.get_mod_menu_group_entries('disabled')
			self.examine_target = entries[0] if entries else None
			return
		if group == 'enabled':
			if target and target in self.options['enabled_mods']:
				rows = self.get_mod_menu_rows_per_page()
				self.mods_menu_enabled_page = self.options['enabled_mods'].index(target) // rows
				self.examine_target = target
				return
			entries = self.get_mod_menu_group_entries('enabled')
			self.examine_target = entries[0] if entries else None
			return

	def move_mod_menu_vertical(self, delta):
		group = self.get_active_mod_menu_group()
		if group == 'upload':
			entries = self.get_mod_menu_group_entries('upload')
			if not entries: return False
			if self.examine_target not in entries:
				self.examine_target = entries[0] if delta >= 0 else entries[-1]
				return True
			idx = entries.index(self.examine_target)
			self.examine_target = entries[(idx + delta) % len(entries)]
			return True
		if group not in ('disabled', 'enabled'): return False
		entries = self.get_mod_menu_group_entries(group)
		if not entries: return False

		if self.get_mod_menu_target_group(self.examine_target) != group or self.examine_target not in entries:
			target = entries[0] if delta >= 0 else entries[-1]
			self.set_mod_menu_focus(group, target)
			return True

		idx = entries.index(self.examine_target)
		if delta < 0:
			if idx > 0:
				self.set_mod_menu_focus(group, entries[idx - 1])
				return True
			if self.adjust_mod_menu_page(group, -1):
				entries = self.get_mod_menu_group_entries(group)
				if entries: self.set_mod_menu_focus(group, entries[-1])
				return True
			self.set_mod_menu_focus(group, entries[-1])
			return True

		if idx + 1 < len(entries):
			self.set_mod_menu_focus(group, entries[idx + 1])
			return True
		if self.adjust_mod_menu_page(group, +1):
			entries = self.get_mod_menu_group_entries(group)
			if entries: self.set_mod_menu_focus(group, entries[0])
			return True
		self.set_mod_menu_focus(group, entries[0])
		return True

	def move_mod_menu_horizontal(self, delta):
		group = self.get_active_mod_menu_group()
		actions = self.get_mod_menu_actions()
		first_action = actions[0]
		last_action = actions[-1]

		if group == 'upload': return False

		if group == 'disabled':
			if delta < 0:
				if self.options['enabled_mods']:
					self.set_mod_menu_focus('enabled')
				else:
					self.set_mod_menu_focus('actions', last_action)
			else:
				self.set_mod_menu_focus('actions', first_action)
			return True

		if group == 'enabled':
			if delta > 0:
				if self.mods_menu_disabled_names:
					self.set_mod_menu_focus('disabled')
				else:
					self.set_mod_menu_focus('actions', first_action)
			else:
				self.set_mod_menu_focus('actions', last_action)
			return True

		if group != 'actions':
			if self.mods_menu_group == 'enabled' and self.options['enabled_mods']:
				self.set_mod_menu_focus('enabled')
			elif self.mods_menu_group == 'disabled' and self.mods_menu_disabled_names:
				self.set_mod_menu_focus('disabled')
			else:
				self.set_mod_menu_focus('actions', self.mods_menu_action_target)
			return True

		action = self.mods_menu_action_target if self.mods_menu_action_target in actions else actions[0]
		idx = actions.index(action)

		if delta < 0:
			if idx > 0:
				self.set_mod_menu_focus('actions', actions[idx - 1])
			elif self.mods_menu_disabled_names:
				self.set_mod_menu_focus('disabled')
			elif self.options['enabled_mods']:
				self.set_mod_menu_focus('enabled')
			return True

		if idx + 1 < len(actions):
			self.set_mod_menu_focus('actions', actions[idx + 1])
		elif self.options['enabled_mods']:
			self.set_mod_menu_focus('enabled')
		elif self.mods_menu_disabled_names:
			self.set_mod_menu_focus('disabled')
		return True

	def get_mod_source_text(self, mod_name):
		mod = self.mods_menu_catalog_by_name.get(mod_name)
		if not mod:
			return ""
		if mod['has_local'] and mod['has_workshop']:
			return "Source: Local (Workshop copy also installed)"
		if mod['has_local']:
			return "Source: Local"
		workshop_mod = mod['workshop'][0]
		return "Source: Workshop %s" % workshop_mod['workshop_item_id']

	def draw_mods_menu(self):
		if self.mods_menu_upload_selecting:
			entries = self.get_mod_menu_group_entries('upload')
			texts = {option: option for option in self.mods_menu_upload_options}
			texts[MOD_MENU_UPLOAD_CANCEL] = "BACK"
			title = "SELECT MOD TO UPLOAD"
			rect_w = max(self.font.size(title)[0], max(self.font.size(texts[option])[0] for option in entries))
			cur_x = self.screen.get_width() // 2 - rect_w // 2
			cur_y = self.screen.get_height() // 2 - self.linesize * 3

			self.draw_string(title, self.screen, cur_x, cur_y, center=True, content_width=rect_w)
			cur_y += self.linesize * 2

			for option in entries:
				text = texts[option]
				line_w = self.font.size(text)[0]
				self.draw_string(text, self.screen, cur_x, cur_y, (255, 255, 255), mouse_content=option, content_width=line_w)
				cur_y += self.linesize + 2

			if self.mods_menu_status:
				status_y = self.screen.get_height() // 2 + self.linesize * 4
				for line in self.mods_menu_status.split('\n'):
					if line:
						self.draw_string(line, self.screen, 0, status_y, center=True, content_width=self.screen.get_width())
					status_y += self.linesize
			return

		col_w = self.screen.get_width() // 5
		line_height = self.linesize
		left_x = col_w
		right_x = col_w * 4
		title_y = self.linesize
		list_y = self.linesize * 4
		actions_y = self.screen.get_height() - self.linesize * 5
		detail_bottom_y = actions_y - line_height * 2
		detail_width = self.screen.get_width() - self.linesize * 4
		status_base_y = actions_y + line_height
		disabled_entries = self.get_mod_menu_group_entries('disabled')
		enabled_entries = self.get_mod_menu_group_entries('enabled')
		open_positions = self.get_mod_menu_positions(self.mods_menu_enabled_on_open, self.mods_menu_disabled_on_open)
		current_positions = self.get_mod_menu_positions(self.options['enabled_mods'], self.mods_menu_disabled_names)
		_, disabled_pages, _, _ = self.get_mod_menu_page_bounds('disabled')
		_, enabled_pages, _, _ = self.get_mod_menu_page_bounds('enabled')

		self.draw_string("MODS", self.screen, 0, title_y, center=True, content_width=self.screen.get_width())
		self.draw_string("DISABLED", self.screen, left_x, list_y - line_height * 2, center=True, content_width=col_w)
		self.draw_string("ENABLED", self.screen, right_x - col_w, list_y - line_height * 2, center=True, content_width=col_w)
		if disabled_pages > 1:
			self.draw_string("%d/%d" % (self.mods_menu_disabled_page + 1, disabled_pages), self.screen, left_x, list_y - line_height, center=True, content_width=col_w)
		if enabled_pages > 1:
			self.draw_string("%d/%d" % (self.mods_menu_enabled_page + 1, enabled_pages), self.screen, right_x - col_w, list_y - line_height, center=True, content_width=col_w)

		cur_y = list_y
		for mod_name in disabled_entries:
			line_w = self.font.size(mod_name)[0]
			cur_color = (0, 255, 0) if open_positions.get(mod_name) != current_positions.get(mod_name) else (255, 255, 255)
			self.draw_string(mod_name, self.screen, left_x, cur_y, cur_color, mouse_content=mod_name, content_width=line_w)
			cur_y += line_height

		cur_y = list_y
		for mod_name in enabled_entries:
			line_w = self.font.size(mod_name)[0]
			x = right_x - line_w
			cur_color = (0, 255, 0) if open_positions.get(mod_name) != current_positions.get(mod_name) else (255, 255, 255)
			self.draw_string(mod_name, self.screen, x, cur_y, cur_color, mouse_content=mod_name, content_width=line_w)
			cur_y += line_height

		action_entries = self.get_mod_menu_actions()
		action_texts = {
			MOD_MENU_BROWSE: "BROWSE WORKSHOP",
			MOD_MENU_UPLOAD: "UPLOAD MOD",
			MOD_MENU_BACK: "BACK",
			MOD_MENU_RESET: "RESET",
			MOD_MENU_RESTART: "RESTART",
		}
		pad_w = cached_size(self.font, "   ")
		total_w = sum(cached_size(self.font, action_texts[action]) for action in action_entries) + pad_w * (len(action_entries) - 1)
		cur_x = self.screen.get_width() // 2 - total_w // 2
		for i, action in enumerate(action_entries):
			text = action_texts[action]
			line_w = cached_size(self.font, text)
			self.draw_string(text, self.screen, cur_x, actions_y, (255, 255, 255), mouse_content=action, content_width=line_w, pre_resolved=True)
			cur_x += line_w
			if i < len(action_entries) - 1:
				cur_x += pad_w

		detail_load_error_summary = ""
		detail_text = ""
		if self.examine_target in self.mods_menu_catalog_by_name:
			mod_name = self.examine_target
			mod = self.mods_menu_catalog_by_name[mod_name]
			loaded_mod_names = {mod['mod_name'] for mod in ModHandler.get_loaded_mods()}
			detail_load_error_summary = ModHandler.get_load_error_summary_for_mod(mod_name)
			detail_text = '\n'.join([
				self.get_mod_source_text(mod_name),
				"Loaded this run: %s" % ("Yes" if mod_name in loaded_mod_names else "No"),
			])
			if detail_load_error_summary:
				detail_text += '\n\n' + detail_load_error_summary
			elif mod['description']:
				detail_text += '\n\n' + mod['description']
		elif self.examine_target in self.options['enabled_mods']:
			detail_text = "Unavailable this run.\nThe mod may still be downloading or may no longer be installed.\nDisable it to remove it from the enabled list."
		elif self.examine_target == MOD_MENU_BROWSE:
			detail_text = "Open the Steam Workshop page."
		elif self.examine_target == MOD_MENU_UPLOAD:
			detail_text = "Upload a local mod to Workshop."
		elif self.examine_target == MOD_MENU_BACK:
			detail_text = "Return to the title screen."
		elif self.examine_target == MOD_MENU_RESET:
			detail_text = "Reset mods to the current run's starting layout."
		elif self.examine_target == MOD_MENU_RESTART:
			detail_text = "Restart the game to apply the current mod layout."

		if detail_text:
			self.draw_wrapped_string(detail_text, self.screen, self.linesize * 2, 0, detail_width, center=True, indent=False, pre_resolved=True, bottom_y=detail_bottom_y)

		status_y = status_base_y
		if ModHandler.get_load_error_count():
			self.draw_string("Load errors: %d" % ModHandler.get_load_error_count(), self.screen, 0, status_y, center=True, content_width=self.screen.get_width())
			status_y += line_height

		status_load_error_summary = ""
		if not detail_load_error_summary:
			status_load_error_summary = ModHandler.get_first_load_error_summary()
		if status_load_error_summary:
			self.draw_string(status_load_error_summary, self.screen, 0, status_y, center=True, content_width=self.screen.get_width())
			status_y += line_height

		if self.mods_menu_status:
			for line in self.mods_menu_status.split('\n'):
				if line:
					self.draw_string(line, self.screen, 0, status_y, center=True, content_width=self.screen.get_width())
				status_y += line_height

	def write_mod_uploader_crash_log(self):
		import traceback

		with open('uploader_crash.txt', 'w', encoding='utf-8') as file:
			file.write("Rift Wizard 3 Workshop uploader crash log\n\n")
			traceback.print_exc(file=file)

	def open_mod_upload_picker(self):
		try:
			import UploadModToWorkshop
			self.mods_menu_upload_options = list(UploadModToWorkshop.get_local_mod_roots().keys())
			if not self.mods_menu_upload_options:
				self.mods_menu_status = "No valid mod folders found in mods."
				return
			self.mods_menu_status = ""
			self.mods_menu_upload_selecting = True
			self.mods_menu_group = 'upload'
			self.examine_target = self.mods_menu_upload_options[0]
		except Exception:
			self.write_mod_uploader_crash_log()
			self.mods_menu_status = "Could not read local mods.\nSee uploader_crash.txt."

	def close_mod_upload_picker(self):
		self.mods_menu_upload_selecting = False
		self.mods_menu_upload_options = []
		self.set_mod_menu_focus('actions', MOD_MENU_UPLOAD)

	def enable_mod(self, mod_name):
		if mod_name in self.options['enabled_mods']:
			return
		self.options['enabled_mods'].append(mod_name)
		self.save_options()
		self.refresh_mod_menu()
		self.set_mod_menu_focus('enabled', mod_name)

	def disable_mod(self, mod_name):
		if mod_name not in self.options['enabled_mods']:
			return
		self.options['enabled_mods'].remove(mod_name)
		self.save_options()
		self.refresh_mod_menu()
		self.set_mod_menu_focus('disabled', mod_name)

	def adjust_mod_order(self, amt):
		mod_name = self.examine_target
		if mod_name not in self.options['enabled_mods']:
			return False
		cur_index = self.options['enabled_mods'].index(mod_name)
		new_index = cur_index + amt
		if new_index < 0 or new_index >= len(self.options['enabled_mods']):
			return False
		self.options['enabled_mods'][cur_index], self.options['enabled_mods'][new_index] = self.options['enabled_mods'][new_index], self.options['enabled_mods'][cur_index]
		self.save_options()
		self.set_mod_menu_focus('enabled', mod_name)
		return True

	def launch_mod_uploader(self, mod_name):
		import traceback

		try:
			import UploadModToWorkshop
			mod = UploadModToWorkshop.get_local_mod_root(mod_name)
			result = UploadModToWorkshop.run_uploader_with_crash_log(mod=mod)
			if result['ok']:
				self.mods_menu_status = "Workshop upload complete.\nItem ID: %s" % result['published_file_id']
			else:
				self.mods_menu_status = "Workshop upload failed.\nSee uploader_crash.txt."
		except Exception:
			with open('uploader_crash.txt', 'w', encoding='utf-8') as file:
				file.write("Rift Wizard 3 Workshop uploader crash log\n\n")
				traceback.print_exc(file=file)
			self.mods_menu_status = "Workshop upload failed.\nSee uploader_crash.txt."
		self.refresh_mod_menu()
		self.close_mod_upload_picker()

	def process_mods_input(self):
		selection = None
		m_loc = self.get_mouse_pos()
		modifier_held = pygame.key.get_mods() & pygame.KMOD_SHIFT

		for evt in self.events:
			if evt.type == pygame.KEYDOWN:

				if evt.key in self.key_binds[KEY_BIND_CONFIRM]:
					self.play_sound('menu_confirm')
					selection = self.examine_target
					continue

				if evt.key in self.key_binds[KEY_BIND_ABORT]:
					self.play_sound('menu_abort')
					if self.mods_menu_upload_selecting: self.close_mod_upload_picker()
					elif self.is_mod_menu_dirty(): self.set_mod_menu_focus('actions', MOD_MENU_RESTART)
					else: self.return_to_title()
					return

				if evt.key in self.key_binds[KEY_BIND_UP]:
					if not self.mods_menu_upload_selecting and modifier_held and self.examine_target in self.options['enabled_mods']:
						if self.adjust_mod_order(-1): self.play_sound('menu_confirm')
						continue
					if self.move_mod_menu_vertical(-1): self.play_sound('menu_confirm')
					continue

				if evt.key in self.key_binds[KEY_BIND_DOWN]:
					if not self.mods_menu_upload_selecting and modifier_held and self.examine_target in self.options['enabled_mods']:
						if self.adjust_mod_order(+1): self.play_sound('menu_confirm')
						continue
					if self.move_mod_menu_vertical(+1): self.play_sound('menu_confirm')
					continue

				if not self.mods_menu_upload_selecting and evt.key in self.key_binds[KEY_BIND_LEFT]:
					if self.move_mod_menu_horizontal(-1): self.play_sound('menu_confirm')
					continue

				if not self.mods_menu_upload_selecting and evt.key in self.key_binds[KEY_BIND_RIGHT]:
					if self.move_mod_menu_horizontal(+1): self.play_sound('menu_confirm')
					continue

			if evt.type == pygame.MOUSEBUTTONDOWN:
				if evt.button == pygame.BUTTON_LEFT:
					for rect, option in self.ui_rects:
						if rect.collidepoint(m_loc):
							self.play_sound('menu_confirm')
							target_group = self.get_mod_menu_target_group(option)
							if target_group == 'actions':
								self.mods_menu_action_target = option
							if target_group:
								self.mods_menu_group = target_group
							self.examine_target = option
							selection = option
							break
				elif evt.button == pygame.BUTTON_RIGHT:
					self.play_sound('menu_abort')
					if self.mods_menu_upload_selecting: self.close_mod_upload_picker()
					elif self.is_mod_menu_dirty(): self.set_mod_menu_focus('actions', MOD_MENU_RESTART)
					else: self.return_to_title()
					return

		dx, dy = self.get_mouse_rel()
		if dx or dy:
			hovered = None
			for rect, option in self.ui_rects:
				if rect.collidepoint(m_loc):
					hovered = option
					break

			if hovered is not None:
				if self.examine_target != hovered: self.play_sound("menu_confirm")
				target_group = self.get_mod_menu_target_group(hovered)
				if target_group == 'actions':
					self.mods_menu_action_target = hovered
				if target_group:
					self.mods_menu_group = target_group
				self.examine_target = hovered

		if selection == MOD_MENU_BROWSE:
			import webbrowser
			webbrowser.open("https://steamcommunity.com/app/4366330/workshop/")
		elif selection == MOD_MENU_UPLOAD:
			self.open_mod_upload_picker()
		elif selection == MOD_MENU_UPLOAD_CANCEL:
			self.close_mod_upload_picker()
		elif selection == MOD_MENU_BACK and not self.is_mod_menu_dirty():
			self.return_to_title()
		elif selection == MOD_MENU_RESET:
			self.reset_mod_menu_to_boot()
		elif selection == MOD_MENU_RESTART:
			self.restart_modded_game()
		elif selection in self.mods_menu_upload_options:
			self.launch_mod_uploader(selection)
		elif selection in self.mods_menu_disabled_names:
			self.enable_mod(selection)
		elif selection in self.options['enabled_mods']:
			self.disable_mod(selection)

	def draw_pick_mode(self):
		opts = [("NORMAL GAME", GAME_MODE_NORMAL),
				("ARCHMAGE TRIALS", GAME_MODE_TRIALS),
				("WEEKLY RUN", GAME_MODE_WEEKLY),
				("MUTATED RUN", GAME_MODE_RANDOM),
				("CUSTOM RUN", GAME_MODE_CUSTOM)]

		rect_w = max(self.font.size(t)[0] for t, _ in opts)
		cur_x = self.screen.get_width() // 2 - rect_w // 2
		cur_y = self.screen.get_height() // 2 - self.linesize * 4

		cur_color = (255, 255, 255)
		for t, o in opts:

			cur_color = (255, 255, 255)

			line_w = self.font.size(t)[0]
			self.draw_string(t, self.screen, cur_x, cur_y, cur_color, mouse_content=o, content_width=line_w)
			if ((o == GAME_MODE_NORMAL and SteamAdapter.get_stat('w')) or
			   (o == GAME_MODE_WEEKLY and SteamAdapter.get_trial_status(get_weekly_name())) or
			   (o == GAME_MODE_TRIALS and all(SteamAdapter.get_trial_status(t.name) for t in all_trials))):
				self.draw_string("*", self.screen, cur_x - 16, cur_y, COLOR_VICTORY)

			cur_y += self.linesize

	def process_pick_mode_input(self):
		options = [
			GAME_MODE_NORMAL,
			GAME_MODE_TRIALS,
			GAME_MODE_WEEKLY,
			GAME_MODE_RANDOM,
			GAME_MODE_CUSTOM,
		]

		selection = None
		m_loc = self.get_mouse_pos()

		for evt in self.events:
			if evt.type == pygame.KEYDOWN:

				if evt.key in self.key_binds[KEY_BIND_CONFIRM]:
					self.play_sound('menu_confirm')
					selection = self.examine_target
					continue

				if evt.key in self.key_binds[KEY_BIND_UP]:
					self.play_sound('menu_confirm')
					if self.examine_target not in options:
						self.examine_target = options[0]
					else:
						idx = options.index(self.examine_target)
						self.examine_target = options[(idx - 1) % len(options)]
					continue

				if evt.key in self.key_binds[KEY_BIND_DOWN]:
					self.play_sound('menu_confirm')
					if self.examine_target not in options:
						self.examine_target = options[0]
					else:
						idx = options.index(self.examine_target)
						self.examine_target = options[(idx + 1) % len(options)]
					continue

				if evt.key in self.key_binds[KEY_BIND_ABORT]:
					self.play_sound('menu_abort')
					self.return_to_title()
					continue

			if evt.type == pygame.MOUSEBUTTONDOWN:

				if evt.button == pygame.BUTTON_LEFT:
					for r, o in self.ui_rects:
						if r.collidepoint(m_loc):
							self.play_sound('menu_confirm')
							selection = o
							break
					else:
						self.play_sound('menu_abort')

				if evt.button == pygame.BUTTON_RIGHT:
					self.return_to_title()
					self.play_sound('menu_abort')

		dx, dy = self.get_mouse_rel()
		if dx or dy:
			for r, o in self.ui_rects:
				if r.collidepoint(m_loc):
					if self.examine_target != o: self.play_sound('menu_confirm')
					self.examine_target = o
					break

		if selection == GAME_MODE_NORMAL:
			self.new_game()
		if selection == GAME_MODE_TRIALS:
			self.state = STATE_PICK_TRIAL
			self.examine_target = all_trials[0]
		if selection == GAME_MODE_WEEKLY:
			self.new_game(mutators=get_random_mutators(weekly=True), trial_name=get_weekly_name(),  seed=get_weekly_seed())
		if selection == GAME_MODE_RANDOM:
			self.new_game(mutators=get_random_mutators(), trial_name="MUTATED_RUN")
		if selection == GAME_MODE_CUSTOM:
			self.restore_custom_mutator_setup()
			self.return_to_custom_mutator_setup(None)

	def get_custom_mutator_rows_per_page(self):
		top_y = self.linesize * 4
		bottom_y = self.screen.get_height() - self.linesize * 10
		available = bottom_y - top_y
		return max(1, available // self.linesize)

	def get_custom_mutator_page_count(self):
		rows = self.get_custom_mutator_rows_per_page()
		return max(1, math.ceil(len(all_mutators) / rows))

	def custom_mutator_page_adjust(self, delta):
		total = self.get_custom_mutator_page_count()
		new_page = (self.custom_mutator_page + delta) % total
		if new_page == self.custom_mutator_page: return False
		self.custom_mutator_page = new_page
		return True

	def get_custom_mutator_page_bounds(self):
		rows = self.get_custom_mutator_rows_per_page()
		total = self.get_custom_mutator_page_count()
		if self.custom_mutator_page >= total: self.custom_mutator_page = total - 1
		if self.custom_mutator_page < 0: self.custom_mutator_page = 0
		start_idx = self.custom_mutator_page * rows
		end_idx = min(start_idx + rows, len(all_mutators))
		return rows, total, start_idx, end_idx

	def draw_setup_custom(self):
		self.ui_rects = []
		col_w = self.screen.get_width() // 5
		line_height = self.linesize
		rows, total_pages, start_idx, end_idx = self.get_custom_mutator_page_bounds()

		# Draw mutators (column 2)
		x_all = col_w
		y = self.linesize * 4
		list_max_w = 0
		for mut in all_mutators[start_idx:end_idx]:
			name = mut.name if not isinstance(mut, type) else mut.__name__
			w = self.font.size(name)[0]
			if w > list_max_w: list_max_w = w
			x = x_all
			self.draw_string(name, self.screen, x, y, (255, 255, 255), mouse_content=mut, content_width=w)
			self.ui_rects.append((pygame.Rect(x, y, w, line_height), mut))
			y += line_height

		# Mutator page controls (column 2)
		if total_pages > 1:
			desc_y = self.screen.get_height() - self.linesize * 9
			page_y = desc_y - line_height
			cur = self.custom_mutator_page + 1
			prev_text = "<<<< PGUP"
			label_text = f"{cur}/{total_pages}"
			next_text = "PGDN >>>>"
			pad_w = cached_size(self.font, " ")
			prev_w = cached_size(self.font, prev_text)
			label_w = cached_size(self.font, label_text)
			next_w = cached_size(self.font, next_text)
			control_w = prev_w + pad_w + label_w + pad_w + next_w
			content_w = max(col_w, list_max_w, control_w)
			cur_x = x_all + (content_w - control_w) // 2

			self.draw_string(prev_text, self.screen, cur_x, page_y, mouse_content="mut_prev", pre_resolved=True)
			cur_x += prev_w + pad_w
			self.draw_string(label_text, self.screen, cur_x, page_y, pre_resolved=True)
			cur_x += label_w + pad_w
			self.draw_string(next_text, self.screen, cur_x, page_y, mouse_content="mut_next", pre_resolved=True)

		# Draw Play Button (column 3)
		x_play = col_w * 2 + col_w // 2
		label = "Play"
		label_w = self.font.size(label)[0]
		x = x_play - label_w // 2
		y = self.screen.get_height() - line_height * 4

		self.draw_string(label, self.screen, x, y, (255, 255, 255), mouse_content="play")
		self.ui_rects.append((pygame.Rect(x, y, label_w, self.linesize), "play"))

		# Draw configured mutators (column 4)
		x_custom = col_w * 4
		y = self.linesize * 4

		for mut, args in zip(self.custom_mutators, self.custom_mutator_args):
			arg_strs = [self.format_param_value(arg) for arg in args]
			name = f"{mut.__class__.__name__} " + " ".join(f"({s})" for s in arg_strs)

			w = self.font.size(name)[0]
			x = x_custom - w
			self.draw_string(name, self.screen, x, y, (255, 255, 255), mouse_content=mut, content_width=w)
			self.ui_rects.append((pygame.Rect(x, y, w, line_height), mut))
			y += line_height

		# Draw description (center column)
		if self.examine_target in self.custom_mutators or self.examine_target in all_mutators:
			if self.examine_target in self.custom_mutators:
				description = resolve_text(self.examine_target.get_description(), fmt=self.examine_target.fmt_dict())
				description = self.get_plain_mutator_text(description)
			else:
				description = self.get_placeholder_description(self.examine_target)
			desc_lines = description.split('\n')
			y = self.screen.get_height() - line_height * 8

			for line in desc_lines:
				x = (self.screen.get_width() // 2) - (self.font.size(line)[0] // 2)
				self.draw_string(line, self.screen, x, y, pre_resolved=True)
				y += line_height

	def get_plain_mutator_text(self, description):
		parts = []
		for kind, *values in self.tokenize(description):
			if kind == 'markup':
				parts.append(values[0].replace('_', ' ') + (values[2] or ''))
			else:
				parts.append(values[0])
		return ''.join(parts)

	def get_placeholder_description(self, mutator_class):
		temp_instance = self.create_placeholder_instance(mutator_class)
		raw_description = resolve_text(temp_instance.get_description() or "No Description", fmt=temp_instance.fmt_dict())

		if mutator_class in mutators_with_vals or mutator_class in mutators_with_params_and_vals:
			dummy_val = 25
			raw_description = raw_description.replace(str(dummy_val), 'X')

		if mutator_class in mutators_with_params:
			dummy_param = self.get_dummy_param(mutator_class)
			if dummy_param is not None:
				if callable(dummy_param):
					try:
						dummy_instance = dummy_param()
						param_str = getattr(dummy_instance, 'name', str(dummy_instance))
					except Exception:
						param_str = None
				else:
					param_str = getattr(dummy_param, 'name', str(dummy_param))
				if param_str:
					raw_description = raw_description.replace(str(param_str), 'X')

		return self.get_plain_mutator_text(raw_description)

	def create_placeholder_instance(self, mutator_class):
		if mutator_class in mutators_with_no_args:
			return mutator_class()
		elif mutator_class in mutators_with_vals:
			return mutator_class(25)
		elif mutator_class in mutators_with_params:
			dummy_param = self.get_dummy_param(mutator_class)
			if mutator_class in mutators_with_params_and_vals:
				return mutator_class(dummy_param, 25)
			return mutator_class(dummy_param)
		return None

	def get_dummy_param(self, mutator_class):
		opts = mutator_param_options.get(mutator_class)
		if not opts:
			return None
		return opts[0]

	def move_custom_mutator_vertical(self, delta, page_start, page_end):
		available = all_mutators[page_start:page_end]
		if not available: return False
		if self.examine_target in available:
			index = available.index(self.examine_target)
			self.examine_target = available[(index + delta) % len(available)]
			return True
		if self.examine_target in self.custom_mutators:
			index = self.custom_mutators.index(self.examine_target)
			self.examine_target = self.custom_mutators[(index + delta) % len(self.custom_mutators)]
			return True
		if self.examine_target == "play": return False
		self.examine_target = available[0]
		return True

	def move_custom_mutator_horizontal(self, delta, page_start, page_end):
		available = all_mutators[page_start:page_end]
		if not available: return False
		if self.examine_target not in available and self.examine_target not in self.custom_mutators and self.examine_target != "play":
			self.examine_target = available[0]
			return True

		if delta < 0:
			if self.examine_target in self.custom_mutators:
				self.examine_target = "play"
			elif self.examine_target == "play":
				self.examine_target = available[0]
			else:
				self.examine_target = self.custom_mutators[0] if self.custom_mutators else "play"
		else:
			if self.examine_target in self.custom_mutators:
				self.examine_target = available[0]
			elif self.examine_target == "play":
				self.examine_target = self.custom_mutators[0] if self.custom_mutators else available[0]
			else:
				self.examine_target = "play"
		return True

	def process_setup_custom_input(self):
		selection = None
		m_loc = self.get_mouse_pos()
		rows, total_pages, page_start, page_end = self.get_custom_mutator_page_bounds()

		for evt in self.events:
			if evt.type == pygame.KEYDOWN:
				if evt.key in self.key_binds[KEY_BIND_CONFIRM]:
					self.play_sound('menu_confirm')
					selection = self.examine_target

				elif evt.key in self.key_binds[KEY_BIND_ABORT]:
					self.exit_custom_mutator_setup()
					return

				elif evt.key in self.key_binds[KEY_BIND_UP]:
					if self.move_custom_mutator_vertical(-1, page_start, page_end): self.play_sound('menu_confirm')

				elif evt.key in self.key_binds[KEY_BIND_DOWN]:
					if self.move_custom_mutator_vertical(1, page_start, page_end): self.play_sound('menu_confirm')

				elif evt.key in self.key_binds[KEY_BIND_RIGHT]:
					if self.move_custom_mutator_horizontal(1, page_start, page_end): self.play_sound('menu_confirm')

				elif evt.key in self.key_binds[KEY_BIND_LEFT]:
					if self.move_custom_mutator_horizontal(-1, page_start, page_end): self.play_sound('menu_confirm')

				elif evt.key == pygame.K_PAGEUP:
					row_offset = all_mutators.index(self.examine_target) - page_start if self.examine_target in all_mutators else 0
					if self.custom_mutator_page_adjust(-1):
						self.play_sound('menu_confirm')
						rows, total_pages, page_start, page_end = self.get_custom_mutator_page_bounds()
						if page_end > page_start:
							new_index = max(page_start, min(page_start + row_offset, page_end - 1))
							self.examine_target = all_mutators[new_index]

				elif evt.key == pygame.K_PAGEDOWN:
					row_offset = all_mutators.index(self.examine_target) - page_start if self.examine_target in all_mutators else 0
					if self.custom_mutator_page_adjust(1):
						self.play_sound('menu_confirm')
						rows, total_pages, page_start, page_end = self.get_custom_mutator_page_bounds()
						if page_end > page_start:
							new_index = max(page_start, min(page_start + row_offset, page_end - 1))
							self.examine_target = all_mutators[new_index]

			elif evt.type == pygame.MOUSEBUTTONDOWN:
				if evt.button == pygame.BUTTON_LEFT:
					for r, o in self.ui_rects:
						if r.collidepoint(m_loc):
							self.play_sound('menu_confirm')
							selection = o
							break
					else:
						self.play_sound('menu_abort')
						return

				elif evt.button == pygame.BUTTON_RIGHT:
					self.exit_custom_mutator_setup()
					return

			elif evt.type == pygame.MOUSEWHEEL:
				row_offset = all_mutators.index(self.examine_target) - page_start if self.examine_target in all_mutators else 0
				page_changed = False
				if evt.y > 0: page_changed = self.custom_mutator_page_adjust(-1)
				elif evt.y < 0: page_changed = self.custom_mutator_page_adjust(1)
				if page_changed:
					self.play_sound('menu_confirm')
					rows, total_pages, page_start, page_end = self.get_custom_mutator_page_bounds()
					if page_end > page_start:
						new_index = max(page_start, min(page_start + row_offset, page_end - 1))
						self.examine_target = all_mutators[new_index]

		if selection: # send to appropriate page, or just add the mutator if it takes no args.
			self.play_sound('menu_confirm')
			if selection in ["mut_prev", "mut_next"]:
				row_offset = all_mutators.index(self.examine_target) - page_start if self.examine_target in all_mutators else 0
				if selection == "mut_prev":
					self.custom_mutator_page_adjust(-1)
				else:
					self.custom_mutator_page_adjust(1)
				rows, total_pages, page_start, page_end = self.get_custom_mutator_page_bounds()
				if page_end > page_start:
					new_index = max(page_start, min(page_start + row_offset, page_end - 1))
					self.examine_target = all_mutators[new_index]
				return
			self.pending_mutator_class = selection

			if selection in mutators_with_no_args:
				self.custom_mutators.append(selection())
				self.custom_mutator_args.append([])

			elif selection in mutators_with_vals:
				self.state = STATE_ENTER_MUTATOR_VALUE

			elif selection in mutators_with_params:
				options = mutator_param_options.get(selection, [])
				if not options:
					self.play_sound('menu_abort')
					return
				if selection in mutators_with_vals_first:
					self.state = STATE_ENTER_MUTATOR_VALUE
				else:
					self.open_mutator_param_picker(selection)

			elif selection in self.custom_mutators:
				i = self.custom_mutators.index(selection)
				del self.custom_mutators[i]
				del self.custom_mutator_args[i]
				if i < len(self.custom_mutators): self.examine_target = self.custom_mutators[i]
				else: self.examine_target = all_mutators[page_start]

			elif selection == "play":
				self.play_sound('menu_confirm')
				self.save_custom_mutator_setup()
				self.new_game(trial_name="Custom", mutators=self.make_custom_run_mutators())

			else:
				self.play_sound('menu_abort')

	def open_mutator_param_picker(self, mutator_class):
		self.clear_mutator_param_picker()
		options = mutator_param_options[mutator_class]
		self.mutator_param_entries = [(option, resolve_text(self.format_param_value(option))) for option in options]
		self.pending_param = options[0]
		self.examine_target = self.mutator_param_entries[0]
		self.state = STATE_PICK_MUTATOR_PARAMS

	def clear_mutator_param_picker(self):
		if self.mutator_param_search_focused: pygame.key.stop_text_input()
		self.mutator_param_entries = []
		self.mutator_param_page = 0
		self.mutator_param_query = ""
		self.mutator_param_search_focused = False

	def set_mutator_param_search_focus(self, focused, clear=False):
		if clear:
			self.mutator_param_query = ""
			self.reset_mutator_param_filter()
		if focused == self.mutator_param_search_focused: return
		self.mutator_param_search_focused = focused
		if focused: pygame.key.start_text_input()
		else: pygame.key.stop_text_input()

	def get_filtered_mutator_param_entries(self):
		terms = self.mutator_param_query.strip().lower().split()
		if not terms: return self.mutator_param_entries
		return [entry for entry in self.mutator_param_entries if all(term in entry[1].lower() for term in terms)]

	def get_mutator_param_layout(self, description):
		desc_rows = max(1, len(description))
		search_y = self.linesize * (4 + desc_rows)
		list_y = search_y + self.linesize * 2
		controls_y = self.screen.get_height() - self.linesize * 2
		rows = max(1, (controls_y - list_y - self.linesize) // self.linesize)
		return search_y, list_y, controls_y, rows

	def reset_mutator_param_filter(self):
		self.mutator_param_page = 0
		entries = self.get_filtered_mutator_param_entries()
		self.examine_target = entries[0] if entries else None
		if entries: self.pending_param = entries[0][0]

	def mutator_param_page_adjust(self, delta):
		entries = self.get_filtered_mutator_param_entries()
		description = self.get_placeholder_description(self.pending_mutator_class).split('\n')
		rows = self.get_mutator_param_layout(description)[3]
		total_pages = max(1, math.ceil(len(entries) / rows))
		new_page = (self.mutator_param_page + delta) % total_pages
		if new_page == self.mutator_param_page: return False
		current = next(entry for entry in entries if entry[0] == self.pending_param)
		offset = entries.index(current) - self.mutator_param_page * rows
		self.mutator_param_page = new_page
		new_start = new_page * rows
		new_end = min(new_start + rows, len(entries))
		new_index = min(new_start + offset, new_end - 1)
		self.pending_param = entries[new_index][0]
		self.examine_target = entries[new_index]
		return True

	def move_mutator_param_selection(self, delta):
		entries = self.get_filtered_mutator_param_entries()
		if not entries: return False
		description = self.get_placeholder_description(self.pending_mutator_class).split('\n')
		rows = self.get_mutator_param_layout(description)[3]
		page_start = self.mutator_param_page * rows
		page_entries = entries[page_start:page_start + rows]
		if not page_entries: return False
		if self.examine_target in page_entries:
			index = page_entries.index(self.examine_target)
		else:
			index = 0
			delta = 0
		entry = page_entries[(index + delta) % len(page_entries)]
		if entry == self.examine_target: return False
		self.pending_param = entry[0]
		self.examine_target = entry
		return True

	def draw_mutator_param_search_bar(self, center_x, y):
		search_label = resolve_text("Search:")
		search_bar_img = get_image(['ui', 'search_bar'])
		x = center_x - (cached_size(self.font, search_label) + search_bar_img.get_width()) // 2
		self.draw_search_bar(self.screen, x, y, self.mutator_param_query, self.mutator_param_search_focused)

	def draw_pick_mutator_params(self):
		self.ui_rects = []
		center_x = self.screen.get_width() // 2
		if not self.mutator_param_entries: return

		if len(self.mutator_param_entries) <= 20:
			description = self.get_placeholder_description(self.pending_mutator_class).split('\n')
			content_height = (len(self.mutator_param_entries) + len(description) + 4) * self.linesize
			start_y = (self.screen.get_height() - content_height) // 2
			self.draw_string(self.pending_mutator_class.__name__, self.screen, 0, start_y, center=True, content_width=self.screen.get_width())
			start_y += self.linesize
			for line in description:
				self.draw_string(line, self.screen, 0, start_y, center=True, content_width=self.screen.get_width(), pre_resolved=True)
				start_y += self.linesize
			start_y += self.linesize * 2
			list_width = max(self.font.size(entry[1])[0] for entry in self.mutator_param_entries)
			list_x = center_x - list_width // 2
			for entry in self.mutator_param_entries:
				self.draw_string(entry[1], self.screen, list_x, start_y, mouse_content=entry, pre_resolved=True)
				start_y += self.linesize
			return

		description = self.get_placeholder_description(self.pending_mutator_class).split('\n')
		self.draw_string(self.pending_mutator_class.__name__, self.screen, 0, self.linesize, center=True, content_width=self.screen.get_width())
		desc_y = self.linesize * 3
		for line in description:
			self.draw_string(line, self.screen, 0, desc_y, center=True, content_width=self.screen.get_width(), pre_resolved=True)
			desc_y += self.linesize

		search_y, list_y, controls_y, rows = self.get_mutator_param_layout(description)
		self.draw_mutator_param_search_bar(center_x, search_y)

		entries = self.get_filtered_mutator_param_entries()
		max_list_width = self.screen.get_width() // 2
		list_width = min(max(self.font.size(entry[1])[0] for entry in self.mutator_param_entries), max_list_width)
		list_x = center_x - list_width // 2
		total_pages = max(1, math.ceil(len(entries) / rows))
		self.mutator_param_page = max(0, min(total_pages - 1, self.mutator_param_page))
		start_idx = self.mutator_param_page * rows
		end_idx = min(start_idx + rows, len(entries))
		if not entries: self.draw_string("No Results", self.screen, list_x, list_y, content_width=list_width, center=True)
		for entry in entries[start_idx:end_idx]:
			label = fit_text_to_width(self.font, entry[1], list_width)
			self.draw_string(label, self.screen, list_x, list_y, mouse_content=entry, pre_resolved=True)
			list_y += self.linesize

		if total_pages > 1:
			prev_text = "<<<<"
			page_text = resolve_text(("Page {cur}/{total}", {"cur": self.mutator_param_page + 1, "total": total_pages}))
			next_text = ">>>>"
			pad_w = self.font.size("   ")[0]
			controls_width = self.font.size(prev_text)[0] + pad_w + self.font.size(page_text)[0] + pad_w + self.font.size(next_text)[0]
			x = center_x - controls_width // 2
			self.draw_string(prev_text, self.screen, x, controls_y, mouse_content=TOOLTIP_PREV, pre_resolved=True)
			x += self.font.size(prev_text)[0] + pad_w
			self.draw_string(page_text, self.screen, x, controls_y, pre_resolved=True)
			x += self.font.size(page_text)[0] + pad_w
			self.draw_string(next_text, self.screen, x, controls_y, mouse_content=TOOLTIP_NEXT, pre_resolved=True)

	def process_pick_mutator_params_input(self):
		selection = None
		m_loc = self.get_mouse_pos()
		large_list = len(self.mutator_param_entries) > 20

		if self.mutator_param_search_focused:
			for evt in self.events:
				if evt.type == pygame.TEXTINPUT:
					self.mutator_param_query += evt.text
					self.reset_mutator_param_filter()

		entries = self.get_filtered_mutator_param_entries()
		if self.examine_target in entries: self.pending_param = self.examine_target[0]

		for evt in self.events:
			if evt.type == pygame.KEYDOWN:
				if self.mutator_param_search_focused:
					if evt.key in self.key_binds[KEY_BIND_CONFIRM]:
						self.set_mutator_param_search_focus(False)
					elif evt.key in self.key_binds[KEY_BIND_ABORT]:
						self.set_mutator_param_search_focus(False, clear=True)
					elif evt.key == pygame.K_BACKSPACE:
						self.mutator_param_query = self.mutator_param_query[:-1]
						self.reset_mutator_param_filter()
						if evt.key not in self.repeat_keys:
							self.repeat_keys[evt.key] = time.time() + REPEAT_DELAY
					continue

				entries = self.get_filtered_mutator_param_entries()
				if evt.key in self.key_binds[KEY_BIND_CONFIRM] and self.examine_target in entries:
					self.play_sound('menu_confirm')
					selection = self.examine_target[0]

				elif evt.key in self.key_binds[KEY_BIND_ABORT]:
					self.clear_custom_mutator()
					return

				elif large_list and evt.key in self.key_binds[KEY_BIND_QUERY]:
					self.set_mutator_param_search_focus(True)

				elif evt.key in self.key_binds[KEY_BIND_UP]:
					if self.move_mutator_param_selection(-1): self.play_sound('menu_confirm')

				elif evt.key in self.key_binds[KEY_BIND_DOWN]:
					if self.move_mutator_param_selection(1): self.play_sound('menu_confirm')

				elif large_list and (evt.key in self.key_binds[KEY_BIND_LEFT] or evt.key == pygame.K_PAGEUP):
					if self.mutator_param_page_adjust(-1): self.play_sound('menu_confirm')

				elif large_list and (evt.key in self.key_binds[KEY_BIND_RIGHT] or evt.key == pygame.K_PAGEDOWN):
					if self.mutator_param_page_adjust(1): self.play_sound('menu_confirm')

			elif evt.type == pygame.MOUSEWHEEL and large_list:
				if evt.y > 0 and self.mutator_param_page_adjust(-1): self.play_sound('menu_confirm')
				elif evt.y < 0 and self.mutator_param_page_adjust(1): self.play_sound('menu_confirm')

			elif evt.type == pygame.MOUSEBUTTONDOWN:
				if evt.button == pygame.BUTTON_LEFT:
					clicked = None
					for r, o in self.ui_rects:
						if r.collidepoint(m_loc):
							clicked = o
							break
					if clicked is None: continue
					if clicked == SEARCH_INPUT_TARGET:
						self.set_mutator_param_search_focus(True)
						continue
					self.set_mutator_param_search_focus(False)
					if clicked == TOOLTIP_PREV:
						if self.mutator_param_page_adjust(-1): self.play_sound('menu_confirm')
					elif clicked == TOOLTIP_NEXT:
						if self.mutator_param_page_adjust(1): self.play_sound('menu_confirm')
					elif clicked in self.get_filtered_mutator_param_entries():
						self.play_sound('menu_confirm')
						selection = clicked[0]

				elif evt.button == pygame.BUTTON_RIGHT:
					if self.mutator_param_search_focused:
						self.set_mutator_param_search_focus(False, clear=True)
						break
					self.clear_custom_mutator()
					return

		if selection is not None:
			self.pending_param = selection

			if self.pending_mutator_class in mutators_with_params_and_vals and self.pending_mutator_class not in mutators_with_vals_first:
				self.play_sound('menu_confirm')
				self.state = STATE_ENTER_MUTATOR_VALUE
			else:
				self.finalize_custom_mutator()

	def format_param_value(self, val):
		if callable(val):
			# Handle lambdas or factory functions
			try:
				instance = val()
				return getattr(instance, 'name', str(instance))
			except:
				return "<invalid>"

		if hasattr(val, 'name'):
			# Tags, units, buffs, etc.
			return val.name

		if isinstance(val, str):
			return val

		return str(val)

	def draw_enter_mutator_value(self):
		self.ui_rects = []

		center_x = self.screen.get_width() // 2
		start_y = self.screen.get_height() // 4

		# Mutator Name
		mut_name = self.pending_mutator_class.__name__
		title_x = center_x - self.font.size(mut_name)[0] // 2
		self.draw_string(mut_name, self.screen, title_x, start_y, (255, 255, 255))
		start_y += self.linesize

		#Mutator Dummy Description
		desc_lines = self.get_placeholder_description(self.pending_mutator_class).split('\n')
		for line in desc_lines:
			line_w = self.font.size(line)[0]
			line_x = center_x - line_w // 2
			self.draw_string(line, self.screen, line_x, start_y, (255, 255, 255), pre_resolved=True)
			start_y += self.linesize

		start_y += self.linesize * 3

		# Title
		title = "Enter Value"
		title_x = center_x - self.font.size(title)[0] // 2
		self.draw_string(title, self.screen, title_x, start_y, (255, 255, 255))
		start_y += self.linesize * 2

		# Input box
		val = getattr(self, 'pending_value_buffer', "")
		input_text = f"> {val}_"
		text_w = self.font.size(input_text)[0]
		text_x = center_x - text_w // 2
		input_rect = pygame.Rect(text_x, start_y, text_w, self.linesize)
		self.draw_string(input_text, self.screen, text_x, start_y, (255, 255, 255), mouse_content="input_box")
		self.ui_rects.append((input_rect, "input_box"))
		start_y += self.linesize * 2

		# Confirm button
		confirm = "Confirm"
		confirm_w = self.font.size(confirm)[0]
		confirm_x = center_x - confirm_w // 2
		confirm_rect = pygame.Rect(confirm_x, start_y, confirm_w, self.linesize)
		self.draw_string(confirm, self.screen, confirm_x, start_y, (255, 255, 255), mouse_content="confirm")
		self.ui_rects.append((confirm_rect, "confirm"))

	def confirm_custom_mutator_value(self):
		value_first = self.pending_mutator_class in mutators_with_vals_first and self.pending_param is None
		if value_first and self.pending_value_buffer.isdigit() and int(self.pending_value_buffer) != 0:
			self.play_sound('menu_confirm')
			self.open_mutator_param_picker(self.pending_mutator_class)
			return
		self.finalize_custom_mutator()

	def process_enter_mutator_value_input(self):
		m_loc = self.get_mouse_pos()

		for evt in self.events:
			if evt.type == pygame.KEYDOWN:
				if evt.key in self.key_binds[KEY_BIND_CONFIRM]:
					self.confirm_custom_mutator_value()
					return

				elif evt.key in self.key_binds[KEY_BIND_ABORT]:
					self.clear_custom_mutator()
					return

				elif evt.key == pygame.K_BACKSPACE:
					self.pending_value_buffer = self.pending_value_buffer[:-1]

				elif hasattr(evt, "unicode") and evt.unicode.isdigit():
					self.pending_value_buffer += evt.unicode

			elif evt.type == pygame.MOUSEBUTTONDOWN:
				if evt.button == pygame.BUTTON_LEFT:
					for r, o in self.ui_rects:
						if r.collidepoint(m_loc):
							if o == "confirm":
								self.confirm_custom_mutator_value()
								return

				elif evt.button == pygame.BUTTON_RIGHT:
					self.clear_custom_mutator()

	def finalize_custom_mutator(self):
		args = []
		mutator_class = self.pending_mutator_class

		if self.pending_param is not None: # if you have a selected parameter, put that first in the args
			args.append(self.pending_param)

		if self.pending_value_buffer.isdigit() and int(self.pending_value_buffer) != 0:
			args.append(int(self.pending_value_buffer))
		elif self.pending_mutator_class in (mutators_with_vals + mutators_with_params_and_vals):
			self.play_sound('menu_abort')
			self.clear_custom_mutator()
			return

		# Add to custom list and reset
		self.custom_mutators.append(mutator_class(*args))
		self.custom_mutator_args.append(args)
		self.play_sound('menu_confirm')
		self.return_to_custom_mutator_setup(mutator_class)

	def return_to_custom_mutator_setup(self, mutator_class):
		self.clear_mutator_param_picker()
		self.pending_mutator_class = None
		self.pending_param = None
		self.pending_value_buffer = ''
		if mutator_class in all_mutators:
			self.custom_mutator_page = all_mutators.index(mutator_class) // self.get_custom_mutator_rows_per_page()
			self.examine_target = mutator_class
		else:
			self.custom_mutator_page = 0
			self.examine_target = all_mutators[0]
		self.state = STATE_SETUP_CUSTOM

	def clear_custom_mutator(self):
		mutator_class = self.pending_mutator_class
		self.play_sound('menu_abort')
		self.return_to_custom_mutator_setup(mutator_class)

	def get_custom_mutator_configs(self):
		configs = []
		for mutator, args in zip(self.custom_mutators, self.custom_mutator_args):
			mutator_class = type(mutator)
			param_name = None
			value = None
			if mutator_class in mutators_with_params:
				param_name = self.format_param_value(args[0])
			if mutator_class in mutators_with_vals:
				value = args[0]
			elif mutator_class in mutators_with_params_and_vals:
				value = args[1]
			mutator_id = (mutator_class.__module__, mutator_class.__qualname__)
			configs.append((mutator_id, param_name, value))
		return configs

	def restore_custom_mutator_setup(self):
		self.custom_mutators.clear()
		self.custom_mutator_args.clear()
		mutator_classes = {(mutator_class.__module__, mutator_class.__qualname__): mutator_class for mutator_class in all_mutators}
		param_options_by_class = {}
		for mutator_id, param_name, value in self.options['last_custom_mutators']:
			if mutator_id not in mutator_classes: continue
			mutator_class = mutator_classes[mutator_id]
			args = []
			if param_name is not None:
				if mutator_class not in param_options_by_class:
					param_options_by_class[mutator_class] = {self.format_param_value(option): option for option in mutator_param_options[mutator_class]}
				param_options = param_options_by_class[mutator_class]
				if param_name not in param_options: continue
				args.append(param_options[param_name])
			if value is not None: args.append(value)
			self.custom_mutators.append(mutator_class(*args))
			self.custom_mutator_args.append(args)

	def save_custom_mutator_setup(self):
		self.options['last_custom_mutators'] = self.get_custom_mutator_configs()
		self.save_options()

	def exit_custom_mutator_setup(self):
		self.save_custom_mutator_setup()
		self.clear_custom_mutator()
		self.return_to_title()

	def make_custom_run_mutators(self):
		return [type(mutator)(*args) for mutator, args in zip(self.custom_mutators, self.custom_mutator_args)]

	def draw_pick_trial(self):

		rect_w = max(self.font.size(trial.name)[0] for trial in all_trials)
		cur_x = self.screen.get_width() // 2 - rect_w // 2
		cur_y = self.screen.get_height() // 2 - self.linesize * (len(all_trials) // 2)

		cur_color = (255, 255, 255)
		for trial in all_trials:
			line_w = self.font.size(trial.name)[0]
			self.draw_string(trial.name, self.screen, cur_x, cur_y, cur_color, mouse_content=trial, content_width=line_w)
			if SteamAdapter.get_trial_status(trial.name): self.draw_string("*", self.screen, cur_x - 16, cur_y, COLOR_VICTORY)
			cur_y += self.linesize

		cur_y += self.linesize * 3

		if isinstance(self.examine_target, Trial):
			desc = self.examine_target.get_description()
			for line in desc.split('\n'):
				cur_x_desc = (self.screen.get_width() // 2) - (self.font.size(line)[0] // 2)
				self.draw_string(line, self.screen, cur_x_desc, cur_y)
				cur_y += self.linesize

	def process_pick_trial_input(self):
		selection = None
		m_loc = self.get_mouse_pos()

		for evt in self.events:
			if evt.type == pygame.KEYDOWN:

				if evt.key in self.key_binds[KEY_BIND_CONFIRM]:
					self.play_sound('menu_confirm')
					selection = self.examine_target
					continue

				if evt.key in self.key_binds[KEY_BIND_UP]:
					self.play_sound('menu_confirm')
					if self.examine_target not in all_trials: self.examine_target = all_trials[0]
					else: self.examine_target = all_trials[(all_trials.index(self.examine_target) - 1) % len(all_trials)]
					continue

				if evt.key in self.key_binds[KEY_BIND_DOWN]:
					self.play_sound('menu_confirm')
					if self.examine_target not in all_trials: self.examine_target = all_trials[0]
					else: self.examine_target = all_trials[(all_trials.index(self.examine_target) + 1) % len(all_trials)]
					continue

				if evt.key in self.key_binds[KEY_BIND_ABORT]:
					self.state = STATE_PICK_MODE
					self.examine_target = None
					self.play_sound('menu_abort')
					return

			if evt.type == pygame.MOUSEBUTTONDOWN:

				if evt.button == pygame.BUTTON_LEFT:
					for r, o in self.ui_rects:
						if r.collidepoint(m_loc):
							self.play_sound('menu_confirm')
							selection = o
							break
					else:
						self.play_sound('menu_abort')

				if evt.button == pygame.BUTTON_RIGHT:
					self.state = STATE_PICK_MODE
					self.examine_target = None
					self.play_sound('menu_abort')
					return

		dx, dy = self.get_mouse_rel()
		if dx or dy:
			for r, o in self.ui_rects:
				if r.collidepoint(m_loc):
					if self.examine_target != o:
						self.play_sound('menu_confirm')
					self.examine_target = o

		if selection:
			self.new_game(trial_name=selection.name, mutators=selection.mutators)

	def get_selected_outfit(self):
		outfit = get_wardrobe_outfit(self.options['selected_outfit'])
		if not outfit or not SteamAdapter.is_outfit_unlocked(outfit):
			outfit = get_wardrobe_outfit('player')
		return outfit

	def open_wardrobe(self):
		outfit = self.get_selected_outfit()
		self.open_shop(SHOP_TYPE_WARDROBE)
		self.shop_rows_per_page = max(1, self.max_shop_objects - 2)
		self.examine_target = outfit
		self.shop_page = wardrobe_outfits.index(outfit) // self.get_shop_rows_per_page()

	def apply_selected_wardrobe_outfit(self):
		outfit = self.get_selected_outfit()
		asset_name = outfit.asset_name
		for mutator in self.game.mutators:
			if isinstance(mutator, CharacterSwap):
				asset_name = mutator.player_asset_replace
		if self.game.p1.asset_name == asset_name: return False
		self.game.p1.asset_name = asset_name
		self.game.p1.clear_runtime_anims()
		return True

	def apply_wardrobe_outfit(self, outfit):
		if not SteamAdapter.is_outfit_unlocked(outfit):
			self.play_sound("menu_abort")
			return
		already_saved = outfit.asset_name == self.options['selected_outfit']
		self.options['selected_outfit'] = outfit.asset_name
		changed_player = self.apply_selected_wardrobe_outfit() if self.game else False
		if already_saved and not changed_player: return
		if not already_saved: self.save_options()
		self.play_sound("menu_confirm")

	def draw_wardrobe_preview(self, outfit):
		panel = self.middle_menu_display
		if not outfit: return
		if not SteamAdapter.is_outfit_unlocked(outfit):
			y = panel.get_height() // 2 - self.linesize
			self.draw_string("Locked", panel, 0, y, UNAVAILABLE_COLOR, center=True,  content_width=panel.get_width())
			if outfit.description is not None:
				self.draw_wrapped_string(outfit.description, panel, self.border_margin, y + self.linesize, panel.get_width() - self.border_margin * 2, color=UNAVAILABLE_COLOR, center=True, indent=False)
			return

		sprite_sheet = self.get_sprite_sheet(['char', outfit.asset_name])
		frame = (cloud_frame_clock // SUB_FRAMES[ANIM_IDLE]) % len(sprite_sheet.anim_frames[ANIM_IDLE])
		subimage = sprite_sheet.anim_frames[ANIM_IDLE][frame]
		preview_size = SPRITE_SIZE * 2
		scaled = pygame.transform.scale(subimage, (preview_size, preview_size))
		preview_x = panel.get_width() // 2 - preview_size // 2
		preview_y = panel.get_height() // 2 - preview_size // 2
		panel.blit(scaled, (preview_x, preview_y))
		name_y = preview_y + preview_size + self.linesize
		self.draw_string(outfit.name, panel, 0, name_y, center=True, content_width=panel.get_width())
		if outfit.description is None: return
		self.draw_wrapped_string(outfit.description, panel, self.border_margin, name_y + self.linesize * 2, panel.get_width() - self.border_margin * 2, center=True, indent=False)

	def draw_wardrobe_shop(self):
		shoptions = self.get_shop_options()
		selected_outfit = self.get_selected_outfit()
		unlocked = len([outfit for outfit in wardrobe_outfits if SteamAdapter.is_outfit_unlocked(outfit)])

		def wardrobe_row(outfit):
			is_unlocked = SteamAdapter.is_outfit_unlocked(outfit)
			selected = outfit == selected_outfit
			label = outfit.name if is_unlocked else "?????????????????????"
			color = (0, 255, 0) if selected else (255, 255, 255)
			if not is_unlocked: color = UNAVAILABLE_COLOR
			return label, color

		title = ("Wardrobe: {cur} of {total}", {"cur": unlocked, "total": len(wardrobe_outfits)})
		self.draw_left_list_shop(title, shoptions, wardrobe_row)
		self.draw_wardrobe_preview(self.examine_target if self.examine_target in shoptions else selected_outfit)
		self.screen.blit(self.middle_menu_display, (self.h_margin, 0))

	def get_options_entries(self):
		entries = [
			OPTION_SOUND_VOLUME,
			OPTION_MUSIC_VOLUME,
			OPTION_SPELL_SPEED,
			OPTION_SAVE_PREFERENCES,
			OPTION_WARDROBE,
			OPTION_WINDOW_MODE,
			OPTION_CONTROLS,
			OPTION_LANGUAGE_SELECT,
		]
		if self.game:
			entries.append(OPTION_RETURN)
			entries.append(OPTION_EXIT)
		else:
			entries.append(OPTION_EXIT)
		return entries

	def draw_options_menu(self):
		self.ui_rects = []
		entries = self.get_options_entries()

		label_texts = []
		for option in entries:
			if option == OPTION_SOUND_VOLUME:
				label = ("Sound Volume: {vol}", {"vol": self.options['sound_volume']})
			elif option == OPTION_MUSIC_VOLUME:
				label = ("Music Volume: {vol}", {"vol": self.options['music_volume']})
			elif option == OPTION_LANGUAGE_SELECT:
				label = "Language Select"
			elif option == OPTION_SPELL_SPEED:
				speed_fmt = SPELL_SPEED_NAMES[self.options['spell_speed']]
				label = ("Anim Speed: {speed}", {"speed": speed_fmt})
			elif option == OPTION_WINDOW_MODE:
				if self.window_mode == WINDOW_MODE_WINDOWED:
					label = "Display: Windowed"
				elif self.window_mode == WINDOW_MODE_BORDERLESS:
					label = "Display: Borderless"
				else:
					label = "Display: Fullscreen"
			elif option == OPTION_SAVE_PREFERENCES:
				label = "Save Preferences"
			elif option == OPTION_WARDROBE:
				label = ("Wardrobe: {outfit}", {"outfit": self.get_selected_outfit().name})
			elif option == OPTION_CONTROLS:
				label = "Rebind Controls"
			elif option == OPTION_RETURN:
				label = "Return to Game"
			elif option == OPTION_EXIT:
				label = "Save and Exit" if self.game else "Back to Title"
			else:
				continue

			label_texts.append((option, resolve_text(label)))

		num_entries = max(1, len(label_texts))
		rect_w = max(self.font.size(text)[0] for _, text in label_texts)

		if self.options_menu_x is None: self.options_menu_x = self.screen.get_width() // 2 - rect_w // 2
		cur_x = self.options_menu_x
		cur_y = self.screen.get_height() // 2 - self.linesize * num_entries // 2

		for option, text in label_texts:
			line_w = self.font.size(text)[0]
			self.draw_string(text, self.screen, cur_x, cur_y, mouse_content=option, content_width=line_w, pre_resolved=True)
			cur_y += self.linesize

	def get_save_pref_entries(self):
		return [
			SAVE_PREF_AUTOSAVE,
			SAVE_PREF_SCREENSHOTS,
			SAVE_PREF_SAVE_RUNS,
			SAVE_PREF_BACK,
		]

	def draw_save_preferences_menu(self):
		self.ui_rects = []
		entries = self.get_save_pref_entries()

		label_texts = []
		max_label_w = 0
		for option in entries:
			if option == SAVE_PREF_AUTOSAVE:
				on_label = resolve_text(("Autosave: {state}", {"state": "On"}))
				off_label = resolve_text(("Autosave: {state}", {"state": "Off"}))
				label = on_label if self.options.get('autosave_progress', False) else off_label
				max_label_w = max(max_label_w, self.font.size(on_label)[0], self.font.size(off_label)[0])
			elif option == SAVE_PREF_SCREENSHOTS:
				on_label = resolve_text(("Save Screenshots: {state}", {"state": "On"}))
				off_label = resolve_text(("Save Screenshots: {state}", {"state": "Off"}))
				label = on_label if self.options.get('save_screenshots', False) else off_label
				max_label_w = max(max_label_w, self.font.size(on_label)[0], self.font.size(off_label)[0])
			elif option == SAVE_PREF_SAVE_RUNS:
				on_label = resolve_text(("Keep Previous Save Files: {state}", {"state": "On"}))
				off_label = resolve_text(("Keep Previous Save Files: {state}", {"state": "Off"}))
				label = on_label if self.options.get('save_prev_runs', False) else off_label
				max_label_w = max(max_label_w, self.font.size(on_label)[0], self.font.size(off_label)[0])
			elif option == SAVE_PREF_BACK:
				label = "Back to Options"
				max_label_w = max(max_label_w, self.font.size(label)[0])
			else:
				continue

			label_texts.append((option, resolve_text(label)))

		num_entries = max(1, len(label_texts))
		rect_w = max_label_w
		cur_x = self.screen.get_width() // 2 - rect_w // 2
		cur_y = self.screen.get_height() // 2 - self.linesize * num_entries // 2

		for option, text in label_texts:
			line_w = self.font.size(text)[0]
			self.draw_string(text, self.screen, cur_x, cur_y, mouse_content=option, content_width=line_w, pre_resolved=True)
			cur_y += self.linesize

	def toggle_save_pref(self, option):
		if option == SAVE_PREF_AUTOSAVE:
			key = 'autosave_progress'
		elif option == SAVE_PREF_SCREENSHOTS:
			key = 'save_screenshots'
		elif option == SAVE_PREF_SAVE_RUNS:
			key = 'save_prev_runs'
		else:
			return False
		self.options[key] = not self.options.get(key, False)
		self.apply_save_preferences()
		self.save_options()
		return True

	def open_save_preferences(self):
		self.state = STATE_SAVE_PREFS
		self.examine_target = SAVE_PREF_AUTOSAVE


	def draw_message(self):
		cur_y = self.border_margin

		lines = self.message.split('\n')

		# If centering the message, center vertically too
		if self.center_message:
			cur_y = self.screen.get_height() // 2 - self.linesize * len(lines) // 2

		for line in lines:
			if line:
				self.draw_string(line, self.screen, 0, cur_y, center=self.center_message, content_width=self.screen.get_width())
			cur_y += self.linesize


	def process_message_input(self):
		for evt in self.events:
			if evt.type in [pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN]:
				self.play_sound("menu_confirm")
				if self.next_messages:
					self.message = self.next_messages.pop(0)
				elif self.game:
					self.state = STATE_LEVEL
				else:
					self.state = STATE_TITLE

	def get_how_to_play_font(self, px):
		cached = self.how_to_play_font_cache.get(px)
		if cached: return cached
		font = self.font_loader(px)
		linesize = font.get_linesize() + FONT_PAD
		self.how_to_play_font_cache[px] = (font, linesize)
		return font, linesize

	def get_how_to_play_page_layout(self):
		title_font, title_linesize = self.get_how_to_play_font(48)
		body_font, body_linesize = self.get_how_to_play_font(32)
		margin_x = self.border_margin * 3
		title_y = self.border_margin * 2
		body_y = title_y + title_linesize * 2
		body_width = self.screen.get_width() - margin_x * 2
		footer_top = self.screen.get_height() - body_linesize * 3
		return title_font, title_linesize, body_font, body_linesize, margin_x, title_y, body_y, body_width, footer_top

	def get_how_to_play_page_lines(self, raw_texts):
		page_lines = []
		for raw_text in raw_texts:
			lines = raw_text.splitlines()
			if page_lines and lines: page_lines.append("")
			page_lines.extend(lines)
		while page_lines and not page_lines[-1]: page_lines.pop()
		return page_lines

	def get_how_to_play_source_sections(self):
		return [
			("CONTROLS:", [text.how_to_play_controls]),
			("ADVANCED CONTROLS:", [text.how_to_play_advanced_controls]),
			("STATUS EFFECTS:", [text.how_to_play_status_effects]),
			("MISC TIPS:", [text.how_to_play_misc_tips]),
		]

	def get_how_to_play_pages(self):
		pages = []
		for page_title, raw_texts in self.get_how_to_play_source_sections():
			page_lines = self.get_how_to_play_page_lines(raw_texts)
			pages.append({"title": page_title, "lines": page_lines})
		return pages

	def draw_how_to_play_footer(self, pages, font, linesize):
		cur_page = self.how_to_play_page
		footer_y = self.screen.get_height() - linesize - self.border_margin * 2
		left_x = self.border_margin * 3
		right_text = ">>>>"
		right_w = cached_size(font, right_text)
		right_x = self.screen.get_width() - self.border_margin * 3 - right_w
		label_text = ("Page {cur}/{total}", {"cur": cur_page + 1, "total": len(pages)})

		self.draw_string("<<<<", self.screen, left_x, footer_y, mouse_content=HOW_TO_PLAY_PREV, font=font, linesize_override=linesize, pre_resolved=True)
		self.draw_string(label_text, self.screen, 0, footer_y, center=True, content_width=self.screen.get_width(), font=font, linesize_override=linesize)
		self.draw_string(right_text, self.screen, right_x, footer_y, mouse_content=HOW_TO_PLAY_NEXT, font=font, linesize_override=linesize, pre_resolved=True)

	def draw_how_to_play_line(self, line, margin_x, cur_y, body_width, body_font, body_linesize):
		leading = len(line) - len(line.lstrip(' '))
		indent_w = cached_size(body_font, line[:leading])
		text_line = line[leading:]
		return self.draw_wrapped_string(text_line, self.screen, margin_x + indent_w, cur_y, body_width - indent_w, font=body_font, linesize_override=body_linesize, indent=False)

	def draw_how_to_play_page(self, page, layout):
		title_font, title_linesize, body_font, body_linesize, margin_x, title_y, body_y, body_width, footer_top = layout
		self.draw_string(page["title"], self.screen, margin_x, title_y, font=title_font, linesize_override=title_linesize)

		cur_y = body_y
		for line in page["lines"]:
			if not line:
				cur_y += body_linesize
				continue
			if cur_y >= footer_top: break
			lines = self.draw_how_to_play_line(line, margin_x, cur_y, body_width, body_font, body_linesize)
			cur_y += lines * body_linesize

	def draw_how_to_play(self):
		layout = self.get_how_to_play_page_layout()
		title_font, title_linesize, body_font, body_linesize, margin_x, title_y, body_y, body_width, footer_top = layout
		pages = self.get_how_to_play_pages()
		self.how_to_play_page = max(0, min(len(pages) - 1, self.how_to_play_page))
		self.draw_how_to_play_page(pages[self.how_to_play_page], layout)
		self.draw_how_to_play_footer(pages, body_font, body_linesize)

	def how_to_play_page_adjust(self, delta):
		pages = self.get_how_to_play_pages()
		self.how_to_play_page = (self.how_to_play_page + delta) % len(pages)
		self.examine_target = None
		self.play_sound("menu_confirm")

	def close_how_to_play(self):
		self.play_sound("menu_abort")
		self.state = self.how_to_play_return_state
		self._examine_target = self.how_to_play_return_examine_target
		self._examine_index = self.how_to_play_return_examine_index
		self._examine_extras = self.get_extra_examine_targets()

	def process_how_to_play_input(self):
		m_loc = self.get_mouse_pos()
		for evt in self.events:
			if evt.type == pygame.KEYDOWN:
				if evt.key in self.key_binds[KEY_BIND_ABORT]:
					self.close_how_to_play()
					return

				if evt.key in self.key_binds[KEY_BIND_LEFT] or evt.key in self.key_binds[KEY_BIND_UP]:
					self.how_to_play_page_adjust(-1)
					continue

				if evt.key in self.key_binds[KEY_BIND_RIGHT] or evt.key in self.key_binds[KEY_BIND_DOWN] or evt.key in self.key_binds[KEY_BIND_CONFIRM]:
					self.how_to_play_page_adjust(1)
					continue

			if evt.type == pygame.MOUSEBUTTONDOWN:
				if evt.button == pygame.BUTTON_RIGHT:
					self.close_how_to_play()
					return
				if evt.button != pygame.BUTTON_LEFT: continue

				target = self.get_ui_target(*m_loc)
				if target == HOW_TO_PLAY_PREV: self.how_to_play_page_adjust(-1)
				elif target == HOW_TO_PLAY_NEXT: self.how_to_play_page_adjust(1)
				else: self.how_to_play_page_adjust(1)

			if evt.type == pygame.MOUSEWHEEL:
				if evt.y > 0: self.how_to_play_page_adjust(-1); continue
				elif evt.y < 0: self.how_to_play_page_adjust(1); continue

		dx, dy = self.get_mouse_rel()
		if dx or dy:
			hovered = None
			for rect, option in self.ui_rects:
				if rect.collidepoint(m_loc):
					hovered = option
					break

			if hovered is not None:
				if self.examine_target != hovered: self.play_sound("menu_confirm")
				self.examine_target = hovered
			else:
				self.examine_target = None

	def show_help(self):
		pages = self.get_how_to_play_pages()
		if self.state != STATE_HOW_TO_PLAY:
			self.how_to_play_return_state = self.state
			self.how_to_play_return_examine_target = self._examine_target
			self.how_to_play_return_examine_index = self._examine_index
		self.state = STATE_HOW_TO_PLAY
		if self.how_to_play_page is None: self.how_to_play_page = 0
		self.how_to_play_page = self.how_to_play_page % len(pages)
		self.examine_target = None

	def show_credits(self):
		self.state = STATE_MESSAGE
		self.center_message = True
		self.message = text.credits_text
		self.next_messages = []

	def adjust_volume(self, amount, stype):
		if not self.can_play_sound: return

		cur_volume = self.options['%s_volume' % stype]
		new_volume = cur_volume + amount

		new_volume = new_volume % 105

		self.options['%s_volume' % stype] = new_volume

		if stype == 'music':
			pygame.mixer.music.set_volume(new_volume / 125.0)

		if stype == 'sound':
			for channel, base_volume in self.base_volumes.items():
				channel.set_volume(base_volume * new_volume / 165.0)

		self.save_options()

	def adjust_window_mode(self, amount):
		cur_mode = self.options.get('window_mode', WINDOW_MODE_FULLSCREEN)
		idx = WINDOW_MODE_CHOICES.index(cur_mode)
		next_idx = (idx + amount) % len(WINDOW_MODE_CHOICES)

		self.window_mode = WINDOW_MODE_CHOICES[next_idx]
		self.options['window_mode'] = self.window_mode

		self.apply_window_mode()
		self.options_menu_x = None
		self.save_options()

	def apply_save_preferences(self):
		if not self.game: return
		self.game.autosave_enabled = bool(self.options.get('autosave_progress', False))
		if self.options.get('save_prev_runs', False):
			self.game.keep_run_count = None
		else:
			self.game.keep_run_count = 1

	def finalize_save_preferences(self):
		if self.game and not self.options.get('save_prev_runs', False):
			self.game.prune_old_runs()

	def save_options(self):
		with open('options2.dat', 'wb') as options_file:
			self.options['key_binds'] = self.serialize_key_binds(self.key_binds)
			pickle.dump(self.options, file=options_file)

	def exit_options(self):
		if self.game:
			self.game.save_game()
		self.return_to_title()

	def process_options_input(self):
		entries = self.get_options_entries()
		if entries and self.examine_target not in entries and self.examine_target is not None: self.examine_target = entries[0]
		m_loc = self.get_mouse_pos()
		for evt in [e for e in self.events if e.type == pygame.KEYDOWN]:

			if entries and evt.key in self.key_binds[KEY_BIND_UP]:
				if self.examine_target is None: self.examine_target = entries[0]
				elif self.examine_target in entries:
					idx = entries.index(self.examine_target)
					self.examine_target = entries[(idx - 1) % len(entries)]
				self.play_sound("menu_confirm")
				continue

			if entries and evt.key in self.key_binds[KEY_BIND_DOWN]:
				if self.examine_target is None: self.examine_target = entries[0]
				elif self.examine_target in entries:
					idx = entries.index(self.examine_target)
					self.examine_target = entries[(idx + 1) % len(entries)]
				self.play_sound("menu_confirm")
				continue

			if evt.key in self.key_binds[KEY_BIND_LEFT]:
				if self.examine_target == OPTION_MUSIC_VOLUME:
					self.play_sound("menu_confirm")
					self.adjust_volume(-5, 'music')
				elif self.examine_target == OPTION_SOUND_VOLUME:
					self.play_sound("menu_confirm")
					self.adjust_volume(-5, 'sound')
				elif self.examine_target == OPTION_SPELL_SPEED:
					self.play_sound("menu_confirm")
					self.options['spell_speed'] = (self.options['spell_speed'] - 1) % 4
				elif self.examine_target == OPTION_WINDOW_MODE:
					self.play_sound("menu_confirm")
					self.adjust_window_mode(-1)
				continue

			if evt.key in self.key_binds[KEY_BIND_RIGHT]:
				if self.examine_target == OPTION_MUSIC_VOLUME:
					self.adjust_volume(5, 'music')
					self.play_sound("menu_confirm")
				elif self.examine_target == OPTION_SOUND_VOLUME:
					self.adjust_volume(5, 'sound')
					self.play_sound("menu_confirm")
				elif self.examine_target == OPTION_SPELL_SPEED:
					self.options['spell_speed'] = (self.options['spell_speed'] + 1) % 4
					self.play_sound("menu_confirm")
				elif self.examine_target == OPTION_WINDOW_MODE:
					self.play_sound("menu_confirm")
					self.adjust_window_mode(1)
				continue

			if evt.key in self.key_binds[KEY_BIND_CONFIRM]:
				target = self.examine_target
				if target == OPTION_EXIT:
					if self.game: self.game.save_game()
					self.return_to_title()
				elif target == OPTION_RETURN and self.game:
					self.play_sound("menu_confirm")
					self.state = STATE_LEVEL
				elif target == OPTION_LANGUAGE_SELECT:
					self.play_sound("menu_confirm")
					self.open_language_menu(STATE_OPTIONS)
				elif target == OPTION_SAVE_PREFERENCES:
					self.play_sound("menu_confirm")
					self.open_save_preferences()
				elif target == OPTION_WARDROBE:
					self.play_sound("menu_confirm")
					self.open_wardrobe()
				elif target == OPTION_CONTROLS:
					self.open_key_rebind()
				elif target == OPTION_SPELL_SPEED:
					self.options['spell_speed'] = (self.options['spell_speed'] + 1) % 4
				elif self.examine_target == OPTION_WINDOW_MODE:
					self.play_sound("menu_confirm")
					self.adjust_window_mode(1)
				continue

			if evt.key in self.key_binds[KEY_BIND_ABORT]:
				if self.game: self.state = STATE_LEVEL
				else: self.return_to_title()
				self.play_sound("menu_confirm")

		dx, dy = self.get_mouse_rel()
		if dx or dy:
			hovered = None
			for rect, option in self.ui_rects:
				if rect.collidepoint(m_loc):
					hovered = option
					break

			if hovered is not None:
				if self.examine_target != hovered:
					self.play_sound("menu_confirm")
				self.examine_target = hovered
			else:
				self.examine_target = None

		for evt in [e for e in self.events if e.type == pygame.MOUSEBUTTONDOWN]:
			if evt.button not in (pygame.BUTTON_LEFT, pygame.BUTTON_RIGHT):
				continue

			clicked_option = None
			for rect, option in self.ui_rects:
				if rect.collidepoint(m_loc):
					clicked_option = option
					break

			if evt.button == pygame.BUTTON_LEFT:
				if clicked_option is None: continue
				self.examine_target = clicked_option
				self.play_sound("menu_confirm")

				if clicked_option == OPTION_EXIT:
					self.save_options()
					if self.game: self.game.save_game()
					self.return_to_title()
				elif clicked_option == OPTION_RETURN and self.game:
					self.state = STATE_LEVEL
				elif clicked_option == OPTION_LANGUAGE_SELECT:
					self.open_language_menu(STATE_OPTIONS)
				elif clicked_option == OPTION_CONTROLS:
					self.open_key_rebind()
				elif clicked_option == OPTION_SOUND_VOLUME:
					self.adjust_volume(5, 'sound')
				elif clicked_option == OPTION_MUSIC_VOLUME:
					self.adjust_volume(5, 'music')
				elif clicked_option == OPTION_SPELL_SPEED:
					self.options['spell_speed'] = (self.options['spell_speed'] + 1) % 4
				elif clicked_option == OPTION_WINDOW_MODE:
					self.adjust_window_mode(1)
				elif clicked_option == OPTION_SAVE_PREFERENCES:
					self.open_save_preferences()
				elif clicked_option == OPTION_WARDROBE:
					self.open_wardrobe()

			elif evt.button == pygame.BUTTON_RIGHT:
				self.examine_target = clicked_option
				self.play_sound("menu_confirm")

				if clicked_option == OPTION_SOUND_VOLUME:
					self.adjust_volume(-5, 'sound')
				elif clicked_option == OPTION_MUSIC_VOLUME:
					self.adjust_volume(-5, 'music')
				elif clicked_option == OPTION_SPELL_SPEED:
					self.options['spell_speed'] = (self.options['spell_speed'] - 1) % 4
				else:
					self.play_sound('menu_confirm')
					if self.game: self.state = STATE_LEVEL
					else: self.return_to_title()

	def process_save_preferences_input(self):
		entries = self.get_save_pref_entries()
		if entries and self.examine_target not in entries and self.examine_target is not None: self.examine_target = entries[0]
		m_loc = self.get_mouse_pos()
		for evt in [e for e in self.events if e.type == pygame.KEYDOWN]:

			if entries and evt.key in self.key_binds[KEY_BIND_UP]:
				if self.examine_target is None: self.examine_target = entries[0]
				elif self.examine_target in entries:
					idx = entries.index(self.examine_target)
					self.examine_target = entries[(idx - 1) % len(entries)]
				self.play_sound("menu_confirm")
				continue

			if entries and evt.key in self.key_binds[KEY_BIND_DOWN]:
				if self.examine_target is None: self.examine_target = entries[0]
				elif self.examine_target in entries:
					idx = entries.index(self.examine_target)
					self.examine_target = entries[(idx + 1) % len(entries)]
				self.play_sound("menu_confirm")
				continue

			if evt.key in self.key_binds[KEY_BIND_LEFT] or evt.key in self.key_binds[KEY_BIND_RIGHT] or evt.key in self.key_binds[KEY_BIND_CONFIRM]:
				target = self.examine_target
				if target == SAVE_PREF_BACK:
					self.play_sound("menu_confirm")
					self.finalize_save_preferences()
					self.state = STATE_OPTIONS
				elif target in entries:
					self.play_sound("menu_confirm")
					self.toggle_save_pref(target)
				continue

			if evt.key in self.key_binds[KEY_BIND_ABORT]:
				self.play_sound("menu_confirm")
				self.finalize_save_preferences()
				self.state = STATE_OPTIONS

		dx, dy = self.get_mouse_rel()
		if dx or dy:
			hovered = None
			for rect, option in self.ui_rects:
				if rect.collidepoint(m_loc):
					hovered = option
					break

			if hovered is not None:
				if self.examine_target != hovered:
					self.play_sound("menu_confirm")
				self.examine_target = hovered
			else:
				self.examine_target = None

		for evt in [e for e in self.events if e.type == pygame.MOUSEBUTTONDOWN]:
			if evt.button not in (pygame.BUTTON_LEFT, pygame.BUTTON_RIGHT):
				continue

			clicked_option = None
			for rect, option in self.ui_rects:
				if rect.collidepoint(m_loc):
					clicked_option = option
					break

			if evt.button == pygame.BUTTON_LEFT:
				if clicked_option is None: continue
				self.examine_target = clicked_option
				self.play_sound("menu_confirm")

				if clicked_option == SAVE_PREF_BACK:
					self.finalize_save_preferences()
					self.state = STATE_OPTIONS
				else:
					self.toggle_save_pref(clicked_option)

			elif evt.button == pygame.BUTTON_RIGHT:
				self.play_sound("menu_confirm")
				self.finalize_save_preferences()
				self.state = STATE_OPTIONS


	def open_combat_log(self, from_death=False):
		self.leave_shop_context()
		self.set_combat_log_query_focus(False, clear=True)
		self.combat_log_cache = {}
		self.combat_log_level = self.game.level_num

		if self.game.cur_level.turn_no == 1 and self.game.level_num > 1:
			self.combat_log_level = self.game.level_num - 1

		max_turn = self.combat_log_max_turn()
		if from_death: default_turn = max_turn or 1
		else:
			if self.combat_log_level == self.game.level_num:
				previous = max(1, self.game.cur_level.turn_no - 1)
				default_turn = min(max_turn or 1, previous)
			else: default_turn = max_turn or 1

		self.set_combat_log_display(self.combat_log_level, default_turn)

		self.state = STATE_COMBAT_LOG

	def get_combat_log(self, level):
		if level not in self.combat_log_cache:
			self.combat_log_cache[level] = self.game.load_combat_log(level)
		return self.combat_log_cache[level]

	def set_combat_log_display(self, level, turn):
		self.combat_log_level = level
		self.combat_log_turn = turn
		combat_log = self.get_combat_log(level)
		self.combat_log_lines = combat_log.get(turn, [])
		self.combat_log_max_turn_value = max(combat_log, default=1)
		self.combat_log_query_prev = ""
		self.rebuild_combat_log_matches()

	def draw_combat_log(self):
		cur_x = self.border_margin
		cur_y = self.border_margin

		self.middle_menu_display.fill((0, 0, 0))

		can_prev = self.combat_log_turn > 1 or self.combat_log_level > 1
		can_next = self.combat_log_turn < self.combat_log_max_turn_value or self.combat_log_level < self.game.level_num
		prev_text = "<<<< Previous Turn"
		next_text = "Next Turn >>>>"
		header_text = ("Level {level} - Turn {turn}", {"level": self.combat_log_level, "turn": self.combat_log_turn})
		prev_color = (255, 255, 255) if can_prev else HIGHLIGHT_COLOR
		next_color = (255, 255, 255) if can_next else HIGHLIGHT_COLOR
		next_x = self.middle_menu_display.get_width() - self.border_margin - cached_size(self.font, next_text)

		self.draw_string(prev_text, self.middle_menu_display, cur_x, cur_y, prev_color, mouse_content=(COMBAT_LOG_PREV_TARGET if can_prev else None), pre_resolved=True)
		self.draw_string(header_text, self.middle_menu_display, 0, cur_y, center=True, content_width=self.middle_menu_display.get_width())
		self.draw_string(next_text, self.middle_menu_display, next_x, cur_y, next_color, mouse_content=(COMBAT_LOG_NEXT_TARGET if can_next else None), pre_resolved=True)
		cur_y += self.linesize * 2

		self.draw_search_bar(self.middle_menu_display, cur_x, cur_y, self.combat_log_query, self.combat_log_query_focused)
		cur_y += self.linesize * 2

		log_lines = self.combat_log_match_lines if self.combat_log_query else self.combat_log_lines
		if log_lines:
			for line in log_lines[self.combat_log_offset:]:
				lines = self.draw_wrapped_string(line, self.middle_menu_display, cur_x, cur_y, self.middle_menu_width - 2 * self.border_margin, pre_resolved=True, cache_ok=False)
				cur_y += lines * self.linesize
				if cur_y + self.border_margin > self.middle_menu_display.get_height(): break

		self.screen.blit(self.middle_menu_display, (self.h_margin, 0))

	def combat_log_max_turn(self):
		return max(self.get_combat_log(self.combat_log_level), default=1)

	def combat_log_scroll(self, direction):
		old_level = self.combat_log_level
		old_turn = self.combat_log_turn
		min_turn = 1
		max_turn = self.combat_log_max_turn_value

		min_level = 1
		max_level = self.game.level_num

		self.combat_log_turn += direction
		# Trying to go to prev level
		if self.combat_log_turn < min_turn:
			# Go to prev level if possible
			if self.combat_log_level > min_level:
				self.combat_log_level -= 1
				self.combat_log_turn = self.combat_log_max_turn()
			# Else undo change
			else:
				self.combat_log_turn -= direction
		# Trying to go to next level
		elif self.combat_log_turn > max_turn:


			# Go to next level if possible
			if self.combat_log_level < max_level:
				self.combat_log_level += 1
				self.combat_log_turn = min_turn
			# Else undo change
			else:
				self.combat_log_turn -= direction

		if self.combat_log_level == old_level and self.combat_log_turn == old_turn: return False
		self.set_combat_log_display(self.combat_log_level, self.combat_log_turn)
		return True

	def close_combat_log(self):
		self.set_combat_log_query_focus(False)
		self.play_sound("menu_abort")
		self.state = STATE_LEVEL

	def process_combat_log_input(self):
		available_height = self.middle_menu_display.get_height() - 2 * self.border_margin - 4 * self.linesize  # for pgup and pgdown in log
		lines_per_page = max(1, available_height // self.linesize)  # Ensure at least one line

		was_focused = self.combat_log_query_focused

		for evt in self.events:
			if evt.type == pygame.MOUSEWHEEL:
				log_lines = self.combat_log_match_lines if self.combat_log_query else self.combat_log_lines
				max_offset = max(0, len(log_lines) - 1)
				if evt.y: self.combat_log_offset = max(0, min(max_offset, self.combat_log_offset - evt.y))
				continue

			if evt.type == pygame.TEXTINPUT:
				if was_focused: self.update_combat_log_query(self.combat_log_query + evt.text)
				continue

			if evt.type == pygame.KEYDOWN:
				if self.combat_log_query_focused:
					if evt.key in self.key_binds[KEY_BIND_CONFIRM]: self.set_combat_log_query_focus(False)
					elif evt.key in self.key_binds[KEY_BIND_ABORT]: self.set_combat_log_query_focus(False, clear=True)
					elif evt.key == pygame.K_BACKSPACE:
						self.update_combat_log_query(self.combat_log_query[:-1])
						if evt.key not in self.repeat_keys: self.repeat_keys[evt.key] = time.time() + REPEAT_DELAY
					continue

				if evt.key in self.key_binds[KEY_BIND_QUERY]: self.set_combat_log_query_focus(True); continue
				if evt.key in self.key_binds[KEY_BIND_ABORT]: self.close_combat_log(); continue
				if evt.key in self.key_binds[KEY_BIND_MESSAGE_LOG]: self.close_combat_log(); continue

				log_lines = self.combat_log_match_lines if self.combat_log_query else self.combat_log_lines
				max_offset = max(0, len(log_lines) - 1)
				if evt.key in self.key_binds[KEY_BIND_UP]: self.combat_log_offset = max(0, self.combat_log_offset - 1)
				if evt.key in self.key_binds[KEY_BIND_PREV_EXAMINE_TARGET]: self.combat_log_offset = max(0, self.combat_log_offset - lines_per_page)
				if evt.key in self.key_binds[KEY_BIND_DOWN]: self.combat_log_offset = min(max_offset, self.combat_log_offset + 1)
				if evt.key in self.key_binds[KEY_BIND_NEXT_EXAMINE_TARGET]: self.combat_log_offset = min(max_offset, self.combat_log_offset + lines_per_page)
				if evt.key in self.key_binds[KEY_BIND_LEFT] and self.combat_log_scroll(-1): self.play_sound("menu_confirm")
				if evt.key in self.key_binds[KEY_BIND_RIGHT] and self.combat_log_scroll(1): self.play_sound("menu_confirm")
				continue

			if evt.type == pygame.MOUSEBUTTONDOWN:
				if evt.button not in (pygame.BUTTON_LEFT, pygame.BUTTON_RIGHT): continue
				m_loc = self.get_mouse_pos()
				clicked = self.get_ui_target(*m_loc)

				if evt.button == pygame.BUTTON_LEFT:
					if clicked is None: continue
					if clicked == SEARCH_INPUT_TARGET: self.set_combat_log_query_focus(True); continue
					self.set_combat_log_query_focus(False)
					if clicked == COMBAT_LOG_PREV_TARGET and self.combat_log_scroll(-1): self.play_sound("menu_confirm")
					elif clicked == COMBAT_LOG_NEXT_TARGET and self.combat_log_scroll(1): self.play_sound("menu_confirm")

				elif evt.button == pygame.BUTTON_RIGHT:
					if self.combat_log_query_focused: self.set_combat_log_query_focus(False, clear=True); break
					self.close_combat_log()

	def set_combat_log_query_focus(self, focused, clear=False):
		if clear: self.update_combat_log_query("")
		if focused == self.combat_log_query_focused: return
		self.combat_log_query_focused = focused
		if self.combat_log_query_focused:
			self.repeat_keys.clear()
			pygame.key.start_text_input()
		else:
			pygame.key.stop_text_input()

	def update_combat_log_query(self, query):
		self.combat_log_query = query
		self.rebuild_combat_log_matches()

	def rebuild_combat_log_matches(self):
		q = self.combat_log_query or ''
		if not q.strip():
			self.combat_log_match_lines = []
			self.combat_log_query_prev = ""
			self.combat_log_offset = 0
			return

		base_lines = self.combat_log_lines
		if self.combat_log_query_prev and q.startswith(self.combat_log_query_prev):
			base_lines = self.combat_log_match_lines

		matches = []
		for line in base_lines:
			if self.match_combat_log_line(line, q):
				matches.append(line)
		self.combat_log_match_lines = matches
		self.combat_log_query_prev = q
		self.combat_log_offset = 0

	def match_combat_log_line(self, line, query):
		if not query: return True
		tokens = self.split_search_tokens(line)
		return self.match_search_tokens(tokens, query)

	def fast_new_game(self):
		self.game = Game()
		self.apply_selected_wardrobe_outfit()
		self.clear_shop_filter_cache()
		self.build_search_cache()
		self.apply_save_preferences()
		self.finalize_save_preferences()
		self.state = STATE_LEVEL
		self.play_battle_music()

		SteamAdapter.set_presence_game(self.game)

	def new_game(self, mutators=None, trial_name=None, seed=None):

		# If you are overwriting an old game, break streak
		if can_continue_game(): SteamAdapter.record_loss()

		self.game = Game(save_enabled=True, mutators=mutators, trial_name=trial_name, seed=seed)
		self.apply_selected_wardrobe_outfit()
		self.clear_shop_filter_cache()
		self.build_search_cache()
		self.apply_save_preferences()
		self.finalize_save_preferences()
		self.message = text.intro_text
		self.draw_combat_log_button = False

		if mutators:
			self.message += "\n\n\n\nChallenge Modifiers:"
			for mutator in mutators:
				self.message += "\n" + resolve_text(mutator.get_description(), fmt=mutator.fmt_dict())

		self.center_message = True
		self.state = STATE_MESSAGE

		self.play_battle_music()

		if self.options.get('save_screenshots', False): self.make_level_screenshot(finished=False)
		SteamAdapter.set_presence_game(self.game)

	def get_next_battle_track(self):
		if self.track_queue: return self.track_queue.pop()
		tracks = list(range(2, 13))
		if self.last_battle_track in tracks and len(tracks) > 1: tracks.remove(self.last_battle_track)
		first_track = random.choice(tracks)
		tracks.remove(first_track)

		random.shuffle(tracks)
		self.track_queue = tracks
		return first_track

	def play_battle_music(self, num=None):
		if num is None: num = self.get_next_battle_track()
		song_name = 'battle_%d' % num
		self.play_music(song_name)

	def make_level_screenshot(self, finished=True):
		self.draw_level()
		self.draw_character()
		self.examine_target = None
		self.draw_examine()
		self.draw_ui_frame()
		suffix = 'finish' if finished else 'begin'
		filename = os.path.join('saves', str(self.game.run_number), 'level_%d_%s.png' % (self.game.level_num, suffix))
		dirname = os.path.dirname(filename)
		if not os.path.exists(dirname): os.makedirs(dirname)
		pygame.image.save(self.screen, filename)

	def draw_level_stats(self):
		self.examine_display.fill((0, 0, 0))
		if not self.game: return
		cache_key = (self.game.run_number, self.game.level_num)
		lines = None
		if self.level_stats_cache_key == cache_key: lines = self.level_stats_cache
		stats_filename = os.path.join('saves', str(self.game.run_number), 'stats.level_%d.txt' % self.game.level_num)
		if lines is None:
			if os.path.exists(stats_filename):
				with open(stats_filename, 'r', encoding='utf-8') as statfile:
					lines = [s.strip() for s in statfile.readlines()]
			else:
				lines = self.game.pending_level_stats.get(self.game.level_num)
				if lines is None: return  # Occurs when cheating in debug

			self.level_stats_cache = lines
			self.level_stats_cache_key = cache_key
		if not lines: return  # Occurs when cheating in debug

		border_margin = self.border_margin
		cur_x = border_margin
		cur_y = border_margin
		for line in lines:
			num_lines = self.draw_wrapped_string(line, self.examine_display, cur_x, cur_y, width=self.examine_display.get_width() - (self.border_margin*2), indent=True, pre_resolved=True)
			cur_y += max(1, num_lines) * self.linesize

	def make_game_end_screenshot(self):
		self.draw_char_sheet(show_available_upgrades=False)
		self.draw_character()
		self.draw_examine()
		self.draw_ui_frame()
		filename = os.path.join('saves', str(self.game.run_number), 'char_sheet.png')
		dirname = os.path.dirname(filename)
		if not os.path.exists(dirname): os.makedirs(dirname)
		pygame.image.save(self.screen, filename)

	def load_game(self, filename=None):
		self.game = continue_game(filename=filename)
		self.apply_selected_wardrobe_outfit()
		self.clear_shop_filter_cache()
		self.build_search_cache()
		self.apply_save_preferences()
		self.state = STATE_LEVEL
		self.on_music_end()
		SteamAdapter.set_presence_game(self.game)

	def return_to_title(self):
		self.game = None
		self.terrain_level = None
		self.terrain_generation = -1
		self.cur_spell = None
		self.cur_spell_target = None
		self.targetable_tiles = None
		self.effects = []
		self.effect_queue = []
		self.effect_queue_tile_counts = {}
		self.spell_speed_flash_frames = 0
		self.state = STATE_TITLE
		self.gameover_frames = 0
		self.gameover_tiles = None
		self.gameover_level_display = None
		self.gameover_anim_frame = 0
		self.deploy_anim_frames = 0

		self.title_can_continue = can_continue_game()
		if self.title_can_continue: self.examine_target = TITLE_SELECTION_LOAD
		else: self.examine_target = TITLE_SELECTION_NEW

		if self.current_music != 'title_theme' or not self.music_is_busy(): self.play_music('title_theme')

		SteamAdapter.set_presence_menu()


	def open_options(self):
		self.leave_shop_context()
		self.play_sound("menu_confirm")
		self.state = STATE_OPTIONS
		self.examine_target = 0
		self.options_menu_x = None

	def open_mods(self):
		self.play_sound("menu_confirm")
		self.state = STATE_MODS
		self.mods_menu_status = ""
		self.mods_menu_upload_selecting = False
		self.mods_menu_upload_options = []
		if self.refresh_mod_menu(): self.save_options()
		if self.mods_menu_enabled_on_boot is None:
			self.mods_menu_enabled_on_boot = list(self.options['enabled_mods'])
		self.mods_menu_enabled_on_open = list(self.options['enabled_mods'])
		self.mods_menu_disabled_on_open = list(self.mods_menu_disabled_names)
		default_target = self.get_default_mod_menu_target()
		default_group = self.get_mod_menu_target_group(default_target) or 'actions'
		self.set_mod_menu_focus(default_group, default_target)

	def draw_gameover(self):

		if self.gameover_frames == 8:
			self.gameover_tiles = [(x, y) for x in range(LEVEL_SIZE) for y in range(LEVEL_SIZE)]
			random.shuffle(self.gameover_tiles)
			self.gameover_level_display = self.level_display.copy()
		if self.gameover_frames < 8: return

		speed = (self.gameover_frames - 12) // 25

		for i in range(speed):
			if not self.gameover_tiles: break
			x, y = self.gameover_tiles.pop()
			rect = (x * SPRITE_SIZE,
					y * SPRITE_SIZE,
					SPRITE_SIZE,
					SPRITE_SIZE)
			pygame.draw.rect(self.gameover_level_display, (0, 0, 0), rect)

		if self.gameover_tiles:
			self.level_display.blit(self.gameover_level_display, (0, 0))

		if not self.gameover_tiles:
			self.screen.fill((0, 0, 0))
			frames = self.victory_frames if self.game.victory else self.defeat_frames
			text_surface = self.victory_image if self.game.victory else self.defeat_image
			victory_lines = [line for line in text.victory_text.splitlines() if line.strip()] if self.game.victory else None

			if self.gameover_anim_frame >= len(frames): self.gameover_anim_frame = len(frames) - 1

			if cloud_frame_clock % 6 == 0:
				last = len(frames) - 1
				if self.gameover_anim_frame < last: self.gameover_anim_frame += 1 # progress through the strip
				else: self.gameover_anim_frame -= 1 # bounce back to the previous one on reaching the end

			frame = frames[self.gameover_anim_frame]
			frame_x = self.screen.get_width() // 2 - frame.get_width() // 2
			frame_y = self.screen.get_height() // 2.5 - frame.get_height() // 2
			self.screen.blit(frame, (frame_x, frame_y))

			text_x = self.screen.get_width() // 2 - text_surface.get_width() // 2
			text_y = frame_y + frame.get_height() - text_surface.get_height() + int(SPRITE_SIZE * 1.5)
			self.screen.blit(text_surface, (text_x, text_y))

			if victory_lines:
				cur_y = text_y + text_surface.get_height() + self.linesize
				for line in victory_lines:
					self.draw_string(line, self.screen, 0, cur_y, center=True, content_width=self.screen.get_width())
					cur_y += self.linesize

	def run(self):

		self.running = True
		profile = False

		gc.collect()
		_, gen1_threshhold, gen2_threshhold = gc.get_threshold()
		gc.set_threshold(7000, gen1_threshhold, gen2_threshhold)
		gc.enable()

		frame_time = 0

		if "newgame" in sys.argv: self.fast_new_game()

		while self.running:

			global cloud_frame_clock
			cloud_frame_clock += 1
			cloud_frame_clock %= 100000

			global idle_frame, idle_subframe
			idle_subframe += 1
			if idle_subframe >= SUB_FRAMES[ANIM_IDLE]:
				idle_subframe = 0
				idle_frame += 1
				idle_frame = idle_frame % 100000


			frame_ms = self.clock.tick(30)
			self.events = pygame.event.get()

			keys = pygame.key.get_pressed()

			for repeat_key, repeat_time in list(self.repeat_keys.items()):

				if keys[repeat_key] and time.time() > repeat_time:
					self.events.append(pygame.event.Event(pygame.KEYDOWN, key=repeat_key))
					self.repeat_keys[repeat_key] = time.time() + REPEAT_INTERVAL

				if not keys[repeat_key]:
					del self.repeat_keys[repeat_key]

			for sound in list(self.sound_cooldowns.keys()):
				self.sound_cooldowns[sound] -= 1
				if self.sound_cooldowns[sound] <= 0:
					del(self.sound_cooldowns[sound])

			self.mouse_dx = 0
			self.mouse_dy = 0
			refresh_scaled_display = False
			refresh_display_bounds = False

			for event in self.events:
				if event.type == pygame.MOUSEMOTION:
					self.mouse_dx += event.rel[0]
					self.mouse_dy += event.rel[1]

				if event.type == pygame.QUIT:
					if self.game and self.game.p1.is_alive():
						self.game.save_game()
					self.running = False

				# Allow repeating of directional keys (but no other keys)
				if event.type == pygame.KEYDOWN and event.key not in self.repeat_keys:
					for bind in [KEY_BIND_LEFT, KEY_BIND_UP_LEFT, KEY_BIND_UP, KEY_BIND_UP_RIGHT,
								 KEY_BIND_RIGHT, KEY_BIND_DOWN_RIGHT, KEY_BIND_DOWN, KEY_BIND_DOWN_LEFT,
								 KEY_BIND_PASS]:
						if event.key in self.key_binds[bind]:
							self.repeat_keys[event.key] = time.time() + REPEAT_DELAY

				if event.type == pygame.VIDEORESIZE:
					self.resize_window(event)
					refresh_scaled_display = True
					if self.window_mode != WINDOW_MODE_WINDOWED: refresh_display_bounds = True
				if event.type == pygame.WINDOWMINIMIZED: self.window_minimized = True
				if event.type in (pygame.WINDOWRESTORED, pygame.WINDOWMAXIMIZED):
					self.window_minimized = False
					refresh_scaled_display = True
					refresh_display_bounds = True
				if event.type == pygame.WINDOWDISPLAYCHANGED:
					self.update_display(event.display_index)
					refresh_scaled_display = True
					if self.window_mode == WINDOW_MODE_WINDOWED and not self.is_window_maximized():
						self.options['windowed_size'] = self.normalized_window_size(pygame.display.get_window_size())
				if event.type in (pygame.RENDER_TARGETS_RESET, pygame.RENDER_DEVICE_RESET):
					refresh_scaled_display = True
					refresh_display_bounds = True

				if event.type == MUSIC_OVER_EVENT: self.on_music_stream_end()

			if refresh_display_bounds: self.update_display(self.display_window.display_index)
			if refresh_scaled_display: self.refresh_scaled_renderer()

			if profile:
				import cProfile
				import pstats
				pr = cProfile.Profile()
				start = time.time()
				pr.enable()


			self.mouse_pos = self.get_mouse_pos()

			# Reset examine target if mouse was moved and not in any ui rects
			if self.mouse_dy or self.mouse_dx:
				mouse_in_rect = any(r.collidepoint(self.mouse_pos) for r, _ in self.ui_rects)
				if not mouse_in_rect:
					mx, _ = self.mouse_pos
					if self.state == STATE_TITLE:
						pass
					elif self.state == STATE_LEVEL and mx > self.h_margin:
						pass
					elif self.state == STATE_REBIND:
						pass
					else:
						self.examine_target = None

			self.ui_rects = []

			self.frameno += 1

			if self.state != STATE_COMBAT_LOG:
				if self.gameover_frames < 8:
					if self.state != STATE_LEVEL: self.screen.fill((0, 0, 0)) # only fill if we're not on the level
				elif self.game:
					self.draw_gameover()
			else:
				# While viewing the combat log after death, skip the level blackout/tiling
				self.screen.fill((0, 0, 0))

			if self.state == STATE_TITLE:
				self.draw_title()
			elif self.state == STATE_MODS:
				self.draw_mods_menu()
			elif self.state == STATE_PICK_MODE:
				self.draw_pick_mode()
			elif self.state == STATE_PICK_TRIAL:
				self.draw_pick_trial()
			elif self.state == STATE_SETUP_CUSTOM:
				self.draw_setup_custom()
			elif self.state == STATE_PICK_MUTATOR_PARAMS:
				self.draw_pick_mutator_params()
			elif self.state == STATE_ENTER_MUTATOR_VALUE:
				self.draw_enter_mutator_value()
			elif self.state == STATE_OPTIONS:
				self.draw_options_menu()
			elif self.state == STATE_SAVE_PREFS:
				self.draw_save_preferences_menu()
			elif self.state == STATE_REBIND:
				self.draw_key_rebind()
			elif self.state == STATE_MESSAGE:
				self.draw_message()
			elif self.state == STATE_HOW_TO_PLAY:
				self.draw_how_to_play()
			elif self.state == STATE_REMINISCE:
				self.draw_reminisce()
			elif self.state == STATE_SELECT_LANGUAGE:
				self.draw_language_menu()
			else:
				if self.game:
					self.draw_character()
				if self.state == STATE_LEVEL:
					self.draw_level()
				if self.state == STATE_CHAR_SHEET:
					self.draw_char_sheet()
				if self.state == STATE_SHOP:
					self.draw_shop()
				if self.state == STATE_CONFIRM:
					self.draw_confirm()
				if self.state == STATE_COMBAT_LOG:
					self.draw_combat_log()
				if self.game or self.state == STATE_SHOP:
					self.draw_examine()
					self.draw_ui_frame()

				# Fail overlay on top of everything
				if self.state == STATE_LEVEL and self.cast_fail_frames > 0:
					self.draw_fail_overlay_on_center()

			if self.game and profile and frame_time > (1.0 / 60.0):
				pygame.draw.rect(self.screen, (255, 0, 0), (0, 0, 5, 5))
			self.draw_screen()

			if self.state in [STATE_LEVEL, STATE_CHAR_SHEET, STATE_SHOP]:
				self.process_examine_panel_input()

				if self.game and 'chronomancer_time_left_ds' in self.game.__dict__: # faster lookup than hasattr
					if self.game.is_awaiting_input() and not (self.game.gameover or self.game.victory):
						self.game.chronomancer_ms_carry_ds += frame_ms
						if self.game.chronomancer_ms_carry_ds >= 100:
							elapsed_ds = self.game.chronomancer_ms_carry_ds // 100
							self.game.chronomancer_ms_carry_ds -= elapsed_ds * 100
							self.game.chronomancer_time_left_ds = max(0, self.game.chronomancer_time_left_ds - elapsed_ds)
							if self.game.chronomancer_time_left_ds == 0 and self.game.p1.cur_hp > 0:
								self.game.cur_level.log("[Wizard:wizard] ran out of time.")
								self.game.p1.cur_hp = 0
								self.game.check_triggers()
								# quit shop / menus if you run out of time
								self.leave_shop_context()
								if self.state in [STATE_SHOP, STATE_CHAR_SHEET]:
									self.examine_target = None
									self.state = STATE_LEVEL

			advanced = False
			if self.game and self.state == STATE_LEVEL:

				if self.game.gameover or self.game.victory: self.gameover_frames += 1

				if self.gameover_frames == 1:
					# Redo the level end screenshot so that it has the red mordred (or wizard) flash frame
					self.make_level_screenshot()
					self.make_game_end_screenshot()

					# Force level finish on victory- the level might not be finished but we are done
					if self.game.victory: self.play_music('victory_theme')

				if self.game and self.game.deploying and not self.deploy_target:
					self.deploy_target = Point(self.game.p1.x, self.game.p1.y)
					self.tab_targets = [t for t in self.game.next_level.iter_tiles() if t.prop and (isinstance(t.prop, Portal) or isinstance(t.prop, Shop) or isinstance(t.prop, ComponentPickup))]

				self.process_level_input()

				if self.game and self.game.victory_evt:
					if not self.victory_wait_frames and not self.game.victory and self.options.get('save_screenshots', False): self.make_level_screenshot()
					self.victory_wait_frames += 1
					if self.victory_wait_frames >= self.victory_delay_frames:
						self.game.victory_evt = False
						self.victory_wait_frames = 0
						self.on_level_finish()
				else: self.victory_wait_frames = 0

				if self.game and not self.game.is_awaiting_input() and not self.gameover_frames:
					self.threat_zone = None
					self.threatening_enemies_cache_key = None
					advanced = True

					top_spell = self.game.cur_level.active_spells[0] if self.game.cur_level.active_spells else None
					self.game.advance()

					# Continually advance everything in super turbo, attemptng to do full turn in 1 go
					if self.fast_forward or self.options['spell_speed'] == 3:
						while not self.game.is_awaiting_input() and not self.game.gameover and not self.game.victory:
							self.game.advance()
					# Do another spell advance on speed 1
					elif self.options['spell_speed'] == 1:
						if self.game.cur_level.active_spells and top_spell and top_spell == self.game.cur_level.active_spells[0]:
							self.game.advance()
					# Continually spell advance on speed 2 until the top spell is finished
					elif self.options['spell_speed'] == 2:
						while self.game.cur_level.active_spells and top_spell == self.game.cur_level.active_spells[0]:
							self.game.advance()


					# Check triggers
					if self.game.cur_level.cur_shop and not self.game.gameover: self.open_shop(SHOP_TYPE_SHOP)

			elif self.state == STATE_CHAR_SHEET:
				self.process_char_sheet_input()
			elif self.state == STATE_TITLE:
				self.process_title_input()
			elif self.state == STATE_MODS:
				self.process_mods_input()
			elif self.state == STATE_PICK_MODE:
				self.process_pick_mode_input()
			elif self.state == STATE_PICK_TRIAL:
				self.process_pick_trial_input()
			elif self.state == STATE_SETUP_CUSTOM:
				self.process_setup_custom_input()
			elif self.state == STATE_PICK_MUTATOR_PARAMS:
				self.process_pick_mutator_params_input()
			elif self.state == STATE_ENTER_MUTATOR_VALUE:
				self.process_enter_mutator_value_input()
			elif self.state == STATE_OPTIONS:
				self.process_options_input()
			elif self.state == STATE_SAVE_PREFS:
				self.process_save_preferences_input()
			elif self.state == STATE_REBIND:
				self.process_key_rebind()
			elif self.state == STATE_SHOP:
				self.process_shop_input()
			elif self.state == STATE_REMINISCE:
				self.process_reminisce_input()
			elif self.state == STATE_MESSAGE:
				self.process_message_input()
			elif self.state == STATE_HOW_TO_PLAY:
				self.process_how_to_play_input()
			elif self.state == STATE_CONFIRM:
				self.process_confirm_input()
			elif self.state == STATE_COMBAT_LOG:
				self.process_combat_log_input()
			elif self.state == STATE_SELECT_LANGUAGE:
				self.process_language_menu_input()


			self.process_post_victory_tasks()

			# If not examining anything- examine cur spell if possible
			if not self.examine_target and self.cur_spell and self.cur_spell.show_tt:
				if self.state == STATE_LEVEL: self.examine_target = self.cur_spell

			if self.game and profile:
				pr.disable()
				finish = time.time()
				frame_time = finish - start
				if frame_time > 1 / 10.0:
					print("draw time ms: %f" % (frame_time * 1000))
					stats = pstats.Stats(pr)
					stats.sort_stats("cumtime")
					stats.dump_stats("draw_profile.stats")
					stats.print_stats()

		self.save_options()

startup_options = load_saved_options()
ModHandler.load_mods(startup_options['enabled_mods'])
for tag in Tags: tooltip_colors.setdefault(tag.name.lower(), tag.color)

# Manually call this after loading mods as mods may impact the bestiary
make_bestiary()


import traceback
try:
	set_visual_mode(True)
	main_view = PyGameView()
	main_view.run()
except:
	traceback.print_exc(file=sys.stdout)
	print('')
	try:
		if main_view and main_view.game: main_view.game.write_crash_combat_log()
	except Exception:
		pass
	loaded_mods = ModHandler.get_loaded_mod_names()
	load_errors = ModHandler.get_load_errors()
	if loaded_mods:
		print("Loaded mods:")
		for mod in loaded_mods:
			print(mod)
	if load_errors:
		print("Mod load errors:")
		for error in load_errors:
			print(error)

	with open('crash.txt', 'w') as file:
		traceback.print_exc(file=file)
		if loaded_mods:
			file.write("Loaded mods:\n")
			for mod in loaded_mods:
				file.write(mod + '\n')
		if load_errors:
			file.write("Mod load errors:\n")
			for error in load_errors:
				file.write(error.rstrip() + '\n')
