from Level import *
from CommonContent import *
import random
from Monsters import *
from Spells import *
from Components import *
import sys


class UnblinkingEye(Equipment):

	def on_init(self):
		self.name = "Unblinking Eye"
		self.tags = [Tags.Eye]
		self.recipe = [(Tags.Enchantment, 1), (Tags.Eye, 1), (Tags.Any, 5)]

		self.tag_bonuses[Tags.Eye]['shot_cooldown'] = -1
		self.tag_bonuses_pct[Tags.Eye]['duration'] = 50
		self.tag_bonuses[Tags.Eye]['minion_duration'] = 10
		self.tag_bonuses[Tags.Eye]['max_charges'] = 2

class SlimeTimer(Equipment):

	def on_init(self):
		self.name = "Slime Timer"
		self.tags = [Tags.Arcane, Tags.Slime]
		self.recipe = [(Tags.Arcane, 1), (Tags.Slime, 1), (Tags.Any, 3)]
		self.global_triggers[EventOnUnitAdded] = self.on_added

	def on_added(self, evt):
		if are_hostile(evt.unit, self.owner): return
		if not Tags.Slime in evt.unit.tags: return
		buff = evt.unit.get_buff(SlimeBuff)
		if buff:
			self.do_ui_flash()
			buff.growth_chance += .25 # increase the growth chance
			buff.growth_chance = min(buff.growth_chance, 1)

	def get_description(self):
		return "When [Slime] allies are summoned, their chance to grow is increased by 25%"

class SlimeBirthCantromancy(Equipment):

	def on_init(self):
		self.name = "Slimebirth Cantromancy"
		self.tags = [Tags.Arcane, Tags.Slime]
		self.recipe = [(Tags.Arcane, 1), (Tags.Slime, 1), (Tags.Sorcery, 2), (Tags.Any, 4)]
		self.global_triggers[EventOnUnitAdded] = self.on_added

	def on_added(self, evt):
		if are_hostile(evt.unit, self.owner): return
		if not Tags.Slime in evt.unit.tags: return
		cantrips = [s for s in self.owner.spells if s.level==1]
		if not cantrips: return
		candidates = []
		for tag in evt.unit.tags:
			for c in cantrips:
				for ctag in c.tags:
					if tag == ctag:
						candidates.append(c)
		if not candidates: return

		s = random.choice(candidates)
		spell = type(s)()
		spell.caster = evt.unit
		spell.owner = evt.unit
		spell.statholder = self.owner
		target = spell.get_ai_target()
		if not target: return
		self.do_ui_flash()
		self.owner.level.act_cast(evt.unit, spell, target.x, target.y, pay_costs=False)

	def get_description(self):
		return ("When [Slime] allies are summoned, they cast a random level 1 spell you know that they share a tag with")


class PyrophiliaLocket(Equipment):

	def on_init(self):
		self.name = "Pyrophilia Locket"
		self.tags = [Tags.Fire, Tags.Nature]
		self.recipe = [(Tags.Fire, 1), (Tags.Nature, 1), (Tags.Any, 3)]
		self.global_triggers[EventOnDamaged] = self.on_dmg

	def on_dmg(self, event):
		if event.damage_type != Tags.Fire: return
		heal = event.damage // 2
		if heal <= 0: return
		if not are_hostile(self.owner, event.unit): return
		self.owner.level.queue_spell(self.do_los_heal(Point(event.unit.x, event.unit.y), heal))

	def do_los_heal(self, point, heal):
		counter = 0
		for u in self.owner.level.get_units_in_los(point):
			if u == self.owner: continue
			if are_friendly(self.owner, u): u.heal(heal, self)
			counter += 1
			if counter % 10 == 0: yield
		if counter: self.do_ui_flash()
		yield

	def get_description(self):
		return "When an enemy takes [Fire] damage, your allies in line of sight of them heal for half that damage"

class SoulHarvester(Equipment):

	def on_init(self):
		self.global_triggers[EventOnDeath] = self.on_death
		self.name = "Soul Harvester"
		self.tags = [Tags.Dark, Tags.Holy]
		self.recipe = [(Tags.Dark, 3), (Tags.Holy, 3), (Tags.Any, 4)]

	def on_death(self, evt):
		damage_event = evt.damage_event
		dtype = getattr(damage_event, 'damage_type', None)
		owner = self.owner
		show_effect = owner.level.show_effect

		# No harvesting your summons
		if not are_hostile(owner, evt.unit): return

		chance = .3 if dtype in [Tags.Dark, Tags.Holy] else .1
		if random.random() > chance: return
		self.do_ui_flash()
		for spell in owner.spells:
			if Tags.Dark in spell.tags:
				spell.refund_charges(1)
				spell.do_ui_flash(Tags.Dark)
				show_effect(owner.x, owner.y, Tags.Dark)
			elif Tags.Holy in spell.tags:
				spell.refund_charges(1)
				spell.do_ui_flash(Tags.Holy)
				show_effect(owner.x, owner.y, Tags.Holy)

	def get_description(self):
		return ("When an enemy dies, there is a 10% chance to regain a charge of your [Dark] and [Holy] spells\n"
				"This chance is tripled if they died to [Dark] or [Holy] damage")

class ArcaneCombustion(Equipment):

	def on_init(self):
		self.tags = [Tags.Arcane]
		self.recipe = [(Tags.Arcane, 1), (Tags.Any, 4)]
		self.name = "Arcane Combustion Powder"
		self.global_triggers[EventOnDeath] = self.on_death
		self.damage = 12
		self.radius = 1

	def on_death(self, evt):
		if evt.damage_event and evt.damage_event.damage_type == Tags.Arcane:
			self.owner.level.queue_spell(self.explosion(evt.unit))
			self.do_ui_flash()

	def explosion(self, evt):
		dmg = self.get_stat('damage')
		deal_dmg = self.owner.level.deal_damage
		tiles = self.owner.level.tiles
		for p in self.owner.level.get_points_in_ball(evt.x, evt.y, self.get_stat('radius')):
			deal_dmg(p.x, p.y, dmg, Tags.Arcane, self)
			if tiles[p.x][p.y].is_wall(): self.owner.level.make_floor(p.x, p.y)
		yield

	def get_description(self):
		return ("When a unit dies to [Arcane] damage, it explodes for [{damage}:damage] [Arcane] damage in a [{radius}:radius] tile burst\n"
				"Melts affected walls")

class SearingEyeStone(Equipment):

	def on_init(self):
		self.tags = [Tags.Eye, Tags.Fire]
		self.recipe = [(Tags.Eye, 1), (Tags.Fire, 1), (Tags.Any, 4)]
		self.name = "Searing Eye Stone"
		self.owner_triggers[EventOnSpellCast] = self.on_cast

	def on_cast(self, evt):
		if Tags.Fire in evt.spell.tags:
			units = list(self.owner.level.get_units_in_los(Point(evt.x, evt.y)))
			random.shuffle(units)
			self.do_ui_flash()
			for u in units:
				if not self.owner.level.are_hostile(u, self.owner): continue
				u.deal_damage(1, Tags.Fire, self)

	def get_description(self):
		return "When you cast a [Fire] spell, deal 1 [Fire] damage to enemies in line of sight of the target"

class MinionRegenerationAmulet(Equipment):

	def on_init(self):
		self.tags = [Tags.Nature, Tags.Holy]
		self.recipe = [(Tags.Nature, 1), (Tags.Holy, 1), (Tags.Any, 2)]
		self.name = "Minion Regeneration Amulet"

	def get_description(self):
		return "Each turn, heal each of your allies for [2 HP:heal]"

	def on_advance(self):
		for unit in self.owner.level.units:
			if unit != self.owner and not self.owner.level.are_hostile(unit, self.owner):
				if unit.cur_hp == unit.max_hp: continue
				unit.heal(2, self)

class GlitteringDancersRobes(Equipment):

	def on_init(self):
		self.tags = [Tags.Arcane, Tags.Conjuration, Tags.Translocation]
		self.recipe = [(Tags.Arcane, 1), (Tags.Conjuration, 1), (Tags.Translocation, 2), (Tags.Any, 2)]
		self.name = "Glittering Dancer's Robes"
		self.slot = SLOT_ARMOR

		self.owner_triggers[EventOnSpellCast] = self.on_spell_cast
		self.casts = 0
		self.cast_last = False

		self.minion_damage = 4
		self.minion_range = 4
		self.minion_duration = 10
		self.minion_health = 9
		self.num_summons = 2

	def get_extra_examine_tooltips(self):
		return [self.make_faery()]

	def get_description(self):
		return "When you cast three [Arcane] spells in a row, regain a charge of a random [Translocation] spell and summon [{num_summons}:num_summons] temporary Faeries"

	def on_advance(self):
		if not self.cast_last: self.casts = 0
		self.cast_last = False

	def make_faery(self):
		return make_minion(self, Faery)

	def on_spell_cast(self, evt):
		if Tags.Arcane in evt.spell.tags:
			if self.casts < 2:
				self.casts += 1
				self.cast_last = True
			else:
				self.casts = 0
				self.cast_last = False
				candidates = [s for s in self.owner.spells if Tags.Translocation in s.tags and s.cur_charges < s.get_stat('max_charges')]
				if candidates:
					candidate = random.choice(candidates)
					candidate.cur_charges += 1
					self.do_ui_flash()
					candidate.do_ui_flash(Tags.Translocation)

				for i in range(self.get_stat('num_summons')):
					unit = self.make_faery()
					self.summon(unit)

class WildHealingStaff(Equipment):

	def on_init(self):
		self.tags = [Tags.Nature]
		self.recipe = [(Tags.Nature, 3), (Tags.Any, 3)]
		self.name = "Wild Healing Staff"
		self.slot = SLOT_WEAPON
		self.trigger_tags = [Tags.Nature]
		self.owner_triggers[EventOnSpellCast] = self.on_spell_cast

	def get_description(self):
		return "When you cast a [Nature] spell, you and your [Living] allies heal [5 HP:heal]"

	def on_spell_cast(self, evt):
		if not any(t for t in self.trigger_tags if t in evt.spell.tags): return
		hp = 5
		self.do_ui_flash()
		for u in self.owner.level.units:
			if are_hostile(self.owner, u): continue
			if not Tags.Living in u.tags: continue
			u.heal(hp, self)

class MeltedArmor(Buff):

	def on_init(self):
		self.resists[Tags.Physical] = -10
		self.name = "Armor Melted"
		self.buff_type = BUFF_TYPE_CURSE
		self.stack_type = STACK_INTENSITY
		self.asset = ['status', 'melted_armor']
		self.color = Tags.Fire.color

class ArmorMelter(Equipment):

	def on_init(self):
		self.tags = [Tags.Fire, Tags.Metallic]
		self.recipe = [(Tags.Fire, 2), (Tags.Metallic, 1), (Tags.Any, 2)]
		self.name = "Armor Melter"
		self.global_triggers[EventOnDamaged] = self.on_damage
		self.duration = 3
		self.add_effect_tooltip(MeltedArmor)

	def get_description(self):
		return ("When enemies take [Fire] damage, they gain a stack of Melted Armor for [{duration}:duration] turns\n"
				"Melted Armor reduces [Physical] resistance by 10")

	def on_damage(self, evt):
		if Tags.Fire == evt.damage_type and self.owner.level.are_hostile(evt.unit, self.owner):
			evt.unit.apply_buff(MeltedArmor(), self.get_stat('duration'))
			self.do_ui_flash()


class MinionSpellGranter(Equipment):

	def __init__(self, name, spell, minion_tags, tags, recipe, dmg=0, range=0, duration=0, cool_down=0, wizard_spell=False):
		Equipment.__init__(self)
		self.name = name
		self.minion_tags = minion_tags
		self.tags = tags
		self.recipe = recipe
		self.spell_cls = spell
		self.wizard_spell = wizard_spell
		self.cd = cool_down
		if not wizard_spell:
			if dmg: self.minion_damage = dmg
			if range: self.minion_range = range
			if duration: self.duration = duration
		self.global_triggers[EventOnUnitAdded] = self.on_unit_add
		self.owner_triggers[EventOnUnitAdded] = self.grant_existing
		self.set_stats()

	def grant(self, unit):
		if unit.get_spell(self.spell_cls): return False
		spell = self.spell_cls()
		if self.wizard_spell: grant_minion_spell(self.spell_cls, unit, self.owner, cool_down=self.cd); return

		spell.damage = self.get_stat('minion_damage')

		if hasattr(self, 'minion_range'): spell.range = self.get_stat('minion_range')
		elif spell.melee: spell.range = 1.5

		if hasattr(self, 'duration'):
			if hasattr(spell, 'buff_duration'): spell.buff_duration = self.get_stat('duration')
			elif hasattr(spell, 'duration'): spell.duration = self.get_stat('duration')
		spell.cool_down = self.cd
		unit.add_spell(spell, prepend=True)
		self.do_ui_flash()

	def grant_existing(self, _evt):
		for u in self.owner.level.units:
			if are_hostile(self.owner, u): continue
			if not any(t in self.minion_tags for t in u.tags): continue
			if u.is_player_controlled: continue
			self.grant(u)

	def on_unit_add(self, evt):
		if are_friendly(evt.unit, self.owner) and any(t in self.minion_tags for t in evt.unit.tags) and not evt.unit.is_player_controlled:
			self.grant(evt.unit)

class HungerLifeLeechSpell(SimpleRangedAttack):

	def __init__(self):
		SimpleRangedAttack.__init__(self, name="Hunger", damage=7, damage_type=Tags.Dark, cool_down=3, range=3, drain=True)

class GraveHungerAmulet(MinionSpellGranter):

	def __init__(self):
		MinionSpellGranter.__init__(self,
									"Grave Hunger Amulet",
								   HungerLifeLeechSpell,
								   [Tags.Undead],
								   [Tags.Conjuration, Tags.Dark],
								   [(Tags.Conjuration, 1), (Tags.Dark, 1), (Tags.Any, 4)],
								   dmg = 7,
								   range = 3,
								   cool_down=3)

	def get_description(self):
		return ("[Undead] allies learn Hunger\n"
			  	"Hunger deals [{minion_damage}:minion_damage] [Dark] damage to a target and heals the caster for damage dealt\n"
				"Hunger has [{minion_range}:range] range and a [3 turn:cooldown] cooldown")


class VenomSpitSpell(SimpleRangedAttack):

	def __init__(self):
		SimpleRangedAttack.__init__(self, name="Venom Spit", damage=4, damage_type=Tags.Poison, buff=Poison, buff_duration=10, cool_down=3, range=3)


class VenomSpitterCasque(MinionSpellGranter):

	def __init__(self):
		MinionSpellGranter.__init__(self,
									"Venom Spitter Casque",
									VenomSpitSpell,
									[Tags.Living, Tags.Nature],
									[Tags.Nature],
									[(Tags.Nature, 2), (Tags.Any, 4)],
									dmg = 4,
									range = 3,
									duration = 10,
									cool_down = 3)

	def get_description(self):
		return ("[Living] and [Nature] allies learn Venom Spit\n"
				"Venom Spit deals [{minion_damage}:minion_damage] [Poison] damage and inflicts [Poison] for [{duration}:duration] turns\n"
				"Venom Spit has [{minion_range}:range] range and a [3 turn:cooldown] cooldown")

class LightningTetherSpell(PullAttack):

	def __init__(self):
		PullAttack.__init__(self, damage=8, damage_type=Tags.Lightning, range=4, pull_squares=1, color=Tags.Lightning.color)
		self.name = "Lightning Tether"
		self.duration = 1
		self.stats.append('duration')
		self.cool_down = 6

	def get_description(self):
		return "Pulls the target 1 tile toward the caster\nApplies stun for [{duration}:duration] turns"

	def on_hit(self, unit):
		unit.apply_buff(Stun(), self.get_stat('duration'))


class LightningTether(MinionSpellGranter):

	def __init__(self):
		MinionSpellGranter.__init__(self,
									"Lightning Tether",
									LightningTetherSpell,
									[Tags.Construct, Tags.Metallic],
									[Tags.Lightning, Tags.Metallic],
									[(Tags.Lightning, 1), (Tags.Metallic, 1), (Tags.Any, 4)],
									dmg = 8,
									range = 3,
									duration = 1,
									cool_down = 6)

	def get_description(self):
		return ("[Construct] and [Metallic] allies learn Lightning Tether\n"
				"Lightning Tether deals [{minion_damage}:minion_damage] [Lightning] damage, pulls the target 1 tile closer, and stuns for [{duration}:duration] turns\n"
				"Lightning Tether has [{minion_range}:range] range and a [6 turn:cooldown] cooldown")

class StolenFlameChoker(MinionSpellGranter):

	def __init__(self):
		MinionSpellGranter.__init__(self,
									"Stolen Flame Choker",
									FireBreath,
									[Tags.Demon],
									[Tags.Fire, Tags.Conjuration],
									[(Tags.Conjuration, 1), (Tags.Dragon, 1), (Tags.Fire, 1), (Tags.Any, 3)],
									dmg = 5,
									range = 3,
									cool_down = 3)

	def get_description(self):
		return ("[Demon] allies learn Fire Breath\n"
				"Fire Breath deals [{minion_damage}:minion_damage] [Fire] damage to units in a cone\n"
				"Fire Breath has [{minion_range}:range] range and a [3 turn:cooldown] cooldown")

class ExpurgateSpell(Spell):

	def on_init(self):
		self.name = "Expurgate"
		self.damage = 8
		self.damage_type = [Tags.Dark, Tags.Holy, Tags.Physical]
		self.range = 1.5
		self.melee = True

	def cast_instant(self, x, y):
		for dtype in self.get_stat('damage_type'):
			self.caster.level.deal_damage(x, y, self.get_stat('damage'), dtype, self)

class UnholyExpurgator(MinionSpellGranter):

	def __init__(self):
		MinionSpellGranter.__init__(self,
									"Unholy Expurgator",
									ExpurgateSpell,
									[Tags.Dark, Tags.Holy],
									[Tags.Dark, Tags.Holy],
									[(Tags.Dark, 2), (Tags.Holy, 2), (Tags.Any, 2)],
									dmg = 8,
									cool_down=3)

	def get_description(self):
		return ("[Dark] and [Holy] allies learn Expurgate\n"
				"Expurgate is a melee spell\n"
				"Expurgate deals [{minion_damage}:minion_damage] [Dark], [Holy], and [Physical] damage\n"
				"Expurgate has a [3 turn:cooldown] cooldown")

class ArcaneShield(Equipment):

	def on_init(self):
		self.name = "Arcane Shield"
		self.tags = [Tags.Arcane]
		self.recipe = [(Tags.Arcane, 1), (Tags.Any, 3)]
		self.description = "When you manually cast an [Arcane] spell, gain [1 SH:shields]"
		self.owner_triggers[EventOnSpellCast] = self.on_spell_cast

	def on_spell_cast(self, evt):
		if not evt.pay_costs: return
		if Tags.Arcane not in evt.spell.tags: return
		self.owner.add_shields(1)
		self.do_ui_flash()


class MagicMinionShield(Equipment):

	def on_init(self):
		self.name = "Magic Minion Shield"
		self.tags = [Tags.Arcane, Tags.Conjuration]
		self.recipe = [(Tags.Arcane, 1), (Tags.Conjuration, 1), (Tags.Any, 3)]
		self.description = ("[Arcane] allies gain [3 SH:shields] when summoned\n"
							"Other allies gain [1 SH:shields] instead")
		self.global_triggers[EventOnUnitAdded] = self.on_unit_add

	def on_unit_add(self, evt):
		if self.owner.level.are_hostile(evt.unit, self.owner): return
		if evt.unit.is_player_controlled: return
		if Tags.Arcane in evt.unit.tags: shields = 3
		else: shields = 1
		evt.unit.add_shields(shields)
		self.do_ui_flash()

class ChaosLinks(Equipment):

	def on_init(self):
		self.name = "Chaos Links"
		self.global_triggers[EventOnDeath] = self.on_death
		self.fire_triggered = False
		self.light_triggered = False
		self.phys_triggered = False

		self.damage = 13
		self.radius = 3

		self.tags = [Tags.Chaos, Tags.Fire, Tags.Lightning]
		self.recipe = [(Tags.Chaos, 1), (Tags.Fire, 1), (Tags.Lightning, 1), (Tags.Translocation, 1), (Tags.Any, 2)]

	def get_description(self):
		return "When an enemy dies to [Fire], [Physical], or [Lightning] damage, a random enemy in line of sight within [{radius}:radius] tiles takes [{damage}:damage] damage of that type"

	def on_death(self, evt):
		if not are_hostile(evt.unit, self.owner): return
		damage_event = evt.damage_event
		if damage_event and damage_event.damage_type in [Tags.Fire, Tags.Lightning, Tags.Physical]:
			self.owner.level.queue_spell(self.trigger(evt))
			self.do_ui_flash()

	def trigger(self, evt):
		candidates = [u for u in self.owner.level.get_units_in_ball(evt.unit, self.radius) if are_hostile(self.owner, u)]
		candidates = [u for u in candidates if self.owner.level.can_see(evt.unit.x, evt.unit.y, u.x, u.y)]

		if candidates:
			target = random.choice(candidates)
			for p in self.owner.level.get_points_in_line(evt.unit, target, find_clear=True)[1:-1]:
				self.owner.level.show_effect(p.x, p.y, evt.damage_event.damage_type)
			target.deal_damage(self.get_stat('damage'), evt.damage_event.damage_type, self)
		yield


class FaeThornStaff(Equipment):

	def on_init(self):
		self.name = "Fae Thorn Staff"
		self.slot = SLOT_WEAPON

		self.tags = [Tags.Arcane, Tags.Conjuration, Tags.Nature]
		self.recipe = [(Tags.Arcane, 1), (Tags.Conjuration, 1), (Tags.Nature, 2), (Tags.Any, 2)]
		self.trigger_tags = [Tags.Arcane, Tags.Nature]

		self.minion_health = 10
		self.minion_damage = 4
		self.minion_duration = 9
		self.num_summons = 3

		self.owner_triggers[EventOnSpellCast] = self.on_spell_cast

	def get_description(self):
		return "When you cast an [Arcane] or [Nature] spell, summon [{num_summons}:num_summons] temporary Fae Thorns near the target"

	def get_extra_examine_tooltips(self):
		return [make_minion(self, FaeThorn)]

	def on_spell_cast(self, evt):
		if any(t for t in self.trigger_tags if t in evt.spell.tags):
			self.owner.level.queue_spell(self.do_summons(evt))
			self.do_ui_flash()

	def do_summons(self, evt):
		for i in range(self.get_stat('num_summons')):
			thorn = make_minion(self, FaeThorn)
			self.summon(thorn, evt, radius=2, sort_dist=False)
		yield

class CrackleVoid(Equipment):

	def on_init(self):
		self.name = "Cracklevoid"
		self.tags = [Tags.Arcane, Tags.Lightning]
		self.recipe = [(Tags.Arcane, 1), (Tags.Lightning, 2), (Tags.Any, 5)]
		self.num_targets = 2
		self.radius = 3

		self.global_triggers[EventOnDamaged] = self.on_damage

	def get_description(self):
		return ("When an enemy takes [Arcane] damage, up to [{num_targets}:num_targets] enemies in line of sight within [{radius}:radius] tiles take that much [Lightning] damage")

	def on_damage(self, evt):
		if evt.damage <= 0: return
		if evt.damage_type != Tags.Arcane: return
		if not are_hostile(evt.unit, self.owner): return
		self.owner.level.queue_spell(self.send_bolts(evt.unit, evt.damage))

	def bolt(self, damage, source, target):
		if not target.is_alive(): return
		self.owner.level.show_beam(source, target, Tags.Lightning, minor=False)
		target.deal_damage(damage, Tags.Lightning, self)
		yield

	def send_bolts(self, source, damage):
		level = self.owner.level
		targets = level.get_units_in_ball(source, self.get_stat('radius'))
		targets = [t for t in targets if are_hostile(t, self.owner) and t != source and level.can_see_unit(source, t)]
		num_targets = min(self.get_stat('num_targets'), len(targets))
		if not num_targets: return
		self.do_ui_flash()
		for target in random.sample(targets, num_targets):
			for _ in self.bolt(damage, source, target):
				yield

class Crackledark(Equipment):

	def on_init(self):
		self.name = "Crackledarkener"
		self.num_targets = 2
		self.radius = 3
		self.global_triggers[EventOnDamaged] = self.on_damage
		self.tags = [Tags.Dark, Tags.Lightning]
		self.recipe = [(Tags.Dark, 1), (Tags.Lightning, 2), (Tags.Any, 5)]

	def get_description(self):
		return ("When an enemy takes [Dark] damage, up to [{num_targets}:num_targets] enemies in line of sight within [{radius}:radius] tiles take that much [Lightning] damage")

	def on_damage(self, evt):
		if evt.damage <= 0: return
		if evt.damage_type != Tags.Dark: return
		if not are_hostile(evt.unit, self.owner): return
		self.owner.level.queue_spell(self.send_bolts(evt.unit, evt.damage))

	def bolt(self, damage, source, target):
		if not target.is_alive(): return
		self.owner.level.show_beam(source, target, Tags.Lightning, minor=False)
		target.deal_damage(damage, Tags.Lightning, self)
		yield

	def send_bolts(self, source, damage):
		level = self.owner.level
		targets = level.get_units_in_ball(source, self.get_stat('radius'))
		targets = [t for t in targets if are_hostile(t, self.owner) and t != source and level.can_see_unit(source, t)]
		num_targets = min(self.get_stat('num_targets'), len(targets))
		if not num_targets: return
		self.do_ui_flash()
		for target in random.sample(targets, num_targets):
			for _ in self.bolt(damage, source, target): yield

class Hemocorruptor(Equipment):

	def on_init(self):
		self.name = "Hemocorruptor"
		self.tags = [Tags.Blood, Tags.Nature, Tags.Dark]
		self.recipe = [(Tags.Blood, 1), (Tags.Dark, 1), (Tags.Nature, 1), (Tags.Any, 3)]
		self.global_triggers[EventOnHealed] = self.on_heal
		self.num_targets = 3
		self.radius = 4

	def get_description(self):
		return ("When your allies heal, up to [{num_targets}:num_targets] enemies in line of sight within [{radius}:radius] tiles take that much [Poison] damage")

	def on_heal(self, evt):
		if evt.unit == self.owner: return
		if are_hostile(evt.unit, self.owner): return
		self.owner.level.queue_spell(self.send_bolts(evt.unit, -evt.heal))

	def bolt(self, damage, source, target):
		if not target.is_alive(): return
		self.owner.level.show_beam(source, target, Tags.Poison, minor=False)
		target.deal_damage(damage, Tags.Poison, self)
		yield

	def send_bolts(self, source, damage):
		level = self.owner.level
		targets = level.get_units_in_ball(source, self.get_stat('radius'))
		targets = [t for t in targets if are_hostile(t, self.owner) and t != source and level.can_see_unit(source, t)]
		num_targets = min(self.get_stat('num_targets'), len(targets))
		if not num_targets: return
		self.do_ui_flash()
		for target in random.sample(targets, num_targets):
			for _ in self.bolt(damage, source, target): yield

class StatusOnDamageEquipment(Equipment):

	def __init__(self, name, tags, recipe, damage_type, status, chance, duration, status_name):
		Equipment.__init__(self, name, tags, recipe, damage_type, status, chance, duration, status_name)
		self.name = name
		self.tags = tags
		self.recipe = recipe
		self.damage_type = damage_type
		self.status = status
		self.status_name = status_name
		self.chance = chance
		self.duration = duration
		self.global_triggers[EventOnDamaged] = self.on_damaged
		self.set_stats()

	def get_description(self):
		duration = self.get_stat('duration')
		turns_kw = 'turn' if duration == 1 else 'turns'
		return ("When an enemy takes {dtype} damage, it has a {chance}% chance to be afflicted with [{duration}:duration] {turns} of [{status}]",
				{'dtype':formatted_tag(self.damage_type), "chance":self.chance, "status":self.status_name, 'turns':turns_kw, "duration":duration})

	def on_damaged(self, evt):
		if evt.damage_type != self.damage_type: return
		if not are_hostile(evt.unit, self.owner): return
		if random.random() > (self.chance / 100): return
		evt.unit.apply_buff(self.status(), self.get_stat('duration'))
		self.do_ui_flash()


class IcyVengeanceIcon(Equipment):

	def on_init(self):
		self.name = "Icy Vengeance Icon"
		self.tags = [Tags.Conjuration, Tags.Dark, Tags.Ice]
		self.recipe = [(Tags.Conjuration, 1), (Tags.Dark, 1), (Tags.Ice, 2), (Tags.Any, 3)]
		self.global_triggers[EventOnDeath] = self.on_death
		self.radius = 5
		self.num_targets = 3

	def get_description(self):
		return ("When your allies die, up to [{num_targets}:num_targets] random enemies within [{radius}:radius] tiles take [Ice] damage equal to half the dead ally's max HP")

	def on_death(self, evt):
		if are_hostile(evt.unit, self.owner): return
		self.owner.level.queue_spell(self.do_damage(evt))
		self.do_ui_flash()

	def do_damage(self, evt):
		units = self.owner.level.get_units_in_ball(evt.unit, self.get_stat('radius'))
		units = [u for u in units if are_hostile(self.owner, u) and u.is_alive()]
		random.shuffle(units)

		show_beam = self.owner.level.show_beam
		for unit in units[:self.get_stat('num_targets')]:
			if not unit.is_alive(): continue
			show_beam(evt.unit, unit, Tags.Ice, minor=False)
			unit.deal_damage(evt.unit.max_hp // 2, Tags.Ice, self)
			yield

class IceSickle(Equipment):

	def on_init(self):
		self.name = "Ice Sickle"
		self.tags = [Tags.Arcane, Tags.Ice]
		self.recipe = [(Tags.Arcane, 1), (Tags.Ice, 1), (Tags.Translocation, 1), (Tags.Any, 3)]
		self.owner_triggers[EventOnSpellCast] = self.on_spell_cast

	def get_description(self):
		return "When you manually cast an [Arcane] spell targeting a [frozen] unit, make a copy of that spell targeting each other frozen enemy in line of sight\nRemove [frozen] from affected units"

	def on_spell_cast(self, evt):
		if not evt.pay_costs: return

		unit = self.owner.level.get_unit_at(evt.x, evt.y)
		if not unit: return
		if not unit.has_buff(FrozenBuff): return
		if Tags.Arcane not in evt.spell.tags: return

		copy_targets = [u for u in self.owner.level.get_units_in_los(unit) if are_hostile(self.owner, u) and u.has_buff(FrozenBuff) and u != unit]
		unit.remove_buffs(FrozenBuff)
		self.do_ui_flash()
		for u in copy_targets:
			if evt.spell.can_copy(u.x, u.y):
				self.owner.level.defer_cast(self.owner, evt.spell, u.x, u.y, pay_costs=False)
				b = u.get_buff(FrozenBuff)
				if b: u.remove_buff(b)


class ChillStaff(Equipment):

	def on_init(self):
		self.name = "Chill Staff"
		self.slot = SLOT_WEAPON
		self.owner_triggers[EventOnSpellCast] = self.on_cast
		self.duration = 3
		self.tags = [Tags.Ice]
		self.recipe = [(Tags.Ice, 1), (Tags.Translocation, 1), (Tags.Any, 3)]

	def get_description(self):
		return "When you cast an [Ice] spell, the nearest unfrozen enemy to that spell's target is [frozen] for [{duration}:duration] turns"

	def on_cast(self, evt):
		if Tags.Ice not in evt.spell.tags: return
		self.owner.level.queue_spell(self.do_freeze(evt))
		self.do_ui_flash()

	def do_freeze(self, evt):
		target_point = Point(evt.x, evt.y)
		targets = [u for u in self.owner.level.units if are_hostile(self.owner, u)]
		random.shuffle(targets)
		targets.sort(key=lambda u: self.owner.level.unit_distance(target_point, u))
		for u in targets:
			if u.has_buff(FrozenBuff): continue
			self.owner.level.show_path_effect(target_point, u, Tags.Ice, minor=True)
			u.apply_buff(FrozenBuff(), self.get_stat('duration'))
			break
		yield


class ShatterShardsNecklace(Equipment):

	def on_init(self):
		self.name = "Shatter Shards Necklace"
		self.tags = [Tags.Ice, Tags.Metallic]
		self.recipe = [(Tags.Ice, 2), (Tags.Metallic, 1), (Tags.Any, 4)]
		self.global_triggers[EventOnUnfrozen] = self.on_unfrozen
		self.radius = 3
		self.num_targets = 3
		self.damage = 6

	def get_description(self):
		return "When a unit is unfrozen or a [frozen] unit dies, up to [{num_targets}:num_targets] enemies within [{radius}:radius] tiles take [{damage}:damage] [Ice] and [Physical] damage"

	def on_unfrozen(self, evt):
		self.owner.level.queue_spell(self.do_shards(evt))
		self.do_ui_flash()

	def bolt(self, u, v):
		if not v.is_alive(): yield False

		for p in self.owner.level.get_points_in_line(u, v, find_clear=True):
			self.owner.level.show_effect(p.x, p.y, Tags.Ice)
			yield True

		damage = self.get_stat('damage')
		for dtype in [Tags.Ice, Tags.Physical]:
			v.deal_damage(damage, dtype, self)
			yield True

		yield False

	def do_shards(self, evt):
		owner = self.owner
		level = owner.level
		can_see = level.can_see
		origin = evt.unit
		nearby_units = [v for v in level.get_units_in_ball(origin, self.get_stat('radius')) if origin != v and v.is_alive() and are_hostile(owner, v) and can_see(v.x, v.y, origin.x, origin.y)]
		bolts = []
		random.shuffle(nearby_units)
		for v in nearby_units[:self.get_stat('num_targets')]: bolts.append(self.bolt(evt.unit, v))
		while any(bolts):
			bolts = [b for b in bolts if next(b)]
			yield

class AmuletOfCollectedAgony(Equipment):

	def on_init(self):
		self.name = "Amulet Of Collected Agony"
		self.global_triggers[EventOnDamaged] = self.on_damage
		self.charges = 0
		self.tags = [Tags.Dark, Tags.Nature]
		self.recipe = [(Tags.Dark, 1), (Tags.Nature, 1), (Tags.Any, 4)]
		self.description = ("Each turn, the nearest [{num_targets}:num_targets] enemies take [Dark] damage"
							"\nThe damage equals 2x the sum of all [Poison] damage dealt since the last activation")

		self.num_targets = 2

	def on_damage(self, evt):
		if evt.damage_type == Tags.Poison: self.charges += evt.damage

	def on_advance(self):
		if self.charges == 0: return
		options = self.owner.level.get_units_by_distance(self.owner, enemy=True)
		if not options: return
		self.do_ui_flash()
		num_to_hit = min(self.get_stat('num_targets'), len(options))
		for i in range(num_to_hit):
			target = options.pop(0)
			self.owner.level.queue_spell(self.do_damage(target, 2*self.charges))
		self.charges = 0

	def do_damage(self, target, damage):
		if not target.is_alive(): return
		self.owner.level.show_path_effect(target, target,Tags.Dark)
		target.deal_damage(damage, Tags.Dark, self)
		yield

class VoidSpikeStone(Equipment):

	def on_init(self):
		self.name = "Void Spike Stone"
		self.global_triggers[EventOnDamaged] = self.on_damage
		self.tags = [Tags.Arcane]
		self.recipe = [(Tags.Arcane, 1), (Tags.Dark, 1), (Tags.Any, 4)]
		self.damage = 5

	def get_description(self):
		return "When you or one of your [Arcane] or [Undead] allies take damage from an enemy, deal [{damage}:damage] [Arcane] damage to the enemy"

	def on_damage(self, evt):
		if are_hostile(self.owner, evt.unit): return
		if not evt.source: return
		if not evt.source.owner: return
		if not are_hostile(evt.source.owner, self.owner): return
		if not (evt.unit == self.owner or Tags.Arcane in evt.unit.tags or Tags.Undead in evt.unit.tags): return
		evt.source.owner.deal_damage(self.get_stat('damage'), Tags.Arcane, self)
		self.do_ui_flash()

class MiniIdolOfVampirism(Equipment):

	def on_init(self):
		self.name = "Mini Idol of Vampirism"
		self.asset_name = 'idol'
		self.tags = [Tags.Blood]
		self.recipe = [(Tags.Blood, 4)]
		self.global_triggers[EventOnDamaged] = self.on_damage

	def get_description(self):
		return "Heal for half of the damage you deal"

	def on_damage(self, evt):
		if evt.damage < 2: return
		if not evt.source: return
		if evt.source.owner != self.owner: return
		self.owner.heal(evt.damage // 2, self)
		self.do_ui_flash()

class MiniIdolOfAgony(Equipment):

	def on_init(self):
		self.name = "Mini Idol of Agony"
		self.asset_name = 'idol'
		self.tags = [Tags.Dark, Tags.Nature]
		self.recipe = [(Tags.Dark, 2), (Tags.Nature, 2)]
		self.global_triggers[EventOnDamaged] = self.on_damage

	def get_description(self):
		return "Redeal non-[Poison] damage you deal as [Poison] damage"

	def on_damage(self, evt):
		if evt.damage <= 0: return
		if evt.damage_type == Tags.Poison: return
		if not evt.source: return
		if evt.source.owner != self.owner: return
		if not evt.unit.is_alive(): return
		self.owner.level.queue_spell(self.redeal_damage(evt.unit, evt.damage))

	def redeal_damage(self, u, damage):
		if not u.is_alive(): return
		u.deal_damage(damage, Tags.Poison, self)
		self.do_ui_flash()
		yield

class MiniIdolOfInvincibility(Equipment):

	def on_init(self):
		self.name = "Mini Idol of Invincibility"
		self.asset_name = 'idol'
		self.tags = [Tags.Arcane]
		self.recipe = [(Tags.Arcane, 4)]

	def get_description(self):
		return "Each turn, gain [1 SH:shields]"

	def on_advance(self):
		self.owner.add_shields(1)
		self.do_ui_flash()

class MiniIdolOfRebirth(Equipment):

	def on_init(self):
		self.name = "Mini Idol of Rebirth"
		self.asset_name = 'idol'
		self.tags = [Tags.Holy]
		self.recipe = [(Tags.Holy, 4)]

	def get_description(self):
		return "Each turn, one of your allies gains the ability to reincarnate"

	def on_advance(self):
		owner = self.owner
		level = owner.level
		allies = [u for u in level.units if are_friendly(owner, u)
				  and not u == owner
				  and not u.is_player_controlled
				  and not u.has_buff(ReincarnationBuff)]
		if not allies: return None
		u = random.choice(allies)
		level.show_path_effect(owner, u, Tags.Holy)
		u.apply_buff(ReincarnationBuff())
		self.do_ui_flash()


MINI_IDOLS = [MiniIdolOfRebirth, MiniIdolOfAgony, MiniIdolOfVampirism, MiniIdolOfInvincibility]

class SpiderCarapaceForm(Buff):

	def on_init(self):
		self.name = "Spider Form"
		self.buff_type = BUFF_TYPE_NONE
		self.stack_type = STACK_TYPE_TRANSFORM
		self.transform_asset = ["char", "player_spider"]
		self.show_effect = False

class SpiderCarapaceRobe(Equipment):

	def on_init(self):
		self.name = "Spider Carapace Robe"
		self.slot = SLOT_ARMOR
		self.tags = [Tags.Nature, Tags.Translocation]
		self.recipe = [(Tags.Nature, 1), (Tags.Translocation, 1), (Tags.Any, 4)]
		self.owner_triggers[EventOnSpellCast] = self.on_cast
		self.num_targets = 3

	def on_equip(self, owner):
		if Tags.Spider not in owner.tags: owner.tags.append(Tags.Spider)
		if not owner.has_buff(SpiderCarapaceForm): owner.apply_buff(SpiderCarapaceForm())

	def on_unequip(self, owner):
		if any(isinstance(item, SpiderCarapaceRobe) for item in owner.equipment): return # don't remove tag or form if you have a copy granting them
		owner.remove_buffs(SpiderCarapaceForm)
		if Tags.Spider in owner.tags: owner.tags.remove(Tags.Spider)

	def get_description(self):
		return ("Gain the [Spider] tag\n"
				"Spawn [{num_targets}:num_targets] webs each turn on adjacent tiles\n"
				"Webs will no longer immobilize you\n"
				"When you cast a [Translocation] spell targeting a web, refund 1 charge of that spell and consume the web")

	def on_advance(self):
		if not any(are_hostile(self.owner, u) for u in self.owner.level.units): return
		o = self.owner
		lvl = o.level

		adj = lvl.get_points_in_ball(o.x, o.y, 1.5)
		candidates = [p for p in adj if lvl.tiles[p.x][p.y].can_see and not isinstance(lvl.tiles[p.x][p.y].cloud, SpiderWeb)]
		if not candidates: return
		num = min(len(candidates), self.get_stat('num_targets'))
		targets = random.sample(candidates, num)
		for t in targets:
			web = SpiderWeb()
			web.owner = o
			lvl.add_obj(web, t.x, t.y)

	def on_cast(self, evt):
		# refund a charge of the spell if there is a web at the target
		cloud = self.owner.level.tiles[evt.x][evt.y].cloud
		if not cloud or not isinstance(cloud, SpiderWeb): return
		# consume the web
		self.owner.level.remove_obj(cloud)
		if Tags.Translocation in evt.spell.tags:self.owner.level.queue_spell(self.refund_spell(evt.spell))

	def refund_spell(self, spell):
		for _ in range(6): yield
		spell.refund_charges(1)
		self.do_ui_flash()

class NecromancersLocket(Equipment):

	def on_init(self):
		self.name = "Necromancer's Locket"
		self.tags = [Tags.Dark]
		self.recipe = [(Tags.Dark, 4)]

		self.tag_bonuses_pct[Tags.Dark]['max_charges'] = 100
		self.resists[Tags.Dark] = 100
		self.resists[Tags.Holy] = -100

		self.description = ("Gain the [Undead] tag\n"
							"Learning a [Dark] spell refunds half its SP cost")

	def on_add_spell(self, spell):
		if Tags.Dark in spell.tags and getattr(spell, 'level', 0):
			self.owner.xp += (spell.level // 2)
			self.do_ui_flash()

	def on_equip(self, owner):
		if Tags.Undead not in owner.tags: owner.tags.append(Tags.Undead)

	def on_unequip(self, owner):
		if any(isinstance(item, NecromancersLocket) for item in owner.equipment): return # don't remove tag if you have a copy granting the tag
		if Tags.Undead in owner.tags: owner.tags.remove(Tags.Undead)

class Companion(Equipment):

	def __init__(self, unit_fn, tags, stats):
		Equipment.__init__(self, unit_fn, tags, stats)
		self.unit_fn = unit_fn
		self.unit_ex = unit_fn()
		self.name = self.unit_ex.name
		for stat, val in stats.items(): setattr(self, stat, val)
		self.tags = tags
		for t in tags: self.recipe.append((t, 3))
		self.description = (("A {name} will be your constant companion\n"
							"They will accompany you across the realms to do battle with your foes",
							{'name':self.unit_ex.name}))
		self.connected_targets = []
		self.owner_triggers[EventOnUnitAdded] = self.on_begin

	def on_begin(self, _):
		self.connected_targets = []
		u = self.summon(make_minion(self, self.unit_fn), radius=12)
		if u: self.connected_targets = [u]

	def get_extra_examine_tooltips(self):
		u = make_minion(self, self.unit_fn)
		u.source = self
		extras = [u]
		u_extras = u.get_extra_examine_tooltips()
		if u_extras: extras.extend(u_extras)
		return extras


class NecromancyBuff(Buff):

	def on_applied(self, owner): self.global_triggers[EventOnDeath] = self.on_death
	def on_death(self, death_event):
		if Tags.Living in death_event.unit.tags: self.owner.level.queue_spell(self.raise_skeleton(death_event.unit))
	def raise_skeleton(self, unit): raise_skeleton(self.owner, unit); yield
	def get_tooltip(self): return "When a [Living] unit dies, raises that unit as a skeleton"

def Necromancer():
	unit = Unit()
	unit.name = "Necromancer"
	unit.asset_name = 'companion_necromancer'
	unit.max_hp = 85
	unit.shields = 3

	life_drain = LifedrainSpell()
	life_drain.max_charges = 0
	life_drain.cool_down = 3
	life_drain.duration = 6
	life_drain.hp_cost = 1
	life_drain.range = 6

	dagger = SimpleMeleeAttack(damage=3, buff=NecrosisBuff, buff_duration=6, damage_type=[Tags.Physical, Tags.Dark], drain=True)
	dagger.name = "Cursed Blade"

	unit.resists[Tags.Dark] = 75
	unit.resists[Tags.Arcane] = 50
	unit.resists[Tags.Holy] = -50
	unit.tags = [Tags.Dark, Tags.Living]

	unit.spells = [life_drain, dagger]
	unit.buffs = [NecromancyBuff()]
	return unit

class SilveredBuff(Buff):

	def on_init(self):
		self.name = "Silvered"
		self.owner_triggers[EventOnSpellCast] = self.on_cast

	def on_cast(self, evt):
		u = self.owner.level.get_unit_at(evt.x, evt.y)
		if not u: return
		if not any(t in [Tags.Blood, Tags.Dark, Tags.Undead] for t in u.tags): return
		if are_friendly(u, self.owner): return
		u.deal_damage(50, Tags.Holy, self)

	def get_tooltip(self):
		return "[Silvered Weapons:holy]:\nCasting a spell targeting a [Blood], [Dark], or [Undead] enemy deals 50 [Holy] damage to the target"

def VampireHunter():
	u = Unit()
	u.name = "Vampire Hunter"
	u.tags = [Tags.Living, Tags.Dark]
	u.max_hp = 160
	shoot = SimpleRangedAttack(name="Silver Bolt", damage=40, range=9, cool_down=3, proj_name='silver_spear')

	sword = SimpleMeleeAttack(damage=40)
	sword.quick_cast = True
	sword.name = "Silver Blade"

	silvered_tags = [Tags.Blood, Tags.Dark, Tags.Undead]

	def make_silvered_can_harm(spell):
		def can_harm(target_unit):
			if Spell.can_harm(spell, target_unit): return True
			if target_unit.resists[Tags.Holy] >= 100: return False
			return any(t in silvered_tags for t in target_unit.tags)
		return can_harm

	shoot.can_harm = make_silvered_can_harm(shoot)
	sword.can_harm = make_silvered_can_harm(sword)

	u.resists[Tags.Physical] = 50
	u.resists[Tags.Dark] = 75

	u.spells = [shoot, sword]
	u.buffs = [QuickmoveBuff(), SilveredBuff()]
	return u

def Paladin():
	u = Unit()
	u.name = "Paladin"
	u.tags = [Tags.Holy, Tags.Living, Tags.Metallic]
	u.max_hp = 200
	u.shields = 2

	def shield_shove(caster, target): push(target, caster, 1)
	shield = SimpleMeleeAttack(damage=10, onhit=shield_shove, onhit_description="Target is pushed 1 tile away")
	shield.cool_down = 2
	shield.name = "Shield Bash"

	def stun_dark(caster, target):
		if Tags.Dark in target.tags: target.apply_buff(Stun(), 2)
	stun_dark_desc = "Stuns [Dark] units for 2 turns"
	maul = SimpleMeleeAttack(damage=18, damage_type=[Tags.Physical, Tags.Holy], onhit=stun_dark, onhit_description=stun_dark_desc)
	maul.name = "Blessed Maul"

	u.spells = [shield, maul]
	u.buffs = [ShieldRegenBuff(2, 2), HealAuraBuff(heal=3, radius=4, heal_self=True)]
	for b in u.buffs: b.color = Tags.Holy.color

	u.resists[Tags.Dark] = 50
	u.resists[Tags.Holy] = 75
	u.resists[Tags.Physical] = 75
	u.resists[Tags.Lightning] = -50
	return u

def DragonKnight():
	u = Unit()
	u.name = "Dragon Knight"
	u.asset_name = 'dragon_hunter'
	u.tags = [Tags.Living, Tags.Dragon, Tags.Metallic]
	u.max_hp = 180

	leap = LeapAttack(50, 5)
	leap.cool_down = 4
	melee = SimpleMeleeAttack(18, attacks=2)

	u.spells = [leap, melee]
	u.buffs = [AdaptiveArmorBuff(25), TeleportyBuff(radius=4, chance=.25)]
	return u

def Ranger():
	u = Unit()
	u.name = "Ranger"
	u.tags = [Tags.Living]
	u.max_hp = 60

	parrow = SimpleRangedAttack(name="Poison Arrow", damage=30, range=8, buff=Poison, buff_duration=10, proj_name='kobold_arrow_long')
	salvo = SimpleRangedAttack(name="Arrow Salvo", damage=30, range=5, attacks=5, cool_down=5, proj_name='kobold_arrow_long')
	bear = SimpleSummon(GiantBear, cool_down=25)
	u.spells = [salvo, bear, parrow]
	return u


class BerserkerRageBuff(Buff):

	def on_init(self):
		self.name = "Berserker Rage"
		self.description = "On taking damage, gain that much resistance to that damage type and +1 damage to all spells"
		self.color = COLOR_DAMAGE
		self.owner_triggers[EventOnDamaged] = self.on_damage

	def on_damage(self, evt):
		# do not resist heals or whatever
		if evt.damage <= 0: return
		self.resists[evt.damage_type] += evt.damage
		self.owner.resists[evt.damage_type] += evt.damage

		for s in self.owner.spells:
			if getattr(s, 'damage', None):
				s.damage += 1

class BerserkerEnrageBuff(Buff):

	def on_init(self):
		self.name = "Enrage"
		self.description = "When this unit falls below half health for the first time, it becomes [berserked] for 10 turns"
		self.color = Tags.Blood.color
		self.owner_triggers[EventOnDamaged] = self.on_damaged

	def on_damaged(self, evt):
		if self.owner.cur_hp > self.owner.max_hp // 2: return
		self.owner.apply_buff(BerserkBuff(), 10)
		self.owner.remove_buff(self)

class BerserkerAxeSwing(Spell):

	def on_init(self):
		self.name = "Frenzied Swings"
		self.description = "Deals [Physical] damage to enemies in an arc\nAttacks 2 times"
		self.range = 1.5
		self.melee = True
		self.can_target_self = False
		self.damage = 20
		self.damage_type = [Tags.Physical]

	def get_impacted_tiles(self, x, y):
		ball = self.caster.level.get_points_in_ball(x, y, 1, diag=True)
		aoe = [p for p in ball if 1 <= distance(p, self.caster, diag=True) < 2]
		return aoe

	def cast(self, x, y):
		dmg = self.get_stat('damage')
		for p in self.get_impacted_tiles(x, y):
			for _ in range(2):
				unit = self.caster.level.get_unit_at(p.x, p.y)
				if unit and not are_hostile(self.caster, unit): continue
				self.caster.level.deal_damage(p.x, p.y, dmg, Tags.Physical, self)
				yield

def Berserker():
	u = Unit()
	u.name = "Berserker"
	u.tags = [Tags.Living, Tags.Blood]
	u.max_hp = 500
	u.buffs = [BerserkerEnrageBuff(), BerserkerRageBuff()]
	u.spells = [BerserkerAxeSwing()]
	return u

class TeleportOnDamage(Buff):

	def on_init(self):
		self.name = "Evasion"
		self.description = "Teleports to a random nearby location and gains 1 [SH:shields] after taking damage"
		self.owner_triggers[EventOnDamaged] = self.on_damaged

	def on_damaged(self, evt):
		randomly_teleport(self.owner, 4)
		self.owner.add_shields(1)

class NullifyResistsBuff(Buff):

	def on_init(self):
		self.name = "Aether Exposure"
		self.description = "Removes damage resistances"
		self.buff_type = BUFF_TYPE_CURSE
		self.stack_type = STACK_INTENSITY
		self.color = Tags.Arcane.color

	def on_applied(self, owner):
		for dt in damage_tags:
			o_res = owner.resists.get(dt, 0)
			if o_res > 0: self.resists[dt] = -o_res

class AssassinStrike(Spell):

	def on_init(self):
		self.name = "Aether Dagger"
		self.damage = 40
		self.range = 4
		self.duration = 10
		self.cool_down = 4
		self.damage_type = [Tags.Arcane]

	def get_description(self):
		return "Ranged attack\nInflicts {duration} turns of Aether Exposure before dealing damage"

	def can_harm(self, target_unit):
		return True

	def get_ai_target(self):
		caster = self.caster
		lvl = caster.level

		r = self.get_stat('range')
		good_units = []
		for u in lvl.units: # look at units in the level
			if not lvl.are_hostile(u, caster): continue
			if abs(u.x - caster.x) > r + u.radius + caster.radius or abs(u.y - caster.y) > r + u.radius + caster.radius: continue
			good_units.append(u)

		if not good_units: return None
		random.shuffle(good_units)
		good_units.sort(key= lambda unit: unit.cur_hp * sum(unit.resists.values()), reverse=True) # better to strip the highest ehp unit we can

		for u in good_units:
			pts = list(u.iter_occupied_points()) if u.radius else [Point(u.x, u.y)]
			random.shuffle(pts)
			candidate = next((p for p in pts if self.can_cast(p.x, p.y)), None)
			if candidate: return candidate

		return None

	def cast(self, x, y):
		level = self.caster.level
		unit = level.get_unit_at(x, y)
		if not unit: return
		for point in level.get_points_in_line(self.caster, unit, inclusive=False):
			level.show_effect(point.x, point.y, Tags.AssassinBlade)
			yield

		if unit:
			unit.apply_buff(NullifyResistsBuff(), self.get_stat('duration'))
			self.caster.level.deal_damage(x, y, self.get_stat('damage'), Tags.Arcane, self)

		yield

def Assassin():
	u = Unit()
	u.name = "Assassin"

	u.tags = [Tags.Living, Tags.Arcane]
	u.max_hp = 85
	u.shields = 6

	dagger = AssassinStrike()

	phase = LeapAttack(damage=40, range=4, damage_type=Tags.Physical, is_ghost=True, buff =HemorrhageBuff, buff_duration=10)
	phase.name = "Ambush"

	add_tooltip(u, NullifyResistsBuff())
	add_tooltip(u, HemorrhageBuff())

	u.spells = [dagger, phase]
	u.buffs = [TeleportOnDamage()]

	return u

class WitheringAura(DamageAuraBuff):

	def __init__(self):
		DamageAuraBuff.__init__(self, damage=0, damage_type=Tags.Dark, radius=6)
		self.name = "Withering Aura"
		self.description = "Each turn, apply a stack of Corrosion to enemies in a 6 tile radius"

	def on_advance(self):
		level = self.owner.level
		seen = set()
		for p in level.get_points_in_ball(self.owner.x, self.owner.y, self.radius):
			unit = level.get_unit_at(p.x, p.y)
			if unit:
				if not are_hostile(self.owner, unit): continue
				if unit not in seen:
					unit.apply_buff(CorrosionDebuff()) # don't give multi-tile enemies 9x or 25x stacks per turn, that gets wild
					seen.add(unit)
			elif random.random() < .5: continue
			else: level.show_effect(p.x, p.y, Tags.Dark, minor=True)

	def get_tooltip(self):
		return self.description

class VoodooBinding(Spell):

	def on_init(self):
		self.name = "Voodoo Binding"
		self.cool_down = 8
		self.num_targets = 4
		self.range = 0
		self.can_target_self = True

	def get_description(self):
		return "Curse {num_targets} random enemies with [Shared Pain:blood]"

	def get_ai_target(self):
		targets = [u for u in self.caster.level.units if are_hostile(self.caster, u) and not u.has_buff(SharedPainBuff)]
		if targets and len(targets) > 1: return self.caster # no sense casting if there's nothing for it to share with
		else: return None

	def cast_instant(self, x, y):
		targets = [u for u in self.caster.level.units if are_hostile(self.caster, u) and not u.has_buff(SharedPainBuff)]
		if not targets: return
		targets = targets[:self.get_stat('num_targets')]
		for u in targets:
			self.caster.level.show_path_effect(self.caster, u, Tags.Blood, minor=True)
			u.apply_buff(SharedPainBuff())

class VoodooBlessing(Spell):

	def on_init(self):
		self.name = "Voodoo Blessing"
		self.cool_down = 8
		self.range = 0
		self.can_target_self = True

	def get_description(self):
		return "Caster and allies gain a stack of Regeneration, healing 1 HP per turn"

	def get_ai_target(self):
		return self.caster

	def cast_instant(self, x, y):
		targets = [u for u in self.caster.level.units if not are_hostile(self.caster, u)]
		if not targets: return
		for u in targets:
			self.caster.level.show_beam(self.caster, u, Tags.Heal, minor=True)
			u.apply_buff(RegenBuff(1))

def WitchDoctor():
	u = Unit()
	u.name = "Witch Doctor"
	u.tags = [Tags.Enchantment, Tags.Living]
	u.max_hp = 55

	def do_hex(caster, target): target.apply_buff(random.choice([NecrosisBuff, BleedBuff, Poison])(), 10)
	u.spells = [VoodooBinding(), VoodooBlessing(), SimpleRangedAttack(name="Hex Bolt", damage=9, damage_type=Tags.Dark, range=6, onhit=do_hex, onhit_description="Afflicts the target with Necrosis, Poison, or Bleed for 10 turns")]

	u.buffs = [WitheringAura()]
	add_tooltip(u, SharedPainBuff())
	add_tooltip(u, RegenBuff(1))
	add_tooltip(u, CorrosionDebuff())

	return u


class HolyAuraBuff(Buff):

	def on_init(self):
		self.name = "Holy Aura"
		self.color = Tags.Holy.color
		self.damage = 3
		self.radius = 6

	def get_description(self):
		return "Each turn, deal 3 [Holy] damage to enemies in a 6 tile radius\nAllies are healed instead"

	def on_advance(self):
		level = self.owner.level
		for p in level.get_points_in_ball(self.owner.x, self.owner.y, self.radius):
			unit = level.get_unit_at(p.x, p.y)
			if unit:
				if are_hostile(self.owner, unit): level.deal_damage(p.x, p.y, self.damage, Tags.Holy, self)
				else: unit.heal(self.damage, self)
			elif random.random() < .5: continue
			else: level.show_effect(p.x, p.y, Tags.Holy, minor=True)

	def can_threaten(self, x, y):
		return distance(self.owner, Point(x, y)) <= self.radius


def Cleric():
	u = Unit()
	u.name = "Cleric"
	u.tags = [Tags.Holy, Tags.Living]
	u.max_hp = 50

	light = HealingLight()
	light.max_charges = 0
	light.cool_down = 8
	light.heal = 100
	light.shields = 3
	light.remove_debuffs = 1
	light.tt_color = Tags.Holy.color
	light.get_description = lambda : "Allies in line of sight lose all debuffs, gain 3 [SH:shields] and are healed for [100 HP:heal]"

	smite = SimpleRangedAttack(name="Smite", damage=10, damage_type=Tags.Holy, range=6, buff=Stun, buff_duration=1, proj_name='holy_ball' )

	u.spells = [light, smite]
	u.buffs = [HolyAuraBuff()]

	return u

def AutoCannon():
	u = Unit()
	u.name = "Auto Cannon"
	u.stationary = True
	u.max_hp = 30
	u.tags = [Tags.Arcane, Tags.Construct, Tags.Metallic]
	u.spells = [SimpleRangedAttack(name="Shoot", damage=3, range=12)]
	return u

class OverclockSpell(Spell):

	def on_init(self):
		self.name = "Command Overclock"
		self.range = 0
		self.description = "Allied Constructs take 3 turns in a row"
		self.cool_down = 6
		self.tt_color = Tags.Lightning.color

	def get_ai_target(self):
		constructs = [u for u in self.caster.level.units if Tags.Construct in u.tags and are_friendly(self.caster, u) and u != self.caster]
		if constructs: return self.caster
		return None

	def cast(self, x, y):
		cannons = [u for u in self.caster.level.units if Tags.Construct in u.tags and are_friendly(self.caster, u) and u != self.caster]
		if not cannons: return
		random.shuffle(cannons)
		for c in cannons:
			self.caster.level.show_beam(self.caster, c, Tags.Lightning, minor=True)
			for _ in range(3):
				for _ in self.caster.level.take_turn(c):
					yield


def Engineer():
	u = Unit()
	u.name = "Engineer"
	u.tags = [Tags.Living]
	u.max_hp = 60
	u.resists[Tags.Fire] = 50

	flamethrower = FireBreath()
	flamethrower.name = "Flamethrower"
	flamethrower.cool_down = 0
	flamethrower.damage = 3
	flamethrower.range = 5
	flamethrower.description = "Deal fire damage in a cone"

	cannon = SimpleSummon(AutoCannon, num_summons=3, cool_down=6, duration=18)
	cannon.name = "Deploy Auto Cannons"
	cannon.range = 0
	cannon.tt_color = Tags.Metallic.color

	u.spells = [cannon, OverclockSpell(), flamethrower]
	return u

class HarmonySpell(Spell):

	def on_init(self):
		self.name = "Harmony"
		self.range = 0
		self.radius = 5
		self.duration = 3
		self.cool_down = 3

	def get_description(self):
		return ("Allies within {radius} tiles heal 10 HP each turn for the next {duration} turns\n"
				"Enemies within {radius} tiles are put to [sleep] for {duration} turns")

	def cast(self, x, y):
		allies = set()
		enemies = set()
		caster = self.caster
		show_beam = caster.level.show_beam
		duration = self.get_stat('duration')
		for u in caster.level.get_units_in_ball(caster, self.get_stat('radius')):
			if u is caster: continue
			if are_hostile(caster, u): enemies.add(u)
			else: allies.add(u)
		all_targets = allies | enemies
		for u in all_targets:
			show_beam(caster, u, Tags.Music) # or show_path_effect is better? try visually both
			if u in allies: u.apply_buff(RegenBuff(10), duration)
			else: u.apply_buff(SleepBuff(), duration)
			yield

	def get_ai_target(self):
		for p in self.get_impacted_tiles(self.caster.x, self.caster.y):
			u = self.caster.level.get_unit_at(p.x, p.y)
			if u and u is not self.caster:
				return self.caster
		return None

	def get_impacted_tiles(self, x, y):
		for stage in Burst(self.caster.level, Point(x, y), self.get_stat('radius'), ignore_walls=True):
			for p in stage:
				yield p


class DiscordSpell(Spell):

	def on_init(self):
		self.name = "Discord"
		self.range = 0
		self.radius = 5
		self.duration = 3
		self.cool_down = 3

	def get_description(self):
		return ("Allies within {radius} tiles gain Quickcast and Quickstep for the next {duration} turns\n"
				"Enemies within {radius} tiles are [berserked] for {duration} turns")

	def cast(self, x, y):
		allies = set()
		enemies = set()
		caster = self.caster
		show_beam = caster.level.show_beam
		duration = self.get_stat('duration')
		for u in caster.level.get_units_in_ball(caster, self.get_stat('radius')):
			if u is caster: continue
			if are_hostile(caster, u): enemies.add(u)
			else: allies.add(u)
		all_targets = allies | enemies
		for u in all_targets:
			show_beam(caster, u, Tags.Music) # or show_path_effect is better? try visually both
			if u in allies: u.apply_buff(QuickcastingBuff(), duration); u.apply_buff(QuickmoveBuff(), duration)
			else: u.apply_buff(BerserkBuff(), duration)
			yield

	def get_ai_target(self):
		for p in self.get_impacted_tiles(self.caster.x, self.caster.y):
			u = self.caster.level.get_unit_at(p.x, p.y)
			if u and u is not self.caster:
				return self.caster
		return None

	def get_impacted_tiles(self, x, y):
		for stage in Burst(self.caster.level, Point(x, y), self.get_stat('radius'), ignore_walls=True):
			for p in stage:
				yield p

class EncoreBuff(Buff):

	def on_init(self):
		self.name = "Encore"
		self.description = "Casting a spell has a chance to trigger an encore, granting the Bard 1 Reincarnation\nThe chance is equal to the number of allies in line of sight"
		self.owner_triggers[EventOnSpellCast] = self.on_cast

	def on_cast(self, evt):
		owner = self.owner
		b = owner.get_buff(ReincarnationBuff)
		if b: existing = True
		else: b = ReincarnationBuff(lives=1); existing = False
		chance = 0.0
		for u in owner.level.get_units_in_los(owner):
			if u is not owner and not are_hostile(owner, u):
				chance += .01
		if chance < random.random(): return
		if existing: b.lives += 1
		else: owner.apply_buff(b)

def Bard():
	u = Unit()
	u.name = "Bard"
	u.tags = [Tags.Living]
	u.max_hp = 75
	u.shields = 1

	u.spells = [HarmonySpell(), DiscordSpell(), SimpleMeleeAttack(10)]
	u.buffs = [EncoreBuff()]

	add_tooltip(u, RegenBuff(10))

	return u

class UnidentifiedConcoction(Spell):

	def on_init(self):
		self.name = "Unidentified Concoction"
		self.range = 5
		self.damage = 25
		self.duration = 3
		self.can_target_empty = False
		self.debuffs = [Poison, FearBuff, NecrosisBuff, BlindBuff, BleedBuff, Stun]
		self.tt_color = Tags.Chaos.color

	def get_description(self):
		return "Deals damage of a random type, inflicts a random debuff for {duration} turns"

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		target = Point(x, y)

		damage = self.get_stat('damage')
		duration = self.get_stat('duration')
		deal_damage = level.deal_damage
		getu = level.get_unit_at

		dtype = random.choice(damage_tags)
		debuff = random.choice(self.debuffs)

		for p in Bolt(level, caster, target):
			level.projectile_effect(p.x, p.y, proj_name='alchemists_jar', proj_origin=caster, proj_dest=target, proj_duration=4)
			yield

		deal_damage(x, y, damage, dtype, self)
		u = getu(x, y)
		if u and u.is_alive(): u.apply_buff(debuff(), duration)
		yield


class RestorativeConcoction(Spell):

	def on_init(self):
		self.name = "Restorative Concoction"
		self.range = 5
		self.heal = 25
		self.cool_down = 3
		self.can_target_self = True
		self.can_target_empty = False
		self.target_allies = True
		self.tt_color = Tags.Nature.color

	def get_description(self):
		return "Remove a debuff from the target and heal them for [{heal} HP:heal]"

	def can_cast(self, x, y):
		if not Spell.can_cast(self, x, y): return False
		unit = self.caster.level.get_unit_at(x, y)
		if unit and unit.team != self.caster.team: return False
		return True

	def get_ai_target(self):
		caster = self.caster
		level = caster.level
		r = self.get_stat('range')
		targets = []

		for u in level.units:
			if u.team != caster.team: continue
			if u.cur_hp >= u.max_hp and not any(b.buff_type == BUFF_TYPE_CURSE for b in u.buffs): continue
			if abs(u.x - caster.x) > r + u.radius + caster.radius or abs(u.y - caster.y) > r + u.radius + caster.radius: continue

			pts = list(u.iter_occupied_points()) if u.radius else [Point(u.x, u.y)]
			level.random.shuffle(pts)
			target = next((p for p in pts if self.can_cast(p.x, p.y)), None)
			if target: targets.append(target)

		level.random.shuffle(targets)
		return targets[0] if targets else None

	def cast(self, x, y):
		caster = self.caster
		level = caster.level
		target = Point(x, y)

		heal = self.get_stat('heal')

		for p in Bolt(level, caster, target):
			level.projectile_effect(p.x, p.y, proj_name='alchemists_jar', proj_origin=caster, proj_dest=target, proj_duration=4)
			yield

		u = level.get_unit_at(x, y)
		if u and u.is_alive() and u.team == caster.team:
			debuffs = [b for b in list(u.buffs) if b.buff_type == BUFF_TYPE_CURSE]
			if debuffs: u.remove_buff(random.choice(debuffs))
			u.heal(heal, self)
		yield

class AlchemistMulticastBuff(Buff):

	def on_init(self):
		self.name = "Brewed Concoctions"
		self.color = Tags.Arcane.color
		self.stack_type = STACK_INTENSITY
		self.owner_triggers[EventOnSpellCast] = self.on_spell_cast
		self.buff_type = BUFF_TYPE_BLESS

	def get_description(self):
		return "When the Alchemist casts Restorative Concoction or Unidentified Concoction, they cast it an additional time for free"

	def on_spell_cast(self, evt):
		if not evt.pay_costs: return
		alchemist_spells = [s for s in self.owner.spells if type(s) in (RestorativeConcoction, UnidentifiedConcoction)]
		if evt.spell not in alchemist_spells: return
		evt.caster.level.queue_spell(self.copy_spell(evt))

	def copy_spell(self, evt):
		target = evt.spell.get_ai_target()
		if not target: return
		if not evt.spell.can_cast(target.x, target.y): return
		for _ in evt.caster.level.act_cast(evt.caster, evt.spell, target.x, target.y, pay_costs=False, queue=False): yield
		yield

class BrewConcoctions(Spell):

	def on_init(self):
		self.name = "Brew Concoctions"
		self.range = 0
		self.max_channel = 3
		self.cool_down = 6
		self.tt_color = Tags.Arcane.color

	def get_description(self):
		return ("Channel for {max_channel} turns, then gain a stack of Brewed Concoctions")

	def get_ai_target(self):
		return self.caster

	def cast(self, x, y, channel_cast=False):
		if not channel_cast:
			self.caster.apply_buff(ChannelBuff(self.cast, Point(x, y), cast_after_channel=True), self.get_stat('max_channel'))
			yield
			return

		self.caster.apply_buff(AlchemistMulticastBuff())
		yield

def Alchemist():
	u = Unit()
	u.max_hp = 99
	u.name = "Alchemist"
	u.tags = [Tags.Living]
	u.spells = [RestorativeConcoction(), UnidentifiedConcoction(), BrewConcoctions()]
	add_tooltip(u, AlchemistMulticastBuff())
	return u

class SpearCharge(LeapAttack):

	def __init__(self):
		LeapAttack.__init__(self, damage=20, range=3, damage_type=Tags.Physical, is_leap=False, buff=ImmobilizeBuff, buff_duration=2)
		self.name = "Spear Charge"
		self.damage_type = [Tags.Physical, Tags.Holy]
		self.tt_color = Tags.Holy.color

	def get_description(self):
		return "Charge attack\nInflict immobilized for {duration} turns"

	def fmt_dict(self):
		d = Spell.fmt_dict(self)
		d['damage'] = self.get_stat('damage')
		d['duration'] = self.get_stat('buff_duration')
		return d

	def cast(self, x, y):
		leap_dest = self.get_leap_dest(x, y)
		if not leap_dest: return

		caster = self.caster
		level = caster.level
		requires_los = self.get_stat('requires_los')
		unit = level.get_unit_at(x, y)

		if leap_dest.x != caster.x or leap_dest.y != caster.y:
			path = level.get_points_in_line(caster, leap_dest, find_clear=requires_los)
			for point in path: level.leap_effect(point.x, point.y, Tags.Holy.color, caster)
			level.act_move(caster, leap_dest.x, leap_dest.y, teleport=True)

		damage = self.get_stat('damage')
		level.deal_damage(x, y, damage, Tags.Physical, self)
		level.deal_damage(x, y, damage, Tags.Holy, self)
		if unit and unit.is_alive(): unit.apply_buff(self.buff(), self.get_stat('buff_duration'))
		yield

class RestoreTouch(Spell):

	def on_init(self):
		self.name = "Restore"
		self.range = 1.5
		self.melee = True
		self.cool_down = 5
		self.can_target_empty = False
		self.target_allies = True
		self.tt_color = Tags.Holy.color

	def get_description(self):
		return "Remove all debuffs from an ally and restore them to full health"

	def can_cast(self, x, y):
		if not Spell.can_cast(self, x, y): return False
		u = self.caster.level.get_unit_at(x, y)
		return u and u != self.caster and u.team == self.caster.team

	def needs_healing(self, unit):
		if unit.cur_hp < unit.max_hp: return True
		return any(b.buff_type == BUFF_TYPE_CURSE for b in unit.buffs)

	def get_ai_target(self):
		level = self.caster.level
		candidates = []
		for u in level.units:
			if u == self.caster: continue
			if u.team != self.caster.team: continue
			if not self.needs_healing(u): continue

			pts = list(u.iter_occupied_points()) if u.radius else [Point(u.x, u.y)]
			level.random.shuffle(pts)
			target = next((p for p in pts if self.can_cast(p.x, p.y)), None)
			if target: candidates.append((u.cur_hp / u.max_hp, target))

		level.random.shuffle(candidates)
		candidates.sort(key=lambda c: c[0])
		return candidates[0][1] if candidates else None

	def cast(self, x, y):
		u = self.caster.level.get_unit_at(x, y)
		if u and u.is_alive() and u != self.caster and u.team == self.caster.team:
			for b in list(u.buffs):
				if b.buff_type == BUFF_TYPE_CURSE: u.remove_buff(b)
			u.heal(u.max_hp, self)
		yield

class ValkyrieOath(Buff):

	def on_init(self):
		self.name = "Valkyrie's Oath"
		self.color = Tags.Holy.color
		self.global_triggers[EventOnDeath] = self.on_death
		self.buff_type = BUFF_TYPE_PASSIVE

	def get_description(self):
		return "When a [Living] ally dies, teleport to their location and take an extra turn"

	def on_death(self, evt):
		if not self.owner.is_alive(): return
		if evt.unit == self.owner: return
		if Tags.Living not in evt.unit.tags: return
		if evt.unit.team != self.owner.team: return
		self.owner.level.queue_spell(self.do_oath_turn(Point(evt.unit.x, evt.unit.y)))

	def do_oath_turn(self, target):
		if not self.owner.is_alive(): return
		level = self.owner.level
		p = level.get_summon_point(target.x, target.y, radius_limit=3, unit=self.owner)
		if not p: return

		path = level.get_points_in_line(self.owner, p)
		for point in path: level.leap_effect(point.x, point.y, Tags.Holy.color, self.owner)
		level.act_move(self.owner, p.x, p.y, teleport=True)
		yield

		for _ in level.take_turn(self.owner): yield

def Valkyrie():
	u = Unit()
	u.max_hp = 180
	u.shields = 2
	u.name = "Valkyrie"
	u.tags = [Tags.Living, Tags.Holy]
	u.flying = True
	u.spells = [RestoreTouch(), SpearCharge()]
	u.buffs = [ValkyrieOath()]
	return u

all_companions = [
	lambda: Companion(Necromancer, [Tags.Dark, Tags.Conjuration], {'minion_health':85, 'shields':3, 'minion_damage':3, 'minion_range':6}),
	lambda: Companion(VampireHunter, [Tags.Dark, Tags.Conjuration], {'minion_health':160, 'minion_damage':40, 'minion_range':9}),
	lambda: Companion(Paladin, [Tags.Holy, Tags.Conjuration], {'minion_health':200, 'shields':2, 'minion_damage':18}),
	lambda: Companion(DragonKnight, [Tags.Dragon, Tags.Conjuration], {'minion_health':180, 'minion_damage':18, 'minion_range':5}),
	lambda: Companion(Ranger, [Tags.Nature, Tags.Conjuration], {'minion_health':60, 'minion_damage':30, 'minion_range':8}),
	lambda: Companion(Berserker, [Tags.Blood, Tags.Conjuration], {'minion_health':500, 'minion_damage':20}),
	lambda: Companion(Assassin, [Tags.Arcane, Tags.Conjuration], {'minion_health':80, 'shields':6, 'minion_damage':40, 'minion_range':4}),
	lambda: Companion(WitchDoctor, [Tags.Enchantment, Tags.Conjuration], {'minion_health':55, 'minion_damage':9, 'minion_range':6}),
	lambda: Companion(Cleric, [Tags.Holy, Tags.Conjuration], {'minion_health':50, 'minion_damage':10, 'minion_range':6}),
	lambda: Companion(Engineer, [Tags.Metallic, Tags.Conjuration], {'minion_health':60, 'minion_damage':3, 'minion_range':5}),
	lambda: Companion(Bard, [Tags.Enchantment, Tags.Conjuration], {'minion_health':75, 'shields':1, 'minion_damage':10}),
	lambda: Companion(Alchemist, [Tags.Arcane, Tags.Conjuration], {'minion_health':99, 'minion_damage':25, 'minion_range':5}),
	lambda: Companion(Valkyrie, [Tags.Holy, Tags.Conjuration], {'minion_health':180, 'shields':2, 'minion_damage':20, 'minion_range':3})
]

class Acidifier(Equipment):

	def on_init(self):
		self.name = "Acidifier"
		self.tags = [Tags.Dark, Tags.Nature]
		self.recipe = [(Tags.Dark, 1), (Tags.Enchantment, 1), (Tags.Nature, 1), (Tags.Any, 1)]
		self.description = "Each turn, a random enemy is acidified\nAcidified units lose 100 [Poison] resist"
		self.add_effect_tooltip(Acidified)

	def on_advance(self):
		candidates = [u for u in self.owner.level.units if are_hostile(u, self.owner) and not u.has_buff(Acidified)]
		good_candidates = [u for u in candidates if not getattr(u, 'turns_to_death', None)]
		candidates = good_candidates if good_candidates else candidates
		if candidates:
			random.choice(candidates).apply_buff(Acidified())
			self.do_ui_flash()


class Starcharge(Buff):

	def __init__(self, spell):
		Buff.__init__(self)
		self.spell = spell

	def on_init(self):
		self.name = "Starcharged"
		self.color = Tags.Arcane.color
		self.buff_type = BUFF_TYPE_BLESS
		self.stack_type = STACK_INTENSITY

	def get_description(self):
		return "Each turn, deal [{damage}:damage] [Arcane] damage to one random enemy in line of sight, and then [{damage}:damage] [Fire] damage to another", {'damage': self.spell.get_stat('damage')}

	def on_advance(self):
		available_targets = [u for u in self.owner.level.get_units_in_los(self.owner) if are_hostile(self.owner, u)]
		dtypes = [Tags.Arcane, Tags.Fire]
		random.shuffle(available_targets)
		damage = self.spell.get_stat('damage')
		for dtype in dtypes:
			# Dont waste hits on enemies that are immune to them
			cur_avail_targets = [t for t in available_targets if t.resists[dtype] < 100]
			if not cur_avail_targets: continue
			target = cur_avail_targets.pop()
			target.deal_damage(damage, dtype, self.spell)
			self.owner.level.show_path_effect(self.owner, target, dtype, minor=True, straight=True)
			available_targets.remove(target)


class VoidflameLantern(Equipment):

	def on_init(self):
		self.name = "Voidflame Lantern"
		self.tags = [Tags.Arcane, Tags.Eye, Tags.Fire]
		self.recipe = [(Tags.Arcane, 1), (Tags.Eye, 1), (Tags.Fire, 1), (Tags.Any, 1)]
		self.owner_triggers[EventOnSpellCast] = self.on_spell_cast
		self.damage = 6
		self.add_effect_tooltip(lambda: Starcharge(self))

	def get_description(self):
		return ("When you cast a [Fire] or [Arcane] spell, gain Starcharged with duration equal to the spell's level\n"
				"Starcharged deals [{damage}:damage] [Arcane] damage to one random enemy in line of sight each turn, and then [{damage}:damage] [Fire] damage to another")

	def on_spell_cast(self, evt):
		if Tags.Fire in evt.spell.tags or Tags.Arcane in evt.spell.tags:
			self.owner.apply_buff(Starcharge(self), evt.spell.level)
			self.do_ui_flash()

class TwilightSentinel(Buff):

	def __init__(self, spell):
		Buff.__init__(self)
		self.spell = spell

	def on_init(self):
		self.name = "Twilight Sentinel"
		self.color = Tags.Dark.color
		self.buff_type = BUFF_TYPE_BLESS
		self.stack_type = STACK_INTENSITY

	def get_description(self):
		return "Each turn, deal [{damage}:damage] [Dark] damage to one random enemy in line of sight, and then [{damage}:damage] [Holy] damage to another", {'damage': self.spell.get_stat('damage')}

	def on_advance(self):
		available_targets = [u for u in self.owner.level.get_units_in_los(self.owner) if are_hostile(self.owner, u)]
		dtypes = [Tags.Dark, Tags.Holy]
		damage = self.spell.get_stat('damage')
		random.shuffle(available_targets)
		for dtype in dtypes:
			cur_avail_targets = [t for t in available_targets if t.resists[dtype] < 100]
			if not cur_avail_targets: continue
			target = cur_avail_targets.pop()
			target.deal_damage(damage, dtype, self.spell)
			self.owner.level.show_path_effect(self.owner, target, dtype, minor=True, straight=True)
			available_targets.remove(target)

class TwilightLantern(Equipment):

	def on_init(self):
		self.name = "Twilight Lantern"
		self.tags = [Tags.Dark, Tags.Eye, Tags.Holy]
		self.recipe = [(Tags.Dark, 1), (Tags.Eye, 1), (Tags.Holy, 1), (Tags.Any, 1)]
		self.owner_triggers[EventOnSpellCast] = self.on_spell_cast
		self.damage = 6
		self.add_effect_tooltip(lambda: TwilightSentinel(self))

	def get_description(self):
		return ("When you cast a [Dark] or [Holy] spell, gain Twilight Sentinel with duration equal to the spell's level\n"
				"Twilight Sentinel deals [{damage}:damage] [Dark] damage to one random enemy in line of sight each turn, and then [{damage}:damage] [Holy] damage to another")

	def on_spell_cast(self, evt):
		if Tags.Dark in evt.spell.tags or Tags.Holy in evt.spell.tags:
			self.owner.apply_buff(TwilightSentinel(self), evt.spell.level)
			self.do_ui_flash()

class Echomancy(Buff):

	def __init__(self, spell):
		self.spell = spell
		Buff.__init__(self)

	def on_init(self):
		self.name = "Echomancy"
		self.color = Tags.Arcane.color

	def get_description(self):
		return ("Refunds next charge used to cast {spell}", {'spell':self.spell.name})

class EchoStaff(Equipment):

	def on_init(self):
		self.name = "Echo Staff"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Sorcery]
		self.recipe = [(Tags.Arcane, 1), (Tags.Sorcery, 1), (Tags.Any, 3)]
		self.prev_spell = None
		self.idle_counter = 0
		self.refund_counter = 0

		self.owner_triggers[EventOnSpellCast] = self.on_spell_cast

	def get_description(self):
		return ("When you manually cast the same [Sorcery] spell twice in a row, gain a charge of that spell")

	def on_advance(self):
		if self.idle_counter:
			self.idle_counter -= 1
			if self.idle_counter == 0:
				self.prev_spell = None
				self.refund_counter = 0

	def on_spell_cast(self, evt):
		if Tags.Sorcery not in evt.spell.tags: return
		if not evt.pay_costs: return 		# Ignore freecasts
		existing = self.owner.get_buff(Echomancy)
		if existing and existing.spell == evt.spell: # If existing echomancy buff for this spell, gain charge
			evt.spell.refund_charges(1)
			evt.spell.do_ui_flash()
			self.owner.remove_buff(existing)
			self.do_ui_flash()
		else:
			self.owner.remove_buffs(Echomancy)
			self.owner.apply_buff(Echomancy(evt.spell), 2)

class Disintegrator(Equipment):

	def on_init(self):
		self.name = "Disintegrator"
		self.tags = [Tags.Sorcery]
		self.recipe = [(Tags.Sorcery, 2), (Tags.Any, 6)]
		self.global_triggers[EventOnDamaged] = self.on_damage

		self.threshold = 40
		self.charges = 0

	def get_description(self):
		return (("For every 40 damage dealt by [Sorcery] spells, deal 1 [Physical] damage to all enemies\n"
				"Damage Dealt: {val}", {'val':self.charges}))

	def on_damage(self, evt):
		if not evt.source: return
		if evt.source == self: return # quick out from own damage
		if not isinstance(evt.source, Spell): return
		if Tags.Sorcery not in evt.source.tags: return
		if evt.damage < 1: return
		self.charges += evt.damage
		if self.charges < self.threshold: return
		procs, self.charges = divmod(self.charges, self.threshold) # hands back floordiv and remainder
		if procs: self.owner.level.queue_spell(self.do_damage(procs)) # don't have to walk the unit list so many times

	def do_damage(self, procs):
		self.do_ui_flash()
		units = list(self.owner.level.units)
		random.shuffle(units)
		for u in units:
			if are_hostile(self.owner, u):
				for _ in range(procs):
					u.deal_damage(1, Tags.Physical, self)
		yield

class BloodStaff(Equipment):

	def on_init(self):
		self.name = "Blood Staff"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Blood]
		self.recipe = [(Tags.Blood, 2), (Tags.Any, 5)]

		self.tag_bonuses[Tags.Blood]['max_charges'] = 1
		self.tag_bonuses[Tags.Blood]['range'] = 2
		self.tag_bonuses[Tags.Blood]['minion_damage'] = 3

		self.tag_bonuses_pct[Tags.Blood]['minion_health'] = 50
		self.tag_bonuses_pct[Tags.Blood]['damage'] = 50

class BloodReaper(Equipment):

	def on_init(self):
		self.name = "Haunted Blood Vial"
		self.tags = [Tags.Blood]
		self.recipe = [(Tags.Blood, 1), (Tags.Dark,1 ), (Tags.Any, 2)]
		self.description = "When a [Demon] or [Living] unit dies, heal [2 HP:heal]"
		self.global_triggers[EventOnDeath] = self.on_death

	def on_death(self, evt):
		if not (Tags.Living in evt.unit.tags or Tags.Demon in evt.unit.tags): return
		self.owner.heal(2, self)
		self.do_ui_flash()

class EnchantersBoon(Equipment):

	def on_init(self):
		self.name = "Enchanters Boon"
		self.tags = [Tags.Enchantment]
		self.recipe = [(Tags.Enchantment, 2), (Tags.Any, 7)]
		self.description = "When you manually cast a self-targeted [Enchantment] spell, one of your allies also casts it"
		self.owner_triggers[EventOnSpellCast] = self.on_spell_cast

	def on_spell_cast(self, evt):
		if not Tags.Enchantment in evt.spell.tags: return
		if not evt.pay_costs: return
		if evt.spell.range != 0: return

		allies = [u for u in self.owner.level.units if u != self.owner and not are_hostile(self.owner, u)]
		if not allies: return

		newcaster = random.choice(allies)

		spell = type(evt.spell)()
		spell.cur_charges = 1
		spell.caster = newcaster
		spell.owner = newcaster
		spell.statholder = self.owner

		if spell.can_cast(newcaster.x, newcaster.y):
			self.owner.level.defer_cast(newcaster, spell, newcaster.x, newcaster.y, pay_costs=False)
			self.do_ui_flash()

class MenacingEyeMask(Equipment):

	def on_init(self):
		self.name = "Menacing Eye Mask"
		self.slot = SLOT_HELMET
		self.tags = [Tags.Dark, Tags.Eye]
		self.recipe = [(Tags.Dark, 2), (Tags.Enchantment, 1), (Tags.Eye, 2), (Tags.Any, 3)]
		self.global_triggers[EventOnDamaged] = self.on_damage
		self.duration = 2

	def get_description(self):
		return "When one of your [Eye] spells damages an enemy, inflict [{duration}:duration] turns of [fear] on them"

	def on_damage(self, evt):
		if not evt.source: return
		if not are_hostile(evt.unit, self.owner): return
		if not isinstance(evt.source, Spell): return
		if not Tags.Eye in evt.source.tags: return
		if evt.source.owner != self.owner and evt.source.statholder != self.owner: return
		evt.unit.apply_buff(FearBuff(), self.get_stat('duration'))
		self.do_ui_flash()

class Earthwrath(Equipment):

	def on_init(self):
		self.name = "Earthwrath"
		self.tags = [Tags.Chaos, Tags.Nature]
		self.recipe = [(Tags.Chaos, 1), (Tags.Nature, 1), (Tags.Any, 2)]
		self.radius = 4
		self.damage = 18

		self.owner_triggers[EventOnSpellCast] = self.on_cast

	def get_description(self):
		return (
			"When you cast a [Nature] or [Chaos] spell, send out tremors along the ground from the target to nearby enemies\n"
			"Each tremor deals [{damage}:damage] [Physical] damage to the target and all units in its path\n"
			"The number of targets is equal to the level of the spell\n"
			"The tremors can target enemies up to [{radius}:radius] tiles away")

	def on_cast(self, evt):
		if Tags.Chaos not in evt.spell.tags and Tags.Nature not in evt.spell.tags: return
		targets = self.owner.level.get_units_in_ball(evt, self.get_stat('radius'))
		random.shuffle(targets)
		num_targets = self.get_stat('num_targets', base=evt.spell.level)
		for u in targets:
			if u.x == evt.x and u.y == evt.y: continue
			if not are_hostile(self.owner, u): continue
			path = self.owner.level.find_path(evt, u, ground_path_probe, cosmetic=True, pythonize=True, unit_penalty=0)
			if not path: continue
			self.owner.level.queue_spell(self.tremor(path))
			num_targets -= 1
			if num_targets <= 0: break
		if targets: self.do_ui_flash()

	def tremor(self, path):
		for p in path:
			self.owner.level.deal_damage(p.x, p.y, self.get_stat('damage'), Tags.Physical, self)
			yield

class Razoreye(Equipment):

	def on_init(self):
		self.name = "Razoreye"
		self.tags = [Tags.Eye, Tags.Metallic]
		self.recipe = [(Tags.Eye, 1), (Tags.Metallic, 1), (Tags.Any, 3)]
		self.owner_triggers[EventOnSpellCast] = self.on_spell_cast
		self.damage = 27

	def get_description(self):
		return "When you cast a [Metallic] spell, deal [{damage}:damage] [Physical] damage to 1 enemy in line of sight per spell level"

	def on_spell_cast(self, evt):
		if Tags.Metallic in evt.spell.tags:
			spell_level = evt.spell.level
			self.owner.level.queue_spell(self.do_razors(spell_level))
			self.do_ui_flash()

	def do_razors(self, spell_level):
		targets = [u for u in self.owner.level.get_units_in_los(self.owner) if are_hostile(self.owner, u)]
		random.shuffle(targets)
		damage = self.get_stat('damage')
		for t in targets[:spell_level]:
			self.owner.level.show_beam(self.owner, t, Tags.Physical, minor=True, inclusive=False)
			t.deal_damage(damage, Tags.Physical, self)
		yield

class SonicShields(Equipment):

	def on_init(self):
		self.name = "Sonic Shields"
		self.tags = [Tags.Arcane, Tags.Metallic]
		self.recipe = [(Tags.Arcane, 2), (Tags.Metallic, 1), (Tags.Any, 5)]

		self.global_triggers[EventOnShieldRemoved] = self.on_sheild_removed

		self.radius = 5
		self.damage = 1

		self.dtypes = [Tags.Physical, Tags.Arcane]

		self.num_targets = 2
		self.duration = 2

	def on_sheild_removed(self, evt):
		if evt.unit == self.owner: return
		if are_hostile(self.owner, evt.unit): return

		targets = self.owner.level.get_units_in_ball(evt.unit, self.get_stat('radius'))
		targets = [t for t in targets if are_hostile(self.owner, t)]
		targets = [t for t in targets if self.owner.level.can_see(evt.unit.x, evt.unit.y, t.x, t.y)]
		random.shuffle(targets)
		if targets: self.do_ui_flash()
		damage = self.get_stat('damage')
		duration = self.get_stat('duration')
		show_beam = self.owner.level.show_beam
		for t in targets[:self.get_stat('num_targets')]:
			for dtype in self.dtypes:
				if not t.is_alive(): break
				show_beam(evt.unit, t, dtype)
				t.deal_damage(damage, dtype, self)
			if t.is_alive(): t.apply_buff(Silence(), duration)

	def get_description(self):
		return ("When one of your allies loses a shield, up to [{num_targets}:num_targets] enemies in their line of sight within [{radius}:radius] tiles take [{damage}:damage] [Physical] and [Arcane] damage\n"
				"Enemies hit are [silenced] for [{duration}:duration] turns")


class BlazebloodStaff(Equipment):

	def on_init(self):
		self.name = "Blazeblood Staff"
		self.slot = SLOT_WEAPON
		self.color = Tags.Fire.color
		self.buff_type = BUFF_TYPE_BLESS
		self.tag_bonuses[Tags.Fire]['quick_cast'] = 1
		self.tag_bonuses[Tags.Blood]['quick_cast'] = 1

		self.tags = [Tags.Blood, Tags.Fire]
		self.recipe = [(Tags.Arcane, 1), (Tags.Blood, 1), (Tags.Fire, 1), (Tags.Any, 4)]

class ChannelersFocus(Equipment):

	def on_init(self):
		self.name = "Channeler's Focus"
		self.color = Tags.Enchantment.color
		self.owner_triggers[EventOnBuffApply] = self.on_buff
		self.duration = 6
		self.tags = [Tags.Enchantment, Tags.Sorcery]
		self.recipe = [(Tags.Enchantment, 1), (Tags.Ritual, 1), (Tags.Sorcery, 1), (Tags.Any, 1)]
		self.global_bonuses_pct['max_channel'] = 100

	def on_buff(self, evt):
		if isinstance(evt.buff, ChannelBuff):
			self.owner.apply_buff(StunImmune(), self.get_stat('duration'))
			self.do_ui_flash()

	def get_description(self):
		return "Gain [{duration}:duration] turns of Clarity when you cast a channeled spell"

class HexSpecialistsRing(Equipment):

	def on_init(self):
		self.name = "Hex Specialist's Ring"
		self.color = Tags.Enchantment.color
		self.tags = [Tags.Enchantment]
		self.recipe = [(Tags.Arcane, 1), (Tags.Enchantment, 2), (Tags.Any, 4)]
		self.damage = 1

	def on_advance(self):
		units = list(self.owner.level.units)
		random.shuffle(units)
		owner = self.owner
		damage = self.get_stat('damage')
		for u in units: # for each unit in the level
			if not u.is_alive(): continue
			if not are_hostile(owner, u): continue
			num_curses = 0
			for b in u.buffs:
				if b.buff_type == BUFF_TYPE_CURSE:num_curses +=1
			if not num_curses: continue
			self.do_ui_flash()
			for _ in range(num_curses): u.deal_damage(damage, Tags.Arcane, self)

	def get_description(self):
		return "Each turn, enemies take [{damage}:damage] [Arcane] damage for each debuff they have"


class BladeStaff(Equipment):

	def on_init(self):
		self.name = "The Bladestaff"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Metallic]
		self.global_bonuses['damage'] = 6
		self.recipe = [(Tags.Metallic, 3), (Tags.Any, 5)]

class TimelordsStaff(Equipment):

	def on_init(self):
		self.name = "Timelord's Staff"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Arcane, Tags.Enchantment]
		self.global_bonuses['duration'] = 3
		self.recipe = [(Tags.Arcane, 2), (Tags.Enchantment, 2), (Tags.Any, 2)]

class GeometerStaff(Equipment):

	def on_init(self):
		self.name = "Geometer's Staff"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Arcane, Tags.Translocation]
		self.global_bonuses['radius'] = 2
		self.global_bonuses['range'] = 1
		self.recipe = [(Tags.Arcane, 1), (Tags.Translocation, 4), (Tags.Any, 2)]

class StaffOfMemory(Equipment):

	def on_init(self):
		self.name = "Memory Staff"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Arcane]
		self.global_bonuses_pct['max_charges'] = 100
		self.recipe = [(Tags.Arcane, 3), (Tags.Any, 5)]

class HordeLordStaff(Equipment):

	def on_init(self):
		self.name = "Warlord Banner"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Conjuration]
		self.global_bonuses['num_summons'] = 2
		self.recipe = [(Tags.Conjuration, 2), (Tags.Any, 6)]

class MultimancerStaff(Equipment):

	def on_init(self):
		self.name = "Multimancer's Staff"
		self.slot = SLOT_WEAPON
		self.global_bonuses_pct['num_targets'] = 50
		self.recipe = [(Tags.Arcane, 1), (Tags.Translocation, 1), (Tags.Any, 6)]
		self.tags = [Tags.Arcane]

class BrainHat(Equipment):

	def on_init(self):
		self.name = "Brain Hat"
		self.slot = SLOT_HELMET
		self.global_bonuses['max_charges'] = 1
		self.recipe = [(Tags.Arcane, 1), (Tags.Any, 3)]
		self.tags = [Tags.Arcane]

class MarksmanCap(Equipment):

	def on_init(self):
		self.name = "Marksman Cap"
		self.slot = SLOT_HELMET
		self.global_bonuses['range'] = 2
		self.global_bonuses['minion_range'] = 1
		self.tags = [Tags.Conjuration]
		self.recipe = [(Tags.Conjuration, 1), (Tags.Translocation, 1), (Tags.Any, 4)]

class WarlordCrown(Equipment):

	def on_init(self):
		self.name = "Warlord Helm"
		self.slot = SLOT_HELMET
		self.global_bonuses['minion_damage'] = 6
		self.tags = [Tags.Conjuration]
		self.recipe = [(Tags.Conjuration, 2), (Tags.Any, 4)]

class WarlordVestments(Equipment):

	def on_init(self):
		self.name = "Warlord Vestments"
		self.slot = SLOT_ARMOR
		self.global_bonuses['minion_health'] = 10
		self.tags = [Tags.Conjuration]
		self.recipe = [(Tags.Conjuration, 2), (Tags.Any, 4)]

class FingerSix(Equipment):

	def on_init(self):
		self.name = "Finger 6"
		self.global_bonuses['num_summons'] = 1
		self.global_bonuses['num_targets'] = 1
		self.tags = [Tags.Arcane, Tags.Conjuration]
		self.recipe = [(Tags.Arcane, 1), (Tags.Conjuration, 1), (Tags.Dark, 1), (Tags.Translocation, 1), (Tags.Any, 1)]

# make a staff for each general stat?
# minion duration, duration

class ArmorOfTheMasterBuff(Buff):

	def on_init(self):
		self.name = "Armor of the Master"


class ArmorOfTheMaster(Equipment):

	def on_init(self):
		self.tags = [Tags.Blood, Tags.Conjuration, Tags.Enchantment]
		self.recipe = [(Tags.Blood, 1), (Tags.Conjuration, 1), (Tags.Enchantment, 1), (Tags.Any, 4)]
		self.name = "Armor of the Master"
		self.slot = SLOT_ARMOR
		self.description = "Your summoned allies' resistances are set equal to yours if they are higher"
		self.tag_bonuses[Tags.Conjuration]['hp_cost'] = 5
		self.global_triggers[EventOnUnitAdded] = self.on_unit_added

	def on_unit_added(self, evt):
		if evt.unit.is_player_controlled: return
		if are_hostile(self.owner, evt.unit): return
		buff = ArmorOfTheMasterBuff()
		for t in damage_tags:
			if self.owner.resists[t] > evt.unit.resists[t]:
				buff.resists[t] = self.owner.resists[t] - evt.unit.resists[t]
		evt.unit.apply_buff(buff)
		self.do_ui_flash()


class BasiliskScaleArmor(Equipment):

	def on_init(self):
		self.tags = [Tags.Arcane, Tags.Enchantment, Tags.Nature]
		self.recipe = [(Tags.Arcane, 1), (Tags.Enchantment, 1), (Tags.Nature, 1), (Tags.Dragon, 1), (Tags.Any, 2)]
		self.name = "Basilisk Scale Armor"
		self.slot = SLOT_ARMOR
		self.global_triggers[EventOnSpellCast] = self.on_spell_cast
		self.resists[Tags.Physical] = 25
		self.num_targets = 3
		self.add_spell_tooltip(PetrifySpell)

	def on_spell_cast(self, evt):
		if (evt.x, evt.y) != (self.owner.x, self.owner.y): return
		if not are_hostile(evt.caster, self.owner): return
		self.owner.level.queue_spell(self.retributive_cast(evt.caster))
		self.do_ui_flash()

	def retributive_cast(self, unit):
		yield
		if not unit.is_alive(): return
		s = self.owner.get_or_make_spell(PetrifySpell)
		for _ in self.owner.level.act_cast(self.owner, s, unit.x, unit.y, pay_costs=False, queue=False): yield
		yield


	def get_description(self):
		return ("Cast Petrify on the first [{num_targets}:num_targets] enemies that target you with a spell each turn")


class CharmOfVigor(Equipment):

	def on_init(self):
		self.tags = [Tags.Nature]
		self.recipe = [(Tags.Conjuration, 1), (Tags.Enchantment, 1), (Tags.Any, 3)]
		self.global_triggers[EventOnUnitAdded] = self.on_unit_added
		self.name = "Charm Of Vigor"
		self.add_effect_tooltip(CharmOfVigorBuff)

	def get_description(self):
		return "Your summoned allies gain [25 Physical:physical] resist, [25 Lightning:lightning] resist, [25 Ice:ice] resist, and [25 Fire:fire] resist"

	def on_unit_added(self, evt):
		u = evt.unit
		if u.is_player_controlled: return
		if not self.owner.level.are_hostile(self.owner, u):
			self.owner.level.queue_spell(self.give_buff(u))
			self.do_ui_flash()

	def give_buff(self, u):
			u.apply_buff(CharmOfVigorBuff())
			yield

class CharmOfDarkness(Equipment):

	def on_init(self):
		self.tags = [Tags.Nature]
		self.recipe = [(Tags.Conjuration, 1), (Tags.Enchantment, 1), (Tags.Any, 3)]
		self.global_triggers[EventOnUnitAdded] = self.on_unit_added
		self.name = "Charm Of Darkness"
		self.add_effect_tooltip(CharmOfDarknessBuff)

	def get_description(self):
		return "Your summoned allies gain [25 Arcane:arcane] resist, [25 Dark:dark] resist, and [25 Holy:holy] resist"

	def on_unit_added(self, evt):
		u = evt.unit
		if u.is_player_controlled: return
		if not self.owner.level.are_hostile(self.owner, u):
			self.owner.level.queue_spell(self.give_buff(u))
			self.do_ui_flash()

	def give_buff(self, u):
			u.apply_buff(CharmOfDarknessBuff())
			yield

class CharmOfVigorBuff(Buff):

	def on_init(self):
		self.name = "Charm Of Vigor"
		self.resists[Tags.Physical] = 25
		self.resists[Tags.Fire] = 25
		self.resists[Tags.Ice] = 25
		self.resists[Tags.Lightning] = 25
		self.stack_type = STACK_INTENSITY

class CharmOfDarknessBuff(Buff):

	def on_init(self):
		self.name = "Charm Of Darkness"
		self.resists[Tags.Arcane] = 25
		self.resists[Tags.Dark] = 25
		self.resists[Tags.Holy] = 25
		self.stack_type = STACK_INTENSITY


class GenericOculusDebuff(Buff):

	def __init__(self, name, tag_pair):
		Buff.__init__(self)
		self.buff_type = BUFF_TYPE_CURSE
		self.color = tag_pair[0].color
		self.name = "%s Weakness" % name
		self.stack_type = STACK_NONE
		for tag in tag_pair: self.resists[tag] = -25

class GenericOculusEquip(Equipment):

	def __init__(self, name, tags):
		self.tag_pair = tags
		Equipment.__init__(self, name, tags)
		self.tags = tags.copy()
		self.global_triggers[EventOnDamaged] = self.on_damage
		self.name = "%s Oculus" % name
		self.n_str = name
		self.recipe = [(Tags.Enchantment, 1), (tags[0], 1), (tags[1], 1), (Tags.Any, 3)]
		self.add_effect_tooltip(lambda: GenericOculusDebuff(self.n_str, self.tag_pair))

	def get_description(self):
		return ("The first time an enemy takes {tag1} or {tag2} damage, it gets -25 {tag1} and {tag2} resist", {'tag1': formatted_tag(self.tag_pair[0]), 'tag2': formatted_tag(self.tag_pair[1])})

	def on_damage(self, evt):
		if are_hostile(evt.unit, self.owner) and evt.damage_type in self.tag_pair:
			evt.unit.apply_buff(GenericOculusDebuff(self.n_str, self.tag_pair))
			self.do_ui_flash()

class ElementalRobe(Equipment):

	def __init__(self, name, tag, resists, bonuses):
		Equipment.__init__(self, name, tag, resists, bonuses)
		self.name = "Robe of %s" % name
		self.slot = SLOT_ARMOR

		for entry in bonuses:
			stat, amount = entry
			self.tag_bonuses_pct[tag][stat] = amount

		for entry in resists:
			resist, amount = entry
			self.resists[resist] = amount

		self.tags = [tag]
		self.recipe = [(tag, 2), (Tags.Any, 7)]

class RobeOfStorms(Equipment):

	def on_init(self):
		self.name = "Robe of Storms"
		self.slot = SLOT_ARMOR
		self.resists[Tags.Ice] = 25
		self.resists[Tags.Lightning] = 25
		self.global_triggers[EventOnDeath] = self.on_damage
		self.tags = [Tags.Ice, Tags.Lightning]
		self.recipe =[(Tags.Ice, 1), (Tags.Lightning, 1), (Tags.Nature, 1), (Tags.Any, 3)]
		self.trigger_tags = [Tags.Ice, Tags.Lightning]

	def get_description(self):
		return "When an enemy dies to [Ice] or [Lightning] damage, gain [1 SH:shields]"

	def on_damage(self, evt):
		if not evt.damage_event: return
		if not are_hostile(self.owner, evt.unit): return
		if not evt.damage_event.damage_type in self.trigger_tags: return
		self.owner.add_shields(1)
		self.do_ui_flash()

class FaeRobe(Equipment):

	def on_init(self):
		self.name = "Fae Plate"
		self.slot = SLOT_ARMOR
		self.tags = [Tags.Arcane]
		self.recipe = [(Tags.Arcane, 1), (Tags.Metallic, 1), (Tags.Any, 2)]

	def get_description(self):
		return "Gain [1 SH:shields] each turn, up to a max of 3"

	def on_advance(self):
		if self.owner.shields < 3:
			self.owner.add_shields(1)
			self.do_ui_flash()

class VampiricVestments(Equipment):

	def on_init(self):
		self.name = "Vampiric Vestments"
		self.slot = SLOT_ARMOR
		self.resists[Tags.Dark] = 25
		self.resists[Tags.Ice] = 25
		self.description = "When a [Living] unit dies, heal [5 HP:heal]"
		self.global_triggers[EventOnDeath] = self.on_death
		self.tags = [Tags.Blood, Tags.Dark]
		self.recipe = [(Tags.Blood, 2), (Tags.Dark, 2), (Tags.Any, 4)]

	def on_death(self, evt):
		if Tags.Living in evt.unit.tags:
			self.owner.heal(5, self)
			self.do_ui_flash()

class DwarvenChainmail(Equipment):

	def on_init(self):
		self.name = "Dwarven Chainmail"
		self.slot = SLOT_ARMOR
		self.resists[Tags.Physical] = 50
		self.resists[Tags.Fire] = 50
		self.resists[Tags.Dark] = 50

class ElvenChainmail(Equipment):

	def on_init(self):
		self.name = "Elven Chainmail"
		self.slot = SLOT_ARMOR
		self.resists[Tags.Physical] = 50
		self.resists[Tags.Arcane] = 50
		self.resists[Tags.Lightning] = 50


class EarthtrollArmor(Equipment):

	def on_init(self):
		self.name = "Earthtroll Armor"
		self.slot = SLOT_ARMOR

		self.resists[Tags.Physical] = 50
		self.description = "Each turn, heal [5 HP:heal]"
		self.tags = [Tags.Nature]
		self.recipe = [(Tags.Nature, 2), (Tags.Metallic, 2), (Tags.Any, 4)]

	def on_advance(self):
		if self.owner.cur_hp < self.owner.max_hp:
			self.owner.heal(5, self)
			self.do_ui_flash()

class StormtrollArmor(Equipment):

	def on_init(self):
		self.name = "Stormtroll Armor"
		self.slot = SLOT_ARMOR

		self.resists[Tags.Lightning] = 50
		self.description = "Each turn, heal [5 HP:heal]"
		self.tags = [Tags.Lightning, Tags.Nature]
		self.recipe = [(Tags.Lightning, 2), (Tags.Nature, 2), (Tags.Any, 4)]

	def on_advance(self):
		if self.owner.cur_hp < self.owner.max_hp:
			self.owner.heal(5, self)
			self.do_ui_flash()

class StormbroodTrickshoes(Equipment):

	def on_init(self):
		self.name = "Stormbrood Trickshoes"
		self.tags = [Tags.Lightning, Tags.Translocation]
		self.recipe = [(Tags.Conjuration, 1), (Tags.Lightning, 1), (Tags.Translocation, 1), (Tags.Any, 1)]
		self.slot = SLOT_BOOTS

		example = StormTroll()
		self.minion_health = example.max_hp
		self.minion_damage = example.spells[0].damage

		self.owner_triggers[EventOnSpellCast] = self.on_cast

	def get_extra_examine_tooltips(self):
		return [self.make_stormtroll()]

	def get_description(self):
		return ("When you cast a [Translocation] spell, summon a Storm Troll at your original location"
				"\nIt can cast your Blink on an 8 turn cooldown")

	def on_cast(self, evt):
		if Tags.Translocation not in evt.spell.tags: return
		self.owner.level.queue_spell(self.do_summon(self.owner.x, self.owner.y))
		self.do_ui_flash()

	def make_stormtroll(self):
		u = StormTroll()
		apply_minion_bonuses(self, u)
		grant_minion_spell(BlinkSpell, u, self.owner, cool_down=8, pre_insert=True)
		return u

	def do_summon(self, x, y):
		self.summon(self.make_stormtroll(), Point(x, y))
		yield

class SpiritVisor(Equipment):

	def on_init(self):
		self.name = "Spirit Visor"
		self.slot = SLOT_HELMET
		self.resists[Tags.Arcane] = -25
		self.resists[Tags.Physical] = -25
		self.owner_triggers[EventOnDamaged] = self.on_damaged
		self.tags = [Tags.Arcane, Tags.Enchantment]
		self.recipe = [(Tags.Arcane, 1), (Tags.Enchantment, 1), (Tags.Any, 3)]

	def get_description(self):
		return "When you take damage, gain [1 SH:shields]"

	def on_damaged(self, evt):
		if evt.damage <= 0: return
		self.owner.add_shields(1)
		self.do_ui_flash()

class ArmorOfSouls(Equipment):

	def on_init(self):
		self.name = "Soulmail"
		self.slot = SLOT_ARMOR
		
		self.resists[Tags.Physical] = 25
		self.resists[Tags.Dark] = 25
		self.resists[Tags.Arcane] = 25

		self.global_triggers[EventOnDeath] = self.on_death
		self.tags = [Tags.Arcane, Tags.Dark, Tags.Holy]
		self.recipe = [(Tags.Arcane, 1), (Tags.Dark, 1), (Tags.Holy, 1), (Tags.Any, 2)]

	def get_description(self):
		return "When a [Living] unit dies, gain [1 SH:shields], up to a max of 4"

	def on_death(self, evt):
		if Tags.Living not in evt.unit.tags: return
		if self.owner.shields < 4:
			self.owner.add_shields(1)
			self.do_ui_flash()

class Earthboots(Equipment):

	def on_init(self):
		self.name = "Earthmeld Boots"
		self.description = "Each turn, heal [3 HP:heal] unless you moved"
		self.slot = SLOT_BOOTS
		self.last_pos = (-1, -1)
		self.tags = [Tags.Nature]
		self.recipe = [(Tags.Metallic, 1), (Tags.Nature, 1), (Tags.Any, 2)]

	def on_pre_advance(self):
		self.last_pos = (self.owner.x, self.owner.y)

	def on_advance(self):
		if self.last_pos == (self.owner.x, self.owner.y):
			self.owner.heal(3, self)
			self.do_ui_flash()

class WingedBoots(Equipment):

	def on_init(self):
		self.name = "Winged Shoes"
		self.description = "Grants Flying"
		self.slot = SLOT_BOOTS
		self.tags = [Tags.Enchantment, Tags.Translocation]
		self.recipe = [(Tags.Enchantment, 1), (Tags.Translocation, 2), (Tags.Any, 2)]

	# Wont work if other stuff starts messing with the wizard's flyingness
	def on_applied(self, owner):
		self.owner.flying += 1

	def on_unapplied(self):
		self.owner.flying -= 1

class DrillShoes(Equipment):

	def on_init(self):
		self.name = "Drill Shoes"
		self.description = "Grants Burrowing"
		self.slot = SLOT_BOOTS
		self.tags = [Tags.Metallic, Tags.Translocation]
		self.owner_triggers[EventOnUnitAdded] = self.on_added
		self.recipe = [(Tags.Nature, 1), (Tags.Metallic, 1), (Tags.Translocation, 3)]

	def on_added(self, evt): # drill away a wall if deploying onto one. hacky, but works as long as only this give burrowing to wizard
		u = self.owner
		loc = u.level.tiles[u.x][u.y]
		if loc.is_wall(): u.level.make_floor(u.x, u.y)

	# Wont work if other stuff starts messing with the wizard's flyingness
	def on_applied(self, owner):
		self.owner.burrowing += 1

	def on_unapplied(self):
		self.owner.burrowing -= 1

class SilkenSandals(Equipment):

	def on_init(self):
		self.name = "Silken Sandals"
		self.slot = SLOT_BOOTS
		self.owner_triggers[EventOnMoved] = self.on_move
		self.tags = [Tags.Holy, Tags.Translocation]
		self.recipe = [(Tags.Holy, 1), (Tags.Translocation, 1), (Tags.Any, 4)]

	def get_description(self):
		return "When you take a step, gain [1 SH:shields]"

	def on_move(self, evt):
		if evt.teleport: return
		self.owner.add_shields(1)
		self.do_ui_flash()

class SnowShoes(Equipment):

	def on_init(self):
		self.name = "Snow Shoes"
		self.description = "When a unit is [frozen], heal [2 HP:heal]"
		self.slot = SLOT_BOOTS
		self.global_triggers[EventOnBuffApply] = self.on_buff
		self.tags = [Tags.Ice, Tags.Nature]
		self.recipe = [(Tags.Ice, 1), (Tags.Nature, 1), (Tags.Any, 3)]

	def on_buff(self, evt):
		if not isinstance(evt.buff, FrozenBuff): return
		self.owner.level.queue_spell(self.do_heal())
		self.do_ui_flash()

	def do_heal(self):
		self.owner.heal(2, self)
		yield

class TravellersBoots(Equipment):

	def on_init(self):
		self.recipe = [(Tags.Metallic, 1), (Tags.Translocation, 1), (Tags.Any, 3)]
		self.tags = [Tags.Translocation]
		self.name = "Travellers Shoes"
		self.slot = SLOT_BOOTS
		self.resists[Tags.Fire] = 25
		self.resists[Tags.Lightning] = 25
		self.resists[Tags.Ice] = 25

class SummonShoes(Equipment):

	def __init__(self, steps, spawn_fn, name):
		self.spawn_fn = spawn_fn
		self.steps = steps
		self.counter = steps

		ex = spawn_fn()
		self.minion_health = ex.max_hp
		self.minion_damage = ex.spells[0].damage
		if not ex.spells[0].melee: self.minion_range = ex.spells[0].range

		Equipment.__init__(self, steps, spawn_fn, name)
		self.name = name
		self.tags = [Tags.Conjuration, Tags.Translocation]
		for tag in ex.tags:
			if tag in component_tags:
				self.tags.append(tag)

		self.recipe = []
		for tag in self.tags: self.recipe.append((tag, 1))
		num_any = 4 - len(self.tags)
		if num_any > 0: self.recipe.append((Tags.Any, num_any))
		self.slot = SLOT_BOOTS


	def on_init(self):
		self.spawn_name = self.spawn_fn().name
		self.owner_triggers[EventOnMoved] = self.on_move
		self.owner_triggers[EventOnUnitAdded] = self.on_enter_level
		self.tags = [Tags.Conjuration, Tags.Translocation]
		self.recipe = [(Tags.Conjuration, 1), (Tags.Translocation, 1), (Tags.Any, 2)]

	def get_description(self):
		return ("Every {steps} steps, summon a {unit}\n{counter} steps until summon",
		{'steps':self.steps, 'unit':self.spawn_name, 'counter':self.counter})

	def on_move(self, evt):
		if evt.teleport: return

		self.counter -= 1
		if self.counter <= 0:
			unit = self.spawn_fn()
			apply_minion_bonuses(self, unit)
			self.summon(unit)
			self.do_ui_flash()
			self.counter = self.steps

	def on_enter_level(self, evt):
		self.counter = self.steps

	def get_extra_examine_tooltips(self):
		return [self.spawn_fn()]

class CantripClogs(Equipment):

	def on_init(self):
		self.name = "Cantrip Clogs"
		self.description = "When you take a step, regain a charge of each level 1 spell you know"
		self.slot = SLOT_BOOTS

		self.owner_triggers[EventOnMoved] = self.on_move
		self.tags = [Tags.Translocation]
		self.recipe = [(Tags.Sorcery, 1), (Tags.Conjuration, 1), (Tags.Enchantment, 1), (Tags.Translocation, 1), (Tags.Any, 1)]

	def on_move(self, evt):
		if evt.teleport: return
		spells = [s for s in self.owner.spells if s.level == 1 and s.cur_charges < s.get_stat('max_charges')]
		for s in spells:
			s.refund_charges(1) # play a sound or show an effect here?
			s.do_ui_flash()
			self.do_ui_flash()

class TimeStriders(Equipment):

	def on_init(self):
		self.name = "Timestriders"
		self.duration = 1
		self.tags = [Tags.Arcane, Tags.Translocation]
		self.slot = SLOT_BOOTS

		self.owner_triggers[EventOnUnitAdded] = self.on_enter
		self.recipe = [(Tags.Arcane, 1), (Tags.Enchantment, 1), (Tags.Translocation, 1), (Tags.Word, 1), (Tags.Any, 1)]

	def get_description(self):
		duration = self.get_stat('duration')
		turns_kw = 'turn' if duration == 1 else 'turns'
		return  ("At the beginning of each level, enemies are [stunned] for [{duration}:duration] {turns}", {'duration':duration, 'turns':turns_kw})

	def on_enter(self, evt):
		dur = self.get_stat('duration')
		self.do_ui_flash()
		for u in self.owner.level.units:
			if are_hostile(self.owner, u):
				u.apply_buff(Stun(), dur)

class EcophagyBuff(Buff):

	def on_init(self):
		self.name = "Ecophagy"
		self.description = "Ecophagy\nEach turn, eat all adjacent walls\nGain 1 max HP per wall consumed"
		self.buff_type = BUFF_TYPE_PASSIVE

	def on_advance(self):
		targets = []

		for tile in self.owner.level.get_tiles_in_ball(self.owner.x, self.owner.y, 1.5):
			if tile.is_wall(): targets.append(tile)
		if targets:
			for target in targets:
				self.owner.level.make_floor(target.x, target.y)
				self.owner.level.show_effect(target.x, target.y, Tags.Physical)
				self.owner.max_hp += 1
				self.owner.heal(1, self)


def GreyGooSlime():
	u = Unit()
	u.name = "Grey Goo"
	u.asset_name = 'metal_slime'
	u.max_hp = 20
	u.tags = [Tags.Metallic, Tags.Slime]
	u.spells.append(SimpleMeleeAttack(6, damage_type=Tags.Physical))
	u.buffs.append(SlimeBuff(spawner=GreyGooSlime))
	u.buffs.append(EcophagyBuff())
	u.resists[Tags.Poison] = 100
	u.resists[Tags.Physical] = 75
	return u

class GreyGoo(Equipment):

	def on_init(self):
		self.name = "Grey Goo"
		self.tags = [Tags.Metallic, Tags.Slime]
		self.recipe = [(Tags.Metallic, 1), (Tags.Slime, 1), (Tags.Any, 2)]
		self.global_triggers[EventOnUnitPreAdded] = self.on_added

		self.minion_health = 20
		self.minion_damage = 6

	def make_goo_template(self):
		u = GreyGooSlime()
		apply_minion_bonuses(self, u)
		for b in u.buffs:
			if isinstance(b, SlimeBuff):
				b.spawner = lambda: self.make_goo_template()
		u.source = self
		return u

	def on_added(self, evt):
		if are_hostile(evt.unit, self.owner): return
		if Tags.Slime not in evt.unit.tags: return
		if evt.unit.name != "Green Slime": return
		goo = self.make_goo_template()
		evt.unit.name = goo.name
		evt.unit.asset_name = goo.asset_name
		evt.unit.tags = goo.tags
		evt.unit.spells = goo.spells
		evt.unit.buffs = goo.buffs
		evt.unit.resists = goo.resists
		evt.unit.max_hp = goo.max_hp
		evt.unit.cur_hp = goo.max_hp
		evt.unit.source = goo.source
		self.do_ui_flash()

	def get_description(self):
		return "If you would summon a Green Slime, you instead summon Grey Goo\nGrey Goo have the Ecophagy buff which causes its owner to eat any adjacent walls at the end of their turn, gaining 1 max HP for each wall consumed this way"

	def get_extra_examine_tooltips(self):
		return [make_minion(self, GreyGooSlime)]

class MacrophagicMask(Equipment):

	def on_init(self):
		self.name = "Macrophagic Mask"
		self.slot = SLOT_HELMET
		self.global_triggers[EventOnDamaged] = self.on_damaged
		self.description = "When [Living] or [Slime] allies damage an enemy, they gain 2 max HP"
		self.tags = [Tags.Blood, Tags.Nature, Tags.Slime]
		self.recipe = [(Tags.Blood, 1), (Tags.Nature, 1), (Tags.Slime, 1), (Tags.Any, 2)]

	def on_damaged(self, evt):
		if not evt.source: return
		if not evt.source.owner: return
		if are_hostile(evt.source.owner, self.owner): return
		if not are_hostile(self.owner, evt.unit): return
		if Tags.Living not in evt.source.owner.tags and Tags.Slime not in evt.source.owner.tags: return
		if evt.source.owner is self.owner or evt.source.owner.is_player_controlled: return
		evt.source.owner.max_hp += 2
		evt.source.owner.heal(2, self)
		self.do_ui_flash()

class OozingScaleArmor(Equipment):

	def on_init(self):
		self.resists[Tags.Physical] = 50
		self.resists[Tags.Poison] = 100
		self.name = "Oozing Scale Armor"
		self.slot = SLOT_ARMOR
		self.description = ("Summon a slime of a matching type when you take damage from an enemy\n"
							"If there is no slime which matches the damage type, summon a random slime")
		self.owner_triggers[EventOnDamaged] = self.on_damaged
		self.tags = [Tags.Conjuration, Tags.Slime]
		self.recipe = [(Tags.Conjuration, 1), (Tags.Dragon, 1), (Tags.Slime, 2), (Tags.Any, 4)]

		self.minion_health = 10
		self.minion_damage = 3
		self.minion_range = 3

	def on_damaged(self, evt):
		if evt.damage <= 0: return
		if not evt.damage_type: return
		if not evt.source: return
		if not evt.source.owner: return
		if not are_hostile(self.owner, evt.source.owner): return
		summon = make_minion(self, self.get_damage_matched_slime(evt.damage_type))
		self.summon(summon, self.owner)
		self.do_ui_flash()

	def get_damage_matched_slime(self, dtype):
		dtype_to_slime = {
			Tags.Fire: RedSlime,
			Tags.Ice: IceSlime,
			Tags.Lightning: ElectricSlime,
			Tags.Poison: GreenSlime,
			Tags.Arcane: VoidSlime,
			Tags.Dark: BloodSlime,
		}

		slime = dtype_to_slime.get(dtype)
		if slime:
			return slime

		return random.choice([RedSlime, IceSlime, ElectricSlime, GreenSlime, BloodSlime, VoidSlime])

class SlimyVoodooMantle(Equipment):

	def on_init(self):
		self.name = "Slimy Voodoo Mantle"
		self.slot = SLOT_ARMOR
		self.description = "If you would take damage, deal that much damage to one of your adjacent [Slime] allies instead"
		self.tag_bonuses[Tags.Slime]['max_charges'] = 2
		self.tag_bonuses[Tags.Slime]['minion_health'] = 10
		self.tags = [Tags.Slime]
		self.recipe = [(Tags.Conjuration, 1), (Tags.Dark, 1), (Tags.Slime, 1), (Tags.Any, 3)]

	def on_applied(self, owner):
		def voodoo_handler(amount, damage_type, source, redirect_chain):
			if amount <= 0: return None
			lvl = owner.level
			adj_slime_allies = [u for u in lvl.get_adjacent_units(owner) if u.cur_hp > 0 and not are_hostile(u, owner) and Tags.Slime in u.tags]
			if not adj_slime_allies: return
			slime = random.choice(adj_slime_allies)
			dealt = lvl.deal_redirected_damage(self, slime.x, slime.y, amount, damage_type, source, redirect_chain)
			if dealt: lvl.show_path_effect(owner, slime, Tags.Poison, minor=True)
			return dealt
		owner.grant_redirect(self, voodoo_handler)

	def on_unapplied(self):
		self.owner.remove_redirect(self)

class CrisisCharm(Equipment):

	def on_init(self):
		self.name = "Crisis Charm"
		self.owner_triggers[EventOnDamaged] = self.on_damage
		self.description = "On taking lethal damage, remove all debuffs and heal to full health\nDiscarded after use"
		self.recipe = [(Tags.Holy, 1), (Tags.Word, 1), (Tags.Any, 2)]
		self.tags = [Tags.Blood, Tags.Enchantment, Tags.Holy]

	def on_damage(self, evt):
		if self.owner.cur_hp > 0: return

		for buff in list(self.owner.buffs): # list all buffs
			if buff.buff_type == BUFF_TYPE_CURSE: # for each debuff
				self.owner.remove_buff(buff) # remove the debuff

		self.owner.cur_hp = self.owner.max_hp
		self.do_ui_flash()

		# Log usage
		self.owner.level.log(("[{unit}:{color}] used a Crisis Charm", {"unit": self.owner.name, "color": log_color(self.owner)}))
		self.owner.unequip(self)


class Ankh(Equipment): 

	def on_init(self):
		self.name = "Ankh"
		self.damage = 1
		self.tags = [Tags.Holy]
		self.recipe = [(Tags.Conjuration, 1), (Tags.Holy, 2), (Tags.Any, 3)]

	def get_description(self):
		return "Each turn, deal [{damage}:damage] [Holy] damage to enemies adjacent to your allies"

	def on_advance(self):
		dmg = self.get_stat('damage')
		activated = False
		for u in self.owner.level.units:
			if are_hostile(u, self.owner): continue
			if u == self.owner: continue
			if not activated: activated = True
			for w in self.owner.level.get_adjacent_units(u):
				if are_hostile(w, self.owner):
					w.deal_damage(dmg, Tags.Holy, self)
		if activated: self.do_ui_flash()

class Drakenstaff(Equipment):

	def on_init(self):
		self.name = "Drakenstaff"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Dragon]
		self.recipe = [(Tags.Dragon, 2), (Tags.Any, 4)]

		self.tag_bonuses[Tags.Dragon]['minion_damage'] = 12
		self.tag_bonuses[Tags.Dragon]['minion_range'] = 1
		self.tag_bonuses_pct[Tags.Dragon]['minion_health'] = 25

class Bloodruby(Equipment):

	def on_init(self):
		self.name = "Blood Ruby"

		self.tag_bonuses_pct[Tags.Blood]['damage'] = 100
		self.tag_bonuses_pct[Tags.Blood]['range'] = 100
		self.tag_bonuses_pct[Tags.Blood]['hp_cost'] = 100
		self.tags = [Tags.Blood]
		self.recipe = [(Tags.Blood, 2), (Tags.Any, 2)]

class EyeNecklace(Equipment):

	def on_init(self):
		self.name = "Eye Rock Pendant"
		self.tag_bonuses[Tags.Eye]['shot_cooldown'] = -1
		self.tags = [Tags.Eye]
		self.recipe = [(Tags.Eye, 1), (Tags.Metallic, 1), (Tags.Any, 3)]

class AmberCube(Equipment):

	def on_init(self):
		self.name = "Amber Cube"
		self.tag_bonuses[Tags.Nature]['minion_health'] = 12
		self.tags = [Tags.Conjuration, Tags.Nature]
		self.recipe = [(Tags.Conjuration, 1), (Tags.Nature, 1), (Tags.Any, 2)]

class SkullNecklace(Equipment):

	def on_init(self):
		self.name = "Skull Necklace"
		self.minion_damage = 1
		self.duration = 20
		self.owner_triggers[EventOnSpellCast] = self.on_cast
		self.tags = [Tags.Dark, Tags.Enchantment]
		self.recipe = [(Tags.Conjuration, 1), (Tags.Dark, 1), (Tags.Enchantment, 1), (Tags.Any, 2)]
		self.add_effect_tooltip(lambda: BloodrageBuff(self.get_stat('minion_damage')))

	def get_description(self):
		return "When you cast a [Dark] spell, your [Undead] allies gain [{minion_damage}:minion_damage] damage to their spells for [{duration}:duration] turns"

	def on_cast(self, evt):
		if Tags.Dark not in evt.spell.tags: return
		self.do_ui_flash()
		minion_dmg = self.get_stat('minion_damage')
		dur = self.get_stat('duration')
		for u in self.owner.level.units:
			if are_hostile(u, self.owner) or u == self.owner: continue
			if Tags.Undead not in u.tags: continue
			u.apply_buff(BloodrageBuff(minion_dmg), dur)

class RedObsidianShard(Equipment):

	def on_init(self):
		self.name = "Red Obsidian Shard"
		self.damage = 10
		self.tags = [Tags.Enchantment, Tags.Fire]
		self.recipe = [(Tags.Dark, 1), (Tags.Enchantment, 1), (Tags.Fire, 1), (Tags.Any, 1)]

	def get_description(self):
		return "Each turn, enemies adjacent to your [Demon] and [Undead] allies take [{damage}:damage] [Fire] damage"

	def on_advance(self):
		targets = set()
		damage = self.get_stat('damage')
		# Build a list of enemies adjacent to allies
		for u in self.owner.level.units:
			if u == self.owner: continue
			if are_hostile(u, self.owner): continue
			if not (Tags.Undead in u.tags or Tags.Demon in u.tags): continue
			for w in self.owner.level.get_adjacent_units(u):
				if are_hostile(w, self.owner): targets.add(w)

		for u in targets: u.deal_damage(damage, Tags.Fire, self)
		if targets: self.do_ui_flash()

class JadeShard(Equipment):

	def on_init(self):
		self.name = "Jade Shard"
		self.duration = 12
		self.tags = [Tags.Nature]
		self.recipe = [(Tags.Enchantment, 1), (Tags.Nature, 1), (Tags.Any, 2)]
		self.unit_tags = [Tags.Living, Tags.Nature]

	def get_description(self):
		return "Each turn, enemies adjacent to your [Living] and [Nature] allies are [poisoned] for [{duration}:duration] turns"

	def on_advance(self):
		targets = set()
		# Build a list of enemies adjacent to allies
		for u in self.owner.level.units:
			if u == self.owner: continue
			if are_hostile(u, self.owner): continue
			if not u.has_tags(self.unit_tags): continue
			for w in self.owner.level.get_adjacent_units(u):
				if are_hostile(w, self.owner): targets.add(w)
		duration = self.get_stat('duration')
		for u in targets: u.apply_buff(Poison(), duration)
		if targets: self.do_ui_flash()

class DragonclawSabatons(Equipment):

	def on_init(self):
		self.name = "Dragonclaw Sabatons"
		self.slot = SLOT_BOOTS
		self.description = "When you take a step, cast Dragon Claw on a random adjacent enemy"
		self.owner_triggers[EventOnMoved] = self.on_move
		self.tags = [Tags.Dragon, Tags.Translocation]
		self.recipe = [(Tags.Blood, 1), (Tags.Dragon, 2), (Tags.Translocation, 1), (Tags.Any, 3)]
		self.add_spell_tooltip(DragonClaw)

	def on_move(self, evt):
		if evt.teleport: return
		owner = self.owner
		level = owner.level
		targets = set()

		# Build a set of units adjacent to the wizard
		for p in level.get_adjacent_points(owner, False, False):
			u = level.get_unit_at(p.x, p.y)
			if not u: continue
			if not are_hostile(owner, u): continue
			targets.add((u, p)) # stash the point so we know where to attack for 3x3s

		if not targets: return

		target, p = targets.pop()
		for _ in level.act_cast(owner, owner.get_or_make_spell(DragonClaw), p.x, p.y, pay_costs=False, queue=False): pass
		self.do_ui_flash()

class FangedAmulet(Equipment):

	def on_init(self):
		self.name = "Fanged Amulet"
		self.global_triggers[EventOnDamaged] = self.on_damage
		self.tags = [Tags.Blood]
		self.recipe = [(Tags.Blood, 1), (Tags.Metallic, 1), (Tags.Any, 3)]

	def get_description(self):
		desc = ["Each turn, deal [Physical] damage equal to your [Blood] mastery to an adjacent unit"
				"\nHeal for the damage dealt"]
		if self.owner: desc.append("\n[Blood Mastery:blood]: [{mastery}:physical]")
		return desc

	def fmt_dict(self):
		d = Equipment.fmt_dict(self)
		d['mastery'] = self.owner.get_mastery(Tags.Blood) if self.owner else 0
		return d

	def on_advance(self):
		targets = self.owner.level.get_adjacent_units(self.owner)
		if targets:
			target = random.choice(targets)
			dmg = self.owner.get_mastery(Tags.Blood)
			target.deal_damage(dmg, Tags.Physical, self)
			target.level.show_effect(target.x, target.y, Tags.Fang, speed=2)
			self.do_ui_flash()

	def on_damage(self, evt):
		if not evt.source == self: return
		if not evt.damage: return
		self.owner.heal(evt.damage, self)

class StoneeaterAmulet(Equipment):

	def on_init(self):
		self.name = "Stoneeater Amulet"
		self.description = "Each turn, eat adjacent walls\nHeal [10 HP:heal] for each wall you eat"
		self.tags = [Tags.Metallic]
		self.recipe = [(Tags.Metallic, 1), (Tags.Nature, 1), (Tags.Any, 2)]

	def on_advance(self):
		activated = False
		for tile in self.owner.level.get_tiles_in_ball(self.owner.x, self.owner.y, self.owner.radius + 1, diag=True):
			if tile.is_wall():
				if not activated: activated = True
				self.owner.level.make_floor(tile.x, tile.y)
				self.owner.level.show_effect(tile.x, tile.y, Tags.Physical)
				self.owner.heal(10, self)
		self.do_ui_flash()


class BlizzardBeacon(Equipment):

	def on_init(self):
		self.name = "Blizzard Beacon"
		self.tags = [Tags.Ice]
		self.recipe = [(Tags.Ice, 2), (Tags.Translocation, 1), (Tags.Any, 2)]

		self.damage = 5
		self.duration = 5

	def get_description(self):
		desc = ["Each turn, summon a random number of [Blizzards:ice] across the level"
				"\nThe [Blizzards:ice] deal [{damage}:damage] damage and last for [{duration}:duration] turns"
				"\nThe maximum number summoned each turn is equal to your [Ice] mastery"]
		if self.owner: desc.append("\n[Ice Mastery:ice]: [{mastery}:ice]")
		return desc

	def fmt_dict(self):
		d = Equipment.fmt_dict(self)
		d['mastery'] = self.owner.get_mastery(Tags.Ice) if self.owner else 0
		return d


	def on_advance(self):
		if not self.owner.level.has_hostile_units(): return
		mastery = self.owner.get_mastery(Tags.Ice)
		if mastery:
			num_blizzard_summons = random.randint(0, mastery)
			self.create_blizzard(num_blizzard_summons)
			self.do_ui_flash()

	def create_blizzard(self, num_blizzard_summons):
		tiles = [tile for tile in self.owner.level.iter_tiles() if not tile.cloud and not tile.is_wall() and (tile.x, tile.y) != (self.owner.x, self.owner.y)]

		random.shuffle(tiles)
		dmg = self.get_stat('damage')
		dur = self.get_stat('duration')
		for t in tiles[:num_blizzard_summons]:
			tile = tiles.pop()
			cloud = BlizzardCloud(self.owner, damage=dmg, duration=dur)
			self.owner.level.add_obj(cloud, tile.x, tile.y)

class StormBeacon(Equipment):

	def on_init(self):
		self.name = "Storm Beacon"
		self.tags = [Tags.Lightning]
		self.recipe = [(Tags.Lightning, 2), (Tags.Translocation, 1), (Tags.Any, 2)]

		self.damage = 10
		self.duration = 5

	def get_description(self):
		desc = ["Each turn, summon a random number of [Storm Clouds:lightning] across the level"
				"\nThe [Storm Clouds:lightning] deal [{damage}:damage] damage and last for [{duration}:duration] turns"
				"\nThe maximum number summoned each turn is your [Lightning] mastery"]
		if self.owner: desc.append("\n[Lightning Mastery:lightning]: [{mastery}:lightning]")
		return desc

	def fmt_dict(self):
		d = Equipment.fmt_dict(self)
		d['mastery'] = self.owner.get_mastery(Tags.Lightning) if self.owner else 0
		return d

	def on_advance(self):
		if not self.owner.level.has_hostile_units(): return
		mastery = self.owner.get_mastery(Tags.Lightning)
		if mastery:
			num_cloud_summons = random.randint(0, mastery)
			self.create_storm(num_cloud_summons)
			self.do_ui_flash()

	def create_storm(self, num_cloud_summons):
		tiles = [tile for tile in self.owner.level.iter_tiles() if not tile.cloud and not tile.is_wall() and (tile.x, tile.y) != (self.owner.x, self.owner.y)]

		random.shuffle(tiles)
		dmg = self.get_stat('damage')
		dur = self.get_stat('duration')
		for t in tiles[:num_cloud_summons]:
			tile = tiles.pop()
			cloud = StormCloud(self.owner, damage=dmg, duration=dur)
			self.owner.level.add_obj(cloud, tile.x, tile.y)

class RainBeacon(Equipment):

	def on_init(self):
		self.name = "Rain Beacon"
		self.tags = [Tags.Nature]
		self.recipe = [(Tags.Nature, 2), (Tags.Translocation, 1), (Tags.Any, 2)]
		self.duration = 5

	def get_description(self):
		desc = ["Each turn, summon a random number of [Rain Clouds:nature] across the level"
				"\nThe [Rain Clouds:nature] last for [{duration}:duration] turns"
				"\nThe maximum number summoned each turn is your [Nature] mastery"]
		if self.owner: desc.append("\n[Nature Mastery:nature]: [{mastery}:nature]")
		return desc

	def fmt_dict(self):
		d = Equipment.fmt_dict(self)
		d['mastery'] = self.owner.get_mastery(Tags.Nature) if self.owner else 0
		return d

	def on_advance(self):
		if not self.owner.level.has_hostile_units(): return
		mastery = self.owner.get_mastery(Tags.Nature)
		if mastery:
			num_cloud_summons = random.randint(0, mastery)
			self.create_cloud(num_cloud_summons)
			self.do_ui_flash()

	def create_cloud(self, num_cloud_summons):
		tiles = [tile for tile in self.owner.level.iter_tiles() if not tile.cloud and not tile.is_wall() and (tile.x, tile.y) != (self.owner.x, self.owner.y)]

		random.shuffle(tiles)
		dur = self.get_stat('duration')
		for t in tiles[:num_cloud_summons]:
			tile = tiles.pop()
			cloud = RainCloud(self.owner, duration=dur)
			self.owner.level.add_obj(cloud, tile.x, tile.y)

class AmuletOfUndeath(Equipment):

	def on_init(self):
		self.name = "Amulet of Undeath"
		self.description = "Each turn, [Undead] allies heal [3 HP:heal]"
		self.tags = [Tags.Dark]
		self.recipe = [(Tags.Conjuration, 1), (Tags.Dark, 1), (Tags.Any, 3)]

	def on_advance(self):
		activated = False
		for u in self.owner.level.units:
			if u == self.owner: continue
			if are_hostile(u, self.owner): continue
			if Tags.Undead not in u.tags: continue
			if u.cur_hp >= u.max_hp: continue
			u.deal_damage(-3, Tags.Heal, self)
			if not activated: activated = True
		if activated: self.do_ui_flash()

class VialOfAmbrosia(Equipment):

	def on_init(self):
		self.name = "Vial of Ambrosia"
		self.duration = 10
		self.owner_triggers[EventOnUnitAdded] = self.on_unit_added
		self.tags = [Tags.Enchantment, Tags.Holy]
		self.recipe = [(Tags.Enchantment, 1), (Tags.Holy, 1), (Tags.Any, 3)]

	def get_description(self):
		return "At the beginning of each level, gain [{duration}:duration] turns of Clarity"

	def on_unit_added(self, evt):
		self.owner.apply_buff(StunImmune(), self.get_stat('duration'))
		self.do_ui_flash()

	def get_extra_examine_tooltips(self):
		return [StunImmune()]

class DracoAntiphonyScepter(Equipment):

	def on_init(self):
		self.name = "Draco Antiphony Scepter"
		self.slot = SLOT_WEAPON
		self.owner_triggers[EventOnSpellCast] = self.on_spell
		self.description = "When you cast a level 4 or lower [Sorcery] spell, your [Dragon] allies with matching tags will attempt to cast it"
		self.tags = [Tags.Dragon, Tags.Sorcery]
		self.recipe = [(Tags.Arcane, 1), (Tags.Dragon, 2), (Tags.Sorcery, 2), (Tags.Any, 3)]

	def copy_spell(self, evt):
		if Tags.Sorcery in evt.spell.tags:
			target_point = Point(evt.x, evt.y)
			casters = self.get_dragons(evt, target_point)
			if casters:
				self.do_ui_flash()
				for dragon in casters:
					spell = type(evt.spell)() # create an instance of the class FireBallSpell()
					spell.caster = dragon # assign the caster and the owner to be the dragon
					spell.owner = dragon
					spell.statholder = self.owner # make sure that the spell is the wizard's version of the spell
					if spell.can_cast(evt.x, evt.y): # if they have los or are in range or w/e
						result = self.owner.level.act_cast(dragon, spell, evt.x, evt.y, pay_costs=False, queue=False)
						for _ in result: yield
					elif (evt.x, evt.y) == (self.owner.x, self.owner.y): # for self-cast sorceries like flameburst/stormburst
						result = self.owner.level.act_cast(dragon, spell, dragon.x, dragon.y, pay_costs=False, queue=False)
						for _ in result: yield

	def on_spell(self, evt):
		if evt.spell.level > 4: return
		self.owner.level.queue_spell(self.copy_spell(evt))

	def get_dragons(self, evt, target_point):
		dragon_allies = []
		for unit in self.owner.level.units:
			if are_hostile(self.owner, unit): continue
			if not (Tags.Dragon in unit.tags and any(tag in unit.tags for tag in evt.spell.tags)): continue
			dragon_allies.append(unit)
		return dragon_allies

class AnnihilatorStaff(Equipment):

	def on_init(self):
		self.name = "Annihilator Staff"
		self.slot = SLOT_WEAPON
		self.global_triggers[EventOnPreDamaged] = self.on_damage
		self.damage = 2
		self.tags = [Tags.Chaos, Tags.Sorcery]
		self.recipe = [(Tags.Chaos, 2), (Tags.Sorcery, 2), (Tags.Any, 5)]

	def get_description(self):
		return "Deals [{damage}:damage] [Physical], [Fire], and [Lightning] damage to units before they would be damaged by your [Sorcery] spells"

	def on_damage(self, evt):
		if evt.damage < 1: return
		if evt.unit.resists[evt.damage_type] >= 100: return
		if not isinstance(evt.source, Spell): return
		if evt.source.caster != self.owner and evt.source.statholder != self.owner: return
		if Tags.Sorcery not in evt.source.tags: return

		damage = self.get_stat('damage')
		evt.unit.deal_damage(damage, Tags.Physical, self)
		evt.unit.deal_damage(damage, Tags.Fire, self)
		evt.unit.deal_damage(damage, Tags.Lightning, self)
		self.do_ui_flash()

class ArcaneAmplifier(Equipment):

	def on_init(self):
		self.name = "Arcane Amplifier"
		self.description = "Redeal half the damage you deal with other [Sorcery] spells and equipment as [Arcane] damage"
		self.global_triggers[EventOnDamaged] = self.on_damage
		self.tags = [Tags.Arcane, Tags.Sorcery]
		self.recipe = [(Tags.Arcane, 2), (Tags.Sorcery, 2), (Tags.Any, 3)]

	def on_damage(self, evt):
		if evt.damage < 2: return # less than 2 rounds to 0 anyway
		if isinstance(evt.source, ArcaneAmplifier): return # don't redeal this thing or it's potential dupes
		if Tags.Sorcery not in getattr(evt.source, 'tags', []): return # tag check
		if not evt.source.owner or evt.source.owner != self.owner: return # make sure it's coming from the wizard
		evt.unit.deal_damage(evt.damage // 2, Tags.Arcane, self)
		self.do_ui_flash()

class Flamenweaver(Equipment):

	def on_init(self):
		self.name = "The Flamenweaver"
		self.global_triggers[EventOnDamaged] = self.on_damage
		self.description = "Redeal half the damage you deal with other [Enchantment] spells and equipment as [Fire] damage"
		self.tags = [Tags.Enchantment, Tags.Fire]
		self.recipe = [(Tags.Enchantment, 1), (Tags.Fire, 2), (Tags.Any, 5)]

	def on_damage(self, evt):
		if evt.damage < 2: return # less than 2 rounds to 0 anyway
		if isinstance(evt.source, Flamenweaver): return # dont redeal this thing or it's potential dupes
		if Tags.Enchantment not in getattr(evt.source, 'tags', []): return # tag check
		if not evt.source.owner or evt.source.owner != self.owner: return # make sure it's coming from the wizard
		evt.unit.deal_damage(evt.damage // 2, Tags.Fire, self)
		self.do_ui_flash()

class TreelordStaff(Equipment):

	def on_init(self):
		self.name = "Treelord Staff"
		self.slot = SLOT_WEAPON
		self.description = "When you cast a level 3 or higher [Nature] spell, summon a Treant nearby"
		self.owner_triggers[EventOnSpellCast] = self.on_spell_cast
		self.trigger_tags = [Tags.Nature]
		self.tags = [Tags.Conjuration, Tags.Nature]
		self.recipe = [(Tags.Conjuration, 1), (Tags.Nature, 1), (Tags.Any, 3)]

		self.minion_health = 37
		self.minion_damage = 8

	def on_spell_cast(self, evt):
		if evt.spell.level < 3: return
		if any(t for t in self.trigger_tags if t in evt.spell.tags):
			unit = make_minion(self, Treant)
			self.summon(unit)
			self.do_ui_flash()

	def get_extra_examine_tooltips(self):
		return [make_minion(self, Treant)]

class AetherlordStaff(Equipment):

	def on_init(self):
		self.name = "Aetherlord Staff"
		self.slot = SLOT_WEAPON
		self.description = "When you cast a level 5 or higher [Arcane] spell, summon a Void Elder nearby"
		self.owner_triggers[EventOnSpellCast] = self.on_spell_cast
		self.tags = [Tags.Arcane, Tags.Conjuration]
		self.recipe = [(Tags.Arcane, 2), (Tags.Conjuration, 2), (Tags.Any, 2)]

		self.add_effect_tooltip(self.get_elder)

		self.minion_health = 80
		self.minion_damage = 15

	def on_spell_cast(self, evt):
		if Tags.Arcane not in evt.spell.tags: return
		if evt.spell.level < 5: return
		self.summon(self.get_elder())
		self.do_ui_flash()

	def get_elder(self):
		return make_minion(self, VoidElder)


class FireClawStaff(Equipment):

	def on_init(self):
		self.name = "Flaming Claw Staff"
		self.slot = SLOT_WEAPON
		self.description = "When your allies damage enemies, redeal half the damage dealt as [Fire] damage"
		self.global_triggers[EventOnDamaged] = self.on_damage
		self.tags = [Tags.Conjuration, Tags.Fire]
		self.recipe = [(Tags.Conjuration, 1), (Tags.Fire, 2), (Tags.Nature, 1), (Tags.Any, 3)]

	def on_damage(self, evt):
		if evt.damage < 2: return
		if getattr(evt.source, 'owner', self.owner) == self.owner: return # double work, guards against ownerless and damage from wizard
		if not are_hostile(self.owner, evt.unit): return # care about damage to enemies only
		if are_hostile(evt.source.owner, self.owner) or evt.source.owner.is_player_controlled: return # care about damage from allies only
		self.do_ui_flash()
		self.owner.level.queue_spell(self.deal_dmg(evt.unit, evt.damage//2))

	def deal_dmg(self, u, dmg):
		if u.is_alive(): u.deal_damage(dmg, Tags.Fire, self); yield

class IceClawStaff(Equipment):

	def on_init(self):
		self.name = "Icy Claw Staff"
		self.slot = SLOT_WEAPON
		self.description = "When your allies damage enemies, redeal half the damage dealt as [Ice] damage"
		self.global_triggers[EventOnDamaged] = self.on_damage
		self.tags = [Tags.Conjuration, Tags.Ice]
		self.recipe = [(Tags.Conjuration, 1), (Tags.Ice, 2), (Tags.Nature, 1), (Tags.Any, 3)]

	def on_damage(self, evt):
		if evt.damage < 2: return
		if getattr(evt.source, 'owner', self.owner) == self.owner: return # double work, guards against ownerless and damage from wizard
		if not are_hostile(self.owner, evt.unit): return # care about damage to enemies only
		if are_hostile(evt.source.owner, self.owner) or evt.source.owner.is_player_controlled: return # care about damage from allies only
		self.do_ui_flash()
		self.owner.level.queue_spell(self.deal_dmg(evt.unit, evt.damage // 2))

	def deal_dmg(self, u, dmg):
		if u.is_alive(): u.deal_damage(dmg, Tags.Ice, self); yield

class BootsOfImminentDoom(Equipment):

	def on_init(self):
		self.name = "Boots of Imminent Doom"
		self.slot = SLOT_BOOTS
		self.owner_triggers[EventOnUnitAdded] = self.on_enter
		self.tags = [Tags.Dark]
		self.radius = 6
		self.recipe = [(Tags.Dark, 1), (Tags.Enchantment, 1), (Tags.Translocation, 1), (Tags.Any, 1)]
		self.add_spell_tooltip(SealFate)

	def get_description(self):
		return "At the beginning of each level, cast Seal Fate on enemies within [{radius}:radius] tiles"

	def on_enter(self, evt):
		spell = self.owner.get_or_make_spell(SealFate)
		enemies = [u for u in self.owner.level.get_units_in_ball(self.owner, self.get_stat('radius')) if are_hostile(self.owner, u)]
		for enemy in enemies: self.owner.level.act_cast(self.owner, spell, enemy.x, enemy.y, pay_costs=False)
		if enemies: self.do_ui_flash()


class RodOfHeavensAssault(Equipment):

	def on_init(self):
		self.name = "Rod of Heaven's Assault"
		self.slot = SLOT_WEAPON
		self.description = "At the beginning of each level, cast Heavenly Blast on [Demon] and [Undead] enemies in your line of sight"
		self.owner_triggers[EventOnUnitAdded] = self.on_enter
		self.tags = [Tags.Holy]
		self.recipe = [(Tags.Eye, 1), (Tags.Holy, 1), (Tags.Any, 4)]
		self.add_spell_tooltip(HolyBlast)

	def on_enter(self, evt):
		p = Point(self.owner.x, self.owner.y)
		enemies = [u for u in self.owner.level.get_units_in_los(p) if are_hostile(self.owner, u) and (Tags.Demon in u.tags or Tags.Undead in u.tags)]
		spell = self.owner.get_or_make_spell(HolyBlast)
		for enemy in enemies: self.owner.level.act_cast(self.owner, spell, enemy.x, enemy.y, pay_costs=False)
		if enemies: self.do_ui_flash()

class StaffOfHeavensVengeance(Equipment):

	def on_init(self):
		self.name = "Staff of Heaven's Vengeance"
		self.slot = SLOT_WEAPON
		self.global_triggers[EventOnDamaged] = self.on_damage
		self.damage = 7
		self.tags = [Tags.Holy]
		self.recipe = [(Tags.Holy, 3), (Tags.Any, 5)]

	def get_description(self):
		return "When you or one of your [Living] or [Holy] allies takes damage from an enemy, deal [{damage}:damage] [Holy] damage to that enemy"

	def on_damage(self, evt):
		if are_hostile(self.owner, evt.unit): return
		if not evt.source or not evt.source.owner: return
		if not are_hostile(evt.source.owner, self.owner): return
		if Tags.Living not in evt.unit.tags and Tags.Holy not in evt.unit.tags: return
		self.owner.level.queue_spell(self.vengeance(evt.source.owner)) # queue up the spell

	def vengeance(self, u):
		u.deal_damage(self.get_stat('damage'), Tags.Holy, self) # deal holy damage to the source of damage
		self.do_ui_flash()
		yield

class RingOfMagneticCharisma(Equipment):

	def on_init(self):
		self.name = "Ring of Magnetic Charisma"
		self.description = "At the beginning of each level, turn the nearest enemy Spawner or [Construct] into an ally"
		self.owner_triggers[EventOnUnitAdded] = self.on_enter
		self.tags = [Tags.Enchantment, Tags.Metallic]
		self.recipe = [(Tags.Enchantment, 2), (Tags.Metallic, 2), (Tags.Any, 2)]

	def on_enter(self, evt):
		player = self.owner
		level = player.level
		targets = level.get_units_by_distance(player, enemy=True)
		for u in targets:
			if Tags.Construct in u.tags or u.is_lair:
				level.show_path_effect(player, u, Tags.Physical)
				u.team = player.team
				self.do_ui_flash()
				break

class HallucinogenicSporeStaff(Equipment):

	def on_init(self):
		self.name = "Hallucinogenic Spore Staff"
		self.slot = SLOT_WEAPON
		self.duration = 3
		self.global_triggers[EventOnBuffApply] = self.on_poison
		self.tags = [Tags.Chaos, Tags.Nature]
		self.recipe = [(Tags.Chaos, 2), (Tags.Nature, 2), (Tags.Any, 2)]

	def get_description(self):
		return "When [poison] is inflicted on an unpoisoned enemy, they are [berserked] for [{duration}:duration] turns"

	def on_poison(self, evt):
		if isinstance(evt.buff, Poison):
			if are_hostile(self.owner, evt.unit):
				evt.unit.apply_buff(BerserkBuff(), self.get_stat('duration'))
				self.do_ui_flash()


class AmuletOfEmeraldFlame(Equipment):

	def on_init(self):
		self.name = "Amulet of Emerald Flame"
		self.damage = 10
		self.global_triggers[EventOnDamaged] = self.on_damage
		self.charge = 0
		self.tags = [Tags.Enchantment, Tags.Fire]
		self.recipe = [(Tags.Enchantment, 1), (Tags.Fire, 1), (Tags.Any, 2)]

	def get_description(self):
		return (("For every 50 damage dealt by [Enchantment] spells, the nearest enemy takes [{damage}:damage] [Fire] damage"
				"\nDamage Dealt: {charge}", {'charge':self.charge}))

	def on_damage(self, evt):
		if not evt.source: return
		if evt.source == self: return # quick out from own damage
		if not isinstance(evt.source, Spell): return
		if Tags.Enchantment not in evt.source.tags: return
		if evt.damage < 1: return
		self.charge += evt.damage
		dmg = self.get_stat('damage')
		player = self.owner
		level = player.level
		if self.charge < 50: return
		self.do_ui_flash()
		while self.charge >= 50:
			self.charge -= 50
			targets = level.get_units_by_distance(player, enemy=True)
			if not targets: return
			level.show_path_effect(player, targets[0], Tags.Fire)
			targets[0].deal_damage(dmg, Tags.Fire, self)

class MonkeySkull(Equipment): # make this into a 1 for 1 component also?

	def on_init(self):
		self.name = "Monkey Skull Amulet"
		self.tags = [Tags.Conjuration, Tags.Enchantment, Tags.Sorcery]
		self.tag_bonuses[Tags.Sorcery]['duration'] = 3
		self.tag_bonuses[Tags.Conjuration]['radius'] = 1
		self.tag_bonuses[Tags.Enchantment]['minion_damage'] = 6
		self.recipe = [(Tags.Conjuration, 1), (Tags.Dark, 1), (Tags.Enchantment, 1), (Tags.Sorcery, 1), (Tags.Any, 1)]

class CannibalMask(Equipment):

	def on_init(self):
		self.name = "Cannibal Mask"
		self.slot = SLOT_HELMET
		self.global_triggers[EventOnDeath] = self.on_death
		self.tags = [Tags.Blood]
		self.recipe = [(Tags.Blood, 3), (Tags.Any, 4)]

	def get_description(self):
		return  "When your allies die, another ally gains half the dead unit's max HP"

	def on_death(self, evt):
		if are_hostile(evt.unit, self.owner): return
		heal_targets = [u for u in self.owner.level.units if are_friendly(self.owner, u) and u.is_alive() and not u.is_player_controlled]
		if not heal_targets: return

		heal = evt.unit.max_hp // 2
		if not heal: return

		self.do_ui_flash()
		target = random.choice(heal_targets)
		target.max_hp += heal
		target.heal(heal, self)
		self.owner.level.show_path_effect(target, evt.unit, Tags.Blood, minor=True)

class FreeCastStaff(Equipment):

	def __init__(self, name, tag, counter_max, free_spell_class):
		
		self.tag = tag
		self.trigger_tags = [tag]
		self.counter_max = counter_max
		Equipment.__init__(self, name, tag, counter_max, free_spell_class)
		self.name = name
		self.slot = SLOT_WEAPON
		self.counter = 0
		self.free_spell_class = free_spell_class
		self.spell_name = free_spell_class().name
		self.add_spell_tooltip(free_spell_class)

		self.recipe = []
		self.tags = free_spell_class().tags + [tag]
		for tag in self.tags: self.recipe.append((tag, 2))
		num_any = 10 - 2 * len(self.tags)
		if num_any > 0: self.recipe.append((Tags.Any, num_any))

		self.global_triggers[EventOnLevelComplete] = self.on_complete

	def get_description(self):
		return ("For every {val} damage dealt to enemies by [{tag}:{tag_key}] spells or equipment, cast {spell} on a random enemy"
				"\nDamage Dealt: {dealt}", {"val": self.counter_max, "tag": self.tag.name, "tag_key": tag_key(self.tag), "spell": self.spell_name, "dealt": self.counter})

	def on_init(self):
		self.global_triggers[EventOnDamaged] = self.on_damage

	def on_complete(self, evt):
		self.counter = 0

	def on_damage(self, evt):
		if not are_hostile(self.owner, evt.unit): return
		if not evt.source: return
		if not (isinstance(evt.source, Equipment) or isinstance(evt.source, Spell)): return
		if not any(t for t in self.trigger_tags if t in evt.source.tags): return
		if evt.damage < 1: return
		self.counter += evt.damage
		if self.counter >= self.counter_max:
			self.owner.level.queue_spell(self.do_freecast(evt))
			self.do_ui_flash()

	# Queue this so that in the highly likely event that the spell kills its target the freecast isnt wasted
	def do_freecast(self, evt):
		while self.counter >= self.counter_max:
			targets = [u for u in self.owner.level.units if are_hostile(self.owner, u) and u.is_alive()]
			if not targets: return
			self.counter -= self.counter_max
			target = random.choice(targets)
			s = self.owner.get_or_make_spell(self.free_spell_class)
			for _ in self.owner.level.act_cast(self.owner, s, target.x, target.y, pay_costs=False, queue=False): yield
			yield
		yield

class BlazingWand(Equipment):

	def on_init(self):
		self.name = "Blazing Wand"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Fire]
		self.recipe = [(Tags.Fire, 2), (Tags.Any, 2)]

		self.tag_bonuses[Tags.Fire]['damage'] = 7
		self.tag_bonuses[Tags.Fire]['max_charges'] = 2

class AshenRod(Equipment):

	def on_init(self):
		self.name = "Ashen Rod"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Fire, Tags.Nature]
		self.recipe = [(Tags.Fire, 1), (Tags.Nature, 1), (Tags.Any, 2)]

		self.tag_bonuses[Tags.Fire]['radius'] = 1
		self.tag_bonuses_pct[Tags.Nature]['duration'] = 100

class SnowStaff(Equipment):

	def on_init(self):
		self.name = "Snow Staff"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Ice]
		self.recipe = [(Tags.Ice, 2), (Tags.Any, 2)]

		self.tag_bonuses[Tags.Ice]['max_charges'] = 1
		self.tag_bonuses[Tags.Ice]['damage'] = 5
		self.tag_bonuses[Tags.Ice]['duration'] = 3

class SanguineFrostWand(Equipment):

	def on_init(self):
		self.name = "Sanguine Frost Wand"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Blood, Tags.Ice]
		self.recipe = [(Tags.Blood, 2), (Tags.Ice, 1), (Tags.Any, 3)]
		self.owner_triggers[EventOnSpendHP] = self.on_spend
		self.chance = 0

	def on_spend(self, evt):
		self.chance += evt.hp
		if random.random() <= (self.chance / 100):
			self.chance = 0
			opts = [s for s in self.owner.spells if Tags.Ice in s.tags and s.cur_charges < s.get_stat('max_charges')]
			if opts:
				s = random.choice(opts)
				s.refund_charges(1)
				s.do_ui_flash(Tags.Blood)
				self.do_ui_flash()


	def get_description(self):
		return (("When you spend HP, there is a chance to regain a charge of a random [Ice] spell"
				"\nThe chance is equal to the HP spent"
				"\nIf this fails to reward a charge, the chance accumulates until it succeeds"
				"\n[Accumulated Chance:blood]: [{val}%:blood]"), {'val':self.chance})


class ColdIronHeart(Equipment):

	def on_init(self):
		self.name = "Cold Iron Heart"
		self.tags = [Tags.Blood, Tags.Ice,Tags.Metallic]
		self.recipe = [(Tags.Blood, 1), (Tags.Ice, 1), (Tags.Metallic, 1), (Tags.Any, 1)]
		self.resists[Tags.Ice] = 25
		self.resists[Tags.Poison] = 25
		self.owner_triggers[EventOnBuffApply] = self.on_buffed

	def get_description(self):
		return "You are immune to [fear]"

	def on_equip(self, unit):
		unit.remove_buffs(FearBuff)

	def on_buffed(self, evt):
		if isinstance(evt.buff, FearBuff):
			evt.unit.remove_buffs(FearBuff)


class SunforgedIris(Equipment):

	def on_init(self):
		self.name = "Sunforged Iris"
		self.tags = [Tags.Eye, Tags.Holy, Tags.Metallic]
		self.recipe = [(Tags.Eye, 1), (Tags.Holy, 1), (Tags.Metallic, 1), (Tags.Any, 1)]
		self.resists[Tags.Holy] = 25
		self.resists[Tags.Fire] = 25
		self.owner_triggers[EventOnBuffApply] = self.on_buffed

	def get_description(self):
		return "You are immune to [blind]"

	def on_equip(self, unit):
		unit.remove_buffs(BlindBuff)

	def on_buffed(self, evt):
		if isinstance(evt.buff, BlindBuff):
			evt.unit.remove_buffs(BlindBuff)


class RunespeakersGorget(Equipment):

	def on_init(self):
		self.name = "Runespeaker's Gorget"
		self.tags = [Tags.Word, Tags.Arcane, Tags.Metallic]
		self.recipe = [(Tags.Arcane, 1), (Tags.Metallic, 1), (Tags.Word, 1), (Tags.Any, 1)]
		self.resists[Tags.Arcane] = 25
		self.resists[Tags.Physical] = 25
		self.owner_triggers[EventOnBuffApply] = self.on_buffed

	def get_description(self):
		return "You are immune to [silence]"

	def on_equip(self, unit):
		unit.remove_buffs(Silence)

	def on_buffed(self, evt):
		if isinstance(evt.buff, Silence):
			evt.unit.remove_buffs(Silence)

class MoltenCarapace(Equipment):

	def on_init(self):
		self.name = "Molten Carapace"
		self.tags = [Tags.Blood, Tags.Fire, Tags.Metallic]
		self.recipe = [(Tags.Blood, 1), (Tags.Fire, 1), (Tags.Metallic, 1), (Tags.Any, 1)]
		self.resists[Tags.Ice] = 25
		self.resists[Tags.Fire] = 25
		self.owner_triggers[EventOnBuffApply] = self.on_buffed

	def get_description(self):
		return "You are immune to [freeze]"

	def on_equip(self, unit):
		unit.remove_buffs(FrozenBuff)

	def on_buffed(self, evt):
		if isinstance(evt.buff, FrozenBuff):
			evt.unit.remove_buffs(FrozenBuff)

class IceCallerStaff(Equipment):

	def on_init(self):
		self.name = "Ice Caller Staff"
		self.slot = SLOT_WEAPON

		self.tags = [Tags.Ice]
		self.recipe = [(Tags.Ice, 1), (Tags.Any, 3)]

		self.tag_bonuses[Tags.Ice]['max_charges'] = 1
		self.tag_bonuses_pct[Tags.Ice]['minion_health'] = 50
		self.tag_bonuses_pct[Tags.Ice]['minion_duration'] = 50
		self.tag_bonuses[Tags.Ice]['minion_range'] =1

class CrystalDagger(Equipment):

	def on_init(self):
		self.name = "Crystal Dagger"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Arcane, Tags.Ice]
		self.recipe = [(Tags.Arcane, 1), (Tags.Ice, 1), (Tags.Any, 2)]

		for tag in self.tags:
			self.tag_bonuses[tag]['damage'] = 3

class LightningStaff(Equipment):

	def on_init(self):
		self.name = "Lightning Staff"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Lightning]
		self.recipe = [(Tags.Lightning, 2), (Tags.Any, 2)]

		self.tag_bonuses[Tags.Lightning]['damage'] = 7
		self.tag_bonuses[Tags.Lightning]['minion_damage'] = 4
		self.tag_bonuses[Tags.Lightning]['max_charges'] = 1

class StormWand(Equipment):

	def on_init(self):
		self.name = "Storm Wand"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Lightning]
		self.recipe = [(Tags.Lightning, 1), (Tags.Any, 3)]

		self.tag_bonuses[Tags.Lightning]['range'] = 2
		self.tag_bonuses[Tags.Lightning]['num_targets'] = 2

class NatureStaff(Equipment):

	def on_init(self):
		self.name = "Nature Staff"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Nature]
		self.recipe = [(Tags.Nature, 2), (Tags.Any, 2)]

		self.tag_bonuses_pct[Tags.Nature]['max_charges'] = 50
		self.tag_bonuses_pct[Tags.Nature]['minion_damage'] = 50
		self.tag_bonuses_pct[Tags.Nature]['minion_health'] = 50

class BloomingWand(Equipment):

	def on_init(self):
		self.name = "Blooming Wand"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Nature]
		self.recipe = [(Tags.Nature, 2), (Tags.Any, 2)]

		self.tag_bonuses[Tags.Nature]['damage'] = 4
		self.tag_bonuses[Tags.Nature]['num_targets'] = 1
		self.tag_bonuses[Tags.Nature]['radius'] = 1

class VileDagger(Equipment):

	def on_init(self):
		self.name = "Vile Dagger"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Dark, Tags.Nature]
		self.recipe = [(Tags.Dark, 1), (Tags.Nature, 1), (Tags.Any, 2)]

		for tag in self.tags:
			self.tag_bonuses[tag]['damage'] = 3


class DarkStaff(Equipment):

	def on_init(self):
		self.name = "Dark Staff"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Dark]
		self.recipe = [(Tags.Dark, 1), (Tags.Any, 3)]

		self.tag_bonuses[Tags.Dark]['range'] = 2
		self.tag_bonuses[Tags.Dark]['radius'] = 1
		self.tag_bonuses[Tags.Dark]['max_charges'] = 1

class UmbralTotem(Equipment):

	def on_init(self):
		self.name = "Umbral Totem"
		self.tags = [Tags.Dark]
		self.recipe = [(Tags.Dark, 2), (Tags.Any, 2)]

		self.tag_bonuses_pct[Tags.Dark]['damage'] = 50
		self.tag_bonuses_pct[Tags.Dark]['duration'] = 50

class NecromancersStaff(Equipment):

	def on_init(self):
		self.name = "Necromancer's Staff"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Dark]
		self.recipe = [(Tags.Conjuration, 2), (Tags.Dark, 2), (Tags.Any, 6)]

		self.tag_bonuses_pct[Tags.Dark]['max_charges'] = 100
		self.tag_bonuses_pct[Tags.Dark]['minion_health'] = 100
		self.tag_bonuses_pct[Tags.Dark]['minion_damage'] = 100

class ArchSorcerersStaff(Equipment):

	def on_init(self):
		self.name = "Arch Sorcerer's Staff"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Sorcery]
		self.recipe = [(Tags.Sorcery, 3), (Tags.Any, 7)]

		self.tag_bonuses[Tags.Sorcery]['damage'] = 7
		self.tag_bonuses[Tags.Sorcery]['range'] = 2
		self.tag_bonuses_pct[Tags.Sorcery]['max_charges'] = 25


class HolyStaff(Equipment):

	def on_init(self):
		self.name = "Holy Staff"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Holy]
		self.recipe = [(Tags.Holy, 1), (Tags.Any, 3)]

		self.tag_bonuses[Tags.Holy]['max_charges'] = 1
		self.tag_bonuses[Tags.Holy]['radius'] = 1
		self.tag_bonuses[Tags.Holy]['minion_range'] = 1
		self.tag_bonuses_pct[Tags.Holy]['minion_duration'] = 50

class SacrificialDagger(Equipment):

	def on_init(self):
		self.name = "Sacrificial Dagger"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Blood, Tags.Holy]
		self.recipe = [(Tags.Blood, 1), (Tags.Holy, 1), (Tags.Any, 2)]

		for tag in self.tags:
			self.tag_bonuses[tag]['damage'] = 3

class ArcaneStaff(Equipment):

	def on_init(self):
		self.name = "Arcane Staff"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Arcane]
		self.recipe = [(Tags.Arcane, 2), (Tags.Any, 2)]

		self.tag_bonuses[Tags.Arcane]['max_charges'] = 2
		self.tag_bonuses[Tags.Arcane]['damage'] = 6
		self.tag_bonuses[Tags.Arcane]['minion_damage'] = 6

class RunicHourglass(Equipment):

	def on_init(self):
		self.name = "Runic Hourglass"
		self.tags = [Tags.Arcane, Tags.Enchantment]
		self.recipe = [(Tags.Arcane, 1), (Tags.Enchantment, 1), (Tags.Any, 2)]
		self.tag_bonuses_pct[Tags.Arcane]['duration'] = 50
		self.tag_bonuses_pct[Tags.Arcane]['minion_duration'] = 50


class SorceryStaff(Equipment):

	def on_init(self):
		self.name = "Sorcery Staff"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Sorcery]
		self.recipe = [(Tags.Sorcery, 1), (Tags.Any, 3)]

		self.tag_bonuses_pct[Tags.Sorcery]['damage'] = 33
		self.tag_bonuses[Tags.Sorcery]['range'] = 1
		self.tag_bonuses[Tags.Sorcery]['max_charges'] = 1

class BattlemageStaff(Equipment):

	def on_init(self):
		self.name = "Battlemage Staff"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Sorcery]
		self.recipe = [(Tags.Eye, 1), (Tags.Sorcery, 1), (Tags.Any, 2)]

		self.tag_bonuses[Tags.Sorcery]['radius'] = 1
		self.tag_bonuses[Tags.Sorcery]['num_targets'] = 1

class ConjurationStaff(Equipment):

	def on_init(self):
		self.name = "Conjuration Staff"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Conjuration]
		self.recipe = [(Tags.Conjuration, 2), (Tags.Any, 2)]

		self.tag_bonuses_pct[Tags.Conjuration]['minion_damage'] = 50
		self.tag_bonuses_pct[Tags.Conjuration]['minion_health'] = 50

class ShepherdsStaff(Equipment):

	def on_init(self):
		self.name = "Shepherd's Staff"
		self.slot = SLOT_WEAPON
		self.tags =[Tags.Conjuration]
		self.recipe = [(Tags.Conjuration, 1), (Tags.Any, 3)]

		self.tag_bonuses[Tags.Conjuration]['num_summons'] = 1
		self.tag_bonuses[Tags.Conjuration]['minion_range'] = 1
		self.tag_bonuses_pct[Tags.Conjuration]['minion_duration'] = 50


class EnchantmentStaff(Equipment):

	def on_init(self):
		self.name = "Enchantment Staff"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Enchantment]
		self.recipe = [(Tags.Enchantment, 1), (Tags.Any, 3)]

		self.tag_bonuses[Tags.Enchantment]['duration'] = 3
		self.tag_bonuses[Tags.Enchantment]['max_charges'] = 2

class SlipperyHexDagger(Equipment):

	def on_init(self):
		self.name = "Slippery Hex Dagger"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Enchantment, Tags.Slime]
		self.recipe = [(Tags.Enchantment, 1), (Tags.Slime, 1), (Tags.Any, 2)]

		for tag in self.tags:
			self.tag_bonuses[tag]['damage'] = 3

class RainbowBlade(Equipment):

	def on_init(self):
		self.name = "Rainbow Blade"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Fire, Tags.Chaos, Tags.Lightning, Tags.Nature, Tags.Ice, Tags.Ritual, Tags.Translocation]
		self.recipe = []

		for tag in self.tags:
			self.tag_bonuses[tag]['damage'] = 6
			self.recipe.append((tag, 1))

class EntropicWand(Equipment):

	def on_init(self):
		self.name = "Entropic Wand"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Chaos]
		self.recipe = [(Tags.Chaos, 1), (Tags.Any, 3)]

		stats = ['num_targets',
				 'damage',
				 'range',
				 'duration']

		for stat in stats:
			self.tag_bonuses_pct[Tags.Chaos][stat] = 33

class ChaosStaff(Equipment):

	def on_init(self):
		self.name = "Chaos Staff"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Chaos]
		self.recipe = [(Tags.Chaos, 1), (Tags.Any, 3)]

		stats = ['max_charges',
				 'num_summons',
				 'minion_damage',
				 'minion_range']

		for stat in stats:
			self.tag_bonuses_pct[Tags.Chaos][stat] = 33

class SlimeStaff(Equipment):

	def on_init(self):
		self.name = "Slime Staff"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Slime]
		self.recipe = [(Tags.Slime, 1), (Tags.Any, 3)]

		self.tag_bonuses[Tags.Slime]['max_charges'] = 3
		self.tag_bonuses[Tags.Slime]['range'] = 3

class OozeWand(Equipment):

	def on_init(self):
		self.name = "Ooze Wand"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Slime]
		self.recipe = [(Tags.Slime, 2), (Tags.Any, 2)]

		self.tag_bonuses_pct[Tags.Slime]['minion_health'] = 100
		self.tag_bonuses_pct[Tags.Slime]['minion_range'] = 100

class SpellBook(Equipment):

	def __init__(self, name, spell):
		Equipment.__init__(self)
		self.spell = spell()
		self.name = name
		self.recipe = []
		self.tags = self.spell.tags
		for tag in self.tags: self.recipe.append((tag, 1))
		self.recipe.append((Tags.Word, 1))
		num_any = 8 - len(self.tags)
		self.recipe.append((Tags.Any, num_any))

	def get_description(self):
		return (("Teaches you the forbidden spell {name}\n"
				"Removing this equipment or its spell also removes the other", {'name':self.spell.name}))

	def get_extra_examine_tooltips(self):
		return [self.spell] + self.spell.get_extra_examine_tooltips()

	def on_equip(self, owner):
		owner.add_spell(self.spell)

	def on_unequip(self, owner):
		if any(isinstance(item, SpellBook) and item.spell.name == self.spell.name for item in owner.equipment): return
		spell_upgrades = [b for b in owner.buffs if b.buff_type == BUFF_TYPE_PASSIVE and type(b.prereq) == type(self.spell)]
		if spell_upgrades:
			for spell_upgrade in spell_upgrades:
				owner.remove_buff(spell_upgrade)
		owner.remove_spell(self.spell)

	def on_remove_spell(self, spell):
		if spell == self.spell: self.owner.unequip(self)

class BookOfRevelation(SpellBook):

	def __init__(self):
		SpellBook.__init__(self, "Book of Revelation", RitualOfRevelation)

class BookOfFourSeals(SpellBook):

	def __init__(self):
		SpellBook.__init__(self, "Book of Four Seals", SummonRider)
		self.recipe = [(Tags.Dark, 2), (Tags.Holy, 2), (Tags.Word, 2), (Tags.Any, 2)]

class BookOfIce(SpellBook):

	def __init__(self):
		SpellBook.__init__(self, "Book of Ice", WordOfIce)
		self.recipe = [(Tags.Ice, 2), (Tags.Word, 2), (Tags.Any, 6)]

class BookOfMadness(SpellBook):

	def __init__(self):
		SpellBook.__init__(self, "Book of Madness", WordOfMadness)


class BookOfChaos(SpellBook):

	def __init__(self):
		SpellBook.__init__(self, "Book of Chaos", WordOfChaos)


class BookOfDeath(SpellBook):

	def __init__(self):
		SpellBook.__init__(self, "Book of Death", WordOfUndeath)

class BookOfCurses(SpellBook):

	def __init__(self):
		SpellBook.__init__(self, "Book of Curses", LitanyOfCurses)

class BookOfLife(SpellBook):

	def __init__(self):
		SpellBook.__init__(self, "Book of Life", WordOfBeauty)

class BookOfMalevolence(SpellBook):

	def __init__(self):
		SpellBook.__init__(self, "Book of Malevolence", ChannelMalevolence)

class BookOfHelheim(SpellBook):

	def __init__(self):
		SpellBook.__init__(self, "Book of Helheim", HelgateSpell)

# class SummonOnDeathStaff(Equipment):
#
# 	def __init__(self, monster, name, monster_name=None, duration=None):
# 		self.monster = monster
# 		self.monster_name = monster_name
# 		Equipment.__init__(self, monster, name, monster_name, duration)
# 		self.name = name
# 		self.slot = SLOT_WEAPON
# 		self.duration = duration
#
# 		if self.duration:
# 			self.description += " for %d turns" % self.duration
#
# 	def on_init(self):
# 		self.global_triggers[EventOnDeath] = self.on_death
#
# 		monster_name = self.monster_name if self.monster_name else self.monster().name
# 		self.description = "When an enemy dies, summon a %s where it was" % monster_name
#
#
# 	def on_death(self, evt):
# 		if not are_hostile(self.owner, evt.unit): return
#
# 		# Do not raise temporary summons
# 		if evt.unit.turns_to_death is not None: return
#
# 		self.owner.level.queue_spell(self.do_summon(evt))
# 		self.do_ui_flash()
#
# 	def do_summon(self, evt):
# 		unit = self.monster()
# 		if self.duration: unit.turns_to_death = self.duration
# 		apply_minion_bonuses(self, unit)
# 		self.summon(unit, target=evt.unit)
# 		yield
#
# 	def get_extra_examine_tooltips(self):
# 		return [self.monster()]

class RiftKeyStaff(Equipment):

	def on_init(self):
		self.name = "Rift Key Staff"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Translocation]
		self.recipe = [(Tags.Arcane, 1), (Tags.Translocation, 2), (Tags.Any, 2)]
		self.global_triggers[EventOnLevelComplete] = self.on_complete

	def get_description(self):
		return 	"Create an additional Rift upon level victory"

	def on_complete(self, _level):
		num_gates = 1

		candidate_tiles = [t for t in self.owner.level.iter_tiles() if not t.prop and t.can_walk]
		random.shuffle(candidate_tiles)

		created = 0
		for t in candidate_tiles:
			path = self.owner.level.find_path(self.owner, Point(t.x, t.y), self.owner, pythonize=True, unit_penalty=0)
			if not path: continue  # if no way to for the wizard to walk there, try again
			self.owner.level.add_portal(Portal(self.owner.level.gen_params.make_child_generator()), t.x, t.y, locked=False)
			created += 1
			self.do_ui_flash()
			if created >= num_gates: break

	def on_equip(self, owner):
		if not owner.is_player_controlled: return
		if owner.game.level_cleared: self.on_complete(owner.level)

class HelmOfTheHost(Equipment):

	def on_init(self):
		self.name = "Helm of the Host"
		self.slot = SLOT_HELMET
		self.owner_triggers[EventOnUnitAdded] = self.on_added
		self.global_triggers[EventOnDamaged] = self.on_damage
		self.counter = 0
		self.tags = [Tags.Conjuration]
		self.recipe = [(Tags.Conjuration, 2), (Tags.Holy, 2), (Tags.Any, 3)]

	def get_description(self):
		return (("Each turn, your allies heal for 1% of the total damage dealt by your allies this level\n"
				"Damage Dealt: {val}\n"
				 "HP / turn: {heal}", {'val':self.counter, 'heal':self.counter//100}))

	def on_damage(self, evt):
		if not evt.source: return
		if not evt.source.owner: return
		if evt.damage <= 0: return
		if evt.source.owner == self.owner: return
		if are_hostile(self.owner, evt.source.owner): return
		self.counter += evt.damage

	def on_added(self, evt):
		self.counter = 0

	def on_advance(self):

		heal = self.counter // 100

		if heal:
			self.do_ui_flash()
			for u in self.owner.level.units:
				if are_hostile(self.owner, u): continue
				if u == self.owner: continue
				u.heal(heal, self)

class ScepterOfSorrows(Equipment):

	def on_init(self):
		self.name = "Scepter of Sorrows"
		self.slot = SLOT_WEAPON
		self.global_triggers[EventOnDamaged] = self.on_damaged
		self.ice_victims = set()
		self.dark_victims = set()
		self.blackice_victims = set()

		self.tags = [Tags.Conjuration, Tags.Dark, Tags.Ice]
		self.recipe = [(Tags.Conjuration, 1), (Tags.Dark, 1), (Tags.Ice, 1), (Tags.Any, 4)]

		self.minion_health = 4
		self.minion_damage = 7
		self.minion_range = 3
		self.minion_duration = 10

	def get_description(self):
		return "When an enemy takes [Dark] and [Ice] damage in the same turn, summon a temporary Sorrow Spirit near that enemy"

	def on_pre_advance(self):
		self.ice_victims.clear()
		self.dark_victims.clear()
		self.blackice_victims.clear()

	def on_damaged(self, evt):
		if evt.damage_type not in [Tags.Ice, Tags.Dark]: return
		if evt.unit in self.blackice_victims: return
		if not are_hostile(self.owner, evt.unit): return
		if evt.damage_type == Tags.Ice:
			self.ice_victims.add(evt.unit)
			if evt.unit in self.dark_victims:
				self.blackice_victims.add(evt.unit)
				self.owner.level.queue_spell(self.do_summon(evt.unit))
			
		if evt.damage_type == Tags.Dark:
			self.dark_victims.add(evt.unit)
			if evt.unit in self.ice_victims:
				self.blackice_victims.add(evt.unit)
				self.owner.level.queue_spell(self.do_summon(evt.unit))

	def monster(self):
		ghost = Ghost()
		ghost.max_hp = self.get_stat('minion_health')
		ghost.spells[0] = SimpleRangedAttack(damage=self.get_stat('minion_damage'), range=self.get_stat('minion_range'), damage_type=Tags.Ice)
		ghost.name = "Sorrow Spirit"
		ghost.asset_name = "ghost_sorrow"
		ghost.resists[Tags.Ice] = 100
		return ghost

	def do_summon(self,u):
		self.do_ui_flash()
		ghost = self.monster()
		ghost.turns_to_death = self.get_stat('minion_duration')
		self.summon(ghost, target=u)
		yield

	def get_extra_examine_tooltips(self):
		return [self.monster()]


class GhostfireScepter(Equipment):

	def on_init(self):
		self.color = Tags.Dark.color
		self.name = "Ghostfire Scepter"
		self.slot = SLOT_WEAPON
		self.global_triggers[EventOnDamaged] = self.on_damaged
		self.tags = [Tags.Conjuration, Tags.Dark, Tags.Fire]

		self.fire_victims = set()
		self.dark_victims = set()
		self.blackfire_victims = set()

		self.tags = [Tags.Conjuration, Tags.Dark, Tags.Fire]
		self.recipe = [(Tags.Conjuration, 1), (Tags.Dark, 1), (Tags.Fire, 1), (Tags.Any, 4)]

		self.minion_health = 4
		self.minion_damage = 7
		self.minion_range = 3
		self.minion_duration = 10

	def get_extra_examine_tooltips(self):
		return [self.make_ghost()]

	def on_pre_advance(self):
		self.fire_victims.clear()
		self.dark_victims.clear()
		self.blackfire_victims.clear()

	def on_damaged(self, evt):
		if evt.damage_type not in [Tags.Fire, Tags.Dark]: return
		if evt.unit in self.blackfire_victims: return
		if not are_hostile(self.owner, evt.unit): return

		if evt.damage_type == Tags.Fire:
			self.fire_victims.add(evt.unit)
			if evt.unit in self.dark_victims:
				self.blackfire_victims.add(evt.unit)
				self.owner.level.queue_spell(self.do_summon(evt.unit))

		if evt.damage_type == Tags.Dark:
			self.dark_victims.add(evt.unit)
			if evt.unit in self.fire_victims:
				self.blackfire_victims.add(evt.unit)
				self.owner.level.queue_spell(self.do_summon(evt.unit))

	def make_ghost(self):
		ghost = Ghost()
		ghost.tags.append(Tags.Fire)
		ghost.max_hp = self.get_stat('minion_health')
		ghost.spells[0] = SimpleRangedAttack(damage=self.get_stat('minion_damage'), range=self.get_stat('minion_range'),damage_type=Tags.Fire)
		ghost.name = "Burning Ghost"
		ghost.asset_name = "fire_ghost"
		ghost.resists[Tags.Fire] = 100
		return ghost

	def do_summon(self, u):
		ghost = self.make_ghost()
		ghost.turns_to_death = self.get_stat('minion_duration')
		self.summon(ghost, target=u)
		self.do_ui_flash()
		yield

	def get_description(self):
		return "When an enemy takes [Dark] and [Fire] damage in the same turn, summon a temporary Burning Ghost near that enemy"

class MaskOfIcyChill(Equipment):

	def on_init(self):
		self.name = "Icy Chill Mask"
		self.slot = SLOT_HELMET
		self.damage = 1
		self.owner_triggers[EventOnSpellCast] = self.on_cast
		self.tags = [Tags.Eye, Tags.Ice]
		self.recipe = [(Tags.Eye, 1), (Tags.Ice, 2), (Tags.Any, 6)]

	def get_description(self):
		return "When you cast an [Ice] spell, deal [{damage}:damage] [Ice] damage to enemies in line of sight of the target"

	def on_cast(self, evt):
		if Tags.Ice in evt.spell.tags:
			dmg = self.get_stat('damage')
			self.do_ui_flash()
			for u in self.owner.level.get_units_in_los(Point(evt.x, evt.y)):
				if not self.owner.level.are_hostile(u, self.owner): continue
				u.deal_damage(dmg, Tags.Ice, self)

class StoneMask(Equipment):

	def on_init(self):
		self.name = "Stone Mask"
		self.slot = SLOT_HELMET
		self.duration = 10
		self.resists[Tags.Physical] = 25
		self.tags = [Tags.Arcane, Tags.Enchantment, Tags.Eye]
		self.recipe = [(Tags.Arcane, 1), (Tags.Enchantment, 1), (Tags.Eye, 1), (Tags.Any, 1)]

	def get_description(self):
		return "Each turn, [petrify] an enemy in your line of sight for [{duration}:duration] turns"

	def on_advance(self):
		candidates = [u for u in self.owner.level.get_units_in_los(self.owner) if are_hostile(self.owner, u) and not u.has_buff(PetrifyBuff)]
		if not candidates: return
		random.choice(candidates).apply_buff(PetrifyBuff(), self.get_stat('duration'))
		self.do_ui_flash()

class EyeHelm(Equipment):

	def on_init(self):
		self.name = "Eye Helm"
		self.slot = SLOT_HELMET
		self.owner_triggers[EventOnSpellCast] = self.on_cast
		self.tags = [Tags.Arcane, Tags.Eye]
		self.recipe = [(Tags.Arcane, 1), (Tags.Eye, 1), (Tags.Metallic, 1), (Tags.Any, 1)]

	def get_description(self):
		return "When you cast an [Eye] spell, gain [3 SH:shields], up to a max of 20"

	def on_cast(self, evt):
		if Tags.Eye in evt.spell.tags:
			self.owner.add_shields(3)
			self.do_ui_flash()

class TalkingHat(Equipment):

	def on_init(self):
		self.name = "Talking Hat"
		self.slot = SLOT_HELMET
		self.description = "Your [Enchantment] spells gain quickcast"
		self.buff_type = BUFF_TYPE_BLESS
		self.tag_bonuses[Tags.Enchantment]['quick_cast'] = 1
		self.tags = [Tags.Enchantment]
		self.recipe = [(Tags.Enchantment, 3), (Tags.Any, 5)]

class GenericFrenzyStack(Buff):

	def __init__(self, tag, damage):
		Buff.__init__(self)
		self.name = "%s Frenzy" % tag.name
		self.color = tag.color
		self.stack_type = STACK_INTENSITY
		self.tag_bonuses[tag]['damage'] = damage

class GenericFrenzyMask(Equipment):

	def __init__(self, tag):
		self.tag = tag
		self.tag_preword = 'a' if tag == Tags.Fire else 'an'
		Equipment.__init__(self, tag)
		self.slot = SLOT_HELMET
		self.tags = [tag]
		self.recipe = [(tag, 2), (Tags.Any, 4)]

	def on_init(self):
		self.name = "%s Frenzy Mask" % self.tag.name
		self.owner_triggers[EventOnSpellCast] = self.on_spell_cast
		self.bonus = 2
		self.duration = 6
		self.add_effect_tooltip(lambda: GenericFrenzyStack(self.tag, self.bonus))

	def get_description(self):
		return ("When you cast {aan} [{tag_label}:{tag_key}] spell, "
				"your [{tag_label}:{tag_key}] spells and equipment gain [{bonus} damage:damage] for [{duration}:duration] turns",
				{"aan":self.tag_preword, "tag_label":tag_label(self.tag), "tag_key":tag_key(self.tag), "bonus":self.bonus, "duration":self.get_stat('duration')})


	def on_spell_cast(self, evt):
		if self.tag in evt.spell.tags:
			self.owner.apply_buff(GenericFrenzyStack(self.tag, self.bonus), duration=self.get_stat('duration'))
			self.do_ui_flash()

class QuillStaff(Equipment):

	def on_init(self):
		self.name = "Quill Staff"
		self.slot = SLOT_WEAPON
		self.damage = 8
		self.global_triggers[EventOnDamaged] = self.on_damage
		self.tags = [Tags.Nature]
		self.recipe = [(Tags.Conjuration, 1), (Tags.Eye, 1), (Tags.Metallic, 1), (Tags.Nature, 2), (Tags.Any, 3)]

	def get_description(self):
		return "When one of your [Living] allies damages an enemy in your line of sight, deal [{damage}:damage] [Physical] damage to that enemy"

	def on_damage(self, evt):
		if not evt.source or not evt.source.owner: return
		if evt.source.owner == self.owner or evt.source.owner.is_player_controlled: return
		if Tags.Living not in evt.source.owner.tags: return
		if are_hostile(self.owner, evt.source.owner): return
		if not are_hostile(self.owner, evt.unit): return
		if not self.owner.level.can_see(self.owner.x, self.owner.y, evt.unit.x, evt.unit.y): return
		self.owner.level.queue_spell(self.quill(evt.unit))
		self.do_ui_flash()

	def quill(self, target):
		if not target.is_alive(): return

		for point in Bolt(self.owner.level, self.owner, target):
			self.owner.level.projectile_effect(point.x, point.y, proj_name='physical_bolt', proj_origin=self.owner, proj_dest=target)
			yield

		target.deal_damage(self.get_stat('damage'), Tags.Physical, self)


class VolcanicLance(Equipment):

	def on_init(self):
		self.name = "Volcanic Lance"
		self.slot = SLOT_WEAPON
		self.owner_triggers[EventOnSpellCast] = self.on_cast
		self.tag_bonuses[Tags.Fire]['range'] = 3
		self.tags = [Tags.Fire]
		self.recipe = [(Tags.Fire, 2), (Tags.Translocation, 1), (Tags.Any, 3)]

	def get_description(self):
		desc = ["When you cast a [Fire] spell targeting an enemy, send out a destructive beam toward the target\n"
				"The beam destroys walls and deals [Fire] damage equal to your [Fire] mastery"]
		if self.owner: desc.append("\n[Fire Mastery:fire]: [{mastery}:fire]")
		return desc

	def fmt_dict(self):
		d = Equipment.fmt_dict(self)
		d['mastery'] = self.owner.get_mastery(Tags.Fire) if self.owner else 0
		return d

	def on_cast(self, evt):
		if Tags.Fire in evt.spell.tags:
			target_unit = self.owner.level.get_unit_at(evt.x, evt.y) # grab the unit there
			if target_unit and are_hostile(self.owner, target_unit): # check if the target was actually a unit and if it's an enemy
				self.owner.level.queue_spell(self.beam(target_unit)) # queue up the lancing beam
				self.do_ui_flash()

	def beam(self, target_unit):
		self.owner.level.show_beam(self.owner, target_unit, Tags.Fire)  # show the beam
		damage = self.owner.get_mastery(Tags.Fire) # set beam's damage equal to Fire Mastery
		path = self.owner.level.get_points_in_line(self.owner, target_unit, two_pass=False, find_clear=False) # get the path
		path = path[1:] # skip the first point
		for point in path: # for each point along the path
			cur_tile = self.owner.level.tiles[point.x][point.y] # grab the tile

			if not cur_tile.can_see: # Kill walls
				self.owner.level.make_floor(point.x, point.y)

			if cur_tile.cloud: # Kill clouds
				cur_tile.cloud.kill()

			unit = self.owner.level.get_unit_at(point.x, point.y) # try to grab a unit at the tile
			if unit: self.owner.level.deal_damage(unit.x, unit.y, damage, Tags.Fire, self, flash=True) # Deal damage
			else: self.owner.level.show_effect(point.x, point.y, Tags.Fire)

			yield

class ErebusLance(Equipment):

	def on_init(self):
		self.name = "Erebus Lance"
		self.slot = SLOT_WEAPON
		self.owner_triggers[EventOnSpellCast] = self.on_cast
		self.tag_bonuses[Tags.Dark]['range'] = 3
		self.tags = [Tags.Dark]
		self.recipe = [(Tags.Dark, 2), (Tags.Translocation, 1), (Tags.Any, 3)]

	def get_description(self):
		desc = ["When you cast a [Dark] spell targeting an enemy, send out a destructive beam toward the target\n"
				"The beam destroys walls and deals [Dark] damage equal to your [Dark] mastery"]
		if self.owner: desc.append("\n[Dark Mastery:dark]: [{mastery}:dark]")
		return desc

	def fmt_dict(self):
		d = Equipment.fmt_dict(self)
		d['mastery'] = self.owner.get_mastery(Tags.Dark) if self.owner else 0
		return d

	def on_cast(self, evt):
		if Tags.Dark in evt.spell.tags:
			target_unit = self.owner.level.get_unit_at(evt.x, evt.y) # grab the unit there
			if target_unit and are_hostile(self.owner, target_unit): # check if the target was actually a unit and if it's an enemy
				self.owner.level.queue_spell(self.beam(target_unit)) # queue up the lancing beam
				self.do_ui_flash()

	def beam(self, target_unit):
		self.owner.level.show_beam(self.owner, target_unit, Tags.Dark)  # show the beam
		damage = self.owner.get_mastery(Tags.Dark) # set beam's damage equal to Dark Mastery
		path = self.owner.level.get_points_in_line(self.owner, target_unit, two_pass=False, find_clear=False) # get the path
		path = path[1:] # skip the first point
		for point in path: # for each point along the path
			cur_tile = self.owner.level.tiles[point.x][point.y] # grab the tile

			if not cur_tile.can_see: # Kill walls
				self.owner.level.make_floor(point.x, point.y)

			if cur_tile.cloud: # Kill clouds
				cur_tile.cloud.kill()

			unit = self.owner.level.get_unit_at(point.x, point.y) # try to grab a unit at the tile
			if unit: self.owner.level.deal_damage(unit.x, unit.y, damage, Tags.Dark, self, flash=True) # Deal damage
			else: self.owner.level.show_effect(point.x, point.y, Tags.Dark)

			yield

class Heavenrender(Equipment):

	def on_init(self):
		self.name = "Heavenrender"
		self.owner_triggers[EventOnSpellCast] = self.on_cast
		self.tags = [Tags.Fire, Tags.Holy, Tags.Lightning]
		self.recipe = [(Tags.Fire, 1), (Tags.Holy, 2), (Tags.Lightning, 1), (Tags.Any, 2)]

		self.radius = 2

	def get_description(self):
		desc = ["When you cast a [Holy] spell, deal [Fire] and [Lightning] damage to enemies within [{radius}:radius] tiles of the target\n"
				"Damage dealt is equal to your mastery in the respective school"]
		if self.owner:
			desc.append("\n[Fire Mastery:fire]: [{fmastery}:fire]")
			desc.append("\n[Lightning Mastery:lightning]: [{lmastery}:lightning]")
		return desc

	def fmt_dict(self):
		d = Equipment.fmt_dict(self)
		d['fmastery'] = self.owner.get_mastery(Tags.Fire) if self.owner else 0
		d['lmastery'] = self.owner.get_mastery(Tags.Lightning) if self.owner else 0
		return d

	def on_cast(self, evt):
		if Tags.Holy not in evt.spell.tags: return
		self.owner.level.queue_spell(self.do_effect(evt))

	def do_effect(self, evt):
		owner = self.owner
		level = owner.level
		targets = [u for u in level.get_units_in_ball(Point(evt.x, evt.y), self.get_stat('radius')) if are_hostile(owner, u)]
		if not targets: return
		l_mastery = owner.get_mastery(Tags.Lightning)
		f_mastery = owner.get_mastery(Tags.Fire)
		if not l_mastery and not f_mastery: return
		self.do_ui_flash()
		for target in targets:
			if f_mastery: target.deal_damage(f_mastery, Tags.Fire, self)
			if l_mastery: target.deal_damage(l_mastery, Tags.Lightning, self)
		yield


class RechargingChalice(Equipment):

	def __init__(self, name, tag):
		self.tag = tag
		Equipment.__init__(self)
		self.name = "Chalice of %s" % name
		self.tags = [tag]
		self.recipe = [(tag, 3), (Tags.Any, 3)]

	def on_init(self):
		self.global_triggers[EventOnItemPickup] = self.on_sp_pickup
		self.effect_tag = self.tag

	def get_description(self):
		return ("When you pick up a Memory Orb, your {tag} spells regain all charges", {'tag':formatted_tag(self.tag)})

	def on_sp_pickup(self, evt):
		if isinstance(evt.item, MemoryOrb):
			self.owner.level.show_effect(self.owner.x, self.owner.y, self.effect_tag) # show an effect of the appropriate color
			for spell in self.owner.spells: # for each of the wizard's spells
				if self.tag in spell.tags: # if the spell has the tag of this item
					spell.cur_charges = spell.get_stat('max_charges') # grant the spell all charges
					spell.do_ui_flash(self.effect_tag)
					self.do_ui_flash()

class ChaliceOfLight(RechargingChalice):

	def __init__(self):
		RechargingChalice.__init__(self, 'Light', Tags.Holy)

class ChaliceOfIron(RechargingChalice):

	def __init__(self):
		RechargingChalice.__init__(self, 'Iron', Tags.Metallic)
		self.effect_tag = Tags.Physical

class ChaliceOfWarp(RechargingChalice):

	def __init__(self):
		RechargingChalice.__init__(self, 'Warp', Tags.Translocation)


class ChaliceOfDragons(RechargingChalice):

	def __init__(self):
		RechargingChalice.__init__(self, 'Dragons', Tags.Dragon)
		self.effect_tag = Tags.Conjuration

class ChaosRobes(Equipment):

	def on_init(self):
		self.name = "Chaos Robes"
		self.slot = SLOT_ARMOR
		self.dtypes = [Tags.Fire, Tags.Lightning, Tags.Physical]
		for dtype in self.dtypes: self.resists[dtype] = 33
		self.damage = 8
		self.num_targets = 3
		self.owner_triggers[EventOnSpellCast] = self.on_cast
		self.tags = [Tags.Chaos]
		self.recipe = [(Tags.Chaos, 2), (Tags.Eye, 1), (Tags.Any, 3)]

	def get_description(self):
		return ("When you cast a [Chaos] spell, deal [{damage}:damage] damage to up to [{num_targets}:num_targets] targets in line of sight\n"
				"Deals [Fire], [Lightning], or [Physical] damage")

	def on_cast(self, evt):
		if Tags.Chaos not in evt.spell.tags: return
		self.owner.level.queue_spell(self.bolts())
		self.do_ui_flash()

	def bolts(self):

		candidates = [u for u in self.owner.level.get_units_in_los(self.owner) if are_hostile(self.owner, u)]
		random.shuffle(candidates)

		dmg = self.get_stat('damage')
		for i in range(self.get_stat('num_targets')):
			while candidates and not candidates[-1].is_alive(): candidates.pop()
			if not candidates: break
			target = candidates.pop()
			dtype = random.choice(self.dtypes)
			self.owner.level.show_beam(self.owner, target, dtype)
			target.deal_damage(dmg, dtype, self)
			yield

class TwoElementShotRobe(Equipment):

	def __init__(self, name, tag1, tag2):
		self.tag1 = tag1
		self.tag2 = tag2
		Equipment.__init__(self)
		self.name = "Robe of %s" % name
		self.slot = SLOT_ARMOR
		self.tags = [tag1, tag2]
		self.recipe =[(tag1, 1), (tag2, 1), (Tags.Eye, 1), (Tags.Any, 3)]
		self.damage = 8
		self.set_stats()

	def on_init(self):
		self.resists[self.tag1] = 25
		self.resists[self.tag2] = 25
		self.owner_triggers[EventOnSpellCast] = self.on_cast

	def get_description(self):
		return ("When you cast a {tag1} or {tag2} spell, deal [{damage}:damage] {tag1} damage to a random enemy in line of sight, and [{damage}:damage] {tag2} damage to another", {'tag1':formatted_tag(self.tag1), 'tag2':formatted_tag(self.tag2)})

	def on_cast(self, evt):
		if self.tag1 not in evt.spell.tags and self.tag2 not in evt.spell.tags: return
		self.owner.level.queue_spell(self.bolts())
		self.do_ui_flash()

	def bolts(self):

		candidates = [u for u in self.owner.level.get_units_in_los(self.owner) if are_hostile(self.owner, u)]
		random.shuffle(candidates)

		dtypes = [self.tag1, self.tag2]
		random.shuffle(dtypes)

		for dtype in dtypes:
			if dtype == Tags.Metallic: dtype = Tags.Physical
			while candidates and not candidates[-1].is_alive(): candidates.pop() # ditch dead units from candidate list until we find a live one
			if not candidates: break
			target = candidates.pop()
			self.owner.level.show_beam(self.owner, target, dtype)
			target.deal_damage(self.get_stat('damage'), dtype, self)
			yield

class RobeOfTwilight(TwoElementShotRobe):

	def __init__(self):
		TwoElementShotRobe.__init__(self, 'Twilight', Tags.Dark, Tags.Holy)

class RobeOfAgony(TwoElementShotRobe):

	def __init__(self):
		TwoElementShotRobe.__init__(self, 'Agony', Tags.Lightning, Tags.Dark)

class RobeOfFrostfire(TwoElementShotRobe):

	def __init__(self):
		TwoElementShotRobe.__init__(self, 'Frostfire', Tags.Fire, Tags.Ice)

class RobeOfCrystals(TwoElementShotRobe):

	def __init__(self):
		TwoElementShotRobe.__init__(self, 'Crystals', Tags.Arcane, Tags.Ice)

class RaimentOfEyes(Equipment):

	def on_init(self):
		self.name = "Raiment of Eyes"
		self.slot = SLOT_ARMOR
		self.global_triggers[EventOnUnitAdded] = self.on_added
		self.owner_triggers[EventOnUnitAdded] = self.on_enter
		self.counter = 0
		self.tags = [Tags.Enchantment, Tags.Eye]
		self.recipe = [(Tags.Conjuration, 1), (Tags.Enchantment, 2), (Tags.Eye, 1), (Tags.Any, 5)]

	def get_description(self):
		desc = ["When allies are summoned, grant them your [Eye] [Enchantment] spells that they share a tag with\n"
				"Each level, you may grant a number of these spells equal to your [Eye] mastery"]
		if self.owner:
			desc.append("\nSpells Granted: [{remaining}:eye]")
			desc.append("\n[Eye Mastery:eye]: [{mastery}:eye]")
		return desc

	def fmt_dict(self):
		d = Equipment.fmt_dict(self)
		m = (self.owner.get_mastery(Tags.Eye) if self.owner else 0)
		d['mastery'] = m
		d['remaining'] = self.counter
		return d

	def on_enter(self, evt):
		self.counter = 0 # reset counter on level entry

	def on_added(self, evt):
		if are_hostile(self.owner, evt.unit): return  # if it's an ally
		if self.counter >= self.owner.get_mastery(Tags.Eye): return  # and you haven't granted all your eyes yet
		for tag in evt.unit.tags:  # for each of its tags
			for spell in self.owner.spells:  # for each of the wizard's spells
				if not (Tags.Enchantment in spell.tags and Tags.Eye in spell.tags): continue # if it's an eye enchantment spell
				if tag in spell.tags:  # if the unit's tag matches one of the eye's tags
					spell_class = type(spell)  # grab the class of the spell
					if any(s for s in evt.unit.spells if s.name == spell.name): continue  # don't dupe eyes, armorer skill problems
					grant_minion_spell(spell_class, evt.unit, self.owner, cool_down=30)
					evt.unit.level.show_path_effect(self.owner, evt.unit, Tags.Arcane, minor=True)
					self.do_ui_flash()
					self.counter += 1

class PrinceOfRuinLike(Equipment):

	def __init__(self, name, tags, damage_tags=None):
		Equipment.__init__(self, name, tags, damage_tags)
		self.name = name
		self.tags = tags
		self.damage_tags = damage_tags if damage_tags else tags.copy()
		self.recipe = [(tags[0], 1), (tags[1], 1), (Tags.Translocation, 1), (Tags.Any, 2)]

	def on_init(self):
		self.global_triggers[EventOnDeath] = self.on_death
		self.damage = 9
		self.radius = 3
		self.triggers = 0

	def get_description(self):
		return (("When an enemy dies to {dtype_1} or {dtype_2} damage, a random enemy in their line of sight within [{radius}:radius] tiles takes [{damage}:damage] damage of that type",
				{"dtype_1":formatted_tag(self.damage_tags[0]), "dtype_2":formatted_tag(self.damage_tags[1])}))

	def on_death(self, evt):
		if not are_hostile(evt.unit, self.owner): return
		if evt.damage_event and evt.damage_event.damage_type in self.damage_tags:
			self.triggers += 1
			delay = (self.triggers // 10)
			self.owner.level.queue_spell(self.trigger(evt.unit, self.get_stat('radius'), self.get_stat('damage'), evt.damage_event.damage_type, delay))
			self.do_ui_flash()

	def on_advance(self): self.triggers = 0

	def trigger(self, unit, radius, damage, dtype, delay):
		if delay:
			for _ in range(delay):
				yield

		candidates = [u for u in unit.level.get_units_in_ball(unit, radius) if are_hostile(self.owner, u)]
		candidates = [u for u in candidates if unit.level.can_see(unit.x, unit.y, u.x, u.y)]

		if candidates:
			target = random.choice(candidates)
			target.level.show_beam(unit, target, dtype)
			target.deal_damage(damage, dtype, self)
		yield

class BloodspikeHelm(Equipment):

	def on_init(self):
		self.name = "Bloodspike Helm"
		self.slot = SLOT_HELMET
		self.num_targets = 3
		self.owner_triggers[EventOnSpendHP] = self.on_spend
		self.tags = [Tags.Blood, Tags.Eye]
		self.recipe = [(Tags.Blood, 1), (Tags.Eye, 1), (Tags.Metallic, 1), (Tags.Any, 3)]

	def on_spend(self, evt):
		self.owner.level.queue_spell(self.fire_spikes(evt.hp))
		self.do_ui_flash()

	def fire_spikes(self, damage):
		targets = [u for u in self.owner.level.get_units_in_los(self.owner) if are_hostile(u, self.owner)]
		random.shuffle(targets)
		for target in targets[:self.get_stat('num_targets')]:
			if not target.is_alive(): continue
			for point in Bolt(self.owner.level, self.owner, target):
				self.owner.level.projectile_effect(point.x, point.y, proj_name='physical_bolt', proj_origin=self.owner, proj_dest=target)
			target.deal_damage(damage, Tags.Physical, self)
			yield

	def get_description(self):
		return "When you spend HP, deal that much [Physical] damage to up to [{num_targets}:num_targets] enemies in your line of sight"


class CurseDoll(Equipment):

	def __init__(self, name, tags, spell):
		Equipment.__init__(self, name, tags, spell)
		self.name = "%s Curse Doll" % name
		self.trigger_tags = tags
		self.spell = spell
		self.spell_ex = spell()
		self.spell_name = self.spell_ex.name
		self.add_spell_tooltip(spell)

		self.tags = self.spell_ex.tags[:]
		self.recipe = []
		cost = 0
		for t in self.tags: self.recipe.append((t, 2)); cost += 2
		if cost < 6: self.recipe.append((Tags.Any, 6-cost))

	def on_init(self):
		self.global_triggers[EventOnDeath] = self.on_death

	def get_description(self):
		return ("When one of your {tag1} or {tag2} allies dies to an enemy, cast {spell} on the killer", {'tag1':formatted_tag(self.trigger_tags[0]), 'tag2':formatted_tag(self.trigger_tags[1]), 'spell':self.spell_name})

	def on_death(self, evt):
		if are_hostile(evt.unit, self.owner): return
		if not any(t in self.trigger_tags for t in evt.unit.tags): return
		if evt.damage_event is None: return

		source = evt.damage_event.source
		if not source: return
		source_unit = source.owner
		if not source_unit: return
		if not are_hostile(source_unit, self.owner): return

		self.owner.level.queue_spell(self.retributive_cast(source_unit)) # double queuing to make sure the location of the killer is captured correctly
		self.do_ui_flash()

	def retributive_cast(self, killer_unit):
		yield
		if not killer_unit.is_alive(): return
		s = self.owner.get_or_make_spell(self.spell)
		for _ in self.owner.level.act_cast(self.owner, s, killer_unit.x, killer_unit.y, pay_costs=False, queue=False): yield
		yield

class SpellBoots(Equipment):

	def __init__(self, name, spell, steps):
		self.spell = spell
		self.steps = steps

		Equipment.__init__(self, name, spell, steps)

		self.name = name
		self.spell_name = self.spell().name
		self.add_spell_tooltip(spell)

		self.tags = spell().tags + [Tags.Translocation]
		self.recipe = []
		for tag in self.tags: self.recipe.append((tag, 1))
		num_any = 8 - len(self.tags)
		if num_any > 0: self.recipe.append((Tags.Any, num_any))
		self.slot = SLOT_BOOTS
		self.active = False
		self.global_triggers[EventOnLevelComplete] = self.on_complete

	def on_applied(self, owner):
		self.active = True

	def on_complete(self, evt):
		self.active = False

	def on_equip(self, owner):
		if not owner.is_player_controlled: return
		if owner.game.level_cleared: self.active = False

	def on_init(self):
		self.counter = self.steps
		self.owner_triggers[EventOnMoved] = self.on_move

	def on_move(self, evt):
		if not self.active: return
		if evt.teleport: return
		self.counter -= 1
		if self.counter <= 0:
			spell = self.owner.get_or_make_spell(self.spell)
			self.owner.level.act_cast(self.owner, spell, self.owner.x, self.owner.y, pay_costs=False)
			self.do_ui_flash()
			self.counter = self.steps

	def get_description(self):
		return ("Every {steps} steps, cast {spellname}\n{counter} steps until cast",
		{'steps':self.steps, 'spellname':self.spell_name, 'counter':self.counter})

class CrownOfRagnarok(Equipment):

	def on_init(self):
		self.name = "Crown of Ragnarok"
		self.slot = SLOT_HELMET
		self.tags = [Tags.Chaos]
		self.recipe = [(Tags.Chaos, 1), (Tags.Any, 3)]

		self.num_targets = 3

		self.r = [EarthquakeSpell, FlameBurstSpell, StormBurst]
		self.add_spell_tooltip(EarthquakeSpell)
		self.add_spell_tooltip(FlameBurstSpell)
		self.add_spell_tooltip(StormBurst)

	def get_description(self):
		return "On the 9th turn of each level, cast Earthquake, Flame Burst, and Storm Burst [{num_targets}:num_targets] times"

	def on_advance(self):
		if self.owner.level.turn_no != 9: return
		self.do_ui_flash()
		o = self.owner
		for _ in range(self.get_stat('num_targets')):
			for s in self.r: o.level.act_cast(o, o.get_or_make_spell(s), o.x, o.y, pay_costs=False)


class CrownOfDevastationBuff(Buff):

	def __init__(self, num_targets):
		self.num_targets = num_targets
		Buff.__init__(self)

	def on_init(self):
		self.name = "Devastation"
		self.color = Tags.Arcane.color
		self.description = "Each turn, cast Void Beam on up to [{num}:num_targets] random enemies", {'num':self.num_targets}
		self.stack_type = STACK_INTENSITY

	def on_advance(self):
		enemies = [u for u in self.owner.level.units if are_hostile(self.owner, u) and u.is_alive()]
		if not enemies: return
		num = min(len(enemies), self.num_targets)
		targets = random.sample(enemies, num)
		for u in targets: self.owner.level.queue_spell(self.do_beam(u))

	def do_beam(self, u):
		s = self.owner.get_or_make_spell(VoidBeamSpell)
		self.owner.level.act_cast(self.owner, s, u.x, u.y, pay_costs=False)
		for _ in range(4): yield


class CrownOfDevastation(Equipment):

	def on_init(self):
		self.name = "Crown of Devastation"
		self.slot = SLOT_HELMET
		self.tags = [Tags.Arcane, Tags.Eye]
		self.recipe = [(Tags.Arcane, 3), (Tags.Eye, 3), (Tags.Any, 3)]

		self.duration = 3
		self.num_targets = 3
		self.counter = 0

		self.owner_triggers[EventOnUnitAdded] = self.on_added
		self.add_effect_tooltip(lambda: CrownOfDevastationBuff(self.get_stat('num_targets')))
		self.add_spell_tooltip(VoidBeamSpell)

	def get_description(self):
		return ("At the beginning of each level, gain the [Devastation:arcane] buff for [{duration}:duration] turns\n"
				"[Devastation:arcane] casts Void Beam on up to [{num_targets}:num_targets] random enemies each turn")

	def on_added(self, evt):
		evt.unit.apply_buff(CrownOfDevastationBuff(self.get_stat('num_targets')), self.get_stat('duration'))
		self.do_ui_flash()

class BloodShield(Equipment):

	def on_init(self):
		self.name = "Blood Shield"
		self.owner_triggers[EventOnSpellCast] = self.on_cast
		self.tags = [Tags.Blood]
		self.recipe = [(Tags.Blood, 2), (Tags.Any, 3)]

	def get_description(self):
		return "When you cast a spell, pay [3 HP:blood] to gain [1 SH:shields]"

	def on_cast(self, evt):
		if evt.spell.name == "look" or evt.spell.name == "walk": # hacky, but don't want those granting shields obv
			return
		self.owner.level.queue_spell(self.on_cast_effects())
		self.do_ui_flash()

	def on_cast_effects(self):
		hp_cost = 3
		if self.owner.cur_hp <= hp_cost: return
		self.owner.cur_hp -= hp_cost
		self.owner.level.event_manager.raise_event(EventOnSpendHP(self.owner, hp_cost), self.owner)
		yield
		self.owner.level.show_effect(self.owner.x, self.owner.y, Tags.Blood)
		yield
		self.owner.add_shields(1)
		yield


class MinionCastHat(Equipment):

	def __init__(self, name, spell, creature_tag, recipe_tag=None):
		self.spell = spell
		self.creature_tag = creature_tag
		Equipment.__init__(self, name, spell, creature_tag)
		self.name = name
		self.spell_name = self.spell().name
		self.slot = SLOT_HELMET
		self.add_spell_tooltip(spell)
		self.tags = spell().tags
		if recipe_tag and recipe_tag not in self.tags: self.tags.append(recipe_tag)
		self.recipe = []
		for tag in self.tags: self.recipe.append((tag, 1))
		num_any = 6 - len(self.tags)
		if num_any > 0: self.recipe.append((Tags.Any, num_any))

	def get_description(self):
		return ("Each turn, one of your {tag} allies casts your {spell} spell on a random enemy", {'tag':formatted_tag(self.creature_tag), 'spell':self.spell_name})

	def on_advance(self):
		# Cast the spell from one random minion that has a valid target on a random valid target
		owner = self.owner
		potential_casters = [u for u in owner.level.units if not are_hostile(owner, u) and self.creature_tag in u.tags and u != owner]

		random.shuffle(potential_casters)

		for c in potential_casters:
			spell = self.spell()
			spell.statholder = self.owner
			spell.caster = c
			spell.owner = c

			def is_good_target(p):
				unit = self.owner.level.get_unit_at(p.x, p.y)
				if not unit: return False
				if not are_hostile(self.owner, unit): return False
				return spell.can_cast(p.x, p.y)

			# Problem is this gets a list of units and then we try to cast deathtouch on the unit's center which is not a valid target, only its corner is (for 3x3s)
			potential_targets = [p for p in self.owner.level.get_points_in_ball(c.x, c.y, spell.get_stat('range')) if is_good_target(p)]

			if not potential_targets: continue

			else:
				target = random.choice(potential_targets)
				self.owner.level.act_cast(c, spell, target.x, target.y, pay_costs=False)
				self.do_ui_flash()
				return

class CausticSprig(Equipment):

	def on_init(self):
		self.name = "Caustic Sprig"
		self.tags = [Tags.Nature]
		self.recipe = [(Tags.Enchantment, 1), (Tags.Nature, 1), (Tags.Any, 3)]
		self.description = ("Each turn, [poisoned] enemies lose one of their temporary buffs\n"
							"If a buff is lost this way, their [poison] duration is doubled")

	def on_advance(self):
		owner = self.owner
		candidates = []

		for u in owner.level.units:
			if not are_hostile(owner, u) or not u.has_buff(Poison): continue
			for b in u.buffs:
				if b.buff_type == BUFF_TYPE_BLESS:
					candidates.append((u, b))
					break

		if not candidates: return
		self.do_ui_flash()
		for u, temp_buff in candidates:
			p = u.get_buff(Poison)
			p.turns_left *= 2
			u.remove_buff(temp_buff)

class DebuffDamager(Equipment):

	def __init__(self, name, damage, damage_type, num_targets, debuff, tags):
		Equipment.__init__(self, name, damage, damage_type, num_targets, debuff, tags)
		self.name = name
		self.damage = damage
		self.num_targets = num_targets
		self.debuff = debuff
		self.debuff_name = debuff().name.lower()
		self.damage_type = damage_type
		self.tags = tags
		self.recipe = []
		for t in tags: self.recipe.append((t, 1))
		self.recipe.append((Tags.Translocation, 1))
		self.recipe.append((Tags.Any, 2))
		self.set_stats()

	def get_description(self):
		return (("Each turn, deal [{damage}:damage] {tag} damage to [{num_targets}:num_targets] random enemies currently afflicted with [{status}]",
				{'tag':formatted_tag(self.damage_type), 'status':self.debuff_name}))

	def on_advance(self):
		candidates = [u for u in self.owner.level.units if are_hostile(self.owner, u) and u.has_buff(self.debuff)]
		if not candidates: return
		self.do_ui_flash()
		num = min(len(candidates), self.get_stat('num_targets'))
		for target in random.sample(candidates, num):
			target.deal_damage(self.get_stat('damage'), self.damage_type, self)


class MulticoloredRageRod(Equipment):

	def on_init(self):
		self.name = "Multicolored Rage Rod"
		self.slot = SLOT_WEAPON
		self.owner_triggers[EventOnSpellCast] = self.on_cast
		self.owner_triggers[EventOnUnitAdded] = self.on_add
		self.owner_triggers[EventOnBuffRemove] = self.on_remove

		self.tags_seen = set()
		self.description = "All spells and equipment gain +1 damage for each unique tag amongst all the spells you have cast this level"
		self.tags = [ Tags.Enchantment, Tags.Sorcery]
		self.recipe = [(Tags.Enchantment, 1), (Tags.Sorcery, 1), (Tags.Any, 6)]
		self.add_effect_tooltip(self.make_rage_tooltip)

	def get_description(self):
		if not self.owner: return self.description
		desc = [self.description]
		if self.tags_seen:
			desc.append("\nTags Cast:\n")
			for t in list(self.tags_seen):
				desc.append(("{tag}\n", {'tag':formatted_tag(t)}))
		return desc

	def make_rage_tooltip(self):
		rage = BloodrageBuff(1)
		rage.buff_type = BUFF_TYPE_BLESS
		rage.name = "Multicolored Rage"
		rage.color = COLOR_DAMAGE
		return rage

	def on_cast(self, evt):
		for t in evt.spell.tags:
			if t in self.tags_seen: continue

			# Check if a buff with this tag already exists
			if any(getattr(b, 'rage_rod_tag', None) == t and getattr(b, 'source', None) == self for b in self.owner.buffs):
				self.tags_seen.add(t)
				continue  # or just skip to the next tag

			rage = BloodrageBuff(1)  # make a buff that does the same thing but is an item type and then remove it on level enter?
			rage.buff_type = BUFF_TYPE_BLESS
			rage.name = "Multicolored Rage"
			rage.color = COLOR_DAMAGE
			rage.rage_rod_tag = t
			rage.source = self # so you can stack w/ duplicated rage rods

			self.owner.apply_buff(rage)
			self.tags_seen.add(t)
			self.do_ui_flash()

	def on_add(self, evt):
		self.tags_seen.clear()

	def on_remove(self, evt):
		if not isinstance(evt.buff, BloodrageBuff): return
		if hasattr(evt.buff, "rage_rod_tag") and evt.buff.rage_rod_tag: self.tags_seen.discard(evt.buff.rage_rod_tag)

class Kettlestaff(Equipment):

	def on_init(self):
		self.name = "The Boiler"
		self.slot = SLOT_WEAPON
		self.damage = 50
		self.tags = [Tags.Fire]
		self.recipe = [(Tags.Fire, 2), (Tags.Any, 3)]

	def get_description(self):
		return "Each turn, all soaked enemies take [{damage}:damage] [Fire] damage"

	def on_advance(self):
		damage = self.get_stat('damage')
		activated = False
		for u in self.owner.level.units[:]:
			if are_hostile(self.owner, u) and u.has_buff(SoakedBuff):
				activated = True
				u.deal_damage(damage, Tags.Fire, self)
		if activated: self.do_ui_flash()

class EvermeltingCube(Equipment):

	def on_init(self):
		self.name = "Evermelting Cube"
		self.duration = 3
		self.global_triggers[EventOnUnfrozen] = self.on_unfrozen
		self.tags = [Tags.Ice]
		self.recipe = [(Tags.Ice, 1), (Tags.Any, 3)]

	def get_description(self):
		return "When an enemy is unfrozen, it is soaked for [{duration} turns:duration]"

	def on_unfrozen(self, evt):
		if are_hostile(self.owner, evt.unit):
			evt.unit.apply_buff(SoakedBuff(), self.get_stat('duration'))
			self.do_ui_flash()

class DwarfHat(Equipment):

	def on_init(self):
		self.name = "Dwarf Hat"
		self.slot = SLOT_HELMET
		self.description = "At the beginning of each level, if you know at least seven spells, summon 7 Duergar"
		self.owner_triggers[EventOnUnitAdded] = self.on_enter
		self.tags = [Tags.Conjuration, Tags.Dark, Tags.Metallic]
		self.recipe = [(Tags.Conjuration, 1), (Tags.Dark, 1), (Tags.Metallic, 1), (Tags.Any, 1)]

		self.minion_health = 35
		self.minion_range = 8
		self.minion_damage = 12

	def do_summon(self):
		for i in range(7):
			dwarf = make_minion(self, Dwarf)
			self.summon(dwarf)
			yield
		self.do_ui_flash()

	def on_enter(self, evt):
		if len(self.owner.spells) >= 7: self.owner.level.queue_spell(self.do_summon())

	def get_extra_examine_tooltips(self):
		return [make_minion(self, Dwarf)]

class HelmOfHexes(Equipment):

	def on_init(self):
		self.name = "Helm of Hexes"
		self.slot = SLOT_HELMET
		self.duration = 6
		self.global_triggers[EventOnBuffApply] = self.on_debuff
		self.debuffs =[BlindBuff, Poison, FrozenBuff, PetrifyBuff, FearBuff, Silence, SleepBuff]
		self.tags = [Tags.Enchantment]
		self.recipe = [(Tags.Dark, 1), (Tags.Enchantment, 2), (Tags.Any, 3)]

	def get_description(self):
		return ("When an enemy gains a debuff, there is a 50% chance to apply another random debuff for the same duration, up to a maximum of [{duration}:duration] turns"
				"\nThis item can apply:"
				"\n[Blind], [poison], [fear], [silence], [frozen], [sleep], and [petrified]")

	def on_debuff(self, evt):
		if not evt.buff.buff_type == BUFF_TYPE_CURSE: return
		if not are_hostile(self.owner, evt.unit): return
		if random.random() > .5: return
		d = self.get_stat('duration')
		dur = min(evt.buff.turns_left, d)
		if dur < 1 : dur = d # if the dbuff applied was permanent i.e 0 duration, we want to set it to a max of this items buff duration
		evt.unit.apply_buff(buff=self.roll_debuff(evt.unit.buffs)(), duration=dur)
		self.do_ui_flash()

	def roll_debuff(self, buffs):
		existing_types = {type(b) for b in buffs if b.buff_type == BUFF_TYPE_CURSE}
		applicable = [b for b in self.debuffs if b not in existing_types]
		if applicable: return random.choice(applicable)
		else: return random.choice(self.debuffs)

class MaskOfWoe(Equipment):

	def on_init(self):
		self.name = "Mask of Woe"
		self.slot = SLOT_HELMET
		self.duration = 1
		self.radius = 2
		self.tags = [Tags.Enchantment]
		self.recipe = [(Tags.Dark, 1), (Tags.Enchantment, 1), (Tags.Translocation, 1), (Tags.Any, 4)]

	def get_description(self):
		return "At the end of your turn, increase the duration of debuffs on enemies within [{radius}:radius] tiles by [{duration}:duration]"

	def on_advance(self):
		for u in self.owner.level.get_units_in_ball(self.owner, self.get_stat('radius')):
			if not are_hostile(self.owner, u): continue
			dur = self.get_stat('duration')
			for b in u.buffs:
				if b.turns_left and b.turns_left > 0:
					if b.buff_type == BUFF_TYPE_CURSE:
						b.turns_left += dur
						self.do_ui_flash()

class WoundRotAmulet(Equipment):

	def on_init(self):
		self.name = "Wound Rot Amulet"
		self.duration = 3
		self.global_triggers[EventOnDamaged] = self.on_damaged
		self.tags = [Tags.Dark, Tags.Nature]
		self.recipe = [(Tags.Dark, 1), (Tags.Nature, 1), (Tags.Any, 4)]

	def get_description(self):
		return "Enemies receive [{duration}:duration] turns of [poison] when they take [Physical] damage"

	def on_damaged(self, evt):
		if not evt.unit.is_alive(): return
		if not evt.damage_type == Tags.Physical: return
		if not are_hostile(self.owner, evt.unit): return
		evt.unit.apply_buff(Poison(), self.get_stat('duration'))
		self.do_ui_flash()

class VeilpiercersMonocle(Equipment):

	def on_init(self):
		self.name = "Veilpiercer's Monocle"
		self.slot = SLOT_HELMET
		self.description = "Gain clarity when you cast a [Translocation] spell\nThe buff's duration is equal to the spell's level"
		self.owner_triggers[EventOnSpellCast] = self.on_cast
		self.tag_bonuses[Tags.Translocation]['range'] = 3
		self.tags = [Tags.Enchantment, Tags.Translocation]
		self.recipe = [(Tags.Enchantment, 1), (Tags.Translocation, 1), (Tags.Any, 2)]

	def on_cast(self, evt):
		if not Tags.Translocation in evt.spell.tags: return
		if not evt.spell.level: return
		self.owner.apply_buff(StunImmune(), evt.spell.level)
		self.do_ui_flash()

class ExplosiveSporeManual(Equipment):

	def on_init(self):
		self.name = "Explosive Spore Manual"
		self.description = "While enemies live, cast Combust Poison at the end of each turn"
		self.global_triggers[EventOnLevelComplete] = self.on_complete
		self.owner_triggers[EventOnUnitAdded] = self.on_unit_added
		self.tags = [Tags.Fire, Tags.Nature]
		self.recipe = [(Tags.Fire, 2), (Tags.Nature, 1), (Tags.Word, 1), (Tags.Any, 4)]
		self.active = True
		self.add_spell_tooltip(IgnitePoison)

	def on_advance(self):
		if not self.active: return
		s = self.owner.get_or_make_spell(IgnitePoison)
		s.animate = False
		self.owner.level.act_cast(self.owner, s, self.owner.x, self.owner.y, pay_costs=False)
		self.do_ui_flash()

	def on_unit_added(self, u):
		self.active = True

	def on_complete(self, _lvl):
		self.active = False

	def on_equip(self, owner):
		if not owner.is_player_controlled: return
		if owner.game.level_cleared: self.active = False

class ShatteringFrostManual(Equipment):

	def on_init(self):
		self.name = "Shattering Frost Manual"
		self.description = "While enemies live, cast Shatter at the end of each turn"
		self.global_triggers[EventOnLevelComplete] = self.on_complete
		self.owner_triggers[EventOnUnitAdded] = self.on_unit_added
		self.tags = [Tags.Ice]
		self.recipe = [(Tags.Ice, 1), (Tags.Word, 1), (Tags.Any, 4)]
		self.active = True
		self.add_spell_tooltip(ShatterSpell)

	def on_advance(self):
		if not self.active: return
		s = self.owner.get_or_make_spell(ShatterSpell)
		s.animate = False
		self.owner.level.act_cast(self.owner, s, self.owner.x, self.owner.y, pay_costs=False)
		self.do_ui_flash()

	def on_unit_added(self, u):
		self.active = True

	def on_complete(self, _lvl):
		self.active = False

	def on_equip(self, owner):
		if not owner.is_player_controlled: return
		if owner.game.level_cleared: self.active = False

class TundraMantle(Equipment):

	def on_init(self):
		self.name = "Tundra Mantle"
		self.slot = SLOT_ARMOR
		self.duration = 3
		self.radius = 5
		self.tag_bonuses[Tags.Ice]['max_charges'] = 2
		self.resists[Tags.Ice] = 50
		self.tags = [Tags.Ice]
		self.recipe = [(Tags.Ice, 2), (Tags.Any, 4)]

	def get_description(self):
		return "Each turn, soaked enemies within [{radius}:radius] tiles are [frozen] for [{duration}:duration] turns"

	def on_advance(self):
		dur = self.get_stat('duration')
		for u in self.owner.level.get_units_in_ball(self.owner, self.get_stat('radius')):
			if not are_hostile(self.owner, u): continue
			if not u.get_buff(SoakedBuff): continue
			u.apply_buff(FrozenBuff(), dur)
			self.do_ui_flash()

class HellfireMantle(Equipment):

	def on_init(self):
		self.name = "Hellfire Mantle"
		self.slot = SLOT_ARMOR
		self.damage = 3
		self.radius = 4
		self.tags = [Tags.Dark, Tags.Fire]
		self.recipe = [(Tags.Dark, 2), (Tags.Fire, 2), (Tags.Any, 2)]
		for tag in self.tags:
			self.resists[tag] = 50
			self.tag_bonuses[tag]['max_charges'] = 1

	def get_description(self):
		return "Each turn, deal [{damage}:damage] [Fire] damage to other units within [{radius}:radius] tiles"

	def on_advance(self):
		dmg = self.get_stat('damage')
		for u in self.owner.level.get_units_in_ball(self.owner, self.get_stat('radius')):
			if u == self.owner: continue
			u.deal_damage(dmg, Tags.Fire, self)


class BalorsEyeStaff(Equipment):

	def on_init(self):
		self.name = "Balor's Eye Staff"
		self.slot = SLOT_WEAPON
		self.description = "When you deal damage with an [Eye] spell, deal that much damage again but in a beam to the target, destroying walls and clouds in the way"
		self.global_triggers[EventOnDamaged] = self.on_damaged
		self.tags = [Tags.Eye]
		self.recipe = [(Tags.Eye, 3), (Tags.Any, 5)]

	def on_damaged(self, evt):
		if not evt.source: return
		if not hasattr(evt.source, 'tags'): return
		if not isinstance(evt.source, Spell): return
		if Tags.Eye not in evt.source.tags: return
		if not evt.source.owner: return
		if evt.source.owner != self.owner: return
		self.owner.level.queue_spell(self.do_beam(evt))
		self.do_ui_flash()

	def do_beam(self, evt):
		owner = self.owner
		level = owner.level
		damage = evt.damage
		dtype = evt.damage_type

		for point in Bolt(level, Point(owner.x, owner.y), Point(evt.unit.x, evt.unit.y), two_pass=False, find_clear=False):
			level.deal_damage(point.x, point.y, damage, dtype, self)
			if not level.tiles[point.x][point.y].can_see: level.make_floor(point.x, point.y)
			cloud = level.tiles[point.x][point.y].cloud
			if cloud: cloud.kill()
			yield

class WyrmSpiritArmorBuff(Buff):

	def __init__(self, tag):
		Buff.__init__(self)
		self.buff_type = BUFF_TYPE_BLESS
		self.name = tag.name + " Wyrm Spirit Armor"
		self.color = tag.color
		self.resists[tag] = 10
		self.stack_type = STACK_INTENSITY

class WyrmSpiritArmor(Equipment):

	def on_init(self):
		self.name = "Wyrm Spirit Armor"
		self.slot = SLOT_ARMOR
		self.description = "When one of your [Dragon] allies dies, gain 10% resistance to damage types matching their tags\nResets each level"
		self.tag_bonuses[Tags.Dragon]['max_charges'] = 2
		self.global_triggers[EventOnDeath] = self.on_death
		self.tags = [Tags.Dragon]
		self.recipe = [(Tags.Conjuration, 1), (Tags.Dragon, 2), (Tags.Holy, 1), (Tags.Any, 3)]

	def on_death(self, evt):
		if are_hostile(evt.unit, self.owner): return
		if not Tags.Dragon in evt.unit.tags: return
		self.do_ui_flash()
		for tag in evt.unit.tags:
			if tag in damage_tags: # if you can have resistances to it and its in the dragon's tags
				self.owner.apply_buff(WyrmSpiritArmorBuff(tag))

class NeanderthalsTooth(Equipment):

	def on_init(self):
		self.name = "Neanderthal's Tooth"
		self.asset_name = 'neanderthals_tooth'
		self.tag_bonuses[Tags.Metallic]['requires_los'] = -1
		self.tag_bonuses[Tags.Slime]['quick_cast'] = 1
		self.tag_bonuses[Tags.Blood]['radius'] = 1
		self.tags = [Tags.Blood, Tags.Metallic, Tags.Slime]
		self.recipe = [(Tags.Blood, 1), (Tags.Metallic, 1), (Tags.Slime, 1), (Tags.Any, 2)]

class EyeOfTamtu(Equipment):

	def on_init(self):
		self.name = "Eye of Tamtu"
		self.tag_bonuses_pct[Tags.Dragon]['minion_health'] = 100
		self.tag_bonuses_pct[Tags.Chaos]['damage'] = 100
		self.tag_bonuses_pct[Tags.Eye]['duration'] = 100
		self.tags = [Tags.Chaos, Tags.Dragon, Tags.Eye]
		self.recipe = [(Tags.Chaos, 1), (Tags.Dragon, 1), (Tags.Eye, 1), (Tags.Any, 2)]

class EyeOfMot(Equipment):

	def on_init(self):
		self.name = "Eye of Mot"
		self.tags = [Tags.Dark, Tags.Eye]
		self.recipe = [(Tags.Dark, 2), (Tags.Eye, 1), (Tags.Any, 2)]
		self.global_triggers[EventOnDamaged] = self.on_damage

	def get_description(self):
		return "Redeal half the damage dealt by [Eye] spells as [Dark] damage"

	def on_damage(self, evt):
		if not evt.source or not evt.source.owner: return
		if not isinstance(evt.source, Spell): return
		if not Tags.Eye in evt.source.tags: return
		if evt.damage < 2: return # omits healing (negative dmg) and instances of 1 that would round to 0
		evt.unit.deal_damage(evt.damage // 2, Tags.Dark, self)
		self.do_ui_flash()

class EyeOfJudgementBuff(Buff):

	def __init__(self, source):
		Buff.__init__(self)
		self.name = "Eye of Judgement"
		self.color = Tags.Holy.color
		self.stack_type = STACK_DURATION
		self.spell = source

	def get_description(self):
		return "Deal [{damage}:damage] [Holy] damage to the lowest HP enemy in your line of sight each turn", {'damage': self.spell.get_stat('damage')}

	def on_advance(self):
		enemies = [u for u in self.owner.level.get_units_in_los(self.owner) if are_hostile(self.owner, u)]
		if not enemies: return
		u = min(enemies, key= lambda e: (e.cur_hp, random.random())) # min compares first value first, then uses random.random as a tiebreaker.
		self.owner.level.show_beam(self.owner, u, Tags.Holy)
		u.deal_damage(self.spell.get_stat('damage'), Tags.Holy, self.spell)

class EyeOfAmmut(Equipment):

	def on_init(self):
		self.name = "Eye of Ammut"
		self.tags = [Tags.Eye, Tags.Holy]
		self.recipe = [(Tags.Eye, 1), (Tags.Holy, 2), (Tags.Any, 2)]
		self.owner_triggers[EventOnSpellCast] = self.on_cast
		self.damage = 30
		self.duration = 3
		self.add_effect_tooltip(lambda: EyeOfJudgementBuff(self))

	def get_description(self):
		return ("When you cast an [Eye] spell, gain [Eye of Judgement:holy] for [{duration}:duration] turns\n"
				"[Eye of Judgement:holy] deals [{damage}:damage] [Holy] damage to the lowest HP enemy in your line of sight each turn")

	def on_cast(self, evt):
		if Tags.Eye not in evt.spell.tags: return
		self.owner.apply_buff(EyeOfJudgementBuff(self), self.get_stat('duration'))
		self.do_ui_flash()


class ArcaneAccelerator(Equipment):

	def on_init(self):
		self.name = "Arcane Accelerator"
		self.description = "Each turn, allies in your line of sight have their current spell cooldowns reduced by 1"
		self.tags = [Tags.Arcane]
		self.recipe = [(Tags.Arcane, 2), (Tags.Word, 1), (Tags.Any, 4)]

	def on_advance(self):
		allies = [u for u in self.owner.level.get_units_in_los(self.owner) if not are_hostile(u, self.owner) and u != self.owner]
		for u in allies:
			for s in list(u.cool_downs):
				if u.cool_downs[s] > 1:
					u.cool_downs[s] -= 1
					self.do_ui_flash()

class PulseAccelerator(Equipment):

	def on_init(self):
		self.name = "Pulse Accelerator"
		self.tags = [Tags.Blood]
		self.recipe = [(Tags.Blood, 1), (Tags.Enchantment, 1), (Tags.Lightning, 1), (Tags.Translocation, 1), (Tags.Any, 4)]
		self.owner_triggers[EventOnSpellCast] = self.on_cast
		self.duration = 2

	def get_description(self):
		return "Casting a [Blood] spell grants you [{duration}:duration] turns of [quickstep:translocation] and quickcast on all spells"

	def on_cast(self, evt):
		if Tags.Blood in evt.spell.tags:
			self.owner.apply_buff(QuickmoveBuff(), self.get_stat('duration'))
			self.owner.apply_buff(QuickcastingBuff(), self.get_stat('duration'))
			self.do_ui_flash()

class QuickstepBoots(Equipment):

	def on_init(self):
		self.name = "Quickstep Boots"
		self.description = "Walking only takes half of your turn"
		self.slot = SLOT_BOOTS
		self.tags = [Tags.Translocation]
		self.recipe = [(Tags.Enchantment, 1), (Tags.Translocation, 2), (Tags.Any, 1)]

	def on_applied(self, owner):
		self.owner.quick_move += 1

	def on_unapplied(self):
		self.owner.quick_move -= 1

class CultistsStaff(Equipment):

	def on_init(self):
		self.name = "Cultist's Staff"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Blood, Tags.Dark]
		self.recipe = [(Tags.Blood, 2), (Tags.Dark, 1), (Tags.Any, 4)]
		self.global_triggers[EventOnLevelComplete] = self.on_complete
		self.owner_triggers[EventOnUnitAdded] = self.on_unit_added
		self.active = True

	def get_description(self):
		return "Each turn, pay [1 HP:blood] to deal [Dark] [damage] equal to your missing HP to the nearest enemy"

	def on_advance(self):
		if not self.active: return
		self.owner.level.queue_spell(self.do_damage())
		self.do_ui_flash()

	def do_damage(self):
		o = self.owner
		lvl = self.owner.level

		hp_cost = 1
		if o.cur_hp <= hp_cost: return # return if you can't afford to pay life

		candidates = lvl.get_units_by_distance(o, enemy=True)
		if not candidates: return
		unit = candidates[0]

		# spend the hp
		o.cur_hp -= hp_cost
		lvl.log(("[{unit}:{color}] paid {amount} HP to activate their {item}", {"unit": o.name, "color": log_color(o), "amount": hp_cost, "item": self.name}))
		lvl.event_manager.raise_event(EventOnSpendHP(o, hp_cost), o)
		lvl.show_effect(o.x, o.y, Tags.Blood, minor=True)


		o.level.show_path_effect(o, unit, Tags.Dark, minor=True)
		missing_hp = o.max_hp - o.cur_hp
		unit.deal_damage(missing_hp, Tags.Dark, self)
		yield

	def on_unit_added(self, _u):
		self.active = True

	def on_complete(self, _lvl):
		self.active = False

	def on_equip(self, owner):
		if not owner.is_player_controlled: return
		if owner.game.level_cleared: self.active = False

class CodexOfChaoticEvolution(Equipment):

	def on_init(self):
		self.name = "Codex of Chaotic Evolution"
		self.description = ("At the beginning of each level, one of your spells receives a random upgrade\n"
							"This effect can grant upgrades to any [Sorcery] or [Chaos] spell that doesn't have all of its upgrades")
		self.owner_triggers[EventOnUnitAdded] = self.on_added
		self.tags = [Tags.Sorcery, Tags.Chaos]
		self.recipe = [(Tags.Conjuration, 1), (Tags.Enchantment, 2), (Tags.Holy, 1), (Tags.Nature, 1), (Tags.Slime, 1), (Tags.Translocation, 2)] # TZEENTCH

	def on_added(self, evt):
		if not self.owner.is_player_controlled: return
		spells = [s for s in self.owner.spells if (Tags.Sorcery in s.tags or Tags.Chaos in s.tags) and not self.owner.game.spell_is_upgraded(s, limit=False) and self.available_upgrades(s)]
		if not spells: return
		spell = random.choice(spells)
		upgrade = random.choice(self.available_upgrades(spell))
		if isinstance(upgrade, Upgrade): self.owner.apply_buff(upgrade)
		self.owner.level.log(("Codex of Chaotic Evolution upgraded {spell} with {upgrade}", {'spell':spell.name, 'upgrade':upgrade.name}))
		spell.do_ui_flash(Tags.Chaos)
		self.do_ui_flash()

	def available_upgrades(self, spell):
		available_upgrades = [u for u in spell.spell_upgrades if u not in self.owner.get_spell_upgrades()]
		return available_upgrades

class OrbOfInfiniteSlaughter(Equipment):

	def on_init(self):
		self.name = "Orb of Infinite Slaughter"
		self.global_triggers[EventOnDeath] = self.on_death
		self.tags = [Tags.Blood, Tags.Dark]
		self.recipe = [(Tags.Chaos, 1), (Tags.Dragon, 1), (Tags.Enchantment, 1), (Tags.Holy, 1), (Tags.Nature, 1), (Tags.Orb, 1), ] # KHORNE

	def on_death(self, evt):
		self.owner.level.queue_spell(self.explosion(evt.unit))
		self.do_ui_flash()

	def explosion(self, unit):
		dmg = self.owner.get_mastery(Tags.Blood)
		for p in self.owner.level.get_points_in_ball(unit.x, unit.y, 1, diag=True):
			self.owner.level.show_effect(p.x, p.y, Tags.Blood)
			dealt = self.owner.level.deal_damage(p.x, p.y, dmg, Tags.Dark, self)
			if dealt > 0: self.owner.heal(dealt, self)
		yield

	def get_description(self):
		desc = ["Units explode on death, dealing [Dark] damage to adjacent units\n"
				"The damage dealt is equal to your [Blood] mastery\n"
				"You heal for any damage dealt by this item"]
		if self.owner: desc.append("\n[Blood Mastery:blood]: [{mastery}:blood]")
		return desc

	def fmt_dict(self):
		d = Equipment.fmt_dict(self)
		d['mastery'] = self.owner.get_mastery(Tags.Blood) if self.owner else 0
		return d

class CystOfEternalBloom(Equipment):

	def on_init(self):
		self.name = "Cyst of Eternal Bloom"
		self.tags = [Tags.Nature, Tags.Dark]
		self.recipe = [(Tags.Dragon, 1), (Tags.Enchantment, 1), (Tags.Lightning, 1), (Tags.Nature, 1), (Tags.Ritual, 1), (Tags.Any, 1)] # NURGLE
		self.chance = 0.5

		self.duration = 7
		self.radius = 7

		self.global_triggers[EventOnUnitAdded] = self.on_added
		self.global_triggers[EventOnLevelComplete] = self.on_complete
		self.owner_triggers[EventOnUnitAdded] = self.on_owner_added

		self.active = True

	def get_description(self):
		return ("Each turn, unpoisoned units within [{radius}:radius] tiles are [poisoned] for [{duration}:duration] turns\n"
				"Summoned allies have a 50% chance to gain the ability to reincarnate on death")

	def on_owner_added(self, evt):
		self.active = True

	def on_added(self, evt):
		if random.random() > self.chance: return
		u = evt.unit
		if are_hostile(u, self.owner) or u == self.owner: return
		if u.has_buff(ReincarnationBuff): u.get_buff(ReincarnationBuff).lives += 1
		else: u.apply_buff(ReincarnationBuff())
		self.owner.level.show_effect(u.x, u.y, Tags.Buff_Apply, Tags.Dark.color)

	def on_advance(self):
		if not self.active: return
		units = self.owner.level.get_units_in_ball(self.owner, self.get_stat('radius'))
		units = [u for u in units if not u.has_buff(Poison) and u.resists[Tags.Poison] < 100]
		for u in units:u.apply_buff(Poison(), self.get_stat('duration'))
		if units: self.do_ui_flash()

	def on_complete(self, evt):
		self.active = False

	def on_equip(self, owner):
		if not owner.is_player_controlled: return
		if owner.game.level_cleared: self.active = False

class PrismOfShatteredSensations(Equipment):

	def on_init(self):
		self.name = "Prism of Shattered Sensations"
		self.duration = 1
		self.tags = [Tags.Chaos]
		self.recipe = [(Tags.Arcane, 2), (Tags.Enchantment, 1), (Tags.Holy, 1), (Tags.Lightning, 1), (Tags.Nature, 1), (Tags.Sorcery, 2)] # SLAANESH
		self.global_triggers[EventOnHealed] = self.on_healed
		self.global_triggers[EventOnDamaged] = self.on_healed

	def on_healed(self, evt):
		u = evt.unit
		if not are_hostile(u, self.owner): return
		if not u.is_alive(): return
		u.apply_buff(Stun(), self.get_stat('duration'))
		self.do_ui_flash()

	def get_description(self):
		return "When an enemy heals or takes damage they are [stunned] for [{duration}:duration] turns"

class TheNorthPole(Equipment):

	def on_init(self):
		self.name = "The North Pole"
		self.description = "When a [Metallic] unit is summoned, cast Magnetize on it"
		self.tags = [Tags.Lightning, Tags.Metallic]
		self.global_triggers[EventOnUnitAdded] = self.on_added
		self.recipe = [(Tags.Enchantment, 2), (Tags.Lightning, 2), (Tags.Metallic, 2), (Tags.Any, 4)]
		self.add_spell_tooltip(MagnetizeSpell)

	def on_added(self, evt):
		self.owner.level.queue_spell(self.do_magnetize(evt.unit))

	def do_magnetize(self, u):
		if not Tags.Metallic in u.tags: return
		o = self.owner
		spell = o.get_or_make_spell(MagnetizeSpell)
		spell.do_ui_flash()
		o.level.act_cast(o, spell, u.x, u.y, pay_costs=False, queue=True)
		self.do_ui_flash()
		yield

class ContagionCorpse(Equipment):

	def on_init(self):
		self.name = "Contagion Corpse"
		self.tags = [Tags.Dark, Tags.Nature]
		self.recipe = [(Tags.Dark, 2),(Tags.Nature, 2), (Tags.Any, 1)]
		self.radius = 3
		self.duration = 7
		self.damage = 3
		self.global_triggers[EventOnDeath] = self.on_death

	def get_description(self):
		return ("When a [poisoned] unit dies, enemies within [{radius}:radius] tiles are [poisoned] for [{duration}:duration] turns "
				"and take [{damage}:damage] [Poison] damage")

	def on_death(self, evt):
		u = evt.unit
		if not u: return
		if not u.has_buff(Poison): return
		u.level.queue_spell(self.contagion(u.x, u.y))
		self.do_ui_flash()

	def contagion(self, x, y):
		o = self.owner
		lvl = o.level
		dur = self.get_stat('duration')
		dmg = self.get_stat('damage')
		for u in lvl.get_units_in_ball(Point(x, y), self.get_stat('radius')):
			if not u.is_alive() or are_friendly(u, o): continue
			lvl.show_path_effect(Point(x, y), u, Tags.Poison)
			u.apply_buff(Poison(), dur)
			u.deal_damage(dmg, Tags.Poison, self)
			yield

class Tome(Equipment):

	def __init__(self, tag):
		Equipment.__init__(self, tag)
		self.tag = tag
		self.tags = [tag]
		self.recipe = [(tag, 2), (Tags.Any, 2)]
		self.tag_bonuses_pct[tag]['max_charges'] = 50
		self.name = f"{tag.name} Tome"

class SpawningVenom(Equipment):

	def on_init(self):
		self.name = "Spawning Venom"
		self.tags = [Tags.Nature, Tags.Conjuration]
		self.recipe = [(Tags.Conjuration, 1), (Tags.Nature, 1), (Tags.Any, 3)]
		self.global_triggers[EventOnDeath] = self.on_death

		self.minion_health = 14
		self.minion_damage = 2
		self.duration = 10

	def get_extra_examine_tooltips(self):
		return [self.make_spider()]

	def get_description(self):
		return "When an enemy dies to [Poison] damage, summon a Giant Spider nearby"

	def make_spider(self):
		u = GiantSpider()
		u.spells[0].buff_duration = self.get_stat('duration')
		apply_minion_bonuses(self, u)
		return u

	def on_death(self, evt):
		if not evt.damage_event: return
		if evt.damage_event.damage_type != Tags.Poison: return
		if are_friendly(self.owner, evt.unit): return
		self.summon(self.make_spider(), target=evt.unit)
		self.do_ui_flash()

class ChaosSerpentStaff(Equipment):
	def on_init(self):
		self.name = "Chaos Serpent Staff"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Chaos, Tags.Dragon]
		self.recipe =[(Tags.Chaos, 1), (Tags.Conjuration, 2), (Tags.Dragon, 2), (Tags.Any, 2)]
		self.global_triggers[EventOnDamaged] = self.on_damage

		self.minion_health = 9
		self.minion_damage = 5
		self.minion_range = 3
		self.minion_duration = 3

	def get_description(self):
		return "When you deal [{minion_health}:minion_health] or more [Fire], [Lightning], or [Physical] damage, summon a corresponding snake for [{minion_duration}:minion_duration] turns"

	def get_extra_examine_tooltips(self):
		return [make_minion(self, Snake), make_minion(self, GoldenSnake), make_minion(self, FireSnake)]

	def on_damage(self, evt):
		if not evt.source: return
		if evt.source.owner != self.owner: return
		if evt.damage < self.get_stat('minion_health'): return
		dt = evt.damage_type
		if dt not in [Tags.Physical, Tags.Fire, Tags.Lightning]: return
		if dt == Tags.Lightning: snake = GoldenSnake()
		elif dt == Tags.Fire: snake = FireSnake()
		else: snake = Snake()
		apply_minion_bonuses(self, snake)
		snake.turns_to_death = self.get_stat('minion_duration')
		self.summon(snake, target=evt.unit)
		self.do_ui_flash()

class StormCallerStaff(Equipment):

	def on_init(self):

		self.name = "Storm Caller Staff"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Ice, Tags.Lightning, Tags.Nature]
		self.recipe = [(Tags.Ice, 2), (Tags.Lightning, 2), (Tags.Nature, 1), (Tags.Any, 2)]
		self.global_triggers[EventOnDamaged] = self.on_damage

		self.duration = 2
		self.damage = 5

	def get_description(self):
		return ("When enemies take [Ice] or [Lightning] damage, create a corresponding [Blizzard:ice] or [Storm Cloud:lightning] nearby\n"
				"[Blizzards:ice] deal [{damage}:damage] [Ice] damage and may [freeze] enemies\n"
				"[Storm Cloud:lightning] strike inconsistently and deal twice as much [Lightning] damage\n"
				"Clouds last [{duration}:duration] turns")

	def get_thunder(self):
		cloud = StormCloud(self.owner)
		cloud.damage =  2 * self.get_stat('damage')
		cloud.duration = self.get_stat('duration')
		return cloud

	def get_blizzard(self):
		cloud = BlizzardCloud(self.owner)
		cloud.damage = self.get_stat('damage')
		cloud.duration = self.get_stat('duration')
		return cloud

	def on_damage(self, evt):
		if not are_hostile(self.owner, evt.unit): return
		if evt.damage_type is Tags.Ice: cloud = self.get_blizzard()
		elif evt.damage_type is Tags.Lightning: cloud = self.get_thunder()
		else: return
		cloud.source = self

		if not self.owner.level.tiles[evt.unit.x][evt.unit.y].cloud: # cloud on them if there isn't one already.
			self.owner.level.add_obj(cloud, evt.unit.x, evt.unit.y)
			self.do_ui_flash()
		else:
			possible_points = self.owner.level.get_points_in_ball(evt.unit.x, evt.unit.y, 1, diag=True)
			def can_cloud(p):
				tile = self.owner.level.tiles[p.x][p.y]
				if tile.cloud: return False
				if tile.is_wall(): return False
				return True

			possible_points = [p for p in possible_points if can_cloud(p)]
			if possible_points:
				point = random.choice(possible_points)
				self.owner.level.add_obj(cloud, point.x, point.y)
				self.do_ui_flash()

class VoodooBound(Buff):

	def __init__(self, origin):
		Buff.__init__(self)
		self.origin = origin

	def on_init(self):
		self.name = "Voodoo Bound"
		self.color = Tags.Blood.color
		self.description = "Damage dealt to the holder of the Voodoo Doll is also dealt to you"
		self.buff_type = BUFF_TYPE_CURSE
		self.stack_type = STACK_INTENSITY

	def on_unapplied(self):
		self.origin.bound.discard(self.owner)

class VoodooDoll(Equipment):

	def on_init(self):
		self.name = "Voodoo Doll"
		self.num_targets = 5
		self.tags = [Tags.Blood, Tags.Enchantment]
		self.recipe = [(Tags.Blood, 1), (Tags.Enchantment, 1), (Tags.Any, 2)]

		self.bound = set()
		self.owner_triggers[EventOnUnitAdded] = self.on_added
		self.owner_triggers[EventOnDamaged] = self.on_damaged
		self.owner_triggers[EventOnSpendHP] = self.on_spend
		self.add_effect_tooltip(lambda: VoodooBound(self))

	def get_description(self):
		return ("At the beginning of each level, the [{num_targets}:num_targets] enemies with the highest HP are [Voodoo Bound:blood]\n"
				"When you take damage, [Voodoo Bound:blood] enemies take that damage\n"
				"When you spend HP, [Voodoo Bound:blood] deals that much [Physical:physical] damage to enemies")

	def on_spend(self, evt):
		lvl = self.owner.level

		for t in list(self.bound): # quick check the list
			if not t.is_alive() or t.level is not lvl:
				self.bound.discard(t)
				continue

		for t in self.bound: lvl.queue_spell(self.do_voodoo(target=t, dmg = evt.hp, dtype=Tags.Physical))

	def clear_bound(self):
		for t in list(self.bound):
			b = t.get_buff(VoodooBound)
			if b: t.remove_buff(b)
		self.bound.clear()

	def on_unapplied(self):
		self.clear_bound()

	def on_added(self, evt):
		o = self.owner
		lvl = o.level
		self.clear_bound()
		targets = [u for u in lvl.units if are_hostile(u, o) and not u.get_buff(VoodooBound)] # enemies that don't already have it (for dupe purposes)
		if not targets: return
		targets.sort(key=lambda u : u.max_hp, reverse=True)
		num = min(len(targets), self.get_stat('num_targets'))
		targets = targets[:num]
		for t in targets: lvl.queue_spell(self.do_binding(o, t, lvl))

	def do_binding(self, o, t, lvl):
		lvl.show_path_effect(o, t, Tags.Blood)
		t.apply_buff(VoodooBound(self))
		self.bound.add(t)
		yield

	def on_damaged(self, evt):
		if evt.damage < 1: return # dont propagate healing or null damage
		lvl = self.owner.level

		for t in list(self.bound): # quick check the list
			if not t.is_alive() or t.level is not lvl:
				self.bound.discard(t)
				continue

		for t in self.bound:
			lvl.queue_spell(self.do_voodoo(target=t, dmg = evt.damage, dtype=evt.damage_type))
			self.do_ui_flash()

	def do_voodoo(self, target, dmg, dtype):
		if not target.is_alive(): return
		self.owner.level.show_path_effect(self.owner, target, Tags.Blood)
		target.deal_damage(dmg, dtype, self)
		yield

class OnPickupTriggerEquipment(Equipment):

	def __init__(self):
		self.on_pickup_components = []
		self.stored_components = []
		Equipment.__init__(self)

	def on_applied(self, owner):
		self.store_components()

	def store_components(self):
		if self.stored_components: return
		for component, val in self.crafting_input_fns.items():
			is_on_pickup = component.on_pickup != Component.on_pickup
			for i in range(val):
				c = component()
				self.stored_components.append(c) # stash an instance of each of the components in here
				if not is_on_pickup: continue
				self.on_pickup_components.append(c)  # stash specifically the on_pickup components here
				add_tooltip(self, c)  # so you can see everything you're going to trigger

	def trigger_component_on_pickup(self, player, component):
		self.do_ui_flash()
		component.on_pickup(player, player.level)
		self.log_trigger(component)

	def log_trigger(self, component):
		self.owner.level.log(("{equipment} triggered {component}", {"equipment": self.name, "component": component.name}))

class ArtificersChalice(OnPickupTriggerEquipment):

	def on_init(self):
		self.name = "Artificer's Chalice"
		self.recipe = [(Tags.Any, 8)]
		self.tags = [Tags.Ritual]
		self.global_triggers[EventOnItemPickup] = self.on_sp_pickup
		self.description = "Picking up a Memory Orb randomly triggers the on pickup effect of one of the components used to craft Artificer's Chalice"

	def on_sp_pickup(self, evt):
		if not isinstance(evt.item, MemoryOrb): return
		if not self.on_pickup_components: return
		self.trigger_component_on_pickup(self.owner, random.choice(self.on_pickup_components))


class ArtificersRod(OnPickupTriggerEquipment):

	def on_init(self):
		self.name = "Artificer's Rod"
		self.recipe = [(Tags.Any, 7)]
		self.tags = [Tags.Ritual]

		self.reqs = defaultdict(int)
		self.cur = defaultdict(int)
		self.activated_this_level = False
		self.owner_triggers[EventOnSpellCast] = self.on_cast


	def on_applied(self, owner):
		super().on_applied(owner)
		self.reqs.clear()
		self.cur.clear()
		self.activated_this_level = False

		for component in self.stored_components:
			for tag in component.tags: self.reqs[tag] += 1

	def on_cast(self, evt):
		if self.activated_this_level: return
		if not self.on_pickup_components: return
		for t in evt.spell.tags: # for each of the spell's tags
			if t in self.reqs.keys(): # if the tag is in the requirements
				if self.cur[t] < self.reqs[t]: # and the requirement hasn't yet been met
					self.cur[t] += 1 # increment
				if all(self.cur[tag] >= req for tag, req in self.reqs.items()): # if all requirements are met
					self.trigger_component_on_pickups(self.owner) # trigger
					return

	def trigger_component_on_pickups(self, player):
		self.activated_this_level = True
		for c in self.on_pickup_components: self.trigger_component_on_pickup(player, c)

	def get_description(self):
		desc = ["Casting spells with tags that match the components used to craft Artificer's Rod recharges it"
				"\nOnce all tag requirements are satisfied, trigger the on pickup effect of each of the components used to craft it"
				"\nCan activate once per level"]
		if not self.reqs: return desc

		desc.append("\nRequirements:")
		for tag, need in sorted(self.reqs.items(), key=lambda kv: tag_label(kv[0])):
			filled = min(self.cur[tag], need)
			if filled >= need:
				desc.append(("\n[{label}:{key}] {filled}/{need}", { "label": tag_label(tag), "key": tag_key(tag), "filled": filled, "need": need}))
			else: desc.append(f"\n{tag_label(tag)} {filled}/{need}")
		return desc

class ArtificersAbacus(OnPickupTriggerEquipment):

	def on_init(self):
		self.name = "Artificer's Abacus"
		self.recipe = [(Tags.Any, 6)]
		self.tags = [Tags.Ritual]
		self.owner_triggers[EventOnSpellCast] = self.on_cast
		self.owner_triggers[EventOnUnitAdded] = self.on_added
		self.charge_count = 0

	def get_description(self):
		return ("When you manually cast a spell, manipulate the abacus\n"
				"If the spell's level is odd, subtract that many beads\n"
				"If the spell's level is even, add that many beads\n"
				"When the number of beads on the abacus equals the realm number, reset the abacus and trigger the on pickup effect of one of the components used to craft it\n"
				"The Artificer's Abacus can only be activated while the turn number is less than the realm number\n\n"
				"Current Beads: {charges}", {'charges':self.charge_count})

	def on_added(self, evt):
		self.charge_count = 0

	def on_cast(self, evt):
		if not evt.pay_costs: return
		if self.owner.level.turn_no >= self.owner.level.level_no: return

		l = evt.spell.level
		if not l: return
		if l % 2: # if odd
			if self.charge_count <= 0: return # if no charges, get out
			self.charge_count = max(0, self.charge_count - l) # otherwise, subtract to min 0
		else: self.charge_count += l # otherwise add

		if self.charge_count != self.owner.level.level_no: return
		self.charge_count = 0
		if not self.on_pickup_components: return
		self.trigger_component_on_pickup(self.owner, random.choice(self.on_pickup_components))

class ArtificersHammer(OnPickupTriggerEquipment):

	def on_init(self):
		self.name = "Artificer's Hammer"
		self.recipe = [(Tags.Any, 5)]
		self.tags = [Tags.Ritual]
		self.owner_triggers[EventOnBuffApply] = self.on_buff
		self.owner_triggers[EventOnUnitAdded] = self.on_added
		self.available_components = []

	def on_applied(self, owner):
		super().on_applied(owner)
		self.available_components.clear()

	def on_added(self, evt):
		self.available_components = self.on_pickup_components.copy()
		random.shuffle(self.available_components)

	def get_description(self):
		return ("When you gain a piece of equipment, trigger the on pickup effect of one of the components used to craft Artificer's Hammer\n"
				"The Artificer's Hammer can trigger each of its stored components once per level\n\n"
				"Remaining Components: {remaining} / {total}", {"remaining":len(self.available_components), "total":len(self.on_pickup_components)})

	def on_buff(self, evt):
		if evt.buff is self: return
		if evt.buff.buff_type != BUFF_TYPE_ITEM: return
		if not self.available_components: return
		self.trigger_component_on_pickup(self.owner, self.available_components.pop())

class ArtificersMirror(OnPickupTriggerEquipment):

	def on_init(self):
		self.name = "Artificer's Mirror"
		self.recipe = [(Tags.Any, 9)]
		self.tags = [Tags.Ritual]
		self.owner_triggers[EventOnItemPickup] = self.on_item

	def get_description(self):
		return ("When you pick up a component, trigger the on pickup effect of one of the components used to craft Artificer's Mirror\n"
				"If the picked up component matches one of the components used to craft Artificer's Mirror, gain a copy of it instead")

	def on_item(self, evt):
		if not isinstance(evt.item, ComponentPickup): return
		if type(evt.item.component) in self.crafting_input_fns:
			self.owner.add_component(type(evt.item.component)())
			self.do_ui_flash()
			return
		if not self.on_pickup_components: return
		self.trigger_component_on_pickup(self.owner, random.choice(self.on_pickup_components))


class PhilosophersStone(Equipment):

	def on_init(self):
		self.name = "Philosopher's Stone"
		self.tags = [Tags.Sorcery]
		self.recipe = [(Tags.Any, 10)]
		self.owner_triggers[EventOnSpellCast] = self.on_cast

	def get_description(self):
		return ("This item gains the tags of the components used to craft it\n"
				"When you cast a spell that shares a tag with this item, there is a 10% chance for all of your spells to regain a charge")

	def on_pre_craft(self, player):
		for component, val in self.crafting_input_fns.items():
			c = component()
			for t in c.tags:
				if t not in self.tags:
					self.tags.append(t)

	def on_cast(self, evt):
		shared = [t for t in evt.spell.tags if t in self.tags]
		if not shared: return
		if random.random() > .1: return
		for s in self.owner.spells: s.refund_charges(1); s.do_ui_flash(random.choice(shared))
		self.do_ui_flash()

class MagicWand(Equipment):

	def on_init(self):
		self.name = "Magic Wand"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Sorcery]
		self.recipe = [(Tags.Any, 5)]
		self.owner_triggers[EventOnSpellCast] = self.on_cast
		self.damage = 3

	def get_description(self):
		return ("This item gains the tags of the components used to craft it\n"
				"When you cast a spell, for each tag it shares with this item, shoot a [{damage}:damage] damage bolt at a random enemy in your line of sight\n"
				"If the shared tag is also a damage type, the bolt deals that type of damage, otherwise a random damage type is chosen")

	def on_pre_craft(self, player):
		for component, val in self.crafting_input_fns.items():
			c = component()
			for t in c.tags:
				if t not in self.tags:
					self.tags.append(t)

	def on_cast(self, evt):
		shared = [t for t in evt.spell.tags if t in self.tags]
		if not shared: return
		self.owner.level.queue_spell(self.bolts(shared))
		self.do_ui_flash()

	def bolts(self, shared_tags):
		owner = self.owner
		candidates = [u for u in owner.level.get_units_in_los(owner) if are_hostile(owner, u)]
		if not candidates: return

		dtypes = []
		for t in shared_tags:
			if t in damage_tags: dtypes.append(t)
			else: dtypes.append(random.choice(damage_tags))


		show_beam = owner.level.show_beam
		damage = self.get_stat('damage')
		for dtype in dtypes:
			while candidates:
				target = random.choice(candidates)
				if target.is_alive(): break
				candidates.remove(target)
			if not candidates: break
			show_beam(owner, target, dtype)
			target.deal_damage(damage, dtype, self)
			yield

class DragonspineCloak(Equipment):

	def on_init(self):
		self.name = "Dragonspine Cloak"
		self.slot = SLOT_ARMOR
		self.tags = [Tags.Dragon]
		self.recipe = [(Tags.Dragon, 2), (Tags.Metallic, 1), (Tags.Any, 6)]
		self.description = "Gain +5% to all resistances for each [Dragon] tag in the components used to craft this item"
		self.activated = False

	def on_applied(self, owner):
		if self.activated: return
		bonus = 5
		for entry in self.crafting_input_fns.items(): # for each type, amount of components used in the crafting
			c, val = entry
			dragon_ct = sum(1 for t in c().tags if t == Tags.Dragon)
			if dragon_ct:
				for dtype in damage_tags: # for each damage type
					self.resists[dtype] += bonus * val * dragon_ct # add resistance equal to the number of that kind of component * how many of them were used.
		self.activated = True

class RechargeOnKillEquipment(Equipment):

	def __init__(self, name, unit_tag, spell_tag):
		Equipment.__init__(self, name, unit_tag, spell_tag)
		self.name = f"{name} Hunter's Sigil"
		self.unit_tag = unit_tag
		self.spell_tag = spell_tag
		if unit_tag == Tags.Living: unit_tag = Tags.Nature
		self.tags = [spell_tag, unit_tag] if spell_tag != unit_tag else [spell_tag]
		self.recipe = [(spell_tag, 2), (unit_tag, 2), (Tags.Any, 6)]
		self.global_triggers[EventOnDeath] = self.on_death
		self.global_triggers[EventOnLevelComplete] = self.on_complete

	def on_complete(self, evt):
		target = None
		candidate_tiles = [t for t in self.owner.level.iter_tiles() if not t.prop and t.can_walk]
		if not candidate_tiles: return # failed to make a portal due to lack of space
		random.shuffle(candidate_tiles)
		for t in candidate_tiles:
			path = self.owner.level.find_path(self.owner, Point(t.x, t.y), self.owner, pythonize=True, unit_penalty=0)
			if path: target = t ; break
		if target is None: target = random.choice(candidate_tiles) # still make one somewhere even if we can't reach it, should be able to reroll it
		self.owner.level.add_portal(Portal(self.owner.level.gen_params.make_child_generator(forced_tag=self.unit_tag)), target.x, target.y, locked=False)
		self.owner.level.show_path_effect(self.owner, target, Tags.Translocation, minor=True)

	def get_description(self):
		return (("For every [{unit_tag}:{unit_tag_key}] unit that dies, one of your [{spell_tag}] spells regains 1 charge"
				 "\nAt the end of each level, a Rift containing [{unit_tag}:{unit_tag_key}] enemies is created"),
				{"unit_tag":tag_label(self.unit_tag), 'unit_tag_key':tag_key(self.unit_tag), "spell_tag":self.spell_tag.name})

	def on_death(self, evt):
		if self.unit_tag not in evt.unit.tags: return
		opts = [s for s in self.owner.spells if self.spell_tag in s.tags and s.cur_charges < s.get_stat('max_charges')]
		if not opts: return
		s = random.choice(opts)
		s.refund_charges(1)
		s.do_ui_flash()
		self.do_ui_flash()

	def on_equip(self, owner):
		if not owner.is_player_controlled: return
		if owner.game.level_cleared: self.on_complete(None)


class ChimeraCage(Equipment):

	def on_init(self):
		self.tags = [Tags.Chaos, Tags.Arcane, Tags.Fire, Tags.Dark, Tags.Ice, Tags.Metallic, Tags.Lightning, Tags.Conjuration]
		self.recipe = [(Tags.Chaos, 1), (Tags.Conjuration, 1), (Tags.Metallic, 1), (Tags.Any, 1)]
		self.name = "Cage of Chimerae"
		self.description = "At the beginning of each level, summon a Chaos Chimera, a Deathchill Chimera, and a Starfire Chimera"
		self.spawners = [DeathchillChimera, ChaosChimera, StarfireChimera]
		self.owner_triggers[EventOnUnitAdded] = self.on_begin

		self.minion_health = 46
		self.minion_damage = 8
		self.minion_range = 5

	def on_begin(self, _):
		for chimera in self.spawners: self.summon(make_minion(self, chimera))

	def get_extra_examine_tooltips(self):
		return [make_minion(self, u) for u in self.spawners]

class QuicksilverArmor(Equipment):

	def on_init(self):
		self.name = "Quicksilver Armor"
		self.slot = SLOT_ARMOR
		self.tags = [Tags.Dark, Tags.Enchantment, Tags.Metallic]
		self.recipe = [(Tags.Dark, 1), (Tags.Enchantment, 1), (Tags.Metallic, 1), (Tags.Any, 3)]
		self.description = "Cast Mercurize on melee attackers"
		self.resists[Tags.Physical] = 50
		self.global_triggers[EventOnSpellCast] = self.on_spell
		self.add_spell_tooltip(MercurizeSpell)

	def on_spell(self, evt):
		if evt.x != self.owner.x or evt.y != self.owner.y: return
		if not (isinstance(evt.spell, LeapAttack) or isinstance(evt.spell, PullAttack) or evt.spell.melee): return
		if are_friendly(self.owner, evt.caster): return
		self.owner.level.queue_spell(self.do_cast(evt.caster))

	def do_cast(self, target):
		yield
		if not target.is_alive(): return
		spell = self.owner.get_or_make_spell(MercurizeSpell)
		for _ in self.owner.level.act_cast(self.owner, spell, target.x, target.y, pay_costs=False, queue=False): yield
		self.do_ui_flash()

class JaculusIdol(Equipment):

	def on_init(self):
		self.name = "Jaculus Idol"
		self.tags = [Tags.Dragon, Tags.Enchantment, Tags.Translocation]
		self.recipe = [(Tags.Dragon, 1), (Tags.Enchantment, 2), (Tags.Translocation, 1), (Tags.Any, 3)]
		self.description = "[Dragon] allies you summon gain [quickstep:translocation]"
		self.tag_bonuses[Tags.Dragon]['quick_cast'] = 1
		self.global_triggers[EventOnUnitAdded] = self.on_added

	def on_added(self, evt):
		if are_hostile(evt.unit, self.owner): return
		if Tags.Dragon not in evt.unit.tags: return
		if evt.unit.has_buff(QuickmoveBuff): return
		evt.unit.apply_buff(QuickmoveBuff())
		self.owner.level.show_path_effect(self.owner, evt.unit, Tags.Translocation)

class AmphisbaenaRing(Equipment):

	def on_init(self):
		self.name = "Amphisbaena Ring"
		self.tags = [Tags.Dragon]
		self.recipe = [(Tags.Dragon, 1), (Tags.Any, 4)]
		self.description = "[Dragon] allies you summon have their cooldowns halved"
		self.global_triggers[EventOnUnitAdded] = self.on_added

	def on_added(self, evt):
		if are_hostile(evt.unit, self.owner): return
		if Tags.Dragon not in evt.unit.tags: return
		for s in evt.unit.spells:
			if s.cool_down:
				s.cool_down = int(math.ceil(s.cool_down / 2))

class HornofUr(Equipment):

	def on_init(self):
		self.name = "Horn of Ur"
		self.tags = [Tags.Dragon, Tags.Conjuration]
		self.recipe = [(Tags.Conjuration, 1), (Tags.Dragon, 1), (Tags.Translocation, 1), (Tags.Any, 3)]
		self.tag_bonuses_pct[Tags.Conjuration]['range'] = 100
		self.tag_bonuses[Tags.Dragon]['requires_los'] = -1

class RapidRitualRod(Equipment):

	def on_init(self):
		self.name = "Rapid Ritual Rod"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Ritual]
		self.recipe = [(Tags.Ritual, 2), (Tags.Any, 5)]
		self.description = "Your channeled [Ritual] spells activate an additional time each turn"

	def on_advance(self):
		b = self.owner.get_buff(ChannelBuff)
		if not b: return
		if Tags.Ritual not in b.spell.__self__.tags: return
		self.owner.level.queue_spell(self.advance_ritual(b))

	def advance_ritual(self, b, deferred=False):
		if not b.applied: return
		if b.turns_left == 1 and not deferred:
			self.owner.level.queue_spell(self.advance_ritual(b, deferred=True))
			return
		b.passed = True
		b.advance()
		self.do_ui_flash()
		yield

class PedanticPendant(Equipment):

	def on_init(self):
		self.name = "Pedantic Pendant"
		self.tags = [Tags.Word]
		self.recipe = [(Tags.Word, 1), (Tags.Any, 3)]
		self.tag_bonuses[Tags.Word]['duration'] = 3
		self.tag_bonuses[Tags.Word]['max_charges'] = 1

class VirtuousSinDamageBuff(Buff):

	def __init__(self, tag):
		Buff.__init__(self)
		self.tag = tag
		self.tag_bonuses_pct[tag]['damage'] = 25
		self.stack_type = STACK_INTENSITY
		keyword = "Sin" if tag == Tags.Dark else "Virtue"
		self.name = f"Crown of {keyword}"
		self.color = tag.color
		self.owner_triggers[EventOnSpellCast] = self.on_cast
		self.triggered = False

	def get_description(self):
		return "Removed when you cast another [{tag_label}:{tag_key}] spell", {"tag_label": tag_label(self.tag), "tag_key": tag_key(self.tag)}

	def on_cast(self, evt):
		if self.tag in evt.spell.tags: self.triggered = True

	def on_advance(self):
		if self.triggered: self.owner.remove_buff(self)

class CrownOfVirtuousSin(Equipment):

	def on_init(self):
		self.name = "Crown of Virtuous Sin"
		self.slot = SLOT_HELMET
		self.tags = [Tags.Dark, Tags.Holy]
		self.recipe = [(Tags.Dark, 2), (Tags.Holy, 2), (Tags.Any, 3)]
		self.tag_bonuses[Tags.Dark]['max_charges'] = 1
		self.tag_bonuses[Tags.Holy]['max_charges'] = 1
		self.owner_triggers[EventOnSpellCast] = self.on_cast
		self.add_effect_tooltip(lambda: VirtuousSinDamageBuff(Tags.Holy))
		self.add_effect_tooltip(lambda: VirtuousSinDamageBuff(Tags.Dark))

	def get_description(self):
		return ("Casting a [Dark] spell grants you a 25% damage bonus to [Holy] spells and equipment, removed when you cast a [Holy] spell\n"
				"Casting a [Holy] spell grants you a 25% damage bonus to [Dark] spells and equipment, removed when you cast a [Dark] spell")

	def on_cast(self, evt):
		if Tags.Dark in evt.spell.tags:
			self.owner.apply_buff(VirtuousSinDamageBuff(Tags.Holy))
			self.do_ui_flash()
		if Tags.Holy in evt.spell.tags:
			self.owner.apply_buff(VirtuousSinDamageBuff(Tags.Dark))
			self.do_ui_flash()

class RobesOfVirtuousSin(Equipment):

	def on_init(self):
		self.name = "Robes of Virtuous Sin"
		self.slot = SLOT_ARMOR
		self.tags = [Tags.Dark, Tags.Holy]
		self.recipe = [(Tags.Dark, 2), (Tags.Holy, 2), (Tags.Any, 2)]
		self.tag_bonuses[Tags.Dark]['max_charges'] = 1
		self.tag_bonuses[Tags.Holy]['max_charges'] = 1
		self.owner_triggers[EventOnSpellCast] = self.on_cast

	def get_description(self):
		return ("Casting a [Dark] spell heals you\n"
				"Casting a [Holy] spell removes debuffs from you\n"
				"Healing and debuffs removed equal the highest spell level of the opposing school\n"
				"[Heal:dark]: [{h}:holy]\n"
				"[Debuffs Removed:holy]: [{d}:dark]")

	def fmt_dict(self):
		d = Equipment.fmt_dict(self)
		d['h'] = self.owner.get_highest_spell_level(Tags.Holy) if self.owner else 0
		d['d'] = self.owner.get_highest_spell_level(Tags.Dark) if self.owner else 0
		return d

	def on_cast(self, evt):
		if Tags.Holy in evt.spell.tags:
			debuffs = [b for b in self.owner.buffs if b.buff_type == BUFF_TYPE_CURSE]
			debuffs = debuffs[:self.owner.get_highest_spell_level(Tags.Dark)]
			if debuffs: 			self.do_ui_flash()
			for d in debuffs: self.owner.remove_buff(d)
		if Tags.Dark in evt.spell.tags:
			amt = self.owner.get_highest_spell_level(Tags.Holy)
			if amt:
				self.owner.heal(amt, self)
				self.do_ui_flash()


class SandalsOfVirtuousSin(Equipment):

	def on_init(self):
		self.name = "Sandals of Virtuous Sin"
		self.slot = SLOT_BOOTS
		self.tags = [Tags.Dark, Tags.Holy, Tags.Translocation]
		self.recipe = [(Tags.Dark, 1), (Tags.Holy, 1), (Tags.Translocation, 2), (Tags.Any, 2)]
		self.tag_bonuses[Tags.Dark]['max_charges'] = 1
		self.tag_bonuses[Tags.Holy]['max_charges'] = 1
		self.radius = 2
		self.active = True

		self.owner_triggers[EventOnMoved] = self.on_move
		self.global_triggers[EventOnLevelComplete] = self.on_complete

	def get_description(self):
		return ("When you take a step, deal [Dark] and [Holy] damage to enemies within [{radius}:radius] tiles\n"
				"The damage dealt of each type is equal to the highest known spell level of the opposing school\n"
				"[Dark Damage:dark]: [{h}:holy]\n"
				"[Holy Damage:holy]: [{d}:dark]")

	def fmt_dict(self):
		d = Equipment.fmt_dict(self)
		d['d'] = self.owner.get_highest_spell_level(Tags.Dark) if self.owner else 0
		d['h'] = self.owner.get_highest_spell_level(Tags.Holy) if self.owner else 0
		return d

	def on_move(self, evt):
		if evt.teleport: return
		if not self.active: return
		self.owner.level.queue_spell(self.do_explosion())


	def on_applied(self, owner):
		self.active = True

	def on_complete(self, evt):
		self.active = False

	def do_explosion(self):
		o = self.owner
		l = o.level
		getu = l.get_unit_at
		show_effect = l.show_effect
		dark_dmg = o.get_highest_spell_level(Tags.Holy)
		holy_dmg = o.get_highest_spell_level(Tags.Dark)
		opts = [(dark_dmg, Tags.Dark), (holy_dmg, Tags.Holy)]
		for i, p in enumerate(l.get_points_in_ball(o.x, o.y, self.get_stat('radius'))):
			u = getu(p.x, p.y)
			if not u: show_effect(p.x, p.y, opts[i % 2][1], minor=True); continue
			if u == o: continue
			if not are_hostile(o, u): continue
			for damage, damage_type in opts:
				if damage: u.deal_damage(damage, damage_type, self)
		yield



class ScalesOfVirtuousSin(Equipment):

	def on_init(self):
		self.name = "Scales of Virtuous Sin"
		self.tags = [Tags.Dark, Tags.Holy]
		self.recipe = [(Tags.Dark, 2), (Tags.Holy, 2), (Tags.Any, 5)]
		self.tag_bonuses[Tags.Dark]['max_charges'] = 1
		self.tag_bonuses[Tags.Holy]['max_charges'] = 1
		self.global_triggers[EventOnDamaged] = self.on_damage

	def get_description(self):
		return ("Redeal half the damage dealt by [Holy] spells as [Dark] damage\n"
				"Redeal half the damage dealt by [Dark] spells as [Holy] damage")

	def on_damage(self, evt):
		if not evt.source or not evt.source.owner: return
		if not isinstance(evt.source, Spell): return
		if evt.damage < 2: return # omits healing (negative dmg) and instances of 1 that would round to 0
		triggered = False
		if Tags.Holy in evt.source.tags: self.owner.level.queue_spell(self.do_damage(evt.unit, evt.damage//2, Tags.Dark)); triggered = True
		if Tags.Dark in evt.source.tags: self.owner.level.queue_spell(self.do_damage(evt.unit, evt.damage//2, Tags.Holy)); triggered = True
		if triggered: self.do_ui_flash()

	def do_damage(self, unit, damage, dtype):
		unit.deal_damage(damage, dtype, self)
		yield

class CrimsonCoronet(Equipment):

	def on_init(self):
		self.name = "Crimson Coronet"
		self.slot = SLOT_HELMET
		self.tags = [Tags.Blood, Tags.Fire, Tags.Conjuration]
		self.recipe = [(Tags.Blood, 1), (Tags.Fire, 2), (Tags.Conjuration, 1), (Tags.Any, 3)]
		self.global_triggers[EventOnUnitAdded] = self.on_added
		self.radius = 2
		self.damage = 2
		self.granted = 0
		self.add_effect_tooltip(lambda: DamageAuraBuff(self.get_stat('damage'), Tags.Fire, self.get_stat('radius'), custom_name='Crimson Coronet'))

	def get_blood_mastery(self):
		return self.owner.get_mastery(Tags.Blood) if self.owner else 0

	def get_fire_mastery(self):
		return self.owner.get_mastery(Tags.Fire) if self.owner else 0

	def get_aura_cap(self):
		return self.get_blood_mastery() * self.get_fire_mastery()

	def get_description(self):
		desc = ["Grant allies a [Fire] damage aura when they are summoned\n"
				"You can grant a number of these auras each level equal to the product of your [Blood] and [Fire] masteries"]
		if self.owner:
			desc.append("\nAuras Granted: {granted} / {total}")
			desc.append("\n[Blood Mastery:blood]: [{b}:blood]")
			desc.append("\n[Fire Mastery:fire]: [{f}:fire]")
		return desc

	def fmt_dict(self):
		d = Equipment.fmt_dict(self)
		d['granted'] = self.granted
		d['total'] = self.get_aura_cap()
		d['b'] = self.get_blood_mastery()
		d['f'] = self.get_fire_mastery()
		return d

	def on_added(self, evt):
		if are_hostile(self.owner, evt.unit): return
		if evt.unit == self.owner: self.granted = 0; return
		if self.get_aura_cap() - self.granted < 1: return
		if any(b.name == 'Crimson Coronet' for b in evt.unit.buffs): return # if you duplicate it
		self.granted += 1
		self.owner.level.show_path_effect(self.owner, evt.unit, [Tags.Blood, Tags.Fire], minor=True)
		evt.unit.apply_buff(DamageAuraBuff(self.get_stat('damage'),Tags.Fire, self.get_stat('radius'), custom_name='Crimson Coronet'))
		self.do_ui_flash()

class CrimsonTorc(Equipment):

	def on_init(self):
		self.name = 'Crimson Torc'
		self.tags = [Tags.Blood, Tags.Fire, Tags.Enchantment]
		self.recipe = [(Tags.Blood, 1), (Tags.Enchantment, 2), (Tags.Fire, 1), (Tags.Any, 2)]
		self.owner_triggers[EventOnUnitAdded] = self.on_added
		self.duration = 3

	def get_description(self):
		desc = ["At the beginning of each level, gain a percent [damage] bonus to [Fire] and [Blood] spells and equipment for [{duration}:duration] turns\n"
				"The bonus is equal to the product of your [Fire] and [Blood] masteries"]
		if self.owner:
			desc.append("\nPercent Bonus: {total}%")
			desc.append("\n[Blood Mastery:blood]: [{b}:blood]")
			desc.append("\n[Fire Mastery:fire]: [{f}:fire]")
		return desc

	def fmt_dict(self):
		d = Equipment.fmt_dict(self)
		b = self.owner.get_mastery(Tags.Blood) if self.owner else 0
		f = self.owner.get_mastery(Tags.Fire) if self.owner else 0
		d['b'] = b
		d['f'] = f
		d['total'] = b * f
		return d

	def on_added(self, evt):
		b, f = self.owner.get_mastery(Tags.Blood), self.owner.get_mastery(Tags.Fire)
		if not b and not f: return
		total = b * f
		if not total: return
		buff = TagAttrBonus(Tags.Blood, 'damage', total, "Crimson Power", pct=True)
		if b: buff.tag_bonuses_pct[Tags.Fire]['damage'] = total

		self.owner.apply_buff(buff, self.get_stat('duration'))
		self.do_ui_flash()

class CrimsonBrooch(Equipment):

	def on_init(self):
		self.name = "Crimson Brooch"
		self.tags = [Tags.Blood, Tags.Fire, Tags.Sorcery]
		self.recipe = [(Tags.Blood, 1), (Tags.Fire, 1), (Tags.Sorcery, 1), (Tags.Any, 1)]
		self.owner_triggers[EventOnUnitAdded] = self.on_added
		self.owner_triggers[EventOnSpendHP] = self.on_spend
		self.counter = 0

	def get_description(self):
		return ("When you spend HP, it is stored in this item\n"
				"You gain a percent damage bonus to [Fire] spells and equipment equal to the amount stored\n"
				"Resets each level\n"
				"[HP Stored:blood]: [{counter}:blood]",
				{'counter':self.counter})

	def on_added(self, evt):
		self.delta_counter(-self.counter)

	def on_spend(self, evt):
		self.delta_counter(evt.hp)

	def delta_counter(self, amt):
		self.counter += amt
		self.tag_bonuses_pct[Tags.Fire]['damage'] = self.counter
		self.owner.adjust_tag_bonus(Tags.Fire, 'damage', amt, pct=True)
		self.do_ui_flash()


class GalvanicFocus(Equipment):

	def on_init(self):
		self.name = "Galvanic Focus"
		self.tags = [Tags.Lightning, Tags.Metallic]
		self.recipe = [(Tags.Lightning, 1), (Tags.Metallic, 1), (Tags.Any, 3)]
		for tag in self.tags:
			self.tag_bonuses[tag]['max_charges'] = 1
			self.tag_bonuses[tag]['duration'] = 3
		self.owner_triggers[EventOnSpellCast] = self.on_cast
		self.add_effect_tooltip(lambda: ResistBuff(Tags.Lightning, -25))

	def get_description(self):
		return "Targeting a [Metallic] or [Construct] enemy with a [Lightning] spell inflicts a debuff which reduces their [Lightning] resistance by 25%"

	def on_cast(self, evt):
		if Tags.Lightning not in evt.spell.tags: return
		u = self.owner.level.get_unit_at(evt.x, evt.y)
		if not u: return
		if not (Tags.Metallic in u.tags or Tags.Construct in u.tags): return
		if not are_hostile(self.owner, u): return
		self.owner.level.show_path_effect(self.owner, u, Tags.Lightning, minor=True)
		u.apply_buff(ResistBuff(Tags.Lightning, -25))
		self.do_ui_flash()

class GalvanicBlade(Equipment):

	def on_init(self):
		self.name = "Galvanic Blade"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Lightning, Tags.Metallic]
		self.recipe = [(Tags.Lightning, 2), (Tags.Metallic, 2), (Tags.Any, 3)]
		for tag in self.tags: self.tag_bonuses[tag]['damage'] = 6

	def get_description(self):
		desc = ["Each turn, deal [Physical] and [Lightning] damage to an adjacent enemy\n"
				"The damage is the product of your [Lightning] and [Metallic] masteries"]
		if self.owner:
			desc.append("\nGalvanic Damage: [{p}:damage]")
			desc.append("\n[Lightning Mastery:lightning]: [{l}:lightning]")
			desc.append("\n[Metallic Mastery:metallic]: [{m}:metallic]")
		return desc

	def fmt_dict(self):
		d = Equipment.fmt_dict(self)
		d['p'] = self.get_damage()
		d['l'] = self.owner.get_mastery(Tags.Lightning) if self.owner else 0
		d['m'] = self.owner.get_mastery(Tags.Metallic) if self.owner else 0
		return d

	def get_damage(self):
		if not self.owner: return 0
		return self.owner.get_mastery(Tags.Lightning) * self.owner.get_mastery(Tags.Metallic)

	def on_advance(self):
		dmg = self.get_damage()
		if not dmg: return
		targets = [unit for unit in self.owner.level.get_adjacent_units(self.owner) if are_hostile(unit, self.owner)]
		if targets:
			target = random.choice(targets)
			target.deal_damage(dmg, Tags.Physical, self)
			target.deal_damage(dmg, Tags.Lightning, self)
			self.owner.level.show_effect(target.x, target.y, Tags.GalvanicBlade, speed=2)
			self.do_ui_flash()


class GalvanicRedirection(Buff):

	def on_init(self):
		self.name = "Galvanic Redirection"
		self.stack_type = STACK_DURATION
		self.color = Tags.Lightning.color

	def get_description(self):
		return ("If you would take [Lightning] damage, that damage is instead redirected to a random enemy in line of sight")

	def on_applied(self, owner):
		def galvanic_handler(amount, damage_type, source, redirect_chain):
			if amount <= 0: return None
			if damage_type != Tags.Lightning: return None
			lvl = owner.level
			hostiles = [u for u in lvl.get_units_in_los(owner) if are_hostile(owner, u)]
			if not hostiles: return None
			target = random.choice(hostiles)
			for pt in lvl.get_points_in_line(owner, target, inclusive=False):
				lvl.show_effect(pt.x, pt.y, Tags.Lightning, minor=True)
			dealt = lvl.deal_redirected_damage(self, target.x, target.y, amount, damage_type, source, redirect_chain)
			return dealt

		owner.grant_redirect(self, galvanic_handler)

	def on_unapplied(self):
		self.owner.remove_redirect(self)

class GalvanicArmor(Equipment):

	def on_init(self):
		self.name = "Galvanic Armor"
		self.slot = SLOT_ARMOR
		self.tags = [Tags.Lightning, Tags.Metallic]
		self.recipe = [(Tags.Lightning, 1), (Tags.Metallic, 2), (Tags.Any, 3)]
		for tag in self.tags: self.tag_bonuses[tag]['radius'] = 1
		self.resists[Tags.Lightning] = 25
		self.resists[Tags.Physical] = 25
		self.owner_triggers[EventOnSpellCast] = self.on_cast
		self.add_effect_tooltip(GalvanicRedirection)

	def get_description(self):
		return ("When you cast a [Metallic] spell, gain Galvanic Redirection with duration equal to the spell's level\n"
				"Galvanic Redirection redirects incoming [Lightning] damage to a random enemy in line of sight")

	def on_cast(self, evt):
		if Tags.Metallic in evt.spell.tags:
			self.owner.apply_buff(GalvanicRedirection(), evt.spell.level)
			self.do_ui_flash()

class FlagellantsCup(Equipment):

	def on_init(self):
		self.name = "Flagellant's Cup"
		self.tags = [Tags.Blood, Tags.Holy]
		self.recipe = [(Tags.Blood, 1), (Tags.Holy, 1), (Tags.Any, 3)]
		self.global_triggers[EventOnLevelComplete] = self.on_complete
		self.owner_triggers[EventOnUnitAdded] = self.on_unit_added
		self.active = True

	def get_description(self):
		return "At the beginning of each turn, pay [1 HP:blood]\nIf you have any debuffs, remove one"

	# run this first so it can help us before the debuffs hurt us
	def on_pre_advance(self):
		if not self.active: return
		hp_cost = 1
		if self.owner.cur_hp <= hp_cost: return # return if you can't afford to pay life

		self.owner.cur_hp -= hp_cost
		self.owner.level.log(("[{unit}:{color}] paid {amount} HP to activate their {item}", {"unit": self.owner.name, "color": log_color(self.owner), "amount": hp_cost, "item": self.name}))
		self.owner.level.event_manager.raise_event(EventOnSpendHP(self.owner, hp_cost), self.owner)
		self.owner.level.show_effect(self.owner.x, self.owner.y, Tags.Blood, minor=True)

		debuffs = [b for b in self.owner.buffs if b.buff_type == BUFF_TYPE_CURSE]
		if not debuffs: return
		self.do_ui_flash()
		self.owner.remove_buff(random.choice(debuffs))

	def on_unit_added(self, _u):
		self.active = True

	def on_complete(self, _lvl):
		self.active = False

	def on_equip(self, owner):
		if not owner.is_player_controlled: return
		if owner.game.level_cleared: self.active = False

class SlimecrustedScarificator(Equipment):

	def on_init(self):
		self.name = "Slimecrusted Scarificator"
		self.tags = [Tags.Blood, Tags.Slime]
		self.recipe = [(Tags.Blood, 1), (Tags.Slime, 1), (Tags.Any, 2)]
		self.owner_triggers[EventOnSpendHP] = self.on_spend
		self.minion_health = 10
		self.minion_damage = 3
		self.minion_range = 3
		self.counter = 0

	def get_description(self):
		return (("Summon a Blood Slime nearby for every [{minion_health}:minion_health] HP you spend"
				"\n[HP Spent:blood]: [{counter}:blood] / [{minion_health}:minion_health]", {'counter':self.counter}))

	def get_extra_examine_tooltips(self):
		return [self.make_slime()]

	def make_slime(self):
		u = BloodSlime()
		apply_minion_bonuses(self, u)
		u.buffs[0].spawner = lambda: self.make_slime()
		return u

	def on_spend(self, evt):
		self.counter += evt.hp
		while self.counter >= self.get_stat('minion_health'):
			self.counter -= self.get_stat('minion_health')
			self.owner.level.queue_spell(self.do_summon())
			self.do_ui_flash()

	def do_summon(self):
		self.summon(self.make_slime())
		yield

class ChelationClaw(Equipment):

	def on_init(self):
		self.name = "Chelation Claw"
		self.tags = [Tags.Blood, Tags.Metallic]
		self.recipe = [(Tags.Blood, 1), (Tags.Metallic, 1), (Tags.Any, 3)]
		self.duration = 4
		self.owner_triggers[EventOnSpellCast] = self.on_cast
		self.add_effect_tooltip(HemorrhageBuff)

	def get_description(self):
		return "When you cast a [Blood] or [Metallic] spell targeting an enemy, inflict [{duration}:duration] turns of [hemorrhage] on them"

	def on_cast(self, evt):
		if Tags.Blood not in evt.spell.tags and Tags.Metallic not in evt.spell.tags: return
		u = self.owner.level.get_unit_at(evt.x, evt.y)
		if not u: return
		if are_friendly(self.owner, u): return
		u.apply_buff(HemorrhageBuff(), self.get_stat('duration'))
		self.do_ui_flash()

class DruidsDibble(Equipment):

	def on_init(self):
		self.name = "Druid's Dibble"
		self.tags = [Tags.Conjuration, Tags.Nature]
		self.recipe = [(Tags.Conjuration, 1), (Tags.Nature, 1), (Tags.Any, 4)]
		self.owner_triggers[EventOnSpellCast] = self.on_cast
		self.description = "Every other [Nature] spell you cast summons a Flytrap near the target"
		self.ready = False
		self.trigger_tags = [Tags.Nature]

		self.minion_health = 7
		self.minion_range = 5
		self.minion_damage = 2

	def get_extra_examine_tooltips(self):
		return [make_minion(self, FlyTrap)]

	def on_cast(self, evt):
		if not any(t for t in self.trigger_tags if t in evt.spell.tags): return
		if not self.ready: self.ready = True; return
		self.ready = False
		self.owner.level.queue_spell(self.do_summon(Point(evt.x, evt.y)))
		self.do_ui_flash()

	def do_summon(self, target):
		self.summon(make_minion(self, FlyTrap), target=target)
		yield


class RimeblightPulverizer(Equipment):

	def on_init(self):
		self.name = "Rimeblight Pulverizer"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Ice, Tags.Nature]
		self.recipe = [(Tags.Ice, 1), (Tags.Metallic, 1), (Tags.Nature, 1), (Tags.Any, 1)]
		self.global_triggers[EventOnUnfrozen] = self.on_unfrozen
		self.damage = 30
		self.duration = 10

	def get_description(self):
		return "When an enemy is unfrozen, they take [{damage}:damage] [Poison] damage and are [poisoned] for [{duration}:duration] turns"

	def on_unfrozen(self, evt):
		if are_friendly(evt.unit, self.owner): return
		evt.unit.deal_damage(self.get_stat('damage'), Tags.Poison, self)
		evt.unit.apply_buff(Poison(), self.get_stat('duration'))
		self.do_ui_flash()

class CryoticAccumulator(Equipment):

	def on_init(self):
		self.name = "Cryotic Accumulator"
		self.tags = [Tags.Ice]
		self.recipe = [(Tags.Ice, 1), (Tags.Any, 3)]
		self.global_triggers[EventOnUnfrozen] = self.on_unfrozen
		self.damage = 10

	def get_description(self):
		return ("When an enemy is unfrozen, they take [Ice] damage"
				"\nThe damage is equal to [{damage}:damage] multiplied by the number of turns they spent [frozen]")

	def on_unfrozen(self, evt):
		if are_friendly(evt.unit, self.owner): return
		evt.unit.deal_damage(self.get_stat('damage') * max(0, evt.buff.turns_frozen), Tags.Ice, self)
		self.do_ui_flash()

class StagnationBasin(Equipment):

	def on_init(self):
		self.name = "Stagnation Basin"
		self.tags = [Tags.Nature]
		self.recipe = [(Tags.Nature, 1), (Tags.Any, 3)]
		self.duration = 10
		self.global_triggers[EventOnBuffApply] = self.on_soak

	def get_description(self):
		return "When an enemy is soaked, they are [poisoned] for [{duration}:duration] turns"

	def on_soak(self, evt):
		if not isinstance(evt.buff, SoakedBuff): return
		if are_friendly(evt.unit, self.owner): return
		evt.unit.apply_buff(Poison(), self.get_stat('duration'))
		self.do_ui_flash()

class SolidSteelStaff(Equipment):

	def on_init(self):
		self.name = "Solid Steel Staff"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Metallic]
		self.recipe = [(Tags.Metallic, 2), (Tags.Any, 2)]

		self.tag_bonuses[Tags.Metallic]['damage'] = 10
		self.tag_bonuses[Tags.Metallic]['duration'] = 2
		self.tag_bonuses_pct[Tags.Metallic]['range'] = 25

class GlasyasBite(Equipment):

	def on_init(self):
		self.name = "Glasya's Bite"
		self.tags = [Tags.Blood, Tags.Chaos]
		self.recipe = [(Tags.Blood, 1), (Tags.Chaos, 1), (Tags.Any, 3)]
		self.owner_triggers[EventOnUnitAdded] = self.on_added

	def get_description(self):
		desc = ["When you enter a level, inflict [bleed] on enemies\n"
				"The duration of the [bleed] is equal to the product of your [Blood] and [Chaos] masteries"]
		if self.owner:
			desc.append("\n[Chaos Mastery:chaos]: [{c}:chaos]")
			desc.append("\n[Blood Mastery:blood]: [{b}:blood]")
			desc.append("\nBleed Duration: [{d}]")
		return desc

	def fmt_dict(self):
		d = Equipment.fmt_dict(self)
		d['c'] = self.owner.get_mastery(Tags.Chaos) if self.owner else 0
		d['b'] = self.owner.get_mastery(Tags.Blood) if self.owner else 0
		d['d'] = d['c'] * d['b'] if self.owner else 0
		return d


	def on_added(self, evt):
		dur = self.owner.get_mastery(Tags.Blood) * self.owner.get_mastery(Tags.Chaos)
		if not dur: return
		enemies = self.owner.get_hostiles()
		if not enemies: return
		self.do_ui_flash()
		for u in enemies:
			u.level.show_effect(u.x, u.y, Tags.Fang, speed=2)
			u.apply_buff(BleedBuff(), dur)

class MaskOfNihilo(Equipment):

	def on_init(self):
		self.name = "Mask of Nihilo"
		self.slot = SLOT_HELMET
		self.tags = [Tags.Chaos, Tags.Dark]
		self.recipe = [(Tags.Chaos, 4), (Tags.Dark, 4), (Tags.Any, 2)]
		for tag in self.tags: self.tag_bonuses_pct[tag]['damage'] = 1000
		self.owner_triggers[EventOnDamaged] = self.on_damaged

	def get_description(self):
		return ("Damage you take reduces your resistance to that damage type by the same amount")

	def on_damaged(self, evt):
		if evt.damage < 1: return
		self.update_res(evt.damage, evt.damage_type)

	def update_res(self, v, t):
		self.resists[t] -= v
		self.owner.resists[t] -= v
		self.do_ui_flash()

class PlasmicDistributor(Equipment):

	def on_init(self):
		self.name = "Plasmic Distributor"
		self.tags = [Tags.Blood]
		self.recipe = [(Tags.Blood, 2), (Tags.Enchantment, 1), (Tags.Any, 1)]
		self.num_targets = 7
		self.granted = 0
		self.global_triggers[EventOnUnitAdded] = self.on_added
		self.add_spell_tooltip(Vampiricism)

	def get_description(self):
		return (("When allies are summoned adjacent to you, cast Vampiricism on them\n"
				"This item can activate up to [{num_targets}:num_targets] times each level\n"
				"Vampiricism Bestowed: [{g}:blood] / [{num_targets}:num_targets]", {'g':self.granted}))

	def on_applied(self, owner): self.granted = 0

	def on_added(self, evt):
		if evt.unit == self.owner: return
		if self.granted >= self.get_stat('num_targets'): return
		if are_hostile(evt.unit, self.owner) or evt.unit == self.owner: return
		if evt.unit.has_buff(VampiricismBuff): return
		if self.owner.level.unit_distance(self.owner, evt.unit) > 1.5: return
		self.granted += 1
		self.owner.level.act_cast(self.owner, self.owner.get_or_make_spell(Vampiricism), evt.unit.x, evt.unit.y, pay_costs=False, queue=True)
		self.do_ui_flash()

class SparkConductor(Equipment):

	def on_init(self):
		self.name = "Spark Conductor"
		self.tags = [Tags.Lightning, Tags.Metallic]
		self.recipe = [(Tags.Lightning, 1), (Tags.Metallic, 1), (Tags.Any, 3)]
		self.global_triggers[EventOnUnitAdded] = self.on_summoned
		self.add_effect_tooltip(GalvanicRedirection)

	def get_description(self):
		return ("When [Metallic] or [Construct] allies are summoned, they gain the Galvanic Redirection buff"
				"\nGalvanic Redirection causes [Lightning] damage they would take to instead be redirected to a random enemy in their line of sight")

	def on_summoned(self, evt):
		if are_hostile(evt.unit, self.owner): return
		if Tags.Metallic in evt.unit.tags or Tags.Construct in evt.unit.tags:
			evt.unit.apply_buff(GalvanicRedirection())
			self.do_ui_flash()

class ConciliatorsClaw(Equipment):

	def on_init(self):
		self.name = "Conciliator's Claw"
		self.tags = [Tags.Blood, Tags.Metallic]
		self.recipe = [(Tags.Blood, 2), (Tags.Metallic, 1), (Tags.Any, 3)]
		self.description = "When you deal damage to an adjacent enemy, heal yourself and allies in your line of sight for [3 HP:heal]"
		self.global_triggers[EventOnDamaged] = self.on_damage

	def on_damage(self, evt):
		if evt.damage < 1: return
		if getattr(evt.source, 'owner', None) != self.owner: return
		if self.owner.level.unit_distance(evt.unit, evt.source.owner, diag=True) > 1: return # adjacent only
		if not are_hostile(self.owner, evt.unit): return # care about damage to enemies only
		self.do_ui_flash()
		for u in self.owner.level.get_units_in_los(self.owner):
			if are_hostile(self.owner, u): continue
			if u.cur_hp == u.max_hp: continue
			u.heal(3, self)

class ArtificialHeart(Equipment):

	def on_init(self):
		self.name = "Artificial Heart"
		self.tags = [Tags.Blood, Tags.Lightning, Tags.Metallic]
		self.recipe = [(Tags.Blood, 1), (Tags.Lightning, 1), (Tags.Metallic, 1), (Tags.Any, 2)]
		self.description = "Summoned [Construct] allies gain the [Living] tag"
		self.global_triggers[EventOnUnitAdded] = self.on_add

	def on_add(self, evt):
		if Tags.Construct in evt.unit.tags and Tags.Living not in evt.unit.tags and not are_hostile(evt.unit, self.owner):
			evt.unit.tags.append(Tags.Living)
			self.do_ui_flash()

class OrreryOfTheUnnamedOne(Equipment):

	def on_init(self):
		self.name = "Orrery of the Unnamed One"
		self.tags = [Tags.Dark, Tags.Orb]
		self.recipe = [(Tags.Blood, 1), (Tags.Holy, 1), (Tags.Ice, 1), (Tags.Nature, 1), (Tags.Orb, 1), (Tags.Dragon, 1), (Tags.Translocation, 1), (Tags.Eye, 1), (Tags.Any, 1)] #NIGHT YORB
		self.description = ("Summoning an [Orb] ally grants them a spell you know on a 3 turn cooldown\n"
							"Spells are chosen from: Darkness, Drain Pulse, Earthquake, Flame Burst, and Storm Burst")
		self.tag_bonuses_pct[Tags.Orb]['minion_health'] = 100
		self.global_triggers[EventOnUnitAdded] = self.on_added
		self.spell_opts = [EarthquakeSpell, Darkness, DrainPulse, FlameBurstSpell, StormBurst]

	def on_added(self, evt):
		if Tags.Orb not in evt.unit.tags: return
		if are_hostile(self.owner, evt.unit): return
		priority = [s for s in self.spell_opts if self.owner.get_spell(s)]
		if priority: s = random.choice(priority)
		else: return
		grant_minion_spell(spell_class=s, unit=evt.unit, master=self.owner, cool_down=3)
		self.do_ui_flash()

class OrbControllersMitts(Equipment):

	def on_init(self):
		self.name = "Orb Controller's Mitts"
		self.tags = [Tags.Orb, Tags.Translocation]
		self.recipe = [(Tags.Orb, 1), (Tags.Translocation, 1), (Tags.Any, 2)]
		self.description = "Casting an [Orb] spell to relocate it refunds the spell's charge"
		self.owner_triggers[EventOnSpellCast] = self.on_cast

	def on_cast(self, evt):
		if Tags.Orb not in evt.spell.tags: return
		if not next((u for u in self.owner.level.units if u.source is evt.spell and u.is_alive()), None):return
		evt.spell.refund_charges(1)
		evt.spell.do_ui_flash(Tags.Translocation)
		self.do_ui_flash()


class BorealArmor(Equipment):
	def on_init(self):
		self.name = "Boreal Armor"
		self.slot = SLOT_ARMOR
		self.tags = [Tags.Ice]
		self.recipe = [(Tags.Ice, 1), (Tags.Metallic, 1), (Tags.Any, 4)]
		self.damage = 12
		self.resists[Tags.Physical] = 25
		self.resists[Tags.Ice] = 25
		self.owner_triggers[EventOnUnitAdded] = self.on_added
		self.global_triggers[EventOnShieldRemoved] = self.on_shield_removed

	def get_description(self):
		return ("Gain [7 SH:shields] at the beginning of each level\n"
				"When an enemy removes one of your shields, deal [{damage}:damage] [Ice] damage to them")

	def on_added(self, evt):
		self.owner.add_shields(7)

	def on_shield_removed(self, evt):
		if evt.unit != self.owner: return
		if not evt.source.owner: return
		if not are_hostile(evt.source.owner, self.owner): return
		evt.source.owner.deal_damage(self.get_stat('damage'), Tags.Ice, self)
		self.do_ui_flash()


class EldritchMantle(Equipment):

	def on_init(self):
		self.name = "Eldritch Mantle"
		self.slot = SLOT_ARMOR
		self.tags = [Tags.Arcane]
		self.recipe = [(Tags.Arcane, 2), (Tags.Translocation, 2), (Tags.Any, 3)]
		self.num_targets = 3
		self.damage = 12

		self.resists[Tags.Arcane] = 25
		self.resists[Tags.Physical] = 25

	def get_description(self):
		return ("Tentacles drag the nearest [{num_targets}:num_targets] enemies along paths toward the wearer each turn\n"
				"Tentacles deal [{damage}:damage] [Arcane] damage to their targets")

	def on_advance(self):
		if not self.owner.level.get_units_by_distance(self.owner, enemy=True, max_results=1): return
		self.owner.level.queue_spell(self.do_pulls())
		self.do_ui_flash()

	def do_pulls(self):
		level = self.owner.level
		seen = set()
		for _ in range(self.get_stat('num_targets')):
			targets = [u for u in level.get_units_by_distance(self.owner, enemy=True) if u not in seen]
			if not targets: break
			t = targets[0]
			seen.add(t)

			path = get_pull_along_path(t, self.owner, RANGE_GLOBAL)
			if path:
				for p in reversed(path): level.flash(p.x, p.y, Tags.Tongue.color)
				p = path[0]
				if t.level.can_move(t, p.x, p.y, teleport=True): t.level.act_move(t, p.x, p.y, teleport=True) # abridged pull
			elif not level.are_adjacent(self.owner, t):
				level.show_path_effect(self.owner, t, Tags.Tongue)

			t.deal_damage(self.get_stat('damage'), Tags.Arcane, self)
			yield

class NumenCenser(Equipment):

	def on_init(self):
		self.name = "Numen Censer"
		self.tags = [Tags.Arcane, Tags.Conjuration, Tags.Holy]
		self.recipe = [(Tags.Arcane, 1), (Tags.Conjuration, 2), (Tags.Holy, 1), (Tags.Any, 5)]
		self.damage = 2
		self.effect_tags = [Tags.Holy, Tags.Arcane]
		self.global_triggers[EventOnUnitAdded] = self.on_added

	def get_description(self):
		return ("When allies are summoned, a burst of energy is released at their location\n"
				"Adjacent allies heal [7 HP:heal] while adjacent enemies take [{damage}:damage] [Holy] and [Arcane] damage")

	def on_added(self, evt):
		if are_hostile(evt.unit, self.owner): return
		if evt.unit == self.owner: return
		self.do_ui_flash()
		damage = self.get_stat('damage')
		for p in self.owner.level.get_adjacent_points(evt.unit, filter_walkable=False, r=evt.unit.radius):
			u = self.owner.level.get_unit_at(p.x, p.y)
			if not u: self.owner.level.show_effect(p.x, p.y, random.choice(self.effect_tags)); continue
			if are_hostile(self.owner, u):
				self.owner.level.deal_damage(p.x , p.y, damage, Tags.Holy, self)
				self.owner.level.deal_damage(p.x , p.y, damage, Tags.Arcane, self)
			else:
				self.owner.level.show_effect(p.x, p.y, Tags.Holy)
				u.heal(7, self)

class PyrrhicCenser(Equipment):

	def on_init(self):
		self.name = "Pyrrhic Censer"
		self.tags = [Tags.Conjuration, Tags.Fire, Tags.Nature]
		self.recipe = [(Tags.Conjuration, 2), (Tags.Fire, 1), (Tags.Nature, 1), (Tags.Any, 3)]
		self.global_triggers[EventOnUnitAdded] = self.on_added

	def get_description(self):
		return ("When allies are summoned, a burst of flames is released at their location\n"
				"Adjacent enemies take [Fire] damage equal to half the summoned ally's max HP")

	def on_added(self, evt):
		if are_hostile(evt.unit, self.owner): return
		if evt.unit == self.owner: return
		self.do_ui_flash()
		damage = evt.unit.max_hp // 2
		for p in self.owner.level.get_adjacent_points(evt.unit, filter_walkable=False, r=evt.unit.radius):
			u = self.owner.level.get_unit_at(p.x, p.y)
			if not u: self.owner.level.show_effect(p.x, p.y, Tags.Fire); continue
			if are_hostile(self.owner, u): self.owner.level.deal_damage(p.x , p.y, damage, Tags.Fire, self)

class ArchangelsSpear(Equipment):

	def on_init(self):
		self.name = "Archangel's Spear"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Holy, Tags.Metallic]
		self.recipe = [(Tags.Holy, 3), (Tags.Metallic, 2), (Tags.Any, 3)]
		self.tag_bonuses_pct[Tags.Holy]['range'] = 100
		self.tag_bonuses_pct[Tags.Holy]['damage'] = 100
		self.owner_triggers[EventOnSpellCast] = self.on_cast

	def get_description(self):
		return "Casting a [Holy] spell targeting an enemy removes their shields"

	def on_cast(self, evt):
		if Tags.Holy not in evt.spell.tags: return
		u = self.owner.level.get_unit_at(evt.x, evt.y)
		if not u: return
		if are_hostile(self.owner, u) and u.shields:
			u.shields = 0
			u.level.show_effect(u.x, u.y, Tags.Shield_Expire)
			self.do_ui_flash()

class TheBloodwell(Equipment):

	def on_init(self):
		self.name = "The Bloodwell"
		self.tags = [Tags.Blood]
		self.recipe = [(Tags.Blood, 2), (Tags.Translocation, 1), (Tags.Any, 2)]
		self.global_triggers[EventOnDamaged] = self.on_damaged

	def get_description(self):
		return "When a unit takes damage from [bleed], heal [1 HP:heal]"

	def on_damaged(self, evt):
		if not isinstance(evt.source, BleedBuff): return
		self.owner.heal(1, self)
		self.do_ui_flash()

class MetallurgyMitts(Equipment):

	def on_init(self):
		self.name = "Metallurgy Mitts"
		self.tags = [Tags.Fire, Tags.Metallic]
		self.recipe = [(Tags.Fire, 2), (Tags.Metallic, 2), (Tags.Any, 2)]
		self.tag_bonuses[Tags.Fire]['radius'] = 1
		self.tag_bonuses[Tags.Fire]['range'] = 2
		self.tag_bonuses[Tags.Metallic]['max_charges'] = 3
		self.resists[Tags.Fire] = 25
		self.resists[Tags.Physical] = 25

class ElectroplasmBuff(Buff):

	def __init__(self, eq_source):
		Buff.__init__(self)
		self.eq_source = eq_source

	def get_description(self):
		return ("Takes [{damage}:damage] [Lightning] damage each turn\nSummons an Electric Slime if killed by [Lightning] damage", {'damage':self.eq_source.get_stat('damage')})

	def on_init(self):
		self.name = "Electroplasm"
		self.color = Tags.Lightning.color
		self.buff_type = BUFF_TYPE_CURSE
		self.stack_type = STACK_INTENSITY
		self.owner_triggers[EventOnDeath] = self.on_death

	def on_advance(self):
		self.owner.deal_damage(self.eq_source.get_stat('damage'), Tags.Lightning, self.eq_source)

	def on_death(self, evt):
		if not evt.damage_event: return
		if evt.damage_event.damage_type != Tags.Lightning: return
		self.eq_source.summon(self.eq_source.make_slime(), target=self.owner)

class ElectroplasmAmpule(Equipment):

	def on_init(self):
		self.name = "Electroplasm Ampule"
		self.tags = [Tags.Conjuration, Tags.Lightning, Tags.Slime]
		self.recipe = [(Tags.Conjuration, 1), (Tags.Lightning, 1), (Tags.Slime, 1), (Tags.Any, 2)]
		self.global_triggers[EventOnUnitAdded] = self.on_added

		self.damage = 1
		self.minion_health = 10
		self.minion_damage = 3
		self.minion_range = 3
		self.add_effect_tooltip(lambda: ElectroplasmBuff(self))

	def make_slime(self):
		u = ElectricSlime()
		apply_minion_bonuses(self, u)
		u.buffs[0].spawner = lambda: self.make_slime()
		return u

	def get_extra_examine_tooltips(self):
		return [self.make_slime()]

	def get_description(self):
		return ("When allies are summoned, they are afflicted with [Electroplasm:lightning]\n"
				"[Electroplasm:lightning] deals [{damage}:damage] [Lightning] damage to afflicted units each turn\n"
				"If a unit with [Electroplasm:lightning] dies to [Lightning] damage, an Electric Slime is summoned nearby")

	def on_added(self, evt):
		if are_hostile(evt.unit, self.owner): return
		if evt.unit == self.owner: return
		evt.unit.apply_buff(ElectroplasmBuff(self))

class IronLegionsBanner(Equipment):

	def on_init(self):
		self.name = "Iron Legion's Banner"
		self.tags = [Tags.Conjuration, Tags.Metallic]
		self.recipe = [(Tags.Conjuration, 1), (Tags.Metallic, 1), (Tags.Any, 3)]
		self.tag_bonuses[Tags.Metallic]['num_summons'] = 1
		self.duration = 10

		self.global_triggers[EventOnUnitAdded] = self.on_added
		self.trigger_tags = [Tags.Metallic, Tags.Construct]

	def get_description(self):
		return "[Metallic] and [Construct] allies gain [2 SH:shields] and [{duration}:duration] turns of [quickstep:translocation] when summoned"

	def on_added(self, evt):
		if are_hostile(self.owner, evt.unit): return
		if not any(t for t in self.trigger_tags if t in evt.unit.tags): return
		evt.unit.shields += 2
		evt.unit.apply_buff(QuickmoveBuff(), self.get_stat('duration'))
		self.do_ui_flash()

class SkybreakerArray(Equipment):

	def on_init(self):
		self.name = "Skybreaker Array"
		self.tags = [Tags.Arcane, Tags.Eye, Tags.Lightning, Tags.Metallic]
		self.recipe = [(Tags.Arcane, 1), (Tags.Eye, 1), (Tags.Lightning, 1), (Tags.Metallic, 1), (Tags.Any, 2)]

		self.damage = 20
		self.duration = 4

		self.global_triggers[EventOnMoved] = self.on_moved

	def get_description(self):
		return "When an enemy teleports to a tile you can see, they take [{damage}:damage] [Lightning] damage and are immobilized for [{duration}:duration] turns"

	def on_moved(self, evt):
		if not evt.teleport: return
		if not are_hostile(evt.unit, self.owner): return
		if not self.owner.level.can_see(self.owner.x, self.owner.y, evt.unit.x, evt.unit.y): return
		self.owner.level.queue_spell(self.do_bolt(evt.unit))
		self.do_ui_flash()

	def do_bolt(self, u):
		if not u.is_alive(): return
		self.owner.level.show_beam(self.owner, u, Tags.Lightning)
		u.deal_damage(self.get_stat('damage'), Tags.Lightning, self)
		u.apply_buff(ImmobilizeBuff(), self.get_stat('duration'))
		yield

class MourningBell(Equipment):

	def on_init(self):
		self.name = "Mourning Bell"
		self.tags = [Tags.Dark, Tags.Holy]
		self.recipe = [(Tags.Dark, 1), (Tags.Holy, 1), (Tags.Metallic, 1), (Tags.Any, 2)]

		self.damage = 10
		self.radius = 4

		self.counter = 0
		self.counter_max = 10

		self.global_triggers[EventOnDeath] = self.on_death

	def get_description(self):
		return (("At the end of your turn, if at least 10 creatures have died since the last toll, the bell tolls, dealing [{damage}:damage] [Dark], [Holy], and [Physical] damage to enemies within [{radius}:radius] tiles\n"
				"Death Toll : {counter} / {counter_max}", {'counter':self.counter, 'counter_max':self.counter_max}))

	def on_death(self, evt):
		self.counter += 1

	def on_advance(self):
		if self.counter >= self.counter_max:
			self.owner.level.queue_spell(self.toll())
			self.do_ui_flash()
			self.counter = 0

	def toll(self):
		damage = self.get_stat('damage')
		level = self.owner.level
		for p in level.get_points_in_ball(self.owner.x, self.owner.y, self.get_stat('radius')):
			u = level.get_unit_at(p.x, p.y)
			if u and are_friendly(self.owner, u): continue
			level.deal_damage(p.x, p.y, damage, Tags.Dark, self)
			level.deal_damage(p.x, p.y, damage, Tags.Holy, self)
			level.deal_damage(p.x, p.y, damage, Tags.Physical, self)
		yield

class VoidTravelersCloak(Equipment):

	def on_init(self):
		self.name = "Void Traveler's Cloak"
		self.slot = SLOT_ARMOR
		self.tags = [Tags.Arcane, Tags.Translocation]
		self.recipe = [(Tags.Arcane, 1), (Tags.Translocation, 2), (Tags.Any, 2)]
		self.resists[Tags.Arcane] = 25
		self.owner_triggers[EventOnMoved] = self.on_moved

	def get_description(self):
		return "When you teleport, gain [2 SH:shields]"

	def on_moved(self, evt):
		if not evt.teleport: return
		self.owner.add_shields(2)
		self.do_ui_flash()

class ChannelersTreads(Equipment):

	def on_init(self):
		self.name = "Channeler's Treads"
		self.slot = SLOT_BOOTS
		self.tags = [Tags.Enchantment, Tags.Sorcery, Tags.Translocation]
		self.recipe = [(Tags.Enchantment, 1), (Tags.Sorcery, 1), (Tags.Translocation, 1), (Tags.Any, 4)]
		self.description = "While channeling, walking will not end the channel"
		self.owner_triggers[EventOnMoved] = self.on_moved
		self.global_bonuses_pct['max_channel'] = 50

	def on_moved(self, evt):
		if evt.teleport: return
		b = self.owner.get_buff(ChannelBuff)
		if not b: return
		b.passed = True

class AmuletOfTheMaster(Equipment):

	def on_init(self):
		self.tags = [Tags.Blood, Tags.Conjuration, Tags.Enchantment]
		self.recipe = [(Tags.Blood, 1), (Tags.Conjuration, 1), (Tags.Enchantment, 1), (Tags.Any, 6)]
		self.name = "Amulet of the Master"
		self.tag_bonuses[Tags.Conjuration]['hp_cost'] = 10

	def get_description(self):
		return "If you would take damage from your allies, that damage is negated\n(Does not negate self-inflicted damage)"

	def on_applied(self, owner):
		def master_handler(amount, damage_type, source, redirect_chain):
			if not source or not source.owner: return None # ignore environmental damage
			if amount <= 0: return None # ignore healing / vfx
			if are_hostile(owner, source.owner) or source.owner == owner: return None # ignore damage from hostiles or self
			else: return 0 # handle / negate damage from everything else (which should be exclusively damage from allies)
		owner.grant_redirect(self, master_handler)

	def on_unapplied(self):
		self.owner.remove_redirect(self)

class PsychopompStaff(Equipment):

	def on_init(self):
		self.name = "Psychopomp Staff"
		self.tags = [Tags.Arcane, Tags.Dark]
		self.recipe = [(Tags.Arcane, 2), (Tags.Dark, 2), (Tags.Any, 6)]
		self.slot = SLOT_WEAPON

		self.global_triggers[EventOnDamaged] = self.on_damaged
		self.global_triggers[EventOnAwakened] = self.on_awakened

	def get_description(self):
		return ("Redeals damage dealt by you and your allies to [sleeping] enemies\n"
				"If this item kills a unit, regain a charge of a random [Arcane] spell")

	def on_damaged(self, evt):
		self.try_redeal(evt, check_sleep=True)

	def on_awakened(self, evt):
		if not evt.buff.wake_damage_event: return
		self.try_redeal(evt.buff.wake_damage_event, check_sleep=False)

	def try_redeal(self, evt, check_sleep):
		if not evt.source: return
		if not evt.source.owner: return
		if evt.damage < 0: return
		if not are_hostile(evt.unit, self.owner): return
		if are_hostile(evt.source.owner, self.owner): return
		if check_sleep and not evt.unit.has_buff(SleepBuff): return
		if isinstance(evt.source, PsychopompStaff): return
		self.owner.level.queue_spell(self.do_damage(evt.unit, evt.damage, evt.damage_type))

	def do_damage(self, unit, damage, dtype):
		if not unit.is_alive(): return
		unit.deal_damage(damage, dtype, self)
		self.do_ui_flash()
		yield
		if not unit.is_alive(): self.grant_charge()

	def grant_charge(self):
		opts = [s for s in self.owner.spells if Tags.Arcane in s.tags and s.cur_charges < s.get_stat('max_charges')]
		if not opts: return
		s = random.choice(opts)
		s.refund_charges(1)
		s.do_ui_flash(Tags.Arcane)


class WitchingHourglass(Equipment):

	def on_init(self):
		self.name = "Witching Hourglass"
		self.tags = [Tags.Conjuration, Tags.Dark]
		self.recipe = [(Tags.Conjuration, 1), (Tags.Dark, 1), (Tags.Any, 2)]
		self.global_triggers[EventOnAwakened] = self.on_awoken

		self.minion_health = 4
		self.minion_damage = 1
		self.minion_duration = 8

	def get_description(self):
		return "When an enemy awakens from [sleep], summon a temporary Ghost near them"

	def get_extra_examine_tooltips(self):
		return [make_minion(self, Ghost)]

	def on_awoken(self, evt):
		if not are_hostile(evt.unit, self.owner): return
		self.summon(make_minion(self, Ghost), evt.unit)
		self.do_ui_flash()

class DreamThiefDiadem(Equipment):

	def on_init(self):
		self.name = "Dream Thief Diadem"
		self.slot = SLOT_HELMET
		self.tags = [Tags.Arcane, Tags.Dark]
		self.recipe = [(Tags.Arcane, 1), (Tags.Conjuration, 1), (Tags.Dark, 1), (Tags.Enchantment, 1), (Tags.Any, 2)]
		self.description = "When an enemy awakens from [sleep], your [Arcane] and [Dark] allies adjacent to it take an extra turn"
		self.global_triggers[EventOnAwakened] = self.on_awakened

	def on_awakened(self, evt):
		if not are_hostile(evt.unit, self.owner): return
		owner = self.owner
		level = owner.level
		units = []
		for u in level.get_adjacent_units(evt.unit):
			if are_hostile(owner, u): continue # ally
			if (Tags.Arcane not in u.tags) and (Tags.Dark not in u.tags): continue # arcane / dark only
			if u.is_player_controlled: continue # non-player
			units.append(u)

		for u in units: level.queue_spell(self.do_turn(u))
		if units: self.do_ui_flash()

	def do_turn(self, u):
		if not u.is_alive(): return
		for _ in u.level.take_turn(u): yield


class BedlamBell(Equipment):

	def on_init(self):
		self.name = "Bedlam Bell"
		self.tags = [Tags.Arcane, Tags.Chaos, Tags.Dark]
		self.recipe = [(Tags.Arcane, 1), (Tags.Chaos, 1), (Tags.Dark, 1), (Tags.Metallic, 1), (Tags.Any, 2)]

		self.radius = 3
		self.duration = 2

		self.global_triggers[EventOnAwakened] = self.on_awakened

	def get_description(self):
		return "When an enemy awakens from [sleep], they and any other enemies within [{radius}:radius] tiles of them are [berserked] for [{duration}:duration] turns"

	def on_awakened(self, evt):
		if not are_hostile(evt.unit, self.owner): return
		level = self.owner.level
		targets = []
		for p in level.get_points_in_ball(evt.unit.x, evt.unit.y, self.get_stat('radius')):
			u = level.get_unit_at(p.x, p.y)
			if not u: continue
			if not are_hostile(u, self.owner): continue
			targets.append(u)

		dur = self.get_stat('duration')
		for u in targets: u.apply_buff(BerserkBuff(), dur)
		if targets: self.do_ui_flash()


class Keraunos(Equipment):

	def on_init(self):
		self.name = "Keraunos"
		self.tags = [Tags.Lightning]
		self.recipe = [(Tags.Lightning, 6), (Tags.Nature, 2), (Tags.Any, 2)]
		self.owner_triggers[EventOnSpellCast] = self.on_cast
		self.slot = SLOT_WEAPON
		self.num_targets = 2
		self.tag_bonuses_pct[Tags.Lightning]['damage'] = 100
		self.tag_bonuses_pct[Tags.Lightning]['max_charges'] = 100

	def get_description(self):
		return "When you manually cast a [Lightning] spell targeting a unit, cast it again [{num_targets}:num_targets] more times"

	def copy_spell(self, evt, copies):
		owner = self.owner
		level = owner.level
		for _ in range(copies):
			for _ in level.act_cast(owner, evt.spell, evt.x, evt.y, pay_costs=False, queue=False): yield
			yield

	def on_cast(self, evt):
		if not evt.pay_costs: return
		if Tags.Lightning not in evt.spell.tags: return
		level = self.owner.level
		target = level.get_unit_at(evt.x, evt.y)
		if not target: return
		copies = self.get_stat('num_targets')
		self.do_ui_flash()
		if copies: level.queue_spell(self.copy_spell(evt, copies))

class RitualPreparednessBuff(Buff):

	def on_init(self):
		self.name = "Ritual Preparedness"
		self.color = Tags.Ritual.color
		self.owner_triggers[EventOnBuffApply] = self.on_channel

	def get_description(self):
		return "The next time you begin channeling a [Ritual] spell, it will be activated repeatedly until it is completed"

	def on_channel(self, evt):
		if not isinstance(evt.buff, ChannelBuff): return
		if not Tags.Ritual in evt.buff.spell.__self__.tags: return
		self.owner.level.queue_spell(self.activate_ritual(evt.buff)) # you've started channeling a ritual

	def activate_ritual(self, b):
		if not b.applied: self.owner.remove_buff(self); return
		b.passed = True
		b.advance()
		b.passed = True
		if b.applied: self.owner.level.queue_spell(self.activate_ritual(b))
		else: self.owner.remove_buff(self)
		yield

class MandalaMukluks(Equipment):

	def on_init(self):
		self.name = "Mandala Mukluks"
		self.slot = SLOT_BOOTS
		self.tags = [Tags.Ritual, Tags.Translocation]
		self.recipe = [(Tags.Ritual, 4), (Tags.Translocation, 2), (Tags.Any, 2)]
		self.owner_triggers[EventOnItemPickup] = self.on_pickup
		self.add_effect_tooltip(RitualPreparednessBuff)

	def get_description(self):
		return ("Picking up a Memory Orb grants the [Ritual Preparedness:ritual] buff\n"
				 "[Ritual Preparedness:ritual] causes your next channeled [Ritual] spell to be activated repeatedly until it is completed")

	def on_pickup(self, evt):
		if not isinstance(evt.item, MemoryOrb): return
		self.do_ui_flash()
		self.owner.apply_buff(RitualPreparednessBuff())

class PlagueDoctorsmask(Equipment):

	def on_init(self):
		self.name = "Plague Doctor's Mask"
		self.slot = SLOT_HELMET
		self.resists[Tags.Poison] = 25
		self.resists[Tags.Dark] = 25
		self.tags = [Tags.Dark, Tags.Nature]
		self.recipe = [(Tags.Dark, 1), (Tags.Nature, 1), (Tags.Any, 2)]
		self.owner_triggers[EventOnBuffApply] = self.on_buffed

	def get_description(self):
		return "You are immune to [necrosis]"

	def on_equip(self, unit):
		unit.remove_buffs(NecrosisBuff)

	def on_buffed(self, evt):
		if isinstance(evt.buff, NecrosisBuff):
			evt.unit.remove_buffs(NecrosisBuff)

class PlagueDoctorsRobes(Equipment):

	def on_init(self):
		self.name = "Plague Doctor's Robe"
		self.slot = SLOT_ARMOR
		self.resists[Tags.Poison] = 50
		self.resists[Tags.Dark] = 50
		self.tags = [Tags.Dark, Tags.Nature]
		self.recipe = [(Tags.Dark, 2), (Tags.Nature, 2), (Tags.Any, 4)]

		self.radius = 5

	def get_description(self):
		return "Each turn, inflict a stack of permanent [necrosis] on other units within [{radius}:radius] tiles"

	def on_advance(self):
		activated = False
		for u in self.owner.level.get_units_in_ball(self.owner, self.get_stat('radius')):
			if u == self.owner: continue
			u.apply_buff(NecrosisBuff())
			activated = True
		if activated: self.do_ui_flash()

class PlagueDoctorsCane(Equipment):

	def on_init(self):
		self.name = "Plague Doctor's Cane"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Dark, Tags.Nature]
		self.recipe = [(Tags.Dark, 1), (Tags.Nature, 1), (Tags.Any, 2)]
		self.damage = 10
		self.duration = 2

	def get_description(self):
		return ("Each turn, deal [{damage}:damage] [Physical] damage to an adjacent enemy, pushing them up to one tile away and [stunning:stun] them for [{duration}:duration] turns")

	def on_advance(self):
		owner = self.owner
		level = owner.level
		targets = [unit for unit in level.get_adjacent_units(owner) if are_hostile(owner, unit)]

		if targets:
			target = random.choice(targets)
			target.deal_damage(self.get_stat('damage'), Tags.Physical, self)
			push(target, owner, 1)
			target.apply_buff(Stun(), self.get_stat('duration'))
			self.do_ui_flash()

class NecrostaticStack(Buff):

	def __init__(self, strength):
		self.strength = strength
		Buff.__init__(self)

	def on_init(self):
		self.name = "Necrostatics"
		self.tag_bonuses[Tags.Lightning]['damage'] = self.strength
		self.color = Tags.Lightning.color

class NecrostaticStaff(Equipment):

	def on_init(self):
		self.name = "Necrostatic Staff"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Dark, Tags.Lightning]
		self.recipe = [(Tags.Conjuration, 1), (Tags.Dark, 1), (Tags.Lightning, 1), (Tags.Any, 3)]

	def get_description(self):
		return "Each of your [Undead] allies grants you a +1 [damage] bonus to [Lightning] spells and equipment until they die"

	def on_pre_advance(self):
		owner = self.owner
		b = owner.get_buff(NecrostaticStack)
		if b: owner.remove_buff(b)
		num_undead_allies = len([u for u in owner.level.units if not are_hostile(u, owner) and Tags.Undead in u.tags and u != owner])
		if num_undead_allies: owner.apply_buff(NecrostaticStack(num_undead_allies))

class VenomancersVial(Equipment):

	def on_init(self):
		self.name = "Venomancer's Vial"
		self.tags = [Tags.Nature, Tags.Dark]
		self.recipe = [(Tags.Dark, 2), (Tags.Nature, 2), (Tags.Any, 2)]
		self.damage = 4

	def get_description(self):
		return ("[Poisoned] enemies take [{damage}:poison] additional [Poison] damage each turn")

	def on_advance(self):
		damage = self.get_stat('damage')
		for u in self.owner.level.units[:]:
			if not are_hostile(u, self.owner): continue
			if u.has_buff(Poison): u.deal_damage(damage, Tags.Poison, self)

class Plaguebringer(Equipment):

	def on_init(self):
		self.name = "Plaguebringer"
		self.slot = SLOT_WEAPON
		self.tags = [Tags.Dark, Tags.Chaos]
		self.recipe = [(Tags.Chaos, 1), (Tags.Dark, 1), (Tags.Nature, 1), (Tags.Any, 4)]
		self.description = "Redeal damage dealt to enemies by [Demon] allies as [Poison] damage"
		self.global_triggers[EventOnDamaged] = self.on_damage

	def on_damage(self, evt):
		if evt.damage < 1: return  # early out on thigns that round to 0
		if not evt.source: return
		if not evt.source.owner: return
		if evt.source.owner == self.owner: return # no repeating damage done by self (demonic wizard replicas)
		if are_hostile(self.owner, evt.source.owner): return # only redeal damage dealt to enemies
		if not are_hostile(self.owner, evt.unit): return # if the damage is dealt by an ally
		if not Tags.Demon in evt.source.owner.tags: return # and that ally has the demon tag
		self.owner.level.queue_spell(self.deal_damage(evt.unit, evt.damage))

	def deal_damage(self, unit, damage):
		if unit.deal_damage(damage, Tags.Poison, self): self.do_ui_flash()
		yield

class GoldRing(Buff):

	def on_init(self):
		self.name = "Gold Ring"
		self.stack_type = STACK_INTENSITY
		self.color = Tags.Holy.color
		self.tag_bonuses[Tags.Holy]['damage'] = 1

	def on_applied(self, owner):
		owner.add_shields(1)

	def get_description(self):
		return "Grants [1 SH:shields] when applied"

class Draupnir(Equipment):

	def on_init(self):
		self.name = "Draupnir"
		self.tags = [Tags.Holy, Tags.Metallic]
		self.recipe = [(Tags.Holy, 2), (Tags.Metallic, 1), (Tags.Any, 2)]
		self.add_effect_tooltip(GoldRing)

	def get_description(self):
		return ("Every 9th turn, gain 8 Gold Rings\n"
				"Each ring grants [1 SH:shields] and 1 [damage] to [Holy] spells and equipment")

	def on_advance(self):
		if self.owner.level.turn_no % 9 != 0: return
		for _ in range(8): self.owner.apply_buff(GoldRing())
		self.do_ui_flash()


class Brisingamen(Equipment):

	def on_init(self):
		self.name = "Brisingamen"
		self.tags = [Tags.Enchantment, Tags.Fire, Tags.Holy, Tags.Metallic]
		self.recipe = [(Tags.Enchantment, 1), (Tags.Fire, 1), (Tags.Holy, 1), (Tags.Metallic, 1), (Tags.Any, 2)]
		self.owner_triggers[EventOnUnitAdded] = self.on_added
		self.duration = 3

	def get_description(self):
		return "At the beginning of each level, enemies in your line of sight are [berserked] for [{duration}:duration] turns"

	def on_added(self, evt):
		owner = self.owner
		duration = self.get_stat('duration')
		show_beam = owner.level.show_beam
		targets = [u for u in owner.level.get_units_in_los(owner) if are_hostile(owner, u)]
		for u in targets:
			show_beam(owner, u, Tags.Fire)
			u.apply_buff(BerserkBuff(), duration)

class Necronomicon(Equipment):

	def on_init(self):
		self.name = "Codex Necronomicus"
		self.tags = [Tags.Dark, Tags.Word]
		self.recipe = [(Tags.Dark, 2), (Tags.Word, 3), (Tags.Any, 5)]
		self.owner_triggers[EventOnSpellCast] = self.on_cast
		self.global_bonuses['hp_cost'] = 1

	def get_description(self):
		desc = ["When you manually cast a [Dark] spell, there is a chance for it to receive a random upgrade\n"
				"When a spell is upgraded this way, the HP cost of all spells and equipment increases by 1\n"
				"The chance for a spell to be upgraded is equal to your [Dark] mastery"]
		if self.owner: desc.append("\n[Dark Mastery:dark]: [{mastery}:dark]")
		return desc

	def fmt_dict(self):
		d = Equipment.fmt_dict(self)
		d['mastery'] = self.owner.get_mastery(Tags.Dark) if self.owner else 0
		return d

	def on_cast(self, evt):
		if not evt.pay_costs: return
		if Tags.Dark not in evt.spell.tags: return
		if not evt.caster.is_player_controlled: return # for if you dupe this to a replica
		available_upgrades = [u for u in evt.spell.spell_upgrades if not u.applied]
		if not available_upgrades: return
		if random.random() * 100 > self.owner.get_mastery(Tags.Dark): return
		self.do_ui_flash()

		upgrade = random.choice(available_upgrades)
		if isinstance(upgrade, Upgrade): self.owner.apply_buff(upgrade)
		self.owner.level.log(("Codex Necronomicus upgraded {spell} with {upgrade}", {'spell':evt.spell.name, 'upgrade':upgrade.name}))
		evt.spell.do_ui_flash(Tags.Dark)

		self.global_bonuses['hp_cost'] += 1
		self.owner.adjust_global_bonus('hp_cost', 1, False)

class PrismaticPlate(Equipment):

	def on_init(self):
		self.name = "Prismatic Plate"
		self.tags = [Tags.Ice, Tags.Holy, Tags.Metallic]
		self.recipe = [(Tags.Ice, 1), (Tags.Holy, 1), (Tags.Metallic, 1), (Tags.Any, 3)]
		self.slot = SLOT_ARMOR
		self.owner_triggers[EventOnSpellCast] = self.on_cast

		self.resists[Tags.Physical] = 25
		self.resists[Tags.Holy] = 25

		self.damage = 25

	def get_description(self):
		return ("When you cast a [Holy] spell, if you have any [SH:shields], lose [1 SH:shields] and unleash beams of light in all 8 directions\n"
				"The beams deal [{damage}:damage] [Holy] damage to units in their path but stop when they encounter a wall")

	def on_cast(self, evt):
		if Tags.Holy not in evt.spell.tags: return
		if not self.owner.shields: return
		self.owner.shields -= 1
		self.owner.level.queue_spell(self.do_beams())
		self.do_ui_flash()

	def do_beams(self):
		owner = self.owner
		level = owner.level
		get_extended_path = level.get_extended_path
		tiles = level.tiles
		deal_damage = level.deal_damage
		damage = self.get_stat('damage')

		for p in level.get_adjacent_points(owner, False, False, owner.radius):
			for pt in get_extended_path(owner, p)[1:]:
				if tiles[pt.x][pt.y].is_wall(): break
				deal_damage(pt.x, pt.y, damage, Tags.Holy, self)
		yield

class HornOfTheWildHunt(Equipment):

	def on_init(self):
		self.name = "Horn of the Wild Hunt"
		self.tags = [Tags.Nature]
		self.recipe = [(Tags.Enchantment, 2), (Tags.Nature, 2), (Tags.Any, 3)]
		self.owner_triggers[EventOnSpellCast] = self.on_cast
		self.trigger_tags = [Tags.Nature]

	def get_description(self):
		return "When you manually cast a [Nature] spell, your [Nature] and [Living] allies take an extra turn"

	def on_cast(self, evt):
		if not evt.pay_costs: return
		if not any(t in evt.spell.tags for t in self.trigger_tags): return
		self.owner.level.queue_spell(self.do_turns())

	def do_turns(self):
		owner = self.owner
		allies = [u for u in owner.level.units if not are_hostile(owner, u) and u.has_tags([Tags.Nature, Tags.Living]) and u.is_alive() and u != owner]
		if not allies: return
		take_turn = owner.level.take_turn
		self.do_ui_flash()
		for u in allies:
			for _ in take_turn(u):
				yield

class ArchangelsArmor(Equipment):

	def on_init(self):
		self.name = "Archangel's Armor"
		self.tags = [Tags.Holy, Tags.Metallic]
		self.recipe = [(Tags.Holy, 3), (Tags.Metallic, 3), (Tags.Any, 3)]
		self.slot = SLOT_ARMOR

		self.resists[Tags.Fire] = 50
		self.resists[Tags.Physical] = 50
		self.resists[Tags.Holy] = 50

		self.owner_triggers[EventOnDamaged] = self.on_damaged

	def get_description(self):
		return "When a [Demon] damages you, cast Blinding Light"

	def on_damaged(self, evt):
		if not evt.source: return
		if not evt.source.owner: return
		if Tags.Demon not in evt.source.owner.tags: return
		owner = self.owner
		owner.level.act_cast(owner, owner.get_or_make_spell(BlindingLightSpell), owner.x, owner.y, pay_costs=False)
		self.do_ui_flash()

class ArchangelsHalo(Equipment):

	def on_init(self):
		self.name = "Archangel's Halo"
		self.tags = [Tags.Holy, Tags.Metallic]
		self.recipe = [(Tags.Holy, 2), (Tags.Metallic, 2), (Tags.Any, 2)]
		self.slot = SLOT_HELMET

		self.tag_bonuses_pct[Tags.Holy]['num_summons'] = 100
		self.tag_bonuses_pct[Tags.Holy]['minion_damage'] = 100

		self.radius = 2

	def get_description(self):
		return "Each turn, [Holy] allies within [{radius}:radius] tiles take an extra turn"

	def on_advance(self):
		owner = self.owner
		targets = [u for u in owner.level.get_units_in_ball(owner, self.get_stat('radius')) if u != owner and Tags.Holy in u.tags and not are_hostile(owner, u)]
		if not targets: return
		owner.level.queue_spell(self.force_turns(targets))
		self.do_ui_flash()

	def force_turns(self, targets):
		take_turn = self.owner.level.take_turn
		for t in targets:
			for _ in take_turn(t):
				yield

class BloodletterBracers(Equipment):

	def on_init(self):
		self.name = "Bloodletter Bracers"
		self.tags = [Tags.Blood]
		self.recipe = [(Tags.Blood, 2), (Tags.Metallic, 1), (Tags.Any, 2)]
		self.owner_triggers[EventOnSpendHP] = self.on_spend
		self.slot = SLOT_WEAPON

		self.counter = 0
		self.threshhold = 50

		self.tag_bonuses_pct[Tags.Blood]['hp_cost'] = 25

	def get_description(self):
		return "For every 50 HP you spend, regain a charge of a random [Blood] spell\n[HP Spent:blood]: [{spent}:blood]", {'spent':self.counter}

	def on_spend(self, evt):
		self.counter += evt.hp
		if self.counter < self.threshhold: return
		spells = [s for s in self.owner.spells if Tags.Blood in s.tags]
		while self.counter >= self.threshhold:
			self.counter -= self.threshhold
			spells = [s for s in spells if s.cur_charges < s.get_stat('max_charges')]
			if not spells: break
			s = random.choice(spells)
			s.refund_charges(1)
			s.do_ui_flash(Tags.Blood)
			self.do_ui_flash()

class RiftBreaker(Equipment):

	def on_init(self):
		self.name = "Rift Breaker"
		self.tags = [Tags.Arcane, Tags.Translocation]
		self.recipe = [(Tags.Arcane, 1), (Tags.Translocation, 1), (Tags.Any, 2)]
		self.slot = SLOT_WEAPON

		self.owner_triggers[EventOnSpellCast] = self.on_cast

	def get_description(self):
		return ("If you cast a spell while standing on a Rift, the Rift is consumed\n"
				"When you consume a rift, your spells regain all charges, you heal for any missing HP, and you gain [20 SH:shields]")

	def on_cast(self, evt):
		owner = self.owner
		prop = owner.level.tiles[owner.x][owner.y].prop
		if not prop or not isinstance(prop, Portal): return
		owner.level.remove_prop(prop)
		self.do_ui_flash()
		for s in owner.spells:
			s.do_ui_flash(Tags.Arcane)
			s.cur_charges = s.get_stat('max_charges')
		owner.heal((owner.max_hp - owner.cur_hp), self)
		owner.add_shields(20)

class ArmorOfNanuk(Equipment):

	def on_init(self):
		self.name = "Armor of Nanuk"
		self.tags = [Tags.Conjuration, Tags.Ice, Tags.Metallic, Tags.Nature]
		self.recipe = [(Tags.Conjuration, 1), (Tags.Ice, 1), (Tags.Metallic, 1), (Tags.Nature, 1), (Tags.Any, 1)]
		self.slot = SLOT_ARMOR

		self.resists[Tags.Physical] = 25
		self.resists[Tags.Ice] = 25

		self.owner_triggers[EventOnUnitAdded] = self.on_added

		self.minion_health = 100
		self.minion_damage = 10
		self.num_summons = 2

	def get_description(self):
		return "At the beginning of each level, summon [{num_summons}:num_summons] Armored Polar Bears"

	def on_added(self, evt):
		self.do_ui_flash()
		for _ in range(self.get_stat('num_summons')):
			self.summon(self.get_bear())

	def get_bear(self):
		return make_minion(self, ArmoredPolarBear)

	def get_extra_examine_tooltips(self):
		return [self.get_bear()]

class TitansBane(Equipment):

	def on_init(self):
		self.name = "Titan's Bane"
		self.tags = [Tags.Arcane, Tags.Sorcery]
		self.recipe = [(Tags.Arcane, 2), (Tags.Sorcery, 1), (Tags.Any, 2)]

		self.owner_triggers[EventOnSpellCast] = self.on_cast
		self.trigger_tags = [Tags.Sorcery]

	def get_description(self):
		return "When you manually cast a [Sorcery] spell targeting a giant, cast it again\nAny unit that occupies more than one tile is considered a giant"

	def copy_spell(self, evt):
		for _ in self.owner.level.act_cast(self.owner, evt.spell, evt.x, evt.y, pay_costs=False, queue=False): yield
		yield

	def on_cast(self, evt):
		if not evt.pay_costs: return
		if not any(t in evt.spell.tags for t in self.trigger_tags): return
		u = self.owner.level.get_unit_at(evt.x, evt.y)
		if not u or not u.radius: return
		self.do_ui_flash()
		self.owner.level.queue_spell(self.copy_spell(evt))

class DualTagCage(Equipment):

	def __init__(self, name, tag1, tag2, unit_fn, minion_health=0, minion_damage=0, minion_range=0):
		Equipment.__init__(self, name, tag1, tag2, unit_fn, minion_health, minion_damage, minion_range)
		self.name = name
		self.unit_fn = unit_fn
		self.recipe = []
		self.tag1 = tag1
		self.tag2 = tag2
		self.tags = [Tags.Conjuration, tag1, tag2]
		self.recipe = []
		for t in self.tags: self.recipe.append((t, 1))
		self.recipe.append((Tags.Any, 3))

		self.num_summons = 2
		self.minion_name = unit_fn().name
		self.minion_health = minion_health
		self.minion_damage = minion_damage
		if minion_range: self.minion_range = minion_range

		self.owner_triggers[EventOnUnitAdded] = self.on_added

		self.set_stats()

	def get_extra_examine_tooltips(self):
		return [make_minion(self, self.unit_fn)]

	def get_description(self):
		desc = [(("At the beginning of each level summon [{num_summons}:num_summons] {name}s\n"
				"The {name}s gain bonus HP equal to the the product of your {tag1} and {tag2} masteries"),
				 {'name':self.minion_name, 'tag1':formatted_tag(self.tag1), 'tag2':formatted_tag(self.tag2)})]
		if self.owner:
			masteries = self.get_masteries()
			desc.append((("\n{tag1}: {mastery1}"
						 "\n{tag2}: {mastery2}"
						 "\nBonus HP: {prod}"),
						 {'tag1':formatted_tag(self.tag1), 'tag2':formatted_tag(self.tag2),
						  'mastery1':masteries[0], 'mastery2':masteries[1], 'prod':masteries[2]}))
		return desc

	def get_masteries(self):
		if not self.owner: return 0, 0, 0
		m1 = self.owner.get_mastery(self.tag1)
		m2 = self.owner.get_mastery(self.tag2)
		prod = m1 * m2
		return m1, m2, prod

	def on_added(self, evt):
		hp = self.get_masteries()[2]
		for _ in range(self.get_stat('num_summons')):
			u = make_minion(self, self.unit_fn)
			u.max_hp += hp
			self.summon(u)

class Backtrackerers(Equipment):

	def on_init(self):
		self.name = "Backtrackers"
		self.tags = [Tags.Translocation]
		self.recipe = [(Tags.Arcane, 1), (Tags.Translocation, 2), (Tags.Any, 2)]
		self.slot = SLOT_BOOTS
		self.owner_triggers[EventOnUnitAdded] = self.on_added
		self.prev_x = None
		self.prev_y = None

	def get_description(self):
		return ("If you begin your turn somewhere other than where you ended your previous turn, attempt to teleport back to your previous location\n"
				"If that location is occupied, attempt to swap places with the occupying unit\nCannot swap places with giant units")

	def on_added(self, _evt):
		self.prev_x = self.owner.x
		self.prev_y = self.owner.y

	def on_pre_advance(self):
		owner = self.owner
		x = self.prev_x
		y = self.prev_y
		if owner.x == x and owner.y == y: return
		if not owner.level.can_move(owner, x, y, teleport=True, force_swap=True): return
		self.owner.level.show_beam(self.owner, Point(x, y), Tags.Translocation)
		owner.level.act_move(owner, x, y, teleport=True, force_swap=True)
		self.do_ui_flash()

	def on_advance(self):
		self.prev_x = self.owner.x
		self.prev_y = self.owner.y


class BishopBoots(Equipment):

	def on_init(self):
		self.name = "Bishop Boots"
		self.tags = [Tags.Translocation]
		self.recipe = [(Tags.Translocation, 2), (Tags.Any, 2)]
		self.owner_triggers[EventOnMoved] = self.on_move
		self.owner_triggers[EventOnUnitAdded] = self.on_added
		self.global_triggers[EventOnLevelComplete] = self.on_complete
		self.slot = SLOT_BOOTS
		self.active = True
		self.moving = False

	def get_description(self):
		return "When you step diagonally, if you are able, take another step in that same direction"

	def on_equip(self, owner):
		if not owner.is_player_controlled: return
		if owner.game.level_cleared: self.active = False

	def on_added(self, _u):
		self.active = True
		self.moving = False

	def on_complete(self, _lvl):
		self.active = False

	def on_move(self, evt):
		if not self.active or self.moving or self.owner.stationary: return
		if evt.teleport: return
		dx = evt.x - evt.old_x
		dy = evt.y - evt.old_y
		if not dx or not dy: return
		next_x = evt.x + dx
		next_y = evt.y + dy
		if not self.owner.level.can_move(self.owner, next_x, next_y): return
		self.moving = True
		self.owner.level.queue_spell(self.defer_move(dx, dy))

	def defer_move(self, dx, dy):
		self.owner.level.queue_spell(self.continue_move(dx, dy))
		return
		yield

	def continue_move(self, dx, dy):
		owner = self.owner
		level = owner.level
		if not self.active or not owner.is_alive() or owner.stationary:
			self.moving = False
			return

		next_x = owner.x + dx
		next_y = owner.y + dy
		if not level.can_move(owner, next_x, next_y):
			self.moving = False
			return

		level.leap_effect(owner.x, owner.y, Tags.Physical.color, owner)
		level.act_move(owner, next_x, next_y)
		if self.active and owner.is_alive(): level.queue_spell(self.continue_move(dx, dy))
		else: self.moving = False
		yield

class CastellanClogs(Equipment):

	def on_init(self):
		self.name = "Castellan Clogs"
		self.tags = [Tags.Translocation]
		self.recipe = [(Tags.Translocation, 2), (Tags.Any, 3)]
		self.owner_triggers[EventOnMoved] = self.on_move
		self.owner_triggers[EventOnUnitAdded] = self.on_added
		self.global_triggers[EventOnLevelComplete] = self.on_complete
		self.slot = SLOT_BOOTS
		self.active = True
		self.moving = False

	def get_description(self):
		return "When you step orthogonally, if you are able, take another step in that same direction"

	def on_equip(self, owner):
		if not owner.is_player_controlled: return
		if owner.game.level_cleared: self.active = False

	def on_added(self, _u):
		self.active = True
		self.moving = False

	def on_complete(self, _lvl):
		self.active = False

	def on_move(self, evt):
		if not self.active or self.moving or self.owner.stationary: return
		if evt.teleport: return
		dx = evt.x - evt.old_x
		dy = evt.y - evt.old_y
		if abs(dx + dy) != 1: return
		next_x = evt.x + dx
		next_y = evt.y + dy
		if not self.owner.level.can_move(self.owner, next_x, next_y): return
		self.moving = True
		self.owner.level.queue_spell(self.defer_move(dx, dy))

	def defer_move(self, dx, dy):
		self.owner.level.queue_spell(self.continue_move(dx, dy))
		return
		yield

	def continue_move(self, dx, dy):
		owner = self.owner
		level = owner.level
		if not self.active or not owner.is_alive() or owner.stationary:
			self.moving = False
			return

		next_x = owner.x + dx
		next_y = owner.y + dy
		if not level.can_move(owner, next_x, next_y):
			self.moving = False
			return

		level.leap_effect(owner.x, owner.y, Tags.Physical.color, owner)
		level.act_move(owner, next_x, next_y)
		if self.active and owner.is_alive(): level.queue_spell(self.continue_move(dx, dy))
		else: self.moving = False
		yield


all_equipment = [
	PlagueDoctorsRobes,
	PlagueDoctorsmask,
	PlagueDoctorsCane,

	ArchangelsSpear,
	ArchangelsArmor,
	ArchangelsHalo,

	GalvanicFocus,
	GalvanicBlade,
	GalvanicArmor,

	CrimsonCoronet,
	CrimsonTorc,
	CrimsonBrooch,

	CrownOfVirtuousSin,
	RobesOfVirtuousSin,
	SandalsOfVirtuousSin,
	ScalesOfVirtuousSin,

	lambda: DualTagCage(name="Lava Cage", tag1=Tags.Fire, tag2=Tags.Slime, unit_fn=LavaSpitter, minion_health=150, minion_range=9, minion_damage=3),
	lambda: DualTagCage(name="Arbiter Cage", tag1=Tags.Eye, tag2=Tags.Holy, unit_fn=Arbiter, minion_health=80, minion_range=12, minion_damage=8),
	lambda: DualTagCage(name="Knight Cage", tag1=Tags.Arcane, tag2=Tags.Metallic, unit_fn=AnimatedKnight, minion_health=75,minion_damage=12),

	ShatteringFrostManual,

	Backtrackerers,
	BishopBoots,
	CastellanClogs,

	HornOfTheWildHunt,
	BloodletterBracers,
	RiftBreaker,
	ArmorOfNanuk,
	TitansBane,
	PrismaticPlate,
	Necronomicon,
	Brisingamen,
	Draupnir,

	Plaguebringer,
	VenomancersVial,
	NecrostaticStaff,
	CharmOfDarkness,
	OrbControllersMitts,

	MandalaMukluks,
	Keraunos,
	PsychopompStaff,
	WitchingHourglass,
	DreamThiefDiadem,
	BedlamBell,

	MoltenCarapace,
	SunforgedIris,
	RunespeakersGorget,
	AmuletOfTheMaster,

	ChannelersTreads,
	DragonclawSabatons,

	VoidTravelersCloak,
	MourningBell,
	SkybreakerArray,

	ElectroplasmAmpule,
	MetallurgyMitts,
	TheBloodwell,
	PulseAccelerator,

	PyrrhicCenser,
	NumenCenser,

	EldritchMantle,
	BorealArmor,
	OrreryOfTheUnnamedOne,

	ConciliatorsClaw,
	ArtificialHeart,
	SparkConductor,

	PlasmicDistributor,
	HellfireMantle,
	MaskOfNihilo,
	GlasyasBite,
	SolidSteelStaff,

	CryoticAccumulator,
	StagnationBasin,
	RimeblightPulverizer,
	DruidsDibble,
	ChelationClaw,
	SlimecrustedScarificator,
	FlagellantsCup,

	PedanticPendant,
	RapidRitualRod,
	DragonspineCloak,

	PhilosophersStone,
	MagicWand,
	ArtificersRod,
	ArtificersChalice,
	ArtificersAbacus,
	ArtificersHammer,
	ArtificersMirror,

	VoodooDoll,
	ContagionCorpse,
	SpawningVenom,
	SlimeBirthCantromancy,
	SoulHarvester,
	WildHealingStaff,
	CrackleVoid,
	IcyVengeanceIcon,
	Disintegrator,
	BloodStaff,
	BloodReaper,
	EnchantersBoon,
	Hemocorruptor,
	ChannelersFocus,

	ChimeraCage,
	SanguineFrostWand,
	ColdIronHeart,

	BlazingWand,
	AshenRod,

	IceCallerStaff,
	SnowStaff,
	CrystalDagger,

	LightningStaff,
	StormWand,

	NatureStaff,
	BloomingWand,
	VileDagger,

	DarkStaff,
	UmbralTotem,
	NecromancersStaff,
	ArchSorcerersStaff,

	HolyStaff,
	SacrificialDagger,

	ArcaneStaff,
	RunicHourglass,


	SorceryStaff,
	BattlemageStaff,

	EnchantmentStaff,
	SlipperyHexDagger,

	RainbowBlade,

	ConjurationStaff,
	ShepherdsStaff,

	ChaosStaff,
	EntropicWand,

	SlimeStaff,
	OozeWand,


	BladeStaff,
	TimelordsStaff,
	GeometerStaff,
	StaffOfMemory,
	BrainHat,
	HordeLordStaff,
	MultimancerStaff,

	IronLegionsBanner,

	lambda: GenericOculusEquip("Storm", [Tags.Ice, Tags.Lightning]),
	lambda: GenericOculusEquip("Void", [Tags.Dark, Tags.Arcane]),
	lambda: GenericOculusEquip("Pyrostatic", [Tags.Fire, Tags.Lightning]),
	lambda: GenericOculusEquip("Twilight", [Tags.Dark, Tags.Holy]),
	lambda: GenericOculusEquip("Crystal", [Tags.Ice, Tags.Arcane]),
	lambda: GenericOculusEquip("Purity", [Tags.Fire, Tags.Holy]),
	#

	# "name", tag, resists=[(damage_type, amount),...], bonuses=[("stat", pct_bonus)...]
	lambda: ElementalRobe("Fire", Tags.Fire, resists=[(Tags.Fire, 75), (Tags.Ice, 25)], bonuses=[("damage", 50), ("minion_damage", 50)]),
	lambda: ElementalRobe("Ice", Tags.Ice, resists=[(Tags.Ice, 75), (Tags.Fire, 25)], bonuses=[("damage", 50), ("duration", 50)]),
	lambda: ElementalRobe("Void", Tags.Arcane, resists=[(Tags.Arcane, 75), (Tags.Dark, 25)], bonuses=[("damage", 50), ("max_charges", 50)]),
	lambda: ElementalRobe("the Druids", Tags.Nature, resists=[(Tags.Poison, 100)], bonuses=[("damage", 50), ("minion_health", 50)]),
	lambda: ElementalRobe("Rifts", Tags.Translocation, resists=[(Tags.Arcane, 25), (Tags.Dark, 25), (Tags.Physical, 25)], bonuses=[("max_charges", 100), ("range", 50)]),


	# Forbidden Magic Spellbooks
	BookOfRevelation,
	BookOfFourSeals,
	BookOfIce,
	BookOfMadness,
	BookOfDeath,
	BookOfLife,
	BookOfChaos,
	BookOfMalevolence,
	BookOfHelheim,
	BookOfCurses,

	TheNorthPole,
	ArcaneAmplifier,
	Flamenweaver,

	TreelordStaff,
	AetherlordStaff,

	FireClawStaff,
	IceClawStaff,

	Drakenstaff,
	DracoAntiphonyScepter,
	AnnihilatorStaff,
	Heavenrender,
	StaffOfHeavensVengeance,

	lambda : FreeCastStaff("The Purifier", Tags.Holy, 120, ImmolateSpell),
	lambda : FreeCastStaff("Silvermelt", Tags.Fire, 80, MercurizeSpell),
	lambda : FreeCastStaff("Sorcwinter", Tags.Sorcery, 120, DeathChill),
	lambda : FreeCastStaff("The Dynamo", Tags.Lightning, 100, AnnihilateSpell),
	lambda : FreeCastStaff("The Blazeloom", Tags.Enchantment, 120, Blazerip),
	lambda : FreeCastStaff("Starblesser", Tags.Arcane, 80, HolyBlast),
	lambda : FreeCastStaff("The Sparkloom", Tags.Enchantment, 120, LightningBoltSpell),
	lambda : FreeCastStaff("Wintersting", Tags.Ice, 80, PoisonSting),
	lambda : FreeCastStaff("Red Majesty", Tags.Blood, 100, ScourgeSpell),
	lambda : FreeCastStaff("The Gloomthorn", Tags.Dark, 120, PrisonOfThorns),
	lambda : FreeCastStaff("Woadwyrd", Tags.Nature, 100, ShadowHexSpell),
	lambda : FreeCastStaff("Doombrand", Tags.Chaos, 100, SealFate),
	lambda : FreeCastStaff("Lightbinder", Tags.Eye, 120, PrismaticBeam),
	lambda : FreeCastStaff("The Lodestar", Tags.Metallic, 120, BlackHoleSpell),
	lambda : FreeCastStaff("The Haemanthus", Tags.Slime, 80, Bloodshift),

	RiftKeyStaff,
	Crackledark,

	ScepterOfSorrows,
	GhostfireScepter,

	# GlassAnimaStaff,
	QuillStaff,
	VolcanicLance,
	ErebusLance,
	HallucinogenicSporeStaff,
	#
	MulticoloredRageRod,
	Kettlestaff,
	BalorsEyeStaff,
	CultistsStaff,

	GlitteringDancersRobes,
	VoidSpikeStone,

	RobeOfStorms,
	FaeRobe,
	VampiricVestments,
	ArmorOfSouls,
	EarthtrollArmor,
	StormtrollArmor,
	RobeOfTwilight,
	RobeOfAgony,
	RobeOfFrostfire,
	RobeOfCrystals,
	RaimentOfEyes,
	OozingScaleArmor,
	SlimyVoodooMantle,
	TundraMantle,
	WyrmSpiritArmor,
	ChaosRobes,
	QuicksilverArmor,

	ChaosLinks,
	MenacingEyeMask,

	JaculusIdol,
	AmphisbaenaRing,
	HornofUr,

	MarksmanCap,
	WarlordCrown,
	WarlordVestments,
	SpiritVisor,
	CannibalMask,
	HelmOfTheHost,
	MaskOfIcyChill,
	StoneMask,
	EyeHelm,
	TalkingHat,
	CrownOfRagnarok,
	CrownOfDevastation,
	MacrophagicMask,
	GreyGoo,

	lambda : GenericFrenzyMask(Tags.Fire),
	lambda : GenericFrenzyMask(Tags.Ice),
	lambda : GenericFrenzyMask(Tags.Arcane),

	BloodspikeHelm,

	lambda : MinionCastHat("Chaos Scale Crown", AnnihilateSpell, Tags.Dragon, recipe_tag=Tags.Dragon),
	lambda : MinionCastHat("Crown of Bony Fingers", TouchOfDeath, Tags.Undead),
	lambda : MinionCastHat("Moon Crown", VoidBeamSpell, Tags.Holy, recipe_tag=Tags.Holy),

	DwarfHat,
	HelmOfHexes,
	MaskOfWoe,
	VeilpiercersMonocle,

	Earthboots,
	TravellersBoots,
	CantripClogs,
	TimeStriders,
	DrillShoes,
	WingedBoots,
	QuickstepBoots,

	BootsOfImminentDoom,
	RodOfHeavensAssault,

	SilkenSandals,
	SnowShoes,

	lambda : SummonShoes(4, Gnome, "Gnome Shoes"),
	lambda : SummonShoes(3, GreenSlime, "Slime Striders"),
	lambda : SummonShoes(3, Cultist, "Cultist Soles"),
	lambda : SummonShoes(2, Kobold, "Kobold Clogs"),
	lambda : SummonShoes(4, Ogre, "Ogre Boots"),
	lambda : SummonShoes(2, Ghost, "Ghost Slippers"),

	StormbroodTrickshoes,

	lambda : SpellBoots("Storm Boots", StormBurst, 8),
	lambda : SpellBoots("Exploding Boots", FlameBurstSpell, 8),
	lambda : SpellBoots("Earthquake Boots", EarthquakeSpell, 6),
	lambda : SpellBoots("Drain Boots", DrainPulse, 6),

	UnblinkingEye,
	SlimeTimer,
	PyrophiliaLocket,
	ArcaneCombustion,
	SearingEyeStone,
	MinionRegenerationAmulet,
	ArmorMelter,
	GraveHungerAmulet,
	ArcaneShield,
	MagicMinionShield,
	FaeThornStaff,
	VenomSpitterCasque,
	LightningTether,
	StolenFlameChoker,
	UnholyExpurgator,
	IceSickle,
	ChillStaff,
	ShatterShardsNecklace,
	AmuletOfCollectedAgony,
	Acidifier,
	VoidflameLantern,
	TwilightLantern,
	EchoStaff,
	Earthwrath,
	Razoreye,
	SonicShields,
	BlazebloodStaff,
	HexSpecialistsRing,

	CharmOfVigor,
	ArmorOfTheMaster,


	ChaliceOfLight,
	ChaliceOfIron,
	ChaliceOfWarp,
	ChaliceOfDragons,

	lambda: RechargeOnKillEquipment("Dragon", Tags.Dragon, Tags.Translocation),
	lambda: RechargeOnKillEquipment("Halo", Tags.Holy, Tags.Dark),
	lambda: RechargeOnKillEquipment("Void", Tags.Arcane, Tags.Arcane),
	lambda: RechargeOnKillEquipment("Thorn", Tags.Nature, Tags.Fire),
	lambda: RechargeOnKillEquipment("Mortal", Tags.Living, Tags.Blood),

	CrisisCharm,
	FingerSix,
	Ankh,
	EyeNecklace,
	AmberCube,
	SkullNecklace,
	RedObsidianShard,
	JadeShard,
	FangedAmulet,
	StoneeaterAmulet,
	BlizzardBeacon,
	StormBeacon,
	RainBeacon,
	AmuletOfUndeath,
	VialOfAmbrosia,
	AmuletOfEmeraldFlame,
	MonkeySkull,
	NeanderthalsTooth,
	Bloodruby,
	BloodShield,
	RingOfMagneticCharisma,

	lambda : PrinceOfRuinLike("Silken Links", [Tags.Arcane, Tags.Nature], damage_tags=[Tags.Arcane, Tags.Poison]),
	lambda : PrinceOfRuinLike("Winter Links", [Tags.Ice, Tags.Dark]),
	lambda : PrinceOfRuinLike("Wrath Links", [Tags.Holy, Tags.Lightning]),
	lambda : PrinceOfRuinLike("Prismatic Links", [Tags.Holy, Tags.Ice]),

	lambda : StatusOnDamageEquipment(name="Paralyzing Venom", tags=[Tags.Nature], recipe=[(Tags.Nature, 1), (Tags.Enchantment, 1), (Tags.Any, 2)], damage_type=Tags.Poison, status=Stun, chance=30, duration=2, status_name='stun'),
	lambda : StatusOnDamageEquipment(name="Chastising Lash", tags=[Tags.Holy], recipe=[(Tags.Holy, 1), (Tags.Enchantment, 1), (Tags.Any, 2)], damage_type=Tags.Holy, status=Stun, chance=40, duration=1, status_name='stun'),
	lambda : StatusOnDamageEquipment(name="Coldsnap Amulet", tags=[Tags.Ice], recipe=[(Tags.Ice, 1), (Tags.Metallic, 1), (Tags.Any, 2)], damage_type=Tags.Ice, status=FrozenBuff, chance=40, duration=2, status_name='frozen'),
	lambda : StatusOnDamageEquipment(name="Necrosis Blade", tags=[Tags.Dark], recipe=[(Tags.Dark, 1), (Tags.Metallic, 1), (Tags.Any, 2)], damage_type=Tags.Dark, status=NecrosisBuff, chance=60, duration=3, status_name='necrosis'),
	lambda : StatusOnDamageEquipment(name="Hypno Bauble", tags=[Tags.Arcane], recipe=[(Tags.Arcane, 1), (Tags.Dark, 1), (Tags.Enchantment, 1), (Tags.Any, 1)], damage_type=Tags.Arcane, status=SleepBuff, chance=40, duration=3, status_name='sleep'),
	lambda : StatusOnDamageEquipment(name="Coruscating Wand", tags=[Tags.Lightning], recipe=[(Tags.Lightning, 1), (Tags.Enchantment, 1), (Tags.Any, 2)], damage_type=Tags.Lightning, status=BlindBuff, chance=40, duration=3, status_name='blind'),

	lambda : CurseDoll("Stone", [Tags.Arcane, Tags.Construct], PetrifySpell),
	lambda : CurseDoll("Ruinous", [Tags.Demon, Tags.Blood], LifedrainSpell),
	lambda : CurseDoll("Pyrostatic", [Tags.Fire, Tags.Lightning], PyrostaticCurse),
	lambda : CurseDoll("Grave", [Tags.Dark, Tags.Undead], ShadowHexSpell),

	CausticSprig,

	lambda: DebuffDamager("Nightmare Hexbag", 4, Tags.Dark, 25, SleepBuff, [Tags.Arcane, Tags.Dark]),
	lambda: DebuffDamager("Dowsing Spark", 5, Tags.Lightning, 20, SoakedBuff, [Tags.Lightning, Tags.Nature]),
	lambda: DebuffDamager("Hemlock Needle", 10, Tags.Dark, 10, BleedBuff, [Tags.Blood, Tags.Dark]),
	lambda : DebuffDamager("Fae Toxin Pouch", 20, Tags.Arcane, 5, Poison, [Tags.Arcane, Tags.Nature]),
	lambda : DebuffDamager("Icy Cruciform", 25, Tags.Holy, 4, FrozenBuff, [Tags.Ice, Tags.Holy]),

	EvermeltingCube,
	WoundRotAmulet,
	ExplosiveSporeManual,
	EyeOfTamtu,
	EyeOfMot,
	EyeOfAmmut,
	ArcaneAccelerator,
	CodexOfChaoticEvolution,
	OrbOfInfiniteSlaughter,
	CystOfEternalBloom,
	PrismOfShatteredSensations,
	BasiliskScaleArmor,
	ChaosSerpentStaff,
	StormCallerStaff
]

def make_all_items():
	items = [item() for item in all_equipment]
	items.sort(key=lambda item: (len(flat_recipe(getattr(item, "recipe", []))), getattr(item, "name", "")))
	return items

def flat_recipe(recipe):
	flat = []
	for tag, amount in recipe:
		flat.extend([tag] * amount)
	return flat

# def treasure_chest(difficulty, prng=random):
# 	items = Staves + Robes + Hats + Boots + Amulets
# 	k = CHEST_SIZE + 1
# 	prng.shuffle(items)
# 	items = items[:k]
# 	items = [i() for i in items]
#
# 	shop = Shop()
# 	shop.name = "Treasure Chest"
#
# 	shop.items = items
# 	shop.asset = ['tiles', 'crafting', 'default']
# 	return shop

def test_equipment():
	failures = []
	for item in all_equipment:
		item_class_name = item.__name__
		item = item()

		name = getattr(item, "name", None)
		if not name: failures.append(f"{item_class_name}: missing .name")
		elif name == "Unnamed buff": failures.append(f"{item_class_name}: placeholder name")

		global_triggers = getattr(item, "global_triggers", [])
		owner_triggers = getattr(item, "owner_triggers", [])
		if (global_triggers or owner_triggers) and not item.get_description():
			failures.append(f"{item.name}: missing description despite having triggers")

		tags = getattr(item, "tags", [])
		for tag in tags:
			if tag not in component_tags:
				failures.append(f"{item.name}: contains illegal tags")
		if not tags: failures.append(f"{item.name}: has no tags")

		recipe = getattr(item, "recipe", [])
		price = 0
		for entry in recipe:
			t, a = entry
			if t not in component_tags: failures.append(f"{item.name} recipe: contains illegal tags")
			if not isinstance(a, int): failures.append(f"{item.name} recipe: contains an illegal amount of tags")
			price += a
		if price > 10: failures.append(f"{item.name} recipe contains too many ({sum}) tags.")

	if failures:
		print("\nEquipment validation failed;\n" + "\n".join(failures))
		raise AssertionError(f"{len(failures)} issues found in equipment list")

	print(f"{len(all_equipment)} / {len(all_equipment)} Equipment Checks Passed.")

def print_item_blurbs():
	for item in all_equipment:
		item = item()

		asset = ['tiles', 'items', 'equipment', item.name.lower().replace(' ', '_')]
		# use generic trinket asset if specific asset is not present
		theoretical_fn = os.path.join('rl_data', *asset) + '.png'
		if os.path.exists(theoretical_fn): continue

		print(item.get_description())

		for attr, bonus in item.global_bonuses.items(): print("+%d %s" % (bonus, attr))
		for attr, bonus in item.global_bonuses_pct.items(): print("+%d%% %s" % (bonus, attr))

		for tag in item.tag_bonuses:
			for attr, bonus in item.tag_bonuses[tag].items(): print("+%d %s for %s" % (bonus, attr, tag.name))
		for tag in item.tag_bonuses_pct:
			for attr, bonus in item.tag_bonuses_pct[tag].items(): print("+%d%% %s for %s" % (bonus, attr, tag.name))

		for tag, resist in item.resists.items(): print("%d%% resist %s" % (resist, tag.name))
		print('\n')

def print_under_represented_equipment_tags():
	tag_representation = defaultdict(int)
	recipe_representation = defaultdict(int)
	for equipment in all_equipment:
		e = equipment()
		for tag in e.tags: tag_representation[tag.name] += 1
		for tag, amt in e.recipe: recipe_representation[tag.name] += 1
	for t, n in sorted(tag_representation.items(), key=lambda item: (item[1], item[0])):
		print(f"{t} has {n} equipment.")
	for t, n in sorted(recipe_representation.items(), key=lambda item: (item[1], item[0])):
		print(f"{n} {t} tags across all recipes.")

def print_equipment_costs_by_tag():
	cost_dict = defaultdict(lambda: defaultdict(int))
	for e in all_equipment:
		e = e()
		cost = 0
		for tag, amt in e.recipe: cost += amt
		for tag in e.tags: cost_dict[cost][tag.name] += 1 # one more piece of equipment at that price point with that tag
	for cost in sorted(cost_dict):
		tag_counts = cost_dict[cost]
		parts = [f"{name}:{cnt}" for name, cnt in sorted(tag_counts.items(), key=lambda kv: (-kv[1], kv[0]))]
		print(f"{cost} -> " + ", ".join(parts))


if __name__ == "__main__":
	test_equipment()
	print_under_represented_equipment_tags()
	print_equipment_costs_by_tag()
	# print_item_blurbs()
